/**
 * ProNotes — Windows desktop app (Electron)
 * =========================================
 * A real .exe: its own icon, its own window, no browser and no Node server.
 *
 * How the app is loaded
 * ---------------------
 * The static export in ./out is served through a custom `pronotes://` scheme
 * rather than file://, because:
 *   - Next.js emits ABSOLUTE asset paths (/_next/...), which file:// resolves
 *     against the drive root and fails to find.
 *   - file:// is an opaque origin, so localStorage would not persist reliably —
 *     which is where every board is stored.
 * Registering the scheme as `standard: true, secure: true` gives it a stable,
 * secure origin, so storage persists across restarts exactly like a website.
 */

const { app, BrowserWindow, shell, protocol, net, Menu } = require("electron");
const path = require("node:path");
const { pathToFileURL } = require("node:url");

const SCHEME = "pronotes";
const WEB_ROOT = path.join(__dirname, "..", "out");

// Must be called before `app.ready`.
protocol.registerSchemesAsPrivileged([
  {
    scheme: SCHEME,
    privileges: {
      standard: true,
      secure: true,
      supportFetchAPI: true,
      stream: true,
    },
  },
]);

/** Resolve a request path to a file inside ./out, refusing to escape it. */
function resolveWebPath(urlPath) {
  const decoded = decodeURIComponent(urlPath.split("?")[0].split("#")[0]);
  const relative = decoded === "/" || decoded === "" ? "index.html" : decoded.replace(/^\/+/, "");
  const full = path.join(WEB_ROOT, relative);

  // Path-traversal guard: a crafted URL must never read outside the bundle.
  const normalizedRoot = path.resolve(WEB_ROOT) + path.sep;
  const normalizedFull = path.resolve(full);
  if (!normalizedFull.startsWith(normalizedRoot)) return null;

  return normalizedFull;
}

function createWindow() {
  const win = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 900,
    minHeight: 600,
    backgroundColor: "#09090b",
    title: "ProNotes",
    icon: path.join(__dirname, "..", "public", "pronotes.ico"),
    // Don't paint a white flash before the app renders.
    show: false,
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      // The canvas is the whole app; let it use the GPU.
      backgroundThrottling: false,
    },
  });

  win.once("ready-to-show", () => win.show());
  win.loadURL(`${SCHEME}://app/index.html`);

  // Any external link (docs, a wiki link the user pasted) opens in the real
  // browser instead of replacing the app inside its own window.
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith("http://") || url.startsWith("https://")) {
      shell.openExternal(url);
    }
    return { action: "deny" };
  });
  win.webContents.on("will-navigate", (event, url) => {
    if (url.startsWith(`${SCHEME}://`)) return;

    // Never let the window navigate away from the app.
    event.preventDefault();

    // Only real web links are handed to the browser. A dropped file arrives
    // here as file:// — passing that to openExternal would launch the user's
    // PDF reader as a side effect of dragging a document onto the app, which
    // is not what the gesture means. Anything that is not http(s) is simply
    // refused.
    if (url.startsWith("http://") || url.startsWith("https://")) {
      shell.openExternal(url);
    }
  });

  return win;
}

// One instance only — a second launch focuses the existing window rather than
// opening a rival copy with its own view of the same storage.
// Must match electron-builder's `appId` (package.json). Windows groups taskbar
// buttons, pins and jump lists by this id; without it the running window can
// fail to group with its own pinned shortcut.
if (process.platform === "win32") app.setAppUserModelId("com.idrees.pronotes");

if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  let mainWindow = null;

  app.on("second-instance", () => {
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.focus();
    }
  });

  app.whenReady().then(() => {
    protocol.handle(SCHEME, (request) => {
      const url = new URL(request.url);
      const filePath = resolveWebPath(url.pathname);
      if (!filePath) {
        return new Response("Forbidden", { status: 403 });
      }
      // A missing file (a stale chunk after a partial rebuild, a typo'd path)
      // must answer 404, not throw: an exception here fails the request with a
      // bare network error, which on index.html is a silent blank window.
      return net.fetch(pathToFileURL(filePath).toString()).catch((err) => {
        console.error(`[pronotes://] ${url.pathname}:`, err && err.message);
        return new Response("Not found", { status: 404 });
      });
    });

    // A menu bar would just take vertical space from an infinite canvas;
    // every action already has a toolbar button and a shortcut.
    Menu.setApplicationMenu(null);

    mainWindow = createWindow();

    app.on("activate", () => {
      if (BrowserWindow.getAllWindows().length === 0) mainWindow = createWindow();
    });
  });

  app.on("window-all-closed", () => {
    if (process.platform !== "darwin") app.quit();
  });
}
