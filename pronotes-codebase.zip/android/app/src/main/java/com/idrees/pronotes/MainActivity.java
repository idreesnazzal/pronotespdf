package com.idrees.pronotes;
 
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.webkit.PermissionRequest;
import android.webkit.WebView;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

import com.getcapacitor.BridgeActivity;
import com.getcapacitor.BridgeWebChromeClient;

/**
 * Bridges the stylus side button and eraser tip into the web layer.
 *
 * Why this is native
 * ------------------
 * Chromium's WebView does not surface the S Pen side button to web content at
 * all — the in-app diagnostic recorded nothing while it was held, so there is
 * no JavaScript fix available. Android itself does report it, on every
 * MotionEvent, and because this is a Capacitor app the Activity sees those
 * events before the WebView consumes them.
 *
 * Reading the button correctly, though, is not just "check getButtonState()".
 * The first version did exactly that on every event and was visibly buggy:
 *
 *   1. Android CLEARS the button state on ACTION_UP. Lifting the nib while
 *      still holding the button therefore read as a release — the tool flipped
 *      back to the pen, and the next hover flipped it to the eraser again. That
 *      is the flicker.
 *
 *   2. ACTION_HOVER_EXIT does NOT only mean "the pen left". It also fires
 *      immediately before every ACTION_DOWN, as the pen crosses from hovering
 *      into contact. Treating it as "pen gone" cancels the gesture mid-stroke.
 *
 *   3. The eraser TIP is a tool type, not a button (Android's stylus guide is
 *      explicit: `TOOL_TYPE_ERASER == event.getToolType(i)`). Folding it into
 *      the button test made one latch answer two different questions.
 *
 * So the rules below are deliberate:
 *
 *   ACTION_BUTTON_PRESS / ACTION_BUTTON_RELEASE  authoritative — these exist
 *                                                for precisely this purpose
 *   DOWN / MOVE / HOVER_ENTER / HOVER_MOVE       sync from getButtonState()
 *   UP / CANCEL                                  IGNORE the button state; it
 *                                                has been cleared and does not
 *                                                mean the button came up
 *   HOVER_EXIT                                   maybe the pen left, maybe the
 *                                                nib is landing — decided by a
 *                                                short timer any further
 *                                                stylus event cancels
 *
 * Not covered: the S Pen's Bluetooth remote button (Air Actions). That is
 * delivered over BLE to Samsung's S Pen Remote SDK and never reaches an
 * ordinary Activity.
 */
public class MainActivity extends BridgeActivity {

    private static final int REQUEST_RECORD_AUDIO_PERMISSION = 2001;
    private PermissionRequest pendingAudioPermissionRequest = null;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        // App-local plugins must be registered BEFORE the bridge starts.
        // GallerySaver puts screenshots where the Gallery app shows them.
        registerPlugin(GallerySaverPlugin.class);
        super.onCreate(savedInstanceState);

        // Configure WebView to grant audio capture permissions for Web Speech / getUserMedia
        if (getBridge() != null && getBridge().getWebView() != null) {
            getBridge().getWebView().setWebChromeClient(new BridgeWebChromeClient(getBridge()) {
                @Override
                public void onPermissionRequest(final PermissionRequest request) {
                    boolean audioRequested = false;
                    for (String r : request.getResources()) {
                        if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) {
                            audioRequested = true;
                            break;
                        }
                    }
                    if (!audioRequested) {
                        // Not ours to decide: Capacitor's own handling asks
                        // Android for whatever the page wants (camera...).
                        // Granting blindly handed out access nobody approved.
                        super.onPermissionRequest(request);
                        return;
                    }
                    runOnUiThread(() -> {
                        // Only the microphone is granted here, even when the
                        // page asked for more in the same request.
                        final String[] audioOnly = new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE};
                        if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.RECORD_AUDIO)
                                == PackageManager.PERMISSION_GRANTED) {
                            request.grant(audioOnly);
                        } else {
                            // A request still waiting is answered, never dropped:
                            // an unanswered one leaves the page waiting forever.
                            if (pendingAudioPermissionRequest != null) {
                                pendingAudioPermissionRequest.deny();
                            }
                            pendingAudioPermissionRequest = request;
                            ActivityCompat.requestPermissions(
                                MainActivity.this,
                                new String[]{Manifest.permission.RECORD_AUDIO},
                                REQUEST_RECORD_AUDIO_PERMISSION
                            );
                        }
                    });
                }
            });
        }

        handleIncoming(getIntent());
    }

    // ------------------------------------------------------------------
    // Files opened or shared from other apps ("Open with" / "Share")
    // ------------------------------------------------------------------
    // Android hands us a content:// URI that only this Activity may read, and
    // only for a while. So the bytes are copied into the app's cache first,
    // then the page is told the file's path; it fetches it through Capacitor's
    // local server (/_capacitor_file_/...) and imports it like a dropped file.
    // The page may still be loading (a cold start from WhatsApp), so delivery
    // is retried until the page says it took the files.

    private static final long DELIVER_RETRY_MS = 400;
    private static final int DELIVER_MAX_TRIES = 150; // ~60 s

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIncoming(intent);
    }

    private void handleIncoming(Intent intent) {
        if (intent == null) return;
        final String action = intent.getAction();
        final List<Uri> uris = new ArrayList<>();
        if (Intent.ACTION_VIEW.equals(action) && intent.getData() != null) {
            uris.add(intent.getData());
        } else if (Intent.ACTION_SEND.equals(action)) {
            Uri u = intent.getParcelableExtra(Intent.EXTRA_STREAM);
            if (u != null) uris.add(u);
        } else if (Intent.ACTION_SEND_MULTIPLE.equals(action)) {
            ArrayList<Uri> list = intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
            if (list != null) uris.addAll(list);
        }
        if (uris.isEmpty()) return;
        final String fallbackType = intent.getType();
        // Handled once: rotating the screen must not import the file again.
        intent.setAction(Intent.ACTION_MAIN);
        intent.setData(null);

        new Thread(() -> {
            JSONArray files = new JSONArray();
            File dir = new File(getCacheDir(), "incoming");
            //noinspection ResultOfMethodCallIgnored
            dir.mkdirs();
            // Copies are only needed until the page has imported them (it
            // keeps its own copy in IndexedDB), so a day-old one is garbage.
            File[] old = dir.listFiles();
            if (old != null) {
                long cutoff = System.currentTimeMillis() - 24L * 60 * 60 * 1000;
                for (File f : old) {
                    //noinspection ResultOfMethodCallIgnored
                    if (f.lastModified() < cutoff) f.delete();
                }
            }
            for (Uri uri : uris) {
                try {
                    String name = displayName(uri);
                    String type = getContentResolver().getType(uri);
                    if (type == null) type = fallbackType;
                    if (type == null && name.toLowerCase().endsWith(".pdf")) type = "application/pdf";
                    File out = new File(dir, System.currentTimeMillis() + "_" + name.replaceAll("[\\/:*?\"<>|]", "_"));
                    try (InputStream in = getContentResolver().openInputStream(uri);
                         OutputStream os = new FileOutputStream(out)) {
                        if (in == null) continue;
                        byte[] buf = new byte[64 * 1024];
                        int n;
                        while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
                    }
                    JSONObject f = new JSONObject();
                    f.put("path", out.getAbsolutePath());
                    f.put("name", name);
                    f.put("type", type == null ? "" : type);
                    files.put(f);
                } catch (Exception e) {
                    try {
                        JSONObject f = new JSONObject();
                        f.put("error", "Could not read a file from the other app: " + e.getMessage());
                        files.put(f);
                    } catch (Exception ignored) {
                        // nothing more to report
                    }
                }
            }
            if (files.length() > 0) deliver(files.toString(), 0);
        }).start();
    }

    private String displayName(Uri uri) {
        String name = null;
        try (Cursor c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) name = c.getString(0);
        } catch (Exception ignored) {
            // some providers do not answer; fall back to the path
        }
        if (name == null || name.isEmpty()) name = uri.getLastPathSegment();
        if (name == null || name.isEmpty()) name = "Shared file";
        return name;
    }

    private void deliver(final String json, final int attempt) {
        if (attempt >= DELIVER_MAX_TRIES) return;
        final String js =
            "(function(){var f=window.__pronotesReceiveFiles;if(!f)return 'wait';f(" + json + ");return 'ok';})()";
        runOnUiThread(() -> {
            WebView webView = getBridge() != null ? getBridge().getWebView() : null;
            if (webView == null) {
                handler.postDelayed(() -> deliver(json, attempt + 1), DELIVER_RETRY_MS);
                return;
            }
            webView.evaluateJavascript(js, result -> {
                if (result == null || !result.contains("ok")) {
                    handler.postDelayed(() -> deliver(json, attempt + 1), DELIVER_RETRY_MS);
                }
            });
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_RECORD_AUDIO_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                if (pendingAudioPermissionRequest != null) {
                    pendingAudioPermissionRequest.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
                    pendingAudioPermissionRequest = null;
                }
            } else {
                if (pendingAudioPermissionRequest != null) {
                    pendingAudioPermissionRequest.deny();
                    pendingAudioPermissionRequest = null;
                }
            }
        }
    }

    /**
     * How long to wait after HOVER_EXIT before deciding the pen really left.
     * The exit that precedes a touch-down is followed by ACTION_DOWN within a
     * frame or two, so anything this side of ~80ms is the same gesture.
     */
    private static final long HOVER_EXIT_GRACE_MS = 80;

    /** Last state reported to the page; only changes are sent. */
    private boolean reportedDown = false;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable penLeft = () -> setDown(false, 0, -1, "HOVER_EXIT timeout");

    private static boolean isStylus(MotionEvent event) {
        if (event.getPointerCount() < 1) return false;
        int tool = event.getToolType(0);
        return tool == MotionEvent.TOOL_TYPE_STYLUS || tool == MotionEvent.TOOL_TYPE_ERASER;
    }

    /** True when the side button is held, per the button bits alone. */
    private static boolean buttonHeld(int state) {
        return (state & MotionEvent.BUTTON_STYLUS_PRIMARY) != 0
            || (state & MotionEvent.BUTTON_STYLUS_SECONDARY) != 0
            || (state & MotionEvent.BUTTON_SECONDARY) != 0;
    }

    private void setDown(boolean down, int buttonState, int toolType, String because) {
        if (down == reportedDown) return;
        reportedDown = down;

        final String js =
            "window.dispatchEvent(new CustomEvent('pronotes:stylusbutton',{detail:{pressed:"
                + (down ? "true" : "false")
                + ",buttonState:"
                + buttonState
                + ",toolType:"
                + toolType
                + ",because:'"
                + because
                + "'}}))";

        runOnUiThread(() -> {
            try {
                WebView webView = getBridge() != null ? getBridge().getWebView() : null;
                if (webView != null) webView.evaluateJavascript(js, null);
            } catch (Exception ignored) {
                // A button press must never crash the app. If the bridge is not
                // up the press is simply lost, as it was before this existed.
            }
        });
    }

    private void observe(MotionEvent event) {
        final int action = event.getActionMasked();
        final int buttons = event.getButtonState();
        final int toolType = event.getToolType(0);
        // The eraser end of the pen is its own signal and needs no button.
        final boolean erasing = buttonHeld(buttons) || toolType == MotionEvent.TOOL_TYPE_ERASER;

        // Any real stylus activity means the pen did not leave.
        handler.removeCallbacks(penLeft);

        switch (action) {
            case MotionEvent.ACTION_BUTTON_PRESS:
                setDown(true, buttons, toolType, "BUTTON_PRESS");
                return;

            case MotionEvent.ACTION_BUTTON_RELEASE:
                // Authoritative: the button itself came up. The eraser TIP can
                // still hold the state on its own.
                setDown(toolType == MotionEvent.TOOL_TYPE_ERASER, buttons, toolType, "BUTTON_RELEASE");
                return;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                // Android has cleared the button bits here. Reading them would
                // report a release the user never made — this is the flicker.
                return;

            case MotionEvent.ACTION_HOVER_EXIT:
                // Either the pen is leaving, or the nib is about to land. Let a
                // following event say which; if none comes, the pen left.
                handler.postDelayed(penLeft, HOVER_EXIT_GRACE_MS);
                return;

            default:
                // DOWN, MOVE, HOVER_ENTER, HOVER_MOVE: the state is meaningful.
                setDown(erasing, buttons, toolType, "action " + action);
        }
    }

    // ------------------------------------------------------------------
    // Observing is not enough: the WebView must not SEE the button
    // ------------------------------------------------------------------
    // Measured on a Galaxy Tab S9: with the side button held, the kernel
    // reported BTN_STYLUS DOWN -> touch -> lift -> BTN_STYLUS UP, and this
    // bridge told the page to switch to the eraser - but the WebView delivered
    // NO pen pointerdown for the stroke at all. Android turns stylus-button +
    // contact into a context click, which reached the page as a `contextmenu`
    // event (pointerType "mouse") while the stroke itself was swallowed. So the
    // app switched to the eraser and then had nothing to erase with.
    //
    // The fix is to keep observing the real event (above) and then hand the
    // WebView a copy with the button bits cleared: to the web layer it is an
    // ordinary pen stroke, and the eraser choice travels separately through
    // the pronotes:stylusbutton bridge. ACTION_BUTTON_PRESS / RELEASE are
    // consumed outright - they exist only to drive that context click.

    /**
     * A copy of the event with no buttons down, fully preserving all historical
     * 240Hz+ digitizer samples so erasing and hover tracking maintain maximum
     * coordinate density and smooth path geometry.
     * Caller is responsible for recycling the returned MotionEvent.
     */
    private static MotionEvent withoutButtons(MotionEvent ev) {
        final int n = ev.getPointerCount();
        final MotionEvent.PointerProperties[] props = new MotionEvent.PointerProperties[n];
        for (int i = 0; i < n; i++) {
            props[i] = new MotionEvent.PointerProperties();
            ev.getPointerProperties(i, props[i]);
        }

        final int historySize = ev.getHistorySize();

        // Fast-path: When there are no historical samples (e.g. single sample or non-MOVE event),
        // perform a single standard obtain with buttonState = 0.
        if (historySize == 0) {
            final MotionEvent.PointerCoords[] coords = new MotionEvent.PointerCoords[n];
            for (int i = 0; i < n; i++) {
                coords[i] = new MotionEvent.PointerCoords();
                ev.getPointerCoords(i, coords[i]);
            }
            return MotionEvent.obtain(
                ev.getDownTime(), ev.getEventTime(), ev.getAction(), n, props, coords,
                ev.getMetaState(), 0 /* buttonState */, ev.getXPrecision(), ev.getYPrecision(),
                ev.getDeviceId(), ev.getEdgeFlags(), ev.getSource(), ev.getFlags());
        }

        // Full historical reconstruction:
        // Initialize the event with the OLDEST historical sample (index 0),
        // append intermediate historical samples (indices 1 .. historySize - 1),
        // and finally append the current (latest) sample.
        final MotionEvent.PointerCoords[] batchCoords = new MotionEvent.PointerCoords[n];
        for (int i = 0; i < n; i++) {
            batchCoords[i] = new MotionEvent.PointerCoords();
        }

        // 1. Initial sample: oldest historical sample at index 0
        for (int i = 0; i < n; i++) {
            ev.getHistoricalPointerCoords(i, 0, batchCoords[i]);
        }
        final MotionEvent clean = MotionEvent.obtain(
            ev.getDownTime(), ev.getHistoricalEventTime(0), ev.getAction(), n, props, batchCoords,
            ev.getMetaState(), 0 /* buttonState */, ev.getXPrecision(), ev.getYPrecision(),
            ev.getDeviceId(), ev.getEdgeFlags(), ev.getSource(), ev.getFlags());

        // 2. Intermediate historical samples (indices 1 .. historySize - 1)
        for (int h = 1; h < historySize; h++) {
            for (int i = 0; i < n; i++) {
                ev.getHistoricalPointerCoords(i, h, batchCoords[i]);
            }
            clean.addBatch(ev.getHistoricalEventTime(h), batchCoords, ev.getMetaState());
        }

        // 3. Current (latest) sample
        for (int i = 0; i < n; i++) {
            ev.getPointerCoords(i, batchCoords[i]);
        }
        clean.addBatch(ev.getEventTime(), batchCoords, ev.getMetaState());

        return clean;
    }

    /** True for the events that exist only to trigger a context click. */
    private static boolean isButtonAction(MotionEvent ev) {
        final int a = ev.getActionMasked();
        return a == MotionEvent.ACTION_BUTTON_PRESS || a == MotionEvent.ACTION_BUTTON_RELEASE;
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent event) {
        if (!isStylus(event)) return super.dispatchTouchEvent(event);
        observe(event);
        if (isButtonAction(event)) return true;
        if (!buttonHeld(event.getButtonState())) return super.dispatchTouchEvent(event);
        final MotionEvent clean = withoutButtons(event);
        try {
            return super.dispatchTouchEvent(clean);
        } finally {
            clean.recycle();
        }
    }

    @Override
    public boolean dispatchGenericMotionEvent(MotionEvent event) {
        if (!isStylus(event)) return super.dispatchGenericMotionEvent(event);
        observe(event);
        if (isButtonAction(event)) return true;
        if (!buttonHeld(event.getButtonState())) return super.dispatchGenericMotionEvent(event);
        final MotionEvent clean = withoutButtons(event);
        try {
            return super.dispatchGenericMotionEvent(clean);
        } finally {
            clean.recycle();
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        // Leaving the app with the button held must not strand the eraser.
        handler.removeCallbacks(penLeft);
        setDown(false, 0, -1, "onPause");
    }
}
