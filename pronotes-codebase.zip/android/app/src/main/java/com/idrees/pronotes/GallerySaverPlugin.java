package com.idrees.pronotes;

import android.Manifest;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;

import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

/**
 * Saves a picture where the Gallery / Photos app will show it.
 *
 * Why this is native
 * ------------------
 * The export path (share.ts) writes to the app's CACHE and opens the share
 * sheet. That is right for sending a file, but nothing written there - or
 * anywhere else @capacitor/filesystem can reach on Android 10+ - is indexed
 * by the media store, so the picture never appears in Gallery. Scoped storage
 * leaves exactly one sanctioned way in: insert the image into MediaStore.
 *
 *   Android 10+ (API 29+)  MediaStore insert into Pictures/<album>, marked
 *                          IS_PENDING while the bytes are written so Gallery
 *                          never shows a half-written file. Needs NO
 *                          permission: an app may always add its own media.
 *   Android 5-9            The public Pictures/<album> folder plus a media
 *                          scan, which needs WRITE_EXTERNAL_STORAGE (declared
 *                          with maxSdkVersion 28, so newer devices never see
 *                          the prompt).
 *
 * JS: registerPlugin("GallerySaver").saveImage({ data, filename, album })
 * where `data` is base64 PNG/JPEG bytes (no data: prefix). Resolves with
 * { uri } of the saved picture.
 */
@CapacitorPlugin(
    name = "GallerySaver",
    permissions = {
        @Permission(strings = { Manifest.permission.WRITE_EXTERNAL_STORAGE }, alias = "storage")
    }
)
public class GallerySaverPlugin extends Plugin {

    @PluginMethod
    public void saveImage(PluginCall call) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q && getPermissionState("storage") != PermissionState.GRANTED) {
            requestPermissionForAlias("storage", call, "storagePermissionCallback");
            return;
        }
        save(call);
    }

    @PermissionCallback
    private void storagePermissionCallback(PluginCall call) {
        if (getPermissionState("storage") == PermissionState.GRANTED) {
            save(call);
        } else {
            call.reject("Permission to save pictures was not given.", "PERMISSION_DENIED");
        }
    }

    private void save(PluginCall call) {
        String data = call.getString("data");
        String filename = call.getString("filename", "ProNotes.png");
        String album = call.getString("album", "ProNotes");
        if (data == null || data.isEmpty()) {
            call.reject("No picture was given.");
            return;
        }
        int comma = data.indexOf(',');
        if (data.startsWith("data:") && comma >= 0) data = data.substring(comma + 1);

        final byte[] bytes;
        try {
            bytes = Base64.decode(data, Base64.DEFAULT);
        } catch (IllegalArgumentException e) {
            call.reject("The picture data could not be read.", e);
            return;
        }
        String mime = filename.toLowerCase().endsWith(".jpg") || filename.toLowerCase().endsWith(".jpeg")
            ? "image/jpeg"
            : "image/png";

        try {
            Uri uri = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
                ? saveViaMediaStore(bytes, filename, album, mime)
                : saveLegacy(bytes, filename, album, mime);
            JSObject ret = new JSObject();
            ret.put("uri", uri != null ? uri.toString() : "");
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("The picture could not be saved to the gallery: " + e.getMessage(), e);
        }
    }

    private Uri saveViaMediaStore(byte[] bytes, String filename, String album, String mime) throws Exception {
        ContentResolver resolver = getContext().getContentResolver();
        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.DISPLAY_NAME, filename);
        values.put(MediaStore.Images.Media.MIME_TYPE, mime);
        values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + File.separator + album);
        values.put(MediaStore.Images.Media.DATE_TAKEN, System.currentTimeMillis());
        values.put(MediaStore.Images.Media.IS_PENDING, 1);

        Uri collection = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
        Uri uri = resolver.insert(collection, values);
        if (uri == null) throw new IllegalStateException("MediaStore refused the new picture");
        try (OutputStream out = resolver.openOutputStream(uri)) {
            if (out == null) throw new IllegalStateException("could not open the new picture for writing");
            out.write(bytes);
        } catch (Exception e) {
            // Leave no empty, pending entry behind in the gallery.
            resolver.delete(uri, null, null);
            throw e;
        }
        ContentValues done = new ContentValues();
        done.put(MediaStore.Images.Media.IS_PENDING, 0);
        resolver.update(uri, done, null, null);
        return uri;
    }

    @SuppressWarnings("deprecation")
    private Uri saveLegacy(byte[] bytes, String filename, String album, String mime) throws Exception {
        File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), album);
        if (!dir.exists() && !dir.mkdirs()) throw new IllegalStateException("could not create " + dir);
        File file = new File(dir, filename);
        try (FileOutputStream out = new FileOutputStream(file)) {
            out.write(bytes);
        }
        // Without a scan the file exists but the gallery does not know it.
        MediaScannerConnection.scanFile(getContext(), new String[] { file.getAbsolutePath() }, new String[] { mime }, null);
        return Uri.fromFile(file);
    }
}
