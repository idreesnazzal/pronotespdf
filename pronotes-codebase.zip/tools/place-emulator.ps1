﻿<#
    place-emulator.ps1 - LAST RESORT window placement.

    Read this before using it: moving the emulator window with MoveWindow has
    crashed the emulator on this machine's Intel Arc driver -

        Critical: UpdateLayeredWindowIndirect failed ... (device not functioning)
        ERROR    : Failed to find ColorBuffer: 110

    The supported fix is to pin `window.scale` / `window.x` / `window.y` in the
    AVD's emulator-user.ini before launch, which run-emulator.ps1 does. So this
    script deliberately does NOTHING when the window already fits, and only
    moves one that is genuinely unreachable (a title bar above the screen top
    cannot be grabbed with the mouse).
#>

param([switch] $Force)

Add-Type -TypeDefinition @'
using System;
using System.Text;
using System.Collections.Generic;
using System.Runtime.InteropServices;
public class EmuPlace {
  [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr p);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
  [DllImport("user32.dll")] public static extern int  GetWindowText(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
  [DllImport("user32.dll")] public static extern bool MoveWindow(IntPtr h, int x, int y, int w, int ht, bool repaint);
  public delegate bool EnumProc(IntPtr h, IntPtr p);
  [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left, Top, Right, Bottom; }
  public static List<IntPtr> Visible() {
    var all = new List<IntPtr>();
    EnumWindows((h, p) => { if (IsWindowVisible(h)) all.Add(h); return true; }, IntPtr.Zero);
    return all;
  }
  public static string Title(IntPtr h) { var sb = new StringBuilder(256); GetWindowText(h, sb, 256); return sb.ToString(); }
}
'@ -ErrorAction SilentlyContinue

Add-Type -AssemblyName System.Windows.Forms
$wa = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea

$main = $null
foreach ($hwnd in [EmuPlace]::Visible()) {
    if ([EmuPlace]::Title($hwnd) -like "Android Emulator - *") { $main = $hwnd; break }
}
if (-not $main) { Write-Warning "No emulator window found."; exit 0 }

$r = New-Object EmuPlace+RECT
[void][EmuPlace]::GetWindowRect($main, [ref]$r)
$w = $r.Right - $r.Left; $h = $r.Bottom - $r.Top
$onScreen = ($r.Left -ge 0 -and $r.Top -ge 0 -and $r.Right -le $wa.Width -and $r.Bottom -le $wa.Height)

if ($onScreen -and -not $Force) {
    "Emulator window is already on screen at $($r.Left),$($r.Top) ${w}x${h} - leaving it alone."
    exit 0
}

Write-Warning "Window is off screen at $($r.Left),$($r.Top) ${w}x${h}. Moving it (this can crash the emulator on Intel GPUs)."
$nw = [Math]::Min($w, $wa.Width  - 120)
$nh = [Math]::Min($h, $wa.Height - 20)
$nx = [Math]::Max(0, [int](($wa.Width - $nw - 110) / 2))
$ny = [Math]::Max(0, [int](($wa.Height - $nh) / 2))
[void][EmuPlace]::MoveWindow($main, $nx, $ny, $nw, $nh, $true)
"Moved to $nx,$ny ${nw}x${nh}."
