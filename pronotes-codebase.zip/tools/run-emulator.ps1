﻿<#
    run-emulator.ps1 - start an Android emulator, install ProNotes, open it.

    Why this script exists
    ----------------------
    This laptop is 3200x2000 at 200% scaling, so Windows reports a 1600x1000
    LOGICAL desktop. The emulator sizes its window from the device resolution
    and placed itself at y = -200: the title bar, with the close and minimise
    buttons, sat above the top edge of the screen and there was nothing left
    to grab.

    The obvious fix - move the window with MoveWindow - CRASHED the emulator
    twice on this machine's Intel Arc driver:

        Critical: UpdateLayeredWindowIndirect failed ... (device not functioning)
        ERROR    : Failed to find ColorBuffer: 110
        [exited with code 1]

    So we do not touch the window. We compute a `window.scale` that fits the
    working area and write it to the AVD's own emulator-user.ini BEFORE launch,
    and the emulator places itself correctly. place-emulator.ps1 is kept only as
    a fallback, and it refuses to move a window that is already on screen.
#>

param(
    [string] $Avd       = "Pixel_Tablet_API_35",
    [string] $Apk       = "$PSScriptRoot\..\ProNotes.apk",
    [string] $Gpu       = "angle_indirect",
    [string] $PackageId = "com.idrees.pronotes",
    [switch] $NoInstall
)

$ErrorActionPreference = "Stop"

$sdk = $env:ANDROID_HOME; if (-not $sdk) { $sdk = $env:ANDROID_SDK_ROOT }
if (-not $sdk) { throw "ANDROID_HOME is not set." }
$emulator = Join-Path $sdk "emulator\emulator.exe"
$adb      = Join-Path $sdk "platform-tools\adb.exe"
$avdDir   = Join-Path $env:USERPROFILE ".android\avd\$Avd.avd"
if (-not (Test-Path $avdDir)) { throw "No such AVD: $Avd (looked in $avdDir)" }

# --- size the window BEFORE the emulator opens it ------------------------
Add-Type -AssemblyName System.Windows.Forms
$wa = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea

$cfg = Get-Content (Join-Path $avdDir "config.ini")
function Val($key) { ($cfg | Where-Object { $_ -like "$key=*" } | Select-Object -First 1) -replace '^.*=', '' }

$lcdW = [int](Val "hw.lcd.width")
$lcdH = [int](Val "hw.lcd.height")
if ((Val "hw.initialOrientation") -eq "landscape") {
    $long = [Math]::Max($lcdW, $lcdH); $short = [Math]::Min($lcdW, $lcdH)
    $lcdW = $long; $lcdH = $short
}

# window.scale maps device pixels -> LOGICAL desktop pixels, one for one.
# Leave headroom on both axes so no offset can push the title bar off-screen.
$scale = [Math]::Min((0.85 * $wa.Width / $lcdW), (0.88 * $wa.Height / $lcdH))
$scale = [Math]::Round($scale, 4)
$winW  = [int]($lcdW * $scale)
$winH  = [int]($lcdH * $scale)
$x     = [Math]::Max(0, [int](($wa.Width  - $winW - 110) / 2))   # 110 = side toolbar
$y     = [Math]::Max(0, [int](($wa.Height - $winH) / 2))

$ini = Join-Path $avdDir "emulator-user.ini"
$tmp = "$ini.tmp"
@(
    "window.x = $x"
    "window.y = $y"
    ("window.scale = {0:F6}" -f $scale)
    "resizable.config.id = -1"
    "posture = 0"
) | Set-Content -Path $tmp -Encoding ASCII
Move-Item -Force $tmp $ini
Write-Host ("Window pinned: {0}x{1} at {2},{3} (scale {4:F4}) inside {5}x{6}" -f $winW, $winH, $x, $y, $scale, $wa.Width, $wa.Height)

# --- start ---------------------------------------------------------------
$running = (& $adb devices) -match "^emulator-\d+\s+device"
if ($running) {
    Write-Host "An emulator is already running - reusing it."
} else {
    Write-Host "Starting $Avd (gpu: $Gpu) ..."
    Start-Process -FilePath $emulator -ArgumentList "-avd", $Avd, "-gpu", $Gpu, "-no-boot-anim"
}

Write-Host "Waiting for boot ..."
& $adb wait-for-device
# This sleep runs on the DEVICE, not on the host.
& $adb shell 'while [ -z "$(getprop sys.boot_completed)" ]; do sleep 2; done' | Out-Null
Write-Host "Booted."

# --- install and open ----------------------------------------------------
if (-not $NoInstall) {
    if (Test-Path $Apk) {
        Write-Host ("Installing {0} ..." -f (Split-Path $Apk -Leaf))
        & $adb install -r $Apk
        & $adb shell monkey -p $PackageId -c android.intent.category.LAUNCHER 1 | Out-Null
        Write-Host "Launched $PackageId."
    } else {
        Write-Warning "No APK at $Apk - skipping install."
    }
}

# Fallback only; this no-ops when the window is already fully on screen.
& (Join-Path $PSScriptRoot "place-emulator.ps1")
