# ProNotes — Repository Map

Every directory and every file that matters, what it does, and which ones are
generated. **Last mapped: 2026-09-19; sidebar + store sections refreshed 2026-09-25.**
(Line counts below predate the sidebar-pro work except where noted.)

For *how to run it and what is still owed*, read [HANDOFF.md](HANDOFF.md).
For *what to build next and why*, read [ROADMAP.md](ROADMAP.md).

---

## 1. What this is, in one paragraph

ProNotes is an infinite whiteboard **and** a paged notebook app, written as a
Next.js 15 / React 19 static site and then wrapped twice: as a Windows `.exe`
with Electron, and as an Android `.apk` with Capacitor. There is **no server and
no account required** — everything is local, in `localStorage` plus IndexedDB.
Supabase and OneDrive are optional add-ons for sync.

**73 source files, 26,440 lines.** 30 runtime dependencies, 12 dev.

---

## 2. The one idea you must know before editing

A board is either a **canvas** (`board.elements`) or a **notebook**
(`board.pages[].elements`). Nothing outside `notebook.ts` may read either field
directly — everything goes through the funnel:

| Function | Reads / writes |
|---|---|
| `getBoardElements(board)` | the **active page**, or the canvas |
| `mapBoardElements(board, fn)` | writes back to the active page, or the canvas |
| `mapAllBoardElements(board, fn)` | every page |
| `allElements(board)` | the whole document, flattened |

Code written before pages existed reads `board.elements`, which is **always
empty for a notebook**. That produces no error — the feature just silently does
nothing. It has been the single largest source of bugs in this project: it once
broke text editing, the properties panel, the minimap, connections, element
counts and export all at the same time. **Grep for `.elements` before you ship.**

### The second rule: ink stays on the paper

A notebook is a stack of sheets, not an infinite canvas. The active page always
sits at world origin — `(0,0)` to `(width,height)` — because re-anchoring slides
the camera by one stride whenever the next sheet takes over.

Anything that **creates content** must go through `clampToSheet` /
`clampBoxToSheet`; anything that **reads position** (panning, hit-testing, the
marquee) must not, because those still have to work off-page. In the canvas that
split is `getInkPoint` (clamped) versus `getWorldPoint` (honest), and
`canStartInkAt` turns a press on the desk into a pan.

Before this, ink written beside a sheet or in the gap between two sheets was
saved but never rendered in export or print, and became unreachable as soon as
you scrolled.

---

## 3. Directory map

```
pronotesdevelop/
├── src/                  the application (73 files, 26.4k lines)
│   ├── app/              Next.js App Router entry
│   ├── components/
│   │   ├── ui/           Radix + Tailwind primitives (button, dialog, ...)
│   │   ├── pwa/          service-worker registration
│   │   └── whiteboard/   every real screen and panel (31 files)
│   ├── lib/whiteboard/   the engine: geometry, strokes, storage, export
│   ├── store/            single Zustand store
│   └── hooks/
├── tests/                13 suites + tests/e2e/ (4 tiers)
├── scripts/              build + icon generation (9 files)
├── electron/main.js      the Windows app shell
├── android/              Capacitor project (Gradle)
├── public/               icons, manifest, service worker, pdf.js worker
├── assets/               icon source art
├── tools/                dev utilities (emulator, input diagnostic)
└── *.md                  documentation
```

---

## 4. `src/lib/whiteboard/` — the engine

This is where the real logic lives. UI components should be thin over this.

| File | Lines | What it owns |
|---|---:|---|
| `types.ts` | 1141 | Every type. `Board`, `WhiteboardElement`, `NotebookPage`, `PAGE_SIZES`, dock positions. `board.kind` is **optional**, which is why no data migration was ever needed. |
| `geometry.ts` | 975 | Hit-testing, bounds, rotation, resize handles, connector routing. |
| `export.ts` | 967 | SVG / PNG / PDF export. Notebooks export every page (one PDF page per sheet), clipped to the paper, with ruling and any imported PDF under the ink. Returns an `ExportReport` of what was missing. |
| `stroke.ts` | 620 | `perfect-freehand` outlines and the swept-capsule pixel eraser. |
| `links.ts` | 588 | `[[WikiLinks]]`, backlinks, the knowledge graph. Reads every notebook page via `allElements`. |
| `notebook.ts` | 639 | **The page model and the element funnel.** Page layout maths, bookmarks, templates, PDF page refs. |
| `persistence.ts` | 466 | Load / save / `migrate()` / degraded save. Since 2026-09-21 the workspace snapshot itself goes to IndexedDB (see `workspaceDb.ts`); this file keeps the synchronous localStorage path for environments without IndexedDB, the migration that adopts the legacy copy once, and the shared save events. Defensive against every shape it has ever written. |
| `workspaceDb.ts` | 233 | IndexedDB workspace record (gzip past 1 MB of JSON), injectable backend (real IDB in prod, in-memory in tests), `persist()` / storage-pressure helpers, cross-tab save heartbeat. |
| `onedrive.ts` | 304 | Optional Microsoft-account sync. |
| `input.ts` | 241 | Wheel classification: is this a mouse notch or a trackpad glide? Sticky per device. |
| `workspace.ts` | 203 | Backup / restore / merge of the whole workspace, plus `collectReferencedAssets` (boards + templates + trash buffer) shared by the asset pruner. |
| `account.ts` | 183 | Optional Supabase sign-up and sync. |
| `pdf.ts` | 131 | pdf.js loading and page rendering. |
| `palm.ts` | 117 | Palm rejection, deliberate-touch classification, and the tap-select rule (a clean fingertip tap selects at once; palms still need the long press). |
| `imagestore.ts` | 125 | Image bytes in IndexedDB as `asset:<id>`. |
| `pdfstore.ts` | 103 | PDF bytes in IndexedDB. |
| `placement.ts` | 137 | Where an inserted image lands and how big it is, plus the tap-inserted shape default (160×120 centred on the tap, never bigger than the sheet). |
| `shortcuts.ts` | 32 | Keyboard combo predicates. |
| `grid.ts` | 31 | Grid snapping. |
| `sort.ts` | 25 | Sidebar comparator (updated/created/name × asc/desc). |
| `textParser.ts` | — | Markdown blocks, checklist toggles, line-prefix/format splices, per-line direction helpers. |
| `speechRecognition.ts` | — | Voice dictation controller (echo + continuation guards, restart catch-up, language choice). |

### Why images and PDFs are in IndexedDB, not the workspace

One pasted photo was measured at **908 KB of a 918 KB workspace** — 99% of it —
against a ~5 MB `localStorage` quota. The failure landed on *save*: you could
work for an hour and then find nothing had been written, and the fallback
dropped the image `src` to `""`, destroying the only copy. So pixels and PDF
bytes go to IndexedDB once and the element keeps only `asset:<id>`.

---

## 5. `src/store/whiteboard.ts` — 2266 lines, one store

Every board, folder, tool setting, camera, selection, undo stack, split-view
state and page action. 34 element-mutating actions all route through the funnel
in §2.

Undo history carries a `pageId`, because turning a page used to **clear the undo
stack** — silently making cross-page undo impossible.

---

## 6. `src/components/whiteboard/` — the screens

| File | Lines | Role |
|---|---:|---|
| `WhiteboardCanvas.tsx` | 3430 | The canvas. Pointer events, pointer capture, palm rejection, wheel handling, drawing, selection, the lot. **The biggest file in the project.** |
| `ElementRenderer.tsx` | 854 | Draws one element of any kind. |
| `Toolbar.tsx` | 686 | Tool dock. Movable to any edge (see `DockControls`). |
| `GraphView.tsx` | 697 | Knowledge-graph view. |
| `Sidebar.tsx` | ~1950 | Folder and board tree: one "+ New" menu, long-press multi-select with folder scope, compact selection bar (Delete with undo toast, Move, Export incl. multi-file .zip, ⋯ menu), per-kind row icons, folder "..." select/import items. Selection stays sidebar-local; rows get only booleans. |
| `MoveToDialog.tsx` | — | Move-to browser + `BatchMoveDialog` (now also moves folders, cycle-guarded by the store). |
| `DuplicateNotebookModal.tsx` | — | Notebook copy by page range. |
| `trashToast.tsx` | — | Delete-with-Undo toast over the store trash buffer. |
| `InlineTextEditor.tsx` | 583 | In-place text and markdown editing. |
| `FavoritePensBar.tsx` | 583 | Pinned pens. Confined to the canvas pane (measured via `data-wb-canvas-area`), so it cannot sit on the sidebar or backlinks panel. |
| `PropertiesPanel.tsx` | 505 | Contextual inspector for the selection. |
| `SplitPane.tsx` | 502 | Second document, side by side. Draws real paper and shares `board.camera`. |
| `ToolProperties.tsx` | 499 | Per-tool options. |
| `SettingsPanel.tsx` | 497 | Settings. Uses a plain `overflow-y-auto` div — **not** Radix ScrollArea, which sets `position: relative` inline and beat every Tailwind fix. |
| `WhiteboardApp.tsx` | 478 | Top-level composition. |
| `NotebookPages.tsx` | 644 | Page bar, page rail, Pages / ★ Favourites tabs, template library. |
| `LinkManager.tsx` | 447 | Link editing. |
| `ExportModal.tsx` | 515 | Export dialog. |
| `TutorialModal.tsx` | 337 | 7-step first-run tour. |
| `SyncPanel.tsx` | 327 | Backup and cloud sync. |
| Others | — | `AccountSection`, `BacklinksPanel`, `CanvasContextMenu`, `ColorSwatches`, `DockControls`, `FileDropZone`, `KeyboardShortcutsModal`, `LinkLegend`, `Minimap`, `PdfPageLayer`, `SearchModal`, `PenDiagnostics`, `SelectToolButton`, `SelectionActions`, `SelectionOverlay`, `SplitPicker`, `StepperControl`, `ThemeToggle` |

---

## 7. Packaging

### Windows (`electron/main.js`)

A real `.exe` with its own icon and window — **not** a browser. The static export
in `out/` is served over a custom `pronotes://` scheme rather than `file://`,
because Next.js emits absolute asset paths (`/_next/...`) that `file://`
resolves against the drive root, and because `file://` is an opaque origin where
`localStorage` would not persist.

> Freshly built unsigned binaries are blocked by Windows **Smart App Control**
> (CodeIntegrity 3118). A code-signing certificate is the only real fix.

### Android (`android/`, Capacitor 6)

Capacitor is pinned to **6** deliberately: 8 requires JDK 21 and this machine has
JDK 17. `webDir` is `out`. Everything runs from files inside the APK — no server,
no internet.

Android export was once **completely dead**: `<a download>` is ignored by the
Capacitor WebView, so every export silently did nothing. It now goes through
`@capacitor/share` + `@capacitor/filesystem`.

---

## 8. Build and test commands

| Command | Does |
|---|---|
| `npm run dev` | Next dev server on :3000, building into `.next-dev` |
| `npm run typecheck` | `tsc --noEmit` |
| `npm run lint` | ESLint (`next/core-web-vitals` + `next/typescript`) |
| `npm test` | every suite (compiles to `.test-dist/` first) |
| `npm run export` | type check + pdf-worker sync, then static export to `out/` |
| `npm run apk` | export, then the Android APK (`build:apk` is an alias - it used to be the export only) |
| `npm run dist:win` | export, then the Windows installer + portable exe |
| `npm run desktop` | export and run Electron locally |
| `npm run audit` | find unreachable modules and risky patterns |

### Test suites

`tests/e2e/` runs 4 tiers — feature coverage, boundaries, pairwise, real-world
scenarios (315 tests, ~1079 assertions as of 2026-09-25). Plus the node suites
wired into `scripts/test-runner.mjs` (`notebook`, `notebook_store`,
`duplicate_notebook`, `workspace_store_v2`, `shape_tools`, `wheel_device`,
`stylus_button`, `top_tools_and_sidebar`, `sidebar_trash`, `sidebar_batch`,
`select_modes`, `dictation_continuation`, milestone / adversarial / stress).
Counts change every session - run `npm test` rather than trusting a
number written here.

---

## 9. Generated — never edit, safe to delete

These are rebuilt by the commands above. Deleting them frees ~820 MB.

```
.next/                        Next build cache          (~414 MB)
.next-dev/                    `npm run dev`'s own build dir
public/pdf.worker.min.mjs     copied from pdfjs-dist on install and every build
out/                          static export             (~6 MB)
dist-desktop/win-unpacked/    Electron intermediate     (~363 MB)
android/app/build/            Gradle output             (~34 MB)
android/.gradle/              Gradle cache              (~3 MB)
.test-dist/                   compiled tests
tsconfig.tsbuildinfo          incremental tsc cache
node_modules/                 npm install               (~1.08 GB)
```

Kept deliberately: `ProNotes.apk`, `dist-desktop/ProNotes <version>.exe`,
`dist-desktop/ProNotes Setup <version>.exe` (the version is `package.json`'s,
which the APK's `versionName` also uses).

---

## 10. Documentation

| File | Read it for |
|---|---|
| `HANDOFF.md` | **start here** — how to run it, what is broken, what is owed |
| `MAP.md` | this file — where everything lives |
| `ROADMAP.md` | competitor research and what to build next |
| `CHANGELOG_FIXES.md` | ~104 KB chronological log. STEP numbers were renumbered 2026-09-19 to remove duplicates; the old -> new table is at the top. |
| `TEST_INFRA.md` | the feature-to-tier coverage matrix |
| `ACCOUNTS_SETUP.md` | Supabase setup (~5 min, free) — **not done yet** |
| `ONEDRIVE_SETUP.md` | Microsoft app registration — **not done yet** |

---

## 11. Known open issues

- ESLint reports ~260 warnings (mostly unused variables) to work down; 0 errors.
- Android `targetSdk` is 34; Google Play requires 35. Not needed for sideloading.
- Supabase and OneDrive credentials are not configured, so sync is inert.
- Windows builds are unsigned, so Smart App Control blocks them.
- **Untested on real hardware**: Android share sheet, finger and stylus drawing,
  PDF import with a real lecture PDF, backup restore picker on Android. An
  emulator gives one pressureless finger and cannot prove any of these.
