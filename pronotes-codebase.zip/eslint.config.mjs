import { dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { FlatCompat } from "@eslint/eslintrc";

/**
 * ESLint for the app.
 *
 * This file used to contain ONLY an ignores list. With nothing extended there
 * were no rules at all, so `npm run lint` passed on anything - including the
 * react-hooks mistakes that are the most common real bug in this codebase's
 * history (stale closures in pointer handlers). eslint-config-next was already
 * installed; it just was never wired in.
 */
const __dirname = dirname(fileURLToPath(import.meta.url));
const compat = new FlatCompat({ baseDirectory: __dirname });

const eslintConfig = [
  {
    ignores: [
      "node_modules/**",
      ".next/**",
      ".next-dev/**",
      "out/**",
      "build/**",
      "dist-desktop/**",
      "next-env.d.ts",
      // Capacitor's native project: generated Java/Gradle plus vendored JS
      // (native-bridge.js) that ships its own lint directives for another config.
      "android/**",
      "ios/**",
      ".test-dist/**",
      // Generated/vendored: the pdf.js worker is copied in from node_modules.
      "public/pdf.worker.min.mjs",
    ],
  },
  ...compat.extends("next/core-web-vitals", "next/typescript"),
  {
    // Electron's main process, the build scripts and the e2e runner are real
    // CommonJS; `require` is correct there, not a style slip.
    files: ["**/*.js", "**/*.cjs"],
    rules: { "@typescript-eslint/no-require-imports": "off" },
  },
  {
    rules: {
      // Apostrophes in JSX text render correctly in React; the rule is about
      // typos in hand-written HTML entities and only produced noise here.
      "react/no-unescaped-entities": "off",
      // Existing `any`s are warnings to work down, not a reason for the gate to
      // fail on every run - a gate that always fails gets ignored.
      "@typescript-eslint/no-explicit-any": "warn",
    },
  },
];

export default eslintConfig;
