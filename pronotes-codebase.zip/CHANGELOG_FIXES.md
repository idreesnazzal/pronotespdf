# ProNotes — Fix & Change Log (Live Working Document)

> **Renumbered 2026-09-19.** Two later sessions appended entries that reused
> STEP 21-27, so several numbers pointed at two different entries. Entries
> from "The pen types were names" onwards were renumbered in file order,
> which is the order they were written. Old -> new:
>
> - old STEP 23 -> **STEP 27** — The pen types were names, not pens
> - old STEP 24 -> **STEP 28** — The writing pens were still identical (line weight was mi...
> - old STEP 27 -> **STEP 29** — Zoom / pan: passive listener, delta units, mouse vs trackpad
> - old STEP 26 -> **STEP 30** — Paper size is adjustable per board
> - old STEP 21 -> **STEP 31** — Thickness slider inline; double-click a tool for its sett...
> - old STEP 22 -> **STEP 32** — Both packages rebuilt (2026-09-04)
> - old STEP 23 -> **STEP 33** — Element-level vertices in the knowledge graph
> - old STEP 24 -> **STEP 34** — "my pen settings reset", stylus button, and the favourite...
> - old STEP 25 -> **STEP 35** — "my hand lands on the text and it opens the object on me"
> - old STEP 27 -> **STEP 36** — Project moved to Documents\pronotesdevelop and made self-...

> This file is updated at nearly every step of the audit/fix/test pass.
> Format: [STEP n] — Area — Recognition / Change / Verification.
> Severity: CRITICAL / HIGH / MEDIUM / LOW. Status: ✅ fixed / 🔧 in progress / ⏳ pending / ❌ won't fix (with reason).

---

## STEP 1 — Baseline verification (before any changes)

**Commands run & results:**
- `npm test` (scripts/test-runner.mjs) → ALL EXISTING SUITES PASS (incl. challenger suites, 12289/12289 assertions).
- `npx tsc --noEmit` → 0 errors.
- `npm run lint` → clean (exit 0). Note: `npx eslint src` fails because eslint.config.mjs ignores `src` glob — `npm run lint` works. (Known config quirk, documented, not changed.)
- `npm run build` → 5/5 pages static, exit 0.

**Recognition:** Baseline is green, but existing tests are "happy path" heavy. Three independent deep audits were launched (canvas/geometry/stroke, store/persistence/links/export, UI components) to find real defects the suite does not cover.

---

## STEP 2 — Audit findings (recognized defects, not yet fixed)

### A. WhiteboardCanvas.tsx + geometry.ts + stroke.ts (audit #1)
| # | Severity | Finding | Status |
|---|----------|---------|--------|
| A1 | CRITICAL✅ | 2-finger tap fires `undo()` once per finger lift (2x), 3-finger tap fires `redo()` 3x — multi-fire gesture, real data loss on touchscreens. Cause: gesture check runs on every pointerup while `maxTouchCountRef` is still ≥2 until map empties. | ⏳ |
| A2 | HIGH✅ | Pointer capture set on `e.target` (child node that can unmount mid-gesture, e.g. SelectionOverlay re-render) → capture silently dropped, gesture never terminates. | ⏳ |
| A3 | HIGH✅ | Stroke points appended via stale-state read-modify-write of `draftElement` → points can be lost/duplicated under batched pointer events. | ⏳ |
| A4 | HIGH✅ | `activeTouchesRef` leaks pointerIds when a pointerup/cancel is missed → permanently disables drawing (every new touch seen as "second finger"). | ⏳ |
| A5 | HIGH✅ | Pen (stylus) pointer is counted as a "touch finger" in `activeTouchesRef` → pen drawing + palm contact (2 pointers) falsely enters pinch-zoom mode mid-stroke. | ⏳ |
| A6 | MEDIUM✅ | `touchStartTimeRef`/`touchMovedRef` reset on every pointerdown → slow 2-finger placement misdetected as quick-tap undo/redo. | ⏳ |
| A7 | MEDIUM✅ | `onPointerCancel={handlePointerUp}` commits cancelled gestures (adds elements, commits history) instead of rolling back. | ⏳ |
| A8 | MEDIUM✅ | Eraser drag-erase runs even while another tool's gesture is active (`tool === "eraser" && e.buttons > 0` unchecked vs interaction.kind). | ⏳ |
| A9 | MEDIUM✅ | `spaceHeld` stuck true if window loses focus while Space held (alt-tab) → canvas locked in pan mode. | ⏳ |
| A10 | MEDIUM✅ | `hitTestElement` ignores `el.rotation` for strokes → rotated strokes keep their old (unrotated) hit area. | ⏳ |
| A11 | MEDIUM✅ | `isElementInPolygon` uses unrotated bounds corners → lasso mis-selects rotated elements. | ⏳ |
| A12 | MEDIUM✅ | `pruneTerminalHooks` applied twice on stroke commit (once explicitly, once inside `buildStrokePath`) → can clip legitimate stroke endings. | ⏳ |
| A13 | MEDIUM✅ | Connect tool with a miss on empty space falls through to select-tool rubber-band branch. | ⏳ |
| A14 | LOW✅ | Rotation stored can be negative (not normalized to [0, 2π)) → inconsistent downstream wrap logic. | ⏳ |
| A15 | LOW✅ | `e.pressure !== 0.5` heuristic treats real stylus pressure of exactly 0.5 as "no data" → pens idling at 0.5 lose pressure dynamics. | ⏳ |
| A16 | LOW✅ | Dead code `e.type.includes("touch")` in handleDoubleClick (always false for dblclick). | ⏳ |
| A17 | LOW | Zoom clamp verified present in store `zoomTo` (MIN_ZOOM/MAX_ZOOM) — NOT a bug. | ❌ no fix needed |
| A18 | — | Second finger landing mid-stroke discards the in-progress draft. Kept intentionally (matches Excalidraw behavior; committing palm-triggered partial strokes would create garbage). Will seal history correctly instead. | ❌ by design (documented) |

### B. store/whiteboard.ts + persistence.ts + links.ts + export.ts (audit #2)
| # | Severity | Finding | Status |
|---|----------|---------|--------|
| B1 | HIGH✅ | `moveFolder` allows moving a folder into its own descendant → parentId cycle → infinite recursion in tree walks, persisted corruption. | ⏳ |
| B2 | HIGH✅ | `migrate()` never validates `elements`/`camera` on saved boards → board with `elements: undefined` (old schema / truncated write) crashes app on every load (`for..of` throws), and gets re-saved — bricked. | ⏳ |
| B3 | MEDIUM✅ | localStorage QuotaExceededError only `console.warn`ed → silent data loss with zero UI signal; comment claims a degraded retry that was never implemented. | ⏳ |
| B4 | MEDIUM✅ | `deleteBoard` of a NON-active board still hijacks `activeBoardId`, resets camera/selection/history → deleting a background board kicks user off current canvas. Also leaves dangling cross-board connections in other boards. | ⏳ |
| B5 | MEDIUM✅ | `deleteFolder` only removes direct children folders → grandchildren orphaned (invisible but persisted forever). | ⏳ |
| B6 | MEDIUM✅ | Multi-tab: single STORAGE_KEY + last-write-wins → silent data loss between tabs. | ⏳ |
| B7 | MEDIUM✅ | Camera never written back to `board.camera` → viewport position lost on every reload. | ⏳ |
| B8 | MEDIUM✅ | History snapshots are shallow clones (`{...el}`) → nested `points`/`source`/`target` shared by reference between snapshots and live state; any in-place mutation corrupts all snapshots. | ⏳ |
| B9 | MEDIUM✅ | Export SVG: `fill` attributes interpolated unescaped (stroke is escaped, fill is not) → attribute injection / malformed SVG with hostile colors. | ⏳ |
| B10 | MEDIUM✅ | `init()` requires `boards.length > 0` → a legitimately-saved empty state (user deleted all boards) is discarded and demo content re-injected, wiping saved folders/link types. | ⏳ |
| B11 | LOW✅ | WikiLink alias regex allows `\|` inside alias (`[[A|b|c]]`) and `[[A|]]` fails to match at all. | ⏳ |
| B12 | LOW✅ | Export text anchor ignores `width` for center/right alignment → exported SVG misaligned vs canvas. | ⏳ |
| B13 | LOW✅ | Export connection label pill width heuristic can overflow with long labels. | ⏳ |
| B14 | LOW✅ | PNG rasterization cannot load Google Fonts `@import` inside `<img>` SVG (security context) → fallback font metrics. | ⏳ |
| B15 | LOW✅ | `bringForward`/`sendBackward` just alias front/back instead of single-layer step. | ⏳ |
| B16 | — | Zoom clamping, nanoid collision odds, empty-selection export guards, accessedAt sorting — verified NOT bugs. | ❌ no fix needed |

### C. UI components (audit #3 — COMPLETE)

| # | Severity | Finding | Status |
|---|----------|---------|--------|
| C1 | HIGH✅ | Global shortcuts Ctrl+K/B/G/L in WhiteboardApp fire while typing in text editor / inputs (no target guard, no stopPropagation in InlineTextEditor's own Ctrl+B/I/K handler) → Ctrl+B bolds AND toggles Backlinks; Ctrl+K inserts `[[` AND opens Search. | ⏳ |
| C2 | HIGH✅ | Font Family/Size Radix popovers portal to document.body → outside containerRef → textarea blur-commit fires after 150ms and unmounts the editor mid-drag. | ⏳ |
| C3 | HIGH✅ | Undo broken for text edits: keystrokes applied with commit=false, then commitHistory() on exit snapshots POST-edit state → first Ctrl+Z is a no-op, pre-edit text unrecoverable via single undo. | ⏳ |
| C4 | MEDIUM✅ | Every keystroke re-renders entire app (Sidebar, all ConnectionShapes, Minimap, Backlinks, GraphView). | ⏳ |
| C5 | MEDIUM✅ | Sidebar search hides starred root-level boards (Starred section gated on !searchQuery; root list filters out starred). | ⏳ |
| C6 | MEDIUM✅ | GraphView node drag has no pointer capture; release outside dialog leaves dragNodeId stuck → node follows cursor with no button. | ⏳ |
| C7 | MEDIUM✅ | Sidebar tag search case-sensitive (`t.includes(q)` vs lowercased q). | ⏳ |
| C8 | LOW✅ | sw.js caches Next.js RSC/router-prefetch responses cache-first → stale RSC after deploy; cache version constant → never purged. | ⏳ |
| C9 | LOW✅ | sw.js cache writes are floating promises (no event.waitUntil) → SW can die before writes finish. | ⏳ |
| C10 | LOW✅ | preventDefault inside React onWheel is a no-op (passive listener) in GraphView. | ⏳ |
| C11 | LOW✅ | GraphView & SearchModal lack focus trap/restore. | ⏳ |
| C12 | LOW✅ | Dead store subscriptions in WhiteboardApp (tool, minimapOpen, snapToGrid...) re-render tree for nothing; tutorialOpen dead state. | ⏳ |
| C13 | LOW✅ | ExportModal "copied" setTimeout not cleaned up on unmount. | ⏳ |
| C14 | — | Verified clean: hydration gating, controlled inputs, listener cleanup, SW precache assets exist, export XSS escaping, minimap drag capture. | ❌ no fix needed |

## STEP 5 — UI component fixes applied (audit #3: C1–C13)

**Files:** `WhiteboardApp.tsx`, `InlineTextEditor.tsx`, `ElementRenderer.tsx`, `Sidebar.tsx`, `GraphView.tsx`, `ExportModal.tsx`, `public/sw.js`

1. ✅ **C1 fixed** — WhiteboardApp's Ctrl+K/G/B/L handler now guards on `editingId` AND event target (INPUT/TEXTAREA/contentEditable). InlineTextEditor's own Ctrl+B/I/K also call `stopPropagation()` as defense-in-depth. Typing no longer triggers panels/modals.
2. ✅ **C2 fixed** — Textarea blur-commit now treats focus inside a Radix popper (`[data-radix-popper-content-wrapper]`) as "still editing" — the font family/size popovers no longer unmount the editor mid-drag.
3. ✅ **C3 fixed** — Text editing takes exactly ONE history snapshot per session, on the FIRST mutation (`mutateElement` + `sessionCommittedRef`); `commitAndExit` no longer snapshots post-edit state. Single Ctrl+Z now truly reverts an edit. All editor mutations (text, font, size, align, colors, auto-height) route through it.
4. ✅ **C4 partially fixed** — ElementRenderer now subscribes to a BOOLEAN editing selector instead of the raw `editingId` (starting/stopping an edit no longer re-renders every element). Full local-draft refactor documented as future work.
5. ✅ **C5 fixed** — Sidebar search no longer hides starred root-level boards.
6. ✅ **C6 fixed** — GraphView node drag sets pointer capture on the node; release outside the dialog ends the drag.
7. ✅ **C7 fixed** — Sidebar tag search is case-insensitive.
8. ✅ **C8 fixed** — sw.js: RSC / Next-Router-Prefetch requests bypass the cache (no stale payloads after deploys); cache version bumped and documented (activate purges old caches).
9. ✅ **C9 fixed** — All sw.js cache writes wrapped in `event.waitUntil` (SW can't be killed mid-write).
10. ✅ **C10 fixed** — GraphView zoom uses a non-passive native `wheel` listener via effect (React's passive onWheel made preventDefault a no-op).
11. ✅ **C13 fixed** — ExportModal "copied" timer cleaned up on unmount.
12. ❌ **C11 (focus traps) deferred** — GraphView/SearchModal focus containment noted; requires wrapping in Radix Dialog (larger change, low harm).

---

## STEP 6 — Cross-feature conflict fixes applied (audit #4: D1–D18)

**Files:** `WhiteboardCanvas.tsx`, `WhiteboardApp.tsx`, `store/whiteboard.ts`, `LinkManager.tsx`, `TutorialModal.tsx`, `LinkLegend.tsx`, `export.ts`, `ExportModal.tsx`, `CanvasContextMenu.tsx` (wired), `SearchModal/GraphView/LinkManager/TutorialModal` (tagged)

1. ✅ **D1 fixed** — Lasso loop skips connections (matching rubber-band) and locked elements. Origin-enclosing lasso can no longer select every connection.
2. ✅ **D2 fixed (2 parts)** — New store actions `addElementToBoard` / `deleteElementFromBoard` write to a specific board WITHOUT switching the active one; LinkManager uses them (no more history wipe / canvas jump behind the modal). Default linkType corrected `"reference"` → `"relates"` (D18). Honest help text (links appear in Graph + list, not as canvas arrows). Board-level links remain graph-visible.
3. ✅ **D3 fixed** — Lock is now enforced everywhere: rubber-band + lasso skip locked; resize/rotate handles refuse locked elements; group-move filters locked; `deleteElements` refuses locked ids (covers keyboard Delete, PropertiesPanel, toolbar); `selectAll` excludes locked.
4. ✅ **D4 fixed** — WhiteboardApp Ctrl+G and Ctrl+L branches require `!shiftKey` (Ctrl+Shift+G is Snap, Ctrl+Shift+L is Lock — both now implemented in the canvas).
5. ✅ **D5 fixed** — Canvas + App shortcut handlers early-return when any modal is open: Radix `[role=dialog][data-state=open]` OR custom overlays tagged `[data-wb-modal]` (SearchModal, GraphView, LinkManager, TutorialModal all tagged; storage banner too).
6. ✅ **D6 fixed** — Store-level guard: `undo()`/`redo()` no-op while `editingId` is set (covers touch 2-finger-tap undo AND toolbar buttons AND any future caller).
7. ✅ **D7 fixed** — Second finger mid-stroke now COMMITS the draft stroke (pruned + path built) instead of discarding it; new `gestureSealedRef` suppresses the 2/3-finger tap-undo for that same touch sequence.
8. ✅ **D8 fixed** — Touch double-tap creates text only in select/text tools (mirrors the mouse dblclick path); no more hijacking eraser/lasso/connect/pen.
9. ✅ **D9 fixed** — Stylus-only mode routes ALL finger touches to pan/select (dropped `isDrawingTool` restriction); the palmRejection toggle keeps its drawing-tools scope.
10. ✅ **D10 fixed (5 of 9 gaps)** — Export now: threads `customLinkTypes` (colors + labels), renders the START arrowhead, applies `mix-blend-mode: multiply` for highlighter-class pens, renders WikiLink/tag DISPLAY text instead of raw `[[...]]` markup (text + sticky), escapes all connection colors. Remaining known gaps (documented): foreignObject text-wrap metrics, cross-board endpoint resolution, badge pill styling nuances.
11. ✅ **D11 fixed** — TutorialModal no longer binds "?" (shortcuts modal is the single owner); link-type names/colors in the tutorial now match the real builtins.
12. ✅ **D12 fixed** — Canvas Space handler ignores Space when a BUTTON/SELECT/[role=button]/[role=slider] has focus (Space activates the button, as native); other shortcuts still work with a focused button.
13. ✅ **D13 fixed** — `createBoard`/`duplicateBoard` capture the outgoing board's live camera (same as `setActiveBoard`).
14. ✅ **D14 fixed** — Implemented previously-documented-but-unbound shortcuts: Ctrl+A (select all), Ctrl+D (duplicate, preventDefault blocks the browser bookmark dialog), Ctrl+Shift+L (lock/unlock), Ctrl+]/[ (single-step layering), Ctrl+0 (reset zoom), Ctrl+= / Ctrl+- (zoom in/out), Shift+1 (zoom to fit), Escape now cancels the active interaction (discards draft, clears rubber band) before deselecting. "I" image-upload shortcut and "H=Pan" doc claims remain unbound/incorrect-by-design (documented; H is Highlighter).
15. ✅ **D15 fixed** — Ctrl+Z / Ctrl+Y are ignored while `interaction.kind !== "idle"` (no more mid-gesture history desync).
16. ✅ **D16 fixed** — All save-health events are now consumed: WhiteboardApp shows a dismissible amber banner for `wb:save-degraded` (images stripped), `wb:save-failed`, `wb:external-change` (multi-tab), and auto-clears on `wb:save-recovered`.
17. ✅ **D17 fixed** — CanvasContextMenu wired around the canvas SVG (right-click → layering/duplicate/delete acting on the current selection); was 100% dead code before.
18. ✅ **D18 fixed** — LinkLegend no longer claims Ctrl+L; TutorialModal link names/colors match builtins; LinkManager default type fixed (see D2).

---

## STEP 7 — Regression suite added + full verification

**New file:** `tests/regression_fix_pass.test.ts` (registered in `scripts/test-runner.mjs`) — 16 pinned regression groups: B1 cycle, B5 descendants, B4/B4b board delete, B8 deep-clone history, D3 lock protection, D6 edit-guard, B15 layer order, B7/D13 camera persistence, B10 state integrity, B11 wikilink aliases, B9/B12/D10 export serialization (injection escape, center anchor, wikilink display, custom link colors, both arrowheads, blend mode), A10/A10b rotated hit-test, A11 rotated lasso, B2 store invariants, D2 board-scoped writes.

**Full gate results:**
- `npm test` → ALL SUITES PASS (all pre-existing suites + all 16 regression groups green).
- `npx tsc --noEmit` → 0 errors.
- `npm run lint` → clean.
- `npm run build` → 5/5 pages, exit 0.

---


### E. Conflict Hunter results (audit #4 — cross-feature conflicts) — ALL FIXED in Step 6

| # | Severity | Conflict | Status |
|---|----------|----------|--------|
| D1 | CRITICAL✅ | Lasso has no connection skip (rubber-band does): all connections live at (0,0), so any lasso enclosing the origin selects EVERY connection → one Delete destroys all relationships. | ⏳ |
| D2 | CRITICAL✅ | LinkManager writes board/folder IDs into connection endpoints (element-ID space) → connections can never render/hit-test ("phantom data"); it also calls setActiveBoard mid-modal which WIPES the undo history. | ⏳ |
| D3 | CRITICAL✅ | Lock bypassed: rubber-band/lasso select locked elements, handles resize/rotate them, Delete destroys them (hitTestElement blocks click-select only). | ⏳ |
| D4 | CRITICAL✅ | Ctrl+Shift+G (documented Snap-to-Grid) ALSO opens Graph View (App's Ctrl+G lacks !shiftKey); Ctrl+Shift+L documented as Lock but opens Link Manager. | ⏳ |
| D5 | CRITICAL✅ | Canvas shortcuts fire under ALL modals (Radix focuses a DIV, not an input): Backspace behind Export modal deletes selection; tool keys/undo/Ctrl+G stack modals. | ⏳ |
| D6 | CRITICAL✅ | 2-finger-tap touch undo has no editingId guard (keyboard undo does) → mid-edit tap reverts the whole editing session; Toolbar undo also clickable mid-edit. | ⏳ |
| D7 | CRITICAL✅ | 2nd finger mid-stroke: draft stroke silently discarded AND quick release then undoes the PREVIOUS action. | ⏳ |
| D8 | HIGH✅ | Touch double-tap hijacks every tool (creates text even with eraser/lasso/connect/pen active); mouse path correctly gated to select/text. | ⏳ |
| D9 | HIGH✅ | Stylus-only palm rejection only guards the 6 freehand tools — palm can lasso/erase/connect in stylus-only mode. | ⏳ |
| D10 | HIGH✅ | Export ≠ canvas parity: highlighter mix-blend-mode lost, start arrowheads dropped, custom link types gray/raw-id, cross-board links dropped, text wrapping metrics differ, wikilink markup printed raw. | ⏳ |
| D11 | HIGH✅ | "?" opens TWO modals at once (Tutorial z-100 + Shortcuts z-50). | ⏳ |
| D12 | MEDIUM✅ | Space stolen from focused buttons (guard excludes only INPUT/TEXTAREA) — Space never activates toolbar/modal buttons. | ⏳ |
| D13 | MEDIUM✅ | Camera lost when creating/duplicating a board (outgoing camera write only exists in setActiveBoard). | ⏳ |
| D14 | MEDIUM✅ | Documented shortcuts unbound: Ctrl+A, Ctrl+D (browser bookmark fires!), Ctrl+]/[, Ctrl+0/=/-, Shift+1, "I"; "H" claimed by both Pan and Highlighter; Escape doesn't cancel interaction. | ⏳ |
| D15 | MEDIUM✅ | Ctrl+Z mid-gesture desyncs history (move loop re-applies over undone snapshot). | ⏳ |
| D16 | LOW✅ | Dead event channels: wb:save-degraded/failed/recovered + wb:external-change dispatched but nobody listens (quota fallback silent); wb:navigate-link / wb:auto-fit-height listened but never dispatched. | ⏳ |
| D17 | LOW✅ | CanvasContextMenu.tsx is dead code — no onContextMenu registered; right-click shows browser menu. | ⏳ |
| D18 | LOW✅ | Docs/UI mismatch: LinkManager defaults linkType "reference" (not a builtin → gray/raw), TutorialModal teaches wrong link names/colors, LinkLegend claims Ctrl+L toggles legend. | ⏳ |
| D19 | — | Verified clean: wheel over modals, board-switch during editing, paste during input, SW vs exports. | ❌ no fix needed |

---

## STEP 3 — WhiteboardCanvas.tsx fixes applied (all edits in one batch)

**File:** `src/components/whiteboard/WhiteboardCanvas.tsx`

1. ✅ **A1 fixed** — Multi-finger tap gesture (2-finger undo / 3-finger redo) is now judged exactly once, only when the LAST finger lifts (`activeTouchesRef.size === 0`), and `maxTouchCountRef` is consumed (reset to 0) immediately after judging. No more double-undo / triple-redo per gesture.
2. ✅ **A6 fixed** — `touchStartTimeRef` / `touchMovedRef` now reset only when the FIRST finger of a gesture lands (count 0→1 transition), so slow two-finger placement can't masquerade as a quick tap.
3. ✅ **A5 fixed** — Only `pointerType === "touch"` pointers are counted as fingers. New `penActiveRef`: while a stylus is in contact, all concurrent touch input is treated as palm and ignored (tracked but non-interacting). Pen+finger no longer falsely triggers pinch-zoom mid-stroke.
4. ✅ **A2 fixed** — All pointer capture now goes through a new `capturePointer()` helper that captures on the stable SVG root (`svgRef.current`) instead of `e.target` (a child node that can unmount mid-gesture). Verified via grep: zero remaining `e.target ... setPointerCapture` sites.
5. ✅ **A4 fixed** — Added `onLostPointerCapture` handler that evicts the pointerId from the touch map; a missed pointerup can no longer permanently poison gesture state. `pointercancel` also cleans the map.
6. ✅ **A7 fixed** — Split `onPointerCancel` from `onPointerUp`. New `handlePointerCancel` ROLLS BACK: discards draft elements, restores original positions/geometry for moving/resizing/rotating (via stored `originalElements`/`originalElement`), clears rubber band, resets interaction — no history commit, no phantom elements.
7. ✅ **A8 fixed** — Drag-erase while another tool's gesture is mid-flight is blocked (`interaction.kind === "idle"` required for the `tool === "eraser" && e.buttons > 0` path).
8. ✅ **A9 fixed** — `window.blur` listener clears `spaceHeld` (alt-tab during Space-hold no longer locks the canvas in pan mode).
9. ✅ **A3 fixed** — Freehand point appending now uses a functional `setDraftElement(prev => …)` so batched pointer events read the LATEST stroke state; points can no longer be dropped/overwritten.
10. ✅ **A15 fixed** — Pressure logic: real stylus pressure trusted only for `pointerType === "pen"` with `pressure > 0`; mouse's constant 0.5 no longer treated as "real data at exactly 0.5" nor stylus 0.5 as fake.
11. ✅ **A13 fixed** — Connect tool with empty-space press now swallows the gesture (`return`) instead of falling through to rubber-band selection.
12. ✅ **A14 fixed** — Rotation normalized to `[0, 2π)` (double-modulo) — stored rotations are never negative.
13. ✅ **A16 fixed** — Dead `e.type.includes("touch")` in `handleDoubleClick` replaced with `false` (dblclick is never a touch event).
14. ✅ **Bonus (from A18 analysis)** — When a second finger lands while an element move/resize/rotate gesture is in flight, `commitHistory()` is called before the gesture state machine switches to pinch mode, so those transforms remain undoable.
15. ✅ **Feature repair** — Double-tap-to-create-text now works in **touch-pan** mode too (double-tap check moved before the touch-pan branch). In stylus-only mode fingers still never create content.
16. ❌ **A18 (by design, kept)** — Second finger landing mid-stroke discards the draft (Excalidraw-consistent; committing palm-triggered partial strokes would create garbage).

**Verification:** pending — `tsc`/`build`/tests run after remaining batches (geometry/store/persistence/export/links).

---

## STEP 4 — Geometry / Store / Persistence / Export / Links fixes applied

**Files:** `src/lib/whiteboard/geometry.ts`, `src/store/whiteboard.ts`, `src/lib/whiteboard/persistence.ts`, `src/lib/whiteboard/export.ts`, `src/lib/whiteboard/links.ts`

### geometry.ts
1. ✅ **A10 fixed** — `hitTestElement` stroke branch now uses the un-rotated query point (`local`) so rotated strokes hit-test against their VISIBLE geometry (previously the old, un-rotated hit area was used forever after rotating).
2. ✅ **A10b (found during fix)** — line/arrow hit-test had the same rotation blindness; now also uses `local`.
3. ✅ **A11 fixed** — `isElementInPolygon` (lasso): stroke sample points, line/arrow endpoints, and bounding-box corners are all rotated by `el.rotation` about the bounds center before polygon testing, so lasso selection matches what the user SEES.

### store/whiteboard.ts
4. ✅ **B1 fixed** — `moveFolder` walks `newParentId` up the ancestor chain (with a visited-set guard against pre-existing corruption) and rejects any move that would place a folder inside its own descendant. No more parentId cycles.
5. ✅ **B5 fixed** — `deleteFolder` computes the FULL descendant set iteratively; grandchildren are deleted along with children, and boards in any doomed folder are moved to root instead of orphaned.
6. ✅ **B4 fixed** — `deleteBoard` only switches `activeBoardId`/camera/selection/history when the ACTIVE board was deleted; deleting a background board no longer kicks the user off their canvas. Cross-board connections in other boards referencing the deleted board are cleaned up (no more silent dangling arrows).
7. ✅ **B8 fixed** — History snapshots now deep-clone via `structuredClone` (fallback JSON clone): `commitHistory`, `undo`, and `redo`. Nested `points`/`source`/`target` can no longer be shared by reference between snapshots and live state.
8. ✅ **B10 fixed** — `init()` honors ANY saved state (including zero boards). Demo content is seeded only when no saved state exists at all; user's folders/link types survive an intentional "delete all boards".
9. ✅ **B7 fixed (two parts)** — (a) `getPersistedState()` injects the live camera into the active board on every debounced save; (b) `setActiveBoard` writes the outgoing board's camera in memory immediately (previously the debounce raced and the old board's viewport was never captured).
10. ✅ **B15 fixed** — `bringForward`/`sendBackward` are real single-layer z-order swaps (adjacent element swap, preserving group order), no longer aliases of front/back.
11. ✅ **B6 (partial)** — `watchExternalSaves()` added in persistence; store dispatches `wb:external-change` window event when another tab writes the shared key. (UI banner wiring pending.)

### persistence.ts
12. ✅ **B2 fixed** — `migrate()` fully validates/backfills: boards/folders arrays enforced; entries without valid `id` dropped; `elements` forced to a filtered array (garbage elements dropped); `camera` validated for finite numbers and zoom > 0; name/tags/starred/accessedAt/color backfilled. A corrupt save can no longer brick the app on load.
13. ✅ **B3 fixed** — `saveState()` on quota/write failure retries once with image `src` payloads stripped (structure/strokes/text survive) and dispatches `wb:save-degraded` / `wb:save-failed` window events; recovery dispatches `wb:save-recovered`. Silent data loss is now at least observable (UI wiring pending).

### export.ts
14. ✅ **B9 fixed** — ALL `fill="…"` attribute interpolations now pass through `escapeXml` (6 shape/sticky sites + sticky colors + connection label color). SVG attribute injection via hostile colors is closed.
15. ✅ **B12 fixed** — text export anchor `x` accounts for element width per alignment (center → x + w/2, right → x + w). Sticky export now honors `st.align` too (previously always left-anchored).
16. ✅ **B13 fixed** — connection label pill: width estimate 8.2px/char AND labels longer than 40 chars are truncated with an ellipsis so the pill never overflows.

### links.ts
17. ✅ **B11 fixed** — WikiLink alias semantics: `[[Target|]]` now matches (displays target), `[[A|b|c]]` matches and displays only the first alias segment `b`, and `[[ ]]`-with-no-target is skipped safely.

### Recognition during this batch
- **NEW FINDING (E1, MEDIUM):** rubber-band selection in `WhiteboardCanvas` still uses UNrotated `getElementBounds` for rotated elements (approximation; matches several mainstream tools' AABB behavior). Left as-is deliberately — SelectionOverlay draws rotated handles, so full parity would require rotated-quad vs rect intersection. Documented; revisit only if users report it.
- **NEW FINDING (E2, LOW):** PNG rasterization cannot fetch the Google Fonts `@import` inside an `<img>`-loaded SVG (browser security context) — text falls back to system fonts in PNG only. Documented, not fixed (needs font inlining as base64; large change).

**Checkpoint:** `npx tsc --noEmit` → **0 errors** after this batch.

---




## STEP 8 — Browser GUI test (partial) + session end

**Environment prep:** dev server started on http://localhost:3000 (200 OK). Formal black-box GUI testing began per the web-gui-tester skill (screenshots + read-only DOM checks only).

**Verified live:**
- App boots with full shell: title "ProNotes — Infinite Whiteboard & Knowledge Canvas", sidebar, search, toolbar, link legend, welcome board, tutorial (screenshot evidence).
- Tutorial open/next/close flow works via GUI clicks.
- Read-only DOM audit mid-test: no stray [data-wb-modal]/dialog blockers, focus on BODY (sane), canvas SVG present with dot-grid pattern + welcome elements (3 foreignObject texts, sticky rects).

**Runtime limitation found (honest record):** synthesized keyboard events ("?", "p", Ctrl+Z via keypress AND type) never reach the app's window-level handlers in the in-app browser runtime — keyboard-dependent fixes remain covered by the store/unit regression suite but could NOT be GUI-verified here. Initial canvas-element counts accidentally measured a Lucide icon SVG; corrected by targeting the pattern#dot-grid SVG.

**Tool-button coordinate map captured** (bottom toolbar, unnamed tool buttons at x=467-924, y=670) — ready to resume mouse-driven draw/shape/export/persistence tests next session.

**Session closed by user request.** Remaining work, deferred items, and the queued Android Tarteel mission are listed in SESSION_SUMMARY_2026-08-17.md.

---

## STEP 9 — Knowledge-graph link fixes + Favorite Pens bar (2026-08-19)

**Reported by user:** "the link when i add link it is not having linked in the
graph network of the knowledge and with arrow with direction" and "no ability to
press and enter the item".

### F1 — Link Manager links never reached the graph (CRITICAL) ✅
**Files:** `src/lib/whiteboard/links.ts`, `src/components/whiteboard/GraphView.tsx`

`buildGraph` keyed connection edges off `endpoint.boardId` only. The Link Manager
stores the REAL endpoint (a board id OR a **folder** id) in `endpoint.elementId`
and leaves the storage board's id in `boardId`. Consequences:
- **board → folder**: both endpoints collapsed to the same board id, the
  `sBoard !== tBoard` guard dropped the edge — the link was invisible.
- **folder → board**: the edge was drawn from an arbitrary board *inside* the
  folder instead of the folder node.
- **folder → folder**: dropped entirely.

`buildGraph(boards, customLinkTypes, folders)` now resolves each endpoint through
the set of all board+folder ids (`elementId` first, `boardId` as fallback). A
same-board shape-to-shape canvas arrow still resolves to one board and stays out
of the global graph, as before. A pin's custom label now also wins over the
link-type name on the edge.

### F2 — No direction arrow on containment edges (MEDIUM) ✅
**File:** `GraphView.tsx` — the arrowhead polygon was rendered only for
`!isParent` edges, so the folder→board "Contains" edge had no direction. All
edges now carry an arrowhead (7px/70% opacity for containment, 10px for links).

### F3 — Folder nodes were dead in the graph (MEDIUM) ✅
**Files:** `GraphView.tsx`, `src/store/whiteboard.ts`
`handleNodeClick` returned early unless the id was a board, so clicking any
folder node did nothing. New store action `revealFolder(id)` expands the folder
AND every ancestor (with a visited-set guard against pre-existing parentId
cycles), marks it active and opens the sidebar; the graph then closes and opens
the folder's first board if it has one.

### F4 — Pen flyout edited the wrong tool (HIGH, found while building F5) ✅
**Files:** `src/lib/whiteboard/types.ts`, `Toolbar.tsx`
The canvas reads `getToolColor/getToolSize` (per-tool fields), but the toolbar's
one shared pen flyout wrote only `penColor`/`penSize`. Picking a colour while the
highlighter/marker/brush/calligraphy/pencil was active silently changed the PEN.
New inverse helpers `setToolColor(tool, c)` / `setToolSize(tool, n)`; the flyout
now reads and writes whichever stroke tool is active.

### F5 — NEW FEATURE: Favorite Pens bar ✅
**Files:** `src/components/whiteboard/FavoritePensBar.tsx` (new),
`store/whiteboard.ts`, `lib/whiteboard/types.ts`, `lib/whiteboard/persistence.ts`,
`WhiteboardApp.tsx`, `Toolbar.tsx`

A floating, movable bar of pinned pens. Each pin is a full
`(tool, color, size)` triple, so the same pen type can be pinned many times in
different colours. Click a pin to use it, drag a pin to reorder, drag the grip to
move the bar anywhere (position persisted and re-clamped on resize), "+" pins the
current pen, right-click a pin to edit its type / colour (10 presets + a native
colour picker for ANY colour) / size, or delete it. Toolbar star button toggles
the bar. All pointer-event based so it works with finger and stylus, not just a
mouse. Persisted through `migrate()` with per-field validation (bad pins dropped).

Two self-inflicted defects were caught during live browser testing and fixed
before landing: a `setState` inside a state updater (React "cannot update a
component while rendering" warning) and an unguarded `setPointerCapture` that
throws when the browser has no active pointer.

**Verification:** `npm test` (incl. new REG-F1 / REG-F2 groups) ALL PASS ·
`tsc --noEmit` 0 errors · `npm run lint` clean · `npm run build` 5/5 pages ·
live browser: link edge now renders with label + arrowhead, folder click opens,
pin add/edit/apply/reorder/move all verified against localStorage.

### F6 — Graph force simulation had an inverted y attraction (MEDIUM) ✅
**File:** `GraphView.tsx` — in the edge-attraction loop `a.vy -= fy` should be
`a.vy += fy`. Linked nodes were pulled together horizontally but pushed apart
vertically, skewing every layout (visible as the vertical stringing in the user's
12-node graph). Now symmetric with `b`.

---

## STEP 10 — Windows app packaging + selection-overlay zoom bug (2026-08-19)

### G1 — Selection box & resize handles drawn away from the element (HIGH) ✅
**Reported by user:** "in the resize for the photos it is like the place of the
what i press to resize is not same place of the image frame" (screenshot: image
top-left, dashed selection box + handles far bottom-right).

**Files:** `src/lib/whiteboard/geometry.ts`, `SelectionOverlay.tsx`

`SelectionOverlay` computes corner/handle positions in SCREEN space (so handles
keep a constant pixel size), then renders them inside the canvas' WORLD group,
undoing that group's transform. The world transform is

    translate(vw/2, vh/2) scale(z) translate(-cx, -cy)

and an SVG transform list applies right-to-left, so the inverse is those three
operations **reversed** and inverted. The code listed them in the same order as
the forward transform:

    translate(-vw/2, -vh/2) scale(1/z) translate(cx, cy)     <-- wrong

which composes to the identity **only when zoom === 1**. At any other zoom it
left a constant offset of `(camera + viewport/2) * (1 - zoom)` — measured drift
459px at zoom 0.5 and 1285px at zoom 2.4 for a 1600x900 viewport. Hit-testing
used the true positions, so the handles you could see were not the handles you
could press. Extracted as `screenSpaceOverlayTransform(camera, viewport)` in
geometry.ts with the correct order.

**Verified live** at 55% zoom on the production build: selection box is
pixel-identical to the element's own screen box (drift 0,0) and all 8 handles +
the rotate handle sit exactly on its corners/edges. Pinned by **REG-F3**, which
round-trips the transform at 7 zoom levels x 3 camera positions.

### G2 — Windows app packaging ✅
**New files:** `ProNotes.vbs` (launcher), `Build-ProNotes.bat`,
`Stop-ProNotes.bat`, `scripts/make-ico.mjs`, `public/pronotes.ico`

ProNotes now opens like a normal Windows app, no terminal and no agent needed:
- `ProNotes.vbs` starts `next start` **hidden** (no console window), polls until
  the port actually answers (30s budget, clear error dialogs on failure), then
  opens a chromeless `--app=` window in Edge or Chrome. Reopening is instant
  because the server is left running; `Stop-ProNotes.bat` ends it.
- `PREFERRED_BROWSER` constant at the top selects edge/chrome/auto/default —
  documented in-file because **boards live in the browser's localStorage**, so
  Edge and Chrome keep separate sets of boards.
- `scripts/make-ico.mjs` builds a real multi-resolution icon (16/24/32/48/64/
  128/256px) from `icon-512.png` via sharp — the shipped favicon.ico was 2KB
  (16/32 only) and looked mushy at desktop-shortcut size.
- Desktop **and** Start-menu shortcuts created, both using that icon.

**Verified:** cold start from the desktop shortcut with port 3000 free — server
answered in <1s, Edge app window titled "ProNotes — Infinite Whiteboard &
Knowledge Canvas", zero visible console windows.

---

## STEP 11 — Cleanup, dead-suite discovery, and three UX/robustness fixes

### H1 — Repository cleanup ✅
Deleted (backed up first — no VCS on this project):
- 36 unused shadcn UI components + `hooks/use-mobile.ts` + the 1-line dead
  `components/whiteboard/grid.ts` re-export shim (38 files, 122 KB) — proven
  unreachable by a walk from `app/layout.tsx` / `app/page.tsx`.
- `src/app/api/route.ts` — a "Hello, world!" boilerplate handler that shipped as
  a real dynamic route. Build now emits 2 routes instead of 3.
- `.test-dist/` (348 KB) and `tsconfig.tsbuildinfo` (231 KB) — regenerable caches.
- `.agents/` (979 KB) — subagent briefings/handoffs from the audit session.
- `ORIGINAL_REQUEST.md`, `TEST_READY.md`, `SESSION_SUMMARY_2026-08-17.md`.

### H2 — 258 tests were outside the gate, and one was FAILING ✅
`tests/e2e/` has its own runner that `npm test` never invoked, so the "258/258
PASS" claim in the handoff report had quietly become 257/258. Registered the
suite in `scripts/test-runner.mjs`.

The failure was real: **`saveState`'s failure notification could itself throw.**
`window.dispatchEvent(new CustomEvent(...))` sat inside (and after) the guarded
blocks, so if event construction/dispatch raised — no CustomEvent, a throwing
listener — the exception escaped `saveState` into the autosave timer, which is
precisely the crash the quota handling exists to prevent. Split into
`saveDegraded()` plus a `notify()` helper that can never throw; success/failure
is now decided by the write alone, never by whether anyone listened.

### H3 — Links panel could not be closed ✅
`BacklinksPanel` had no close control. Its "Links" toggle only renders while the
sidebar is hidden — and the panel then covers that button, so the only way out
was the undocumented Ctrl+B. Added an X button and a one-line explanation of
what the panel actually shows (it opens from a button labelled only "Links").

### H4 — Ctrl+Shift+Z was dead, Ctrl+Z broke under Caps Lock ✅
Undo/redo matched on `e.key`, which carries the SHIFTED/caps character: with
Shift held the event reports `"Z"`, so `e.key === "z" && e.shiftKey` could never
be true and the documented Ctrl+Shift+Z redo never fired; Caps Lock likewise
broke plain Ctrl+Z. Moved to `e.code` (physical, layout-stable) and extracted
`isUndoCombo`/`isRedoCombo` into `lib/whiteboard/shortcuts.ts` so the rule is
unit-testable. Pinned by **REG-F4**.

### H5 — Unguarded setPointerCapture could abort a whole gesture ✅
`WhiteboardCanvas.capturePointer` called `setPointerCapture` bare. It throws
`NotFoundError` when the pointer is no longer active — a genuine race on touch
devices if the finger lifts between the event firing and the handler running —
and the exception escaped `handlePointerDown`, skipping the rest of the gesture
setup (tool state, draft element, history). Same class as the leaked-pointer
bugs in Group A. Now caught; losing capture only costs events outside the SVG.

**Verification:** `npm test` — all suites INCLUDING the newly-wired 258-test E2E
suite (258/258) and REG-F1..F4 · `tsc --noEmit` 0 errors · lint clean ·
`npm run build` clean.

### H6 — Link Legend was drawn underneath the toolbar ✅
**Reported by user:** "conflict" (screenshot: legend clipped by the bottom dock).

`LinkLegend` sat at `absolute bottom-16 right-4 z-20`. Both bottom docks — the
tool dock and the zoom/undo cluster — sit at `bottom-6` (24px) with **z-30** and
are ~52px tall, so they occupy roughly 24-76px of the bottom edge. The legend's
own bottom edge at 64px landed inside that band, and the lower z-index meant the
docks painted over it. Moved to `bottom-28 right-6 z-30` (aligned with the
right-hand cluster) and capped at `max-h-[45vh] overflow-y-auto` so a long list
of custom link types cannot grow up into the header instead.

**Verified** by measuring live bounding boxes at 1600x900 and 1280x720: 36px
clearance to the nearest dock, zero rectangle intersection at both sizes.

---

## STEP 12 — Accounts & cross-device sync via OneDrive (free)

Goal: install on an Android tablet and as a Microsoft Store app, sign in with the
same email, and have boards sync — **without any subscription**. Microsoft
removed Store registration fees for individuals and (May 2026) companies, and
hosting is a free Netlify static deploy, so the only recurring cost is zero.

### New: workspace document (`lib/whiteboard/workspace.ts`)
One portable JSON doc holding folders, boards, elements, link types and pens.
Imported payloads go through the same `migrate()` hardening as a local load
(`migrateState` exported for this), so a hand-edited or truncated backup cannot
brick the app. `parseWorkspace` rejects non-JSON, files from other apps, and
backups from a NEWER format with actionable messages rather than silently
importing an empty workspace over good data.

**`mergeWorkspaces` merges per BOARD by `updatedAt`, not per document.**
Whole-document last-write-wins is what destroys work: edit board A on the tablet
and board B on the PC and whichever syncs second erases the other's board
entirely. Per-board merge means both survive; only a board edited on *both*
devices picks a winner. Custom link types are unioned (losing one would render
its connections as unlabelled grey lines); pinned pens and bar position stay
per-device.

### New: OneDrive client (`lib/whiteboard/onedrive.ts`)
OAuth 2.0 **authorization code + PKCE** (the only flow Microsoft still allows for
SPAs; implicit is deprecated), no client secret, no backend, and no MSAL
dependency — ~100KB avoided for what is three fetch calls. Scope is
`Files.ReadWrite.AppFolder`, so the app can touch **only its own folder**, never
the rest of the user's OneDrive. Silent refresh a minute before expiry; a dead
refresh token forces re-auth instead of retrying forever.

### New: `SyncPanel.tsx` + store actions
`getWorkspaceSnapshot` / `replaceWorkspace` / `mergeWorkspace`. Restore replaces
everything, so it confirms with the real board count first — it is not undoable.
Restore also clears history on purpose: undo stacks describe elements that no
longer exist. Backup/restore works with **no account at all**, which is the
migration path off per-browser localStorage.

Gated behind `NEXT_PUBLIC_MS_CLIENT_ID`; without it the panel shows an amber
"not set up" notice and backup/restore still work. Setup documented in
`ONEDRIVE_SETUP.md` (app registration is the one step that needs the user's own
Microsoft credentials).

**Verification:** REG-F5 pins the round trip, the three rejection cases, and the
merge rules (locally-newer keeps local, remotely-newer takes remote, remote-only
pulled in, empty remote never wipes local, link types unioned, active board
preserved). `npm test` all green incl. 258/258 E2E · tsc 0 errors · lint clean ·
build clean. Panel verified live in the unconfigured state.

---

## STEP 13 — Android APK + self-service accounts

### I1 — Real Android APK ✅
Machine already had JDK 17 (Temurin), Android SDK (platform 35, build-tools
34/35) and Gradle 8.9, so the APK is built **locally** — no hosting, no
PWABuilder, no Play account needed.

- `next.config.ts` gained an **opt-in** static export (`PRONOTES_STATIC=1`).
  It is not always-on because `output: "export"` is incompatible with
  `next start`, which the Windows launcher (ProNotes.vbs) depends on.
  `npm run build` = server build for Windows; `npm run build:apk` = static
  export into `./out` for Capacitor.
- **Capacitor 6, not 8.** Capacitor 8 compiles against Java 21 and failed with
  `invalid source release: 21`; rather than install a second JDK on the user's
  machine, dropped to Capacitor 6, which targets JDK 17.
- `scripts/make-android-icons.mjs` generates launcher icons at all five
  densities from `icon-512.png`, including the adaptive-icon foreground inset
  to ~62% (Android crops roughly a third, which would shave the mark's edges).
- `npm run apk` runs the whole chain and drops `ProNotes.apk` in the root.

**Result:** `com.idrees.pronotes`, 5.1 MB, signed, minSdk 22 / target 34, with
all 64 web assets bundled in `assets/public` — runs with no server and no
internet.

### I2 — Self-service sign-up ✅
Requirement was explicitly "signing up, not just you adding the user".

`lib/whiteboard/account.ts` (Supabase) — anyone can create their own account
with email + password. **Email/password rather than OAuth on purpose:** the app
also ships as an APK, and an OAuth redirect round-trip inside a WebView is
fragile, whereas an email/password call is a plain HTTPS request. Terse Supabase
errors are mapped to actionable messages ("That email already has an account —
sign in instead").

`AccountSection.tsx` — sign in / create account / forgot password, with the
password-mismatch check done client-side *before* the account is created, so a
mistyped password cannot produce an account the user cannot log into.

Sync reuses the same per-board `mergeWorkspaces` as OneDrive, so all three
paths (account, OneDrive, backup file) share one merge policy.

Security: one row per account, guarded by **row-level security** policies
(`ACCOUNTS_SETUP.md` ships the SQL). Without them the public anon key would let
any signed-in user read every other user's boards. The docs call out never using
`service_role` in a browser build.

### I3 — Lint was silently scanning generated Android output ✅
Adding `android/` made `eslint .` walk Capacitor's vendored `native-bridge.js`
and report an error for a rule that config doesn't define. Added `android/`,
`ios/`, `out/`, `.test-dist/` to the ignore list, and the Capacitor/Gradle build
outputs to `.gitignore`.

**Verification:** APK contents inspected with `aapt2 dump badging` + zip listing
(package id, label, signature, bundled assets). Sign-up form verified live with
placeholder credentials — three fields render and the mismatch check fires
before any network call; placeholders then removed and `.env.local.example`
added. `npm test` all green incl. 258/258 E2E · tsc 0 errors · lint clean ·
both builds clean.

---

## STEP 14 — Real Windows desktop app (Electron)

Replaces the VBS launcher + browser-app-window with a genuine `.exe`: own
process named `ProNotes`, own icon, own window, no browser and no Node server.

**Files:** `electron/main.js`, `scripts/build-desktop.mjs`, electron-builder
config in `package.json`.

### Why a custom `pronotes://` scheme instead of `file://`
Two concrete reasons, both fatal with `file://`:
- Next.js emits **absolute** asset paths (`/_next/...`), which `file://`
  resolves against the drive root — every chunk 404s.
- `file://` is an **opaque origin**, so `localStorage` does not persist
  reliably. Every board lives in localStorage, so that alone rules it out.

The scheme is registered `standard: true, secure: true`, giving a stable secure
origin, so storage behaves exactly as on a website. The handler resolves paths
under `./out` with a **path-traversal guard** — a crafted URL must not be able
to read outside the bundle.

### Other hardening
- `requestSingleInstanceLock()` — a second launch focuses the existing window
  instead of opening a rival copy competing over the same storage.
- External links open in the real browser (`setWindowOpenHandler` +
  `will-navigate`) rather than replacing the app inside its own window.
- `contextIsolation: true`, `nodeIntegration: false`, `sandbox: true`.
- Native menu bar removed — it would only steal vertical space from an infinite
  canvas, and every action already has a button and a shortcut.

### Build notes
- npm here blocks postinstall scripts, so Electron's binary was never
  downloaded (`Electron failed to install correctly`). Fixed by running
  `node node_modules/electron/install.js` directly.
- Two outputs in `dist-desktop/`: an **NSIS installer** (per-user, so no admin
  prompt; creates Start-menu + desktop shortcuts) and a **portable exe**.

**Verified:** packaged exe carries ProductName/FileDescription "ProNotes" and a
real icon (extracted 32x32); launching it yields a process named `ProNotes`
with the window title from the app's own HTML — which also proves the custom
protocol served index.html correctly.

### KNOWN: storage does not carry over
The desktop app is a separate browser profile from Edge, so boards created in
the old launcher window do **not** appear in it — this is unavoidable, not a
bug, and applies to any browser change. Move them with
**Sync & Backup → Save backup** then **Restore** in the new app, or sign in to
an account on both.

---

## STEP 15 — Toolbar/chrome redesign (ordering, settings, contextual properties)

User report: duplicate light/dark icons, panels stacking so some tools could not
be clicked, the Link Legend permanently occupying canvas, and no home for
settings — "see how apps design the tools and settings things".

### J1 — Duplicate controls removed ✅
Export, Keyboard-shortcuts and Theme each existed in BOTH the header and the
toolbar (hence two sun/moon icons). Now every control appears exactly once:
- **Header (top-right) = document actions:** Links · Search · Graph · Export ·
  Sync · Settings
- **Bottom dock = tools + view:** tool row, contextual properties row, zoom
- **Settings panel = set-once options**

Self-inflicted repeat: the first pass put a Settings gear in *both* the header
and the view dock. Caught by the user; the duplicate-detector had compared
title *strings*, which differed, so it missed a same-purpose duplicate.

### J2 — Overlap at non-maximised sizes (the real bug) ✅
The first overlap sweep at 1600x900 found nothing because the collision only
happens when the window is NARROW — the user pointed this out. Reproduced at
900x700: tools dock spanned 284-872 while the zoom dock sat at 715-876, so the
zoom dock covered the right-hand tools and made them unclickable.

Root cause: the two docks were independently positioned (`bottom-6 left-1/2`
and `bottom-6 right-6`), which cannot collide on a wide window and always
collides on a narrow one. They now share ONE centred wrapping flex container,
so they sit side by side when there is room and stack when there is not —
collision is structurally impossible at any size.

Two follow-ons found by measuring rather than eyeballing:
- The row used `max-w-[calc(100vw-2rem)]`, but it is positioned inside the
  CANVAS area (offset by the sidebar), not the window — so it still hung off
  the right edge at 760px. Now `calc(100% - 2rem)`.
- The favourites bar only re-clamped on a `resize` event. It now clamps at
  **render** time: `pos` is what the user chose, `renderPos` is where it is
  allowed to be now. A window can be resized while backgrounded, and
  Electron/Android restore sizes without firing resize; a stale position left
  the bar stranded off screen where it could not be dragged back.

### J3 — Contextual tool properties (the requested pattern) ✅
**New:** `ToolProperties.tsx` (bar + panel), `ColorSwatches.tsx`.

Following Samsung Notes / Concepts: the tool row only SELECTS; a second row
shows the ACTIVE tool's properties — thickness presets (dot size mirrors the
real stroke width), quick colours, and a ⚙ opening the full panel (pen family,
thickness slider with -/+, full palette, dash/fill for shapes, font for text,
sticky colour). The bar hides entirely for tools with nothing to configure
(select/lasso/pan/image).

**Custom colour** is now real: a rainbow disc wrapping a native colour input,
plus `recentColors` in the store (max 8, deduped, persisted) so a mixed colour
is not lost the moment you pick another. Recents lead the compact row.

The old pen flyout — which carried its own duplicate colour and size controls —
is now a plain selection button.

### J4 — Link Legend off by default ✅
It is a colour key, not a tool, and it permanently occupied a large block of
canvas. Now starts hidden, toggled from Settings > Canvas.

**Verified** by measuring bounding boxes of every floating panel pairwise at
1280x800, 900x700 and 700x620: zero overlaps, zero off-screen panels, and the
contextual row live with 5 thickness presets, 6 quick colours and the custom
wheel. Gates: tests green incl. 258/258 E2E, tsc 0 errors, lint clean, build clean.

### J5 — Element Properties panel appeared not to work ✅
**Reported:** "the one in the first photo not work for the shapes but the second
what changes" — the *Rectangle Properties* panel seemed inert while the toolbar
shape flyout worked.

The panel's logic was fine: verified live that clicking a colour in it updates
the element and persists (`#1e293b` → `#eab308` written to the board). The
failure was **occlusion**. The panel is `absolute right-5 z-30`; the floating
favourites pen bar is `fixed z-40` and defaulted to the RIGHT edge, so it sat on
top of the panel and swallowed the clicks on the third option of every row —
which is exactly why *Solid*, *Dotted* and *8px* are clipped in the screenshot.
Covered controls do nothing when clicked, so the panel reads as broken.

Fixes:
- Panel raised to `z-50` (above the pen bar) and given `max-h`/`max-w` so it can
  never exceed the canvas area on a small window.
- The favourites bar now defaults to the LEFT edge; the right-hand side belongs
  to the header and the properties panel. It is still draggable anywhere.

**Verified** with a hit-test rather than by eye: for all 22 controls in the
panel, `document.elementFromPoint` at each control's own centre returns that
control — zero blocked. (An earlier run showed all 22 blocked by the tutorial's
`z-[100]` overlay, which correctly covers everything while it is open.)

---

## STEP 16 — Rebuild both packaged apps (they had gone stale)

The APK and the Windows installer are **snapshots**, not live views of the
source. Both had fallen behind:

| Artifact | Was built | Missing |
|---|---|---|
| `ProNotes.apk` | 14:24 | sign-up/accounts, Settings panel, toolbar redesign, contextual tool row + custom colour, legend-off default, properties-panel occlusion fix |
| `ProNotes Setup .exe` | 14:49 | everything from the toolbar redesign onward |

Both rebuilt from source at 15:37 / 15:40.

### Bug found while rebuilding: `npm run apk` was broken ✅
`scripts/build-apk.mjs` invoked `gradlew.bat` as a bare command with a changed
cwd, which does not resolve (`'gradlew.bat' is not recognized`). The first APK
only succeeded because it was built by hand with `./gradlew` from a bash shell.
Now uses an absolute, quoted path to the wrapper.

### Verification — content, not timestamps
A fresh timestamp proves nothing, so both packages were opened and searched for
strings that only exist in the new code ("Custom colour", "Create account",
"Link legend", "Snap to grid", "Sync & Backup"):
- APK: 65 web-asset files, all markers present.
- Windows: all markers present inside `app.asar`.

(An initial check reported everything missing — that was a bad `unzip` glob:
`assets/public/*` does not cross `/`, so only 20 top-level files were extracted
and the app chunks under `chunks/app/` were never searched. The extraction was
wrong, not the APK.)

---

## STEP 17 — Per-board background colour & paper style

Each board now carries its own paper: a background colour plus a pattern
(Dots / Grid / Lines / Plain), set in **Settings → Board background**.

**Files:** `types.ts` (`BoardBackground`, `BOARD_BACKGROUNDS`, `BOARD_PATTERNS`,
`Board.background`), `store/whiteboard.ts` (`setBoardBackground`),
`WhiteboardCanvas.tsx` (paper rendering), `SettingsPanel.tsx` (picker),
`persistence.ts` (validation).

Design decisions worth recording:
- **Presets are stored by id, not by colour.** Each preset carries a light AND a
  dark value, so a board painted "Mint" becomes `#eef8f2` in light and `#12201a`
  in dark instead of staying a glaring pale green on a dark canvas. A *custom*
  colour is stored literally, since the user picked exactly that.
- **Two rects, not one.** A solid colour rect is painted first and the pattern
  tiled on top. Tiling colour and pattern together would need opaque tiles,
  which would hide the board colour.
- Preset colours are deliberately low-saturation: the background sits behind
  everything, and a vivid one makes ink and sticky notes unreadable.
- The pattern is offset by the camera, so paper scrolls WITH the canvas rather
  than staying pinned to the screen.
- `migrate()` drops a background whose pattern is not recognised, rather than
  rendering nothing.

**Verified live:** picking Mint + Grid painted `#12201a` with a `path` pattern
(dark theme) and persisted `{pattern:"grid",color:"mint"}`; switching to Light
repainted the same board `#eef8f2` — the theme-pairing works.

### Test updated (not silenced)
E2E `16.2` asserted the canvas source contains the literal string `dot-grid`,
the old pattern id. Renaming it to `board-paper` broke a test whose real intent
is "the paper adapts to dark mode". Rewrote the assertion to check the pattern
id AND both dark-mode ink classes (`dark:fill-zinc-700`, `dark:stroke-zinc-700`),
so it now guards the behaviour rather than a name. 258/258, 575 assertions
(up from 573).

---

## STEP 18 — Windows blocked the Electron app (Smart App Control)

**Symptom:** launching the pinned taskbar shortcut gives
*"An Application Control policy has blocked this file."*

**Diagnosis (not a bug in the app):**
- `HKLM\SYSTEM\CurrentControlSet\Control\CI\Policy` →
  `VerifiedAndReputablePolicyState = 1` — **Smart App Control is ON**.
- `Get-AuthenticodeSignature` on `ProNotes.exe` → **NotSigned**.
- Launching it directly reproduces the same block.
- AppLocker is not configured, so SAC is the sole cause.

Smart App Control only allows binaries that are signed by a recognised
publisher or have established reputation. An electron-builder output signed
with no certificate has neither, so Windows refuses it. This would block ANY
self-built exe, not just this one.

**Working paths under SAC (verified):**
- `node.exe` is signed by `CN=OpenJS Foundation` (status Valid), and Edge is
  Microsoft-signed — so the original **VBS launcher** path is unaffected.
  Re-tested: server up, Edge app window titled ProNotes.
- The app meets PWA install criteria (`manifest.json` 200, `sw.js` 200,
  name/start_url/display=standalone/icons at 192 & 512), so **Edge → Install**
  gives a real Start-menu/taskbar app with its own icon and window while
  running inside Microsoft-signed Edge — no unsigned binary involved.

**Not done deliberately:** Smart App Control was NOT disabled. It is a security
setting, and critically it can only be turned OFF — re-enabling it requires
reinstalling Windows. That is the user's call, not something to change on their
behalf.

---

## STEP 19 — Stroke ends were blunt / "unsmooth finish"

**Reported:** the end of a written stroke finishes with an angular chop instead
of a clean point.

**Root cause, measured not guessed.** `getSvgPathFromStroke` smooths the
perfect-freehand outline with midpoint quadratics: each segment is
`Q vertex, midpoint(vertex, next)`. A quadratic Bezier never passes through its
control point, so **every vertex is cut**. On gentle curvature that is exactly
what you want; at a sharp vertex it lops the corner off.

Quantified on a real pen outline (16px stroke):
- tip vertex `(334.0, 144.0)`, interior angle **112°**
- smoothed curve's closest approach `(332.5, 146.2)`
- **gap = 2.66px = 17% of the stroke width** — the visible blunt end.

**Threshold chosen from data, not taste.** Angle distribution across a straight
flick, curved script and a tight loop:

| outline | min | p05 | median |
|---|---|---|---|
| straight flick | 112° | 123° | 180° |
| curved script | 122° | 123° | 168° |
| tight loop | 125° | 137° | 167° |

Tips and true corners cluster at 112-125°; ordinary curvature is 137°+. **130°**
separates them cleanly, so `isSharpCorner()` routes the path THROUGH vertices
below 130° and keeps the quadratic everywhere else.

**Verified:** the emitted path now contains the tip as an on-curve point
(gap 0 instead of 2.66px), while 37 of 45 segments remain quadratic — only the
8 genuinely sharp vertices become line segments, so curves are still smooth.

### Two tests updated (they encoded the bug)
`milestone1` asserted a **square**'s 90° corners produce `Q` segments, and
`challenger_stroke_stress` asserted the same for a **triangle**. Both were
pinning the corner-cutting behaviour that caused this defect. Rewrote them to
assert the corrected intent — sharp vertices reached, not rounded — and added a
32-gon (circle approximation) case asserting that shallow curvature still emits
**zero** line segments, so the fix cannot regress into faceting smooth strokes.

All suites green: 12,289 challenger assertions, 258/258 E2E, regression suite,
tsc 0 errors, lint clean.

---

## STEP 20 — Stroke ends STILL blunt: the geometry was frozen at draw time

Follow-up to STEP 19. The corner fix was correct but **invisible on existing
strokes**, because `StrokeShape` did not derive the path — it reused a cached
one:

```ts
if (isDraft || !element.path) return buildStrokePath(element, isDraft);
return element.path;   // geometry frozen at the moment it was drawn
```

`path` was written into the element on commit, so every stroke carried a
snapshot of its own outline. Consequences:
1. **No rendering improvement could ever reach an existing stroke** — the taper
   and corner fixes applied only to strokes drawn afterwards.
2. **~143% storage overhead per stroke** (measured: 120-point stroke = 3436
   bytes of points + 4912 bytes of cached path ≈ 2.4x), duplicated into every
   deep-cloned undo/redo snapshot, and pushing localStorage toward the quota
   path that STEP 11 had to harden.

**Fix:** the path is now always derived from the points (memoised on the
element, so one build per change — the same cost drafts already paid at 60fps).
The commit paths no longer write `path`, and `migrate()` strips the legacy field
on load, reclaiming the space and letting every stroke ever drawn pick up the
STEP 19 tip fix immediately.

**Measurements that drove this:**
- end width at the tip is 0.01px on an 8px stroke — the taper does reach a true
  point, so the blunt end was never a taper problem.
- the only sub-130 degree vertices are 4 in total: two straddling the tip, two
  straddling the start. Exactly the two taper points, nothing else — so the
  corner handling is not faceting the curve.

All suites green: stroke stress 16/16, challenger 12,289, regression, 258/258
E2E, tsc 0 errors, lint clean.

---

## STEP 21 — The real cause of blunt stroke ends: coincident tip vertices

STEP 19 fixed corner-cutting and STEP 20 removed the frozen path cache, but the
end still finished as a flat chisel cut. Dumping the actual outline found why.

For a tapered end, perfect-freehand converges to a point by emitting **several
vertices at the same coordinate**. Measured on a 20px stroke: outline indices
22, 23 and 24 were all **0px** from the last input point, with the next real
vertices 17.9px away.

`isSharpCorner()` guards against zero-length edges (`l1 < 0.001` -> return
false). At the tip every edge to an immediate neighbour IS zero-length, so the
guard fired, the tip was classified "smooth", and the midpoint quadratic
rounded the point away — leaving the flat end.

**Fix:** `getSvgPathFromStroke` now collapses consecutive coincident vertices
(and a wrap-around duplicate) before building the path. The tip becomes a single
vertex between two 17.9px edges, is correctly seen as sharp, and the path is
routed through it.

**Verified:** the emitted path contains the stroke's end point as an on-curve
point, and 42 of 50 segments remain quadratic — the tip is a point, the curve
stays smooth.

Also corrected a flawed measurement of my own: an earlier probe reported the
taper length made no difference to tip sharpness. It was taking the outline's
GLOBAL sharpest vertex, which is the START cap — held constant across every
case. Measuring at the end specifically is what exposed the coincident vertices.

Pinned by **REG-F6**: a synthetic outline with three coincident tip vertices
must produce the tip as an on-curve point; a 40-gon must still emit zero
straight segments; an all-coincident outline must not emit NaN.

Suites: milestone1, stroke stress 16/16, geometry 17/17, challenger 12,289,
regression incl. REG-F6, 258/258 E2E, tsc 0 errors, lint clean, build clean.

---

## STEP 22 — Pen was a brush: round cap instead of a taper

Side-by-side against another notes app made the real difference obvious: their
pen is **uniform width with a round cap**; ours converged to a needle point.
Every previous step had been trying to make a *taper* look smooth, when a pen
should not be tapered at all — that is brush behaviour.

Measured on a 20px stroke with a fading-pressure (stylus lift-off) input:

| preset | outline pts | sharp corners | nearest vertex to the end point |
|---|---|---|---|
| pen, taper 2/4, thinning 0.15 | 51 | 4 | **0.0px** — collapses to a spike |
| taper 0, thinning 0 | 92 | **0** | **10.0px = exactly the half-width** |

With `taper: 0` the outline stays a full half-width away from the end and closes
as a semicircle — a true round cap — and contains **zero** sub-130-degree
vertices, so the corner handling from STEP 19/21 leaves it perfectly smooth.

**Changed:** `pen` -> `thinning 0, startTaper 0, endTaper 0` (gel/felt pen);
`pencil` -> taper 0/0, keeping `thinning 0.1` so it still varies slightly, since
a pencil wears blunt rather than to a needle. `brush` and `calligraphy` keep
their tapers — that IS their character. `highlighter` and `marker` were already
taper-free.

All suites green: stroke stress 16/16, challenger 12,289, regression incl.
REG-F6, 258/258 E2E, tsc 0 errors, build clean.

---

## STEP 23 — Tool setup and preferences were never saved

**Reported:** "the settings of for example the font size is not saved after
closing the app."

It was not just the font size. `getPersistedState()` omitted **all** of it, and
none of the setters scheduled a save either, so every launch reset:

- every pen/marker/brush/highlighter/pencil **colour and size**
- **font size**, font family, text alignment, sticky colour
- shape stroke/fill colours, fill style, dash style, border width
- connection routing and link type
- **stylus mode, palm rejection, two-finger undo** — the most painful one on a
  tablet, since the app reopened in touch-draw every time
- snap-to-grid, minimap, favourites-bar visibility
- the selected tool

**Fixed:** those are now part of the persisted payload; `setStyle`,
`setTouchSettings`, `toggleSnapToGrid`, `toggleMinimap` and `togglePinnedBar`
call `saveNow()` (debounced, so dragging a slider coalesces into one write); and
`init()` restores them by **merging over the defaults** rather than replacing
them, so a preference added in a later version still gets its default value on
an older save.

Two deliberate choices:
- **The eraser is never restored as the active tool.** Reopening straight into
  eraser mode means a stray tap on a restored board silently destroys work
  before the user has noticed which tool is armed; it falls back to select.
- Each preference is validated independently in `migrate()` (object / boolean /
  known-tool), so one corrupt field cannot discard the rest — anything invalid
  becomes `undefined` and picks up its default at init.

**Verified live:** set pen thickness 37 and colour #f97316 -> both present in
localStorage (`style.penSize: 37`, `style.penColor: "#f97316"`, `tool: "pen"`) ->
full reload -> toolbar still reads **37px**. Pinned by **REG-F7**, which also
asserts corrupt preferences are dropped rather than merged.

Gates: challenger 12,289, regression incl. REG-F7, 258/258 E2E, tsc 0 errors,
build clean.

---

## STEP 24 — Pixel eraser (partial erase) instead of delete-on-contact

The eraser called `deleteElements([hit.id])` — touching any part of a stroke
destroyed the whole thing. It now erases only what it covers.

**New:** `eraseFromStroke(points, x, y, radius)` in `stroke.ts`. Points inside
the eraser circle are dropped and the survivors are regrouped into contiguous
runs, so erasing the MIDDLE of a stroke yields **two** strokes — the point of
erasing pixels rather than objects.

Return contract, chosen for the drag path:
- `null` when nothing was touched, so the caller skips the write entirely. This
  runs on every pointermove of an erase drag, so the common case must be free.
- `[]` when the stroke is now gone.
- otherwise the surviving runs.

Runs of a single point are discarded: one leftover point renders as a stray dot
exactly where the user just erased.

**Canvas:** one `eraseAt()` routine shared by press and drag. It cuts through
**every** stroke under the eraser, not just the topmost — an eraser is a
physical brush, not a picker — with a cheap bounds reject before touching any
points. Each surviving piece is re-origined so its points stay relative to its
own element.

**History:** `commit` is true only for the FIRST erase of a gesture, so a whole
swipe collapses into a single undo step instead of dozens.

**Scope:** shapes, text, stickies and images have no partial form, so they still
delete whole — the eraser is never inert. Locked strokes are skipped.

**Mode switch:** `style.eraserMode` (`"pixel"` default, `"object"` for the old
behaviour), exposed both in the contextual bar (Pixel / Whole) and the eraser's
⚙ panel, and persisted with the rest of the tool setup from STEP 23.

Pinned by **REG-F8**: middle-erase splits into two pieces that both lie outside
the circle; end-erase trims to one; full cover returns `[]`; a miss returns
`null`; single-point fragments are dropped.

Gates: challenger 12,289, regression incl. REG-F8, 258/258 E2E, tsc 0 errors,
lint clean, build clean.

---

## STEP 25 — Pixel eraser rewritten: segment clipping along a swept capsule

STEP 24's eraser tested the stroke's recorded POINTS against a circle at the
current pointer position. That is the wrong model, and it failed in three ways —
each measured on a stroke with 30px point spacing (normal for a quickly drawn
line):

| symptom | measured |
|---|---|
| eraser passes between two recorded points | **nothing erased at all** |
| cut can only land on an existing point | a **24px eraser removed 60px** of stroke |
| only the current position is tested | a fast drag erases only around its END |

Public implementations of partial erase clip each **segment** and treat the
eraser's motion as a swept shape rather than a point sample.

**Rewritten:**
- The eraser is a **capsule**: `eraseFromStroke(points, ax, ay, bx, by, radius)`
  takes where it was and where it is now. The canvas keeps the previous
  position in a ref (reset on each press, so a new stroke does not erase a line
  back to the last one) and the bounds reject now tests the swept box.
- Each segment is clipped **analytically** against the eraser — solving
  `|P + t·d − C|² = r²` per sample circle, merging the covered `t` intervals,
  then walking the polyline emitting the uncovered parts with **interpolated
  boundary points**. Cuts land exactly on the eraser's edge whatever the point
  spacing.
- The path is sampled at `radius/2` steps so consecutive circles overlap and the
  union is the capsule — no gaps at any drag speed.
- Single-point strokes (dots) have no segments, so they fall back to a
  point-to-segment distance test rather than being ignored.

**REG-F8 rewritten** to assert the measured behaviour, not just "it splits":
the between-points case erases; the cut lands within 0.5px of the eraser edge
(138/162 for r=12 at x=150); a 24px eraser removes under 25px; a full-length
drag erases everything; a perpendicular sweep splits the line between points;
a miss returns null; fragments are never single points; a dot erases only when
touched.

Gates: stroke stress 16/16, challenger 12,289, regression incl. REG-F8,
258/258 E2E, tsc 0 errors, lint clean, build clean.

Sources consulted: <https://nobuhikosawai.com/en/behind-the-eraser/>,
<https://learn.microsoft.com/en-us/javascript/api/@microsoft/live-share-canvas/istroke>

---

## STEP 26 — Eraser: freezing, beading, and a stray cross-gesture cut

Three separate problems behind "not smooth, freezes, cutted".

### 1. Freezing — the sampling approach blew the frame budget
STEP 25 approximated the eraser capsule by sampling circles along it, costing
O(samples) per segment. Measured on a realistic board (20 strokes x 200 points),
per single pointermove:

| drag | before | after |
|---|---|---|
| slow (8px, r=12) | 5.1 ms | **2.9 ms** |
| normal (40px) | 5.4 ms | **1.7 ms** |
| fast flick (300px) | **8.2 ms — over budget** | **1.8 ms** |
| fast + big eraser (300px, r=48) | 3.5 ms | **1.4 ms** |

Replaced with `clipSegmentToCapsule()`: the capsule is a rectangle plus two end
discs, each clipped analytically and unioned — **O(1) per segment**. A capsule is
convex, so the line-capsule intersection is a single interval and min/max over
the three pieces is exact. Added a per-segment bounding-box reject against the
swept box, which is why even the slow drag got faster: previously every segment
of every stroke paid full cost on every event.

### 2. Beading — fragments smaller than the eraser were kept
Erasing left a trail of short pills and lens-shaped slivers (see the user's
screenshots): each surviving scrap became its own stroke element, complete with
its own round caps. Fragments shorter than the eraser radius are now discarded —
they are debris from the rub, not ink the user chose to keep — which also stops
the element count exploding during a long erase.

### 3. A stray cut in a direction the user never moved
`lastErasePosRef` was cleared on pointer DOWN but never on up or cancel, and the
drag handler has a fallback branch for `idle + button held` (pointer entered
already pressed, or capture lost). That branch continued the *previous*
gesture's sweep, so the capsule spanned from wherever the last erase ended to
the new position — **erasing a straight line between two unrelated places**.
The ref is now cleared on up/cancel, and the fallback branch starts a fresh
sweep instead of continuing a stale one.

### Direction independence pinned
Measured and asserted in REG-F8: a stationary eraser cuts exactly its own
diameter (24px for r=12) on horizontal, vertical and diagonal strokes alike; a
perpendicular sweep also cuts one diameter; a sweep ALONG the stroke removes
travel + diameter, because that is the area the eraser actually passed over.

Gates: stroke stress 16/16, challenger 12,289, regression incl. REG-F8,
258/258 E2E, tsc 0 errors, lint clean, build clean.

---

## STEP 27 — The pen types were names, not pens

**Reported:** "all pens types is same no diff of them ... make more than type for
real and not just a diff names".

**Confirmed by measurement.** perfect-freehand varies width only through
`pressure x thinning`. With a mouse every point arrives at ~0.5, so a preset
that only tweaks `thinning` renders identically. Width profile on one stroke,
compared to the plain pen: marker differed by **3.1px**, highlighter 5.6px,
pencil 6.8px — i.e. pen/marker/highlighter/pencil were the SAME geometry and
differed only in opacity. Brush and calligraphy differed from each other by
0.05 thinning: the same pen twice.

### Real differentiation, not new labels
Two new mechanisms in `applyPenDynamics()` re-weight per-point pressure, which
is the only place a preset can change geometry when input pressure is flat:

- **`speedResponse`** — fast strokes thin out, as a real ballpoint or fountain
  pen does. Derived from the distance between consecutive points, clamped so a
  flick cannot collapse the line.
- **`nibAngle`** — width depends on the DIRECTION of travel: wide across the
  chisel, narrow along it. This is what makes a fountain pen calligraphic
  rather than merely thin.

Plus **`cap: round | flat`** (a marker/highlighter has a squared-off tip; a pen
does not) and **`grain`** for the pencil, rendered as an SVG turbulence +
displacement filter defined once per canvas.

### The eight pens (researched against GoodNotes / Samsung Notes)
Ballpoint · Gel · Fineliner · Fountain · Brush · Marker · Highlighter · Pencil,
each with a one-line hint and a live preview squiggle in the picker.

Measured on one identical stroke (12px base): **8 of 8 distinct signatures.**

| pen | width range | cap | blend |
|---|---|---|---|
| ballpoint | 10.2-11.4 | round | normal |
| gel | 11.9-12.0 | round | normal |
| fineliner | 12.0 flat | round | normal |
| fountain | 7.2-10.4 (direction) | round | normal |
| brush | 6.8-10.3 | round | normal |
| marker | 19.2 (1.6x) | flat | normal |
| highlighter | 36.0 (3x) | flat | multiply |
| pencil | 10.9-11.7 | round | multiply + grain |

Legacy ids `pen` and `calligraphy` are kept and mapped to Gel and Fountain so
strokes drawn before this rework still render. `isStrokeTool()` /
`STROKE_TOOL_IDS` replace four hand-maintained copies of the stroke-tool list.

### Four tests replaced (they pinned the defect)
E2E 1.3-1.6 asserted the exact old numbers (`thinning === 0.05`,
`thinning === 0.45`) — the values that made the pens identical. Rewritten to
assert what actually matters:
- flat vs round caps per family
- brush is pressure-driven and tapers; fineliner does neither
- **fountain width changes with direction** (>0.15 pressure difference along vs
  across the nib) while a fineliner is provably direction-blind on the same
  two strokes
- **all eight pens produce distinct signatures** — the exact defect, now pinned
- fast strokes thin for speed-responsive pens, and not for a fineliner

259/259 E2E (one more than before), challenger 12,289, regression, milestones,
tsc 0 errors, lint clean, build clean.

### NOTE: another agent is editing this project concurrently
`eraseFromStroke()` and `eraserMode` appeared in the source without being
written by this session, and files were modified between this session's edits.
There is no git here, so there is no safety net against two agents overwriting
each other. Changes in this step were kept additive for that reason.

---

## STEP 28 — The writing pens were still identical (line weight was missing)

**Reported:** two handwritten samples, "what is the diff between two?" — they
looked the same.

They were. STEP 27 made the pens differ in *dynamics* (speed, nib angle, cap,
blend) but every pen still drew at the same nominal width. Measuring ink area on
one identical stroke at a 10px setting:

| pen | ink area vs Gel |
|---|---|
| gel | 0% |
| **fineliner** | **+0%** |
| **ballpoint** | **-8%** |
| pencil | -2% |

Gel and Fineliner were byte-for-byte the same weight, and Ballpoint within 8% —
so whichever two everyday pens were used, they had to look identical at
handwriting size. The dynamics only show up on fast or sharply-curving strokes;
ordinary writing does not exercise them.

**Missing concept: line weight.** Real pens differ mostly by nominal width — a
0.3mm fineliner against a 0.7mm ballpoint. Added `sizeScale` per preset
(replacing the two hard-coded highlighter/marker multipliers, which were the
same idea applied ad hoc to only two pens):

fineliner 0.5 · ballpoint 0.7 · pencil 0.85 · gel 1.0 · fountain 1.05 ·
brush 1.25 · marker 1.6 · highlighter 3.0

Result on the same stroke — every pen now at least 13% from Gel, and the three
writing pens span -49% / -36% / 0%:

| pen | ink area | perceived (x opacity) |
|---|---|---|
| fineliner | -49% | -49% |
| ballpoint | -36% | -36% |
| pencil | -21% | -33% |
| fountain | -15% | -15% |
| gel | 0% | 0% |
| brush | +13% | +7% |
| marker | +48% | +36% |
| highlighter | +192% | +2% |

`pen-sampler.svg` renders all eight on the identical input stroke for visual
comparison (also on the Desktop).

259/259 E2E, challenger 12,289, regression, tsc 0 errors, build clean.

---

## STEP 29 — Zoom / pan: passive listener, delta units, mouse vs trackpad

### 1. `preventDefault()` was a no-op — pinch zoomed the whole browser
`handleWheel` called `e.preventDefault()` inside React's `onWheel`. React
registers wheel handlers **passively**, so that call is ignored — the console
was filling with *"Unable to preventDefault inside passive event listener
invocation"* (visible in the very first inspection of this app). The browser
therefore ALSO applied its own page zoom on a trackpad pinch or Ctrl+wheel.

Replaced with a **non-passive native listener** on the container
(`addEventListener("wheel", …, { passive: false })`), the same fix already
applied to GraphView in STEP 5 (C10). Camera and viewport are read through refs
so the listener is attached once instead of being rebuilt on every zoom step.

### 2. `deltaMode` was never read
Chrome sends pixels; **Firefox sends LINES** (~3 per notch) and page mode
exists too. Treating 3 lines as 3 pixels meant:

| device | before | after |
|---|---|---|
| Chrome wheel notch | pans 100px | pans 100px |
| Firefox wheel notch | pans **3px** (inert) | pans 48px |
| Firefox pinch | zooms **0.2%** per event | ~2% per event |

`normalizeWheelDelta()` converts lines (x16) and pages (x800) to pixels.

### 3. Mouse vs trackpad is now an explicit choice
New `resolveWheelAction(event, mode)` in `lib/whiteboard/input.ts`, with
`touchSettings.wheelMode`:
- **Auto** (default) — a quantised vertical-only step is treated as a mouse
  wheel (zoom); small fractional deltas with sideways drift are a trackpad (pan).
- **Trackpad** — scroll pans, pinch zooms.
- **Mouse** — the wheel zooms.

In every mode Ctrl/Cmd+wheel zooms (browsers deliver a trackpad pinch as exactly
that, so pinch and Ctrl+wheel are indistinguishable and must behave alike), and
Shift+wheel scrolls sideways on a device with only a vertical wheel.

Zoom is exponential (`exp(-dy * 0.0015)`) so it is **symmetric**: zooming in and
back out returns to exactly the starting zoom instead of drifting.

**Verified live:** pinch took the canvas 100% -> 120% with
`defaultPrevented: true` (so the page itself no longer zooms), and a following
two-finger scroll left the zoom at 120% while the world transform moved from
(42.17, 0) to (52.19, 33.41) — pan and zoom cleanly separated.

Pinned by **REG-F9**: unit conversion, Firefox/Chrome notch parity, pinch zooms
in all three modes, zoom round-trip is exactly 1, mode behaviour, the
auto-detection heuristic, and Shift moving the delta to the X axis.

Gates: challenger 12,289, regression incl. REG-F9, E2E all pass, tsc 0 errors,
build clean.

---

## STEP 30 — Paper size is adjustable per board

The paper pattern was locked to a hard-coded 24px (`GRID_SIZE`), so Dots / Grid
/ Lines only ever came in one spacing.

**Added:** `BoardBackground.size` — spacing in px, per board, alongside colour
and pattern. Settings → Board background now has a **Paper size** slider
(6–120px) with 12 / 24 / 40 / 64 presets, hidden for "Plain" since there is no
spacing to set when nothing is drawn.

Details worth recording:
- **Snap-to-grid follows the paper.** `snapToGrid`/`snapPointToGrid` already
  took an optional size, so the canvas now passes the board's spacing. Snapping
  to an invisible 24px lattice while looking at 64px paper is disorienting.
- **The dot radius scales with spacing** (`paperSize / 20`). A fixed 1.2px dot
  looks like dust on 64px paper and like noise on 8px paper.
- **Clamped on load.** A size of `0` or `NaN` would make the SVG pattern tile
  infinitely small and lock the renderer, so `migrate()` clamps to 6–120 and
  drops non-finite values so the default applies. The canvas clamps again at
  render, so even an in-memory bad value cannot reach the pattern.

**Verified live:** pattern tile 24 → 64 on picking the preset, dot radius
1.2 → 3.2, persisted as `{pattern:"dots",size:64}`, and still 64 after a full
reload. Pinned by **REG-F10** (persists per board, other boards unaffected,
survives migrate, 0 is clamped, NaN is dropped).

Gates: regression incl. REG-F10, 258/258 E2E, tsc 0 errors, lint clean, build
clean.

---

## STEP 31 — Thickness slider inline; double-click a tool for its settings

### K1 — Thickness is now a slider in the contextual bar ✅
The bar showed five fixed size presets; any other value meant opening the ⚙
panel. Replaced them with a live range slider plus a preview dot that shows the
ACTUAL width in the current colour (dashed outline for the eraser, which has no
colour). One drag now covers the whole range — 1-64px for pens, 4-96 for the
eraser, 10-96 for text — instead of five fixed stops.

### K2 — Double-click a tool opens its settings ✅
Requested for the pen; applied to the eraser, text and sticky too, so the rule
is "double-click any tool" rather than a special case on one button. Selecting a
pen and choosing WHICH pen are different intents, so a single click still only
selects — a panel must not appear over the canvas on an ordinary tool switch.
The pen tooltip advertises the gesture ("Double-click for pen types"), since an
undiscoverable shortcut is not a feature.

**Verified live:** single click on the pen opens nothing; double-click opens the
pen-type panel (Ballpoint / Gel pen / Brush / Marker / Highlighter / Pencil);
double-click on the eraser opens the Eraser panel. Gates: regression suite,
258/258 E2E, challenger 12,289, tsc 0 errors, lint clean, build clean.

---

## STEP 32 — Both packages rebuilt (2026-09-04)

Gates verified BEFORE packaging, so neither artifact ships a known-broken build:
tsc 0 errors · lint clean · regression suite · 258/258 E2E · 12,289 challenger
assertions.

| Artifact | Size | Built |
|---|---|---|
| `ProNotes.apk` | 5.2 MB | 06:20 |
| `ProNotes Setup 1.0.0.exe` | 193.8 MB | 06:27 |
| `ProNotes 1.0.0.exe` (portable) | 193.5 MB | 06:27 |

**Verified by content, not timestamp.** Both packages were opened and searched
for strings that only exist in the newest code — "Board background",
"Double-click for pen types", "Custom colour", "Ballpoint" (the expanded pen
set), "Erase only the part you touch" (pixel eraser), "Create account",
"Thickness" (the inline slider). All present in the APK's 65 web-asset files and
in the Windows `app.asar`.

Newest source is 8/28 21:48; both builds are 9/4 — so the packages are ahead of
every source change, which a timestamp alone would not prove.

**Unchanged caveat:** the Electron `.exe` is still unsigned and Smart App
Control still refuses it (STEP 18). The rebuilt installer is only useful if that
policy is turned off; the VBS launcher and the Edge PWA install remain the
working Windows paths. The APK is unaffected.

---

## STEP 33 — Element-level vertices in the knowledge graph

**Request:** an object that carries a link (a text box, sticky, shape…) should
be its own vertex rather than being folded into its board's dot; each object
type should be recognisable by shape; and clicking a vertex should land on the
OBJECT, not drop you somewhere on the right board.

### Graph model
`GraphNode` gained `kind` ("board" | "folder" | "element"), plus `boardId`,
`elementId` and `elementType`. Element vertices use a namespaced id,
`el:<boardId>:<elementId>`, with `elementNodeId()` / `parseElementNodeId()`.
Element ids are nanoid and would not realistically collide with board ids, but a
collision would navigate to the wrong object, and the prefix makes an id
self-describing in a debug dump.

**WikiLink edges now start at the element that contains the link**, not at the
board — the graph answers "which note points at this?" rather than only "which
board". The edge is labelled with the link's display alias, so
`[[Physics|the notes]]` reads as "the notes".

**Connections between two shapes on ONE board now appear.** Previously both
endpoints resolved to the same board and the self-loop guard dropped them, so
on-canvas relationships were invisible in the graph. Each endpoint that names an
element on that board becomes an element vertex instead.

Only elements that actually carry a link become vertices — a vertex per shape
would bury the structure in noise. Each hangs off its board with a containment
edge so it is never floating unattached.

### Shapes
`elementNodeShape()` draws each type as itself: text as a wide flat card, sticky
as a square with a peeled corner, image as a landscape rect, diamond/triangle/
star/ellipse as themselves, line/arrow as a bar, stroke as a drawn curve.
Boards stay circles and folders stay squares so the three levels never blur, and
element vertices take a distinct teal fill and a smaller radius — separable by
colour as well as shape, which matters where shape alone is too small to read.

### Navigation
New store action `focusElement(boardId, elementId)`: switches board if needed,
centres the camera on the element and selects it. Centring is just setting the
camera to the element's centre, because the camera IS the world point shown at
the viewport centre — no viewport size needed, which matters since the store
cannot see the viewport. Zoom is floored at 0.6 so you never arrive with the
object as a speck, but someone who deliberately zoomed out is not zoomed in on.

**Verified live:** the welcome board's two stickies now appear as their own
sticky-shaped vertices beside the board circle and folder square; clicking one
closed the graph, switched board, landed the camera exactly on the object's
centre (−170, 70) and selected it. Pinned by REG-F12 (vertices, types, labels,
containment edge, id round-trip, noise exclusion) and REG-F13 (navigation,
centring, selection, unknown-element no-op).

---

## STEP 34 — "my pen settings reset", stylus button, and the favourites bar

### L1 — Settings reset when switching tools: FOUR causes, one root ✅
The pen set grew from 6 to 8 (ballpoint/gel/fineliner/fountain added) but four
separate **hand-written lists** were never updated to match. Each produced part
of the reported "it resets":

1. **`getToolColor`/`getToolSize` had no case** for the four new pens, so they
   fell through to `default: style.strokeColor` / `strokeWidth` — the SHAPE
   border. All four shared one colour and size with each other *and with shape
   borders*: changing a rectangle's border changed your ballpoint.
2. **The pen button hardcoded `"pen"`** — a legacy id not even in the picker —
   so eraser → pen dropped you on a different pen than the one you had.
3. **`VALID_TOOLS` in migrate()** still listed only the old ids, so a saved
   `tool: "fountain"` was rejected and reset on every reload.
4. **`VALID_PIN_TOOLS`** had the same stale list, so a pinned ballpoint / gel /
   fineliner / fountain was **deleted from the favourites bar on reload**.

Fixed structurally rather than by adding four more cases: per-tool ink is now a
keyed map (`style.toolInk`), and both whitelists are derived from
`STROKE_TOOL_IDS`. A map cannot fall through, so adding a pen can never again
silently share state. `buildToolInk()` migrates old saves from the legacy
per-pen fields. `setToolInk()` writes colour and size in ONE patch — two
separate patches both carry `toolInk` and the second would drop the first.
`lastStrokeTool` now remembers the pen in hand across any tool switch.

Caught during the work: `DEFAULT_STYLE` evaluates `buildToolInk()` at module
load, so its constants had to be hoisted above it — the first arrangement threw
`ReferenceError` at import time, i.e. a white screen.

### L2 — Android: could not change or pick a pen ✅
The pen picker was reachable only by DOUBLE-CLICK, a mouse gesture; a double tap
is not reliably delivered as `dblclick` to a button in the Android WebView, so on
the tablet there was no way to change pen from the tool button. Added
**long-press** (450ms, touch only) as the mobile equivalent — mouse keeps
double-click, and a long press suppresses the click that follows it.

### L3 — Stylus button shortcuts ✅
Researched first. **The S Pen's BLE remote button (Air Actions — single click,
double click, gestures) is NOT delivered to web content at all**; it needs the
native S Pen Remote SDK, so double-tap-to-undo cannot be built inside a WebView.
What the platform *does* expose is `PointerEvent.buttons`: bit `2` = barrel
button, bit `32` = eraser end. Implemented the behaviour OneNote and Samsung
Notes both use: **hold the button (or invert the pen) to erase, release to get
your pen back.** The pen is handed back on lift too, so releasing mid-stroke
cannot strand you in the eraser. Toggle in Settings → Touch & stylus.

### L4 — Favourites bar: rotate, dock, and a dead highlight ✅
- **Rotates** between a vertical rail and a horizontal strip, so it can sit as a
  strip along the top. Persisted; position is re-clamped after rotating so it can
  never be thrown off screen.
- Clamping is now **two-axis measured** — the old fixed-width clamp would have
  stranded a horizontal bar off the right edge.
- Reorder-drag and the drop indicator now measure along the bar's **own axis**;
  using Y while horizontal would have landed every drop on the same slot.
- **Bug found:** `isPinActive` indexed `style["gelColor"]` by string — field
  names that stopped existing when ink moved into a map — so **no pin ever
  showed as selected**. Now read through the accessors.

**Verified live:** set Fountain to 13px, switched to the eraser, returned via the
pen button → back on Fountain at 13px with every other pen's ink untouched; the
bar rotated 56x154 → 154x56 and persisted. Pinned by REG-F14 (independent ink,
combined patch, both whitelists surviving migrate) and REG-F15 (pen memory).

### L5 — E2E suite was already red; four tests fixed ✅
Running the full suite exposed 4 failures, one of which had been red since the
element-vertex work in STEP 23 and was **missed because the final gate output
did not include the E2E line and its absence was not noticed**. Recorded here so
the earlier "258/258" claim is not left standing uncorrected.

- `8.2`, `11.1`, `P22` asserted the *storage shape* (`penSize`,
  `highlighterSize`, …) rather than behaviour. No production code writes those
  fields any more — verified by grep before changing the tests — so they were
  re-pointed at `setToolInk`/`getToolSize`. `11.1` additionally now asserts the
  highlighter's size did NOT follow the pen back, and `P22` was widened from the
  6 pre-rework ids to **every pen `PEN_TYPES` offers**, plus a check that pen ink
  never leaks into `strokeWidth` — precisely the bug L1 fixed.
- `P14` asserted a wikilink edge starts at the BOARD. Under STEP 23 it starts at
  the element carrying the link. Updated to the current model while keeping the
  test's real subject: the edge still crosses the folder boundary, and the new
  source vertex is asserted to belong to the board in the other folder.

Suite is now 259/259 with 581 assertions (was 575 before this step).

---

## STEP 35 — "my hand lands on the text and it opens the object on me"

Reported from the tablet: while writing, the side of the hand comes to rest on a
line already typed, and the object opens — resize handles, and a menu of "all
the options" — interrupting the sentence. The request was to make that require a
deliberate gesture (long press, triple tap) and to check how other apps avoid it.

There were **two independent culprits**, and the second one is why fixing the
obvious one would not have been enough.

### M1 — palm rejection only looked at the wrong instant ✅
The canvas suppressed touch only while `penActiveRef` was true — i.e. while the
nib was ON the glass. A palm does not arrive that way:

- it lands **before** you start writing, so at palm-down the flag is false;
- it **stays** down while you lift the pen between words, and the flag drops the
  instant the nib leaves.

Both gaps let the contact through to the select tool, which grabbed whatever it
landed on and dragged it if the hand shifted. New `lib/whiteboard/palm.ts` does
what the tablet note apps actually do — no single signal, four layers:

1. **stylus down** → touch is not input;
2. **stylus recently down** (`PEN_SUPPRESSION_MS = 800`) → still not input,
   which is the between-words gap the old check missed;
3. **retroactive** — a pen landing now proves the contact already down was a
   palm, so whatever it started is *rolled back*, not merely stopped;
4. **contact geometry** — `PointerEvent.width/height`; a fingertip reports
   ~15-30 CSS px, the edge of a hand 45+, often as a long thin ellipse, so the
   larger dimension decides. `1x1` is the spec default for "cannot measure", so
   it abstains rather than guessing.

Rules 1-3 cost pure-touch users **nothing** — a device with no stylus never sets
`lastPenAt`, so the window cannot open. That is what lets this be always-on
instead of a setting nobody finds. Rule 4 demotes an oversized patch to
navigation rather than silencing it, so a broad fingertip can still pan.

Also fixed: the existing stylus-only / palm-rejection branch called
`setSelected(hit.id)` — **palm rejection itself selected the object it was
supposed to be rejecting**.

### M2 — the "all the options" menu had its own long press ✅
The transform box was only half of it. `CanvasContextMenu`'s Radix trigger sits
directly on the canvas `<svg>`, and Radix opens a context menu after **700ms of
long press for every pointer that is not a mouse** (its test is literally
`pointerType !== "mouse"`). So:

- a resting palm opened Bring Forward / Send Backward / Delete on its own, and
- a **stylus paused mid-thought** did too, because Radix lumps pens in with
  fingers.

Because the trigger lives on the same element, the canvas' palm rejection could
not reach it. It is now gated through a new `disabled` prop. Two details that
cost a round of debugging each:

- Radix reads `disabled` **when the press starts**, so arming mid-press is too
  late — re-arming happens when the previous gesture *ends*.
- Conversely, disarming mid-press does work (Radix's own effect clears the
  pending timer), but it relies on a re-render. For the palm path that race is
  closed synchronously instead with `preventDefault()`, which Radix's
  `composeEventHandlers` honours. Suppressing the compat mouse events also stops
  a resting hand from dismissing the editor you are typing in — wanted here.

### M3 — the deliberate gesture, as asked ✅
A finger landing on an object it has not already selected no longer grabs it:

| gesture | result |
|---|---|
| finger lands and stays | nothing — 500ms hold selects |
| finger lands and slides | pans; nothing is grabbed |
| hold, then drag | moves the object |
| hold on an already-selected object | opens the options menu |
| mouse / stylus | unchanged — selects on contact |

500ms is Android's own long press, with a 12px slop so a wobbling finger still
counts as holding. The two-stage rhythm — press to select, press again for
options — exists because both timers otherwise fire on one press and the menu
pre-empted the selection, leaving the user holding neither.

While the text editor is open, a touch on another object does nothing at all: no
selection, no menu. The tap still blurs the editor, so leaving it works as
before.

`touchFeedback` was a declared setting that nothing read; it now drives the
haptic tick when the long press catches.

### Verified live (not merely reasoned about)
Driven through real `PointerEvent`s on the running app, reading the selection
overlay and the menu's `data-state` rather than trusting the code:

| scenario | before | after |
|---|---|---|
| hand rests on typed text | 9 handles | nothing |
| pen lifts between words, hand rests | 9 handles | nothing |
| palm while the nib is down | 9 handles | nothing |
| stylus paused mid-thought | menu opens | no menu |
| hand rests while typing | grabs the object | nothing; editor stays open |
| palm selects, then the nib lands | stays selected | retracted |
| quick accidental tap | selects | nothing |
| hand lands then slides | drags the object | pans |
| deliberate 1st long press | — | selects |
| deliberate 2nd long press | — | options menu |
| mouse click | selects | selects (unchanged) |

Two false readings along the way, both from the Browser pane being hidden:
background timer throttling stretched a 200ms gap past the 800ms window (fixed
with a busy-wait), and paused CSS exit animations left closed menus in the DOM,
so the detector had to check `data-state="open"` rather than presence.

Pinned by **REG-F16** (24 assertions: each pen rule at its boundary, the
pure-touch no-op, contact geometry including the unmeasurable `1x1` case, and
the long-press slop as a radius).

**Gate:** regression suite pass · E2E 259/259 (581 assertions) · challenger
12,289 · tsc 0 · lint 0 · build clean.

---

## STEP 36 — Project moved to Documents\pronotesdevelop and made self-contained

The project lived in `C:\Users\idree\.gemini\antigravity\scratch\knowledge-whiteboard`
— a **scratch** directory belonging to another tool, which is exactly the kind
of place that gets cleaned out. Moved to `C:\Users\idree\Documents\pronotesdevelop`
(2.43 GB, same volume, so an instant rename).

**Locks that blocked the move**, found rather than forced:
- an Explorer window I had opened on `dist-desktop\win-unpacked`;
- two stale `wscript.exe` processes still running `ProNotes.vbs` from earlier
  launches.
Only those were killed. 22 unrelated `node.exe` processes belonging to other
tools were identified by command line and deliberately left alone.

**Made self-contained:** `scripts/generate-icons.js` hard-coded
`...\antigravity\brain\<uuid>\pronotes_icon_...jpg` — a file outside the project
in another scratch tree. The image is now committed at
`assets/pronotes-icon-source.jpg` and the script resolves it with `path.join`
relative to itself, so the icon pipeline no longer depends on anything outside
the folder. Re-ran it: all brand assets regenerate correctly.

**Repointed to the new path:** Desktop, Start-menu and taskbar shortcuts (all
three now target `dist-desktop\win-unpacked\ProNotes.exe` directly), and the
`pronotes` entry in `.claude/launch.json`.

**User data is unaffected.** The app's boards live in the Electron user-data
directory (`%APPDATA%\ProNotes`), not inside the project, so moving the source
does not touch anything drawn.

**Verified from the new location:** `tsc --noEmit` 0 errors, regression suite,
challenger 12,289 assertions, 258/258 E2E, lint clean, production build clean,
and the Desktop shortcut opens the app in 1.3s with the correct window title.

---

## STEP 37 — Type gate that cannot be bypassed, storage hardening, strict-mode note

**Recognition:** `next.config.ts` set `typescript.ignoreBuildErrors: true`, safe only
because the wrappers ran `tsc` first — but a bare `npx next build` bypassed the
check entirely and shipped broken types green. Separately, `node scripts/audit.mjs`
flags direct `localStorage` uses outside `persistence.ts`, several unguarded.

**Change:**
- `scripts/build-static.mjs`: after the preflight type check passes, sets
  `PRONOTES_TYPECHECKED=1` for the child `next build`. The `PRONOTES_SKIP_TYPECHECK=1`
  hatch leaves it unset, so that build still gets Next's own type pass.
- New `scripts/build.mjs` (`npm run build` now calls it): `tsc --noEmit`, then
  `next build` with the marker. A script and not inline `VAR=1 cmd` because inline
  env assignment is not portable to Windows cmd.
- `next.config.ts`: `ignoreBuildErrors: process.env.PRONOTES_TYPECHECKED === "1"`,
  with a comment explaining the mechanism truthfully. `reactStrictMode: false`
  got its missing comment: reason not recorded (present since the squashed
  initial commit `0ce84ec`, no history explains it — checked
  `git log -S reactStrictMode`).
- `src/lib/whiteboard/onedrive.ts`: new guarded `storageGet/Set/Remove` helpers;
  `storeTokens`, `signOut`, the PKCE `sessionStorage` writes/reads in
  `beginSignIn`/`completeSignInIfRedirected` all go through them. A storage throw
  (private mode, quota, disabled storage) now means "sign in again", never a crash.
- `src/components/whiteboard/TutorialModal.tsx`: the first-run `getItem` and the
  dismissal `setItem` are now try/caught — previously a throw on the first-run
  path broke the tutorial effect.
- Left alone (OK, small guarded UI prefs): `SelectToolButton.tsx` last-mode
  get/set (already try/caught), `loadTokens` (already guarded). `HANDOFF.md` §6
  documents the marker mechanism.

**Verification:** probe `src/__probe.ts` (`export const x: number = "a"`) —
(a) `npm run export` green with Next printing `Skipping validation of types`
(no second type pass); (b) bare `npx next build` FAILS with
`./src/__probe.ts:2:14 Type error: Type 'string' is not assignable to type 'number'`;
(c) `npm run export` with the probe stops at
`src/__probe.ts(2,14): error TS2322` + `Type-checking failed - not building`
(exit 2, Next never runs). Probe deleted afterwards.
Gates: `tsc --noEmit` 0 errors, `eslint .` 0 errors, `npm test` all green
(incl. 294/294 E2E). Branch `followups-ignorebuild-localstorage`, unmerged.

---

## STEP 38 — Notebook pages wore the active page's paper

**Recognition:** a grid page showed grid while it sat below the page above, then
"turned blank" the moment you navigated to it. `WhiteboardCanvas` computed one
`paperSource` from the ACTIVE page and painted it on every visible sheet, so
neighbours never wore their own paper — mixed templates in one document (the
Notability complaint this was built to beat) only worked for the live page.
The rail thumbnails never painted paper at all (always white).

**Change:**
- `notebook.ts`: new `paperForPage(board, page)` — the page's own paper falling
  back to the notebook's, with pattern validation and spacing clamp. Every
  renderer goes through it.
- New `PaperPattern.tsx`: `paperColorFor` (preset→theme resolution, was an
  inline IIFE in the canvas) and `PaperTiles` (world-unit ruling tiles, one
  definition for all consumers).
- `WhiteboardCanvas.tsx`: neighbour sheets resolve their OWN paper and get
  their own `<pattern>` def each (`page-paper-<id>`); the shared `#page-paper`
  def now uses `PaperTiles`. Live sheet, snapping and canvas-board paths behave
  exactly as before.
- `NotebookPages.tsx`: `PageThumb` paints the page's paper (bg + ruling, PDF
  pages skip the ruling like the canvas). Paper props are primitives so the
  memo still skips re-renders; the favourites tab computes them per item.
- Tests: 3 new `paperForPage` cases in `notebook.test.ts` (per-page resolution,
  dots/24 fallback, clamp 6–120 + raw colour passthrough).

**Verification:** `tsc --noEmit` 0 errors, `eslint .` 0 errors (262 pre-existing
warnings, none new), `npm test` all green (notebook suite 72 passed incl. the 3
new, challenger 12,289/12,289, 294/294 E2E). Branch `fix/notebook-per-page-paper`,
unmerged.

---

## STEP 39 — Rail Paper submenu never fired on the tablet

**Recognition:** after STEP 38 every sheet showed its own TRUE paper — and they
were all blank. A scratch test driving the REAL store (`createNotebook` →
`setPageBackground` on the non-active page → `goToPage` → `paperForPage` →
save/migrate round trip) passed end to end, so the setting logic was never
broken: the tap never reached it. The Paper picker was a nested Radix submenu
radio (`DropdownMenuSub` → `RadioGroup onValueChange`); the sibling items that
use plain `onSelect` (Duplicate/Delete/Bookmark) work on the tablet, the radio
path swallows taps in the Android WebView. Before STEP 38 this was invisible —
neighbours borrowed the active page's paper, so the grid you saw was never the
page's own.

**Change:** `NotebookPages.tsx` — Paper is now four plain `DropdownMenuItem`s
with `onSelect={() => setPageBackground(page.id, ...)}` and a check mark on the
current ruling. Same options, same store call, the touch-proven event path.
Removed the now-unused submenu/radio imports. (Scratch test deleted after use.)

**Verification:** `tsc --noEmit` 0 errors, `eslint` on touched files clean,
`npm test` all green (294/294 E2E). On-device tap check still owed — needs the
tablet.

---

## STEP 40 — Page menu: set order by number, per-page ruling size, notebook default

**Recognition:** on the tablet the ⋯ menu needed (1) a tap-friendly reorder —
dragging cards by the grip is fiddly and Move up/down means one tap per step;
(2) ruling size per page — spacing lived only in Settings for the whole board;
(3) new pages copied the neighbour's paper instead of the notebook default, so
a fresh sheet in a mixed (or PDF) notebook was unpredictable; (4) ruling never
painted over PDF scans, so Paper on a PDF page saved but showed nothing.

**Change:**
- `notebook.ts`: `addPage` / `addPageBefore` start new sheets with
  `board.background` (the Settings default). Per-page overrides are untouched.
- `NotebookPages.tsx`: Move up/down replaced by **Set order…**, opening a
  number grid (1..N, current highlighted) that calls the existing
  `movePage(page.id, k)`; the panel stays mounted behind the dialog. New
  **Ruling size** section (12/24/40/64 px presets, ✓ on current) writing
  `setPageBackground(page.id, { size })` per page.
- `WhiteboardCanvas.tsx` / `NotebookPages.tsx` thumbs / `export.ts`: a page
  ruling paints OVER its PDF scan (was skipped). Defaults unchanged — PDF
  notebooks are plain, so scans stay clean unless you pick a ruling.
- Tests: inherit-behaviour test rewritten to the default rule; new test for an
  added page in a plain-default notebook taking its own grid + size.

**Verification:** `tsc --noEmit` 0 errors, `eslint .` 0 errors, `npm test` all
green (notebook 73 passed, challenger 12,289/12,289, 294/294 E2E). Branch
`fix/notebook-per-page-paper`, unmerged.

---

## STEP 41 — Settings panel tells the truth (snap, PDF page size, legend)

**Recognition:** debugging the ⚙ panel found four cases where the UI promised
what the code did not do: (1) "Snap-to-grid follows this spacing" while 14 of
16 snap sites used the hardcoded 24px; (2) the Page-size grid is dead on PDF
notebooks (`pageSizeOf` prefers the document size, `setPageSize` never clears
it) yet highlighted A4; (3) board-paper copy predated the notebook-default
rule; (4) the link legend reset every launch while its neighbours persist.

**Change:**
- `WhiteboardCanvas.tsx`: all 16 snap sites pass `paperSize` (plain handlers,
  so no dep churn). The 24px default now only applies where no paper exists.
- `SettingsPanel.tsx`: snap hint reads "paper spacing"; board note explains
  the default + per-page overrides; Page-size grid hidden on PDF notebooks
  with a "uses its PDF's page size" note (dims readout stays, it was right).
- Store + `persistence.ts`: `legendOpen` persisted like `minimapOpen`
  (init/snapshot/migrate); `WhiteboardApp` reads it from the store instead of
  `useState`.
- Tests: legend save→migrate round trip in `notebook_store.test.ts`.

**Verification:** `tsc --noEmit` 0 errors, `eslint .` 0 errors (262 warnings,
none new), `npm test` all green (challenger 12,289/12,289, 294/294 E2E).
Merged via `main` (renumbered from STEP 38 — that number was already taken).

---

## STEP 42 — Paper defaults: app default, per-notebook scope, size slider

**Recognition:** three asks in one: (1) ruling size as presets only — wanted a
drag slider with −/+ like font size; (2) no app-wide paper default (new boards
fell back to dots) and no way to say whether a Settings change hits all pages
or just future ones; (3) split-view target unverified — checked
`focusSplitSide`: tapping a pane makes its board active, so Settings already
edits the last-touched pane; no change needed.

**Change:**
- Store: `defaultPaper` (factory plain, persisted + migrated); `createBoard`
  stamps it on new boards (notebooks inherit it onto page 1); `setDefaultPaper`
  for future notes only; `setBoardBackground` takes `{ allPages }` to rewrite
  every page in the notebook too.
- `SettingsPanel`: "Apply to all pages" toggle (notebooks only, starts off) +
  "App default: …" readout with a "Set as app default" button copying the open
  board's paper. All six paper controls pass the scope through.
- Page ⋯ menu: ruling size is now a slider + hold-to-repeat −/+ (presets
  removed); the menu stays open while adjusting.
- Tests: app-default factory/future-vs-past/scope cases; F10 updated (fresh
  boards now carry the default instead of `undefined` — same no-leak intent).

**Verification:** `tsc --noEmit` 0 errors, `eslint .` 0 errors, `npm test` all
green (challenger 12,289/12,289, 294/294 E2E). Branch `fix/paper-defaults`,
unmerged.

---

## STEP 43 — Favourite pens bar stuck on touch

**Recognition:** the bar would not move and pins would not reorder on the
tablet. The grip and the pins are touch-drag surfaces with pointer capture —
but unlike every other such surface (canvas, minimap, page grip, steppers)
they missed `touch-none`, so a finger drag was hijacked for scroll/pan and
died with a pointercancel. Store reorder/persist code was verified correct.

**Change:** `FavoritePensBar.tsx` — `touch-none select-none` on the bar root
(taps still click; the pin editor lives in a portal so its slider is
unaffected). Also corrected two touch-unaware texts (no pencil icon exists —
editing is right-click / long-press).

**Verification:** `tsc --noEmit` 0 errors, `eslint` on the file clean,
`npm test` all green (294/294 E2E). Drag feel on device still owed — needs the
tablet. Branch `fix/pens-bar-touch`, unmerged. (The whiteboard toolbar needs
no fix: it moves via an edge picker, not a drag.)

---

## STEP 44 — Pin editor on double-tap, move buttons, tap/drag hygiene

**Recognition:** asked: double-click/double-tap a pin opens resize + color +
delete, plus an explicit way to move pins in the list. Timed on pointer-up,
not the `dblclick` event — a mobile WebView with zoom disabled never fires it.

**Change:** `FavoritePensBar.tsx` — two pointer-ups within 350ms open the
editor (first tap still selects the pen, like every toolbar); the editor gains
Earlier/Later buttons (disabled at the ends) over the tested
`reorderPinnedPens`. Sweep fixes in the same code: tap-then-drag-then-tap no
longer phantom-opens the editor (tap history resets on drag start, cancelled
presses are forgotten), and a grip tap without movement no longer rewrites
storage.

**Verification:** `tsc --noEmit` 0 errors, `eslint` on the file clean,
`npm test` all green (294/294 E2E). Double-tap feel owed — needs the tablet.
Merged via `main` (renumbered from STEP 42/43 — those numbers were taken).

---

## STEP 45 — Hold a page card to drag-reorder it

**Recognition:** reordering needed the small grip handle (press-and-drag from
it) — hard to discover and fiddly on a tablet. Asked: press-and-hold anywhere
on the card, then drag it where it belongs.

**Change:** `NotebookPages.tsx` — holding a card still for 350ms picks it up
(short vibrate, pointer capture so the finger drags instead of scrolling, a
suppressed tap on release) and reuses the existing drop machinery (DropLine,
`movePage`). Moving before the hold fires cancels it, so the panel still
scrolls from the card. Grip and ⋯ keep their own gestures.

**Verification:** `tsc --noEmit` 0 errors, `eslint` on the file clean,
`npm test` all green (294/294 E2E). On-device feel check owed — needs the
tablet. Merged via `main` (renumbered from STEP 42 — that number was taken).

---

## STEP 46 — Panel auto-scrolls while dragging; undo survives restarts

**Recognition:** two reports: (1) grip-dragging a page to the panel's top edge
just dies there — the list never scrolls, so far positions are unreachable;
(2) closing the app wiped all undo/redo history, and the in-session cap was 50.

**Change:**
- `NotebookPages.tsx`: dragging within 64px of the panel's top/bottom edge
  scrolls it (24px per move event) — shared by grip and hold drags. Hold tuned
  for shaky hands: 350ms → 300ms, 12px → 24px slop before a scroll cancels it.
- Undo history persists per notebook across restarts (last 100 undo + 100 redo
  steps, newest kept): new `z-whiteboard-history-v1` key with oldest-first
  shrinking under a 1.5MB budget, so it can never threaten the workspace save;
  corrupt entries rejected at load, deleted boards pruned. Restored oldest
  first on `init`, flushed on unload. Challenger 50-cap test updated to 100.
- Tests: new `history.test.ts` (7 tests: order, caps, byte budget, corruption,
  pruning, flush, missing key) wired into `test-runner.mjs`.

**Verification:** `tsc --noEmit` 0 errors, `eslint .` 0 errors, `npm test` all
green (challenger 12,289/12,289, 294/294 E2E). Branch
`fix/drag-tune-and-undo`, unmerged.

---

## STEP 47 — Zoom pill detaches when the dock is on top, hideable in Settings

**Recognition:** with the toolbar docked on top, the zoom pill (out / % / in /
fit) hung right under it over the canvas — the clutter circled on the tablet.
And the floating pens bar could park over the zoom controls, swallowing taps.

**Change:**
- `Toolbar.tsx`: zoom controls extracted to `ZoomDock`; in the row everywhere
  except dock-on-top, where it detaches to bottom-center instead. Both spots
  carry `data-wb-toolbar`.
- Store + `persistence.ts`: `zoomDockOpen` persisted like the minimap;
  Settings > Canvas gains a Zoom controls toggle.
- `FavoritePensBar.tsx`: the bar clamp treats every toolbar rect as an
  exclusion zone (push out, pane wins ties), re-evaluated on dock moves.
- Tests: zoom visibility persist round trip.

**Verification:** `tsc --noEmit` 0 errors, `eslint .` 0 errors, `npm test` all
green (challenger 12,289/12,289, 294/294 E2E). Branch `fix/zoom-dock`,
unmerged.

---

## STEP 48 — Halve the dead space between sheets (40 → 20)

**Recognition:** the grey bands between notebook sheets ate too much screen.
`PAGE_GAP` feeds every stride/hit-test, so one constant change propagates;
the gap "+" button is screen-scaled, so it still fits and works.

**Verification:** `tsc --noEmit` 0 errors, `npm test` all green (294/294 E2E).
Branch `fix/page-gap`, unmerged.

---

## STEP 49 — Notebook fit means fit-width (was: fit-ink-bounds)

**Recognition:** the fit button fit the active page's INK bounds, so a sparse
page landed at a random tiny zoom (seen at 44%) with the desk huge on all
sides. The sheet is the stable frame a notebook reader wants.

**Change:** `zoomToFit` on a notebook fits the sheet width (24px margins,
clamped, anchored on the active page). Canvas boards keep fitting their
content. Test: sheet-width fit with centered camera.

**Verification:** `tsc --noEmit` 0 errors, `eslint .` 0 errors, `npm test` all
green (294/294 E2E). Branch `fix/fit-width`, unmerged.

---

## STEP 50 — Sidebar drag & drop: file anything anywhere by holding

**Recognition:** the store could move boards/folders for ages (`moveBoard` /
`moveFolder`, cycle-safe) but nothing called them — the imports sat dead in
`Sidebar.tsx` and there was no gesture at all. Asked: drag any type onto any
folder, like the reference.

**Change:** `Sidebar.tsx` — hold any row 300ms (tap still opens/toggles,
moving first still scrolls), then drop onto a folder (green ring), a board's
row (files into its folder), or empty tree space (top level). Holding over a
collapsed folder springs it open; the tree auto-scrolls at the edges; dropping
a folder into itself/subtree highlights nothing and the store rejects it.
`moveBoard` got the same ghost/exists guards `moveFolder` had.
Tests: board↔folder↔root moves, cycle/self/ghost rejection.

**Verification:** `tsc --noEmit` 0 errors, `eslint` on touched files clean
(2 pre-existing warnings left), `npm test` all green (294/294 E2E). Drag feel
owed — needs the tablet. Branch `fix/sidebar-drag-drop`, unmerged.

---

## STEP 51 — Hold-drag survived Radix's own long-press menu

**Recognition:** holding a row opened star/rename/duplicate/export on top of
the drag instead of picking the row up: Radix fires its context menu on a
~700ms long-press, after our 300ms pickup, and the row name got text-selected
too. The trigger `disabled` prop arrived a render late and could not win.

**Change:** `Sidebar.tsx` — a window-level CAPTURE `contextmenu` listener
kills the event while a drag is active (ref, not state: zero render delay),
plus `select-none` on both row roots. Trigger `disabled` props stay as backup.

**Verification:** `tsc --noEmit` 0 errors, `eslint` on the file clean,
`npm test` all green (294/294 E2E). Device check owed — needs the tablet.
Branch `fix/sidebar-drag-drop`, unmerged.

---

## STEP 52 — Stuck drags, invisible ⋯ buttons, Move-to dialog, double-tap menus

**Recognition:** three reports in one: (1) a drag that outlives the app's
attention (home/power/alert) stuck forever — no pointerup ever arrives, the
menu killer stays armed, every menu stops opening; (2) the ⋯ buttons are
`opacity-0` until hover, which touchscreens never do — the menu was
unreachable on the tablet; (3) asked: a "Move to…" browser (drill into nested
folders, search, apply at any level) plus the FULL option list on double-tap.

**Change:** `Sidebar.tsx` — window blur cancels drags; ⋯ triggers visible on
coarse pointers; double-tap (350ms, pen and finger) opens the row's
DropdownMenu; new `MoveToDialog.tsx` (breadcrumb drill-down, search with
trails, contained counts, invalid destinations disabled with reasons, footer
shows the live destination) wired into both ⋯ menus and both context menus.

**Verification:** `tsc --noEmit` 0 errors, `eslint` on touched files clean
(1 pre-existing warning), `npm test` all green (294/294 E2E). Device check
owed — needs the tablet. Branch `fix/sidebar-move-dialog`, unmerged.

---

## STEP 53 — Double-tap zoom no longer eats the app

**Recognition:** double-tapping a sidebar row (the new menu gesture) zoomed
the whole WebView instead — content slid half off screen with names cut at
the edge. The viewport `maximum-scale=1, user-scalable=no` lock IS emitted
(verified in the built `out/index.html`) but the Android WebView does not
honor it, so the lock never engaged.

**Change:** `globals.css` — `touch-action: manipulation` on `html` kills
double-tap zoom at the gesture level; pan and pinch keep working wherever the
app allows them. Canvas (`touch-none`) and all drag surfaces unaffected.

**Verification:** `tsc --noEmit` 0 errors, `eslint .` 0 errors, `npm test` all
green (294/294 E2E). Reinstall resets any currently-zoomed view. Branch
`fix/sidebar-move-dialog`, unmerged.

---

## STEP 54 — Page zoom locked out: pan-only at the browser level

**Recognition:** the cut-off sidebar persisted after killing double-tap zoom —
video frames show the whole app ~1.5x with names cut at the edge. The culprit
is pinch-zooming the PAGE itself (not the canvas): `manipulation` still allows
it, and the WebView ignores the viewport lock. The canvas never needed it —
it zooms through its own code behind `touch-none`.

**Change:** `globals.css` — `html { touch-action: pan-x pan-y }`: scroll
only, no page zoom of any kind. Reinstall resets any currently-zoomed view.

**Verification:** `tsc --noEmit` 0 errors, `eslint .` 0 errors, `npm test` all
green (294/294 E2E). Branch `fix/sidebar-move-dialog`, unmerged.

---

## STEP 55 — Sidebar names cut off: the real cause was flex truncation

**Recognition:** the previous photo was misread as browser zoom (fixed
harmlessly anyway). The new report — names cut at the LEFT with ⋯ visible on
the right after opening another file — is classic flex overflow: both row
name spans were `flex-1 truncate` WITHOUT `min-w-0`, so a long unbreakable
name (`scan_method_hebrew_rtl_fixed`) refused to shrink, forced its row wider
than the 256px sidebar, and the tree panned sideways.

**Change:** `Sidebar.tsx` — `min-w-0` on both name spans, `shrink-0` on the
element-count span, and `overflow-x-clip` (not hidden: hidden would fork
vertical scrolling) on the tree so a row can never pan sideways again.

**Verification:** `tsc --noEmit` 0 errors, `eslint .` 0 errors, `npm test` all
green (294/294 E2E). Branch `fix/sidebar-move-dialog`, unmerged.

---

## STEP 56 — The page itself can never pan sideways

**Recognition:** names still cut at the left on device after the row-level
fix. A row can no longer overflow — but any floating element wider than the
viewport (toolbar row, dialog, menu) still lets the whole PAGE pan, which
looks identical and no in-app scroller can undo.

**Change:** `globals.css` — `html, body { overflow: hidden;
overscroll-behavior: none }`. The app is a fixed h-screen layout; every list
already scrolls inside its own container, so nothing legitimate loses
scrolling.

**Verification:** `tsc --noEmit` 0 errors, `eslint .` 0 errors, `npm test` all
green (294/294 E2E). Branch `fix/sidebar-move-dialog`, unmerged.

---

## Three select shapes — fixing the Samsung "Encircle" pass

The ask: keep the two select shapes there are, add a third that behaves like
**Samsung Notes' rope** — draw a full closed loop and take only what is
completely inside — and let all three be chosen from Settings or by cycling
with a long press.

The groundwork for that was already in the working tree (store flag, geometry,
Settings row, long-press cycle). Three things in it were wrong.

### 1. Encircle could not select handwriting at all ✅
`isElementFullyInPolygon` demanded that **every** point from
`sampleElementPoints` be inside the loop — and that set includes the element's
**bounding-box corners**. A stroke's bounding box is a rectangle drawn around a
curve, so for anything diagonal the corners sit in empty space well off the ink.
Requiring those inside meant the one gesture the mode exists for — snaking a
loop between two lines of writing to lift a single word — **always failed**,
because the corners of that word's box are up in the line above.

Measured, before the fix: a loop hugging a diagonal stroke gave
`loose: true, strict: false`.

Containment now asks where an element actually *is*, via a new
`outlineElementPoints`:

| element | tested points |
|---|---|
| stroke | the ink itself, sampled along the path |
| line / arrow | its two ends — the box around a diagonal is mostly air |
| rect, ellipse, text, sticky, image | the box corners; the box IS the extent |

Loose lasso is untouched (any point inside, still greedy by design).

### 2. A duplicate Lasso button that also broke the mode ✅
A standalone "Freeform lasso" button had been added to the toolbar beside
`SelectToolButton` — which already carries all three shapes. Besides being the
duplicate icon this toolbar has been cleaned of twice, it called
`setTool("lasso")` **without setting strictness**, so pressing the button
labelled "Freeform Lasso" handed you Encircle whenever that was the last loop
mode used. Removed; the three shapes live in one place.

Its comment claimed the lasso "was unreachable on the tablet" — the same change
set had already fixed that with the long-press cycle.

### 3. Tooltip pinned to the wrong side ✅
The Select button's tooltip was hardcoded `side="top"`, dropping the
dock-position-aware `flyoutSide()` the rest of the toolbar uses; it would sit
over the dock when the dock is on top. Restored.

### Verified on the running app
Two lines of handwriting drawn **by the app's own pen** (injected elements skip
the element pipeline and proved nothing), then loops driven as real
`PointerEvent`s, one move per frame — firing a whole loop in one task leaves
every handler reading the same stale `interaction`, so the polygon never grows
past two points and *nothing* selects. That cost a round of false negatives.

| gesture | Freeform (loose) | Encircle (strict) |
|---|---|---|
| closed loop around the lower line | lower + everything grazed | **lower only** |
| loop covering half that line | takes it | **nothing** |
| open squiggle across it | takes it | **nothing** |

Long-press on the Select button cycles Rectangle → Freeform → Encircle →
Rectangle with the label following; Settings > Touch & stylus > "Select shape"
drives the same three and the toolbar button reflects the choice; `lassoStrict`
survives a reload.

Pinned by `tests/select_modes.test.ts` (13 tests, including the hugging loop,
one line of writing lifted from between its neighbours, and the half-covered
word loose takes but strict refuses).

**Verification:** `tsc --noEmit` 0 errors · `eslint` 0 errors and no new
warnings (identical per-file counts before/after) · `npm test` 315/315 E2E,
1077 assertions · `npm run build` clean.

### Follow-up: the lasso is a pen now, and Encircle is gone

Two complaints, both correct:

**"Freeform and Encircle are the same action."** They were. Drawing a loop that
takes only what it fully contains is the same gesture as drawing a loop that
takes whatever it touches — the difference is a rule, not a shape. Samsung
Notes has exactly this and does not make it a second tool: one Lasso, one
Rectangle, and a switch, *"Include partially selected objects"*. Ours now
matches — two shapes, and that switch in both the Select menu and Settings.
`lassoStrict` survives as the stored flag (off = include partial, Samsung's
default); saves that remembered "encircle" as the shape land on Lasso.

**"It starts from a point and that point is the centre."** Real, and visible in
one line of the render: the preview was a `<polygon>`, and SVG closes a polygon
for you. Mid-stroke that painted a **filled wedge hinged on wherever the stroke
started** — so the enclosed area appeared to fan out from the start point
instead of following the nib. Worse, the live selection was computed against
that same half-drawn wedge, so elements flicked in and out as the closing chord
swept over them.

- The preview is a `<polyline>` with `fill="none"` — literally the line drawn,
  which is all Samsung shows (confirmed against the app: an open dashed trail,
  no fill, no chord home, even on the last frame before the lift).
- Selection is decided **on lift**, when the loop closes back to its first
  point and there is actually a region to test against. A tap or flick
  (< 3 points) selects nothing.
- `isLoopClosed` is deleted along with its three tests. It gated strict mode on
  the user closing the loop themselves; Samsung closes it for you on lift, so
  the gate was a requirement we invented.

Verified on the running app: mid-drag the DOM holds a `polyline` with
`fill="none"` and zero filled polygons, and the screenshot shows the open
dashed arc. The same circle over two stickies selects both with the switch on
and nothing with it off. Long-press cycles Rectangle ↔ Lasso.

**Verification:** `tsc --noEmit` 0 errors · `eslint` 0 errors · `npm test`
315/315 E2E (1077 assertions) + 10 select-mode tests · `npm run build` clean.

### Dock layout: page controls beside the tools, a fold chevron, a fading zoom readout

**Page controls moved into the dock.** They were a floating bar pinned to the
bottom-left corner, which drifted into the tool dock on a narrow pane — so they
carried a `ResizeObserver` that measured both and *lifted* the bar out of the
way. Living in the dock's own row they cannot collide: flexbox puts them
alongside. The observer and the lift are gone.

- **No "add page" here.** Adding is occasional and deliberate and belongs with
  the rest of page management in the panel; what you want constantly at the
  edge of the canvas is to know where you are and jump.
- **The number is the jump.** Tapping `5 / 12` turns it into a field: type a
  number, Enter. Out of range clamps rather than complains — "999" in a
  12-page notebook plainly means the end.

`NotebookPageBar` split into `NotebookPagePanelHost` (mounts the panel, still
rendered by WhiteboardApp) and `NotebookPageControls` (the dock strip).

**A fold chevron, pinned outside the scroller.** The tool row scrolls
horizontally when the tools overflow. The chevron that folds the active tool's
colour/thickness row sits *outside* that scrolling pill on purpose: a control
that scrolls off the end is a control you cannot reach exactly when the bar is
crowded enough to need it. Verified — scrolling the row moved the Pan button
106px while the chevron stayed at the same x. The arrow flips (▼ hide, ▲ show)
and the state is saved as `toolPropsBarCollapsed`.

Getting it pinned took two goes: as a plain child of the wrapping dock row it
simply wrapped onto a line of its own. It now shares a `min-w-0` group with the
pill, so the pill shrinks and scrolls while the chevron keeps its place.

**Zoom readout: top-left, small, and only while zooming.** It used to ride
inside the tool row, costing ~150px the row could not spare, and needed a
special case that detached it to the bottom whenever the dock sat on top. Now
it owns a corner in every dock position, at about half the size, and fades in
while the zoom is changing — the percentage matters while you are pinching and
never again. It stays up while the pointer is on it so the buttons remain
usable, and is `pointer-events-none` when hidden: an invisible pill eating
clicks in the corner of the canvas would be worse than the space it saved.

**Bug found while building it:** the fade never appeared, because this build
generates no `.opacity-100` rule — the class flipped correctly and did nothing.
Opacity is an inline style now, which needs nothing generated and wins outright.

Two false readings came from the preview pane not painting: CSS transitions do
not advance without frames, so `getComputedStyle` kept reporting the old
opacity, and a `querySelector('.overflow-x-auto')` picked the properties bar,
which carries that class too, instead of the tool row.

**Verification:** `tsc --noEmit` 0 errors · `eslint` 0 errors · `npm test`
315/315, 1077 assertions — identical per-tier counts to the pre-change baseline,
checked tier by tier after a misread total suggested three had gone missing.
