# Accounts & Sync — Setup (free, ~5 minutes)

Gives ProNotes **self-service sign-up**: anyone opens the app, creates their own
account with an email and password, and gets their own private boards synced
across every device. Nobody has to be added by hand.

**Cost: nothing.** Supabase's free tier covers this comfortably.

I cannot create the project for you — it needs your own login. Everything in the
app is already built and waits for two values.

---

## Step 1 — Create the project

1. Go to <https://supabase.com> → **Start your project** → sign in (GitHub or email).
2. **New project**. Name it `pronotes`. Pick any region near you.
3. Set a database password and keep it somewhere — you will not need it for the
   app, only for direct database access.
4. Wait ~2 minutes while it provisions.

---

## Step 2 — Create the table

Open **SQL Editor** in the left menu, paste this, and press **Run**:

```sql
-- One workspace document per account.
create table if not exists public.workspaces (
  user_id    uuid primary key references auth.users(id) on delete cascade,
  doc        jsonb not null,
  updated_at timestamptz not null default now()
);

-- Row-level security is what makes accounts private. Without it, ANY signed-in
-- user could read every other user's boards with the public anon key.
alter table public.workspaces enable row level security;

create policy "own workspace: read"
  on public.workspaces for select
  using (auth.uid() = user_id);

create policy "own workspace: insert"
  on public.workspaces for insert
  with check (auth.uid() = user_id);

create policy "own workspace: update"
  on public.workspaces for update
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);
```

> The three policies are the security boundary. The anon key shipped in the app
> is *meant* to be public — it only grants what these policies allow.

---

## Step 3 — Copy the two values

**Project Settings → API**:

| Copy this | Into |
|---|---|
| **Project URL** (`https://xxxx.supabase.co`) | `NEXT_PUBLIC_SUPABASE_URL` |
| **anon / public** key | `NEXT_PUBLIC_SUPABASE_ANON_KEY` |

Never use the `service_role` key here — it bypasses row-level security, and in a
browser app it would be readable by anyone.

Create `.env.local` in the project root:

```
NEXT_PUBLIC_SUPABASE_URL=https://xxxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOi...
```

Then rebuild:

```bash
npm run build
```

For the Android app, rebuild the APK so the values are baked in:

```bash
npm run apk
```

---

## Step 4 — Email confirmation (choose one)

**Authentication → Providers → Email** in Supabase.

- **Confirmation ON** (default, safer): new users get a link to click before they
  can sign in. Supabase's built-in mailer is rate-limited to a few messages an
  hour — fine for you and a handful of people.
- **Confirmation OFF**: sign-up works instantly. Easier for personal use.

The app handles both: if confirmation is required it tells the user to check
their inbox instead of pretending sign-in failed.

---

## Using it

1. Open **Sync & Backup** (cloud icon, top right) → **Create account**.
2. Enter email + password (min 6 characters), confirm it, create.
3. **Sync now** uploads your boards.
4. On the tablet: install the APK, same panel, **sign in** with that email,
   **Sync now**.

Boards merge **one at a time**, newest edit wins — editing different boards on
different devices never loses anything.

---

## Troubleshooting

| Symptom | Cause |
|---|---|
| "Accounts are not set up in this build" | `.env.local` missing or not rebuilt. The values are read at **build** time. |
| "That email already has an account" | Use **Sign in**, or **Forgot your password?** |
| "Check your inbox and click the confirmation link first" | Email confirmation is on (Step 4). |
| Sync says permission denied | The SQL in Step 2 was not run, or the policies were not created. |
| Free project paused | Supabase pauses a free project after ~1 week with no traffic. Open the dashboard and click **Restore**. Regular use prevents it. |
