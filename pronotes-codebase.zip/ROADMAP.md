# ProNotes — Competitive Research & Roadmap

Research date: 2026-09-09. Sources are listed at the bottom.

This is the "what should we build and why" document. For how the project
works today, read [HANDOFF.md](HANDOFF.md).

---

## 1. The single biggest opening: people are furious about subscriptions

This came up in every source, and it is not a small grumble.

- **GoodNotes 6** moved from one-time purchase to subscription. Long-time users
  lost features they had already paid for, were forced to log in, and some lost
  data during the upgrade. Ratings dropped.
- **Notability** locked away features previously given to paying users.
  Reviewers called it *theft*.
- **Notewise** cuts you off after **10 notes** unless you pay.
- **OneNote** puts real features behind Microsoft 365.
- **Notion** cannot create pages or edit databases offline at all.

ProNotes is already free, offline, local-first, and requires no account. That
is not a missing feature — **it is the product's strongest position**, and it
should be stated loudly rather than left implicit.

A second, funnier data point: GoodNotes 6 users are angry that the upgrade
**removed the favourites toolbar**. ProNotes already has a favourite pens bar
with pinning, reordering and a movable dock.

---

## 2. Tools the leaders ship that ProNotes does not

Notewise's toolbox is the most complete of the group: pen, highlighter, eraser,
lasso, tape, shape, textbox, image, audio recorder, table, zoom box, ruler,
laser pointer, sticky notes, creative brushes, stickers.

Measured against that, here is the honest gap.

| Tool | Who has it | ProNotes | Why it matters |
|---|---|---|---|
| **Zoom box** | GoodNotes, Notewise | ✗ | Write large at the bottom, it lands small on the page. The #1 thing Samsung Notes users demand. Essential on a tablet. |
| **Audio recording synced to notes** | Notability, AfterNote, Notewise | ✗ | Notability's signature feature. Tap a word, hear what was said as you wrote it. Made for lectures. |
| **Handwriting search / OCR** | GoodNotes, OneNote, Notewise | ✗ | Search your own handwriting. OneNote is praised for it; GoodNotes is criticised for being worse at it. |
| **Handwriting → text** | GoodNotes, Notewise | ✗ | Convert a scrawled page into typed text. |
| **Shape recognition** | GoodNotes, Notewise | ✗ | Draw a rough circle, get a clean one. ProNotes has shape *tools* but no recognition. |
| **Ruler / straightedge** | GoodNotes, Notewise | ✗ | Straight lines and diagrams by hand. |
| **Tables** | Notewise | ✗ | |
| **Laser pointer** | Notewise | ✗ | Presenting from the canvas. |
| **Page templates** | all of them | partial | ProNotes has dots/grid/lines/plain with adjustable size. Notability is *criticised* for having only 3 and for not allowing mixed templates in one document — an easy bar to clear. |
| **Tape / stickers** | Notewise | ✗ | Low priority, but cheap and users like them. |

ProNotes already has, and the others mostly do not: **an infinite canvas with a
knowledge graph, `[[WikiLinks]]`, backlinks, typed links, and a pixel eraser
with true stroke splitting.**

---

## 3. What users complain about — each one is a design rule for us

| Complaint | Aimed at | Rule for ProNotes |
|---|---|---|
| Subscription / paywalled features | GoodNotes, Notability, Notewise, OneNote | Stay free and offline. Never gate an existing feature. |
| Forced login | GoodNotes 6 | Accounts stay **optional**. The app must be fully usable with no account, forever. |
| Data loss on upgrade | GoodNotes 6 | Migrations must be defensive and reversible. `persistence.ts` already hardens this — keep it that way, and back up before migrating. |
| Lasso / erase / duplicate bugs after a UI update | GoodNotes (2026) | Do not ship UI changes without regression tests over the editing tools. |
| No tabs — must exit to the menu to switch notes | Notability | Add **tabs** for open notes. *(Not built yet. Split view covers two documents at once; the Pages / ★ tabs in the page rail are not document tabs.)* |
| Can't mix paper templates in one document | Notability | Make the paper template **per page**, not only per board. *(Shipped — per-page paper in the page rail.)* |
| Weak organisation / no notebooks | Notability | The tree already does folders; keep strengthening it. |
| Fixed-size pages, no infinite canvas | GoodNotes | Already our advantage. Do not lose it when adding pages. |
| Mobile is a slow web wrapper | Notion | Keep the APK a real local app. Never require the network. |
| Needs a plugin for everything | Obsidian | Ship the useful things built in. |
| Overwhelming / overloaded UI | OneNote, Notion | Progressive disclosure: common controls one tap away, the rest behind ⚙. Already the pattern in `ToolProperties.tsx`. |

---

## 4. Recommended order

Ordered by *value per unit of work*, given a student who writes maths, reads
course PDFs, and works in Hebrew and English.

### Phase 1 — Notes (the actual request)
A page-based document type living beside the canvas. Blocks, markdown
shortcuts, `/` menu, checkboxes, tables, code, callouts, outline panel.

**Architecture:** generalise `Board` into `Doc { kind: "canvas" | "note" }`
rather than adding a parallel list — one tree, one graph, one search, one
sync, one backup, and links work between notes and canvases for free.

### Phase 2 — The tablet tool gap
**Zoom box**, **ruler**, **shape recognition**, **tabs**, **per-page paper
templates**. These are the cheapest wins that close the distance to GoodNotes,
and every one of them answers a documented complaint.

> Status 2026-09-19: **per-page paper shipped.** Zoom box, ruler, shape
> recognition and document tabs are **not started** (checked against the code,
> not assumed).

### Phase 3 — PDF import + annotation
Ink on PDF pages, **page-thumbnail sidebar**, **bookmarks**, link pages into
the graph. The thumbnail sidebar and bookmarks are the two loudest Samsung
Notes requests.

> Status 2026-09-19: **shipped** — PDF import as a notebook you write on, the
> thumbnail rail, bookmarks (★ tab), a template library, and export of every
> page with the PDF underneath the ink. **Not yet:** linking individual pages
> into the knowledge graph.

### Phase 4 — Maths, RTL, and study
KaTeX inline `$…$` and block `$$…$$`, vendored **offline** (never a CDN),
automatic per-paragraph RTL so Hebrew and English mix correctly, then
flashcards with SM-2 spaced repetition.

> Status 2026-09-25: **per-line RTL shipped** — `dir="auto"` per block plus
> explicit per-line RTL/LTR/Auto overrides (`lineDirs`, editor buttons,
> honoured by SVG/PNG/PDF export). KaTeX, flashcards still open.

### Phase 5 — Handwriting intelligence
Handwriting OCR and search, then handwriting → text.

### Phase 6 — Product polish
Command palette (Ctrl+K), global search across text *and* ink, tags,
templates, daily notes, onboarding.

### Phase 7 — Audio (last, by request)
Lecture recording synced to strokes — Notability's signature feature: tap a
word, hear what was being said as you wrote it. Deliberately last: it is the
heaviest to build (recording, storage, playback, stroke-to-timestamp mapping)
and the least useful until the notes it attaches to exist.

---

## 5. The quality bar

Being "the best of all of them" is mostly refusing to do what they did:

1. **Free and offline forever.** No feature ever moves behind a paywall.
2. **No account required.** Sync is opt-in, and the app is complete without it.
3. **Never lose data.** Every migration defensive; back up before touching
   stored state.
4. **Fast.** No feature may make the canvas stutter. Measure, don't guess.
5. **Not overwhelming.** Common controls visible, everything else one level
   deep.
6. **Regression-tested.** The suites exist; every tool change gets one.

---

## Sources

- Notion: [offline access requests](https://fibery.io/openion/notion-2/request-for-offline-access-capability-in-notion-244985) · [mobile lag & sync](https://fibery.io/openion/notion-notes-docs-tasks-2/mobile-app-performance-concerns-lag-sync-issues-and-slow-load-times-244843) · [why the mobile app is still bad](https://techresolve.blog/2026/03/09/why-is-notions-mobile-app-still-so-bad-in-2026/)
- Obsidian: [review — missing collaboration, sync, mobile](https://aisotools.com/blog/obsidian-review-2026) · [too complicated](https://productivematters.substack.com/p/obsidian-is-too-complicated)
- GoodNotes: [customer feedback analysis](https://kimola.com/reports/unlock-insights-goodnotes-6-customer-feedback-analysis-app-store-us-148345) · [backlash over the UI update](https://techissuestoday.com/goodnotes-faces-backlash-as-users-demand-the-goodnotes-6-ui-back/) · [limitations](https://eathealthy365.com/the-top-7-limitations-of-the-goodnotes-app-in-2026/)
- Notability: [Capterra reviews](https://www.capterra.com/p/229356/Notability/reviews/) · [vs GoodNotes](https://paperlike.com/blogs/paperlikers-insights/app-review-goodnotes-vs-notability)
- Notewise: [Google Play listing](https://play.google.com/store/apps/details?id=com.yygg.note.app&hl=en) · [review](https://updf.com/annotate-pdf/notewise/) · [Techjockey reviews](https://www.techjockey.com/reviews/notewise)
- Samsung Notes: [missing features thread](https://r2.community.samsung.com/t5/Galaxy-Store-Apps-more/Features-missing-in-Samsung-Notes-app/m-p/13469677/highlight/true)
- Students / STEM: [RemNote LaTeX + flashcards](https://www.remnote.com/feature/math-latex) · [Notion vs OneNote vs Obsidian](https://computeracademichelp.com/notion-vs-onenote-vs-obsidian/) · [best notetaking apps for students](https://www.drawboard.com/blog/best-notetaking-apps-students)
