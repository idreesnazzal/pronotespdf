/**
 * Static export into ./out, shared by BOTH packaged apps: Capacitor copies it
 * into the APK, and Electron serves it through the `pronotes://` scheme. Sets
 * PRONOTES_STATIC so next.config.ts switches to `output: "export"`. It is not
 * always on only because `npm run build` / `npm start` - the plain web server -
 * need the normal server build.
 *
 * Why the retry loop
 * ------------------
 * On Windows `next build` intermittently dies on a file it has just written,
 * with a DIFFERENT error each run:
 *
 *   Cannot find module for page: /_document
 *   ENOENT  ... .next\server\pages-manifest.json
 *   ENOENT  ... rename .next\export\500.html -> .next\server\pages\500.html
 *   EBUSY   ... rmdir ...\out
 *
 * The files are present immediately afterwards, and the same commit builds
 * fine on a retry, so nothing is genuinely missing. It is a file-handle race
 * on .next / out. Two things make it much worse and are checked for below:
 * a `next dev` server running against this project (it writes the same .next),
 * and an orphaned `next build` left over from a previous failed run.
 *
 * Only that signature is retried. A real compile or type error fails on the
 * first attempt, because retrying it would just bury the message.
 */
import { spawnSync, execSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";

const ATTEMPTS = 3;
const root = process.cwd();
// The build directory. Builds own `.next`; `npm run dev` now builds into
// `.next-dev` (see next.config.ts), so clearing this can no longer take a
// running dev server down with it.
//
// An earlier version of this script believed the export built into
// `.next-static`. Nothing ever set that, so it cleared a folder that did not
// exist while every export silently shared `.next` with the dev server.
const nextDir = path.join(root, ".next");
const outDir = path.join(root, "out");

/**
 * Transient Windows file-handle failure, as opposed to a real build error.
 * NOTE: the paths in these messages use BACKslashes. An earlier version of
 * this check used [\/] and therefore never matched a single real failure.
 */
function isHandleRace(output) {
  const errno = /(ENOENT|EBUSY|EPERM|EACCES|MODULE_NOT_FOUND|Cannot find module|PageNotFoundError)/.test(output);
  const ourPaths = /(\.next|[\/]out\b|for page: \/_document)/.test(output);
  return errno && ourPaths;
}

/** rmSync with backoff — the handle is usually released within a second. */
function removeWithRetries(dir) {
  try {
    fs.rmSync(dir, { recursive: true, force: true, maxRetries: 10, retryDelay: 300 });
  } catch {
    /* Next will try again itself; a still-locked dir shows up as a retry. */
  }
}

/** A dev server or a stale build fights us over .next. Say so, don't guess. */
function warnAboutCompetingProcesses() {
  if (process.platform !== "win32") return;
  try {
    const ps =
      `Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'node.exe' -and ` +
      `$_.CommandLine -match 'next.dist.bin.next' -and $_.CommandLine -match [regex]::Escape('${root}') } | ` +
      `ForEach-Object { "$($_.ProcessId) $($_.CommandLine)" }`;
    const found = execSync(`powershell -NoProfile -Command "${ps.replace(/"/g, '\\"')}"`, {
      encoding: "utf8",
      stdio: ["ignore", "pipe", "ignore"],
    }).trim();
    if (!found) return;
    const lines = found.split("\n").map((l) => l.trim()).filter(Boolean);
    const mine = String(process.pid);
    const others = lines.filter((l) => !l.startsWith(mine));
    if (!others.length) return;
    console.warn(
      `\n[build-static] Another Next process is using this project's .next:\n` +
        others.map((l) => `    ${l.slice(0, 120)}`).join("\n") +
        `\n  A running \`npm run dev\` writes the same .next as the build and is the\n` +
        `  usual cause of these failures. Stop it, or kill the pid above, then retry.\n`
    );
  } catch {
    /* Diagnostics only. */
  }
}

// ---------------------------------------------------------------------------
// Preflight, shared by EVERY packaged build (APK, Windows installer, desktop).
// ---------------------------------------------------------------------------
// Doing these here rather than in package.json is deliberate: the scripts had
// drifted - `desktop` skipped the worker sync while `dist:win` did it, and
// nothing type-checked at all - so one path could ship a stale pdf.js worker
// (a version-mismatch error on every PDF) or broken types. Every export goes
// through this file, so every export gets both.
function preflight(label, command) {
  console.log(`[build-static] ${label} ...`);
  const r = spawnSync(command, { cwd: root, stdio: "inherit", shell: true });
  if (r.status !== 0) {
    console.error(`\n[build-static] ${label} failed - not building.`);
    process.exit(r.status ?? 1);
  }
}
preflight("Syncing the pdf.js worker", "node scripts/sync-pdf-worker.mjs");
if (process.env.PRONOTES_SKIP_TYPECHECK === "1") {
  console.warn("[build-static] PRONOTES_SKIP_TYPECHECK=1 - shipping WITHOUT a type check.");
} else {
  preflight("Type-checking", "npx tsc --noEmit");
  // The check just passed in THIS process, so the child `next build` below may
  // skip Next's own type pass (see next.config.ts). A bare `npx next build`
  // never sets this, so it still gets full type errors.
  process.env.PRONOTES_TYPECHECKED = "1";
}

// The export ALWAYS starts from a clean build directory.
//
// A dev server leaves unminified fallback chunks in its .next/static, and the
// export copies static/ into out/ wholesale. That silently added 16 MB of
// development bundles to the APK (6.2 MB -> 10.5 MB) with no warning.
//
// Clearing `.next` is safe now that the dev server lives in `.next-dev`. When
// they shared `.next`, this wiped the running dev server's manifests and it
// served 500s with a different phantom-missing file every reload - which looks
// exactly like the file-handle race this script exists to survive.
removeWithRetries(nextDir);

let lastOutput = "";
for (let attempt = 1; attempt <= ATTEMPTS; attempt++) {
  // Next removes ./out itself but fails outright if a handle is still open.
  removeWithRetries(outDir);

  const res = spawnSync("npx", ["next", "build"], {
    cwd: root,
    // PRONOTES_TYPECHECKED is set above once the preflight type check passes
    // (and only then — the SKIP hatch leaves it unset, so Next type-checks).
    // Spread after the mutation so the child inherits it.
    env: { ...process.env, PRONOTES_STATIC: "1" },
    encoding: "utf8",
    shell: process.platform === "win32",
    maxBuffer: 64 * 1024 * 1024,
  });

  lastOutput = `${res.stdout ?? ""}${res.stderr ?? ""}`;
  process.stdout.write(lastOutput);

  if (res.status === 0) {
    if (attempt > 1) console.log(`\n[build-static] Succeeded on attempt ${attempt} of ${ATTEMPTS}.`);
    process.exit(0);
  }

  if (!isHandleRace(lastOutput)) {
    console.error(`\n[build-static] This is a real build error, not the file-handle race — not retrying.`);
    break;
  }
  if (attempt === ATTEMPTS) break;

  console.log(
    `\n[build-static] Attempt ${attempt} of ${ATTEMPTS} hit the Windows file-handle race ` +
      `(not a real build error). Clearing .next and retrying ...\n`
  );
  removeWithRetries(nextDir);
}

if (isHandleRace(lastOutput)) {
  console.error(`\n[build-static] Failed ${ATTEMPTS} times on the file-handle race.`);
  warnAboutCompetingProcesses();
}
process.exit(1);
