/**
 * Generate the Android launcher icons from public/icon-512.png.
 * Capacitor scaffolds Capacitor's own placeholder icon; this replaces it with
 * the ProNotes mark at every density, plus the round + foreground variants
 * Android's adaptive icons need.
 */
import sharp from "sharp";
import fs from "node:fs/promises";
import path from "node:path";

const SRC = path.join(process.cwd(), "public", "icon-512.png");
const RES = path.join(process.cwd(), "android", "app", "src", "main", "res");

// density -> launcher icon size in px
const DENSITIES = {
  "mipmap-mdpi": 48,
  "mipmap-hdpi": 72,
  "mipmap-xhdpi": 96,
  "mipmap-xxhdpi": 144,
  "mipmap-xxxhdpi": 192,
};

for (const [dir, size] of Object.entries(DENSITIES)) {
  const outDir = path.join(RES, dir);
  await fs.mkdir(outDir, { recursive: true });

  const square = await sharp(SRC).resize(size, size, { fit: "contain" }).png().toBuffer();
  await fs.writeFile(path.join(outDir, "ic_launcher.png"), square);
  await fs.writeFile(path.join(outDir, "ic_launcher_round.png"), square);

  // Adaptive-icon foreground: the system crops ~1/3, so the mark is inset
  // into a transparent canvas or it gets its edges shaved off.
  const inner = Math.round(size * 0.62);
  const pad = Math.round((size - inner) / 2);
  const foreground = await sharp({
    create: {
      width: size,
      height: size,
      channels: 4,
      background: { r: 0, g: 0, b: 0, alpha: 0 },
    },
  })
    .composite([
      { input: await sharp(SRC).resize(inner, inner, { fit: "contain" }).png().toBuffer(), top: pad, left: pad },
    ])
    .png()
    .toBuffer();
  await fs.writeFile(path.join(outDir, "ic_launcher_foreground.png"), foreground);
  console.log(`${dir}: ${size}px`);
}
console.log("Android launcher icons written.");
