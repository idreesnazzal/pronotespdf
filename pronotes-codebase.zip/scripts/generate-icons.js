/**
 * Icon Generation Pipeline for ProNotes
 * =====================================
 * Generates all multi-resolution brand assets, PWA icons, favicons,
 * and maskable adaptive icons using sharp.
 */

const path = require("path");
const fs = require("fs");
const sharp = require("sharp");

// Kept inside the project on purpose. This used to point at a file in an
// external scratch/brain folder, so the script broke the moment that folder was
// cleaned or the project was moved.
const SOURCE_ICON = path.join(__dirname, "..", "assets", "pronotes-icon-source.jpg");
const PUBLIC_DIR = path.resolve(__dirname, "../public");

// Ensure public directory exists
if (!fs.existsSync(PUBLIC_DIR)) {
  fs.mkdirSync(PUBLIC_DIR, { recursive: true });
}

// Background color for maskable icons and dark slate UI
const MASKABLE_BG = { r: 15, g: 23, b: 42, alpha: 1 }; // #0f172a

/**
 * Creates a valid binary ICO file embedding one or more PNG buffers.
 * @param {Array<{ width: number, height: number, buffer: Buffer }>} images
 * @returns {Buffer}
 */
function createIco(images) {
  const count = images.length;
  const headerSize = 6;
  const dirEntrySize = 16;
  let offset = headerSize + count * dirEntrySize;

  const header = Buffer.alloc(headerSize);
  header.writeUInt16LE(0, 0); // Reserved
  header.writeUInt16LE(1, 2); // Type 1 = ICO
  header.writeUInt16LE(count, 4); // Number of images

  const dirEntries = [];
  const imageBuffers = [];

  for (const img of images) {
    const entry = Buffer.alloc(dirEntrySize);
    entry.writeUInt8(img.width >= 256 ? 0 : img.width, 0);
    entry.writeUInt8(img.height >= 256 ? 0 : img.height, 1);
    entry.writeUInt8(0, 2); // Color palette
    entry.writeUInt8(0, 3); // Reserved
    entry.writeUInt16LE(1, 4); // Color planes
    entry.writeUInt16LE(32, 6); // Bits per pixel
    entry.writeUInt32LE(img.buffer.length, 8); // Image size in bytes
    entry.writeUInt32LE(offset, 12); // Image offset

    dirEntries.push(entry);
    imageBuffers.push(img.buffer);
    offset += img.buffer.length;
  }

  return Buffer.concat([header, ...dirEntries, ...imageBuffers]);
}

async function run() {
  console.log(`[Icon Pipeline] Checking source icon: ${SOURCE_ICON}`);
  if (!fs.existsSync(SOURCE_ICON)) {
    throw new Error(`Source icon not found at: ${SOURCE_ICON}`);
  }

  console.log("[Icon Pipeline] Generating high-resolution PNG assets...");

  // 1. Standard PWA Icons
  const pwa192 = path.join(PUBLIC_DIR, "icon-192.png");
  await sharp(SOURCE_ICON)
    .resize(192, 192, { fit: "cover" })
    .png({ quality: 100 })
    .toFile(pwa192);
  console.log(`  ✓ Created ${pwa192}`);

  const pwa512 = path.join(PUBLIC_DIR, "icon-512.png");
  await sharp(SOURCE_ICON)
    .resize(512, 512, { fit: "cover" })
    .png({ quality: 100 })
    .toFile(pwa512);
  console.log(`  ✓ Created ${pwa512}`);

  // 2. High-res logo
  const logo512 = path.join(PUBLIC_DIR, "logo.png");
  await sharp(SOURCE_ICON)
    .resize(512, 512, { fit: "cover" })
    .png({ quality: 100 })
    .toFile(logo512);
  console.log(`  ✓ Created ${logo512}`);

  // 3. Apple Touch Icon (iOS Safari)
  const appleTouch = path.join(PUBLIC_DIR, "apple-touch-icon.png");
  await sharp(SOURCE_ICON)
    .resize(180, 180, { fit: "cover" })
    .png({ quality: 100 })
    .toFile(appleTouch);
  console.log(`  ✓ Created ${appleTouch}`);

  // 4. Favicon PNGs
  const fav32 = path.join(PUBLIC_DIR, "favicon-32x32.png");
  const fav32Buffer = await sharp(SOURCE_ICON)
    .resize(32, 32, { fit: "cover" })
    .png({ quality: 100 })
    .toBuffer();
  fs.writeFileSync(fav32, fav32Buffer);
  console.log(`  ✓ Created ${fav32}`);

  const fav16 = path.join(PUBLIC_DIR, "favicon-16x16.png");
  const fav16Buffer = await sharp(SOURCE_ICON)
    .resize(16, 16, { fit: "cover" })
    .png({ quality: 100 })
    .toBuffer();
  fs.writeFileSync(fav16, fav16Buffer);
  console.log(`  ✓ Created ${fav16}`);

  const favMain = path.join(PUBLIC_DIR, "favicon.png");
  fs.writeFileSync(favMain, fav32Buffer);
  console.log(`  ✓ Created ${favMain}`);

  // 5. Maskable Adaptive Icons (Android safe zone = 80% with #0f172a background padding)
  const mask512 = path.join(PUBLIC_DIR, "icon-512-maskable.png");
  await sharp(SOURCE_ICON)
    .resize(410, 410, { fit: "contain", background: MASKABLE_BG })
    .extend({ top: 51, bottom: 51, left: 51, right: 51, background: MASKABLE_BG })
    .png({ quality: 100 })
    .toFile(mask512);
  console.log(`  ✓ Created ${mask512}`);

  const mask192 = path.join(PUBLIC_DIR, "icon-192-maskable.png");
  await sharp(SOURCE_ICON)
    .resize(154, 154, { fit: "contain", background: MASKABLE_BG })
    .extend({ top: 19, bottom: 19, left: 19, right: 19, background: MASKABLE_BG })
    .png({ quality: 100 })
    .toFile(mask192);
  console.log(`  ✓ Created ${mask192}`);

  // 6. Favicon .ICO (Multi-resolution: 32x32 and 16x16)
  const favIco = path.join(PUBLIC_DIR, "favicon.ico");
  const icoBuffer = createIco([
    { width: 32, height: 32, buffer: fav32Buffer },
    { width: 16, height: 16, buffer: fav16Buffer },
  ]);
  fs.writeFileSync(favIco, icoBuffer);
  console.log(`  ✓ Created ${favIco}`);

  console.log("[Icon Pipeline] All brand assets successfully generated!");
}

run().catch((err) => {
  console.error("[Icon Pipeline Error]", err);
  process.exit(1);
});
