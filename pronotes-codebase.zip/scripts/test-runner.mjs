import { execSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";

const rootDir = process.cwd();
const outDir = path.join(rootDir, ".test-dist");

if (!fs.existsSync(outDir)) {
  fs.mkdirSync(outDir, { recursive: true });
}

// Compile test and lib files using typescript
console.log("Compiling test files...");
const tscBin = path.join(rootDir, "node_modules", "typescript", "bin", "tsc");
execSync(`node "${tscBin}" -p tsconfig.test.json`, {
  stdio: "inherit",
  cwd: rootDir,
});

console.log("Running compiled tests...");
execSync(`node "${path.join(outDir, "tests", "milestone1.test.js")}"`, {
  stdio: "inherit",
  cwd: rootDir,
});
execSync(`node "${path.join(outDir, "tests", "notebook.test.js")}"`, {
  stdio: "inherit",
  cwd: rootDir,
});
execSync(`node "${path.join(outDir, "tests", "wheel_device.test.js")}"`, {
  stdio: "inherit",
  cwd: rootDir,
});
execSync(`node "${path.join(outDir, "tests", "stylus_button.test.js")}"`, {
  stdio: "inherit",
  cwd: rootDir,
});
execSync(`node "${path.join(outDir, "tests", "image_placement.test.js")}"`, {
  stdio: "inherit",
  cwd: rootDir,
});
execSync(`node "${path.join(outDir, "tests", "notebook_camera.test.js")}"`, {
  stdio: "inherit",
  cwd: rootDir,
});
execSync(`node "${path.join(outDir, "tests", "pens_bar_placement.test.js")}"`, {
  stdio: "inherit",
  cwd: rootDir,
});
execSync(`node "${path.join(outDir, "tests", "notebook_store.test.js")}"`, {
  stdio: "inherit",
  cwd: rootDir,
});
execSync(`node "${path.join(outDir, "tests", "export_geometry.test.js")}"`, {
  stdio: "inherit",
  cwd: rootDir,
});
execSync(`node "${path.join(outDir, "tests", "share_insert.test.js")}"`, {
  stdio: "inherit",
  cwd: rootDir,
});
execSync(`node "${path.join(outDir, "tests", "split_view.test.js")}"`, {
  stdio: "inherit",
  cwd: rootDir,
});
execSync(`node "${path.join(outDir, "tests", "pointer_handoff.test.js")}"`, {
  stdio: "inherit",
  cwd: rootDir,
});
execSync(`node "${path.join(outDir, "tests", "duplicate_notebook.test.js")}"`, {
  stdio: "inherit",
  cwd: rootDir,
});
execSync(`node "${path.join(outDir, "tests", "workspace_store_v2.test.js")}"`, {
  stdio: "inherit",
  cwd: rootDir,
});
execSync(`node "${path.join(outDir, "tests", "shape_tools.test.js")}"`, {
  stdio: "inherit",
  cwd: rootDir,
});
execSync(`node "${path.join(outDir, "tests", "toolbar_fixes.test.js")}"`, {
  stdio: "inherit",
  cwd: rootDir,
});
execSync(`node "${path.join(outDir, "tests", "text_editing.test.js")}"`, {
  stdio: "inherit",
  cwd: rootDir,
});
execSync(`node "${path.join(outDir, "tests", "pro_text_tool.test.js")}"`, {
  stdio: "inherit",
  cwd: rootDir,
});
execSync(`node "${path.join(outDir, "tests", "review_fixes.test.js")}"`, {
  stdio: "inherit",
  cwd: rootDir,
});
execSync(`node "${path.join(outDir, "tests", "dictation_continuation.test.js")}"`, {
  stdio: "inherit",
  cwd: rootDir,
});
execSync(`node "${path.join(outDir, "tests", "select_modes.test.js")}"`, {
  stdio: "inherit",
  cwd: rootDir,
});
execSync(`node "${path.join(outDir, "tests", "onedrive.test.js")}"`, {
  stdio: "inherit",
  cwd: rootDir,
});
execSync(`node "${path.join(outDir, "tests", "history.test.js")}"`, {
  stdio: "inherit",
  cwd: rootDir,
});
execSync(`node "${path.join(outDir, "tests", "challenger_stroke_stress.test.js")}"`, {
  stdio: "inherit",
  cwd: rootDir,
});
execSync(`node "${path.join(outDir, "tests", "challenger_geometry_stress.test.js")}"`, {
  stdio: "inherit",
  cwd: rootDir,
});
execSync(`node "${path.join(outDir, "tests", "adversarial_zoom_gestures.test.js")}"`, {
  stdio: "inherit",
  cwd: rootDir,
});
execSync(`node "${path.join(outDir, "tests", "milestone2_tools_qa.test.js")}"`, {
  stdio: "inherit",
  cwd: rootDir,
});
execSync(`node "${path.join(outDir, "tests", "milestone3_features_r3.test.js")}"`, {
  stdio: "inherit",
  cwd: rootDir,
});
execSync(`node "${path.join(outDir, "tests", "adversarial_challenger1.test.js")}"`, {
  stdio: "inherit",
  cwd: rootDir,
});
execSync(`node "${path.join(outDir, "tests", "regression_fix_pass.test.js")}"`, {
  stdio: "inherit",
  cwd: rootDir,
});
if (fs.existsSync(path.join(outDir, "tests", "challenger_2_empirical.test.js"))) {
  execSync(`node "${path.join(outDir, "tests", "challenger_2_empirical.test.js")}"`, {
    stdio: "inherit",
    cwd: rootDir,
  });
}
execSync(`node "${path.join(outDir, "tests", "pen_dynamics_and_stabilization.test.js")}"`, {
  stdio: "inherit",
  cwd: rootDir,
});
execSync(`node "${path.join(outDir, "tests", "image_studio.test.js")}"`, {
  stdio: "inherit",
  cwd: rootDir,
});
execSync(`node "${path.join(outDir, "tests", "dictation_robustness.test.js")}"`, {
  stdio: "inherit",
  cwd: rootDir,
});
execSync(`node "${path.join(outDir, "tests", "office_import.test.js")}"`, {
  stdio: "inherit",
  cwd: rootDir,
});
execSync(`node "${path.join(outDir, "tests", "toolbar_laser.test.js")}"`, {
  stdio: "inherit",
  cwd: rootDir,
});
execSync(`node "${path.join(outDir, "tests", "eraser_settle.test.js")}"`, {
  stdio: "inherit",
  cwd: rootDir,
});
execSync(`node "${path.join(outDir, "tests", "shape_recognition.test.js")}"`, {
  stdio: "inherit",
  cwd: rootDir,
});
execSync(`node "${path.join(outDir, "tests", "capture.test.js")}"`, {
  stdio: "inherit",
  cwd: rootDir,
});
execSync(`node "${path.join(outDir, "tests", "search_scopes.test.js")}"`, {
  stdio: "inherit",
  cwd: rootDir,
});
execSync(`node "${path.join(outDir, "tests", "pdf_text.test.js")}"`, {
  stdio: "inherit",
  cwd: rootDir,
});
execSync(`node "${path.join(outDir, "tests", "spen_review.test.js")}"`, {
  stdio: "inherit",
  cwd: rootDir,
});
execSync(`node "${path.join(outDir, "tests", "spen_deep_audit.test.js")}"`, {
  stdio: "inherit",
  cwd: rootDir,
});
execSync(`node "${path.join(outDir, "tests", "m1_adversarial_spen_stress.test.js")}"`, {
  stdio: "inherit",
  cwd: rootDir,
});
execSync(`node "${path.join(outDir, "tests", "interactive_knowledge_graph.test.js")}"`, {
  stdio: "inherit",
  cwd: rootDir,
});
execSync(`node "${path.join(outDir, "tests", "top_tools_and_sidebar.test.js")}"`, {
  stdio: "inherit",
  cwd: rootDir,
});
execSync(`node "${path.join(outDir, "tests", "sidebar_trash.test.js")}"`, {
  stdio: "inherit",
  cwd: rootDir,
});
execSync(`node "${path.join(outDir, "tests", "sidebar_batch.test.js")}"`, {
  stdio: "inherit",
  cwd: rootDir,
});

// The tests/e2e suite has its own plain-JS runner and was never wired in here,
// so 258 tests sat outside the `npm test` gate and quietly went stale.
console.log("\nRunning E2E suite (tests/e2e)...");
execSync(`node "${path.join(rootDir, "tests", "e2e", "runner.js")}"`, {
  stdio: "inherit",
  cwd: rootDir,
});
