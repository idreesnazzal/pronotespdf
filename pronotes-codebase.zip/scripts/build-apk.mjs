/**
 * One-command Android build: static export -> Capacitor sync -> APK.
 *
 *   npm run apk
 *
 * Produces android/app/build/outputs/apk/debug/app-debug.apk and copies it to
 * the project root as ProNotes.apk for easy transfer to a tablet.
 */
import { execSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";

const root = process.cwd();

// Version, computed rather than remembered.
//
// versionCode must strictly increase for Android to install an update over the
// old APK, and when it was a hand-edited number it stayed at 1 for months, so a
// tablet's build could not be identified. Minutes since 2026-01-01 UTC rises on
// every build, never repeats in practice, and stays far inside Android's limit
// (2,100,000,000) for thousands of years. The first value is ~375,000 - well
// above the 2 that the last hand-numbered APK used, so it installs over it.
const EPOCH = Date.UTC(2026, 0, 1);
const versionCode = Math.floor((Date.now() - EPOCH) / 60000);
const versionName = JSON.parse(fs.readFileSync(path.join(root, "package.json"), "utf8")).version;
if (!(versionCode > 2)) throw new Error(`Computed versionCode ${versionCode} is not above the last release (2) - is the clock right?`);
const run = (cmd, opts = {}) =>
  execSync(cmd, { stdio: "inherit", cwd: root, env: process.env, ...opts });

console.log("\n[1/3] Static export…");
// The web layer is told the version code so the app can show which build it
// is - the only way to tell "the fix did not work" from "the APK never
// installed" while holding the tablet.
run("node scripts/build-static.mjs", {
  env: { ...process.env, PRONOTES_BUILD_CODE: String(versionCode) },
});

console.log("\n[2/3] Syncing web assets into the Android project…");
run("npx cap sync android");
run("node scripts/make-android-icons.mjs");

console.log("\n[3/3] Building the APK (this takes a few minutes the first time)…");
// Absolute path: a bare "gradlew.bat" is not resolved when the command is
// spawned with a different cwd, and "./gradlew" is shell-specific.
const androidDir = path.join(root, "android");
const gradlew = path.join(androidDir, process.platform === "win32" ? "gradlew.bat" : "gradlew");
console.log(`      version ${versionName} (code ${versionCode})`);
run(`"${gradlew}" assembleDebug -PpronotesVersionCode=${versionCode} -PpronotesVersionName=${versionName}`, {
  cwd: androidDir,
});

const built = path.join(root, "android", "app", "build", "outputs", "apk", "debug", "app-debug.apk");
if (!fs.existsSync(built)) {
  console.error("APK not found at", built);
  process.exit(1);
}
const dest = path.join(root, "ProNotes.apk");
fs.copyFileSync(built, dest);
const mb = (fs.statSync(dest).size / 1048576).toFixed(1);
console.log(`\nDone. ${dest} (${mb} MB) - version ${versionName}, code ${versionCode}`);
console.log("Copy it to your tablet and open it to install.");
