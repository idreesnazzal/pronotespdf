/**
 * Static audit: unreachable modules and risky patterns.
 *
 *   node scripts/audit.mjs
 *
 * Reports files no entry point can reach, plus patterns worth a second look
 * (type suppressions, unguarded parses, stray console.log). It is a lead
 * generator, not a linter — every hit needs judging by hand.
 */
import fs from "node:fs";
import path from "node:path";

const ROOT = process.cwd();
const SRC = path.join(ROOT, "src");
const EXTS = [".tsx", ".ts"];
const rel = (f) => path.relative(ROOT, f).split(path.sep).join("/");

function* walk(dir) {
  for (const d of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, d.name);
    if (d.isDirectory()) yield* walk(p);
    else yield p;
  }
}

const files = [...walk(SRC)].filter((f) => EXTS.includes(path.extname(f)));

function resolveImport(spec, from) {
  let base;
  if (spec.startsWith("@/")) base = path.join(SRC, spec.slice(2));
  else if (spec.startsWith(".")) base = path.resolve(path.dirname(from), spec);
  else return null;
  for (const e of EXTS) if (fs.existsSync(base + e)) return base + e;
  for (const e of EXTS) {
    const idx = path.join(base, "index" + e);
    if (fs.existsSync(idx)) return idx;
  }
  return null;
}

// ---- reachability from the Next.js entry points ---------------------------
const entries = [path.join(SRC, "app/layout.tsx"), path.join(SRC, "app/page.tsx")].filter(fs.existsSync);
for (const f of files) if (/route\.tsx?$/.test(f) && f.includes("app")) entries.push(f);

const reachable = new Set();
const stack = [...entries];
while (stack.length) {
  const f = stack.pop();
  if (reachable.has(f)) continue;
  reachable.add(f);
  const code = fs.readFileSync(f, "utf8");
  for (const m of code.matchAll(/(?:from\s+|import\(\s*)["']([^"']+)["']/g)) {
    const r = resolveImport(m[1], f);
    if (r) stack.push(r);
  }
}
const dead = files.filter((f) => !reachable.has(f));

// ---- risky patterns -------------------------------------------------------
const findings = [];
for (const f of files) {
  const lines = fs.readFileSync(f, "utf8").split("\n");
  lines.forEach((line, i) => {
    const at = `${rel(f)}:${i + 1}`;
    if (/\bas any\b/.test(line)) findings.push(["as any", at]);
    if (/@ts-ignore|@ts-expect-error/.test(line)) findings.push(["ts suppression", at]);
    if (/console\.log\(/.test(line)) findings.push(["console.log", at]);
    if (/dangerouslySetInnerHTML/.test(line)) findings.push(["dangerouslySetInnerHTML", at]);
    // A bare await inside a component body cannot be caught by an error boundary.
    if (/localStorage\.(getItem|setItem)/.test(line)) findings.push(["direct localStorage", at]);
  });
}

console.log(`files ${files.length}   reachable ${reachable.size}   dead ${dead.length}`);
for (const d of dead) console.log(`  DEAD  ${rel(d)}`);

const grouped = {};
for (const [kind, at] of findings) (grouped[kind] ||= []).push(at);
console.log("\nrisk scan");
for (const kind of Object.keys(grouped).sort()) {
  console.log(`  ${kind}: ${grouped[kind].length}`);
  grouped[kind].slice(0, 5).forEach((a) => console.log(`      ${a}`));
}
