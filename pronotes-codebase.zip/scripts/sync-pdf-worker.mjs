/**
 * Copies the pdf.js worker into public/ so it is served from the app's own
 * root in every package: the dev server, the static export, Electron's
 * `pronotes://app/` scheme, and the APK's asset root.
 *
 * It lives in public/ rather than being resolved with `new URL(...,
 * import.meta.url)` because that form cannot compile to CommonJS, which the
 * node test suite uses — and the store imports the PDF module, so the whole
 * suite failed to build. A CDN was never an option: the app must work offline.
 *
 * Run after any pdfjs-dist upgrade, or the app ships a worker from the old
 * version and rendering fails with a version-mismatch error.
 */
import fs from "node:fs";
import path from "node:path";

const from = path.join("node_modules", "pdfjs-dist", "build", "pdf.worker.min.mjs");
const to = path.join("public", "pdf.worker.min.mjs");

if (!fs.existsSync(from)) {
  console.error(`pdf.js worker not found at ${from} — is pdfjs-dist installed?`);
  process.exit(1);
}

const src = fs.readFileSync(from);
const same = fs.existsSync(to) && Buffer.compare(src, fs.readFileSync(to)) === 0;
if (same) {
  console.log("pdf.js worker already up to date");
} else {
  fs.writeFileSync(to, src);
  console.log(`pdf.js worker synced -> ${to} (${(src.length / 1024).toFixed(0)} KB)`);
}
