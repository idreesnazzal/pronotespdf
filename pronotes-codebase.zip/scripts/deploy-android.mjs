/**
 * Build the APK and push it straight onto a connected tablet.
 *
 *   npm run apk:deploy              build, install, launch
 *   npm run apk:deploy -- --fast    skip the build, install the existing APK
 *
 * Why this exists
 * ---------------
 * `npm run apk` stops at a file and tells you to copy it across by hand. Over
 * USB that is unnecessary: adb can replace the installed app in place. `-r`
 * keeps the app's data, so notebooks and imported PDFs survive the update —
 * an uninstall/reinstall would wipe them.
 */
import { execSync, execFileSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";

const root = process.cwd();
const args = process.argv.slice(2);
const fast = args.includes("--fast");
const APK = path.join(root, "ProNotes.apk");
const PKG = "com.idrees.pronotes";

const sdk = process.env.ANDROID_HOME || process.env.ANDROID_SDK_ROOT;
if (!sdk) {
  console.error("ANDROID_HOME is not set — cannot find adb.");
  process.exit(1);
}
const adb = path.join(sdk, "platform-tools", process.platform === "win32" ? "adb.exe" : "adb");
const sh = (args, opts = {}) => execFileSync(adb, args, { encoding: "utf8", ...opts }).trim();

// --- which device? -------------------------------------------------------
let devices = [];
try {
  devices = sh(["devices"])
    .split("\n")
    .slice(1)
    .map((l) => l.trim().split(/\s+/))
    .filter((p) => p.length >= 2 && p[1] === "device")
    .map((p) => p[0]);
} catch (e) {
  console.error("adb is not responding:", e.message);
  process.exit(1);
}

const unauthorized = (() => {
  try {
    return sh(["devices"]).includes("unauthorized");
  } catch {
    return false;
  }
})();

if (unauthorized) {
  console.error(
    "\nThe tablet is connected but NOT authorised.\n" +
      "Unlock it and tap \"Allow USB debugging\" on the prompt, ticking\n" +
      "\"Always allow from this computer\", then run this again."
  );
  process.exit(1);
}

if (devices.length === 0) {
  console.error(
    "\nNo device found. On the tablet:\n" +
      "  1. Settings > About tablet > tap \"Build number\" seven times\n" +
      "  2. Settings > System > Developer options > enable \"USB debugging\"\n" +
      "  3. Plug in the USB-C cable and accept the prompt\n" +
      "Then: adb devices  (it should list one line ending in 'device')"
  );
  process.exit(1);
}

// Prefer a real tablet over a running emulator.
const physical = devices.filter((d) => !d.startsWith("emulator-"));
const target = (physical.length ? physical : devices)[0];
if (devices.length > 1) {
  console.log(`Several devices attached (${devices.join(", ")}) — using ${target}.`);
}

// --- build ---------------------------------------------------------------
if (!fast) {
  execSync("node scripts/build-apk.mjs", { stdio: "inherit", cwd: root });
} else {
  if (!fs.existsSync(APK)) {
    console.error(`--fast given but ${APK} does not exist yet. Run without --fast once.`);
    process.exit(1);
  }
  const age = Math.round((Date.now() - fs.statSync(APK).mtimeMs) / 60000);
  console.log(`--fast: installing the existing APK (built ${age} min ago) without rebuilding.`);
}

// --- install -------------------------------------------------------------
const mb = (fs.statSync(APK).size / 1048576).toFixed(1);
console.log(`\nInstalling ProNotes.apk (${mb} MB) on ${target} ...`);
let out;
try {
  out = execFileSync(adb, ["-s", target, "install", "-r", APK], { encoding: "utf8" });
} catch (e) {
  out = `${e.stdout || ""}${e.stderr || ""}`;
}

if (!/Success/.test(out)) {
  console.error(out.trim());
  if (/UPDATE_INCOMPATIBLE|signatures do not match/i.test(out)) {
    console.error(
      "\nThe installed copy was signed with a different key, so it cannot be\n" +
        "replaced in place. Uninstalling REMOVES ITS NOTEBOOKS — export a backup\n" +
        "from the app first, then:\n" +
        `    adb -s ${target} uninstall ${PKG}`
    );
  }
  process.exit(1);
}

execFileSync(adb, ["-s", target, "shell", "monkey", "-p", PKG, "-c", "android.intent.category.LAUNCHER", "1"], {
  stdio: "ignore",
});
console.log("Installed and launched. Existing notebooks were kept (-r).");
