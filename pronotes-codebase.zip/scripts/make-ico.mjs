/**
 * Build a multi-resolution Windows .ico from public/icon-512.png.
 *
 * The repo only shipped a 2KB favicon.ico (16/32px), which looks mushy as a
 * desktop-shortcut and taskbar icon. ICO files may embed PNGs directly, so we
 * resize with sharp and assemble the container by hand — no extra dependency.
 */
import sharp from "sharp";
import fs from "node:fs/promises";
import path from "node:path";

const SIZES = [16, 24, 32, 48, 64, 128, 256];
const src = path.join(process.cwd(), "public", "icon-512.png");
const out = path.join(process.cwd(), "public", "pronotes.ico");

const images = await Promise.all(
  SIZES.map(async (size) => ({
    size,
    data: await sharp(src).resize(size, size, { fit: "contain" }).png().toBuffer(),
  }))
);

const HEADER = 6;
const ENTRY = 16;
const header = Buffer.alloc(HEADER);
header.writeUInt16LE(0, 0); // reserved
header.writeUInt16LE(1, 2); // type 1 = icon
header.writeUInt16LE(images.length, 4);

let offset = HEADER + ENTRY * images.length;
const entries = [];
for (const img of images) {
  const e = Buffer.alloc(ENTRY);
  // 256 is stored as 0 in the single-byte width/height fields.
  e.writeUInt8(img.size === 256 ? 0 : img.size, 0);
  e.writeUInt8(img.size === 256 ? 0 : img.size, 1);
  e.writeUInt8(0, 2); // palette colours (0 = truecolour)
  e.writeUInt8(0, 3); // reserved
  e.writeUInt16LE(1, 4); // colour planes
  e.writeUInt16LE(32, 6); // bits per pixel
  e.writeUInt32LE(img.data.length, 8);
  e.writeUInt32LE(offset, 12);
  entries.push(e);
  offset += img.data.length;
}

await fs.writeFile(out, Buffer.concat([header, ...entries, ...images.map((i) => i.data)]));
console.log(`wrote ${out} (${SIZES.join("/")}px, ${(await fs.stat(out)).size} bytes)`);
