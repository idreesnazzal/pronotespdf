/**
 * Production server build: `npm run build`.
 *
 * Type-checks first, then runs `next build` with PRONOTES_TYPECHECKED=1 so
 * next.config.ts lets Next skip its own duplicate type pass (it just passed
 * here). A bare `npx next build` never sets the marker, so it still fails on
 * type errors instead of shipping them green.
 *
 * A script — not `tsc && next build` inline in package.json — because setting
 * an env var inline is not portable to Windows cmd. No new dependencies.
 */
import { spawnSync } from "node:child_process";

const root = process.cwd();

if (process.env.PRONOTES_SKIP_TYPECHECK === "1") {
  console.warn("[build] PRONOTES_SKIP_TYPECHECK=1 - building WITHOUT a type check.");
} else {
  const t = spawnSync("npx tsc --noEmit", { cwd: root, stdio: "inherit", shell: true });
  if (t.status !== 0) {
    console.error("\n[build] Type-checking failed - not building.");
    process.exit(t.status ?? 1);
  }
  process.env.PRONOTES_TYPECHECKED = "1";
}

const b = spawnSync("npx", ["next", "build"], {
  cwd: root,
  stdio: "inherit",
  shell: process.platform === "win32",
  env: { ...process.env },
});
process.exit(b.status ?? 1);
