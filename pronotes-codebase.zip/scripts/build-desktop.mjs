/**
 * Build the Windows desktop app: static export -> Electron package.
 *
 *   npm run dist:win
 *
 * Produces, in ./dist-desktop:
 *   - ProNotes Setup <version>.exe  (installer: Start menu + desktop shortcut)
 *   - ProNotes <version>.exe        (portable: run it from anywhere, no install)
 */
import { execSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";

const root = process.cwd();
const run = (cmd) => execSync(cmd, { stdio: "inherit", cwd: root, env: process.env });

console.log("\n[1/2] Static export…");
run("node scripts/build-static.mjs");

console.log("\n[2/2] Packaging the Windows app…");
run("npx electron-builder --win --x64");

const out = path.join(root, "dist-desktop");
if (fs.existsSync(out)) {
  const exes = fs.readdirSync(out).filter((f) => f.endsWith(".exe"));
  console.log("\nBuilt:");
  for (const e of exes) {
    const mb = (fs.statSync(path.join(out, e)).size / 1048576).toFixed(1);
    console.log(`  ${e}  (${mb} MB)`);
  }
}
