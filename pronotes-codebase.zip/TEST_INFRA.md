# E2E Test Infra: ProNotes Infinite Whiteboard

> **Note (2026-09-18):** `ORIGINAL_REQUEST.md` no longer exists — it was the
> original brief and was removed in an earlier cleanup. The `§ R1/R2/R3`
> references below are historical. The feature-to-tier matrix itself is still
> accurate for the live suite in `tests/e2e/`.

## Test Philosophy
- Opaque-box, requirement-driven. Derives strictly from ORIGINAL_REQUEST.md.
- Methodology: Category-Partition + Boundary Value Analysis (BVA) + Pairwise Combinatorial Testing + Real-World Workload Scenarios.

## Feature Inventory & Test Coverage
| # | Feature | Source (Requirement) | Tier 1 (Coverage) | Tier 2 (Boundary) | Tier 3 (Pairwise) | Tier 4 (Real-World) |
|---|---------|---------------------|:-----------------:|:-----------------:|:-----------------:|:-------------------:|
| 1 | Runtime TypeError Fix (R1) | ORIGINAL_REQUEST § R1 | 5 | 5 | ✓ | ✓ |
| 2 | Select & Marquee Tool | ORIGINAL_REQUEST § R2 | 5 | 5 | ✓ | ✓ |
| 3 | Lasso Freeform Selection | ORIGINAL_REQUEST § R2 | 5 | 5 | ✓ | ✓ |
| 4 | Pan Tool & Camera Zoom | ORIGINAL_REQUEST § R2 | 5 | 5 | ✓ | ✓ |
| 5 | 6 Pen Types & Strokes | ORIGINAL_REQUEST § R2 | 5 | 5 | ✓ | ✓ |
| 6 | Single-Tap Arc Dots | ORIGINAL_REQUEST § R2 | 5 | 5 | ✓ | ✓ |
| 7 | Eraser Tool | ORIGINAL_REQUEST § R2 | 5 | 5 | ✓ | ✓ |
| 8 | 8 Shape Primitives | ORIGINAL_REQUEST § R2 | 5 | 5 | ✓ | ✓ |
| 9 | Line & Arrow Vectors | ORIGINAL_REQUEST § R2 | 5 | 5 | ✓ | ✓ |
| 10| Rotated Element Resizing | ORIGINAL_REQUEST § R2 | 5 | 5 | ✓ | ✓ |
| 11| Smart Connectors (3 Modes) | ORIGINAL_REQUEST § R2 | 5 | 5 | ✓ | ✓ |
| 12| Text Tool & Typography | ORIGINAL_REQUEST § R2 | 5 | 5 | ✓ | ✓ |
| 13| Sticky Notes & Formatting | ORIGINAL_REQUEST § R2 | 5 | 5 | ✓ | ✓ |
| 14| Obsidian [[WikiLinks]] | ORIGINAL_REQUEST § R2 | 5 | 5 | ✓ | ✓ |
| 15| Image Upload & Paste | ORIGINAL_REQUEST § R2 | 5 | 5 | ✓ | ✓ |
| 16| Touchscreen Gestures | ORIGINAL_REQUEST § R2 | 5 | 5 | ✓ | ✓ |
| 17| Size Sliders & Undo/Redo | ORIGINAL_REQUEST § R2 | 5 | 5 | ✓ | ✓ |
| 18| Dark/Light Theme Toggle (R3)| ORIGINAL_REQUEST § R3 | 5 | 5 | ✓ | ✓ |
| 19| Export Board PNG/SVG (R3) | ORIGINAL_REQUEST § R3 | 5 | 5 | ✓ | ✓ |
| 20| Keyboard Shortcuts Modal (R3)| ORIGINAL_REQUEST § R3 | 5 | 5 | ✓ | ✓ |
| 21| Minimap Navigator (R3) | ORIGINAL_REQUEST § R3 | 5 | 5 | ✓ | ✓ |
| 22| Snap-to-Grid (R3) | ORIGINAL_REQUEST § R3 | 5 | 5 | ✓ | ✓ |
| 23| Opacity Slider (R3) | ORIGINAL_REQUEST § R3 | 5 | 5 | ✓ | ✓ |

## Test Architecture
- Test runner: `node tests/e2e/runner.js`
- Core stress runner: `npm test` (`node scripts/test-runner.mjs`)
- Exit code 0 on all passes; comprehensive assertion logging across all 4 tiers.

## Coverage Thresholds
- Tier 1: ≥5 test cases per feature (115+ test cases)
- Tier 2: ≥5 boundary test cases per feature (115+ test cases)
- Tier 3: Pairwise combinations across tools and canvas operations (20+ test cases)
- Tier 4: Real-world workflow simulations (Architecture diagramming, brainstorming, mind-mapping, complex whiteboards) (8+ scenarios)
- **Total: >250 rigorous test cases with 100% pass rate requirement.**

## Actual status (2026-09-19) — read this before trusting the targets above

The targets above were written up front and are **not all met**. What
`node tests/e2e/runner.js` actually enforces is `minAssertions: 110` for Tiers
1-2 and `minTests` 25 / 5 for Tiers 3-4:

| Tier | Target above | Actual (2026-09-25) |
|---|---|---|
| 1 Feature coverage | 115+ tests | 125 tests, 296 assertions |
| 2 Boundaries | 115+ tests | 119 tests, 229 assertions |
| 3 Pairwise | 20+ tests | 30 tests |
| 4 Scenarios | 8+ scenarios | 6 scenarios |
| Milestone 3 (PWA, icons, branding) | - | 35 tests, 393 assertions |

Node suites in `npm test` now also include `top_tools_and_sidebar`,
`sidebar_trash`, `sidebar_batch`, `select_modes` and `dictation_continuation`.

The matrix at the top has 23 rows; the runner tracks 22 features (row 23,
the opacity slider, is covered inside Tier 1 but not counted as its own
feature).

**`m3-pwa-branding.test.js`** was written for milestone 3 but never added to
the runner, so it rotted: it read the deleted `start.bat`, expected the old
README title, hardcoded a service-worker cache key that is bumped on every
deploy, and faked requests without the `headers.get()` that `sw.js` now calls.
Twelve of its tests failed once it was run. It is now wired in as the fifth
tier and passes.

**`mutation-challenge.js` is manual-only and must never be added to `npm
test`.** It deliberately REWRITES source files (`stroke.ts`, `geometry.ts`,
...) to check that the suites catch each break, then restores them. An
interrupted run, or one that overlaps another editor or Claude session, can
leave a sabotaged file behind. Run it only on a clean `git status`, and check
`git diff` afterwards.
