# OneDrive Sync — Setup (free, ~2 minutes)

Sync signs you in with your Microsoft account and keeps **one file** in your own
OneDrive, so the same email gives you the same boards on your PC and your tablet.

**Cost: nothing.** No server, no subscription. The file lives in your OneDrive
quota, and Microsoft app registration is free.

Everything in the app is already built. The only thing missing is *your* app ID —
I cannot create it for you, because it requires signing into your Microsoft
account.

---

## Step 1 — Register the app (once)

1. Go to <https://entra.microsoft.com> and sign in with **your** Microsoft account.
2. Left menu: **Applications → App registrations → + New registration**.
3. Fill in:
   - **Name:** `ProNotes`
   - **Supported account types:** *Accounts in any organizational directory and
     personal Microsoft accounts* — this is the one that allows `@outlook.com` /
     `@hotmail.com` / `@gmail`-linked Microsoft accounts.
   - **Redirect URI:** choose platform **Single-page application (SPA)** and enter
     the address the app runs at. Sign-in sends you back to the page's own
     address (`src/lib/whiteboard/onedrive.ts` → `redirectUri()`), so it differs
     per platform:

     | Where you run ProNotes | Redirect URI to register |
     |---|---|
     | Dev server (`npm run dev`) | `http://localhost:3000/` |
     | Android APK | `https://localhost/` — Capacitor serves the app from there. *Not yet tested on a device.* |
     | A deployed website | `https://YOUR-SITE/` |
     | **Windows app** | **Not supported yet — see below.** |

     > Add each one with *Add a platform → SPA*. The URI must match **exactly**,
     > including the trailing slash; a mismatch fails with `AADSTS50011`.

     > **The Windows app cannot sign in with this flow.** It loads from
     > `pronotes://app/index.html`, and Microsoft's SPA platform only accepts
     > `http`/`https` redirect URIs, so there is nothing valid to register. It
     > needs a different sign-in (a loopback redirect or the system browser)
     > before OneDrive can work there. Until then, move boards to and from the
     > Windows app with **Sync & Backup → Save backup / Restore**.
4. Click **Register**.
5. On the overview page copy the **Application (client) ID** — a GUID that looks
   like `11111111-2222-3333-4444-555555555555`.

**Do not create a client secret.** Browser apps cannot keep one, and this setup
uses PKCE instead, which is what Microsoft requires for SPAs.

### Permissions

The app requests these when you first sign in — no admin approval needed:

| Scope | What it allows |
|---|---|
| `Files.ReadWrite.AppFolder` | Read/write **only** ProNotes' own folder in your OneDrive. It cannot see your other files. |
| `User.Read` | Your name and email, to show who is signed in. |
| `offline_access` | Stay signed in without logging in every hour. |

---

## Step 2 — Give the app your client ID

Create a file called `.env.local` in the project root:

```
NEXT_PUBLIC_MS_CLIENT_ID=paste-your-client-id-here
```

Then rebuild the app you actually use. The ID is baked in at build time, so
`npm run build` (the web server build) does **not** update the Android or Windows
apps:

```bash
npm run apk        # Android
npm run dist:win   # Windows
```

Launch from the Desktop shortcut. Open **Sync & Backup** (the cloud icon, top
right) and the amber "not set up" notice will be replaced by
**Sign in with Microsoft**.

---

## Step 3 — Sync

1. On your PC: **Sign in with Microsoft** → **Sync now**. Your boards upload.
2. On your tablet: open the same site, sign in with the **same email**, **Sync now**.

Boards are merged **one at a time**, newest edit wins. Editing different boards on
different devices never loses anything. Only a board you changed on *both* devices
since the last sync has to pick a winner, and then the newer one wins.

---

## Don't want an account at all?

**Sync & Backup → Save backup** downloads a `.json` file with your whole
workspace. **Restore** loads it on any other device. That path needs no
Microsoft account, no internet, and no setup — it is just a manual copy.

---

## Troubleshooting

| Symptom | Cause |
|---|---|
| `AADSTS50011: redirect URI mismatch` | The URI in step 3 does not exactly match the address in the browser bar. Check `http` vs `https`, the port, and the trailing slash. |
| Sign-in works, sync says 401 | Token expired and could not refresh — sign out and back in. |
| "not set up" notice remains | `.env.local` was not picked up. It is read at **build** time, so `npm run build` must be re-run after creating it. |
| Boards missing after switching browser | Boards are stored per-browser until you sign in. Use a backup file, or sign in on both. |
