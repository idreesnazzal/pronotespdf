/**
 * Shape recognition on hand-drawn strokes.
 *
 * Every shape is drawn many times the way a hand draws it - a slow wobble, a
 * little jitter, starting anywhere, closing with a small gap or an overshoot,
 * at any angle - and must come out as the shape meant, the same size and in
 * the same place. Things that are NOT shapes (handwriting, an open arc, a
 * zig-zag, a scribble) must be left exactly as drawn.
 */

import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { joinLine, recognizeShape, type ShapeKind } from "../src/lib/whiteboard/shapeRecognition";

const NL = String.fromCharCode(10);
let passed = 0;
let failed = 0;
function test(name: string, fn: () => void) {
  try {
    fn();
    passed++;
    console.log(`  ✓ ${name}`);
  } catch (err) {
    failed++;
    console.error(`  ✗ ${name}`);
    console.error(`      ${(err as Error).message}`);
  }
}

type Pt = [number, number, number];

// Deterministic randomness, so a failure can be reproduced.
let seed = Number(process.env.SHAPE_SEED) || 12345;
const rand = () => {
  seed = (seed * 1103515245 + 12345) & 0x7fffffff;
  return seed / 0x7fffffff;
};

/** A path through `pts` sampled like a pen: ~3px apart, wobble + jitter. */
function handDrawn(path: Array<[number, number]>, wobble: number, jitter = 0.6): Pt[] {
  const out: Pt[] = [];
  const phase = rand() * 10;
  const freq = 0.02 + rand() * 0.02;
  let s = 0;
  for (let i = 0; i < path.length - 1; i++) {
    const [x0, y0] = path[i];
    const [x1, y1] = path[i + 1];
    const len = Math.hypot(x1 - x0, y1 - y0);
    const n = Math.max(1, Math.round(len / 3));
    const nx = -(y1 - y0) / (len || 1);
    const ny = (x1 - x0) / (len || 1);
    for (let k = 0; k < n; k++) {
      const t = k / n;
      s += len / n;
      const w = Math.sin(s * freq + phase) * wobble;
      out.push([
        x0 + (x1 - x0) * t + nx * w + (rand() - 0.5) * jitter,
        y0 + (y1 - y0) * t + ny * w + (rand() - 0.5) * jitter,
        0.45 + rand() * 0.1,
      ]);
    }
  }
  const [lx, ly] = path[path.length - 1];
  out.push([lx, ly, 0.5]);
  return out;
}

/** A closed outline from `corners` (or a dense curve), started at a random place, closed with a gap/overshoot. */
function closedStroke(outline: Array<[number, number]>, wobble: number, closeBy: number): Pt[] {
  const n = outline.length;
  const start = Math.floor(rand() * n);
  const loop: Array<[number, number]> = [];
  for (let i = 0; i <= n; i++) loop.push(outline[(start + i) % n]);
  // closeBy > 0: overshoot that fraction of the next side; < 0: stop short.
  if (closeBy > 0) {
    const a = loop[loop.length - 1];
    const b = outline[(start + 1) % n];
    loop.push([a[0] + (b[0] - a[0]) * closeBy, a[1] + (b[1] - a[1]) * closeBy]);
  } else if (closeBy < 0) {
    const a = loop[loop.length - 2];
    const b = loop[loop.length - 1];
    loop[loop.length - 1] = [b[0] + (a[0] - b[0]) * -closeBy, b[1] + (a[1] - b[1]) * -closeBy];
  }
  return handDrawn(loop, wobble);
}

function rotateAll(pts: Array<[number, number]>, ang: number, cx: number, cy: number): Array<[number, number]> {
  return pts.map(([x, y]) => [
    cx + (x - cx) * Math.cos(ang) - (y - cy) * Math.sin(ang),
    cy + (x - cx) * Math.sin(ang) + (y - cy) * Math.cos(ang),
  ]);
}

function circleOutline(cx: number, cy: number, rx: number, ry: number, rot = 0, n = 72): Array<[number, number]> {
  const out: Array<[number, number]> = [];
  for (let i = 0; i < n; i++) {
    const t = (i / n) * Math.PI * 2;
    out.push([cx + rx * Math.cos(t), cy + ry * Math.sin(t)]);
  }
  return rot ? rotateAll(out, rot, cx, cy) : out;
}

function bbox(pts: Array<[number, number] | Pt>) {
  const xs = pts.map((p) => p[0]);
  const ys = pts.map((p) => p[1]);
  return { x0: Math.min(...xs), y0: Math.min(...ys), x1: Math.max(...xs), y1: Math.max(...ys) };
}

/** Recognise `trials` drawings; each must be `want` and fit the ideal box within `tol` px. */
function expectShape(
  want: ShapeKind | ShapeKind[],
  make: () => { stroke: Pt[]; ideal: Array<[number, number]> },
  trials = 40,
  tol = 8
) {
  const wants = Array.isArray(want) ? want : [want];
  let wrong = 0;
  const kinds: Record<string, number> = {};
  for (let i = 0; i < trials; i++) {
    const { stroke, ideal } = make();
    const r = recognizeShape(stroke, { minSize: 20 });
    const k = r ? r.kind : "none";
    kinds[k] = (kinds[k] ?? 0) + 1;
    if (!r || !wants.includes(r.kind)) {
      wrong++;
      continue;
    }
    const a = bbox(r.points);
    const b = bbox(ideal);
    const off = Math.max(Math.abs(a.x0 - b.x0), Math.abs(a.y0 - b.y0), Math.abs(a.x1 - b.x1), Math.abs(a.y1 - b.y1));
    if (off > tol) {
      wrong++;
      kinds[`${k}-misplaced(${off.toFixed(1)})`] = (kinds[`${k}-misplaced(${off.toFixed(1)})`] ?? 0) + 1;
    }
  }
  // A hand is not a machine: 1 miss in 20 is allowed, never a wrong shape
  // counted as right.
  assert.ok(wrong <= Math.floor(trials * 0.05), `${wrong}/${trials} wrong: ${JSON.stringify(kinds)}`);
}

/** Must be left as drawn (null) at least this often. */
function expectNone(make: () => Pt[], trials = 40) {
  const kinds: Record<string, number> = {};
  let converted = 0;
  for (let i = 0; i < trials; i++) {
    const r = recognizeShape(make(), { minSize: 20 });
    if (r) {
      converted++;
      kinds[r.kind] = (kinds[r.kind] ?? 0) + 1;
    }
  }
  assert.ok(converted <= Math.floor(trials * 0.05), `${converted}/${trials} converted: ${JSON.stringify(kinds)}`);
}

console.log(NL + "── Shape recognition ──");

const R = (a: number, b: number) => a + rand() * (b - a);

test("circles become circles, same place and size", () => {
  expectShape("circle", () => {
    const r = R(30, 160);
    const cx = R(0, 500);
    const cy = R(0, 500);
    const ideal = circleOutline(cx, cy, r, r);
    return { stroke: closedStroke(ideal, r * R(0.01, 0.05), R(-0.12, 0.25) * 0.2), ideal };
  }, 60, 0.12 * 160);
});

test("ellipses become ellipses, upright or turned", () => {
  expectShape("ellipse", () => {
    const rx = R(80, 180);
    const ry = rx * R(0.4, 0.7);
    const cx = R(0, 500);
    const cy = R(0, 500);
    const ideal = circleOutline(cx, cy, rx, ry, rand() < 0.5 ? 0 : R(0.3, 1.2));
    return { stroke: closedStroke(ideal, ry * R(0.01, 0.04), R(-0.1, 0.2) * 0.2), ideal };
  }, 60, 16);
});

test("squares become squares", () => {
  expectShape("square", () => {
    const s = R(60, 240);
    const x = R(0, 400);
    const y = R(0, 400);
    const ideal: Array<[number, number]> = [[x, y], [x + s, y], [x + s, y + s], [x, y + s]];
    return { stroke: closedStroke(ideal, s * R(0.004, 0.015), R(-0.15, 0.2)), ideal };
  }, 60, 10);
});

test("rectangles become rectangles, also turned", () => {
  expectShape("rectangle", () => {
    const w = R(120, 300);
    const h = w * R(0.35, 0.7);
    const x = R(0, 400);
    const y = R(0, 400);
    let ideal: Array<[number, number]> = [[x, y], [x + w, y], [x + w, y + h], [x, y + h]];
    if (rand() < 0.5) ideal = rotateAll(ideal, R(0.2, 1.2), x + w / 2, y + h / 2);
    return { stroke: closedStroke(ideal, h * R(0.004, 0.015), R(-0.15, 0.2)), ideal };
  }, 60, 12);
});

test("triangles become triangles", () => {
  expectShape("triangle", () => {
    const s = R(80, 240);
    const x = R(0, 400);
    const y = R(0, 400);
    let ideal: Array<[number, number]> = [[x, y + s], [x + s, y + s], [x + s * R(0.2, 0.8), y + s * R(0, 0.2)]];
    if (rand() < 0.4) ideal = rotateAll(ideal, R(0.3, 2.5), x + s / 2, y + s / 2);
    return { stroke: closedStroke(ideal, s * R(0.004, 0.012), R(-0.12, 0.15)), ideal };
  }, 60, 12);
});

test("straight lines become ruler-straight, level when nearly level", () => {
  expectShape("line", () => {
    const len = R(60, 500);
    const ang = rand() < 0.5 ? R(-0.05, 0.05) : R(0, Math.PI * 2);
    const x = R(0, 400);
    const y = R(0, 400);
    const drawn: Array<[number, number]> = [[x, y], [x + Math.cos(ang) * len, y + Math.sin(ang) * len]];
    // Within 4 degrees of level or upright it is straightened, like a ruler.
    const q = Math.round(ang / (Math.PI / 2)) * (Math.PI / 2);
    const a = Math.abs(ang - q) <= (4 * Math.PI) / 180 ? q : ang;
    const ideal: Array<[number, number]> = [[x, y], [x + Math.cos(a) * len, y + Math.sin(a) * len]];
    return { stroke: handDrawn(drawn, R(0.5, 2)), ideal };
  }, 60, 8);
  // Nearly level comes out exactly level.
  const r = recognizeShape(handDrawn([[0, 100], [300, 108]], 1), { minSize: 20 })!;
  assert.equal(r.kind, "line");
  assert.ok(Math.abs(r.points[0][1] - r.points[r.points.length - 1][1]) < 1e-6, "level");
});

test("pentagons and hexagons keep their corners", () => {
  for (const sides of [5, 6] as const) {
    expectShape(sides === 5 ? "pentagon" : "hexagon", () => {
      const r = R(90, 200);
      const cx = R(0, 400);
      const cy = R(0, 400);
      const off = rand() * Math.PI;
      const ideal: Array<[number, number]> = [];
      for (let i = 0; i < sides; i++) ideal.push([cx + r * Math.cos(off + (i / sides) * Math.PI * 2), cy + r * Math.sin(off + (i / sides) * Math.PI * 2)]);
      return { stroke: closedStroke(ideal, r * 0.006, R(-0.1, 0.1)), ideal };
    }, 30, 14);
  }
});

test("handwriting, arcs, zig-zags and scribbles are left as drawn", () => {
  // Cursive-like loops along a line.
  expectNone(() => {
    const pts: Array<[number, number]> = [];
    const x0 = R(0, 300);
    for (let t = 0; t < 200; t++) pts.push([x0 + t * 1.5 + Math.cos(t / 5) * 10, 100 + Math.sin(t / 5) * 18]);
    return handDrawn(pts, 0.5);
  });
  // An open arc (a "C").
  expectNone(() => {
    const pts: Array<[number, number]> = [];
    const r = R(40, 120);
    const span = R(Math.PI * 0.5, Math.PI * 1.3);
    for (let i = 0; i <= 60; i++) pts.push([200 + r * Math.cos(0.3 + (i / 60) * span), 200 + r * Math.sin(0.3 + (i / 60) * span)]);
    return handDrawn(pts, r * 0.01);
  });
  // A zig-zag.
  expectNone(() => {
    const pts: Array<[number, number]> = [];
    for (let i = 0; i < 8; i++) pts.push([i * R(20, 40), i % 2 ? 0 : R(30, 60)]);
    return handDrawn(pts, 0.5);
  });
  // A dense scribble back and forth.
  expectNone(() => {
    const pts: Array<[number, number]> = [];
    for (let i = 0; i < 12; i++) pts.push([100 + (i % 2 ? 80 : 0) + R(-5, 5), 100 + i * 3]);
    return handDrawn(pts, 0.5);
  });
  // An "L" (two sides only).
  expectNone(() => handDrawn([[0, 0], [0, R(80, 200)], [R(80, 200), R(80, 200)]], 0.8));
});

test("rounded corners and sloppy closing still read as the shape", () => {
  // A square drawn with rounded corners (how most hands draw one).
  expectShape("square", () => {
    const s = R(80, 220);
    const x = R(0, 400);
    const y = R(0, 400);
    const rr = s * R(0.05, 0.12);
    const out: Array<[number, number]> = [];
    const corners: Array<[number, number, number]> = [
      [x + s - rr, y + rr, -Math.PI / 2],
      [x + s - rr, y + s - rr, 0],
      [x + rr, y + s - rr, Math.PI / 2],
      [x + rr, y + rr, Math.PI],
    ];
    for (const [cx, cy, a0] of corners) for (let k = 0; k <= 6; k++) out.push([cx + rr * Math.cos(a0 + (k / 6) * (Math.PI / 2)), cy + rr * Math.sin(a0 + (k / 6) * (Math.PI / 2))]);
    const ideal: Array<[number, number]> = [[x, y], [x + s, y], [x + s, y + s], [x, y + s]];
    return { stroke: closedStroke(out, s * 0.008, R(-0.05, 0.1)), ideal };
  }, 40, 12);
  // A wobblier circle, closed with a larger gap.
  expectShape("circle", () => {
    const r = R(50, 150);
    const ideal = circleOutline(200, 200, r, r);
    return { stroke: closedStroke(ideal, r * 0.06, -0.1), ideal };
  }, 40, 0.15 * 150);
});

test("a star, a heart, a figure-8, a spiral and a letter D are left as drawn", () => {
  expectNone(() => {
    const pts: Array<[number, number]> = [];
    const r = R(60, 150);
    for (let i = 0; i < 10; i++) {
      const rad = i % 2 ? r * 0.4 : r;
      pts.push([200 + rad * Math.cos(-Math.PI / 2 + (i / 10) * Math.PI * 2), 200 + rad * Math.sin(-Math.PI / 2 + (i / 10) * Math.PI * 2)]);
    }
    return closedStroke(pts, r * 0.005, 0.02);
  }, 30);
  expectNone(() => {
    const pts: Array<[number, number]> = [];
    const k = R(4, 7);
    for (let i = 0; i < 80; i++) {
      const t = (i / 80) * Math.PI * 2;
      pts.push([200 + k * 16 * Math.sin(t) ** 3, 200 - k * (13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t))]);
    }
    return closedStroke(pts, 1, 0.02);
  }, 30);
  expectNone(() => {
    const pts: Array<[number, number]> = [];
    const r = R(40, 90);
    for (let i = 0; i < 80; i++) {
      const t = (i / 80) * Math.PI * 2;
      pts.push([200 + r * Math.sin(t), 200 + r * Math.sin(t) * Math.cos(t) * 2]);
    }
    return closedStroke(pts, 0.5, 0.02);
  }, 30);
  expectNone(() => {
    const pts: Array<[number, number]> = [];
    for (let i = 0; i < 120; i++) {
      const t = (i / 120) * Math.PI * 5;
      pts.push([200 + t * 8 * Math.cos(t), 200 + t * 8 * Math.sin(t)]);
    }
    return handDrawn(pts, 0.5);
  }, 30);
  expectNone(() => {
    const h = R(80, 160);
    const pts: Array<[number, number]> = [[100, 100], [100, 100 + h]];
    for (let i = 0; i <= 20; i++) {
      const t = Math.PI / 2 - (i / 20) * Math.PI;
      pts.push([100 + (h / 2) * 1.1 * Math.cos(t), 100 + h / 2 + (h / 2) * Math.sin(-t)]);
    }
    return handDrawn(pts, 0.6);
  }, 30);
});

test("tiny marks are never shapes (a dot, a letter o)", () => {
  assert.equal(recognizeShape(closedStroke(circleOutline(10, 10, 6, 6), 0.2, 0), { minSize: 20 }), null);
});

test("output stays in the stroke's own coordinates and is closed", () => {
  const ideal = circleOutline(300, 200, 80, 80);
  const r = recognizeShape(closedStroke(ideal, 1, 0.02), { minSize: 20 })!;
  assert.equal(r.kind, "circle");
  const a = r.points[0];
  const b = r.points[r.points.length - 1];
  assert.ok(Math.hypot(a[0] - b[0], a[1] - b[1]) < 1e-6, "ends meet");
  assert.ok(r.points.every((p) => p[2] > 0 && p[2] <= 1), "pressure kept sensible");
});

test("real strokes drawn by hand: every shape meant is found, the rest left alone", () => {
  const file = path.join(process.cwd(), "tests", "fixtures", "shape_user_strokes.json");
  const { strokes } = JSON.parse(fs.readFileSync(file, "utf8")) as {
    strokes: Array<{ id: string; expect: string; points: Pt[] }>;
  };
  const wrong: string[] = [];
  for (const s of strokes) {
    const r = recognizeShape(s.points, { minSize: 28 });
    const got = r ? r.kind : "none";
    if (!s.expect.split("|").includes(got)) wrong.push(`${s.id}: ${got} (want ${s.expect})`);
  }
  assert.deepEqual(wrong, []);
});

test("an overshoot, a tail past the start or a crossing still closes the shape", () => {
  // A square whose pen runs on a quarter side past where it began.
  const sq: Array<[number, number]> = [[0, 0], [200, 0], [200, 200], [0, 200], [0, 0], [120, 0]];
  assert.equal(recognizeShape(handDrawn(sq, 1), { minSize: 20 })?.kind, "square");
  // A circle that crosses over its start and carries on.
  const c = circleOutline(200, 200, 90, 90);
  const loop = [...c, ...c.slice(0, 14)];
  assert.equal(recognizeShape(handDrawn(loop, 1.5), { minSize: 20 })?.kind, "circle");
});

test("lines drawn one after another join at clean corners", () => {
  // The first line ran a little past the corner; the second starts short of it.
  const first = { id: "a", line: [[0, 0], [212, 3]] as [[number, number], [number, number]] };
  const j = joinLine([195, 14], [201, 180], [first], 30);
  const corner = j.start;
  assert.ok(Math.abs(corner[1] - (corner[0] * 3) / 212) < 0.5, "the corner is on the first line");
  assert.equal(j.adjust.length, 1, "the first line is trimmed to the corner");
  assert.deepEqual(j.adjust[0].to, corner);
  assert.equal(j.adjust[0].end, 1);
  // Far away: nothing moves.
  const far = joinLine([400, 400], [500, 500], [first], 30);
  assert.deepEqual([far.start, far.end, far.adjust.length], [[400, 400], [500, 500], 0]);
  // Near a triangle's corner: the end lands on it.
  const tri = { id: "t", corners: [[50, 50], [150, 50], [100, 130]] as [number, number][] };
  assert.deepEqual(joinLine([148, 56], [300, 60], [tri], 20).start, [150, 50]);
});

console.log(`  ${passed} passed, ${failed} failed`);
if (failed > 0) process.exit(1);
