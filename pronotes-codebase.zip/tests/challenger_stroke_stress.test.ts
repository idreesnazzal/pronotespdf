import assert from "node:assert/strict";
import {
  getSvgPathFromStroke,
  buildStrokePath,
  pruneTerminalHooks,
  computePressureFromSpeed,
  getStrokeOptionsForStyle,
  getArrowheadPath,
} from "../src/lib/whiteboard/stroke";
import { PEN_TYPE_PRESETS, type StrokeElement } from "../src/lib/whiteboard/types";

console.log("===================================================================");
console.log("=== RUNNING CHALLENGER STRESS SUITE: STROKE & B-SPLINE ENGINE   ===");
console.log("===================================================================");

let totalChecks = 0;
function pass(msg: string) {
  totalChecks++;
  // console.log(`  ✓ ${msg}`);
}

// ----------------------------------------------------------------------------
// Section 1: getSvgPathFromStroke Adversarial Edge Cases
// ----------------------------------------------------------------------------
console.log("\n[Section 1] getSvgPathFromStroke Boundary & Topology Stress Tests...");

// 1.1 Empty array
assert.equal(getSvgPathFromStroke([]), "", "Empty point array must return empty string");
assert.equal(getSvgPathFromStroke([], false), "", "Empty point array (open) must return empty string");
pass("0 points returns empty string");

// 1.2 Single point
const p1_default = getSvgPathFromStroke([[50, 60]]);
assert.ok(p1_default.startsWith("M 49.00,60.00"), "Single point must return mini circle starting at (x-1, y)");
assert.ok(p1_default.endsWith("Z"), "Single point must end with Z");
assert.ok(!p1_default.includes("NaN"), "Single point path must not contain NaN");

const p1_neg = getSvgPathFromStroke([[-100.5, -200.75]]);
assert.ok(!p1_neg.includes("NaN"), "Negative single point must not contain NaN");
pass("1 point generates valid SVG circle path without NaN");

// 1.3 Two points
const p2_closed = getSvgPathFromStroke([[10, 20], [30, 40]], true);
assert.equal(p2_closed, "M 10.00,20.00 L 30.00,40.00 Z", "2 points closed must return M p0 L p1 Z");

const p2_open = getSvgPathFromStroke([[10, 20], [30, 40]], false);
assert.equal(p2_open, "M 10.00,20.00 L 30.00,40.00 Z", "2 points open must return M p0 L p1 Z");
pass("2 points returns valid closed line M...L...Z");

// 1.4 Three points (Triangle polygon)
const tri = [[0, 0], [100, 0], [50, 80]];
const triClosed = getSvgPathFromStroke(tri, true);
// Start midpoint: (tri[0] + tri[2])/2 = (25, 40)
assert.ok(triClosed.startsWith("M 25.00,40.00"), "Triangle closed must start at midpoint of p2 and p0");
// A triangle's corners are far sharper than the 130-degree threshold, so the
// path must be routed THROUGH each vertex. Rounding them (the old behaviour)
// cut the corners off, which is what blunted the end of every stroke.
assert.ok(triClosed.includes("L 0.00,0.00"), "sharp vertex p0 reached, not rounded away");
assert.ok(triClosed.includes("L 100.00,0.00"), "sharp vertex p1 reached, not rounded away");
assert.ok(triClosed.includes("L 50.00,80.00"), "sharp vertex p2 reached, not rounded away");
assert.ok(triClosed.endsWith("Z"), "Triangle closed must end with Z");

const triOpen = getSvgPathFromStroke(tri, false);
assert.ok(triOpen.startsWith("M 0.00,0.00"), "Open 3-pt path must start at p0");
assert.ok(triOpen.includes("L 50.00,80.00"), "Open path must end with L pLast");
pass("3 points closed and open: sharp vertices preserved, ends with Z");

// 1.5 Collinear Points
const horizPoints = Array.from({ length: 20 }, (_, i) => [i * 10, 50]);
const horizPath = getSvgPathFromStroke(horizPoints, true);
assert.ok(!horizPath.includes("NaN") && !horizPath.includes("Infinity"), "Horizontal collinear must have no NaN/Inf");
assert.ok(horizPath.endsWith("Z"), "Horizontal collinear must end with Z");

const vertPoints = Array.from({ length: 20 }, (_, i) => [50, i * 10]);
const vertPath = getSvgPathFromStroke(vertPoints, true);
assert.ok(!vertPath.includes("NaN") && !vertPath.includes("Infinity"), "Vertical collinear must have no NaN/Inf");

const diagPoints = Array.from({ length: 50 }, (_, i) => [i * 5.5, i * 5.5]);
const diagPath = getSvgPathFromStroke(diagPoints, true);
assert.ok(!diagPath.includes("NaN"), "Diagonal collinear must have no NaN");
pass("Collinear points (horizontal, vertical, diagonal) generate smooth valid paths");

// 1.6 Duplicate Coordinates & Zero Distance
const dupPoints = [[10, 10], [10, 10], [10, 10], [10, 10]];
const dupPath = getSvgPathFromStroke(dupPoints, true);
assert.ok(!dupPath.includes("NaN"), "Duplicate coordinates must not produce NaN");
assert.equal(dupPath.match(/Q 10\.00,10\.00 10\.00,10\.00/g)?.length, 4, "Duplicate coordinates produce 4 quad segments smoothly");

const mixedDup = [[0, 0], [0, 0], [100, 100], [100, 100], [200, 0]];
const mixedDupPath = getSvgPathFromStroke(mixedDup, true);
assert.ok(!mixedDupPath.includes("NaN"), "Mixed duplicate coordinates produce valid path");

const microPoints = [[0, 0], [1e-8, 1e-8], [2e-8, 2e-8], [3e-8, 3e-8]];
const microPath = getSvgPathFromStroke(microPoints, true);
assert.ok(!microPath.includes("NaN"), "Micro-distance coordinates produce valid path");
pass("Duplicate and micro-distance coordinates handled with zero division error");

// 1.7 Self-Intersecting Polygons (Figure-8, Star, Spirals, Zigzag)
const figure8 = [[0, 0], [100, 100], [100, 0], [0, 100]];
const fig8Path = getSvgPathFromStroke(figure8, true);
assert.ok(!fig8Path.includes("NaN") && fig8Path.endsWith("Z"), "Figure-8 path generated cleanly");

// 5-Point Star
const starPoly = [
  [50, 0], [20, 100], [95, 35], [5, 35], [80, 100]
];
const starPath = getSvgPathFromStroke(starPoly, true);
assert.ok(!starPath.includes("NaN") && starPath.endsWith("Z"), "Self-intersecting star polygon generated cleanly");

// Tight zigzag with 180-deg reversal
const zigzag: number[][] = [];
for (let i = 0; i < 50; i++) {
  zigzag.push([i * 4, (i % 2 === 0) ? 0 : 50]);
}
const zigzagPath = getSvgPathFromStroke(zigzag, true);
assert.ok(!zigzagPath.includes("NaN") && zigzagPath.endsWith("Z"), "Zigzag path generated cleanly");
pass("Self-intersecting loops and tight reversals generate valid SVG paths");

// 1.8 Massive Point Sets (1,000 to 10,000 points - Stress & Benchmark)
const largePts1k: number[][] = Array.from({ length: 1000 }, (_, i) => {
  const theta = (i / 1000) * Math.PI * 2;
  return [500 + Math.cos(theta) * 200, 500 + Math.sin(theta) * 200];
});

const t0 = performance.now();
const path1k = getSvgPathFromStroke(largePts1k, true);
const t1 = performance.now();
assert.ok(!path1k.includes("NaN"), "1k points must have no NaN");
assert.ok(t1 - t0 < 50, `1k points B-spline generation took ${(t1 - t0).toFixed(2)}ms (expected < 50ms)`);

const largePts10k: number[][] = Array.from({ length: 10000 }, (_, i) => [i, Math.sin(i * 0.05) * 50]);
const t2 = performance.now();
const path10k = getSvgPathFromStroke(largePts10k, true);
const t3 = performance.now();
assert.ok(!path10k.includes("NaN"), "10k points must have no NaN");
assert.ok(t3 - t2 < 100, `10k points B-spline generation took ${(t3 - t2).toFixed(2)}ms (expected < 100ms)`);
pass(`Massive point sets (1k & 10k points) passed benchmark in ${(t3 - t2).toFixed(2)}ms`);

// ----------------------------------------------------------------------------
// Section 2: buildStrokePath - Single-Tap Dots & Micro-Jitter Stress
// ----------------------------------------------------------------------------
console.log("\n[Section 2] buildStrokePath Single-Tap Dots, Jitter & Stroke Width Stress...");

const makeStroke = (points: [number, number, number][], strokeWidth: number, strokeStyle = "pen"): StrokeElement => ({
  id: "test-stroke",
  type: "stroke",
  x: 100,
  y: 100,
  rotation: 0,
  opacity: 1,
  points,
  color: "#000000",
  strokeWidth,
  strokeStyle: strokeStyle as any,
  createdAt: Date.now(),
  updatedAt: Date.now(),
});

// 2.1 Empty stroke
assert.equal(buildStrokePath(makeStroke([], 2)), "", "Empty stroke must return empty string");
pass("Empty stroke element returns empty string");

// 2.2 Stroke Width Matrix for 1-point tap: [1, 2, 4, 10, 24, 50, 100]
const widths = [1, 2, 4, 10, 24, 50, 100];
for (const w of widths) {
  const el = makeStroke([[0, 0, 0.5]], w);
  const path = buildStrokePath(el);
  const expectedRadius = Math.max(w / 2, 2);
  const expectedRStr = expectedRadius.toFixed(2);
  const expectedDiamStr = (expectedRadius * 2).toFixed(2);
  
  assert.ok(path.startsWith(`M -${expectedRStr},0.00`), `Width ${w} should start at -${expectedRStr}`);
  assert.ok(path.includes(`a ${expectedRStr},${expectedRStr} 0 1,0 ${expectedDiamStr},0`), `Width ${w} should have arc with diameter ${expectedDiamStr}`);
  assert.ok(path.endsWith("Z"), `Width ${w} must end with Z`);
  assert.ok(!path.includes("NaN"), `Width ${w} must have no NaN`);
}
pass("Single-tap dots render exact circles for all stroke widths (1px to 100px)");

// 2.3 Degenerate stroke widths (0, negative)
const elZero = makeStroke([[0, 0, 0.5]], 0);
const pathZero = buildStrokePath(elZero);
assert.ok(pathZero.includes("a 2.00,2.00"), "0 strokeWidth clamps to radius 2");

const elNeg = makeStroke([[0, 0, 0.5]], -10);
const pathNeg = buildStrokePath(elNeg);
assert.ok(pathNeg.includes("a 2.00,2.00"), "Negative strokeWidth clamps to radius 2");
pass("Degenerate stroke widths (0, negative) safely clamped to minimum radius 2");

// 2.4 Micro-Jitter Tap Testing (0.5px, 1.5px, 3.0px, 10.0px)
// Jitter: 2 points with 0.5px distance
const elJitter05 = makeStroke([[0, 0, 0.5], [0.3, 0.4, 0.5]], 4); // dist = 0.5
const path05 = buildStrokePath(elJitter05);
assert.ok(path05.includes("a 2.00,2.00"), "0.5px jitter renders solid circle");

// Jitter: 2 points with 1.5px distance
const elJitter15 = makeStroke([[0, 0, 0.5], [0.9, 1.2, 0.5]], 4); // dist = 1.5
const path15 = buildStrokePath(elJitter15);
assert.ok(path15.includes("a 2.00,2.00"), "1.5px jitter renders solid circle");

// Jitter: 3 points within 3.0px bounding span
const elJitter30 = makeStroke([[0, 0, 0.5], [1.5, 1.0, 0.5], [2.0, 2.0, 0.5]], 4); // span ~2.83px
const path30 = buildStrokePath(elJitter30);
assert.ok(path30.includes("a 2.00,2.00"), "3.0px jitter renders solid circle");

// Jitter with large strokeWidth (e.g. strokeWidth = 50, dotThreshold = max(4, 50*0.6) = 30px)
const elJitterLargeW = makeStroke([[0, 0, 0.5], [5, 8, 0.5], [10, 10, 0.5]], 50); // span ~14.14px < 30px
const pathLargeW = buildStrokePath(elJitterLargeW);
assert.ok(pathLargeW.includes("a 25.00,25.00"), "14px jitter with 50px stroke width renders solid circle radius 25");

// High jitter: 2 points with 10.0px distance with 2px stroke (span 10 > 4, but length <= 2 and span < 6 -> false, getStroke called)
const elJitter10 = makeStroke([[0, 0, 0.5], [6, 8, 0.5]], 2);
const path10 = buildStrokePath(elJitter10);
assert.ok(path10.length > 0 && path10.startsWith("M ") && path10.endsWith("Z"), "10px movement generates full stroke path or fallback circle");
pass("Micro-jitter taps (0.5px, 1.5px, 3.0px, 10px) correctly resolved without collapsing to 0 area");

// ----------------------------------------------------------------------------
// Section 3: All 6 Pen Presets Stress Testing
// ----------------------------------------------------------------------------
console.log("\n[Section 3] All 6 Pen Presets (Pen, Highlighter, Marker, Brush, Calligraphy, Pencil)...");

const allPresets = ["pen", "highlighter", "marker", "brush", "calligraphy", "pencil"] as const;

for (const preset of allPresets) {
  // Check options
  const opt = getStrokeOptionsForStyle(preset, 4, true);
  assert.ok(opt.size !== undefined && opt.size > 0, `${preset} size must be > 0`);
  assert.ok(opt.start?.taper !== undefined, `${preset} start taper defined`);
  assert.ok(opt.end?.taper !== undefined, `${preset} end taper defined`);
  
  if (preset === "highlighter") {
    assert.equal(opt.size, 12, "Highlighter size multiplier 3x applied");
  }

  // 1. Single dot for preset
  const dot = makeStroke([[0, 0, 0.5]], 4, preset);
  const dotPath = buildStrokePath(dot);
  assert.ok(dotPath.includes("a 2.00,2.00") && dotPath.endsWith("Z"), `${preset} single dot must render circle`);

  // 2. Short 3-point stroke
  const shortStroke = makeStroke([[0, 0, 0.5], [10, 5, 0.6], [25, 12, 0.7]], 6, preset);
  const shortPath = buildStrokePath(shortStroke);
  assert.ok(shortPath.length > 0 && shortPath.startsWith("M ") && shortPath.endsWith("Z"), `${preset} short stroke valid`);

  // 3. Medium S-curve stroke
  const medStroke = makeStroke([
    [0, 0, 0.5],
    [30, 20, 0.6],
    [70, 80, 0.8],
    [120, 60, 0.5],
    [180, 100, 0.3],
    [240, 150, 0.2],
  ], 8, preset);
  const medPath = buildStrokePath(medStroke);
  assert.ok(medPath.length > 0 && medPath.startsWith("M ") && medPath.endsWith("Z"), `${preset} medium stroke valid`);
  assert.ok(!medPath.includes("NaN"), `${preset} medium stroke has no NaN`);

  // 4. Draft mode (isDraft = true)
  const draftPath = buildStrokePath(medStroke, true);
  assert.ok(draftPath.length > 0 && draftPath.startsWith("M ") && draftPath.endsWith("Z"), `${preset} draft mode valid`);
}

// Fallback for unknown preset
const unknownOpt = getStrokeOptionsForStyle("unknown_fancy_pen", 5);
assert.equal(unknownOpt.size, 5, "Unknown preset falls back to pen size");
const unknownStroke = makeStroke([[0, 0, 0.5], [20, 20, 0.5], [50, 50, 0.5]], 5, "unknown_fancy_pen");
const unknownPath = buildStrokePath(unknownStroke);
assert.ok(unknownPath.length > 0 && unknownPath.endsWith("Z"), "Unknown preset produces valid stroke");
pass("All 6 pen presets and unknown fallback tested under dots, short, medium, and draft modes");

// ----------------------------------------------------------------------------
// Section 4: Terminal Hook Pruning & Speed-Based Pressure
// ----------------------------------------------------------------------------
console.log("\n[Section 4] Terminal Hook Pruning & Speed-Based Pressure Math...");

// 4.1 pruneTerminalHooks
assert.deepEqual(pruneTerminalHooks([]), [], "Empty array safe");
assert.deepEqual(pruneTerminalHooks([[0, 0, 0.5]]), [[0, 0, 0.5]], "1 point safe");
assert.deepEqual(pruneTerminalHooks([[0, 0, 0.5], [10, 0, 0.5]]), [[0, 0, 0.5], [10, 0, 0.5]], "2 points safe");
assert.deepEqual(pruneTerminalHooks([[0, 0, 0.5], [10, 0, 0.5], [20, 0, 0.5]]), [[0, 0, 0.5], [10, 0, 0.5], [20, 0, 0.5]], "3 points safe");

// 4 points with sharp 180-deg reversal hook (< 45px tail)
const hookedPoints: [number, number, number][] = [
  [0, 0, 0.5],
  [50, 0, 0.5],
  [100, 0, 0.5],
  [85, 0, 0.5], // turns back by 15px
];
const unhooked = pruneTerminalHooks(hookedPoints);
assert.equal(unhooked.length, 3, "Sharp trailing tail hook pruned");
assert.deepEqual(unhooked[2], [100, 0, 0.5], "Last point is now the true peak");

// 4 points continuing forward (smooth line) -> NOT pruned
const straightPts: [number, number, number][] = [
  [0, 0, 0.5],
  [50, 0, 0.5],
  [100, 0, 0.5],
  [150, 0, 0.5],
];
const keptStraight = pruneTerminalHooks(straightPts);
assert.equal(keptStraight.length, 4, "Straight stroke tail is NOT pruned");

// Smooth 45-deg curve -> NOT pruned
const curvePts: [number, number, number][] = [
  [0, 0, 0.5],
  [50, 0, 0.5],
  [100, 0, 0.5],
  [120, 20, 0.5],
];
const keptCurve = pruneTerminalHooks(curvePts);
assert.equal(keptCurve.length, 4, "Smooth curve tail is NOT pruned");
pass("Terminal hook filter prunes sharp reversals while preserving smooth curves and forward lines");

// 4.2 computePressureFromSpeed
assert.equal(computePressureFromSpeed([]), 0.5, "Empty points returns 0.5");
assert.equal(computePressureFromSpeed([[0, 0, 0.5]]), 0.5, "1 point returns 0.5");

// Stationary points (dist = 0) -> pressure = 0.52 - 0 = 0.52
const pStationary = computePressureFromSpeed([[0, 0, 0.5], [0, 0, 0.5]]);
assert.equal(pStationary, 0.52, "Zero speed returns maximum stationary pressure 0.52");

// Very high speed (dist = 100px >= 10px maxSpeed) -> t = 1 -> pressure = 0.52 - 0.08 = 0.44
const pFast = computePressureFromSpeed([[0, 0, 0.5], [100, 0, 0.5]]);
assert.equal(pFast, 0.44, "High speed returns minimum pressure 0.44");

// Moderate speed (dist = 5px = half maxSpeed) -> t = 0.5 -> pressure = 0.52 - 0.04 = 0.48
const pMed = computePressureFromSpeed([[0, 0, 0.5], [3, 4, 0.5]]); // dist = 5
assert.ok(Math.abs(pMed - 0.48) < 1e-6, "Medium speed returns interpolated pressure ~0.48");
pass("Speed-based pressure calculation is continuous and bounded in [0.44, 0.52]");

// 4.3 Arrowhead helper in stroke.ts
const arrowPath = getArrowheadPath(100, 100, 0, 10);
assert.ok(arrowPath.startsWith("M 100,100 L"), "Arrowhead helper produces valid polygon");
pass("Arrowhead path generator in stroke.ts verified");

console.log(`\n===================================================================`);
console.log(`=== STROKE STRESS SUITE: ALL ${totalChecks} ASSERTIONS PASSED (100%) ===`);
console.log(`===================================================================\n`);
