/**
 * Notebook × store integration.
 *
 * notebook.test.ts proves the pure page model. This proves the *wiring*: 34
 * places in the store used to touch `board.elements` directly, and every one
 * of them now has to route to the active page instead. A site that was missed
 * would write a stroke onto the canvas field of a notebook, where nothing
 * renders it — invisible data loss. These tests exercise the real store.
 */

import assert from "node:assert/strict";

import { useWhiteboard } from "../src/store/whiteboard";
import { migrateState } from "../src/lib/whiteboard/persistence";
import {
  getBoardElements,
  getPages,
  allElements,
  getActivePageIndex,
  PAGE_GAP,
  bookmarkedPages,
  pageSizeOf,
} from "../src/lib/whiteboard/notebook";
import type { Board, WhiteboardElement } from "../src/lib/whiteboard/types";
import {
  effectiveSelectFilter,
  passesSelectFilter,
  selectCategoryOf,
} from "../src/lib/whiteboard/types";

let passed = 0;
let failed = 0;
function test(name: string, fn: () => void) {
  try {
    fn();
    passed++;
    console.log(`  ✓ ${name}`);
  } catch (err) {
    failed++;
    console.error(`  ✗ ${name}`);
    console.error(`      ${(err as Error).message}`);
  }
}

const S = () => useWhiteboard.getState();
const board = (id: string): Board => S().boards.find((b) => b.id === id)!;

function rect(id: string, x = 0): WhiteboardElement {
  return {
    id,
    type: "rectangle",
    x,
    y: 0,
    width: 10,
    height: 10,
    angle: 0,
    strokeColor: "#000",
    backgroundColor: "transparent",
    fillStyle: "transparent",
    strokeWidth: 2,
    strokeStyle: "solid",
    dashStyle: "solid",
    opacity: 1,
    seed: 1,
    createdAt: Date.now(),
    updatedAt: Date.now(),
  } as unknown as WhiteboardElement;
}

/** A fresh notebook, made active, with `pageCount` pages. */
function freshNotebook(pageCount = 1): string {
  const id = S().createNotebook(`NB ${Math.random().toString(36).slice(2, 7)}`, null);
  S().setActiveBoard(id);
  for (let i = 1; i < pageCount; i++) S().addPage();
  return id;
}

console.log("\n── Notebook × store ──");

test("createNotebook produces a notebook with exactly one page", () => {
  const id = freshNotebook();
  assert.equal(board(id).kind, "notebook");
  assert.equal(getPages(board(id)).length, 1);
  assert.equal(board(id).pageSize, "a4");
});

test("a plain board is still a canvas", () => {
  const id = S().createBoard("Plain", null);
  assert.equal(board(id).kind, undefined);
});

test("addElement lands on the active page, never on the canvas field", () => {
  const id = freshNotebook(2); // page 2 is active after addPage
  S().addElement(rect("a"));

  assert.deepEqual(getBoardElements(board(id)).map((e) => e.id), ["a"]);
  assert.deepEqual(board(id).elements, [], "canvas field must stay empty");
  assert.deepEqual(getPages(board(id))[0].elements, [], "page 1 untouched");
  assert.deepEqual(getPages(board(id))[1].elements.map((e) => e.id), ["a"]);
});

test("ink drawn on one page does not appear on another", () => {
  const id = freshNotebook(3);
  S().addElement(rect("p3"));           // on page 3
  S().stepPage(-1);
  assert.deepEqual(getBoardElements(board(id)), [], "page 2 is blank");
  S().addElement(rect("p2"));
  S().stepPage(-1);
  assert.deepEqual(getBoardElements(board(id)), [], "page 1 is blank");

  assert.deepEqual(allElements(board(id)).map((e) => e.id), ["p2", "p3"].sort(), );
});

test("addElements (paste / multi-add) also lands on the active page", () => {
  const id = freshNotebook(2);
  S().addElements([rect("x"), rect("y")]);
  assert.deepEqual(getBoardElements(board(id)).map((e) => e.id), ["x", "y"]);
  assert.deepEqual(getPages(board(id))[0].elements, []);
});

test("updateElement edits the copy on the active page", () => {
  const id = freshNotebook();
  S().addElement(rect("a", 5));
  S().updateElement("a", { x: 99 } as never, false);
  assert.equal((getBoardElements(board(id))[0] as { x: number }).x, 99);
});

test("deleteElements removes from the active page only", () => {
  const id = freshNotebook();
  S().addElement(rect("keep"));
  S().addPage();
  S().addElement(rect("gone"));
  S().deleteElements(["gone"], false);

  assert.deepEqual(getBoardElements(board(id)), [], "page 2 emptied");
  assert.deepEqual(getPages(board(id))[0].elements.map((e) => e.id), ["keep"], "page 1 kept");
});

test("z-order actions reorder within the active page", () => {
  const id = freshNotebook();
  S().addElement(rect("a"));
  S().addElement(rect("b"));
  S().addElement(rect("c"));

  S().bringToFront(["a"]);
  assert.deepEqual(getBoardElements(board(id)).map((e) => e.id), ["b", "c", "a"]);

  S().sendToBack(["c"]);
  assert.deepEqual(getBoardElements(board(id)).map((e) => e.id), ["c", "b", "a"]);

  S().sendBackward(["a"]);
  assert.deepEqual(getBoardElements(board(id)).map((e) => e.id), ["c", "a", "b"]);

  S().bringForward(["c"]);
  assert.deepEqual(getBoardElements(board(id)).map((e) => e.id), ["a", "c", "b"]);
});

test("duplicateElements clones onto the same page", () => {
  const id = freshNotebook(2);
  S().addElement(rect("orig"));
  const made = S().duplicateElements(["orig"]);
  assert.equal(made.length, 1);
  assert.equal(getBoardElements(board(id)).length, 2);
  assert.deepEqual(getPages(board(id))[0].elements, [], "page 1 not touched");
});

test("selectAll selects only what is on the current page", () => {
  const id = freshNotebook();
  S().addElement(rect("a"));
  S().addPage();
  S().addElement(rect("b"));
  S().addElement(rect("c"));
  S().selectAll();
  assert.deepEqual(S().selectedIds.sort(), ["b", "c"]);
  assert.ok(board(id));
});

test("undo restores onto the page the edit happened on", () => {
  const id = freshNotebook(2);
  S().addElement(rect("first"));       // page 2, commits history
  S().addElement(rect("second"));      // page 2
  assert.equal(getBoardElements(board(id)).length, 2);

  S().undo();
  assert.deepEqual(
    getBoardElements(board(id)).map((e) => e.id),
    ["first"],
    "undo removed the second element from page 2"
  );
  assert.equal(getActivePageIndex(board(id)), 1, "and stayed on page 2");
  assert.deepEqual(getPages(board(id))[0].elements, [], "page 1 was never involved");
});

test("undo after turning the page edits the page the snapshot came from", () => {
  const id = freshNotebook(2);
  S().addElement(rect("onPage2"));
  S().setActivePage(getPages(board(id))[0].id); // turn back to page 1

  S().undo();

  assert.deepEqual(getPages(board(id))[1].elements, [], "page 2's element was undone");
  assert.deepEqual(getPages(board(id))[0].elements, [], "page 1 was not overwritten with page 2 content");
});

test("redo puts it back on the right page too", () => {
  const id = freshNotebook(2);
  S().addElement(rect("x"));
  S().undo();
  assert.deepEqual(getPages(board(id))[1].elements, []);
  S().redo();
  assert.deepEqual(getPages(board(id))[1].elements.map((e) => e.id), ["x"]);
  assert.deepEqual(getPages(board(id))[0].elements, []);
});

test("duplicateBoard copies every page with fresh element ids", () => {
  const id = freshNotebook();
  S().addElement(rect("p1"));
  S().addPage();
  S().addElement(rect("p2"));

  const copyId = S().duplicateBoard(id)!;
  const copy = board(copyId);

  assert.equal(getPages(copy).length, 2, "both pages copied");
  assert.equal(allElements(copy).length, 2);
  assert.deepEqual(copy.elements, [], "nothing stranded on the canvas field");

  const originalIds = allElements(board(id)).map((e) => e.id);
  for (const el of allElements(copy)) {
    assert.ok(!originalIds.includes(el.id), `copied element ${el.id} must not reuse an original id`);
  }
  const pageIds = getPages(copy).map((p) => p.id);
  for (const p of getPages(board(id))) {
    assert.ok(!pageIds.includes(p.id), "copied pages must not reuse page ids");
  }
});

test("search finds text on any page, not just the visible one", () => {
  const id = freshNotebook();
  S().addElement({ ...rect("t1"), type: "text", text: "alpha marker" } as never);
  S().addPage();
  S().addElement({ ...rect("t2"), type: "text", text: "beta marker" } as never);
  S().setActivePage(getPages(board(id))[0].id);

  const hits = S().searchBoards("beta marker");
  assert.ok(
    hits.some((h) => h.boardId === id),
    "text on page 2 must be findable while page 1 is open"
  );
});

test("page turns clear the selection so handles do not float over nothing", () => {
  const id = freshNotebook();
  S().addElement(rect("a"));
  S().selectAll();
  assert.deepEqual(S().selectedIds, ["a"]);
  S().addPage();
  assert.deepEqual(S().selectedIds, [], "selection cleared on the new page");
  assert.ok(board(id));
});

test("convertToNotebook turns a canvas into page 1, losing nothing", () => {
  const id = S().createBoard("Canvas with work", null);
  S().setActiveBoard(id);
  S().addElement(rect("drawn1"));
  S().addElement(rect("drawn2"));
  assert.equal(board(id).kind, undefined);

  S().convertToNotebook(id);

  assert.equal(board(id).kind, "notebook");
  assert.equal(getPages(board(id)).length, 1);
  assert.deepEqual(
    getBoardElements(board(id)).map((e) => e.id),
    ["drawn1", "drawn2"],
    "existing work became page 1"
  );
  assert.deepEqual(board(id).elements, [], "and is not left duplicated on the canvas field");
});

test("convertToNotebook is a no-op on something already a notebook", () => {
  const id = freshNotebook(3);
  S().addElement(rect("keep"));
  S().convertToNotebook(id);
  assert.equal(getPages(board(id)).length, 3, "pages not collapsed");
  assert.deepEqual(getBoardElements(board(id)).map((e) => e.id), ["keep"]);
});

test("converting clears history, since old entries name no page", () => {
  const id = S().createBoard("C", null);
  S().setActiveBoard(id);
  S().addElement(rect("a"));
  S().convertToNotebook(id);
  S().undo();
  assert.deepEqual(
    getBoardElements(board(id)).map((e) => e.id),
    ["a"],
    "a pre-conversion undo must not fire and blank page 1"
  );
});

test("setPageSize applies to the notebook without moving ink", () => {
  const id = freshNotebook();
  S().addElement(rect("a", 700));
  S().setPageSize("letter-landscape");
  assert.equal(board(id).pageSize, "letter-landscape");
  assert.equal((getBoardElements(board(id))[0] as { x: number }).x, 700, "ink untouched");
});

test("reanchorPage swaps the page and slides the camera so nothing jumps", () => {
  const id = freshNotebook(3);
  S().setActivePage(getPages(board(id))[0].id);
  const stride = 1123 + PAGE_GAP;

  // Scroll down past the bottom of page 1.
  S().setCamera({ x: 0, y: stride - 100, zoom: 1 });
  const before = S().camera.y;

  S().reanchorPage(1, stride);

  assert.equal(getActivePageIndex(board(id)), 1, "page 2 is now the anchored page");
  assert.equal(
    S().camera.y,
    before - stride,
    "camera slid by exactly one stride, so the view does not move"
  );
});

test("reanchorPage going back up is the exact inverse", () => {
  const id = freshNotebook(3);
  const stride = 1123 + PAGE_GAP;
  S().reanchorPage(1, stride);
  const midIndex = getActivePageIndex(board(id));
  const midY = S().camera.y;

  S().reanchorPage(-1, stride);

  assert.equal(getActivePageIndex(board(id)), midIndex - 1);
  assert.equal(S().camera.y, midY + stride, "returns to exactly where it was");
});

test("reanchorPage does nothing at the ends, so the camera cannot drift", () => {
  const id = freshNotebook(2);
  S().setActivePage(getPages(board(id))[0].id);
  const stride = 1123 + PAGE_GAP;
  const y = S().camera.y;

  S().reanchorPage(-1, stride); // already on page 1
  assert.equal(getActivePageIndex(board(id)), 0);
  assert.equal(S().camera.y, y, "camera untouched when the page cannot change");

  S().reanchorPage(1, stride);
  S().reanchorPage(1, stride); // already on the last page
  assert.equal(getActivePageIndex(board(id)), 1);
});

test("reanchorPage is a no-op on a canvas", () => {
  const id = S().createBoard("C", null);
  S().setActiveBoard(id);
  const y = S().camera.y;
  S().reanchorPage(1, 1163);
  assert.equal(S().camera.y, y);
  assert.equal(board(id).kind, undefined);
});

// --- bookmarks, insert-before, templates -------------------------------------

test("insert-before puts the new page ahead of the anchor and selects it", () => {
  const id = freshNotebook(3);
  const ids = getPages(board(id)).map((p) => p.id);

  S().addPageBefore(ids[1]);

  const after = getPages(board(id)).map((p) => p.id);
  assert.equal(after.length, 4);
  assert.equal(after[0], ids[0]);
  assert.equal(after[2], ids[1], "the anchor moved down one");
  assert.equal(S().boards.find((b) => b.id === id)!.activePageId, after[1], "new page is active");
});

test("insert-before on page 1 makes a new first page", () => {
  const id = freshNotebook(2);
  const first = getPages(board(id))[0].id;
  S().addPageBefore(first);
  assert.equal(getPages(board(id))[1].id, first);
  assert.equal(getActivePageIndex(board(id)), 0);
});

test("bookmarking a page shows it in the favourites list with its real number", () => {
  const id = freshNotebook(4);
  const ids = getPages(board(id)).map((p) => p.id);

  S().togglePageBookmark(ids[2]);

  const favs = bookmarkedPages(board(id));
  assert.equal(favs.length, 1);
  assert.equal(favs[0].index, 2, "keeps its position in the notebook, not in the filtered list");
  assert.equal(favs[0].page.id, ids[2]);
});

test("bookmarking toggles off and does not disturb the page", () => {
  const id = freshNotebook(2);
  S().addElement(rect("ink"));
  const pid = getPages(board(id))[1].id;

  S().togglePageBookmark(pid);
  assert.equal(bookmarkedPages(board(id)).length, 1);
  S().togglePageBookmark(pid);
  assert.equal(bookmarkedPages(board(id)).length, 0);
  assert.deepEqual(getBoardElements(board(id)).map((e) => e.id), ["ink"], "ink untouched");
});

test("bookmarking keeps the selection, since the page did not change", () => {
  const id = freshNotebook();
  S().addElement(rect("a"));
  S().selectAll();
  S().togglePageBookmark(getPages(board(id))[0].id);
  assert.deepEqual(S().selectedIds, ["a"]);
});

test("saving a page as a template copies its ink and paper", () => {
  const id = freshNotebook();
  S().addElement(rect("drawn"));
  S().setPageBackground(getPages(board(id))[0].id, { pattern: "lines" });

  S().savePageAsTemplate(getPages(board(id))[0].id, "Lecture sheet");

  const t = S().pageTemplates.find((x) => x.name === "Lecture sheet")!;
  assert.ok(t, "template saved");
  assert.equal(t.elements.length, 1);
  assert.equal(t.background?.pattern, "lines");
  assert.equal(t.width, 794);
  assert.equal(t.height, 1123);
});

test("a page built from a template gets fresh element ids", () => {
  const id = freshNotebook();
  S().addElement(rect("orig"));
  S().savePageAsTemplate(getPages(board(id))[0].id, "T");
  const tid = S().pageTemplates.find((x) => x.name === "T")!.id;

  S().addPageFromTemplate(tid);

  const pages = getPages(board(id));
  assert.equal(pages.length, 2);
  assert.equal(pages[1].elements.length, 1);
  assert.notEqual(
    pages[1].elements[0].id,
    pages[0].elements[0].id,
    "shared ids would make the two pages delete and select as one"
  );
});

test("a template can be used twice without the two pages aliasing", () => {
  const id = freshNotebook();
  S().addElement(rect("orig"));
  S().savePageAsTemplate(getPages(board(id))[0].id, "Twice");
  const tid = S().pageTemplates.find((x) => x.name === "Twice")!.id;

  S().addPageFromTemplate(tid);
  S().addPageFromTemplate(tid);

  const [, a, b] = getPages(board(id));
  assert.notEqual(a.elements[0].id, b.elements[0].id);
  assert.notEqual(a.id, b.id);
});

test("an image template is fitted to the sheet, never cropped, and starts locked", () => {
  const id = freshNotebook();
  // A wide image on a portrait A4 page must fit by width.
  S().createImageTemplate("scan", "data:image/png;base64,AAA", 1588, 1123);

  const t = S().pageTemplates.find((x) => x.name === "scan")!;
  const el = t.elements[0] as unknown as { width: number; height: number; x: number; y: number; locked: boolean };
  assert.ok(el.width <= 794 + 0.01 && el.height <= 1123 + 0.01, "fits inside the page");
  assert.ok(Math.abs(el.width - 794) < 0.01, "scaled to the limiting dimension");
  assert.ok(el.y > 0, "centred vertically rather than pinned to the top");
  assert.equal(el.locked, true, "a backdrop you write on top of");
});

test("deleting a template leaves existing pages alone", () => {
  const id = freshNotebook();
  S().addElement(rect("orig"));
  S().savePageAsTemplate(getPages(board(id))[0].id, "Doomed");
  const tid = S().pageTemplates.find((x) => x.name === "Doomed")!.id;
  S().addPageFromTemplate(tid);
  const before = getPages(board(id)).length;

  S().deletePageTemplate(tid);

  assert.equal(S().pageTemplates.find((x) => x.id === tid), undefined);
  assert.equal(getPages(board(id)).length, before, "the page it made survives");
});

test("adding from an unknown template id is a no-op", () => {
  const id = freshNotebook(2);
  const before = getPages(board(id)).length;
  S().addPageFromTemplate("nope");
  assert.equal(getPages(board(id)).length, before);
});

// --- split view --------------------------------------------------------------

test("opening a board beside the current one sets the reference pane", () => {
  const a = freshNotebook();
  const b = S().createBoard("Reference", null);
  S().setActiveBoard(a);

  S().setSplitBoard(b);
  assert.equal(S().splitBoardId, b);
});

test("a board cannot be split against itself", () => {
  const a = freshNotebook();
  S().setActiveBoard(a);
  S().setSplitBoard(null);

  S().setSplitBoard(a);
  assert.equal(S().splitBoardId, null, "the pane would not follow your edits, so the halves would disagree");
});

test("swapping moves the documents to the other side, editability unchanged", () => {
  const a = freshNotebook();
  const b = S().createBoard("Other", null);
  S().setSplitPair(a, b);
  S().setSplitRatio(0.3);

  S().swapSplit();

  assert.equal(S().splitSide, "right", "the editable document moved to the right slot");
  assert.equal(S().activeBoardId, a, "and is still the same document — this is not a focus change");
  assert.equal(S().splitBoardId, b);
  assert.ok(
    Math.abs(S().splitRatio - 0.7) < 1e-9,
    "the left slot is always splitRatio, so flipping it keeps each document its own width"
  );
});

test("swapping twice returns everything exactly where it started", () => {
  const a = freshNotebook();
  const b = S().createBoard("Other-b", null);
  S().setSplitPair(a, b);
  S().setSplitRatio(0.35);

  S().swapSplit();
  S().swapSplit();

  assert.equal(S().splitSide, "left");
  assert.equal(S().activeBoardId, a);
  assert.equal(S().splitBoardId, b);
  assert.ok(Math.abs(S().splitRatio - 0.35) < 1e-9);
});

test("swapping is not the same action as focusing the other pane", () => {
  const a = freshNotebook();
  const b = S().createBoard("Other-c", null);
  S().setSplitPair(a, b);

  S().swapSplit();
  const afterSwap = { active: S().activeBoardId, side: S().splitSide };

  S().setSplitPair(a, b);
  S().focusSplitSide("right");
  const afterFocus = { active: S().activeBoardId, side: S().splitSide };

  assert.equal(afterSwap.side, afterFocus.side, "both end up with the right slot editable-side");
  assert.notEqual(
    afterSwap.active,
    afterFocus.active,
    "but swap keeps the same document editable while focus hands over to the other"
  );
});

test("swapping with no split open does nothing", () => {
  const a = freshNotebook();
  S().setActiveBoard(a);
  S().setSplitBoard(null);
  S().swapSplit();
  assert.equal(S().activeBoardId, a);
  assert.equal(S().splitBoardId, null);
});

test("neither pane can be dragged away to nothing", () => {
  S().setSplitRatio(0.01);
  assert.equal(S().splitRatio, 0.2, "clamped, or the split looks broken with no way back");
  S().setSplitRatio(5);
  assert.equal(S().splitRatio, 0.8);
});

test("closing the split clears the reference board", () => {
  const a = freshNotebook();
  const b = S().createBoard("Other2", null);
  S().setActiveBoard(a);
  S().setSplitBoard(b);
  S().setSplitBoard(null);
  assert.equal(S().splitBoardId, null);
});

test("setSplitPair puts a chosen document on each side", () => {
  const a = S().createBoard("Left doc", null);
  const b = S().createBoard("Right doc", null);

  S().setSplitPair(a, b);

  assert.equal(S().activeBoardId, a, "the left document is the editable one");
  assert.equal(S().splitBoardId, b);
  assert.equal(S().splitSide, "left");
});

test("setSplitPair refuses the same document on both sides", () => {
  const a = S().createBoard("Only", null);
  S().setSplitBoard(null);
  S().setSplitPair(a, a);
  assert.equal(S().splitBoardId, null);
});

test("focusing the other pane makes it editable without moving either side", () => {
  const a = S().createBoard("L", null);
  const b = S().createBoard("R", null);
  S().setSplitPair(a, b);

  S().focusSplitSide("right");

  assert.equal(S().activeBoardId, b, "the right document is now editable");
  assert.equal(S().splitBoardId, a, "and the left one becomes the reference");
  assert.equal(S().splitSide, "right", "the editable pane is the right-hand slot");
});

test("focusing the side that is already editable does nothing", () => {
  const a = S().createBoard("L2", null);
  const b = S().createBoard("R2", null);
  S().setSplitPair(a, b);
  S().focusSplitSide("left");
  assert.equal(S().activeBoardId, a);
  assert.equal(S().splitBoardId, b);
});

test("each side keeps its own camera when focus moves between them", () => {
  const a = S().createBoard("CamA", null);
  const b = S().createBoard("CamB", null);
  S().setSplitPair(a, b);

  S().setCamera({ x: 111, y: 222, zoom: 1 });   // on A
  S().focusSplitSide("right");
  S().setCamera({ x: 333, y: 444, zoom: 1 });   // on B
  S().focusSplitSide("left");

  assert.equal(Math.round(S().camera.x), 111, "returning to A restores A's view");
  S().focusSplitSide("right");
  assert.equal(Math.round(S().camera.x), 333, "and B keeps its own");
});

test("focus does not switch while a text editor is open", () => {
  const a = S().createBoard("EditL", null);
  const b = S().createBoard("EditR", null);
  S().setSplitPair(a, b);
  S().addElement({ ...rect("t"), type: "text", text: "half typed" } as never);
  S().setEditingId("t");

  S().focusSplitSide("right");

  assert.equal(S().activeBoardId, a, "switching would discard the open edit");
  assert.equal(S().editingId, "t");
  S().setEditingId(null);
});

test("focus switches once the editor is closed", () => {
  const a = S().createBoard("EditL2", null);
  const b = S().createBoard("EditR2", null);
  S().setSplitPair(a, b);
  S().setEditingId(null);
  S().focusSplitSide("right");
  assert.equal(S().activeBoardId, b);
});

// --- components must read the same element list the store writes -------------
//
// The store was funnelled through getBoardElements when notebooks landed, but
// the COMPONENTS were not: they kept reading `board.elements`, which is empty
// for a notebook. These pin the store-side contract those components rely on.

test("a notebook's selection is findable through the funnel, not board.elements", () => {
  const id = freshNotebook();
  S().addElement(rect("sel"));
  S().setSelected(["sel"]);

  assert.deepEqual(board(id).elements, [], "the canvas field is empty for a notebook");
  assert.ok(
    getBoardElements(board(id)).find((e) => e.id === "sel"),
    "anything reading board.elements would show no properties for this selection"
  );
});

test("the editing target of a notebook is findable the same way", () => {
  const id = freshNotebook();
  S().addElement({ ...rect("t1"), type: "text", text: "hi" } as never);
  S().setEditingId("t1");

  assert.ok(
    getBoardElements(board(id)).find((e) => e.id === S().editingId),
    "otherwise double-clicking text in a notebook opens nothing"
  );
  S().setEditingId(null);
});

test("a document-wide count sees every page, so a notebook never reads as empty", () => {
  const id = freshNotebook();
  S().addElement(rect("p1"));
  S().addPage();
  S().addElement(rect("p2"));

  assert.equal(board(id).elements.length, 0, "the canvas field would report 0 elements");
  assert.equal(allElements(board(id)).length, 2);
});

// ---------------------------------------------------------------------------
// The camera cannot lose the page
// ---------------------------------------------------------------------------
// Panning sideways used to carry on forever, leaving you in empty space with
// the sheet nowhere on screen and no way back except zoom-to-fit. A whiteboard
// should do that; a notebook should not.

test("panning a notebook sideways forever cannot lose the page", () => {
  const id = freshNotebook();
  const { width } = pageSizeOf(board(id));

  for (let i = 0; i < 50; i++) S().panCamera(-400, 0);
  const far = S().camera.x;
  assert.ok(
    far <= width * 1.5 + 0.001,
    `camera.x ran to ${far}; it must stop near the page (width ${width})`
  );

  for (let i = 0; i < 50; i++) S().panCamera(400, 0);
  const near = S().camera.x;
  assert.ok(
    near >= -width * 0.5 - 0.001,
    `camera.x ran to ${near} the other way`
  );
});

test("the vertical camera is NOT bounded — that is how pages turn", () => {
  const id = freshNotebook(3);
  const { height } = pageSizeOf(board(id));
  S().setCamera({ y: height * 2 + PAGE_GAP * 2 });
  assert.ok(
    S().camera.y > height,
    "clamping Y would stop the notebook scrolling past the first sheet"
  );
});

test("a plain whiteboard stays unbounded", () => {
  const id = S().createBoard("Unbounded", null);
  S().setActiveBoard(id);
  for (let i = 0; i < 50; i++) S().panCamera(-400, 0);
  assert.ok(
    S().camera.x > 5000,
    `an infinite canvas must still pan forever, got ${S().camera.x}`
  );
});

test("panning DOWN past the last page cannot lose the notebook", () => {
  const id = freshNotebook(3);
  const { height } = pageSizeOf(board(id));
  const stride = height + PAGE_GAP;

  for (let i = 0; i < 60; i++) S().panCamera(0, -600);   // drag upward, forever
  const far = S().camera.y;
  // Active page is index 0, so the document ends at 2 strides + one page.
  assert.ok(
    far <= 2 * stride + height + height * 0.5 + 0.001,
    `camera.y ran to ${far}: the sheets would be off screen with no way back`
  );
});

test("panning UP past the first page cannot lose the notebook", () => {
  const id = freshNotebook(3);
  const { height } = pageSizeOf(board(id));
  const stride = height + PAGE_GAP;
  // addPage selects the page it adds, so page 3 is the anchor here — the
  // document extends two strides ABOVE the origin, not zero.
  const activeIndex = getActivePageIndex(board(id));
  const top = -(activeIndex * stride) - height * 0.5;

  for (let i = 0; i < 60; i++) S().panCamera(0, 600);
  assert.ok(
    S().camera.y >= top - 0.001,
    `camera.y ran to ${S().camera.y}, past the top bound ${top}`
  );
});

test("the bound follows the ACTIVE page, so later pages stay reachable", () => {
  const id = freshNotebook(5);
  const { height } = pageSizeOf(board(id));
  const stride = height + PAGE_GAP;
  // On the last page the document extends UPWARD from the anchor instead.
  const pages = getPages(board(id));
  S().setActivePage(pages[pages.length - 1].id);
  for (let i = 0; i < 60; i++) S().panCamera(0, 600);
  assert.ok(
    S().camera.y >= -(4 * stride) - height * 0.5 - 0.001,
    "scrolling back to page 1 from the last page must still be possible"
  );
});

// ---------------------------------------------------------------------------
// One Select tool with a "pick up" filter
// ---------------------------------------------------------------------------

test("each element kind lands in exactly one pick-up category", () => {
  assert.equal(selectCategoryOf({ type: "stroke" }), "ink");
  assert.equal(selectCategoryOf({ type: "text" }), "text");
  assert.equal(selectCategoryOf({ type: "sticky" }), "text");
  assert.equal(selectCategoryOf({ type: "image" }), "images");
  for (const t of ["rectangle", "ellipse", "diamond", "triangle", "star", "cloud", "line", "arrow"]) {
    assert.equal(selectCategoryOf({ type: t }), "shapes", t);
  }
  assert.equal(selectCategoryOf({ type: "connection" }), null, "connections are never swept up");
});

test("a malformed saved filter falls back to everything, never to nothing", () => {
  for (const bad of [undefined, null, 42, "ink", [], ["nonsense"], [{}]]) {
    assert.equal(effectiveSelectFilter(bad).size, 4, `for ${JSON.stringify(bad)}`);
  }
  const f = effectiveSelectFilter(["ink", "from-a-newer-build"]);
  assert.deepEqual([...f], ["ink"], "unknown entries are dropped, known ones kept");
});

test("Select All obeys the filter", () => {
  const id = freshNotebook();
  const stroke = { ...rect("s1"), type: "stroke", points: [[0, 0, 0.5]] } as unknown as WhiteboardElement;
  const text = { ...rect("t1"), type: "text", text: "hi" } as unknown as WhiteboardElement;
  S().addElement(stroke, true);
  S().addElement(text, true);
  S().addElement(rect("r1"), true);

  S().setTouchSettings({ selectFilter: ["ink"] });
  S().selectAll();
  assert.deepEqual(S().selectedIds, ["s1"], "only the handwriting");

  S().setTouchSettings({ selectFilter: ["text", "shapes"] });
  S().selectAll();
  assert.deepEqual(new Set(S().selectedIds), new Set(["t1", "r1"]));

  S().setTouchSettings({ selectFilter: undefined });
  S().selectAll();
  assert.equal(S().selectedIds.length, 3, "no filter selects everything");
  assert.ok(getBoardElements(board(id)).length >= 3);
});

test("passesSelectFilter rejects kinds that are switched off", () => {
  const onlyInk = effectiveSelectFilter(["ink"]);
  assert.equal(passesSelectFilter({ type: "stroke" }, onlyInk), true);
  assert.equal(passesSelectFilter({ type: "image" }, onlyInk), false);
});

// ---------------------------------------------------------------------------
// The "+" between pages
// ---------------------------------------------------------------------------

/** Where page `j` is on screen (world y minus camera y), in the anchored frame. */
function screenYOf(id: string, j: number): number {
  const b = board(id);
  const stride = pageSizeOf(b).height + PAGE_GAP;
  return (j - getActivePageIndex(b)) * stride - S().camera.y;
}

test("insertPageAt(0) adds a page ABOVE the first one", () => {
  const id = freshNotebook(3);
  const first = getPages(board(id))[0].id;
  S().insertPageAt(0);
  const pages = getPages(board(id));
  assert.equal(pages.length, 4);
  assert.equal(pages[1].id, first, "old first page pushed down to 2nd");
  assert.equal(getActivePageIndex(board(id)), 0, "the new page is active");
});

test("insertPageAt(length) adds a page BELOW the last one", () => {
  const id = freshNotebook(3);
  const last = getPages(board(id))[2].id;
  S().insertPageAt(3);
  const pages = getPages(board(id));
  assert.equal(pages[2].id, last);
  assert.equal(getActivePageIndex(board(id)), 3);
});

test("insertPageAt(k) puts it BETWEEN pages k-1 and k", () => {
  const id = freshNotebook(4);
  const [a, b, c, d] = getPages(board(id)).map((p) => p.id);
  S().insertPageAt(2);
  const ids = getPages(board(id)).map((p) => p.id);
  assert.deepEqual([ids[0], ids[1], ids[3], ids[4]], [a, b, c, d]);
  assert.equal(getActivePageIndex(board(id)), 2);
});

test("inserting between pages does not move anything above it on screen", () => {
  const id = freshNotebook(4);          // page 4 active
  S().setCamera({ y: 300 });
  const before0 = screenYOf(id, 0);
  const before1 = screenYOf(id, 1);
  S().insertPageAt(2);                  // between pages 2 and 3
  assert.ok(Math.abs(screenYOf(id, 0) - before0) < 1e-6, "page 1 stayed put");
  assert.ok(Math.abs(screenYOf(id, 1) - before1) < 1e-6, "page 2 stayed put");
  // And the new page sits right where page 3 used to begin.
  const b = board(id);
  const stride = pageSizeOf(b).height + PAGE_GAP;
  assert.ok(Math.abs(screenYOf(id, 2) - (before1 + stride)) < 1e-6, "new sheet fills the gap");
});

test("goToPage shows the TOP of the page", () => {
  const id = freshNotebook(3);
  S().setCamera({ zoom: 0.5 });
  const target = getPages(board(id))[0].id;
  S().goToPage(target, 1000);
  assert.equal(getActivePageIndex(board(id)), 0);
  // Page top (world 0) sits 24 px below the top of a 1000 px screen.
  const z = S().camera.zoom;
  const screenTop = (0 - S().camera.y) * z + 1000 / 2;
  assert.ok(Math.abs(screenTop - 24) < 1e-6, `page top at ${screenTop}px`);
});

test("movePage moves the page you DRAGGED to where you dropped it", () => {
  const id = freshNotebook(5);
  const ids = getPages(board(id)).map((p) => p.id);
  S().movePage(ids[0], 3);              // drag page 1 to position 4
  const after = getPages(board(id)).map((p) => p.id);
  assert.equal(after[3], ids[0], "page 1 landed at position 4");
  assert.deepEqual(after.filter((x) => x !== ids[0]), ids.slice(1), "others keep their order");
});

test("zoomToFit on a notebook fits the sheet width, not the ink", () => {
  // Fitting ink bounds on a sparse page lands at a random zoom per page; the
  // sheet is the stable frame.
  const id = freshNotebook();
  S().addElement(rect("dot"));
  S().zoomToFit({ width: 800, height: 1200 });
  const dim = pageSizeOf(board(id));
  const cam = S().camera;
  assert.ok(
    Math.abs(cam.zoom - (800 - 48) / dim.width) < 1e-9,
    `zoom fills the width, got ${cam.zoom}`
  );
  assert.equal(cam.x, dim.width / 2);
  assert.equal(cam.y, dim.height / 2, "stays anchored on the active page");
});

test("link legend visibility persists like the minimap", () => {
  S().setLegendOpen(true);
  try {
    const snap = S().getPersistedState() as unknown as Record<string, unknown>;
    assert.equal(snap.legendOpen, true, "saved with the workspace");
    const back = migrateState({ boards: [], ...snap, version: 1 } as never);
    assert.equal(
      (back as unknown as Record<string, unknown>).legendOpen,
      true,
      "survives the load path"
    );
  } finally {
    S().setLegendOpen(false);
  }
});

test("zoom controls visibility persists and defaults to shown", () => {
  assert.equal(S().zoomDockOpen, true, "shown by default");
  S().setZoomDockOpen(false);
  try {
    const snap = S().getPersistedState() as unknown as Record<string, unknown>;
    assert.equal(snap.zoomDockOpen, false, "saved with the workspace");
    const back = migrateState({ boards: [], ...snap, version: 1 } as never);
    assert.equal(
      (back as unknown as Record<string, unknown>).zoomDockOpen,
      false,
      "survives the load path"
    );
  } finally {
    S().setZoomDockOpen(true);
  }
});

test("new boards start with the app default paper", () => {
  const id = S().createBoard("DefTest", null);
  assert.equal(board(id).background?.pattern, "plain");
});

test("set as app default changes future boards, never past ones", () => {
  const before = S().createBoard("Before", null);
  S().setDefaultPaper({ pattern: "grid", size: 40 });
  try {
    const after = S().createBoard("After", null);
    assert.equal(board(after).background?.pattern, "grid");
    assert.equal(board(after).background?.size, 40);
    assert.equal(board(before).background?.pattern, "plain", "past boards keep theirs");
  } finally {
    S().setDefaultPaper({ pattern: "plain", size: 24 });
  }
});

test("board paper rewrites all pages only when asked", () => {
  const id = freshNotebook(2);
  S().setBoardBackground(id, { pattern: "grid" });
  assert.equal(board(id).background?.pattern, "grid");
  assert.equal(
    getPages(board(id))[0].background?.pattern,
    "plain",
    "pages keep their own paper by default"
  );
  S().setBoardBackground(id, { pattern: "lines" }, { allPages: true });
  assert.equal(getPages(board(id))[0].background?.pattern, "lines");
  assert.equal(getPages(board(id))[1].background?.pattern, "lines");
});

test("stamping the current board paper onto all pages matches every page", () => {
  // What the Settings "Apply to all pages" toggle does when flipped on.
  const id = freshNotebook(3);
  S().setBoardBackground(id, { pattern: "grid", size: 40 });
  const bg = board(id).background!;
  S().setBoardBackground(id, { ...bg }, { allPages: true });
  for (const p of getPages(board(id))) {
    assert.equal(p.background?.pattern, "grid");
    assert.equal(p.background?.size, 40);
  }
});

test("sidebar filing: boards and folders move, cycles and ghosts rejected", () => {
  const fa = S().createFolder("FileA", null);
  const fb = S().createFolder("FileB", fa);
  const id = S().createBoard("Filing", null);
  S().moveBoard(id, fa);
  assert.equal(board(id).folderId, fa, "board files into the folder");
  S().moveBoard(id, null);
  assert.equal(board(id).folderId, null, "board files back to the top level");
  // Into its own descendant: rejected while the nesting holds.
  S().moveFolder(fa, fb);
  assert.equal(
    S().folders.find((f) => f.id === fa)!.parentId,
    null,
    "a folder cannot move into its own subtree"
  );
  S().moveFolder(fa, fa);
  assert.equal(
    S().folders.find((f) => f.id === fa)!.parentId,
    null,
    "a folder cannot move into itself"
  );
  S().moveFolder(fb, null);
  assert.equal(S().folders.find((f) => f.id === fb)!.parentId, null);
  // Ghosts: no throw, nothing changes.
  S().moveBoard("ghost-board", fa);
  S().moveBoard(id, "ghost-folder");
  S().moveFolder("ghost-folder", fa);
  assert.equal(board(id).folderId, null);
});

console.log(`\n  ${passed} passed, ${failed} failed\n`);
if (failed > 0) process.exit(1);
