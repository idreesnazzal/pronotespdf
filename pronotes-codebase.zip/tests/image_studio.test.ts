/**
 * Image editing and locked-items mode.
 * - Edits are descriptions: an unedited picture draws exactly as before.
 * - Crop keeps the picture's scale and centre; flips carry the crop with them.
 * - Locked-items mode picks ONLY locked things; normal mode never does.
 */

import assert from "node:assert/strict";
import {
  boxForCrop,
  centeredAspectCrop,
  dragCrop,
  fitAspect,
  flipCrop,
  imageLayout,
  imageSvgMarkup,
  isFullCrop,
  isUnedited,
  MIN_CROP,
  normalizeCrop,
  quarterTurn,
} from "../src/lib/whiteboard/imageEdit";
import { fitWithin } from "../src/lib/whiteboard/imageImport";
import { pickableNow, type ImageElement } from "../src/lib/whiteboard/types";

let passed = 0;
let failed = 0;
function test(name: string, fn: () => void) {
  try {
    fn();
    passed++;
    console.log(`  ✓ ${name}`);
  } catch (err) {
    failed++;
    console.error(`  ✗ ${name}`);
    console.error(`      ${(err as Error).message}`);
  }
}
const near = (a: number, b: number, eps = 1e-6) => Math.abs(a - b) < eps;

console.log(String.fromCharCode(10) + "── Image studio & locked items ──");

function photo(extra: Partial<ImageElement> = {}): ImageElement {
  return {
    id: "p1",
    type: "image",
    x: 100,
    y: 100,
    width: 400,
    height: 300,
    rotation: 0,
    opacity: 1,
    createdAt: 0,
    updatedAt: 0,
    src: "data:image/png;base64,AAAA",
    naturalWidth: 4000,
    naturalHeight: 3000,
    ...extra,
  };
}

test("a picture with no edits counts as unedited (drawn the old way)", () => {
  assert.equal(isUnedited(photo()), true);
  assert.equal(isUnedited(photo({ crop: { x: 0, y: 0, w: 1, h: 1 }, filter: "none", frame: "square" })), true);
  assert.equal(isUnedited(photo({ flipX: true })), false);
  assert.equal(isUnedited(photo({ filter: "document" })), false);
  assert.equal(isUnedited(photo({ borderWidth: 2 })), false);
});

test("crops are clamped inside the picture and never vanish", () => {
  const c = normalizeCrop({ x: 0.9, y: -1, w: 0.5, h: 0 });
  assert.ok(c.x + c.w <= 1 + 1e-9 && c.y >= 0 && c.h >= MIN_CROP, JSON.stringify(c));
  assert.deepEqual(normalizeCrop(undefined), { x: 0, y: 0, w: 1, h: 1 });
  assert.deepEqual(normalizeCrop({ x: NaN, y: 0, w: 1, h: 1 }), { x: 0, y: 0, w: 1, h: 1 });
});

test("cropping keeps the scale and the centre: it takes away, never zooms", () => {
  const el = photo();
  const box = boxForCrop(el, { x: 0.25, y: 0.25, w: 0.5, h: 0.5 });
  assert.ok(near(box.width, 200) && near(box.height, 150), JSON.stringify(box));
  assert.ok(near(box.x + box.width / 2, 300) && near(box.y + box.height / 2, 250));
  // Uncropping a cropped picture brings back the whole photo at the same scale.
  const cropped = photo({ ...box, crop: { x: 0.25, y: 0.25, w: 0.5, h: 0.5 } });
  const back = boxForCrop(cropped, { x: 0, y: 0, w: 1, h: 1 });
  assert.ok(near(back.width, 400) && near(back.height, 300), JSON.stringify(back));
});

test("the crop is the inner viewBox, in the photo's own pixels", () => {
  const L = imageLayout(photo({ crop: { x: 0.1, y: 0.2, w: 0.5, h: 0.4 } }));
  assert.ok(near(L.viewBox.x, 400) && near(L.viewBox.y, 600) && near(L.viewBox.w, 2000) && near(L.viewBox.h, 1200));
  assert.equal(L.flip, "");
  assert.match(imageLayout(photo({ flipX: true })).flip, /scale\(-1 1\)/);
});

test("mirroring carries the kept window with the picture", () => {
  const c = { x: 0.1, y: 0.2, w: 0.3, h: 0.4 };
  const fx = flipCrop(c, "x");
  assert.ok(near(fx.x, 0.6) && fx.y === 0.2);
  assert.deepEqual(flipCrop(fx, "x").x.toFixed(6), c.x.toFixed(6));
  assert.ok(near(flipCrop(c, "y").y, 0.4));
});

test("quarter turns snap a hand-rotated picture and stay bounded", () => {
  assert.ok(near(quarterTurn(0, 1), Math.PI / 2));
  assert.ok(near(quarterTurn(0.1, 1), Math.PI / 2), "0.1 rad snaps to 0 first");
  let r = 0;
  for (let i = 0; i < 4; i++) r = quarterTurn(r, 1);
  assert.equal(r, 0);
  assert.ok(near(quarterTurn(0, -1), -Math.PI / 2));
});

test("dragging a corner resizes; dragging the middle moves; both stay inside", () => {
  const start = { x: 0.2, y: 0.2, w: 0.5, h: 0.5 };
  const se = dragCrop(start, "se", 0.1, 0.05, null);
  assert.ok(near(se.w, 0.6) && near(se.h, 0.55) && se.x === 0.2);
  const nw = dragCrop(start, "nw", 0.9, 0.9, null);
  assert.ok(nw.w >= MIN_CROP - 1e-9 && nw.h >= MIN_CROP - 1e-9, JSON.stringify(nw));
  const mv = dragCrop(start, "move", 5, -5, null);
  assert.ok(near(mv.x, 0.5) && near(mv.y, 0) && mv.w === 0.5);
});

test("a fixed ratio holds while dragging and when chosen", () => {
  const sq = centeredAspectCrop(1);
  assert.deepEqual(sq, { x: 0, y: 0, w: 1, h: 1 });
  const wide = centeredAspectCrop(2);
  assert.ok(near(wide.w / wide.h, 2) && near(wide.y, 0.25));
  const d = dragCrop({ x: 0.1, y: 0.1, w: 0.4, h: 0.4 }, "se", 0.3, 0.0, 1.5);
  assert.ok(near(d.w / d.h, 1.5), JSON.stringify(d));
  const f = fitAspect({ x: 0, y: 0, w: 1, h: 1 }, 0.5);
  assert.ok(near(f.w, 0.5) && near(f.h, 1));
  assert.equal(isFullCrop(f), false);
});

test("export draws the same crop, flip, look and frame as the canvas", () => {
  const svg = imageSvgMarkup(
    photo({ crop: { x: 0, y: 0, w: 0.5, h: 0.5 }, flipY: true, filter: "document", frame: "circle", borderWidth: 3 }),
    "data:image/png;base64,AAAA"
  );
  assert.match(svg, /viewBox="0 0 2000 1500"/);
  assert.match(svg, /scale\(1 -1\)/);
  assert.match(svg, /grayscale\(1\)/);
  assert.match(svg, /<ellipse/);
  assert.match(svg, /stroke-width="3"/);
});

test("big camera photos are scaled to 2560 px on the long side, small ones untouched", () => {
  assert.deepEqual(fitWithin(8000, 6000), { w: 2560, h: 1920 });
  assert.deepEqual(fitWithin(1200, 900), { w: 1200, h: 900 });
  assert.deepEqual(fitWithin(3000, 6000), { w: 1280, h: 2560 });
});

test("locked-items mode picks ONLY locked things; normal selection never does", () => {
  assert.equal(pickableNow({ locked: true }, false), false);
  assert.equal(pickableNow({}, false), true);
  assert.equal(pickableNow({ locked: true }, true), true);
  assert.equal(pickableNow({ locked: false }, true), false);
});

console.log(`  ${passed} passed, ${failed} failed`);
if (failed > 0) process.exit(1);
