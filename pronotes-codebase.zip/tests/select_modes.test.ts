/**
 * Select modes: loose lasso vs strict Samsung-style encircle.
 *
 * Loose (any visible point inside) is fast; strict (EVERY point inside a
 * CLOSED loop) is surgical. A neighbour the loop only grazes must stay
 * unselected in strict mode, and an open squiggle must select nothing.
 */

import assert from "node:assert/strict";
import {
  isElementFullyInPolygon,
  isElementInPolygon,
  isPointInPolygon,
} from "../src/lib/whiteboard/geometry";
import type { LineElement, RectangleElement, StrokeElement } from "../src/lib/whiteboard/types";

const NL = String.fromCharCode(10);

let passed = 0;
let failed = 0;
function test(name: string, fn: () => void) {
  try {
    fn();
    passed++;
    console.log(`  ✓ ${name}`);
  } catch (err) {
    failed++;
    console.error(`  ✗ ${name}`);
    console.error(`      ${(err as Error).message}`);
  }
}

let seq = 0;
function rect(x: number, y: number, w: number, h: number): RectangleElement {
  seq++;
  return {
    id: `r${seq}`,
    type: "rectangle",
    x,
    y,
    width: w,
    height: h,
    rotation: 0,
    opacity: 1,
    strokeColor: "#000",
    fillColor: "transparent",
    fillStyle: "transparent",
    dashStyle: "solid",
    strokeWidth: 2,
    createdAt: 1,
    updatedAt: 1,
  };
}

function stroke(pts: Array<[number, number]>, ox = 0, oy = 0): StrokeElement {
  seq++;
  return {
    id: `s${seq}`,
    type: "stroke",
    x: ox,
    y: oy,
    rotation: 0,
    opacity: 1,
    points: pts.map(([x, y]) => [x, y, 0.5] as [number, number, number]),
    color: "#000",
    strokeWidth: 3,
    strokeStyle: "pen",
    createdAt: 1,
    updatedAt: 1,
  };
}

/** Big square loop around (0,0)-(200,200). */
const LOOP = [
  { x: 0, y: 0 },
  { x: 200, y: 0 },
  { x: 200, y: 200 },
  { x: 0, y: 200 },
];

function main() {
  console.log(NL + "── Select modes ──");

  test("loose lasso takes a fully enclosed box", () => {
    assert.equal(isElementInPolygon(rect(50, 50, 40, 40), LOOP), true);
  });

  test("loose lasso takes a box the loop only grazes", () => {
    assert.equal(isElementInPolygon(rect(180, 180, 60, 60), LOOP), true);
  });

  test("strict encircle takes the fully enclosed box", () => {
    assert.equal(isElementFullyInPolygon(rect(50, 50, 40, 40), LOOP), true);
  });

  test("strict encircle refuses the grazed neighbour", () => {
    assert.equal(isElementFullyInPolygon(rect(180, 180, 60, 60), LOOP), false);
  });

  test("strict encircle refuses an outside box", () => {
    assert.equal(isElementFullyInPolygon(rect(300, 300, 40, 40), LOOP), false);
  });

  test("both modes need at least a triangle", () => {
    const line = [
      { x: 0, y: 0 },
      { x: 200, y: 200 },
    ];
    assert.equal(isElementInPolygon(rect(50, 50, 40, 40), line), false);
    assert.equal(isElementFullyInPolygon(rect(50, 50, 40, 40), line), false);
  });


  // ---- handwriting: the case the strict mode exists for -------------------
  // A stroke's bounding box is a rectangle around a curve, so for anything
  // diagonal the box corners sit in empty space. Testing THOSE made strict
  // encircle fail on every hugging loop — the Samsung gesture itself.

  test("strict encircle takes a stroke from a loop that hugs the ink", () => {
    // Diagonal ink from (10,10) to (90,90); the loop follows it closely, so
    // the stroke's box corners (10,90) and (90,10) are OUTSIDE the loop.
    const ink = stroke([
      [0, 0],
      [20, 20],
      [40, 40],
      [60, 60],
      [80, 80],
    ], 10, 10);
    const hug = [
      { x: 0, y: 20 },
      { x: 80, y: 100 },
      { x: 100, y: 100 },
      { x: 100, y: 80 },
      { x: 20, y: 0 },
      { x: 0, y: 0 },
    ];
    assert.equal(isPointInPolygon(10, 90, hug), false, "the box corner really is outside");
    assert.equal(isElementFullyInPolygon(ink, hug), true, "but every point of ink is inside");
  });

  test("strict encircle lifts one line of writing and leaves its neighbour", () => {
    const above = stroke([[10, 10], [30, 14], [50, 10], [70, 14]]);
    const below = stroke([[10, 40], [30, 44], [50, 40], [70, 44]]);
    // A loop snaked between the two lines, around the lower one only.
    const snake = [
      { x: 5, y: 28 },
      { x: 80, y: 28 },
      { x: 80, y: 55 },
      { x: 5, y: 55 },
    ];
    assert.equal(isElementFullyInPolygon(below, snake), true, "the encircled word comes");
    assert.equal(isElementFullyInPolygon(above, snake), false, "the line above stays put");
  });

  test("strict refuses a half-covered word where loose takes it", () => {
    const word = stroke([[10, 40], [30, 44], [50, 40], [70, 44]]);
    const half = [
      { x: 5, y: 28 },
      { x: 40, y: 28 },
      { x: 40, y: 55 },
      { x: 5, y: 55 },
    ];
    assert.equal(isElementInPolygon(word, half), true, "loose is greedy — that is its job");
    assert.equal(isElementFullyInPolygon(word, half), false, "strict wants all of it");
  });

  test("a diagonal line is its two ends, not the air around them", () => {
    const diag: LineElement = {
      id: "ln1",
      type: "line",
      x: 20,
      y: 20,
      x2: 60,
      y2: 60,
      rotation: 0,
      opacity: 1,
      strokeColor: "#000",
      dashStyle: "solid",
      strokeWidth: 2,
      createdAt: 1,
      updatedAt: 1,
    };
    // A narrow band along the diagonal: both ENDS are inside it, both box
    // corners are not.
    const hug = [
      { x: 0, y: 20 },
      { x: 90, y: 110 },
      { x: 110, y: 90 },
      { x: 20, y: 0 },
    ];
    assert.equal(isPointInPolygon(20, 80, hug), false, "the box corner really is outside");
    assert.equal(isElementFullyInPolygon(diag, hug), true, "but both ends are inside");
  });

  console.log(`  ${passed} passed, ${failed} failed`);
  if (failed > 0) process.exit(1);
}

void main();
