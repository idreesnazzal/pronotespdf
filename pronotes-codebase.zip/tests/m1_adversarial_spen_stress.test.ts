/**
 * Milestone 1 Empirical Adversarial Stress Test Suite
 * ===================================================
 * Agent: m1_challenger_1 (Empirical Challenger & Adversarial Verifier)
 * 
 * Target Verifications:
 * 1. S Pen High-Frequency 240Hz–360Hz Digitizer Burst Streams, Zero-Delay Sub-Events, and Micro-Loops
 * 2. Pointer ID Isolation & Capacitive Palm Contention under Simultaneous Move, Liftoff, and OS Cancel
 * 3. Hardware Prediction (getPredictedEvents) Overlay Isolation & History Non-Persistence
 * 4. Feather-Light Pressure (0.0), Single-Tap Dots, and Auto-Straightening 5px Deadband
 */

import assert from "node:assert/strict";
import {
  calibratePressure,
  computePressureFromSpeed,
  applyPenDynamics,
  buildStrokePath,
  getSvgPathFromStroke,
  getStrokeOptionsForStyle,
  pruneTerminalHooks,
  isStrokeStraight,
  straightenStrokePoints,
} from "../src/lib/whiteboard/stroke";
import {
  screenToWorld,
  type Viewport,
} from "../src/lib/whiteboard/geometry";
import {
  PEN_TYPE_PRESETS,
  type StrokeStyle,
  type StrokeElement,
  type Camera,
  type WhiteboardElement,
} from "../src/lib/whiteboard/types";
import {
  classifyTouch,
  contactLooksLikePalm,
  isRejectedTouch,
  type ContactGeometry,
  type PenProximity,
} from "../src/lib/whiteboard/palm";
import {
  stylusEraseTransition,
  isStylusEraseRequest,
  STYLUS_BARREL_BUTTON,
  type StylusButtonState,
} from "../src/lib/whiteboard/input";
import { useWhiteboard } from "../src/store/whiteboard";

let passedCount = 0;
let failedCount = 0;
let totalAssertions = 0;

function runTest(name: string, fn: () => void) {
  try {
    fn();
    passedCount++;
    console.log(`  ✓ PASS: ${name}`);
  } catch (err: unknown) {
    failedCount++;
    console.error(`  ✗ FAIL: ${name}`);
    console.error(`    ${(err as Error).message}`);
    if ((err as Error).stack) {
      console.error(`    ${(err as Error).stack?.split("\n").slice(1, 3).join("\n")}`);
    }
  }
}

function expect(condition: boolean, msg: string) {
  totalAssertions++;
  assert.ok(condition, msg);
}

function expectEqual<T>(actual: T, expected: T, msg: string) {
  totalAssertions++;
  assert.equal(actual, expected, msg);
}

console.log("\n================================================================================");
console.log("🔥 EMPIRICAL ADVERSARIAL CHALLENGER: S PEN INKING & HARDWARE COALESCENCE (M1)");
console.log("================================================================================\n");

// ============================================================================
// SECTION 1: 240Hz–360Hz Digitizer Coalescence & Extreme Burst Ingestion
// ============================================================================
console.log("── SECTION 1: 240Hz–360Hz Coalescence & Extreme Burst Ingestion ──");

runTest("1.1 360Hz continuous burst stream: 1,000 sub-events ingested with strict chronological order", () => {
  // Simulate 1,000 coordinate samples generated at 360Hz (dt = 2.77ms per sample)
  // along an Archimedean spiral: r(theta) = a + b*theta
  const totalSamples = 1000;
  const sampleRateHz = 360;
  const dtMs = 1000 / sampleRateHz;
  const startTime = 100000;

  interface RawSample {
    clientX: number;
    clientY: number;
    pressure: number;
    timeStamp: number;
    pointerType: string;
  }

  const generatedStream: RawSample[] = [];
  const cx = 500;
  const cy = 500;
  const b = 0.25;

  for (let i = 0; i < totalSamples; i++) {
    const t = startTime + i * dtMs;
    const theta = i * 0.05;
    const r = 10 + b * theta;
    const clientX = cx + r * Math.cos(theta);
    const clientY = cy + r * Math.sin(theta);
    // Oscillating realistic pen pressure
    const pressure = 0.2 + 0.5 * Math.sin(i * 0.02);
    generatedStream.push({
      clientX,
      clientY,
      pressure: Math.max(0.01, Math.min(1.0, pressure)),
      timeStamp: t,
      pointerType: "pen",
    });
  }

  // Simulate batching into 16.6ms display frames (each frame receives ~6 coalesced samples)
  const frames: RawSample[][] = [];
  let currentIdx = 0;
  while (currentIdx < totalSamples) {
    const batchSize = Math.min(6, totalSamples - currentIdx);
    frames.push(generatedStream.slice(currentIdx, currentIdx + batchSize));
    currentIdx += batchSize;
  }

  expect(frames.length > 0, "Frames must be populated");

  // Ingest stream simulating WhiteboardCanvas coalesced event processing
  const ingestedPoints: Array<[number, number, number]> = [];
  const tStart = performance.now();

  for (const frame of frames) {
    // getCoalescedEvents() returns the batch
    const coalescedBatch = frame;
    for (const ev of coalescedBatch) {
      const p = calibratePressure(ev.pressure, 65, "standard");
      ingestedPoints.push([ev.clientX, ev.clientY, p]);
    }
  }

  const tDuration = performance.now() - tStart;

  expectEqual(ingestedPoints.length, 1000, "All 1,000 samples must be ingested without dropping");
  expect(tDuration < 50, `1,000 points ingestion must complete under 50ms (took ${tDuration.toFixed(2)}ms)`);

  // Verify monotonicity and numerical validity
  for (let i = 0; i < ingestedPoints.length; i++) {
    const [x, y, p] = ingestedPoints[i];
    expect(Number.isFinite(x) && Number.isFinite(y), `Coordinates at ${i} must be finite`);
    expect(p >= 0.02 && p <= 1.0, `Pressure at ${i} must be calibrated between 0.02 and 1.0 (got ${p})`);
  }

  // Tessellate stroke through perfect-freehand and getSvgPathFromStroke
  const strokeEl: StrokeElement = {
    id: "burst-stroke",
    type: "stroke",
    x: 0,
    y: 0,
    rotation: 0,
    opacity: 1,
    points: ingestedPoints,
    color: "#000000",
    strokeWidth: 4,
    strokeStyle: "gel",
    smoothing: 50,
    createdAt: Date.now(),
    updatedAt: Date.now(),
  };

  const svgPath = buildStrokePath(strokeEl, false);
  expect(svgPath.startsWith("M") && svgPath.endsWith("Z"), "Tessellated SVG path must be valid closed polygon");
  expect(!svgPath.includes("NaN") && !svgPath.includes("Infinity"), "SVG path must contain no NaN or Infinity");
});

runTest("1.2 Zero-delay sub-events: duplicate coordinates (dt=0, dx=0, dy=0) do not cause division by zero", () => {
  // Simulate 50 sub-events where pen rests or digitizer reports duplicate coordinates
  const dupStream: Array<[number, number, number]> = [];
  for (let i = 0; i < 50; i++) {
    dupStream.push([150.0, 200.0, 0.45]);
  }

  // computePressureFromSpeed on zero-distance points
  const pSpeed = computePressureFromSpeed(dupStream);
  expect(Number.isFinite(pSpeed), "computePressureFromSpeed must be finite on duplicate points");
  expectEqual(pSpeed, 0.52, "Zero-distance points should yield default speed pressure 0.52");

  // applyPenDynamics on duplicate points
  const dynPoints = applyPenDynamics(dupStream, "ballpoint");
  expectEqual(dynPoints.length, 50, "Dynamics must preserve point count");
  for (const pt of dynPoints) {
    expect(Number.isFinite(pt[0]) && Number.isFinite(pt[1]) && Number.isFinite(pt[2]), "All dynamics values must be finite");
  }

  // getSvgPathFromStroke on duplicate points
  const path = getSvgPathFromStroke(dupStream.map(([x, y]) => [x, y]), true);
  expect(path.startsWith("M") && path.endsWith("Z"), "Path from duplicate points must be closed");
  expect(!path.includes("NaN"), "Path must not contain NaN");
});

runTest("1.3 Micro-loops: ultra-tight 0.5px–2.0px cursive loops across all 8 pen engines", () => {
  const engines: StrokeStyle[] = [
    "ballpoint",
    "gel",
    "fineliner",
    "fountain",
    "brush",
    "marker",
    "highlighter",
    "pencil",
  ];

  // Micro-loop with radius 1.2px (rapid 360-degree direction reversal over 16 points)
  const radius = 1.2;
  const loopPoints: Array<[number, number, number]> = [];
  for (let i = 0; i < 16; i++) {
    const angle = (i / 16) * Math.PI * 2;
    loopPoints.push([100 + Math.cos(angle) * radius, 100 + Math.sin(angle) * radius, 0.5]);
  }

  for (const eng of engines) {
    const strokeEl: StrokeElement = {
      id: `micro-${eng}`,
      type: "stroke",
      x: 0,
      y: 0,
      rotation: 0,
      opacity: 1,
      points: loopPoints,
      color: "#0f172a",
      strokeWidth: 3,
      strokeStyle: eng,
      smoothing: 50,
      createdAt: 1,
      updatedAt: 1,
    };

    const pathData = buildStrokePath(strokeEl, false);
    expect(pathData.startsWith("M"), `${eng}: path must start with M`);
    expect(pathData.endsWith("Z"), `${eng}: path must end with Z`);
    expect(!pathData.includes("NaN"), `${eng}: path must not contain NaN on micro-loop`);
    expect(!pathData.includes("Infinity"), `${eng}: path must not contain Infinity on micro-loop`);
  }
});

runTest("1.4 Auto-straighten deadband under 240Hz micro-jitter: jitter within 5px preserves hold timer", () => {
  // Anchor at (200, 200)
  const anchor = { x: 200, y: 200 };
  const HOLD_DEADBAND_PX = 5;

  // 10 high-frequency digitizer jitter samples around anchor
  const jitters = [
    { x: 200.8, y: 201.2 },
    { x: 202.1, y: 199.4 },
    { x: 198.5, y: 202.3 },
    { x: 203.2, y: 201.8 }, // dist = hypot(3.2, 1.8) = 3.67 <= 5
    { x: 201.0, y: 200.5 },
  ];

  for (const j of jitters) {
    const dist = Math.hypot(j.x - anchor.x, j.y - anchor.y);
    const exceedsDeadband = dist > HOLD_DEADBAND_PX;
    expect(!exceedsDeadband, `Micro-jitter (${j.x}, ${j.y}) dist=${dist.toFixed(2)} must NOT exceed deadband 5px`);
  }

  // Intentional movement exceeds deadband
  const intentionalMove = { x: 208, y: 206 };
  const distMove = Math.hypot(intentionalMove.x - anchor.x, intentionalMove.y - anchor.y);
  expect(distMove > HOLD_DEADBAND_PX, `Intentional move dist=${distMove.toFixed(2)} must exceed deadband`);
});

// ============================================================================
// SECTION 2: Drawing Pointer ID Isolation & Palm Contention Stress
// ============================================================================
console.log("\n── SECTION 2: Drawing Pointer ID Isolation & Palm Contention Stress ──");

runTest("2.1 Pointer ID isolation: simultaneous palm touches, moves, liftoffs, and cancellations do not corrupt pen stroke", () => {
  // Realistic simulation of the WhiteboardCanvas state machine and refs
  const state = {
    drawingPointerId: null as number | null,
    penActive: false,
    lastPenAt: 0,
    activeTouches: new Map<number, { x: number; y: number; startX: number; startY: number }>(),
    rejectedPalms: new Set<number>(),
    interaction: { kind: "idle" as "idle" | "drawing" | "panning" | "moving" },
    liveDraftStroke: null as { originX: number; originY: number; points: Array<[number, number, number]> } | null,
    committedStrokes: [] as Array<{ points: Array<[number, number, number]> }>,
    camera: { x: 0, y: 0, zoom: 1 },
  };

  const handlePointerDown = (e: { pointerId: number; pointerType: string; clientX: number; clientY: number; width?: number; height?: number; pressure?: number }) => {
    const isPen = e.pointerType === "pen";
    const isTouch = e.pointerType === "touch";

    if (isPen) {
      state.penActive = true;
      state.lastPenAt = Date.now();
    }

    if (isTouch) {
      const verdict = classifyTouch(
        { width: e.width ?? 20, height: e.height ?? 20 },
        { penDown: state.penActive, lastPenAt: state.lastPenAt, now: Date.now() }
      );

      const isSecondFingertipPinch =
        !state.penActive &&
        verdict === "pen-recent" &&
        state.activeTouches.size >= 1 &&
        !contactLooksLikePalm({ width: e.width ?? 20, height: e.height ?? 20 });

      if ((verdict === "pen-down" || verdict === "pen-recent") && !isSecondFingertipPinch) {
        state.rejectedPalms.add(e.pointerId);
        state.activeTouches.set(e.pointerId, { x: e.clientX, y: e.clientY, startX: e.clientX, startY: e.clientY });
        return; // Rejected palm contact returns immediately
      }

      state.activeTouches.set(e.pointerId, { x: e.clientX, y: e.clientY, startX: e.clientX, startY: e.clientY });
    }

    // Inking tool touchdown
    if (isPen) {
      state.drawingPointerId = e.pointerId;
      state.interaction = { kind: "drawing" };
      state.liveDraftStroke = {
        originX: e.clientX,
        originY: e.clientY,
        points: [[0, 0, calibratePressure(e.pressure ?? 0.5, 65, "standard")]],
      };
    }
  };

  const handlePointerMove = (e: { pointerId: number; pointerType: string; clientX: number; clientY: number; pressure?: number }) => {
    // Multi-touch pan/zoom guard (Defect D5)
    const nonPalmTouches = Array.from(state.activeTouches.entries())
      .filter(([id]) => !state.rejectedPalms.has(id))
      .map(([, t]) => t);

    if (
      nonPalmTouches.length === 2 &&
      !state.penActive &&
      state.drawingPointerId === null &&
      state.interaction.kind !== "drawing"
    ) {
      // Pan camera
      state.camera.x += 10;
      return;
    }

    if (state.interaction.kind === "drawing") {
      // R1-DEF-02: Isolate pen stream from palm moves
      if (state.drawingPointerId !== null && e.pointerId !== state.drawingPointerId) {
        return; // Palm movement completely ignored
      }

      const live = state.liveDraftStroke;
      if (!live) return;
      const p = calibratePressure(e.pressure ?? 0.5, 65, "standard");
      live.points.push([e.clientX - live.originX, e.clientY - live.originY, p]);
    }
  };

  const handlePointerUp = (e: { pointerId: number; pointerType: string }) => {
    state.activeTouches.delete(e.pointerId);
    state.rejectedPalms.delete(e.pointerId);

    if (e.pointerType === "pen") {
      state.penActive = false;
      state.lastPenAt = Date.now();
    }

    if (state.interaction.kind === "drawing") {
      // R1-DEF-02: Ignore pointerup from non-drawing pointers (e.g. palm lifting off)
      if (state.drawingPointerId !== null && e.pointerId !== state.drawingPointerId) {
        return; // Palm liftoff does NOT commit pen stroke
      }

      state.drawingPointerId = null;
      if (state.liveDraftStroke && state.liveDraftStroke.points.length >= 1) {
        state.committedStrokes.push({ points: state.liveDraftStroke.points });
      }
      state.liveDraftStroke = null;
      state.interaction = { kind: "idle" };
    }
  };

  const handlePointerCancel = (e: { pointerId: number; pointerType: string }) => {
    state.activeTouches.delete(e.pointerId);
    state.rejectedPalms.delete(e.pointerId);

    if (state.interaction.kind === "drawing") {
      // R1-DEF-02: Strict Pointer ID Isolation for Inking Cancellation
      if (state.drawingPointerId !== null && e.pointerId !== state.drawingPointerId) {
        return; // OS cancelled palm touch: DO NOT CANCEL ACTIVE PEN INKING!
      }
      state.drawingPointerId = null;
      state.liveDraftStroke = null;
      state.interaction = { kind: "idle" };
    }
  };

  // STEP 1: Stylus touchdown at (100, 100)
  handlePointerDown({ pointerId: 42, pointerType: "pen", clientX: 100, clientY: 100, pressure: 0.5 });
  expectEqual(state.drawingPointerId, 42, "drawingPointerId must be 42");
  expectEqual(state.interaction.kind, "drawing", "Interaction must be drawing");
  expectEqual(state.liveDraftStroke?.points.length, 1, "Live draft must have 1 point");

  // STEP 2: Simultaneous capacitive palm touches land (pointerId 101, 102)
  handlePointerDown({ pointerId: 101, pointerType: "touch", clientX: 450, clientY: 350, width: 50, height: 40 });
  handlePointerDown({ pointerId: 102, pointerType: "touch", clientX: 470, clientY: 360, width: 55, height: 45 });
  expect(state.rejectedPalms.has(101), "Palm 101 must be in rejectedPalms");
  expect(state.rejectedPalms.has(102), "Palm 102 must be in rejectedPalms");

  // STEP 3: Palm touches move erratically across screen
  handlePointerMove({ pointerId: 101, pointerType: "touch", clientX: 480, clientY: 390 });
  handlePointerMove({ pointerId: 102, pointerType: "touch", clientX: 510, clientY: 410 });
  // Camera must NOT have panned
  expectEqual(state.camera.x, 0, "Camera must not pan from dual palm contacts during inking");
  // Stroke must NOT have received palm coordinates
  expectEqual(state.liveDraftStroke?.points.length, 1, "Stroke must not include palm move coordinates");

  // STEP 4: Stylus draws valid cursive segment
  handlePointerMove({ pointerId: 42, pointerType: "pen", clientX: 110, clientY: 105, pressure: 0.55 });
  handlePointerMove({ pointerId: 42, pointerType: "pen", clientX: 120, clientY: 115, pressure: 0.60 });
  expectEqual(state.liveDraftStroke?.points.length, 3, "Pen points must be added to live stroke");

  // STEP 5: Palm 101 lifts off (pointerup on palm)
  handlePointerUp({ pointerId: 101, pointerType: "touch" });
  expectEqual(state.drawingPointerId, 42, "drawingPointerId must still be 42 after palm lift");
  expectEqual(state.interaction.kind, "drawing", "Interaction must still be drawing");
  expectEqual(state.committedStrokes.length, 0, "Stroke must not be prematurely committed by palm lift");

  // STEP 6: Android OS sends ACTION_CANCEL on Palm 102 (pointercancel)
  handlePointerCancel({ pointerId: 102, pointerType: "touch" });
  expectEqual(state.drawingPointerId, 42, "drawingPointerId must still be 42 after palm cancel");
  expectEqual(state.interaction.kind, "drawing", "Interaction must still be drawing after palm cancel");
  expect(state.liveDraftStroke !== null, "Live draft must not be destroyed by palm cancel");

  // STEP 7: Stylus continues drawing additional segment
  handlePointerMove({ pointerId: 42, pointerType: "pen", clientX: 130, clientY: 125, pressure: 0.65 });
  expectEqual(state.liveDraftStroke?.points.length, 4, "Stroke continued drawing smoothly");

  // STEP 8: Stylus finally lifts off (pointerup on pen)
  handlePointerUp({ pointerId: 42, pointerType: "pen" });
  expectEqual(state.drawingPointerId, null, "drawingPointerId reset to null");
  expectEqual(state.interaction.kind, "idle", "Interaction reset to idle");
  expectEqual(state.committedStrokes.length, 1, "Exactly 1 stroke committed on pen lift");
  expectEqual(state.committedStrokes[0].points.length, 4, "Committed stroke contains only the 4 pen points");

  // Verify NONE of the coordinates match palm coordinates
  const committedPts = state.committedStrokes[0].points;
  for (const pt of committedPts) {
    const worldX = pt[0] + 100;
    expect(worldX < 200, `Committed point X=${worldX} must belong to pen, not palm (450+)`);
  }
});

runTest("2.2 Context-aware fast-bypass: 800ms suppression protects resting palm but immediately allows 2-finger pinch", () => {
  const now = 20000;
  const lastPenLiftAt = now - 150; // 150ms after pen lift (inside 800ms window)

  // 1. Single resting palm lands (broad contact patch) -> REJECTED
  const palmGeometry: ContactGeometry = { width: 50, height: 45 };
  const palmVerdict = classifyTouch(palmGeometry, { penDown: false, lastPenAt: lastPenLiftAt, now });
  expectEqual(palmVerdict, "pen-recent", "Resting palm within 150ms must be pen-recent");
  expect(isRejectedTouch(palmGeometry, { penDown: false, lastPenAt: lastPenLiftAt, now }), "Palm must be rejected");

  // 2. Fingertip touch lands (small contact patch) within 150ms -> verdict is pen-recent
  const fingerGeometry: ContactGeometry = { width: 16, height: 16 };
  const fingerVerdict = classifyTouch(fingerGeometry, { penDown: false, lastPenAt: lastPenLiftAt, now });
  expectEqual(fingerVerdict, "pen-recent", "Fingertip within 150ms has base verdict pen-recent");

  // 3. Fast-bypass criteria: pen lifted (!penActive), touchVerdict === 'pen-recent', activeTouches >= 1, not palm-sized
  const penActive = false;
  const activeTouchesCount = 1; // 1 contact already present, 2nd arrives
  const isSecondFingertipPinch =
    !penActive &&
    fingerVerdict === "pen-recent" &&
    activeTouchesCount >= 1 &&
    !contactLooksLikePalm(fingerGeometry);

  expect(isSecondFingertipPinch, "Second fingertip must engage context-aware fast bypass immediately");
});

// ============================================================================
// SECTION 3: Hardware Prediction Isolation & History Non-Persistence
// ============================================================================
console.log("\n── SECTION 3: Hardware Prediction Isolation & History Non-Persistence ──");

runTest("3.1 Predicted points are rendered in live draft but NEVER committed to document history on pointerup", () => {
  // Model WhiteboardCanvas predicted event handling
  const live = {
    originX: 100,
    originY: 100,
    points: [[0, 0, 0.5]] as Array<[number, number, number]>,
  };
  let predictedPoints: Array<[number, number, number]> = [];

  // Frame 1: Move with real points + predicted points from getPredictedEvents()
  const realEvent = { clientX: 120, clientY: 100, pressure: 0.6 };
  const predictedEvents = [
    { clientX: 128, clientY: 100, pressure: 0.6 },
    { clientX: 136, clientY: 100, pressure: 0.6 },
    { clientX: 144, clientY: 100, pressure: 0.6 },
  ];

  // Ingestion of real event
  live.points.push([realEvent.clientX - live.originX, realEvent.clientY - live.originY, realEvent.pressure]);

  // Speculative prediction filtering (1px <= dist <= 40px, max 3)
  const lastReal = [realEvent.clientX, realEvent.clientY, realEvent.pressure];
  const newPredictions: Array<[number, number, number]> = [];
  for (const pe of predictedEvents.slice(0, 3)) {
    const dist = Math.hypot(pe.clientX - lastReal[0], pe.clientY - lastReal[1]);
    if (dist >= 1.0 && dist <= 40.0) {
      newPredictions.push([pe.clientX - live.originX, pe.clientY - live.originY, pe.pressure]);
    }
  }
  predictedPoints = newPredictions;

  // Live RAF render points
  const renderPoints = predictedPoints.length > 0 ? [...live.points, ...predictedPoints] : live.points;
  expectEqual(renderPoints.length, 5, "Live render points must combine 2 real + 3 predicted points (5 total)");
  expectEqual(live.points.length, 2, "Real points buffer must contain ONLY 2 real points");

  // Frame 2: Stylus moves to (130, 100) with new predictions
  const realEvent2 = { clientX: 130, clientY: 100, pressure: 0.65 };
  const predictedEvents2 = [
    { clientX: 138, clientY: 100, pressure: 0.65 },
    { clientX: 146, clientY: 100, pressure: 0.65 },
  ];

  live.points.push([realEvent2.clientX - live.originX, realEvent2.clientY - live.originY, realEvent2.pressure]);
  const lastReal2 = [realEvent2.clientX, realEvent2.clientY, realEvent2.pressure];
  const newPredictions2: Array<[number, number, number]> = [];
  for (const pe of predictedEvents2.slice(0, 3)) {
    const dist = Math.hypot(pe.clientX - lastReal2[0], pe.clientY - lastReal2[1]);
    if (dist >= 1.0 && dist <= 40.0) {
      newPredictions2.push([pe.clientX - live.originX, pe.clientY - live.originY, pe.pressure]);
    }
  }
  predictedPoints = newPredictions2; // Replaces previous frame's predictions

  const renderPoints2 = predictedPoints.length > 0 ? [...live.points, ...predictedPoints] : live.points;
  expectEqual(renderPoints2.length, 5, "Live render now has 3 real + 2 predicted (5 total)");
  expectEqual(live.points.length, 3, "Real points buffer contains exactly 3 real points");

  // POINTERUP: Commit stroke
  predictedPoints = []; // Cleared on pointerup
  const cleanPoints = pruneTerminalHooks(live.points);
  const finalStroke: StrokeElement = {
    id: "commit-stroke-1",
    type: "stroke",
    x: live.originX,
    y: live.originY,
    rotation: 0,
    opacity: 1,
    points: cleanPoints,
    color: "#000",
    strokeWidth: 3,
    strokeStyle: "gel",
    smoothing: 50,
    createdAt: Date.now(),
    updatedAt: Date.now(),
  };

  // Assertions on committed stroke
  expectEqual(finalStroke.points.length, 3, "Committed stroke MUST have exactly 3 points");
  expectEqual(finalStroke.points[0][0], 0, "Origin X is 0");
  expectEqual(finalStroke.points[1][0], 20, "Point 1 X is 20");
  expectEqual(finalStroke.points[2][0], 30, "Point 2 X is 30 (last real point at 130 - 100)");

  // Verify none of the predicted X coordinates (28, 36, 44, 38, 46) exist in final stroke
  const forbiddenPredictedX = [28, 36, 44, 38, 46];
  for (const pt of finalStroke.points) {
    expect(!forbiddenPredictedX.includes(pt[0]), `Predicted coordinate X=${pt[0]} must NOT be in committed stroke`);
  }
});

runTest("3.2 Predicted points deadband & outlier clamping: discards < 1px jitter and > 40px outliers", () => {
  const lastReal: [number, number, number] = [100, 100, 0.5];
  const candidates = [
    { clientX: 100.4, clientY: 100.3, pressure: 0.5 }, // dist = 0.5px (< 1.0px) -> DISCARDED
    { clientX: 110.0, clientY: 100.0, pressure: 0.5 }, // dist = 10.0px (valid) -> KEPT
    { clientX: 125.0, clientY: 100.0, pressure: 0.5 }, // dist = 25.0px (valid) -> KEPT
    { clientX: 170.0, clientY: 100.0, pressure: 0.5 }, // dist = 70.0px (> 40.0px) -> DISCARDED
  ];

  const filteredPredictions: Array<[number, number, number]> = [];
  for (const pe of candidates.slice(0, 3)) {
    const dist = Math.hypot(pe.clientX - lastReal[0], pe.clientY - lastReal[1]);
    if (dist >= 1.0 && dist <= 40.0) {
      filteredPredictions.push([pe.clientX - lastReal[0], pe.clientY - lastReal[1], pe.pressure]);
    }
  }

  expectEqual(filteredPredictions.length, 2, "Exactly 2 valid predictions kept (jitter and wild outlier discarded)");
  expectEqual(filteredPredictions[0][0], 10.0, "First valid prediction at 10px");
  expectEqual(filteredPredictions[1][0], 25.0, "Second valid prediction at 25px");
});

// ============================================================================
// SECTION 4: Feather-Light Pressure & Touchdown Geometry
// ============================================================================
console.log("\n── SECTION 4: Feather-Light Pressure & Touchdown Geometry ──");

runTest("4.1 S Pen rawPressure === 0.0 preserves hairline (0.02) without falling back to speed pressure (0.50)", () => {
  // S Pen feather-light touch
  const isPen = true;
  const rawEvPressure = 0.0;
  const rawP = isPen
    ? (typeof rawEvPressure === "number" ? rawEvPressure : 0.5)
    : (rawEvPressure > 0 ? rawEvPressure : 0.5);

  expectEqual(rawP, 0.0, "Raw pressure for pen must preserve 0.0");

  const calibrated = calibratePressure(rawP, 65, "standard");
  expectEqual(calibrated, 0.02, "calibrated pressure for 0.0 must be 0.02 hairline");
  expect(calibrated < 0.1, "Hairline pressure must be delicate (< 0.1), not thick fallback (0.5)");
});

runTest("4.2 Single-point tap touchdown (dot / niqqud / period) renders valid circular SVG dot", () => {
  const dotStroke: StrokeElement = {
    id: "dot-1",
    type: "stroke",
    x: 200,
    y: 300,
    rotation: 0,
    opacity: 1,
    points: [[0, 0, 0.5]], // Single point
    color: "#1e293b",
    strokeWidth: 4,
    strokeStyle: "ballpoint",
    smoothing: 50,
    createdAt: Date.now(),
    updatedAt: Date.now(),
  };

  const dotPath = buildStrokePath(dotStroke, false);
  expect(dotPath.startsWith("M"), "Dot path must start with M");
  expect(dotPath.endsWith("Z"), "Dot path must end with Z");
  expect(dotPath.includes(" a ") || dotPath.includes("a "), "Dot path must contain arc commands for circle");
  expect(!dotPath.includes("NaN"), "Dot path must not contain NaN");
});

// ============================================================================
// SUMMARY & VERDICT EVALUATION
// ============================================================================
console.log("\n================================================================================");
console.log(`📊 ADVERSARIAL CHALLENGE EXECUTION SUMMARY`);
console.log(`  Tests Passed:       ${passedCount}`);
console.log(`  Tests Failed:       ${failedCount}`);
console.log(`  Total Assertions:   ${totalAssertions}`);
console.log("================================================================================\n");

if (failedCount > 0) {
  process.exit(1);
}
