/**
 * Tests for the shape-tool rework:
 *  (A) the quick color picker colors the fill too, not just the edges;
 *  (D) a tap (no drag) plants a default-size shape instead of nothing;
 *  (E) a fingertip tap selects at once instead of needing a long press;
 *  (P) the inspector folds to its header (persisted) so it never buries
 *      the canvas; inserting returns to select, so only one panel is ever open.
 */

import assert from "node:assert/strict";
import { DEFAULT_STYLE, setToolInk, type ToolType } from "../src/lib/whiteboard/types";
import { TAP_SHAPE_WIDTH, TAP_SHAPE_HEIGHT, tapShapeRect } from "../src/lib/whiteboard/placement";
import { shouldSelectOnTouchTap } from "../src/lib/whiteboard/palm";
import { useWhiteboard } from "../src/store/whiteboard";

let passed = 0;
let failed = 0;
function test(name: string, fn: () => void) {
  try {
    fn();
    passed++;
    console.log(`  ✓ ${name}`);
  } catch (err) {
    failed++;
    console.error(`  ✗ ${name}`);
    console.error(`      ${(err as Error).message}`);
  }
}

const SHAPES: ToolType[] = ["rectangle", "ellipse", "diamond", "triangle", "star", "cloud"];

console.log("\n── Shape tools: fill, tap-insert, tap-select ──");

test("quick color pick on a shape tool colors the fill as well as the edge", () => {
  for (const tool of SHAPES) {
    const patch = setToolInk(DEFAULT_STYLE, tool, { color: "#ff0000" });
    assert.equal(
      (patch as { shapeStrokeColor?: string }).shapeStrokeColor,
      "#ff0000",
      `${tool}: edge must follow the pick`
    );
    assert.equal(
      (patch as { shapeFillColor?: string }).shapeFillColor,
      "#ff0000",
      `${tool}: fill must follow the pick (was stuck default blue)`
    );
  }
});

test("quick color pick on other tools does not touch shape fill", () => {
  const line = setToolInk(DEFAULT_STYLE, "line", { color: "#00ff00" });
  assert.equal((line as { lineColor?: string }).lineColor, "#00ff00");
  assert.equal("shapeFillColor" in line, false, "line pick must not write shape fill");
  const text = setToolInk(DEFAULT_STYLE, "text", { color: "#0000ff" });
  assert.equal((text as { textColor?: string }).textColor, "#0000ff");
  assert.equal("shapeFillColor" in text, false, "text pick must not write shape fill");
  const pen = setToolInk(DEFAULT_STYLE, "gel", { color: "#123456", size: 5 });
  assert.equal("shapeFillColor" in pen, false, "pen pick must not write shape fill");
});

test("tap shape is centred on the tap point at the default size", () => {
  const r = tapShapeRect(400, 300);
  assert.equal(r.width, TAP_SHAPE_WIDTH);
  assert.equal(r.height, TAP_SHAPE_HEIGHT);
  assert.equal(r.x, 400 - TAP_SHAPE_WIDTH / 2);
  assert.equal(r.y, 300 - TAP_SHAPE_HEIGHT / 2);
});

test("tap shape is capped to the sheet and translated fully onto it", () => {
  const page = { width: 200, height: 200 };
  // A 160x120 default fits a 200x200 sheet as-is, centred.
  const mid = tapShapeRect(100, 100, { page });
  assert.equal(mid.width, TAP_SHAPE_WIDTH);
  assert.equal(mid.x, 100 - TAP_SHAPE_WIDTH / 2);
  assert.ok(mid.x >= 0 && mid.x + mid.width <= 200, "must sit fully on the sheet");
  assert.ok(mid.y >= 0 && mid.y + mid.height <= 200, "must sit fully on the sheet");

  // A tap at the corner pulls the whole shape on paper, never off it.
  const corner = tapShapeRect(5, 5, { page });
  assert.equal(corner.x, 0);
  assert.equal(corner.y, 0);

  // A sheet smaller than the default is never exceeded.
  const tiny = tapShapeRect(50, 50, { page: { width: 100, height: 60 } });
  assert.ok(tiny.width <= 100 && tiny.height <= 60, "must never be born bigger than the page");
  assert.ok(tiny.x >= 0 && tiny.y >= 0, "must stay on a tiny sheet");
});

test("tap shape is snapped when grid snap is on, untouched otherwise", () => {
  const snap = (v: number) => Math.round(v / 10) * 10;
  const snapped = tapShapeRect(403, 307, { snap });
  assert.equal(snapped.x, Math.round((403 - TAP_SHAPE_WIDTH / 2) / 10) * 10);
  const plain = tapShapeRect(403, 307);
  assert.equal(plain.x, 403 - TAP_SHAPE_WIDTH / 2, "no snap fn means no rounding");
});

test("fingertip tap on a fresh object selects at once", () => {
  assert.equal(
    shouldSelectOnTouchTap({ verdict: "allow", hitSelected: false, shiftKey: false, editing: false }),
    true,
    "clean tap must select immediately"
  );
});

test("tap-select stays off for palms, selections, shift and mid-edit", () => {
  assert.equal(
    shouldSelectOnTouchTap({ verdict: "contact-size", hitSelected: false, shiftKey: false, editing: false }),
    false,
    "a palm-sized patch still needs the long press"
  );
  assert.equal(
    shouldSelectOnTouchTap({ verdict: "pen-down", hitSelected: false, shiftKey: false, editing: false }),
    false,
    "pen-suppressed contact must not select"
  );
  assert.equal(
    shouldSelectOnTouchTap({ verdict: "allow", hitSelected: true, shiftKey: false, editing: false }),
    false,
    "already-selected keeps its own (move/menu) path"
  );
  assert.equal(
    shouldSelectOnTouchTap({ verdict: "allow", hitSelected: false, shiftKey: true, editing: false }),
    false,
    "shift keeps toggling"
  );
  assert.equal(
    shouldSelectOnTouchTap({ verdict: "allow", hitSelected: false, shiftKey: false, editing: true }),
    false,
    "mid-edit touch stays a resting hand"
  );
});

test("inspector fold state persists through the store", () => {
  const S = () => useWhiteboard.getState();
  assert.equal(S().propsPanelCollapsed, true, "inspector starts folded so it never buries the canvas");
  S().setPropsPanelCollapsed(false);
  assert.equal(S().propsPanelCollapsed, false, "unfolding flips the flag");
  assert.equal(
    S().getPersistedState().propsPanelCollapsed,
    false,
    "the flag must survive a reload like every other panel toggle"
  );
  S().setPropsPanelCollapsed(true);
  assert.equal(S().getPersistedState().propsPanelCollapsed, true, "folding persists too");
});

console.log(`\n${passed} passed, ${failed} failed.`);
if (failed > 0) process.exit(1);
