/**
 * Sidebar pro work: trash with undo.
 *
 * Deleting boards/folders from the sidebar must be undoable through the
 * store — restoring boards, folders, their pages AND their element data —
 * and the asset pruner must treat the undo buffer as referenced until the
 * undo window ends. Otherwise "Undo" brings back boards whose pictures and
 * PDFs were already reclaimed from IndexedDB.
 */

import assert from "node:assert/strict";
import { useWhiteboard } from "../src/store/whiteboard";
import { collectReferencedAssets } from "../src/lib/whiteboard/workspace";
import type { Board } from "../src/lib/whiteboard/types";

const NL = String.fromCharCode(10);

let passed = 0;
let failed = 0;
async function test(name: string, fn: () => void | Promise<void>) {
  try {
    await fn();
    passed++;
    console.log(`  ✓ ${name}`);
  } catch (err) {
    failed++;
    console.error(`  ✗ ${name}`);
    console.error(`      ${(err as Error).message}`);
  }
}

function resetStore() {
  useWhiteboard.setState({
    boards: [],
    folders: [],
    activeBoardId: null,
    activeFolderId: null,
    selectedIds: [],
    editingId: null,
    history: { past: [], future: [] },
  });
  useWhiteboard.getState().discardTrash();
}

let seq = 0;
function board(partial: Partial<Board> = {}): Board {
  seq++;
  return {
    id: `b${seq}`,
    name: `Board ${seq}`,
    folderId: null,
    elements: [],
    background: { pattern: "plain" },
    camera: { x: 0, y: 0, zoom: 1 },
    createdAt: seq,
    updatedAt: seq,
    ...partial,
  } as Board;
}

function seed() {
  resetStore();
  const f1 = { id: "f1", name: "F1", parentId: null, color: "#fff", expanded: true, createdAt: 1 };
  const f2 = { id: "f2", name: "F2", parentId: "f1", color: "#fff", expanded: true, createdAt: 2 };
  const b1 = board({ id: "b1", name: "B1", folderId: null });
  const b2 = board({ id: "b2", name: "B2", folderId: "f1" });
  const b3 = board({
    id: "b3",
    name: "B3",
    folderId: "f2",
    kind: "notebook",
    pages: [
      {
        id: "p1",
        elements: [{ id: "e1", type: "text", x: 0, y: 0, rotation: 0, opacity: 1, text: "hi", createdAt: 1, updatedAt: 1 } as never],
        createdAt: 1,
        updatedAt: 1,
      },
    ],
  });
  useWhiteboard.setState({ folders: [f1, f2] as never, boards: [b1, b2, b3], activeBoardId: "b1" });
}

async function main() {
  console.log(NL + "── Sidebar trash + undo ──");

  await test("trashItems removes boards; undoTrash restores them in place", () => {
    seed();
    const S = () => useWhiteboard.getState();
    S().trashItems(["b1", "b3"], []);
    assert.deepEqual(S().boards.map((b) => b.id), ["b2"]);
    assert.ok(S().lastDeleted, "undo buffer holds the deletion");
    S().undoTrash();
    assert.deepEqual(S().boards.map((b) => b.id), ["b1", "b2", "b3"]);
    const b3 = S().boards.find((b) => b.id === "b3")!;
    assert.equal(b3.kind, "notebook");
    assert.equal((b3.pages ?? [])[0]?.elements.length, 1, "pages and elements survive");
    assert.equal(S().lastDeleted, null, "buffer clears after undo");
  });

  await test("trashing a folder removes its subtree but keeps boards at root", () => {
    seed();
    const S = () => useWhiteboard.getState();
    S().trashItems([], ["f1"]);
    assert.deepEqual(S().folders.map((f: { id: string }) => f.id), [], "subtree gone");
    assert.deepEqual(
      S().boards.map((b) => `${b.id}:${b.folderId ?? "root"}`).sort(),
      ["b1:root", "b2:root", "b3:root"]
    );
    S().undoTrash();
    assert.deepEqual(S().folders.map((f: { id: string }) => f.id).sort(), ["f1", "f2"]);
    const byId = new Map(S().boards.map((b) => [b.id, b.folderId]));
    assert.equal(byId.get("b2"), "f1", "board folder placement restored");
    assert.equal(byId.get("b3"), "f2");
  });

  await test("undoTrash with an empty buffer is a no-op", () => {
    seed();
    const S = () => useWhiteboard.getState();
    const before = S().boards.map((b) => b.id);
    S().undoTrash();
    assert.deepEqual(S().boards.map((b) => b.id), before);
  });

  await test("trashing unknown ids touches nothing and clobbers no buffer", () => {
    seed();
    const S = () => useWhiteboard.getState();
    S().trashItems(["nope"], ["missing"]);
    assert.deepEqual(S().boards.map((b) => b.id), ["b1", "b2", "b3"]);
    assert.equal(S().lastDeleted, null);
  });

  await test("a second trash replaces the first (single-level undo)", () => {
    seed();
    const S = () => useWhiteboard.getState();
    S().trashItems(["b1"], []);
    S().trashItems(["b2"], []);
    S().undoTrash();
    assert.deepEqual(S().boards.map((b) => b.id).sort(), ["b2", "b3"]);
  });

  await test("asset collection counts the undo buffer as referenced", () => {
    seed();
    const S = () => useWhiteboard.getState();
    const withAsset = board({
      id: "img1",
      elements: [{ id: "e9", type: "image", x: 0, y: 0, rotation: 0, opacity: 1, src: "asset:pic1", createdAt: 1, updatedAt: 1 } as never],
    });
    useWhiteboard.setState({ boards: [...S().boards, withAsset] });
    S().trashItems(["img1"], []);
    const buffered = (S().lastDeleted?.removedBoards ?? []).map((r) => r.board);
    const refs = collectReferencedAssets(S().boards, [], buffered);
    assert.ok(refs.imageIds.has("pic1"), "trashed board's picture stays referenced during undo window");
    S().discardTrash();
    const buffered2 = (S().lastDeleted?.removedBoards ?? []).map((r) => r.board);
    const refs2 = collectReferencedAssets(S().boards, [], buffered2);
    assert.ok(!refs2.imageIds.has("pic1"), "after discard the picture is reclaimable");
  });

  console.log(`  ${passed} passed, ${failed} failed`);
  if (failed > 0) process.exit(1);
}

void main();
