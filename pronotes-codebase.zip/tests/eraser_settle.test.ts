/**
 * Pixel eraser: the ink beside a cut must not change shape.
 *
 * A stroke is drawn from its raw points after smoothing that depends on the
 * points before each one. Cutting a stroke and letting each piece be smoothed
 * again from its new start bent the writing beside every cut - measured on a
 * zig-zag line, the piece after the cut came out 20px tall instead of 28. The
 * eraser now cuts the drawn line itself (`settledStrokePoints`) and the pieces
 * are drawn as they are.
 */

import assert from "node:assert/strict";
import { buildStrokePath, eraseFromStroke, settledStrokePoints } from "../src/lib/whiteboard/stroke";
import type { StrokeElement } from "../src/lib/whiteboard/types";

const NL = String.fromCharCode(10);
let passed = 0;
let failed = 0;
function test(name: string, fn: () => void) {
  try {
    fn();
    passed++;
    console.log(`  ✓ ${name}`);
  } catch (err) {
    failed++;
    console.error(`  ✗ ${name}`);
    console.error(`      ${(err as Error).message}`);
  }
}

console.log(NL + "── Pixel eraser keeps the ink in place ──");

/** Handwriting-like zig-zag: sharp turns every few points. */
function zigzag(): StrokeElement {
  const points: [number, number, number][] = [];
  for (let t = 0; t <= 60; t++) {
    const k = t % 6;
    points.push([t * 8 + (k < 3 ? 0 : -6), k < 3 ? -k * 12 : (k - 6) * -12 - 36, 0.5]);
  }
  return {
    id: "s",
    type: "stroke",
    x: 0,
    y: 0,
    rotation: 0,
    opacity: 1,
    points,
    color: "#000",
    strokeWidth: 3,
    strokeStyle: "gel",
    createdAt: 0,
    updatedAt: 0,
  };
}

/** Bounding box of a path's coordinates, optionally only within [x0, x1]. */
function box(d: string, x0 = -Infinity, x1 = Infinity) {
  const nums = (d.match(/-?\d+(\.\d+)?/g) ?? []).map(Number);
  let minY = Infinity;
  let maxY = -Infinity;
  let minX = Infinity;
  let maxX = -Infinity;
  for (let i = 0; i + 1 < nums.length; i += 2) {
    const [x, y] = [nums[i], nums[i + 1]];
    if (x < x0 || x > x1) continue;
    minX = Math.min(minX, x);
    maxX = Math.max(maxX, x);
    minY = Math.min(minY, y);
    maxY = Math.max(maxY, y);
  }
  return { minX, maxX, minY, maxY, h: maxY - minY };
}

test("a settled stroke draws the same line as the original", () => {
  const s = zigzag();
  const settled: StrokeElement = { ...s, points: settledStrokePoints(s), settled: true };
  const a = box(buildStrokePath(s));
  const b = box(buildStrokePath(settled));
  for (const k of ["minX", "maxX", "minY", "maxY"] as const) {
    assert.ok(Math.abs(a[k] - b[k]) < 1.5, `${k}: ${a[k]} vs ${b[k]}`);
  }
});

test("the piece after a cut keeps the height of the writing it came from", () => {
  const s = zigzag();
  const pts = settledStrokePoints(s);
  // A vertical swipe through the middle.
  const runs = eraseFromStroke(pts, 240, -80, 240, 60, 10);
  assert.ok(runs && runs.length === 2, "cut in two");
  const right = runs![1];
  const piece: StrokeElement = { ...s, points: right, settled: true, cutStart: true };
  const whole = box(buildStrokePath(s), 300, 460);
  const part = box(buildStrokePath(piece), 300, 460);
  assert.ok(Math.abs(whole.h - part.h) < 2, `height ${whole.h.toFixed(1)} vs ${part.h.toFixed(1)}`);
  assert.ok(Math.abs(whole.minY - part.minY) < 2 && Math.abs(whole.maxY - part.maxY) < 2, "same place");
});

test("settling is done once: a settled stroke's points are kept as they are", () => {
  const s = { ...zigzag(), settled: true };
  assert.equal(settledStrokePoints(s), s.points);
});

console.log(`  ${passed} passed, ${failed} failed`);
if (failed > 0) process.exit(1);
