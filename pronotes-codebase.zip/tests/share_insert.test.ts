/**
 * Exporting a page range, and inserting pages into a notebook.
 *
 * Two features that meet in the same place: a notebook is no longer all-or-
 * nothing. You can hand in pages 4 to 9, and you can pull pages 2 to 5 of last
 * year's notes (or of a PDF) into the middle of this one.
 *
 * The things most likely to go wrong, and so the things pinned here:
 *   - a range typed backwards, past the end, or half-typed must never export
 *     nothing or throw - it must mean the obvious thing;
 *   - copied pages must get FRESH element ids, or selecting one selects both
 *     copies and deleting one deletes both;
 *   - a connector whose other end was left behind must be dropped, not carried
 *     over pointing at an element that does not exist;
 *   - inserting must COPY, never move - the source notebook is someone's work;
 *   - a copied PDF page must keep the whole notebook's record of its documents
 *     straight, or the storage collector deletes a PDF still being read.
 */

import assert from "node:assert/strict";

import { useWhiteboard } from "../src/store/whiteboard";
import {
  getPages,
  allElements,
  resolvePageRange,
  parsePageSelection,
  formatPageSelection,
  copyPagesFrom,
  insertPages,
  pageFromPdf,
} from "../src/lib/whiteboard/notebook";
import { buildExportSvg, exportFilename } from "../src/lib/whiteboard/export";
import { isShareCancellation, shareRoute, canChooseApp } from "../src/lib/whiteboard/share";
import type {
  Board,
  NotebookPage,
  StrokeElement,
  ConnectionElement,
  WhiteboardElement,
} from "../src/lib/whiteboard/types";

let passed = 0;
let failed = 0;
function test(name: string, fn: () => void) {
  try {
    fn();
    passed++;
    console.log(`  ✓ ${name}`);
  } catch (err) {
    failed++;
    console.error(`  ✗ ${name}`);
    console.error(`      ${(err as Error).message}`);
  }
}

const S = () => useWhiteboard.getState();
const board = (id: string): Board => S().boards.find((b) => b.id === id)!;

let seq = 0;
function stroke(extra: Partial<StrokeElement> = {}): StrokeElement {
  seq++;
  return {
    id: `s${seq}`,
    type: "stroke",
    x: 10,
    y: 10,
    width: 50,
    height: 50,
    rotation: 0,
    opacity: 1,
    // Points are [x, y, pressure] tuples, not objects.
    points: [
      [0, 0, 0.5],
      [10, 10, 0.5],
      [20, 18, 0.5],
    ],
    color: "#000000",
    strokeWidth: 2,
    penType: "pen",
    createdAt: 1,
    updatedAt: 1,
    ...extra,
  } as StrokeElement;
}

function connection(id: string, fromId: string, toId: string, boardId: string): ConnectionElement {
  return {
    id,
    type: "connection",
    x: 0,
    y: 0,
    width: 0,
    height: 0,
    rotation: 0,
    opacity: 1,
    source: { boardId, elementId: fromId },
    target: { boardId, elementId: toId },
    createdAt: 1,
    updatedAt: 1,
  } as unknown as ConnectionElement;
}

function page(elements: WhiteboardElement[] = [], extra: Partial<NotebookPage> = {}): NotebookPage {
  seq++;
  return { id: `pg${seq}`, elements, createdAt: 1, updatedAt: 1, ...extra };
}

/** A detached notebook, not in the store - for the pure helpers. */
function notebook(pages: NotebookPage[], id = "src"): Board {
  return {
    id,
    name: "Source",
    folderId: null,
    elements: [],
    camera: { x: 0, y: 0, zoom: 1 },
    kind: "notebook",
    pages,
    activePageId: pages[0]?.id,
    createdAt: 1,
    updatedAt: 1,
  } as Board;
}

/** A real notebook in the store, with `count` pages each holding one stroke. */
function storeNotebook(name: string, count: number): string {
  const id = S().createNotebook(name, null);
  S().setActiveBoard(id);
  for (let i = 0; i < count; i++) {
    if (i > 0) S().addPage();
    S().addElement(stroke(), true);
  }
  return id;
}

console.log("\n── Page ranges: what a typed range means ──");

test("a plain range becomes the pages between its ends, inclusive", () => {
  const r = resolvePageRange(10, 2, 5);
  assert.deepEqual(r.indices, [1, 2, 3, 4]);
  assert.equal(r.from, 2);
  assert.equal(r.to, 5);
});

test("a single page is a range of one", () => {
  assert.deepEqual(resolvePageRange(10, 3, 3).indices, [2]);
});

test("a backwards range means what it says, not nothing", () => {
  // Typing "5 to 2" is a person describing pages 2 to 5 in the wrong order.
  assert.deepEqual(resolvePageRange(10, 5, 2).indices, resolvePageRange(10, 2, 5).indices);
});

test("a range past the end stops at the last page", () => {
  const r = resolvePageRange(10, 8, 999);
  assert.deepEqual(r.indices, [7, 8, 9]);
  assert.equal(r.to, 10);
});

test("zero and negatives clamp to the first page", () => {
  assert.deepEqual(resolvePageRange(5, 0, 2).indices, [0, 1]);
  assert.deepEqual(resolvePageRange(5, -7, 1).indices, [0]);
});

test("a half-typed range is still a range", () => {
  // The box is empty while you type, which arrives as NaN. It must not throw
  // and must not silently select nothing.
  assert.deepEqual(resolvePageRange(4, NaN, NaN).indices, [0, 1, 2, 3]);
  assert.deepEqual(resolvePageRange(4, 2, NaN).indices, [1, 2, 3]);
});

test("a notebook with no pages yields no pages", () => {
  assert.deepEqual(resolvePageRange(0, 1, 5).indices, []);
});

console.log("\n-- Typing a page selection --");

test("the shorthand every note app accepts", () => {
  assert.deepEqual(parsePageSelection("2-5, 8", 10), [2, 3, 4, 5, 8]);
  assert.deepEqual(parsePageSelection("1,3", 10), [1, 3]);
  assert.deepEqual(parsePageSelection("7", 10), [7]);
});

test("open-ended ranges mean from-the-start and to-the-end", () => {
  assert.deepEqual(parsePageSelection("8-", 10), [8, 9, 10]);
  assert.deepEqual(parsePageSelection("-3", 10), [1, 2, 3]);
});

test("messy input still means something sensible", () => {
  assert.deepEqual(parsePageSelection("  4 - 2 ", 10), [2, 3, 4], "backwards and spaced");
  assert.deepEqual(parsePageSelection("2-4,", 10), [2, 3, 4], "trailing comma");
  assert.deepEqual(parsePageSelection("2\u20135", 10), [2, 3, 4, 5], "en-dash pasted from a PDF");
  assert.deepEqual(parsePageSelection("3,3,3", 10), [3], "duplicates collapse");
  assert.deepEqual(parsePageSelection("9-99", 10), [9, 10], "clamped to what exists");
});

test("nothing usable selects nothing, rather than throwing", () => {
  assert.deepEqual(parsePageSelection("", 10), []);
  assert.deepEqual(parsePageSelection("abc", 10), []);
  assert.deepEqual(parsePageSelection("-", 10), []);
  assert.deepEqual(parsePageSelection("1-3", 0), []);
});

test("a selection reads back the way it was typed", () => {
  assert.equal(formatPageSelection([1, 2, 3, 5]), "1-3, 5");
  assert.equal(formatPageSelection([4]), "4");
  assert.equal(formatPageSelection([]), "");
  assert.equal(formatPageSelection([3, 1, 2]), "1-3", "order does not matter");
});

test("typing a range and ticking pages are exact inverses", () => {
  // The dialog keeps the range box and the thumbnails in sync; that only
  // holds if these two round-trip.
  assert.equal(formatPageSelection(parsePageSelection("2-5, 8", 10)), "2-5, 8");
});

console.log("\n── Exporting a page range ──");

test("the export contains exactly the pages asked for", () => {
  const nb = notebook([page([stroke()]), page([stroke()]), page([stroke()]), page([stroke()])]);
  assert.equal(buildExportSvg(nb, { pages: { from: 2, to: 3 } }).report.pages, 2);
  assert.equal(buildExportSvg(nb, { pages: "all" }).report.pages, 4);
  assert.equal(buildExportSvg(nb, { pages: "current" }).report.pages, 1);
});

test("the range picks the RIGHT pages, not just the right number", () => {
  // Each page carries an identifiable piece of text, so the export can be
  // searched for it. Counting sheets alone would pass even if the export
  // always took the first N pages.
  const mk = (t: string) =>
    page([
      {
        id: `t_${t}`,
        type: "text",
        x: 5,
        y: 5,
        width: 100,
        height: 20,
        rotation: 0,
        opacity: 1,
        text: t,
        color: "#000",
        fontSize: 12,
        fontFamily: "Inter",
        fontWeight: 400,
        align: "left",
        createdAt: 1,
        updatedAt: 1,
      } as unknown as WhiteboardElement,
    ]);
  const nb = notebook([mk("ALPHA"), mk("BRAVO"), mk("CHARLIE"), mk("DELTA")]);
  const svg = buildExportSvg(nb, { pages: { from: 2, to: 3 } }).svg;
  assert.ok(!svg.includes("ALPHA"), "page 1 was left out");
  assert.ok(svg.includes("BRAVO"), "page 2 is in");
  assert.ok(svg.includes("CHARLIE"), "page 3 is in");
  assert.ok(!svg.includes("DELTA"), "page 4 was left out");
});

test("a backwards range exports rather than failing", () => {
  const nb = notebook([page(), page(), page()]);
  assert.equal(buildExportSvg(nb, { pages: { from: 3, to: 1 } }).report.pages, 3);
});

test("the filename says which pages are inside", () => {
  const nb = notebook([page(), page(), page(), page()]);
  nb.name = "Calculus Notes";
  assert.equal(exportFilename(nb, "pdf", { pages: { from: 2, to: 4 } }), "Calculus_Notes_p2-4.pdf");
  assert.equal(exportFilename(nb, "png", { pages: { from: 3, to: 3 } }), "Calculus_Notes_p3.png");
  assert.equal(exportFilename(nb, "pdf", { pages: "all" }), "Calculus_Notes.pdf");
});

test("a name full of punctuation still produces a legal filename", () => {
  const nb = notebook([page()]);
  nb.name = 'Week 3: "derivatives"/limits*?';
  const name = exportFilename(nb, "pdf", {});
  assert.ok(!/[:"/*?]/.test(name), `still has punctuation: ${name}`);
  assert.ok(name.endsWith(".pdf"));
});

test("every format gets its own extension", () => {
  const nb = notebook([page()]);
  nb.name = "n";
  assert.ok(exportFilename(nb, "jpeg", {}).endsWith(".jpg"), "jpeg is .jpg, as the world writes it");
  assert.ok(exportFilename(nb, "webp", {}).endsWith(".webp"));
  assert.ok(exportFilename(nb, "svg", {}).endsWith(".svg"));
});

console.log("\n── Copying pages between notebooks ──");

test("copied pages are independent of the originals", () => {
  const a = stroke();
  const src = notebook([page([a]), page([stroke()])]);
  const copies = copyPagesFrom(src, [0], "target", () => `new${seq++}`);

  assert.equal(copies.length, 1);
  assert.notEqual(copies[0].id, src.pages![0].id, "the page has a new id");
  assert.notEqual(copies[0].elements[0].id, a.id, "the element has a new id");
  assert.equal(src.pages![0].elements[0].id, a.id, "the source is untouched");
});

test("a connector between two copied elements follows them", () => {
  const a = stroke();
  const b = stroke();
  const conn = connection("c1", a.id, b.id, "src");
  const src = notebook([page([a, b, conn])]);

  const copies = copyPagesFrom(src, [0], "target", () => `new${seq++}`);
  const copied = copies[0].elements.find((e) => e.type === "connection") as ConnectionElement;

  assert.ok(copied, "the connector came along");
  assert.equal(copied.source.boardId, "target", "it points at the new board");
  assert.notEqual(copied.source.elementId, a.id, "at the new element ids");
  const ids = copies[0].elements.map((e) => e.id);
  assert.ok(ids.includes(copied.source.elementId), "which exist on the copied page");
  assert.ok(ids.includes(copied.target.elementId));
});

test("a connector to a page left behind is dropped, not left dangling", () => {
  const a = stroke();
  const far = stroke();
  const conn = connection("c2", a.id, far.id, "src");
  const src = notebook([page([a, conn]), page([far])]);

  // Copy only page 1: `far` stays behind.
  const copies = copyPagesFrom(src, [0], "target", () => `new${seq++}`);
  assert.equal(
    copies[0].elements.some((e) => e.type === "connection"),
    false,
    "the half-attached connector was removed"
  );
  assert.equal(copies[0].elements.length, 1, "the stroke itself is still there");
});

test("a connector to a DIFFERENT board keeps pointing there", () => {
  const a = stroke();
  const conn = connection("c3", a.id, "elsewhere", "src");
  conn.target.boardId = "other-board";
  const src = notebook([page([a, conn])]);

  const copied = copyPagesFrom(src, [0], "target", () => `new${seq++}`)[0].elements.find(
    (e) => e.type === "connection"
  ) as ConnectionElement;
  assert.ok(copied, "a cross-board link survives the copy");
  assert.equal(copied.target.boardId, "other-board");
  assert.equal(copied.target.elementId, "elsewhere", "untouched - it was never ours to remap");
});

test("a PDF-backed page keeps its reference and its paper", () => {
  const src = notebook([pageFromPdf("doc1", 7)]);
  const copy = copyPagesFrom(src, [0], "target", () => "x")[0];
  assert.deepEqual(copy.pdf, { docId: "doc1", pageNumber: 7 });
  assert.equal(copy.background?.pattern, "plain", "a PDF page is the paper; no dots over a slide");
});

console.log("\n── Inserting pages at a position ──");

test("pages land exactly where asked", () => {
  const nb = notebook([page(), page(), page()]);
  const mark = page();
  mark.id = "INSERTED";

  assert.equal(getPages(insertPages(nb, [mark], 0)).findIndex((p) => p.id === "INSERTED"), 0);
  assert.equal(getPages(insertPages(nb, [mark], 1)).findIndex((p) => p.id === "INSERTED"), 1);
  assert.equal(getPages(insertPages(nb, [mark], 3)).findIndex((p) => p.id === "INSERTED"), 3);
});

test("a position past the end appends instead of throwing away the pages", () => {
  const nb = notebook([page(), page()]);
  const mark = page();
  mark.id = "LAST";
  const out = insertPages(nb, [mark], 999);
  assert.equal(getPages(out).length, 3);
  assert.equal(getPages(out)[2].id, "LAST");
});

test("the first inserted page becomes the one you are looking at", () => {
  const nb = notebook([page(), page()]);
  const a = page();
  a.id = "FIRST_NEW";
  const b = page();
  const out = insertPages(nb, [a, b], 1);
  assert.equal(out.activePageId, "FIRST_NEW", "you are taken to what you just inserted");
});

test("inserting nothing changes nothing", () => {
  const nb = notebook([page(), page()]);
  assert.equal(insertPages(nb, [], 1), nb);
});

console.log("\n── Inserting through the store ──");

test("a range of another notebook's pages is copied in, and the source is untouched", () => {
  const source = storeNotebook("Source NB", 5);
  const target = storeNotebook("Target NB", 2);

  const n = S().insertPagesFromBoard(source, { from: 2, to: 4 }, 1);

  assert.equal(n, 3, "three pages inserted");
  assert.equal(getPages(board(target)).length, 5, "2 + 3");
  assert.equal(getPages(board(source)).length, 5, "the source still has all of its pages");
});

test("the inserted pages carry the source's ink, under new ids", () => {
  const source = storeNotebook("Ink Source", 3);
  const sourceIds = allElements(board(source)).map((e) => e.id);
  const target = storeNotebook("Ink Target", 1);

  S().insertPagesFromBoard(source, { from: 1, to: 3 }, 1);

  const targetEls = allElements(board(target));
  assert.equal(targetEls.length, 4, "one of its own plus three copied strokes");
  for (const id of targetEls.map((e) => e.id)) {
    assert.ok(!sourceIds.includes(id), `element ${id} reused a source id`);
  }
});

test("pages land at the position given", () => {
  const source = storeNotebook("Pos Source", 2);
  const target = storeNotebook("Pos Target", 3);
  const before = getPages(board(target)).map((p) => p.id);

  S().insertPagesFromBoard(source, { from: 1, to: 1 }, 0);

  const after = getPages(board(target)).map((p) => p.id);
  assert.equal(after.length, 4);
  assert.deepEqual(after.slice(1), before, "the original pages all moved down by one");
});

test("a whiteboard inserts as a single page", () => {
  const canvas = S().createBoard("A sketch", null);
  S().setActiveBoard(canvas);
  S().addElement(stroke(), true);
  const target = storeNotebook("Mixed NB", 1);

  const n = S().insertPagesFromBoard(canvas, { from: 1, to: 1 }, 1);
  assert.equal(n, 1, "the canvas counts as one page");
  assert.equal(getPages(board(target)).length, 2);
});

test("inserting into a whiteboard does nothing rather than corrupting it", () => {
  const source = storeNotebook("Src", 2);
  const canvas = S().createBoard("Not a notebook", null);
  S().setActiveBoard(canvas);

  assert.equal(S().insertPagesFromBoard(source, { from: 1, to: 2 }, 0), 0);
  assert.equal(getPages(board(canvas)).length, 0);
});

test("a copied PDF page is recorded on the new notebook, so it is not garbage-collected", () => {
  // The storage collector deletes any PDF no page references. A copied page
  // references it, and the target board must say so too or its own record of
  // its documents is a lie.
  const source = storeNotebook("PDF Source", 1);
  const pages = getPages(board(source));
  useWhiteboard.setState((s) => ({
    boards: s.boards.map((b) =>
      b.id === source
        ? { ...b, pages: [{ ...pages[0], pdf: { docId: "doc-xyz", pageNumber: 1 } }], pdfDocIds: ["doc-xyz"] }
        : b
    ),
  }));

  const target = storeNotebook("PDF Target", 1);
  S().insertPagesFromBoard(source, { from: 1, to: 1 }, 1);

  const t = board(target);
  assert.deepEqual(getPages(t)[1].pdf, { docId: "doc-xyz", pageNumber: 1 }, "the page still shows the PDF");
  assert.ok(t.pdfDocIds?.includes("doc-xyz"), "and the notebook lists the document");
});

test("an out-of-range request inserts nothing instead of blank pages", () => {
  const source = storeNotebook("Small", 2);
  const target = storeNotebook("Dest", 1);
  // Pages 9-12 of a 2-page notebook: clamped to the last page, not invented.
  const n = S().insertPagesFromBoard(source, { from: 9, to: 12 }, 1);
  assert.equal(n, 1, "clamped to the one page that exists");
  assert.equal(getPages(board(target)).length, 2);
});

console.log("\n── Sharing: where a file goes ──");

test("dismissing a share sheet is not an error", () => {
  assert.equal(isShareCancellation({ name: "AbortError" }), true, "the Web Share API's name for it");
  assert.equal(isShareCancellation(new Error("Share canceled")), true, "Android's wording");
  assert.equal(isShareCancellation(new Error("Share cancelled")), true);
  assert.equal(isShareCancellation(new Error("No space left on device")), false, "a real failure is not swallowed");
  assert.equal(isShareCancellation(null), false);
});

test("without a system share sheet, files fall back to a download", () => {
  // Node has no navigator.share, which is exactly the Electron case.
  assert.equal(canChooseApp(), false);
  assert.equal(shareRoute(), "download");
});

console.log(`\n  ${passed} passed, ${failed} failed\n`);
if (failed > 0) process.exit(1);
