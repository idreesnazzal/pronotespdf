#!/usr/bin/env node

/**
 * ProNotes E2E Test Suite Runner
 * ==============================
 * Master test runner executing Tiers 1-4 across all 22 features, boundary cases,
 * pairwise combinations, and real-world application scenarios.
 *
 * Exit Codes:
 *   0: All tests and assertions passed successfully.
 *   1: One or more tests or assertions failed.
 */

const path = require('path');
const { ctx, clearModuleCache, getAllBeforeEachFns, getAllAfterEachFns } = require('./test-helpers');

// Color formatting for console output
const colors = {
  reset: '\x1b[0m',
  bold: '\x1b[1m',
  dim: '\x1b[2m',
  green: '\x1b[32m',
  red: '\x1b[31m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  cyan: '\x1b[36m',
  magenta: '\x1b[35m',
  gray: '\x1b[90m',
  bgGreen: '\x1b[42m\x1b[30m',
  bgRed: '\x1b[41m\x1b[37m'
};

const TIERS = [
  { file: 'tier1-features.test.js', name: 'Tier 1: Feature Coverage (22 Features)', minAssertions: 110 },
  { file: 'tier2-boundaries.test.js', name: 'Tier 2: Boundary & Corner Cases (22 Features)', minAssertions: 110 },
  { file: 'tier3-pairwise.test.js', name: 'Tier 3: Pairwise Combinations (>=25 Tests)', minTests: 25 },
  { file: 'tier4-scenarios.test.js', name: 'Tier 4: Real-World Scenarios (>=5 Workflows)', minTests: 5 },
  // Written for milestone 3 but never added here, so it had quietly rotted
  // (it read the deleted start.bat). Wired in so it stays true.
  { file: 'm3-pwa-branding.test.js', name: 'Milestone 3: PWA, Icons & Branding', minTests: 1 }
];

async function runTestSuite() {
  const startTime = Date.now();
  console.log('\n' + colors.bold + colors.cyan + '='.repeat(80) + colors.reset);
  console.log(colors.bold + colors.cyan + '  🧠  ProNotes — Automated End-to-End Test Suite Runner' + colors.reset);
  console.log(colors.cyan + '='.repeat(80) + colors.reset + '\n');

  let totalTestsPassed = 0;
  let totalTestsFailed = 0;
  let totalAssertionsCount = 0;
  const tierResults = [];

  for (let tIdx = 0; tIdx < TIERS.length; tIdx++) {
    const tier = TIERS[tIdx];
    const tierStart = Date.now();
    console.log(colors.bold + colors.blue + `[Tier ${tIdx + 1}/${TIERS.length}] Loading ${tier.name}...` + colors.reset);

    // Reset test context for clean isolation
    ctx.reset();
    clearModuleCache();

    try {
      // Require and evaluate the test file
      const fullPath = path.resolve(__dirname, tier.file);
      delete require.cache[require.resolve(fullPath)];
      require(fullPath);
    } catch (loadErr) {
      console.error(colors.red + `[ERROR] Failed to load test suite ${tier.file}: ${loadErr.message}` + colors.reset);
      console.error(loadErr.stack);
      process.exit(1);
    }

    let tierPassedTests = 0;
    let tierFailedTests = 0;
    let tierAssertions = 0;

    for (const suite of ctx.suites) {
      if (suite.tests.length === 0) continue;
      console.log(`\n  ${colors.bold}${suite.name}${colors.reset}`);

      for (const testItem of suite.tests) {
        ctx.currentTest = testItem;
        const testStart = Date.now();

        try {
          // Execute all beforeEach hooks (ancestors -> current)
          const beforeFns = getAllBeforeEachFns(testItem.suite);
          for (const fn of beforeFns) {
            await fn();
          }

          // Execute test body
          await testItem.fn();

          // Execute all afterEach hooks (current -> ancestors)
          const afterFns = getAllAfterEachFns(testItem.suite);
          for (const fn of afterFns) {
            await fn();
          }

          testItem.durationMs = Date.now() - testStart;
          testItem.passed = true;
          tierPassedTests++;
          totalTestsPassed++;
          console.log(`    ${colors.green}✓${colors.reset} ${colors.gray}${testItem.name}${colors.reset} ${colors.dim}(${testItem.durationMs}ms)${colors.reset}`);
        } catch (err) {
          testItem.durationMs = Date.now() - testStart;
          testItem.passed = false;
          testItem.error = err;
          tierFailedTests++;
          totalTestsFailed++;
          console.log(`    ${colors.red}✗ ${testItem.name}${colors.reset} ${colors.dim}(${testItem.durationMs}ms)${colors.reset}`);
          console.log(`      ${colors.red}Error: ${err.message}${colors.reset}`);
          if (err.stack) {
            const stackLines = err.stack.split('\n').slice(1, 4).join('\n');
            console.log(`      ${colors.gray}${stackLines}${colors.reset}`);
          }
        }
      }
    }

    tierAssertions = ctx.totalAssertions;
    totalAssertionsCount += tierAssertions;
    const tierDuration = Date.now() - tierStart;

    tierResults.push({
      tierName: tier.name,
      passed: tierPassedTests,
      failed: tierFailedTests,
      total: tierPassedTests + tierFailedTests,
      assertions: tierAssertions,
      durationMs: tierDuration
    });

    console.log(`\n  ${colors.dim}--> ${tier.name}: ${tierPassedTests} passed, ${tierFailedTests} failed (${tierAssertions} assertions, ${tierDuration}ms)${colors.reset}\n`);
  }

  const totalDuration = Date.now() - startTime;

  // Print Comprehensive Summary Table
  console.log('\n' + colors.bold + colors.cyan + '='.repeat(80) + colors.reset);
  console.log(colors.bold + '  📊  E2E TEST EXECUTION SUMMARY' + colors.reset);
  console.log(colors.cyan + '='.repeat(80) + colors.reset);

  console.log(
    `  ${'Tier Name'.padEnd(52)} | ${'Tests'.padStart(7)} | ${'Pass'.padStart(5)} | ${'Fail'.padStart(5)} | ${'Assertions'.padStart(10)}`
  );
  console.log('  ' + '-'.repeat(88));

  for (const res of tierResults) {
    const statusColor = res.failed === 0 ? colors.green : colors.red;
    console.log(
      `  ${statusColor}${res.tierName.padEnd(52)}${colors.reset} | ` +
      `${String(res.total).padStart(7)} | ` +
      `${colors.green}${String(res.passed).padStart(5)}${colors.reset} | ` +
      `${res.failed > 0 ? colors.red : colors.gray}${String(res.failed).padStart(5)}${colors.reset} | ` +
      `${String(res.assertions).padStart(10)}`
    );
  }

  console.log('  ' + '-'.repeat(88));
  console.log(
    `  ${colors.bold}${'TOTAL'.padEnd(52)}${colors.reset} | ` +
    `${String(totalTestsPassed + totalTestsFailed).padStart(7)} | ` +
    `${colors.green}${String(totalTestsPassed).padStart(5)}${colors.reset} | ` +
    `${totalTestsFailed > 0 ? colors.red : colors.green}${String(totalTestsFailed).padStart(5)}${colors.reset} | ` +
    `${String(totalAssertionsCount).padStart(10)}`
  );

  console.log(colors.cyan + '='.repeat(80) + colors.reset);
  console.log(`  ⏱️  Total Duration: ${totalDuration}ms`);

  if (totalTestsFailed === 0) {
    console.log('\n' + colors.bgGreen + colors.bold + '  ✓ ALL E2E TESTS PASSED SUCCESSFULLY (Exit Code 0)  ' + colors.reset + '\n');
    process.exit(0);
  } else {
    console.log('\n' + colors.bgRed + colors.bold + `  ✗ ${totalTestsFailed} TEST(S) FAILED (Exit Code 1)  ` + colors.reset + '\n');
    process.exit(1);
  }
}

runTestSuite();
