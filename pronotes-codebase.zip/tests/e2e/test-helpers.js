/**
 * E2E Test Framework & Helpers for ProNotes
 * ==========================================
 * Provides lightweight test harness primitives (describe, it/test, expect, beforeEach, afterEach),
 * transparent TypeScript module loader using ts.transpileModule, DOM/Window/Storage simulation,
 * and vector math assertion utilities.
 */

const fs = require('fs');
const path = require('path');
const ts = require('typescript');

// ============================================================================
// Test Runner Harness Primitives
// ============================================================================

class TestContext {
  constructor() {
    this.suites = [];
    this.currentSuite = null;
    this.currentTest = null;
    this.totalAssertions = 0;
    this.passedAssertions = 0;
    this.failedAssertions = 0;
    this.featureCoverage = new Map(); // featureKey -> count
  }

  reset() {
    this.suites = [];
    this.currentSuite = null;
    this.currentTest = null;
    this.totalAssertions = 0;
    this.passedAssertions = 0;
    this.failedAssertions = 0;
    this.featureCoverage.clear();
  }
}

const ctx = new TestContext();

function describe(suiteName, fn) {
  const parentSuite = ctx.currentSuite;
  const suite = {
    name: suiteName,
    parent: parentSuite,
    tests: [],
    beforeEachFns: [],
    afterEachFns: [],
    passed: 0,
    failed: 0,
    durationMs: 0
  };
  ctx.suites.push(suite);
  ctx.currentSuite = suite;
  try {
    fn();
  } finally {
    ctx.currentSuite = parentSuite;
  }
}

function beforeEach(fn) {
  if (ctx.currentSuite) {
    ctx.currentSuite.beforeEachFns.push(fn);
  }
}

function afterEach(fn) {
  if (ctx.currentSuite) {
    ctx.currentSuite.afterEachFns.push(fn);
  }
}

function it(testName, fn, options = {}) {
  if (!ctx.currentSuite) {
    throw new Error(`Test "${testName}" must be inside a describe() block`);
  }
  const test = {
    name: testName,
    suite: ctx.currentSuite,
    fn,
    options,
    assertions: [],
    passed: true,
    error: null,
    durationMs: 0
  };
  ctx.currentSuite.tests.push(test);
}

const test = it;

function getAllBeforeEachFns(suite) {
  const fns = [];
  let curr = suite;
  while (curr) {
    if (curr.beforeEachFns && curr.beforeEachFns.length > 0) {
      fns.unshift(...curr.beforeEachFns);
    }
    curr = curr.parent;
  }
  return fns;
}

function getAllAfterEachFns(suite) {
  const fns = [];
  let curr = suite;
  while (curr) {
    if (curr.afterEachFns && curr.afterEachFns.length > 0) {
      fns.push(...curr.afterEachFns);
    }
    curr = curr.parent;
  }
  return fns;
}

function trackFeature(featureKey) {
  const count = ctx.featureCoverage.get(featureKey) || 0;
  ctx.featureCoverage.set(featureKey, count + 1);
}

// ============================================================================
// Assertions & Matchers
// ============================================================================

class Expectation {
  constructor(actual) {
    this.actual = actual;
    this.isNot = false;
  }

  get not() {
    this.isNot = !this.isNot;
    return this;
  }

  _record(pass, message, expected) {
    ctx.totalAssertions++;
    const finalPass = this.isNot ? !pass : pass;
    if (finalPass) {
      ctx.passedAssertions++;
    } else {
      ctx.failedAssertions++;
      const err = new Error(message || `Assertion failed: expected ${JSON.stringify(this.actual)} ${this.isNot ? 'NOT ' : ''}to match ${JSON.stringify(expected)}`);
      if (ctx.currentTest) {
        ctx.currentTest.passed = false;
        ctx.currentTest.error = err;
      }
      throw err;
    }
  }

  toBe(expected) {
    const pass = this.actual === expected || Object.is(this.actual, expected);
    this._record(pass, `Expected ${this.actual} to be ${expected}`, expected);
  }

  toEqual(expected) {
    const pass = deepEqual(this.actual, expected);
    this._record(pass, `Expected deep equality:\nActual:   ${JSON.stringify(this.actual)}\nExpected: ${JSON.stringify(expected)}`, expected);
  }

  toBeTruthy() {
    const pass = Boolean(this.actual);
    this._record(pass, `Expected ${this.actual} to be truthy`);
  }

  toBeFalsy() {
    const pass = !Boolean(this.actual);
    this._record(pass, `Expected ${this.actual} to be falsy`);
  }

  toBeNull() {
    const pass = this.actual === null;
    this._record(pass, `Expected ${this.actual} to be null`);
  }

  toBeUndefined() {
    const pass = this.actual === undefined;
    this._record(pass, `Expected ${this.actual} to be undefined`);
  }

  toBeDefined() {
    const pass = this.actual !== undefined;
    this._record(pass, `Expected value to be defined`);
  }

  toBeGreaterThan(expected) {
    const pass = typeof this.actual === 'number' && this.actual > expected;
    this._record(pass, `Expected ${this.actual} > ${expected}`, expected);
  }

  toBeGreaterThanOrEqual(expected) {
    const pass = typeof this.actual === 'number' && this.actual >= expected;
    this._record(pass, `Expected ${this.actual} >= ${expected}`, expected);
  }

  toBeLessThan(expected) {
    const pass = typeof this.actual === 'number' && this.actual < expected;
    this._record(pass, `Expected ${this.actual} < ${expected}`, expected);
  }

  toBeLessThanOrEqual(expected) {
    const pass = typeof this.actual === 'number' && this.actual <= expected;
    this._record(pass, `Expected ${this.actual} <= ${expected}`, expected);
  }

  toBeCloseTo(expected, precision = 2) {
    const pass = typeof this.actual === 'number' && Math.abs(this.actual - expected) < Math.pow(10, -precision) / 2;
    this._record(pass, `Expected ${this.actual} to be close to ${expected} (precision ${precision})`, expected);
  }

  toContain(expected) {
    let pass = false;
    if (typeof this.actual === 'string' || Array.isArray(this.actual)) {
      pass = this.actual.includes(expected);
    } else if (this.actual instanceof Set || this.actual instanceof Map) {
      pass = this.actual.has(expected);
    }
    this._record(pass, `Expected ${JSON.stringify(this.actual)} to contain ${JSON.stringify(expected)}`, expected);
  }

  toHaveLength(expected) {
    const len = this.actual ? this.actual.length : undefined;
    const pass = len === expected;
    this._record(pass, `Expected length ${len} to be ${expected}`, expected);
  }

  toMatch(regexOrString) {
    let pass = false;
    if (typeof regexOrString === 'string') {
      pass = typeof this.actual === 'string' && this.actual.includes(regexOrString);
    } else if (regexOrString instanceof RegExp) {
      pass = typeof this.actual === 'string' && regexOrString.test(this.actual);
    }
    this._record(pass, `Expected "${this.actual}" to match ${regexOrString}`, regexOrString);
  }

  toThrow(expectedError) {
    let threw = false;
    let thrownError = null;
    if (typeof this.actual !== 'function') {
      throw new Error('toThrow requires a function');
    }
    try {
      this.actual();
    } catch (e) {
      threw = true;
      thrownError = e;
    }
    if (!threw) {
      this._record(false, 'Expected function to throw an error, but it did not');
      return;
    }
    if (expectedError) {
      if (typeof expectedError === 'string') {
        const pass = thrownError.message.includes(expectedError);
        this._record(pass, `Expected error message "${thrownError.message}" to include "${expectedError}"`, expectedError);
      } else if (expectedError instanceof RegExp) {
        const pass = expectedError.test(thrownError.message);
        this._record(pass, `Expected error message "${thrownError.message}" to match ${expectedError}`, expectedError);
      } else {
        this._record(true);
      }
    } else {
      this._record(true);
    }
  }
}

function expect(actual) {
  return new Expectation(actual);
}

function deepEqual(a, b) {
  if (a === b || Object.is(a, b)) return true;
  if (typeof a !== 'object' || a === null || typeof b !== 'object' || b === null) return false;
  if (Array.isArray(a) !== Array.isArray(b)) return false;

  if (Array.isArray(a)) {
    if (a.length !== b.length) return false;
    for (let i = 0; i < a.length; i++) {
      if (!deepEqual(a[i], b[i])) return false;
    }
    return true;
  }

  const keysA = Object.keys(a);
  const keysB = Object.keys(b);
  if (keysA.length !== keysB.length) return false;
  for (const k of keysA) {
    if (!Object.prototype.hasOwnProperty.call(b, k)) return false;
    if (!deepEqual(a[k], b[k])) return false;
  }
  return true;
}

// ============================================================================
// Environment Simulation (DOM / Window / LocalStorage)
// ============================================================================

let mockStorage = {};

function setupMockDom() {
  mockStorage = {};
  global.window = {
    innerWidth: 1200,
    innerHeight: 800,
    devicePixelRatio: 2,
    localStorage: {
      getItem: (k) => mockStorage[k] || null,
      setItem: (k, v) => { mockStorage[k] = String(v); },
      removeItem: (k) => { delete mockStorage[k]; },
      clear: () => { mockStorage = {}; },
      key: (i) => Object.keys(mockStorage)[i] || null,
      get length() { return Object.keys(mockStorage).length; }
    },
    addEventListener: () => {},
    removeEventListener: () => {},
    matchMedia: () => ({ matches: false, addEventListener: () => {}, removeEventListener: () => {} }),
    navigator: {
      userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) ProNotes/1.0',
      maxTouchPoints: 5,
      serviceWorker: {
        register: async () => ({ scope: '/' }),
        ready: Promise.resolve({ scope: '/' })
      }
    }
  };

  global.document = {
    createElement: (tag) => {
      if (tag === 'canvas') {
        return {
          width: 0,
          height: 0,
          getContext: () => ({
            fillRect: () => {},
            drawImage: () => {},
            scale: () => {},
            getImageData: () => ({ data: new Uint8ClampedArray(4) })
          }),
          toDataURL: (type) => `data:${type || 'image/png'};base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==`,
          toBlob: (cb, type) => cb(new Blob([], { type: type || 'image/png' }))
        };
      }
      return {
        style: {},
        setAttribute: () => {},
        getAttribute: () => null,
        appendChild: () => {},
        removeChild: () => {},
        click: () => {}
      };
    },
    getElementById: () => null,
    body: { appendChild: () => {}, removeChild: () => {} }
  };

  global.Blob = global.Blob || class MockBlob {
    constructor(parts, options = {}) {
      this.parts = parts;
      this.type = options.type || '';
      this.size = parts.reduce((acc, p) => acc + (typeof p === 'string' ? p.length : (p.byteLength || 0)), 0);
    }
  };

  global.URL = global.URL || {
    createObjectURL: (blob) => `blob:mock-url-${Math.random()}`,
    revokeObjectURL: () => {}
  };
}

// ============================================================================
// TypeScript Module Loader
// ============================================================================

const moduleCache = new Map();

function loadTsModule(relativePathFromRoot) {
  const rootDir = path.resolve(__dirname, '../../');
  let fullPath = path.resolve(rootDir, relativePathFromRoot);

  if (!fs.existsSync(fullPath)) {
    if (fs.existsSync(fullPath + '.ts')) fullPath += '.ts';
    else if (fs.existsSync(fullPath + '.tsx')) fullPath += '.tsx';
    else if (fs.existsSync(fullPath + '.js')) fullPath += '.js';
    else if (fs.existsSync(fullPath + '/index.ts')) fullPath += '/index.ts';
    else if (fs.existsSync(fullPath + '/index.tsx')) fullPath += '/index.tsx';
  }

  if (moduleCache.has(fullPath)) {
    return moduleCache.get(fullPath);
  }

  if (!fs.existsSync(fullPath)) {
    throw new Error(`Cannot find module file at ${fullPath}`);
  }

  const code = fs.readFileSync(fullPath, 'utf-8');
  const transpiled = ts.transpileModule(code, {
    compilerOptions: {
      module: ts.ModuleKind.CommonJS,
      target: ts.ScriptTarget.ES2022,
      esModuleInterop: true,
      jsx: ts.JsxEmit.ReactJSX,
      baseUrl: rootDir,
      paths: {
        "@/*": ["src/*"]
      }
    }
  });

  const m = { exports: {} };
  moduleCache.set(fullPath, m.exports);

  const req = (mod) => {
    if (mod.startsWith('@/')) {
      return loadTsModule(path.join('src', mod.slice(2)));
    }
    if (mod.startsWith('./') || mod.startsWith('../')) {
      const targetRel = path.relative(rootDir, path.resolve(path.dirname(fullPath), mod));
      return loadTsModule(targetRel);
    }
    return require(mod);
  };

  try {
    const fn = new Function('require', 'module', 'exports', '__dirname', '__filename', transpiled.outputText);
    fn(req, m, m.exports, path.dirname(fullPath), fullPath);
    moduleCache.set(fullPath, m.exports);
    return m.exports;
  } catch (err) {
    moduleCache.delete(fullPath);
    throw new Error(`Failed to execute transpiled module ${relativePathFromRoot}: ${err.message}\n${err.stack}`);
  }
}

// Clear module cache
function clearModuleCache() {
  moduleCache.clear();
}

module.exports = {
  ctx,
  describe,
  it,
  test,
  beforeEach,
  afterEach,
  expect,
  getAllBeforeEachFns,
  getAllAfterEachFns,
  trackFeature,
  setupMockDom,
  loadTsModule,
  clearModuleCache,
  getMockStorage: () => mockStorage
};
