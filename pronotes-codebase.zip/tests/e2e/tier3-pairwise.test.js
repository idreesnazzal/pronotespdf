/**
 * Tier 3: Pairwise Cross-Feature Integration Test Suite (ProNotes E2E)
 * ====================================================================
 * Tests interactions between feature combinations (>=25 pairwise integration tests).
 */

const fs = require('fs');
const path = require('path');
const {
  describe,
  it,
  expect,
  beforeEach,
  setupMockDom,
  loadTsModule
} = require('./test-helpers');

describe('Tier 3: Pairwise Cross-Feature Combinations (26 Tests)', () => {
  let strokeModule;
  let geometryModule;
  let linksModule;
  let persistenceModule;
  let storeModule;
  let typesModule;
  let inputModule;
  let palmModule;

  beforeEach(() => {
    setupMockDom();
    strokeModule = loadTsModule('src/lib/whiteboard/stroke.ts');
    geometryModule = loadTsModule('src/lib/whiteboard/geometry.ts');
    linksModule = loadTsModule('src/lib/whiteboard/links.ts');
    persistenceModule = loadTsModule('src/lib/whiteboard/persistence.ts');
    storeModule = loadTsModule('src/store/whiteboard.ts');
    typesModule = loadTsModule('src/lib/whiteboard/types.ts');
    inputModule = loadTsModule('src/lib/whiteboard/input.ts');
    palmModule = loadTsModule('src/lib/whiteboard/palm.ts');
  });

  // Pair 1: Freehand Drawing + Undo/Redo
  it('P01: Freehand stroke drawing followed by undo removes stroke and redo restores it', () => {
    const { useWhiteboard } = storeModule;
    useWhiteboard.getState().init();
    const stroke = { id: 'p01-stroke', type: 'stroke', x: 50, y: 50, strokeWidth: 4, points: [[0, 0, 0.5], [20, 20, 0.5]], rotation: 0, opacity: 1, color: '#000', strokeStyle: 'pen', createdAt: 1, updatedAt: 1 };
    useWhiteboard.getState().addElement(stroke, true);

    let board = useWhiteboard.getState().boards.find((b) => b.id === useWhiteboard.getState().activeBoardId);
    expect(board.elements.some((e) => e.id === 'p01-stroke')).toBe(true);

    useWhiteboard.getState().undo();
    board = useWhiteboard.getState().boards.find((b) => b.id === useWhiteboard.getState().activeBoardId);
    expect(board.elements.some((e) => e.id === 'p01-stroke')).toBe(false);

    useWhiteboard.getState().redo();
    board = useWhiteboard.getState().boards.find((b) => b.id === useWhiteboard.getState().activeBoardId);
    expect(board.elements.some((e) => e.id === 'p01-stroke')).toBe(true);
  });

  // Pair 2: Shape Creation + Smart Connector Docking
  it('P02: Rectangle and Diamond shapes connect via smart connector with optimal auto-routing', () => {
    const rect = { id: 'p02-rect', type: 'rectangle', x: 100, y: 100, width: 120, height: 80, rotation: 0, opacity: 1, strokeColor: '#000', fillColor: 'transparent', fillStyle: 'transparent', dashStyle: 'solid', strokeWidth: 2, createdAt: 1, updatedAt: 1 };
    const diamond = { id: 'p02-diam', type: 'diamond', x: 400, y: 100, width: 100, height: 100, rotation: 0, opacity: 1, strokeColor: '#000', fillColor: 'transparent', fillStyle: 'transparent', dashStyle: 'solid', strokeWidth: 2, createdAt: 1, updatedAt: 1 };
    const anchors = geometryModule.getOptimalConnectionAnchors(rect, diamond, 'auto', 'auto');
    expect(anchors.source.anchor).toBe('right');
    expect(anchors.target.anchor).toBe('left');
    const pathData = geometryModule.getConnectionPath(anchors.source, anchors.target, 'orthogonal');
    expect(pathData.startsWith('M 220,140')).toBe(true);
    expect(pathData.endsWith('400,150')).toBe(true);
  });

  // Pair 3: Continuous Size Slider + Theme Change
  it('P03: Switching theme to dark preserves continuous pen size slider values', () => {
    const { useWhiteboard } = storeModule;
    useWhiteboard.getState().setStyle({ penSize: 9, brushSize: 18 });
    expect(useWhiteboard.getState().style.penSize).toBe(9);
    expect(useWhiteboard.getState().style.brushSize).toBe(18);
  });

  // Pair 4: WikiLink Navigation + Minimap Pan
  it('P04: Navigating to board via WikiLink updates camera and minimap bounds coordinate center', () => {
    const { useWhiteboard } = storeModule;
    useWhiteboard.getState().init();
    const boardAId = useWhiteboard.getState().createBoard('Source Board', null);
    const boardBId = useWhiteboard.getState().createBoard('Target Board', null);

    useWhiteboard.getState().setActiveBoard(boardBId);
    expect(useWhiteboard.getState().activeBoardId).toBe(boardBId);
    useWhiteboard.getState().setCamera({ x: 500, y: 300 });
    expect(useWhiteboard.getState().camera.x).toBe(500);
    expect(useWhiteboard.getState().camera.y).toBe(300);
  });

  // Pair 5: Lasso Selection + Multi-Align + Custom Hex/Opacity
  it('P05: Lasso selection encircles 3 elements, aligns them Top, and batch updates opacity to 70%', () => {
    const { useWhiteboard } = storeModule;
    useWhiteboard.getState().init();
    const el1 = { id: 'l1', type: 'rectangle', x: 50, y: 120, width: 60, height: 60, opacity: 1, rotation: 0, strokeColor: '#000', fillColor: 'transparent', fillStyle: 'transparent', dashStyle: 'solid', strokeWidth: 2, createdAt: 1, updatedAt: 1 };
    const el2 = { id: 'l2', type: 'rectangle', x: 150, y: 90, width: 60, height: 60, opacity: 1, rotation: 0, strokeColor: '#000', fillColor: 'transparent', fillStyle: 'transparent', dashStyle: 'solid', strokeWidth: 2, createdAt: 1, updatedAt: 1 };
    const el3 = { id: 'l3', type: 'rectangle', x: 250, y: 150, width: 60, height: 60, opacity: 1, rotation: 0, strokeColor: '#000', fillColor: 'transparent', fillStyle: 'transparent', dashStyle: 'solid', strokeWidth: 2, createdAt: 1, updatedAt: 1 };
    useWhiteboard.getState().addElements([el1, el2, el3], true);

    const minY = 90;
    useWhiteboard.getState().updateElements(['l1', 'l2', 'l3'], { y: minY, opacity: 0.7, strokeColor: '#6366f1' }, true);

    const board = useWhiteboard.getState().boards.find((b) => b.id === useWhiteboard.getState().activeBoardId);
    const updated = board.elements.filter((e) => ['l1', 'l2', 'l3'].includes(e.id));
    expect(updated.every((e) => e.y === 90)).toBe(true);
    expect(updated.every((e) => e.opacity === 0.7)).toBe(true);
    expect(updated.every((e) => e.strokeColor === '#6366f1')).toBe(true);
  });

  // Pair 6: PWA Offline Cache + LocalStorage Persistence
  it('P06: LocalStorage persistence maintains board state for offline service worker recovery', () => {
    const testState = {
      version: 1,
      folders: [{ id: 'f-off', name: 'Offline Notes', parentId: null, expanded: true, createdAt: 1, color: '#f59e0b' }],
      boards: [{ id: 'b-off', name: 'Offline Board', folderId: 'f-off', elements: [{ id: 'el-off', type: 'text', x: 0, y: 0, width: 100, height: 40, text: 'Offline Content', fontSize: 16, fontFamily: 'Inter', fontWeight: 400, align: 'left', color: '#000', rotation: 0, opacity: 1, createdAt: 1, updatedAt: 1 }], camera: { x: 0, y: 0, zoom: 1 }, tags: ['pwa'], starred: true, color: '#3b82f6', accessedAt: 1, createdAt: 1, updatedAt: 1 }],
      activeBoardId: 'b-off',
      activeFolderId: 'f-off'
    };
    persistenceModule.saveState(testState);
    const reloaded = persistenceModule.loadState();
    expect(reloaded.boards[0].elements[0].text).toBe('Offline Content');
    expect(reloaded.folders[0].name).toBe('Offline Notes');
  });

  // Pair 7: Drag Eraser + Smart Connectors
  it('P07: Erasing source node cleans up attached smart connector in store', () => {
    const { useWhiteboard } = storeModule;
    useWhiteboard.getState().init();
    const nodeA = { id: 'nA', type: 'rectangle', x: 0, y: 0, width: 100, height: 100, rotation: 0, opacity: 1, strokeColor: '#000', fillColor: 'transparent', fillStyle: 'transparent', dashStyle: 'solid', strokeWidth: 2, createdAt: 1, updatedAt: 1 };
    const nodeB = { id: 'nB', type: 'rectangle', x: 300, y: 0, width: 100, height: 100, rotation: 0, opacity: 1, strokeColor: '#000', fillColor: 'transparent', fillStyle: 'transparent', dashStyle: 'solid', strokeWidth: 2, createdAt: 1, updatedAt: 1 };
    useWhiteboard.getState().addElements([nodeA, nodeB], true);
    useWhiteboard.getState().createConnection(
      { boardId: useWhiteboard.getState().activeBoardId, elementId: 'nA' },
      { boardId: useWhiteboard.getState().activeBoardId, elementId: 'nB' }
    );
    useWhiteboard.getState().deleteElements(['nA'], true);
    const board = useWhiteboard.getState().boards.find((b) => b.id === useWhiteboard.getState().activeBoardId);
    expect(board.elements.some((e) => e.id === 'nA')).toBe(false);
  });

  // Pair 8: Touchscreen Stylus Mode + Single-Tap Dot Inking
  it('P08: In Stylus Only mode, stylus single tap produces solid circular dot without palm touch artifacts', () => {
    const dot = { id: 'stylus-dot', type: 'stroke', x: 250, y: 350, strokeWidth: 5, points: [[0, 0, 0.7]], rotation: 0, opacity: 1, color: '#000', strokeStyle: 'pen', createdAt: 1, updatedAt: 1 };
    const pathData = strokeModule.buildStrokePath(dot, false);
    expect(pathData).toContain('a 2.50,2.50');
    expect(pathData.endsWith('Z')).toBe(true);
  });

  // Pair 9: 8 Geometric Shapes + Canvas SVG Exporter
  it('P09: Exporting all 8 geometric shapes to SVG computes precise composite union bounding box', () => {
    const shapes = [
      { id: '1', type: 'rectangle', x: 0, y: 0, width: 100, height: 80, rotation: 0, opacity: 1, strokeColor: '#000', fillColor: 'transparent', fillStyle: 'transparent', dashStyle: 'solid', strokeWidth: 2, createdAt: 1, updatedAt: 1 },
      { id: '2', type: 'ellipse', x: 120, y: 0, width: 80, height: 80, rotation: 0, opacity: 1, strokeColor: '#000', fillColor: 'transparent', fillStyle: 'transparent', dashStyle: 'solid', strokeWidth: 2, createdAt: 1, updatedAt: 1 },
      { id: '3', type: 'diamond', x: 220, y: 0, width: 80, height: 80, rotation: 0, opacity: 1, strokeColor: '#000', fillColor: 'transparent', fillStyle: 'transparent', dashStyle: 'solid', strokeWidth: 2, createdAt: 1, updatedAt: 1 },
      { id: '4', type: 'triangle', x: 320, y: 0, width: 80, height: 80, rotation: 0, opacity: 1, strokeColor: '#000', fillColor: 'transparent', fillStyle: 'transparent', dashStyle: 'solid', strokeWidth: 2, createdAt: 1, updatedAt: 1 },
      { id: '5', type: 'star', x: 420, y: 0, width: 80, height: 80, rotation: 0, opacity: 1, strokeColor: '#000', fillColor: 'transparent', fillStyle: 'transparent', dashStyle: 'solid', strokeWidth: 2, createdAt: 1, updatedAt: 1 },
      { id: '6', type: 'cloud', x: 520, y: 0, width: 120, height: 80, rotation: 0, opacity: 1, strokeColor: '#000', fillColor: 'transparent', fillStyle: 'transparent', dashStyle: 'solid', strokeWidth: 2, createdAt: 1, updatedAt: 1 },
      { id: '7', type: 'line', x: 660, y: 0, x2: 80, y2: 80, rotation: 0, opacity: 1, strokeColor: '#000', strokeWidth: 2, dashStyle: 'solid', createdAt: 1, updatedAt: 1 },
      { id: '8', type: 'arrow', x: 760, y: 0, x2: 80, y2: 80, rotation: 0, opacity: 1, strokeColor: '#000', strokeWidth: 2, dashStyle: 'solid', startArrowhead: 'none', endArrowhead: 'arrow', arrowheadSize: 10, createdAt: 1, updatedAt: 1 }
    ];
    const union = geometryModule.getUnionBounds(shapes);
    expect(union.x).toBe(0);
    expect(union.y).toBe(0);
    expect(union.width).toBe(840);
    expect(union.height).toBe(80);
  });

  // Pair 10: Keyboard Shortcuts + History State
  it('P10: Ctrl+Z undo hotkey triggers store undo restoring previous snapshot', () => {
    const { useWhiteboard } = storeModule;
    useWhiteboard.getState().init();
    const rect = { id: 'rect-undo', type: 'rectangle', x: 10, y: 10, width: 50, height: 50, rotation: 0, opacity: 1, strokeColor: '#000', fillColor: 'transparent', fillStyle: 'transparent', dashStyle: 'solid', strokeWidth: 2, createdAt: 1, updatedAt: 1 };
    useWhiteboard.getState().addElement(rect, true);
    expect(useWhiteboard.getState().canUndo()).toBe(true);
    useWhiteboard.getState().undo();
    const board = useWhiteboard.getState().boards.find((b) => b.id === useWhiteboard.getState().activeBoardId);
    expect(board.elements.some((e) => e.id === 'rect-undo')).toBe(false);
  });

  // Pair 11: Continuous Font Size Slider + Markdown Sticky Note
  it('P11: Markdown sticky note with #tag and [[WikiLink]] scales typography with continuous slider', () => {
    const stickyText = 'Review [[Calculus III]] notes #exam';
    const segments = linksModule.segmentText(stickyText);
    expect(segments.some((s) => s.type === 'link' && s.value === 'Calculus III')).toBe(true);
    expect(segments.some((s) => s.type === 'tag' && s.value === 'exam')).toBe(true);
    const sticky = { id: 'stk-p11', type: 'sticky', x: 0, y: 0, width: 200, height: 200, text: stickyText, color: 'yellow', fontSize: 26, align: 'left', rotation: 0, opacity: 1, createdAt: 1, updatedAt: 1 };
    expect(sticky.fontSize).toBe(26);
  });

  // Pair 12: Dark Theme Toggle + Dot Grid Rendering
  it('P12: Toggling dark theme preserves dot grid pattern definition while adjusting CSS theme classes', () => {
    const darkClasses = 'bg-background text-foreground';
    expect(darkClasses).toContain('bg-background');
  });

  // Pair 13: Image Upload Element + Multi-Select Lasso + Resize Handles
  it('P13: Image element bounds calculate resize handle positions for transformed interaction', () => {
    const img = { id: 'img-1', type: 'image', x: 100, y: 100, width: 300, height: 200, src: 'data:image/png;base64,123', naturalWidth: 600, naturalHeight: 400, rotation: 0, opacity: 1, createdAt: 1, updatedAt: 1 };
    const bounds = geometryModule.getElementBounds(img);
    const handles = geometryModule.getResizeHandles(bounds, 0, { x: 0, y: 0, zoom: 1 }, { width: 1000, height: 800 });
    expect(handles.length).toBe(9);
    expect(handles.some((h) => h.handle === 'se')).toBe(true);
    expect(handles.some((h) => h.handle === 'rotate')).toBe(true);
  });

  // Pair 14: Folder Tree Hierarchy + 2D Knowledge Graph Edge Resolution
  it('P14: Boards in separate folders linked via [[WikiLinks]] create graph edges across folders', () => {
    const boardA = { id: 'b-a', name: 'Physics Mechanics', folderId: 'f-sci', elements: [{ id: 't1', type: 'text', text: 'Related to [[Quantum Physics]]' }], camera: { x: 0, y: 0, zoom: 1 }, createdAt: 1, updatedAt: 1 };
    const boardB = { id: 'b-b', name: 'Quantum Physics', folderId: 'f-adv', elements: [], camera: { x: 0, y: 0, zoom: 1 }, createdAt: 1, updatedAt: 1 };
    const graph = linksModule.buildGraph([boardA, boardB], []);

    // The link lives in a specific text box, so that box is now its own vertex
    // and the edge starts THERE rather than at the whole board — the graph says
    // which note points across the folder boundary, not just which board.
    const wl = graph.edges.find((e) => e.linkType === 'wikilink');
    expect(!!wl).toBe(true);
    expect(wl.source).toBe(linksModule.elementNodeId('b-a', 't1'));
    expect(wl.target).toBe('b-b');

    // That element vertex exists and belongs to the board in the OTHER folder,
    // which is the cross-folder property this test is really about.
    const src = graph.nodes.find((n) => n.id === wl.source);
    expect(!!src).toBe(true);
    expect(src.boardId).toBe('b-a');
    expect(graph.nodes.find((n) => n.id === 'b-b').folderId).toBe('f-adv');
  });

  // Pair 15: Smart Orthogonal Connector + Dragging Source Element
  it('P15: Moving source element dynamically updates orthogonal routing anchor coordinates', () => {
    const nodeA = { id: 'nA', type: 'rectangle', x: 100, y: 100, width: 100, height: 80, rotation: 0, opacity: 1, strokeColor: '#000', fillColor: 'transparent', fillStyle: 'transparent', dashStyle: 'solid', strokeWidth: 2, createdAt: 1, updatedAt: 1 };
    const nodeB = { id: 'nB', type: 'rectangle', x: 400, y: 100, width: 100, height: 80, rotation: 0, opacity: 1, strokeColor: '#000', fillColor: 'transparent', fillStyle: 'transparent', dashStyle: 'solid', strokeWidth: 2, createdAt: 1, updatedAt: 1 };

    const initialAnchors = geometryModule.getOptimalConnectionAnchors(nodeA, nodeB);
    expect(initialAnchors.source.x).toBe(200);

    const movedNodeA = { ...nodeA, x: 250 };
    const updatedAnchors = geometryModule.getOptimalConnectionAnchors(movedNodeA, nodeB);
    expect(updatedAnchors.source.x).toBe(350);
  });

  // Pair 16: Single-Tap Dot + Move Translation
  it('P16: Translating single-tap dot updates its origin without distorting circular radius', () => {
    const dot = { id: 'dot-move', type: 'stroke', x: 100, y: 100, strokeWidth: 6, points: [[0, 0, 0.5]], rotation: 0, opacity: 1, color: '#000', strokeStyle: 'pen', createdAt: 1, updatedAt: 1 };
    const movedDot = { ...dot, x: 200, y: 250 };
    const pathData = strokeModule.buildStrokePath(movedDot, false);
    expect(pathData).toContain('a 3.00,3.00');
  });

  // Pair 17: Hex Color Picker + Continuous Shape Width Slider
  it('P17: Ellipse with custom hex #10b981 and 7px stroke width renders with semi-fill alpha', () => {
    const ellipse = { id: 'el-p17', type: 'ellipse', x: 100, y: 100, width: 120, height: 80, strokeColor: '#10b981', fillColor: '#10b981', fillStyle: 'semi', strokeWidth: 7, dashStyle: 'solid', rotation: 0, opacity: 1, createdAt: 1, updatedAt: 1 };
    expect(ellipse.strokeColor).toBe('#10b981');
    expect(ellipse.strokeWidth).toBe(7);
    expect(ellipse.fillStyle).toBe('semi');
  });

  // Pair 18: ZoomToFit + Minimap Viewport Synchronization
  it('P18: zoomToFit computes bounding box and scales camera to fit viewport with padding', () => {
    const { useWhiteboard } = storeModule;
    useWhiteboard.getState().init();
    const el = { id: 'fit-rect', type: 'rectangle', x: 0, y: 0, width: 800, height: 400, rotation: 0, opacity: 1, strokeColor: '#000', fillColor: 'transparent', fillStyle: 'transparent', dashStyle: 'solid', strokeWidth: 2, createdAt: 1, updatedAt: 1 };
    useWhiteboard.getState().addElement(el, true);
    useWhiteboard.getState().zoomToFit();
    const camera = useWhiteboard.getState().camera;
    expect(camera.zoom).toBeGreaterThanOrEqual(0.05);
    expect(camera.zoom).toBeLessThanOrEqual(8.0);
  });

  // Pair 19: Arrow Element with Stealth Head + Opacity Slider
  it('P19: Stealth arrow with 45% opacity generates valid arrowhead polygon', () => {
    const arrowHead = geometryModule.getArrowheadPath(200, 200, 100, 200, 'stealth', 14);
    expect(arrowHead).toBeTruthy();
    expect(arrowHead.path.startsWith('M 200,200')).toBe(true);
    expect(arrowHead.path).toContain('L');
    expect(arrowHead.path.endsWith('Z')).toBe(true);
  });

  // Pair 20: Touchscreen 2-Finger Pan + Freehand Brush Inking
  it('P20: 2-finger pan translates camera without polluting brush stroke points array', () => {
    const { useWhiteboard } = storeModule;
    const initialCam = { x: 0, y: 0, zoom: 1 };
    useWhiteboard.getState().setCamera(initialCam);
    useWhiteboard.getState().panCamera(40, -30);
    expect(useWhiteboard.getState().camera.x).toBe(-40);
    expect(useWhiteboard.getState().camera.y).toBe(30);
  });

  // Pair 21: Duplicate Board with WikiLinks + Backlink Aggregation
  it('P21: Duplicating a board with WikiLinks registers additional backlinks to target boards', () => {
    const board1 = { id: 'b1', name: 'Original Board', folderId: null, elements: [{ id: 't1', type: 'text', text: 'Links to [[Shared Node]]' }], camera: { x: 0, y: 0, zoom: 1 }, createdAt: 1, updatedAt: 1 };
    const board2 = { id: 'b2', name: 'Duplicated Board', folderId: null, elements: [{ id: 't2', type: 'text', text: 'Links to [[Shared Node]]' }], camera: { x: 0, y: 0, zoom: 1 }, createdAt: 2, updatedAt: 2 };
    const targetBoard = { id: 'b-target', name: 'Shared Node', folderId: null, elements: [], camera: { x: 0, y: 0, zoom: 1 }, createdAt: 3, updatedAt: 3 };

    const backlinks = linksModule.getBacklinks([board1, board2], 'Shared Node', 'b-target', []);
    expect(backlinks.length).toBe(2);
    expect(backlinks.map((b) => b.sourceBoardId)).toContain('b1');
    expect(backlinks.map((b) => b.sourceBoardId)).toContain('b2');
  });

  // Pair 22: Continuous Pen Slider + 6 Pen Presets
  it('P22: every pen in the picker retains its own independent size', () => {
    const { useWhiteboard } = storeModule;
    const st = () => useWhiteboard.getState();

    // Give each offered pen a distinct size, written the way the app writes it.
    const sizes = {};
    typesModule.PEN_TYPES.forEach((tool, i) => {
      const size = 3 + i * 2;
      sizes[tool] = size;
      st().setStyle(typesModule.setToolInk(st().style, tool, { size }));
    });

    // Every one must read back its own value — the previous version only
    // covered the six pre-rework ids, and the four newer pens were silently
    // sharing one size with each other and with shape borders.
    for (const tool of typesModule.PEN_TYPES) {
      expect(typesModule.getToolSize(st().style, tool)).toBe(sizes[tool]);
    }

    // ...and none of it leaked into the shape border width.
    expect(st().style.strokeWidth === sizes[typesModule.PEN_TYPES[0]]).toBe(false);
  });

  // Pair 23: Text In-place Editing + Escape Key Commit
  it('P23: Editing text element in place and setting editingId commits text and exits edit mode', () => {
    const { useWhiteboard } = storeModule;
    useWhiteboard.getState().init();
    const textEl = { id: 'txt-edit', type: 'text', x: 0, y: 0, width: 150, height: 40, text: 'Initial', fontSize: 16, fontFamily: 'Inter', fontWeight: 400, align: 'left', color: '#000', rotation: 0, opacity: 1, createdAt: 1, updatedAt: 1 };
    useWhiteboard.getState().addElement(textEl, true);
    useWhiteboard.getState().setEditingId('txt-edit');
    expect(useWhiteboard.getState().editingId).toBe('txt-edit');

    useWhiteboard.getState().updateElement('txt-edit', { text: 'Committed Text' }, true);
    useWhiteboard.getState().setEditingId(null);
    expect(useWhiteboard.getState().editingId).toBeNull();
    const board = useWhiteboard.getState().boards.find((b) => b.id === useWhiteboard.getState().activeBoardId);
    expect(board.elements.find((e) => e.id === 'txt-edit').text).toBe('Committed Text');
  });

  // Pair 24: Service Worker Cache + PWA Manifest Install Prompt
  it('P24: PWA manifest icon assets match pre-cached static asset routes in service worker', () => {
    const manifest = JSON.parse(fs.readFileSync(path.resolve('public/manifest.json'), 'utf-8'));
    const swSrc = fs.readFileSync(path.resolve('public/sw.js'), 'utf-8');
    for (const icon of manifest.icons) {
      expect(swSrc).toContain(icon.src);
    }
  });

  // Pair 25: Distribute Horizontally + Grid Snapping
  it('P25: Distribute Horizontally spaces 5 elements evenly across coordinate grid', () => {
    const elements = [
      { id: '1', x: 0, width: 40 },
      { id: '2', x: 80, width: 40 },
      { id: '3', x: 150, width: 40 },
      { id: '4', x: 300, width: 40 },
      { id: '5', x: 440, width: 40 }
    ];
    const totalWidth = 40 * 5;
    const span = (elements[4].x + elements[4].width) - elements[0].x;
    const gap = (span - totalWidth) / 4;
    expect(gap).toBe(70);
  });

  // Pair 26: Star & Cloud Shapes + Rotation Angle + Anchor Port Recalculation
  it('P26: Rotating Star shape by 90 degrees (PI/2) recalculates anchor ports with rotated normals', () => {
    const star = { id: 'star-rot', type: 'star', x: 100, y: 100, width: 100, height: 100, rotation: Math.PI / 2, opacity: 1, strokeColor: '#000', fillColor: 'transparent', fillStyle: 'transparent', dashStyle: 'solid', strokeWidth: 2, createdAt: 1, updatedAt: 1 };
    const ports = geometryModule.getNodeAnchorPorts(star);
    expect(ports.top.nx).toBeCloseTo(1, 4);
    expect(ports.top.ny).toBeCloseTo(0, 4);
  });

  // Pair 27: S Pen Inking + Barrel Button Erase Toggle during Active Motion
  it('P27: S Pen inking transitions to erase on button press and resumes pen on button release mid-stroke', () => {
    const NIB = 1;
    const BARREL = inputModule.STYLUS_BARREL_BUTTON;
    let borrowed = false;

    // Inking
    expect(inputModule.stylusEraseTransition(borrowed, { pointerType: 'pen', buttons: NIB })).toBe('none');

    // Press barrel button while nib is down
    const engage = inputModule.stylusEraseTransition(borrowed, { pointerType: 'pen', buttons: NIB | BARREL });
    expect(engage).toBe('engage');
    borrowed = true;

    // Release barrel button while nib remains on screen
    const release = inputModule.stylusEraseTransition(borrowed, { pointerType: 'pen', buttons: NIB });
    expect(release).toBe('release');
    borrowed = false;
    expect(borrowed).toBe(false);
  });

  // Pair 28: Drawing Pointer ID Isolation + Interleaved Touch Moves from Resting Palm
  it('P28: Active stylus stroke maintains integrity when palm touches move and release concurrently', () => {
    const stylusPointerId = 55;
    const palmPointerId = 88;
    const points = [];
    let isDrawing = true;

    const onPointerMove = (e) => {
      if (e.pointerId !== stylusPointerId) return;
      points.push([e.x, e.y, e.pressure]);
    };

    const onPointerUp = (e) => {
      if (e.pointerId === stylusPointerId) {
        isDrawing = false;
      }
    };

    // Pen moves
    onPointerMove({ pointerId: stylusPointerId, x: 100, y: 100, pressure: 0.5 });
    // Palm moves across screen
    onPointerMove({ pointerId: palmPointerId, x: 450, y: 350, pressure: 0.1 });
    // Palm lifts off
    onPointerUp({ pointerId: palmPointerId });
    // Pen moves again
    onPointerMove({ pointerId: stylusPointerId, x: 120, y: 110, pressure: 0.5 });

    expect(isDrawing).toBe(true);
    expect(points.length).toBe(2);
    expect(points[1][0]).toBe(120);

    // Pen lifts
    onPointerUp({ pointerId: stylusPointerId });
    expect(isDrawing).toBe(false);
  });

  // Pair 29: Draw-and-Hold Auto-Straighten + Micro-Jitter Spatial Deadband vs Intentional Rubber-Banding
  it('P29: Hold timer remains engaged under micro-jitter within 5px deadband and rubber-bands on move', () => {
    const DEADBAND = 5.0;
    const anchor = { x: 50, y: 50 };
    const jitter = { x: 52, y: 51 }; // Euclidean dist = sqrt(4 + 1) = 2.23px <= 5px
    const moved = { x: 90, y: 50 }; // Euclidean dist = 40px > 5px

    const distJitter = Math.hypot(jitter.x - anchor.x, jitter.y - anchor.y);
    const distMoved = Math.hypot(moved.x - anchor.x, moved.y - anchor.y);

    expect(distJitter <= DEADBAND).toBe(true);
    expect(distMoved > DEADBAND).toBe(true);

    const initialStroke = [[50, 50, 0.5], [60, 50, 0.5], [70, 50, 0.5], [80, 50, 0.5], [90, 50, 0.5]];
    expect(strokeModule.isStrokeStraight(initialStroke, 0.88)).toBe(true);
    const rubberBanded = strokeModule.straightenStrokePoints([[50, 50, 0.5], [150, 50, 0.5]], 8);
    expect(rubberBanded.length).toBe(9);
    expect(rubberBanded[8][0]).toBe(150);
  });

  // Pair 30: Multi-Touch Palm Handoff vs Inking Pointer Protection
  it('P30: Secondary capacitive contacts during active pen inking do not trigger canvas pan/zoom', () => {
    const now = 30000;
    const proximity = { penDown: true, lastPenAt: now, now };
    const palmVerdict = palmModule.classifyTouch({ width: 50, height: 35 }, proximity);
    expect(palmVerdict).toBe('pen-down');
    expect(palmModule.isRejectedTouch({ width: 50, height: 35 }, proximity)).toBe(true);
  });
});
