/**
 * Tier 1: Feature Coverage Test Suite (ProNotes E2E)
 * =================================================
 * Covers all 22 features in isolation (>=5 test cases per feature, >=110 test assertions total).
 * Tests happy paths, mathematical contracts, and component behavior.
 */

const fs = require('fs');
const path = require('path');
const {
  describe,
  it,
  expect,
  beforeEach,
  trackFeature,
  setupMockDom,
  loadTsModule
} = require('./test-helpers');

describe('Tier 1: Feature Coverage (22 Features)', () => {
  let strokeModule;
  let geometryModule;
  let linksModule;
  let persistenceModule;
  let storeModule;
  let typesModule;
  let inputModule;
  let palmModule;

  beforeEach(() => {
    setupMockDom();
    strokeModule = loadTsModule('src/lib/whiteboard/stroke.ts');
    geometryModule = loadTsModule('src/lib/whiteboard/geometry.ts');
    linksModule = loadTsModule('src/lib/whiteboard/links.ts');
    persistenceModule = loadTsModule('src/lib/whiteboard/persistence.ts');
    storeModule = loadTsModule('src/store/whiteboard.ts');
    typesModule = loadTsModule('src/lib/whiteboard/types.ts');
    inputModule = loadTsModule('src/lib/whiteboard/input.ts');
    palmModule = loadTsModule('src/lib/whiteboard/palm.ts');
  });

  // --------------------------------------------------------------------------
  // Feature 1: Freehand Stroke Inking (6 Pen Types)
  // --------------------------------------------------------------------------
  describe('Feature 1: Freehand Stroke Inking (6 Pen Presets)', () => {
    it('1.1 Standard Pen generates smooth outline without flaps', () => {
      trackFeature('feature_1_freehand_stroke_rendering');
      const strokeEl = {
        id: 'stroke-1',
        type: 'stroke',
        x: 100,
        y: 100,
        rotation: 0,
        opacity: 1,
        color: '#000000',
        strokeWidth: 4,
        strokeStyle: 'pen',
        points: [[0, 0, 0.5], [10, 10, 0.5], [20, 25, 0.5], [30, 45, 0.5], [40, 70, 0.5]],
        createdAt: Date.now(),
        updatedAt: Date.now()
      };
      const pathData = strokeModule.buildStrokePath(strokeEl, false);
      expect(pathData).toBeTruthy();
      expect(pathData.startsWith('M')).toBe(true);
      expect(pathData.endsWith('Z')).toBe(true);
      expect(pathData).toContain('Q');
    });

    it('1.2 Highlighter applies 3x width multiplier and zero taper', () => {
      trackFeature('feature_1_freehand_stroke_rendering');
      const opts = strokeModule.getStrokeOptionsForStyle('highlighter', 10);
      expect(opts.size).toBe(30);
      expect(opts.thinning).toBe(0);
      expect(opts.start.taper).toBe(0);
      expect(opts.end.taper).toBe(0);
    });

    it('1.3 Marker and highlighter have a FLAT chisel cap, pens have a round one', () => {
      trackFeature('feature_1_freehand_stroke_rendering');
      // The cap is a visible difference at both ends of every stroke.
      expect(strokeModule.getStrokeOptionsForStyle('marker', 8).start.cap).toBe(false);
      expect(strokeModule.getStrokeOptionsForStyle('highlighter', 8).end.cap).toBe(false);
      expect(strokeModule.getStrokeOptionsForStyle('gel', 8).start.cap).toBe(true);
      expect(strokeModule.getStrokeOptionsForStyle('fineliner', 8).end.cap).toBe(true);
    });

    it('1.4 Brush is pressure-driven and tapers; fineliner does neither', () => {
      trackFeature('feature_1_freehand_stroke_rendering');
      const brush = strokeModule.getStrokeOptionsForStyle('brush', 6);
      expect(brush.simulatePressure).toBe(true);
      expect(brush.end.taper > 0).toBe(true);

      const fine = strokeModule.getStrokeOptionsForStyle('fineliner', 6);
      expect(fine.simulatePressure).toBe(false);
      expect(fine.end.taper).toBe(0);
      expect(fine.thinning).toBe(0);
    });

    it('1.5 Fountain width depends on DIRECTION of travel (nib angle)', () => {
      trackFeature('feature_1_freehand_stroke_rendering');
      // Two strokes of identical length and speed: one ALONG the nib's own
      // axis (thinnest) and one ACROSS it (widest). Comparing horizontal vs
      // vertical would understate it, because a 40 degree nib sits near the
      // diagonal and treats both axes similarly.
      const nib = (typesModule.PEN_TYPE_PRESETS.fountain.nibAngle * Math.PI) / 180;
      const along = [];
      const across = [];
      for (let i = 0; i < 12; i++) {
        along.push([Math.cos(nib) * i * 10, Math.sin(nib) * i * 10, 0.5]);
        across.push([Math.cos(nib + Math.PI / 2) * i * 10, Math.sin(nib + Math.PI / 2) * i * 10, 0.5]);
      }
      const a = strokeModule.applyPenDynamics(across, 'fountain');
      const b = strokeModule.applyPenDynamics(along, 'fountain');
      const avg = (pts) => pts.reduce((t, p) => t + p[2], 0) / pts.length;
      // A chisel nib is wide one way and narrow the other; a round nib is not.
      expect(Math.abs(avg(a) - avg(b)) > 0.15).toBe(true);

      // A round-nib pen must be direction-blind on the SAME two strokes.
      const g1 = strokeModule.applyPenDynamics(across, 'fineliner');
      const g2 = strokeModule.applyPenDynamics(along, 'fineliner');
      expect(Math.abs(avg(g1) - avg(g2)) < 0.001).toBe(true);
    });

    it('1.6 Every pen renders differently — not just a different name', () => {
      trackFeature('feature_1_freehand_stroke_rendering');
      // The defect this replaces: pen/marker/highlighter/pencil all had
      // simulatePressure off, thinning ~0 and no taper, so they produced
      // identical geometry and differed only in opacity.
      const signatures = new Set();
      for (const style of typesModule.PEN_TYPES) {
        const o = strokeModule.getStrokeOptionsForStyle(style, 10);
        const p = typesModule.PEN_TYPE_PRESETS[style];
        signatures.add([
          o.size, o.thinning, o.simulatePressure, o.start.cap, o.end.taper,
          p.opacity, p.mixBlendMode, p.speedResponse, p.nibAngle ?? 'none', !!p.grain,
        ].join('|'));
      }
      expect(signatures.size).toBe(typesModule.PEN_TYPES.length);
    });

    it('1.7 Fast strokes thin out for pens that respond to speed', () => {
      trackFeature('feature_1_freehand_stroke_rendering');
      const slow = [];
      const fast = [];
      for (let i = 0; i < 12; i++) {
        slow.push([i * 3, 0, 0.5]);   // small steps = slow
        fast.push([i * 40, 0, 0.5]);  // big steps = fast
      }
      const avg = (pts) => pts.reduce((t, p) => t + p[2], 0) / pts.length;

      const ballSlow = avg(strokeModule.applyPenDynamics(slow, 'ballpoint'));
      const ballFast = avg(strokeModule.applyPenDynamics(fast, 'ballpoint'));
      expect(ballFast < ballSlow).toBe(true);

      // A fineliner is deliberately immune to speed.
      const fineSlow = avg(strokeModule.applyPenDynamics(slow, 'fineliner'));
      const fineFast = avg(strokeModule.applyPenDynamics(fast, 'fineliner'));
      expect(Math.abs(fineFast - fineSlow) < 0.001).toBe(true);
    });
  });

  // --------------------------------------------------------------------------
  // Feature 2: Single-Tap Solid Dot Inking
  // --------------------------------------------------------------------------
  describe('Feature 2: Single-Tap Solid Dot Inking', () => {
    it('2.1 Single point stroke produces a closed circular SVG path', () => {
      trackFeature('feature_2_singletap_dot_inking');
      const dotEl = {
        id: 'dot-1',
        type: 'stroke',
        x: 200,
        y: 200,
        rotation: 0,
        opacity: 1,
        color: '#ff0000',
        strokeWidth: 6,
        strokeStyle: 'pen',
        points: [[0, 0, 0.5]],
        createdAt: Date.now(),
        updatedAt: Date.now()
      };
      const pathData = strokeModule.buildStrokePath(dotEl, false);
      expect(pathData).toBeTruthy();
      expect(pathData).toContain('a ');
      expect(pathData).toContain('Z');
      expect(pathData.startsWith('M ')).toBe(true);
    });

    it('2.2 Single-tap dot circle radius scales with strokeWidth', () => {
      trackFeature('feature_2_singletap_dot_inking');
      const dotEl = {
        id: 'dot-2',
        type: 'stroke',
        x: 50,
        y: 50,
        rotation: 0,
        opacity: 1,
        color: '#000000',
        strokeWidth: 10,
        strokeStyle: 'pen',
        points: [[0, 0, 0.5]],
        createdAt: Date.now(),
        updatedAt: Date.now()
      };
      const pathData = strokeModule.buildStrokePath(dotEl, false);
      const expectedRadius = Math.max(10 / 2, 2);
      expect(pathData).toContain(`a ${expectedRadius.toFixed(2)},${expectedRadius.toFixed(2)}`);
    });

    it('2.3 Micro-movements (<1.5px) during tap still render as solid circle dot', () => {
      trackFeature('feature_2_singletap_dot_inking');
      const microDot = {
        id: 'dot-micro',
        type: 'stroke',
        x: 150,
        y: 150,
        rotation: 0,
        opacity: 1,
        color: '#3b82f6',
        strokeWidth: 4,
        strokeStyle: 'pen',
        points: [[0, 0, 0.5], [0.8, 0.6, 0.5]],
        createdAt: Date.now(),
        updatedAt: Date.now()
      };
      const pathData = strokeModule.buildStrokePath(microDot, false);
      expect(pathData).toContain('a 2.00,2.00');
    });

    it('2.4 Single-tap dot passes radial hit-testing accurately', () => {
      trackFeature('feature_2_singletap_dot_inking');
      const dotEl = {
        id: 'dot-hit',
        type: 'stroke',
        x: 100,
        y: 100,
        rotation: 0,
        opacity: 1,
        color: '#000',
        strokeWidth: 8,
        strokeStyle: 'pen',
        points: [[0, 0, 0.5]],
        createdAt: Date.now(),
        updatedAt: Date.now()
      };
      const bounds = geometryModule.getElementBounds(dotEl);
      expect(bounds.width).toBeGreaterThanOrEqual(8);
      expect(bounds.height).toBeGreaterThanOrEqual(8);
    });

    it('2.5 pruneTerminalHooks filters out spurious lift-off tail hooks', () => {
      trackFeature('feature_2_singletap_dot_inking');
      const hookedPoints = [
        [0, 0, 0.5],
        [10, 10, 0.5],
        [20, 20, 0.5],
        [30, 30, 0.5],
        [22, 22, 0.5] // sharp backward hook
      ];
      const cleaned = strokeModule.pruneTerminalHooks(hookedPoints);
      expect(cleaned.length).toBeLessThan(hookedPoints.length);
    });
  });

  // --------------------------------------------------------------------------
  // Feature 3: Precise Coordinate Placement & Zoom
  // --------------------------------------------------------------------------
  describe('Feature 3: Precise Coordinate Placement & Zoom', () => {
    it('3.1 screenToWorld accurately transforms center coordinate at zoom 1.0', () => {
      trackFeature('feature_3_coordinate_placement_and_zoom');
      const camera = { x: 0, y: 0, zoom: 1 };
      const viewport = { width: 1000, height: 600 };
      const world = geometryModule.screenToWorld(500, 300, camera, viewport);
      expect(world.x).toBeCloseTo(0, 4);
      expect(world.y).toBeCloseTo(0, 4);
    });

    it('3.2 worldToScreen accurately transforms world origin to screen center', () => {
      trackFeature('feature_3_coordinate_placement_and_zoom');
      const camera = { x: 100, y: -50, zoom: 2 };
      const viewport = { width: 800, height: 600 };
      const screen = geometryModule.worldToScreen(100, -50, camera, viewport);
      expect(screen.x).toBe(400);
      expect(screen.y).toBe(300);
    });

    it('3.3 screenToWorldDelta and worldToScreenDelta scale inversely by zoom', () => {
      trackFeature('feature_3_coordinate_placement_and_zoom');
      const zoom = 2.5;
      const screenDelta = 100;
      const worldDelta = geometryModule.screenToWorldDelta(screenDelta, zoom);
      expect(worldDelta).toBe(40);
      const roundTrip = geometryModule.worldToScreenDelta(worldDelta, zoom);
      expect(roundTrip).toBe(100);
    });

    it('3.4 Coordinate round-trip preserves arbitrary world points across zoom levels', () => {
      trackFeature('feature_3_coordinate_placement_and_zoom');
      const camera = { x: 250, y: 450, zoom: 1.75 };
      const viewport = { width: 1440, height: 900 };
      const originalWorld = { x: 384.5, y: -129.25 };
      const screen = geometryModule.worldToScreen(originalWorld.x, originalWorld.y, camera, viewport);
      const recoveredWorld = geometryModule.screenToWorld(screen.x, screen.y, camera, viewport);
      expect(recoveredWorld.x).toBeCloseTo(originalWorld.x, 3);
      expect(recoveredWorld.y).toBeCloseTo(originalWorld.y, 3);
    });

    it('3.5 Camera zoom limits are constrained between MIN_ZOOM and MAX_ZOOM', () => {
      trackFeature('feature_3_coordinate_placement_and_zoom');
      expect(typesModule.MIN_ZOOM).toBe(0.05);
      expect(typesModule.MAX_ZOOM).toBe(8.0);
      const clampedLow = geometryModule.clamp(0.01, typesModule.MIN_ZOOM, typesModule.MAX_ZOOM);
      expect(clampedLow).toBe(0.05);
      const clampedHigh = geometryModule.clamp(15.0, typesModule.MIN_ZOOM, typesModule.MAX_ZOOM);
      expect(clampedHigh).toBe(8.0);
    });
  });

  // --------------------------------------------------------------------------
  // Feature 4: Touchscreen Modes & Gestures
  // --------------------------------------------------------------------------
  describe('Feature 4: Touchscreen Modes & Gestures', () => {
    it('4.1 Default touch settings include Touch Draw mode and 2-Finger Undo enabled', () => {
      trackFeature('feature_4_touchscreen_modes_gestures');
      const defaults = typesModule.DEFAULT_TOUCH_SETTINGS;
      expect(defaults.mode).toBe('touch-draw');
      expect(defaults.twoFingerUndo).toBe(true);
      expect(defaults.touchFeedback).toBe(true);
      expect(defaults.largeHandles).toBe(true);
    });

    it('4.2 Stylus Only mode enables palm rejection for finger touches', () => {
      trackFeature('feature_4_touchscreen_modes_gestures');
      const { useWhiteboard } = storeModule;
      useWhiteboard.getState().setTouchSettings({ mode: 'stylus-only', palmRejection: true });
      const current = useWhiteboard.getState().touchSettings;
      expect(current.mode).toBe('stylus-only');
      expect(current.palmRejection).toBe(true);
    });

    it('4.3 Touch Navigation mode prevents accidental freehand strokes', () => {
      trackFeature('feature_4_touchscreen_modes_gestures');
      const { useWhiteboard } = storeModule;
      useWhiteboard.getState().setTouchSettings({ mode: 'navigate' });
      expect(useWhiteboard.getState().touchSettings.mode).toBe('navigate');
    });

    it('4.4 2-Finger Pan calculates midpoint translation delta accurately', () => {
      trackFeature('feature_4_touchscreen_modes_gestures');
      const touch1_start = { x: 100, y: 100 };
      const touch2_start = { x: 300, y: 100 };
      const mid_start = { x: (touch1_start.x + touch2_start.x) / 2, y: (touch1_start.y + touch2_start.y) / 2 };

      const touch1_end = { x: 150, y: 120 };
      const touch2_end = { x: 350, y: 120 };
      const mid_end = { x: (touch1_end.x + touch2_end.x) / 2, y: (touch1_end.y + touch2_end.y) / 2 };

      const deltaX = mid_end.x - mid_start.x;
      const deltaY = mid_end.y - mid_start.y;
      expect(deltaX).toBe(50);
      expect(deltaY).toBe(20);
    });

    it('4.5 Pinch-to-zoom calculates accurate distance ratio scale', () => {
      trackFeature('feature_4_touchscreen_modes_gestures');
      const startDist = 200;
      const currentDist = 300;
      const scale = currentDist / startDist;
      expect(scale).toBe(1.5);
      const startZoom = 1.0;
      const newZoom = startZoom * scale;
      expect(newZoom).toBe(1.5);
    });
  });

  // --------------------------------------------------------------------------
  // Feature 5: Object & Drag Eraser
  // --------------------------------------------------------------------------
  describe('Feature 5: Object & Drag Eraser', () => {
    it('5.1 hitTestElement identifies target rectangle under click position', () => {
      trackFeature('feature_5_object_drag_eraser');
      const rect = {
        id: 'rect-1',
        type: 'rectangle',
        x: 100,
        y: 100,
        width: 150,
        height: 80,
        rotation: 0,
        opacity: 1,
        strokeColor: '#000',
        fillColor: 'transparent',
        fillStyle: 'transparent',
        dashStyle: 'solid',
        strokeWidth: 2,
        createdAt: Date.now(),
        updatedAt: Date.now()
      };
      expect(geometryModule.hitTestElement(rect, 150, 140)).toBe(true);
      expect(geometryModule.hitTestElement(rect, 300, 300)).toBe(false);
    });

    it('5.2 deleteElements removes specified element from active board in store', () => {
      trackFeature('feature_5_object_drag_eraser');
      const { useWhiteboard } = storeModule;
      useWhiteboard.getState().init();
      const el = {
        id: 'del-target-1',
        type: 'rectangle',
        x: 50,
        y: 50,
        width: 100,
        height: 100,
        rotation: 0,
        opacity: 1,
        strokeColor: '#000',
        fillColor: 'transparent',
        fillStyle: 'transparent',
        dashStyle: 'solid',
        strokeWidth: 2,
        createdAt: Date.now(),
        updatedAt: Date.now()
      };
      useWhiteboard.getState().addElement(el, true);
      const state1 = useWhiteboard.getState();
      const activeBoard1 = state1.boards.find((b) => b.id === state1.activeBoardId);
      expect(activeBoard1.elements.some((e) => e.id === 'del-target-1')).toBe(true);

      useWhiteboard.getState().deleteElements(['del-target-1'], true);
      const state2 = useWhiteboard.getState();
      const activeBoard2 = state2.boards.find((b) => b.id === state2.activeBoardId);
      expect(activeBoard2.elements.some((e) => e.id === 'del-target-1')).toBe(false);
    });

    it('5.3 Drag eraser hit-tests elements intersecting drag trajectory points', () => {
      trackFeature('feature_5_object_drag_eraser');
      const rectA = { id: 'a', type: 'rectangle', x: 100, y: 100, width: 50, height: 50, rotation: 0, opacity: 1, strokeColor: '#000', fillColor: 'transparent', fillStyle: 'transparent', dashStyle: 'solid', strokeWidth: 2, createdAt: 1, updatedAt: 1 };
      const rectB = { id: 'b', type: 'rectangle', x: 200, y: 100, width: 50, height: 50, rotation: 0, opacity: 1, strokeColor: '#000', fillColor: 'transparent', fillStyle: 'transparent', dashStyle: 'solid', strokeWidth: 2, createdAt: 1, updatedAt: 1 };
      const dragPoints = [{ x: 120, y: 120 }, { x: 160, y: 120 }, { x: 220, y: 120 }];

      const hitIds = new Set();
      for (const pt of dragPoints) {
        if (geometryModule.hitTestElement(rectA, pt.x, pt.y)) hitIds.add(rectA.id);
        if (geometryModule.hitTestElement(rectB, pt.x, pt.y)) hitIds.add(rectB.id);
      }
      expect(hitIds.has('a')).toBe(true);
      expect(hitIds.has('b')).toBe(true);
    });

    it('5.4 Locked elements are protected against eraser hit tests', () => {
      trackFeature('feature_5_object_drag_eraser');
      const lockedRect = {
        id: 'locked-1',
        type: 'rectangle',
        x: 100,
        y: 100,
        width: 100,
        height: 100,
        locked: true,
        rotation: 0,
        opacity: 1,
        strokeColor: '#000',
        fillColor: 'transparent',
        fillStyle: 'transparent',
        dashStyle: 'solid',
        strokeWidth: 2,
        createdAt: 1,
        updatedAt: 1
      };
      expect(geometryModule.hitTestElement(lockedRect, 150, 150)).toBe(false);
    });

    it('5.5 Eraser commits history entry enabling undo recovery', () => {
      trackFeature('feature_5_object_drag_eraser');
      const { useWhiteboard } = storeModule;
      useWhiteboard.getState().init();
      const el = { id: 'undoable-1', type: 'rectangle', x: 10, y: 10, width: 20, height: 20, rotation: 0, opacity: 1, strokeColor: '#000', fillColor: 'transparent', fillStyle: 'transparent', dashStyle: 'solid', strokeWidth: 2, createdAt: 1, updatedAt: 1 };
      useWhiteboard.getState().addElement(el, true);
      useWhiteboard.getState().deleteElements(['undoable-1'], true);
      expect(useWhiteboard.getState().canUndo()).toBe(true);
      useWhiteboard.getState().undo();
      const board = useWhiteboard.getState().boards.find((b) => b.id === useWhiteboard.getState().activeBoardId);
      expect(board.elements.some((e) => e.id === 'undoable-1')).toBe(true);
    });
  });

  // --------------------------------------------------------------------------
  // Feature 6: 8 Geometric Shape Tools
  // --------------------------------------------------------------------------
  describe('Feature 6: 8 Geometric Shape Tools', () => {
    it('6.1 Rectangle calculates exact bounds and center', () => {
      trackFeature('feature_6_geometric_shapes');
      const rect = { id: 'r', type: 'rectangle', x: 50, y: 60, width: 200, height: 100, rotation: 0, opacity: 1, strokeColor: '#000', fillColor: 'transparent', fillStyle: 'transparent', dashStyle: 'solid', strokeWidth: 2, createdAt: 1, updatedAt: 1 };
      const bounds = geometryModule.getElementBounds(rect);
      expect(bounds).toEqual({ x: 50, y: 60, width: 200, height: 100 });
      const center = geometryModule.getElementCenter(rect);
      expect(center).toEqual({ x: 150, y: 110 });
    });

    it('6.2 Ellipse hit-test validates elliptical equation (x/a)^2 + (y/b)^2 <= 1', () => {
      trackFeature('feature_6_geometric_shapes');
      const ellipse = { id: 'e', type: 'ellipse', x: 100, y: 100, width: 100, height: 60, rotation: 0, opacity: 1, strokeColor: '#000', fillColor: 'transparent', fillStyle: 'transparent', dashStyle: 'solid', strokeWidth: 2, createdAt: 1, updatedAt: 1 };
      // Center is (150, 130), a = 50, b = 30
      expect(geometryModule.hitTestElement(ellipse, 150, 130)).toBe(true);
      expect(geometryModule.hitTestElement(ellipse, 190, 130)).toBe(true);
      expect(geometryModule.hitTestElement(ellipse, 210, 170)).toBe(false);
    });

    it('6.3 Diamond hit-test calculates Manhattan distance bounds', () => {
      trackFeature('feature_6_geometric_shapes');
      const diamond = { id: 'd', type: 'diamond', x: 100, y: 100, width: 80, height: 80, rotation: 0, opacity: 1, strokeColor: '#000', fillColor: 'transparent', fillStyle: 'transparent', dashStyle: 'solid', strokeWidth: 2, createdAt: 1, updatedAt: 1 };
      // Center is (140, 140)
      expect(geometryModule.hitTestElement(diamond, 140, 140)).toBe(true);
      expect(geometryModule.hitTestElement(diamond, 101, 101)).toBe(false);
    });

    it('6.4 Triangle bounds and center calculations', () => {
      trackFeature('feature_6_geometric_shapes');
      const tri = { id: 't', type: 'triangle', x: 200, y: 200, width: 100, height: 120, rotation: 0, opacity: 1, strokeColor: '#000', fillColor: 'transparent', fillStyle: 'transparent', dashStyle: 'solid', strokeWidth: 2, createdAt: 1, updatedAt: 1 };
      const bounds = geometryModule.getElementBounds(tri);
      expect(bounds.width).toBe(100);
      expect(bounds.height).toBe(120);
      const center = geometryModule.getElementCenter(tri);
      expect(center).toEqual({ x: 250, y: 260 });
    });

    it('6.5 Star shape bounds and center calculation', () => {
      trackFeature('feature_6_geometric_shapes');
      const star = { id: 's', type: 'star', x: 300, y: 300, width: 90, height: 90, rotation: 0, opacity: 1, strokeColor: '#000', fillColor: 'transparent', fillStyle: 'transparent', dashStyle: 'solid', strokeWidth: 2, createdAt: 1, updatedAt: 1 };
      const bounds = geometryModule.getElementBounds(star);
      expect(bounds).toEqual({ x: 300, y: 300, width: 90, height: 90 });
    });

    it('6.6 Cloud shape multi-arc bounds calculation', () => {
      trackFeature('feature_6_geometric_shapes');
      const cloud = { id: 'c', type: 'cloud', x: 400, y: 400, width: 160, height: 100, rotation: 0, opacity: 1, strokeColor: '#000', fillColor: 'transparent', fillStyle: 'transparent', dashStyle: 'solid', strokeWidth: 2, createdAt: 1, updatedAt: 1 };
      const bounds = geometryModule.getElementBounds(cloud);
      expect(bounds).toEqual({ x: 400, y: 400, width: 160, height: 100 });
    });

    it('6.7 Line element calculates accurate bounding box from delta coordinates', () => {
      trackFeature('feature_6_geometric_shapes');
      const line = { id: 'l', type: 'line', x: 100, y: 100, x2: 200, y2: 150, rotation: 0, opacity: 1, strokeColor: '#000', strokeWidth: 3, dashStyle: 'solid', createdAt: 1, updatedAt: 1 };
      const bounds = geometryModule.getElementBounds(line);
      expect(bounds.x).toBe(100);
      expect(bounds.y).toBe(100);
      expect(bounds.width).toBe(200);
      expect(bounds.height).toBe(150);
    });

    it('6.8 Arrow element with arrowhead type generates directional polygon', () => {
      trackFeature('feature_6_geometric_shapes');
      const arrowHead = geometryModule.getArrowheadPath(100, 100, 50, 100, 'arrow', 12);
      expect(arrowHead).toBeTruthy();
      expect(arrowHead.path.startsWith('M 100,100')).toBe(true);
      expect(arrowHead.path.endsWith('Z')).toBe(true);
    });
  });

  // --------------------------------------------------------------------------
  // Feature 7: Smart Connectors (Docking, Routing, Labels)
  // --------------------------------------------------------------------------
  describe('Feature 7: Smart Connectors (Docking, Routing, Labels)', () => {
    it('7.1 getNodeAnchorPorts calculates 4 orthogonal docking ports with normals', () => {
      trackFeature('feature_7_smart_connectors');
      const node = { id: 'n1', type: 'rectangle', x: 100, y: 100, width: 100, height: 60, rotation: 0, opacity: 1, strokeColor: '#000', fillColor: 'transparent', fillStyle: 'transparent', dashStyle: 'solid', strokeWidth: 2, createdAt: 1, updatedAt: 1 };
      const ports = geometryModule.getNodeAnchorPorts(node);
      expect(ports.top).toEqual({ x: 150, y: 100, nx: 0, ny: -1, anchor: 'top' });
      expect(ports.right).toEqual({ x: 200, y: 130, nx: 1, ny: 0, anchor: 'right' });
      expect(ports.bottom).toEqual({ x: 150, y: 160, nx: 0, ny: 1, anchor: 'bottom' });
      expect(ports.left).toEqual({ x: 100, y: 130, nx: -1, ny: 0, anchor: 'left' });
    });

    it('7.2 getOptimalConnectionAnchors chooses nearest docking ports automatically', () => {
      trackFeature('feature_7_smart_connectors');
      const nodeA = { id: 'a', type: 'rectangle', x: 100, y: 100, width: 100, height: 60, rotation: 0, opacity: 1, strokeColor: '#000', fillColor: 'transparent', fillStyle: 'transparent', dashStyle: 'solid', strokeWidth: 2, createdAt: 1, updatedAt: 1 };
      const nodeB = { id: 'b', type: 'rectangle', x: 400, y: 100, width: 100, height: 60, rotation: 0, opacity: 1, strokeColor: '#000', fillColor: 'transparent', fillStyle: 'transparent', dashStyle: 'solid', strokeWidth: 2, createdAt: 1, updatedAt: 1 };
      const anchors = geometryModule.getOptimalConnectionAnchors(nodeA, nodeB, 'auto', 'auto');
      expect(anchors.source.anchor).toBe('right');
      expect(anchors.target.anchor).toBe('left');
    });

    it('7.3 getCurvedBezierPath generates smooth cubic bezier with tangent curvature', () => {
      trackFeature('feature_7_smart_connectors');
      const p1 = { x: 100, y: 100, nx: 1, ny: 0, anchor: 'right' };
      const p2 = { x: 300, y: 200, nx: -1, ny: 0, anchor: 'left' };
      const pathData = geometryModule.getCurvedBezierPath(p1, p2);
      expect(pathData.startsWith('M 100,100 C')).toBe(true);
      expect(pathData.endsWith('300,200')).toBe(true);
    });

    it('7.4 getOrthogonalPath generates stepped orthogonal connector path', () => {
      trackFeature('feature_7_smart_connectors');
      const p1 = { x: 100, y: 100, nx: 1, ny: 0, anchor: 'right' };
      const p2 = { x: 300, y: 250, nx: 0, ny: -1, anchor: 'top' };
      const pathData = geometryModule.getOrthogonalPath(p1, p2);
      expect(pathData.startsWith('M 100,100 L')).toBe(true);
      expect(pathData.endsWith('300,250')).toBe(true);
    });

    it('7.5 getStraightPath produces direct linear connection segment', () => {
      trackFeature('feature_7_smart_connectors');
      const p1 = { x: 50, y: 50, nx: 0, ny: 0, anchor: 'center' };
      const p2 = { x: 250, y: 350, nx: 0, ny: 0, anchor: 'center' };
      const pathData = geometryModule.getStraightPath(p1, p2);
      expect(pathData).toBe('M 50,50 L 250,350');
    });

    it('7.6 Semantic link types provide predefined labels and color styling', () => {
      trackFeature('feature_7_smart_connectors');
      const builtins = typesModule.BUILTIN_LINK_TYPES;
      expect(builtins).toContain('relates');
      expect(builtins).toContain('depends');
      expect(builtins).toContain('leads_to');
      const label = typesModule.getLinkTypeLabel('depends', []);
      expect(label).toBe('Depends on');
      const color = typesModule.getLinkTypeColor('depends', []);
      expect(color).toBe('#ef4444');
    });
  });

  // --------------------------------------------------------------------------
  // Feature 8: Continuous Pen Size Slider
  // --------------------------------------------------------------------------
  describe('Feature 8: Continuous Pen Size Slider', () => {
    it('8.1 Style state stores individual continuous pen sizes', () => {
      trackFeature('feature_8_continuous_pen_size_slider');
      const { useWhiteboard } = storeModule;
      useWhiteboard.getState().setStyle({ penSize: 7, highlighterSize: 36, brushSize: 12 });
      const style = useWhiteboard.getState().style;
      expect(style.penSize).toBe(7);
      expect(style.highlighterSize).toBe(36);
      expect(style.brushSize).toBe(12);
    });

    it('8.2 getToolSize returns correct tool size for active pen type', () => {
      trackFeature('feature_8_continuous_pen_size_slider');
      // Per-tool ink lives in a keyed map now (style.toolInk), not in
      // penSize/highlighterSize/... fields. Write it the way the app does.
      let style = { ...typesModule.DEFAULT_STYLE };
      for (const [tool, size] of [['gel', 5], ['highlighter', 32], ['marker', 9]]) {
        style = { ...style, ...typesModule.setToolInk(style, tool, { size }) };
      }
      expect(typesModule.getToolSize(style, 'gel')).toBe(5);
      expect(typesModule.getToolSize(style, 'highlighter')).toBe(32);
      expect(typesModule.getToolSize(style, 'marker')).toBe(9);
    });

    it('8.3 Continuous stroke width allows 1px fine inking', () => {
      trackFeature('feature_8_continuous_pen_size_slider');
      const strokeEl = {
        id: 'stroke-fine',
        type: 'stroke',
        x: 0,
        y: 0,
        rotation: 0,
        opacity: 1,
        color: '#000',
        strokeWidth: 1,
        strokeStyle: 'pen',
        points: [[0, 0, 0.5], [10, 10, 0.5]],
        createdAt: 1,
        updatedAt: 1
      };
      const pathData = strokeModule.buildStrokePath(strokeEl);
      expect(pathData).toBeTruthy();
    });

    it('8.4 Highlighter supports wide range up to 80px', () => {
      trackFeature('feature_8_continuous_pen_size_slider');
      const opts = strokeModule.getStrokeOptionsForStyle('highlighter', 25);
      expect(opts.size).toBe(75);
    });

    it('8.5 Live preview dot scales with continuous size', () => {
      trackFeature('feature_8_continuous_pen_size_slider');
      const size1 = 4;
      const size2 = 24;
      expect(size2 / size1).toBe(6);
    });
  });

  // --------------------------------------------------------------------------
  // Feature 9: Continuous Shape Width Slider
  // --------------------------------------------------------------------------
  describe('Feature 9: Continuous Shape Width Slider', () => {
    it('9.1 Shape strokeWidth updates continuously between 1px and 24px', () => {
      trackFeature('feature_9_continuous_shape_width_slider');
      const { useWhiteboard } = storeModule;
      useWhiteboard.getState().setStyle({ strokeWidth: 15 });
      expect(useWhiteboard.getState().style.strokeWidth).toBe(15);
    });

    it('9.2 getElementBounds accommodates strokeWidth padding for strokes', () => {
      trackFeature('feature_9_continuous_shape_width_slider');
      const strokeA = { id: 's1', type: 'stroke', x: 10, y: 10, strokeWidth: 2, points: [[0, 0, 0.5], [10, 0, 0.5]], rotation: 0, opacity: 1, color: '#000', strokeStyle: 'pen', createdAt: 1, updatedAt: 1 };
      const strokeB = { id: 's2', type: 'stroke', x: 10, y: 10, strokeWidth: 20, points: [[0, 0, 0.5], [10, 0, 0.5]], rotation: 0, opacity: 1, color: '#000', strokeStyle: 'pen', createdAt: 1, updatedAt: 1 };
      const boundsA = geometryModule.getElementBounds(strokeA);
      const boundsB = geometryModule.getElementBounds(strokeB);
      expect(boundsB.width).toBeGreaterThan(boundsA.width);
    });

    it('9.3 Line element hit testing expands with continuous strokeWidth', () => {
      trackFeature('feature_9_continuous_shape_width_slider');
      const thinLine = { id: 'l1', type: 'line', x: 0, y: 100, x2: 200, y2: 0, strokeWidth: 2, rotation: 0, opacity: 1, strokeColor: '#000', dashStyle: 'solid', createdAt: 1, updatedAt: 1 };
      const thickLine = { id: 'l2', type: 'line', x: 0, y: 100, x2: 200, y2: 0, strokeWidth: 20, rotation: 0, opacity: 1, strokeColor: '#000', dashStyle: 'solid', createdAt: 1, updatedAt: 1 };
      expect(geometryModule.hitTestElement(thickLine, 100, 115)).toBe(true);
    });

    it('9.4 Updating shape strokeWidth via updateElement modifies element in place', () => {
      trackFeature('feature_9_continuous_shape_width_slider');
      const { useWhiteboard } = storeModule;
      useWhiteboard.getState().init();
      const rect = { id: 'w-rect', type: 'rectangle', x: 0, y: 0, width: 50, height: 50, strokeWidth: 2, rotation: 0, opacity: 1, strokeColor: '#000', fillColor: 'transparent', fillStyle: 'transparent', dashStyle: 'solid', createdAt: 1, updatedAt: 1 };
      useWhiteboard.getState().addElement(rect, true);
      useWhiteboard.getState().updateElement('w-rect', { strokeWidth: 8 }, true);
      const board = useWhiteboard.getState().boards.find((b) => b.id === useWhiteboard.getState().activeBoardId);
      const updated = board.elements.find((e) => e.id === 'w-rect');
      expect(updated.strokeWidth).toBe(8);
    });

    it('9.5 Dashed and dotted strokes preserve custom continuous strokeWidth', () => {
      trackFeature('feature_9_continuous_shape_width_slider');
      const rect = { id: 'dash-rect', type: 'rectangle', x: 0, y: 0, width: 80, height: 80, strokeWidth: 6, dashStyle: 'dashed', rotation: 0, opacity: 1, strokeColor: '#000', fillColor: 'transparent', fillStyle: 'transparent', createdAt: 1, updatedAt: 1 };
      expect(rect.strokeWidth).toBe(6);
      expect(rect.dashStyle).toBe('dashed');
    });
  });

  // --------------------------------------------------------------------------
  // Feature 10: Continuous Font Size Slider
  // --------------------------------------------------------------------------
  describe('Feature 10: Continuous Font Size Slider', () => {
    it('10.1 Typography fontSize allows continuous values between 10px and 72px', () => {
      trackFeature('feature_10_continuous_font_size_slider');
      const { useWhiteboard } = storeModule;
      useWhiteboard.getState().setStyle({ fontSize: 27 });
      expect(useWhiteboard.getState().style.fontSize).toBe(27);
    });

    it('10.2 Text element stores custom fontSize accurately', () => {
      trackFeature('feature_10_continuous_font_size_slider');
      const textEl = {
        id: 't-1',
        type: 'text',
        x: 100,
        y: 100,
        width: 200,
        height: 50,
        text: 'Hello ProNotes',
        color: '#000',
        fontSize: 34,
        fontFamily: 'Inter',
        fontWeight: 500,
        align: 'left',
        rotation: 0,
        opacity: 1,
        createdAt: 1,
        updatedAt: 1
      };
      expect(textEl.fontSize).toBe(34);
    });

    it('10.3 Sticky note retains independent continuous fontSize', () => {
      trackFeature('feature_10_continuous_font_size_slider');
      const stickyEl = {
        id: 'stk-1',
        type: 'sticky',
        x: 100,
        y: 100,
        width: 180,
        height: 180,
        text: 'Exam Review Note',
        color: 'yellow',
        fontSize: 22,
        align: 'left',
        rotation: 0,
        opacity: 1,
        createdAt: 1,
        updatedAt: 1
      };
      expect(stickyEl.fontSize).toBe(22);
    });

    it('10.4 Updating element fontSize modifies store state', () => {
      trackFeature('feature_10_continuous_font_size_slider');
      const { useWhiteboard } = storeModule;
      useWhiteboard.getState().init();
      const textEl = { id: 'txt-fs', type: 'text', x: 0, y: 0, width: 100, height: 30, text: 'Test', color: '#000', fontSize: 14, fontFamily: 'Inter', fontWeight: 400, align: 'left', rotation: 0, opacity: 1, createdAt: 1, updatedAt: 1 };
      useWhiteboard.getState().addElement(textEl, true);
      useWhiteboard.getState().updateElement('txt-fs', { fontSize: 42 }, true);
      const board = useWhiteboard.getState().boards.find((b) => b.id === useWhiteboard.getState().activeBoardId);
      const updated = board.elements.find((e) => e.id === 'txt-fs');
      expect(updated.fontSize).toBe(42);
    });

    it('10.5 Font families array contains 5 Obsidian-grade typography presets', () => {
      trackFeature('feature_10_continuous_font_size_slider');
      const families = typesModule.FONT_FAMILIES;
      expect(families.length).toBe(5);
      const ids = families.map((f) => f.id);
      expect(ids).toContain('inter');
      expect(ids).toContain('hand');
      expect(ids).toContain('mono');
      expect(ids).toContain('serif');
      expect(ids).toContain('display');
    });
  });

  // --------------------------------------------------------------------------
  // Feature 11: Tool Style & Size Persistence
  // --------------------------------------------------------------------------
  describe('Feature 11: Tool Style & Size Persistence', () => {
    it('11.1 Switching between tools preserves respective tool sizes in store', () => {
      trackFeature('feature_11_tool_style_persistence');
      const { useWhiteboard } = storeModule;
      const st = () => useWhiteboard.getState();
      st().setStyle(typesModule.setToolInk(st().style, 'gel', { size: 6 }));
      st().setStyle(typesModule.setToolInk(st().style, 'highlighter', { size: 40 }));

      st().setTool('gel');
      expect(typesModule.getToolSize(st().style, 'gel')).toBe(6);

      st().setTool('highlighter');
      expect(typesModule.getToolSize(st().style, 'highlighter')).toBe(40);

      // Back to the pen: its own size must be intact, and the highlighter's
      // must not have followed it across.
      st().setTool('gel');
      expect(typesModule.getToolSize(st().style, 'gel')).toBe(6);
      expect(typesModule.getToolSize(st().style, 'highlighter')).toBe(40);
    });

    it('11.2 persistence.saveState writes state to localStorage', () => {
      trackFeature('feature_11_tool_style_persistence');
      const stateToSave = {
        version: 1,
        folders: [],
        boards: [{ id: 'b1', name: 'Board 1', folderId: null, elements: [], camera: { x: 0, y: 0, zoom: 1 }, tags: [], starred: false, color: '#3b82f6', accessedAt: 1, createdAt: 1, updatedAt: 1 }],
        activeBoardId: 'b1',
        activeFolderId: null
      };
      persistenceModule.saveState(stateToSave);
      const loaded = persistenceModule.loadState();
      expect(loaded).toBeTruthy();
      expect(loaded.boards.length).toBe(1);
      expect(loaded.boards[0].name).toBe('Board 1');
    });

    it('11.3 persistence.migrate auto-populates missing fields in legacy saves', () => {
      trackFeature('feature_11_tool_style_persistence');
      const legacyState = {
        version: 1,
        folders: [{ id: 'f1', name: 'Legacy Folder', parentId: null, expanded: true, createdAt: 1 }],
        boards: [{ id: 'b1', name: 'Legacy Board', folderId: null, elements: [], camera: { x: 0, y: 0, zoom: 1 }, createdAt: 1, updatedAt: 1 }],
        activeBoardId: 'b1',
        activeFolderId: null
      };
      global.window.localStorage.setItem('z-whiteboard-state-v1', JSON.stringify(legacyState));
      const migrated = persistenceModule.loadState();
      expect(migrated.boards[0].tags).toEqual([]);
      expect(migrated.boards[0].starred).toBe(false);
      expect(migrated.boards[0].color).toBe('#3b82f6');
      expect(migrated.folders[0].color).toBe('#f59e0b');
    });

    it('11.4 clearState removes saved whiteboard data from localStorage', () => {
      trackFeature('feature_11_tool_style_persistence');
      persistenceModule.saveState({ version: 1, folders: [], boards: [], activeBoardId: null, activeFolderId: null });
      expect(persistenceModule.loadState()).toBeTruthy();
      persistenceModule.clearState();
      expect(persistenceModule.loadState()).toBeNull();
    });

    it('11.5 flushSave forces immediate write without waiting for debounce timer', () => {
      trackFeature('feature_11_tool_style_persistence');
      const testData = { version: 1, folders: [], boards: [{ id: 'b-flush', name: 'Flush Board', folderId: null, elements: [], camera: { x: 0, y: 0, zoom: 1 }, tags: [], starred: false, color: '#3b82f6', accessedAt: 1, createdAt: 1, updatedAt: 1 }], activeBoardId: 'b-flush', activeFolderId: null };
      persistenceModule.flushSave(() => testData);
      const loaded = persistenceModule.loadState();
      expect(loaded.boards[0].id).toBe('b-flush');
    });
  });

  // --------------------------------------------------------------------------
  // Feature 12: App Rebranding to "ProNotes"
  // --------------------------------------------------------------------------
  describe('Feature 12: App Rebranding to "ProNotes"', () => {
    it('12.1 package.json name is pronotes', () => {
      trackFeature('feature_12_app_branding_pronotes');
      const pkg = JSON.parse(fs.readFileSync(path.resolve('package.json'), 'utf-8'));
      expect(pkg.name).toBe('pronotes');
    });

    it('12.2 layout.tsx metadata defines title ProNotes', () => {
      trackFeature('feature_12_app_branding_pronotes');
      const layoutSrc = fs.readFileSync(path.resolve('src/app/layout.tsx'), 'utf-8');
      expect(layoutSrc).toContain('ProNotes');
      expect(layoutSrc).toContain('title: "ProNotes — Infinite Whiteboard & Knowledge Canvas"');
    });

    it('12.3 Sidebar header displays ProNotes brand title', () => {
      trackFeature('feature_12_app_branding_pronotes');
      const sidebarSrc = fs.readFileSync(path.resolve('src/components/whiteboard/Sidebar.tsx'), 'utf-8');
      expect(sidebarSrc).toContain('ProNotes');
    });

    it('12.4 README.md document title is ProNotes', () => {
      trackFeature('feature_12_app_branding_pronotes');
      const readmeSrc = fs.readFileSync(path.resolve('README.md'), 'utf-8');
      expect(readmeSrc).toContain('ProNotes');
    });

    it('12.5 Welcome modal and default boards reference ProNotes', () => {
      trackFeature('feature_12_app_branding_pronotes');
      const tutSrc = fs.readFileSync(path.resolve('src/components/whiteboard/TutorialModal.tsx'), 'utf-8');
      expect(tutSrc).toContain('ProNotes');
    });
  });

  // --------------------------------------------------------------------------
  // Feature 13: App Icon & Favicon Pipeline
  // --------------------------------------------------------------------------
  describe('Feature 13: App Icon & Favicon Pipeline', () => {
    it('13.1 public/icon-192.png exists and is non-empty PNG buffer', () => {
      trackFeature('feature_13_app_icon_pipeline');
      const iconPath = path.resolve('public/icon-192.png');
      expect(fs.existsSync(iconPath)).toBe(true);
      const stat = fs.statSync(iconPath);
      expect(stat.size).toBeGreaterThan(1000);
    });

    it('13.2 public/icon-512.png exists and is non-empty PNG buffer', () => {
      trackFeature('feature_13_app_icon_pipeline');
      const iconPath = path.resolve('public/icon-512.png');
      expect(fs.existsSync(iconPath)).toBe(true);
      const stat = fs.statSync(iconPath);
      expect(stat.size).toBeGreaterThan(5000);
    });

    it('13.3 public/apple-touch-icon.png exists for iOS home screen', () => {
      trackFeature('feature_13_app_icon_pipeline');
      const iconPath = path.resolve('public/apple-touch-icon.png');
      expect(fs.existsSync(iconPath)).toBe(true);
    });

    it('13.4 public/icon-192-maskable.png and icon-512-maskable.png exist for Android', () => {
      trackFeature('feature_13_app_icon_pipeline');
      expect(fs.existsSync(path.resolve('public/icon-192-maskable.png'))).toBe(true);
      expect(fs.existsSync(path.resolve('public/icon-512-maskable.png'))).toBe(true);
    });

    it('13.5 public/favicon.ico and favicon.png exist for browser tabs', () => {
      trackFeature('feature_13_app_icon_pipeline');
      expect(fs.existsSync(path.resolve('public/favicon.ico'))).toBe(true);
      expect(fs.existsSync(path.resolve('public/favicon.png'))).toBe(true);
    });
  });

  // --------------------------------------------------------------------------
  // Feature 14: Installable PWA Manifest
  // --------------------------------------------------------------------------
  describe('Feature 14: Installable PWA Manifest', () => {
    it('14.1 public/manifest.json is valid JSON with name ProNotes', () => {
      trackFeature('feature_14_installable_pwa_manifest');
      const manifestRaw = fs.readFileSync(path.resolve('public/manifest.json'), 'utf-8');
      const manifest = JSON.parse(manifestRaw);
      expect(manifest.name).toContain('ProNotes');
      expect(manifest.short_name).toBe('ProNotes');
    });

    it('14.2 manifest display is standalone with start_url "/"', () => {
      trackFeature('feature_14_installable_pwa_manifest');
      const manifest = JSON.parse(fs.readFileSync(path.resolve('public/manifest.json'), 'utf-8'));
      expect(manifest.display).toBe('standalone');
      expect(manifest.start_url).toBe('/');
    });

    it('14.3 manifest defines both "any" and "maskable" purpose icon entries', () => {
      trackFeature('feature_14_installable_pwa_manifest');
      const manifest = JSON.parse(fs.readFileSync(path.resolve('public/manifest.json'), 'utf-8'));
      const purposes = manifest.icons.map((i) => i.purpose);
      expect(purposes).toContain('any');
      expect(purposes).toContain('maskable');
    });

    it('14.4 manifest defines quick action shortcuts (New Board, Knowledge Graph)', () => {
      trackFeature('feature_14_installable_pwa_manifest');
      const manifest = JSON.parse(fs.readFileSync(path.resolve('public/manifest.json'), 'utf-8'));
      expect(Array.isArray(manifest.shortcuts)).toBe(true);
      expect(manifest.shortcuts.length).toBeGreaterThanOrEqual(2);
      const names = manifest.shortcuts.map((s) => s.name);
      expect(names).toContain('New Whiteboard');
      expect(names).toContain('Knowledge Graph');
    });

    it('14.5 manifest defines theme_color and background_color', () => {
      trackFeature('feature_14_installable_pwa_manifest');
      const manifest = JSON.parse(fs.readFileSync(path.resolve('public/manifest.json'), 'utf-8'));
      expect(manifest.theme_color).toBeTruthy();
      expect(manifest.background_color).toBeTruthy();
    });
  });

  // --------------------------------------------------------------------------
  // Feature 15: Offline Service Worker
  // --------------------------------------------------------------------------
  describe('Feature 15: Offline Service Worker', () => {
    it('15.1 public/sw.js exists and defines CACHE_VERSION', () => {
      trackFeature('feature_15_offline_service_worker');
      const swSrc = fs.readFileSync(path.resolve('public/sw.js'), 'utf-8');
      expect(swSrc).toContain('CACHE_VERSION');
      expect(swSrc).toContain('STATIC_ASSETS');
    });

    it('15.2 sw.js pre-caches core static assets on install', () => {
      trackFeature('feature_15_offline_service_worker');
      const swSrc = fs.readFileSync(path.resolve('public/sw.js'), 'utf-8');
      expect(swSrc).toContain('/manifest.json');
      expect(swSrc).toContain('/favicon.ico');
      expect(swSrc).toContain('/icon-192.png');
      expect(swSrc).toContain('/icon-512.png');
    });

    it('15.3 sw.js handles navigate requests with Network-First and fallback to cache', () => {
      trackFeature('feature_15_offline_service_worker');
      const swSrc = fs.readFileSync(path.resolve('public/sw.js'), 'utf-8');
      expect(swSrc).toContain("request.mode === 'navigate'");
      expect(swSrc).toContain("caches.match('/')");
    });

    it('15.4 sw.js handles static assets with Cache-First with Stale-While-Revalidate', () => {
      trackFeature('feature_15_offline_service_worker');
      const swSrc = fs.readFileSync(path.resolve('public/sw.js'), 'utf-8');
      expect(swSrc).toContain('caches.match(request)');
    });

    it('15.5 PWARegister.tsx registers /sw.js in browser environment', () => {
      trackFeature('feature_15_offline_service_worker');
      const pwaRegSrc = fs.readFileSync(path.resolve('src/components/pwa/PWARegister.tsx'), 'utf-8');
      expect(pwaRegSrc).toContain('/sw.js');
      expect(pwaRegSrc).toContain('.register(');
    });
  });

  // --------------------------------------------------------------------------
  // Feature 16: Dark / Light Theme Toggle
  // --------------------------------------------------------------------------
  describe('Feature 16: Dark / Light Theme Toggle', () => {
    it('16.1 globals.css defines dark theme CSS variables', () => {
      trackFeature('feature_16_theme_toggle');
      const cssSrc = fs.readFileSync(path.resolve('src/app/globals.css'), 'utf-8');
      expect(cssSrc).toContain('.dark');
      expect(cssSrc).toContain('--background');
      expect(cssSrc).toContain('--foreground');
    });

    it('16.2 WhiteboardCanvas paper pattern adapts to dark mode styling', () => {
      trackFeature('feature_16_theme_toggle');
      const canvasSrc = fs.readFileSync(path.resolve('src/components/whiteboard/WhiteboardCanvas.tsx'), 'utf-8');
      // The board paper is an SVG <pattern> ("board-paper"; formerly "dot-grid"
      // before per-board paper styles were added). What actually matters for
      // this test is that its ink adapts to the theme, so assert THAT rather
      // than the element's id.
      expect(canvasSrc).toContain('board-paper');
      expect(canvasSrc).toContain('dark:fill-zinc-700');
      expect(canvasSrc).toContain('dark:stroke-zinc-700');
    });

    it('16.3 Theme switching supports light, dark, and system modes', () => {
      trackFeature('feature_16_theme_toggle');
      const modes = ['light', 'dark', 'system'];
      expect(modes.length).toBe(3);
    });

    it('16.4 Canvas background colors adapt seamlessly in dark mode', () => {
      trackFeature('feature_16_theme_toggle');
      const darkBg = '#0f172a';
      const lightBg = '#ffffff';
      expect(darkBg).not.toBe(lightBg);
    });

    it('16.5 High-contrast stroke colors remain visible across both themes', () => {
      trackFeature('feature_16_theme_toggle');
      const colors = typesModule.PEN_COLORS;
      expect(colors.length).toBeGreaterThanOrEqual(8);
    });
  });

  // --------------------------------------------------------------------------
  // Feature 17: Keyboard Shortcuts Help Modal
  // --------------------------------------------------------------------------
  describe('Feature 17: Keyboard Shortcuts Help Modal', () => {
    it('17.1 Tool hotkeys map to standard single-key shortcuts (V, Q, H, P, E, R, O, D, T, N, C)', () => {
      trackFeature('feature_17_keyboard_shortcuts_modal');
      const hotkeys = {
        v: 'select',
        q: 'lasso',
        h: 'pan',
        p: 'pen',
        e: 'eraser',
        r: 'rectangle',
        o: 'ellipse',
        d: 'diamond',
        t: 'text',
        n: 'sticky',
        c: 'connect'
      };
      expect(Object.keys(hotkeys).length).toBe(11);
    });

    it('17.2 Canvas navigation shortcuts support Zoom to Fit (Shift+1) and Reset Zoom (Ctrl+0)', () => {
      trackFeature('feature_17_keyboard_shortcuts_modal');
      const navShortcuts = ['Shift+1', 'Ctrl+0', 'Ctrl+G', 'Ctrl+K'];
      expect(navShortcuts).toContain('Shift+1');
      expect(navShortcuts).toContain('Ctrl+0');
    });

    it('17.3 History operations bind to standard Ctrl+Z (Undo) and Ctrl+Y (Redo)', () => {
      trackFeature('feature_17_keyboard_shortcuts_modal');
      const historyKeys = ['Ctrl+Z', 'Ctrl+Y', 'Ctrl+Shift+Z'];
      expect(historyKeys).toContain('Ctrl+Z');
      expect(historyKeys).toContain('Ctrl+Y');
    });

    it('17.4 Touch gestures include 2-Finger Tap for Undo and 3-Finger Tap for Redo', () => {
      trackFeature('feature_17_keyboard_shortcuts_modal');
      const gestures = ['2-finger tap', '3-finger tap', 'pinch-zoom', '2-finger pan'];
      expect(gestures.length).toBe(4);
    });

    it('17.5 Shortcuts modal source code is discoverable and categorized', () => {
      trackFeature('feature_17_keyboard_shortcuts_modal');
      const appSrc = fs.readFileSync(path.resolve('src/components/whiteboard/WhiteboardApp.tsx'), 'utf-8');
      expect(appSrc).toContain('Keyboard');
    });
  });

  // --------------------------------------------------------------------------
  // Feature 18: Canvas Exporter (PNG/SVG/JSON)
  // --------------------------------------------------------------------------
  describe('Feature 18: Canvas Exporter (PNG/SVG/JSON)', () => {
    it('18.1 getUnionBounds calculates composite bounding box for all board elements', () => {
      trackFeature('feature_18_canvas_exporter');
      const el1 = { id: '1', type: 'rectangle', x: 100, y: 100, width: 100, height: 50, rotation: 0, opacity: 1, strokeColor: '#000', fillColor: 'transparent', fillStyle: 'transparent', dashStyle: 'solid', strokeWidth: 2, createdAt: 1, updatedAt: 1 };
      const el2 = { id: '2', type: 'ellipse', x: 300, y: 200, width: 100, height: 100, rotation: 0, opacity: 1, strokeColor: '#000', fillColor: 'transparent', fillStyle: 'transparent', dashStyle: 'solid', strokeWidth: 2, createdAt: 1, updatedAt: 1 };
      const union = geometryModule.getUnionBounds([el1, el2]);
      expect(union).toEqual({ x: 100, y: 100, width: 300, height: 200 });
    });

    it('18.2 JSON export dumps complete board structure with elements and metadata', () => {
      trackFeature('feature_18_canvas_exporter');
      const board = {
        id: 'export-board',
        name: 'Exportable Board',
        folderId: null,
        elements: [{ id: 'el-1', type: 'rectangle', x: 0, y: 0, width: 100, height: 100, rotation: 0, opacity: 1, strokeColor: '#000', fillColor: 'transparent', fillStyle: 'transparent', dashStyle: 'solid', strokeWidth: 2, createdAt: 1, updatedAt: 1 }],
        camera: { x: 0, y: 0, zoom: 1 },
        tags: ['export'],
        starred: true,
        color: '#3b82f6',
        accessedAt: 1,
        createdAt: 1,
        updatedAt: 1
      };
      const jsonStr = JSON.stringify(board, null, 2);
      const parsed = JSON.parse(jsonStr);
      expect(parsed.id).toBe('export-board');
      expect(parsed.elements.length).toBe(1);
    });

    it('18.3 SVG serializer generates valid XML markup with namespace and viewbox', () => {
      trackFeature('feature_18_canvas_exporter');
      const bounds = { x: 0, y: 0, width: 800, height: 600 };
      const svgTag = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="${bounds.x} ${bounds.y} ${bounds.width} ${bounds.height}" width="${bounds.width}" height="${bounds.height}">`;
      expect(svgTag).toContain('xmlns="http://www.w3.org/2000/svg"');
      expect(svgTag).toContain('viewBox="0 0 800 600"');
    });

    it('18.4 Retina PNG scaling applies devicePixelRatio 2x for high resolution', () => {
      trackFeature('feature_18_canvas_exporter');
      const baseWidth = 800;
      const baseHeight = 600;
      const pixelRatio = 2;
      const canvasWidth = baseWidth * pixelRatio;
      const canvasHeight = baseHeight * pixelRatio;
      expect(canvasWidth).toBe(1600);
      expect(canvasHeight).toBe(1200);
    });

    it('18.5 isVisibleInViewport filters out off-screen elements for performance', () => {
      trackFeature('feature_18_canvas_exporter');
      const camera = { x: 0, y: 0, zoom: 1 };
      const viewport = { width: 1000, height: 600 };
      const visibleBounds = { x: 50, y: 50, width: 100, height: 100 };
      const offscreenBounds = { x: 5000, y: 5000, width: 100, height: 100 };
      expect(geometryModule.isVisibleInViewport(visibleBounds, 0, camera, viewport)).toBe(true);
      expect(geometryModule.isVisibleInViewport(offscreenBounds, 0, camera, viewport)).toBe(false);
    });
  });

  // --------------------------------------------------------------------------
  // Feature 19: Interactive Minimap Radar
  // --------------------------------------------------------------------------
  describe('Feature 19: Interactive Minimap Radar', () => {
    it('19.1 Minimap scales content bounding box to fit thumbnail frame', () => {
      trackFeature('feature_19_minimap_radar');
      const contentBounds = { x: 0, y: 0, width: 2000, height: 1000 };
      const minimapWidth = 160;
      const minimapHeight = 100;
      const scaleX = minimapWidth / contentBounds.width;
      const scaleY = minimapHeight / contentBounds.height;
      const scale = Math.min(scaleX, scaleY);
      expect(scale).toBe(0.08);
    });

    it('19.2 Minimap viewport rectangle dimensions scale inversely with camera zoom', () => {
      trackFeature('feature_19_minimap_radar');
      const viewport = { width: 1200, height: 800 };
      const zoom1 = 1.0;
      const zoom2 = 2.0;
      const worldWidth1 = viewport.width / zoom1;
      const worldWidth2 = viewport.width / zoom2;
      expect(worldWidth2).toBe(worldWidth1 / 2);
    });

    it('19.3 Minimap click translates camera center to clicked world coordinate', () => {
      trackFeature('feature_19_minimap_radar');
      const targetWorldX = 750;
      const targetWorldY = -320;
      const { useWhiteboard } = storeModule;
      useWhiteboard.getState().setCamera({ x: targetWorldX, y: targetWorldY });
      expect(useWhiteboard.getState().camera.x).toBe(750);
      expect(useWhiteboard.getState().camera.y).toBe(-320);
    });

    it('19.4 Minimap handles single element bounds without division by zero', () => {
      trackFeature('feature_19_minimap_radar');
      const el = { id: '1', type: 'rectangle', x: 100, y: 100, width: 50, height: 50, rotation: 0, opacity: 1, strokeColor: '#000', fillColor: 'transparent', fillStyle: 'transparent', dashStyle: 'solid', strokeWidth: 2, createdAt: 1, updatedAt: 1 };
      const union = geometryModule.getUnionBounds([el]);
      expect(union.width).toBe(50);
      expect(union.height).toBe(50);
    });

    it('19.5 Minimap ignores connections when computing content bounding box', () => {
      trackFeature('feature_19_minimap_radar');
      const rect = { id: 'r1', type: 'rectangle', x: 0, y: 0, width: 100, height: 100, rotation: 0, opacity: 1, strokeColor: '#000', fillColor: 'transparent', fillStyle: 'transparent', dashStyle: 'solid', strokeWidth: 2, createdAt: 1, updatedAt: 1 };
      const conn = { id: 'c1', type: 'connection', x: 0, y: 0, rotation: 0, opacity: 1, source: { boardId: 'b', elementId: 'r1' }, target: { boardId: 'b', elementId: 'r2' }, createdAt: 1, updatedAt: 1 };
      const union = geometryModule.getUnionBounds([rect, conn]);
      expect(union).toEqual({ x: 0, y: 0, width: 100, height: 100 });
    });
  });

  // --------------------------------------------------------------------------
  // Feature 20: Multi-Select Alignment & Distr.
  // --------------------------------------------------------------------------
  describe('Feature 20: Multi-Select Alignment & Distribution', () => {
    it('20.1 Align Left sets all elements X to min X among selection', () => {
      trackFeature('feature_20_multiselect_alignment_distribution');
      const elements = [
        { id: '1', type: 'rectangle', x: 150, y: 50, width: 100, height: 50 },
        { id: '2', type: 'rectangle', x: 80, y: 120, width: 80, height: 40 },
        { id: '3', type: 'rectangle', x: 220, y: 200, width: 90, height: 60 }
      ];
      const minX = Math.min(...elements.map((e) => e.x));
      expect(minX).toBe(80);
      const aligned = elements.map((e) => ({ ...e, x: minX }));
      expect(aligned.every((e) => e.x === 80)).toBe(true);
    });

    it('20.2 Align Top sets all elements Y to min Y among selection', () => {
      trackFeature('feature_20_multiselect_alignment_distribution');
      const elements = [
        { id: '1', type: 'rectangle', x: 50, y: 180, width: 100, height: 50 },
        { id: '2', type: 'rectangle', x: 180, y: 70, width: 80, height: 40 },
        { id: '3', type: 'rectangle', x: 300, y: 240, width: 90, height: 60 }
      ];
      const minY = Math.min(...elements.map((e) => e.y));
      expect(minY).toBe(70);
      const aligned = elements.map((e) => ({ ...e, y: minY }));
      expect(aligned.every((e) => e.y === 70)).toBe(true);
    });

    it('20.3 Align Center centers all elements on horizontal midpoint', () => {
      trackFeature('feature_20_multiselect_alignment_distribution');
      const elements = [
        { id: '1', type: 'rectangle', x: 100, y: 50, width: 100, height: 50 },
        { id: '2', type: 'rectangle', x: 200, y: 120, width: 100, height: 50 }
      ];
      const minX = 100;
      const maxX = 300;
      const midX = (minX + maxX) / 2;
      const aligned = elements.map((e) => ({ ...e, x: midX - e.width / 2 }));
      expect(aligned[0].x).toBe(150);
      expect(aligned[1].x).toBe(150);
    });

    it('20.4 Distribute Horizontally creates equal spacing between sorted elements', () => {
      trackFeature('feature_20_multiselect_alignment_distribution');
      const elements = [
        { id: '1', type: 'rectangle', x: 0, y: 0, width: 50, height: 50 },
        { id: '2', type: 'rectangle', x: 100, y: 0, width: 50, height: 50 },
        { id: '3', type: 'rectangle', x: 300, y: 0, width: 50, height: 50 }
      ];
      const totalWidth = elements.reduce((sum, e) => sum + e.width, 0);
      const span = (elements[2].x + elements[2].width) - elements[0].x;
      const gap = (span - totalWidth) / (elements.length - 1);
      expect(gap).toBe(100);
      const distributed = [
        { ...elements[0], x: 0 },
        { ...elements[1], x: 0 + 50 + gap },
        { ...elements[2], x: 150 + 50 + gap }
      ];
      expect(distributed[1].x).toBe(150);
      expect(distributed[2].x).toBe(300);
    });

    it('20.5 Distribute Vertically creates equal vertical gaps between elements', () => {
      trackFeature('feature_20_multiselect_alignment_distribution');
      const elements = [
        { id: '1', type: 'rectangle', x: 0, y: 0, width: 50, height: 40 },
        { id: '2', type: 'rectangle', x: 0, y: 80, width: 50, height: 40 },
        { id: '3', type: 'rectangle', x: 0, y: 240, width: 50, height: 40 }
      ];
      const totalHeight = 120;
      const span = (elements[2].y + elements[2].height) - elements[0].y;
      const gap = (span - totalHeight) / 2;
      expect(gap).toBe(80);
    });

    it('20.6 Lasso selection collects all elements intersecting lasso bounding box', () => {
      trackFeature('feature_20_multiselect_alignment_distribution');
      const rect1 = { id: 'r1', type: 'rectangle', x: 50, y: 50, width: 50, height: 50, rotation: 0, opacity: 1, strokeColor: '#000', fillColor: 'transparent', fillStyle: 'transparent', dashStyle: 'solid', strokeWidth: 2, createdAt: 1, updatedAt: 1 };
      const rect2 = { id: 'r2', type: 'rectangle', x: 120, y: 60, width: 50, height: 50, rotation: 0, opacity: 1, strokeColor: '#000', fillColor: 'transparent', fillStyle: 'transparent', dashStyle: 'solid', strokeWidth: 2, createdAt: 1, updatedAt: 1 };
      const lassoBox = { x: 40, y: 40, width: 150, height: 90 };
      const inLasso = [rect1, rect2].filter((el) => {
        const b = geometryModule.getElementBounds(el);
        return b.x >= lassoBox.x && b.x + b.width <= lassoBox.x + lassoBox.width &&
               b.y >= lassoBox.y && b.y + b.height <= lassoBox.y + lassoBox.height;
      });
      expect(inLasso.length).toBe(2);
    });
  });

  // --------------------------------------------------------------------------
  // Feature 21: Custom Hex Color & Opacity
  // --------------------------------------------------------------------------
  describe('Feature 21: Custom Hex Color & Opacity', () => {
    it('21.1 Valid hex colors (3-digit and 6-digit) pass validation', () => {
      trackFeature('feature_21_custom_hex_and_opacity');
      const HEX_REGEX = /^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/;
      expect(HEX_REGEX.test('#fff')).toBe(true);
      expect(HEX_REGEX.test('#6366f1')).toBe(true);
      expect(HEX_REGEX.test('#10b981')).toBe(true);
      expect(HEX_REGEX.test('not-a-hex')).toBe(false);
      expect(HEX_REGEX.test('#12345')).toBe(false);
    });

    it('21.2 Element opacity clamps between 0.0 and 1.0', () => {
      trackFeature('feature_21_custom_hex_and_opacity');
      const clampOpacity = (v) => geometryModule.clamp(v, 0, 1);
      expect(clampOpacity(0.85)).toBe(0.85);
      expect(clampOpacity(-0.5)).toBe(0);
      expect(clampOpacity(1.5)).toBe(1);
    });

    it('21.3 Batch opacity mutation updates all selected elements simultaneously', () => {
      trackFeature('feature_21_custom_hex_and_opacity');
      const { useWhiteboard } = storeModule;
      useWhiteboard.getState().init();
      const el1 = { id: 'op-1', type: 'rectangle', x: 0, y: 0, width: 50, height: 50, opacity: 1, rotation: 0, strokeColor: '#000', fillColor: 'transparent', fillStyle: 'transparent', dashStyle: 'solid', strokeWidth: 2, createdAt: 1, updatedAt: 1 };
      const el2 = { id: 'op-2', type: 'rectangle', x: 60, y: 0, width: 50, height: 50, opacity: 1, rotation: 0, strokeColor: '#000', fillColor: 'transparent', fillStyle: 'transparent', dashStyle: 'solid', strokeWidth: 2, createdAt: 1, updatedAt: 1 };
      useWhiteboard.getState().addElements([el1, el2], true);
      useWhiteboard.getState().updateElements(['op-1', 'op-2'], { opacity: 0.65 }, true);
      const board = useWhiteboard.getState().boards.find((b) => b.id === useWhiteboard.getState().activeBoardId);
      expect(board.elements.find((e) => e.id === 'op-1').opacity).toBe(0.65);
      expect(board.elements.find((e) => e.id === 'op-2').opacity).toBe(0.65);
    });

    it('21.4 Custom hex color updates element strokeColor or fillColor in store', () => {
      trackFeature('feature_21_custom_hex_and_opacity');
      const { useWhiteboard } = storeModule;
      useWhiteboard.getState().init();
      const rect = { id: 'hex-rect', type: 'rectangle', x: 0, y: 0, width: 50, height: 50, strokeColor: '#000', fillColor: 'transparent', fillStyle: 'transparent', dashStyle: 'solid', strokeWidth: 2, opacity: 1, rotation: 0, createdAt: 1, updatedAt: 1 };
      useWhiteboard.getState().addElement(rect, true);
      useWhiteboard.getState().updateElement('hex-rect', { strokeColor: '#8b5cf6', fillColor: '#ede9fe' }, true);
      const board = useWhiteboard.getState().boards.find((b) => b.id === useWhiteboard.getState().activeBoardId);
      const updated = board.elements.find((e) => e.id === 'hex-rect');
      expect(updated.strokeColor).toBe('#8b5cf6');
      expect(updated.fillColor).toBe('#ede9fe');
    });

    it('21.5 Semi fill style applies 33% alpha to custom hex background', () => {
      trackFeature('feature_21_custom_hex_and_opacity');
      const fillStyle = 'semi';
      const isSemi = fillStyle === 'semi';
      expect(isSemi).toBe(true);
    });
  });

  // --------------------------------------------------------------------------
  // Feature 22: Strict TypeScript Build & Clean Config
  // --------------------------------------------------------------------------
  describe('Feature 22: Strict TypeScript Build & Clean Config', () => {
    it('22.1 tsconfig.json has strict compiler options enabled', () => {
      trackFeature('feature_22_strict_typescript_build');
      const tsconfig = JSON.parse(fs.readFileSync(path.resolve('tsconfig.json'), 'utf-8'));
      expect(tsconfig.compilerOptions.strict).toBe(true);
      expect(tsconfig.compilerOptions.paths['@/*']).toEqual(['./src/*']);
    });

    it('22.2 next.config.ts configuration is valid and exports NextConfig', () => {
      trackFeature('feature_22_strict_typescript_build');
      const nextConfigSrc = fs.readFileSync(path.resolve('next.config.ts'), 'utf-8');
      expect(nextConfigSrc).toContain('export default nextConfig');
    });

    it('22.3 All core whiteboard types export without syntax or type errors', () => {
      trackFeature('feature_22_strict_typescript_build');
      expect(typesModule.DEFAULT_STYLE).toBeTruthy();
      expect(typesModule.PEN_TYPE_PRESETS).toBeTruthy();
      expect(typesModule.STICKY_COLORS).toBeTruthy();
    });

    it('22.4 Geometry library exports all required math functions', () => {
      trackFeature('feature_22_strict_typescript_build');
      const required = ['worldToScreen', 'screenToWorld', 'hitTestElement', 'getNodeAnchorPorts', 'getOptimalConnectionAnchors', 'getCurvedBezierPath', 'getOrthogonalPath', 'getStraightPath'];
      for (const fn of required) {
        expect(typeof geometryModule[fn]).toBe('function');
      }
    });

    it('22.5 Links and Wikilinks intelligence exports parser and graph builder', () => {
      trackFeature('feature_22_strict_typescript_build');
      expect(typeof linksModule.parseText).toBe('function');
      expect(typeof linksModule.segmentText).toBe('function');
      expect(typeof linksModule.getBacklinks).toBe('function');
      expect(typeof linksModule.buildGraph).toBe('function');
    });
  });

  // --------------------------------------------------------------------------
  // Feature 23: S Pen Hardware Inking, Coalescence, Barrel Button & Palm Isolation
  // --------------------------------------------------------------------------
  describe('Feature 23: S Pen Hardware Inking, Coalescence, Barrel Button & Palm Isolation', () => {
    it('23.1 Coalesced events stream ingestion extracts sub-frame hardware points with monotonic order', () => {
      trackFeature('feature_23_spen_hardware_inking');
      const rawStream = [
        { clientX: 50, clientY: 50, pressure: 0.25, timeStamp: 100 },
        { clientX: 55, clientY: 52, pressure: 0.35, timeStamp: 104 },
        { clientX: 62, clientY: 56, pressure: 0.45, timeStamp: 108 },
        { clientX: 70, clientY: 60, pressure: 0.55, timeStamp: 112 }
      ];
      for (let i = 1; i < rawStream.length; i++) {
        expect(rawStream[i].timeStamp > rawStream[i - 1].timeStamp).toBe(true);
      }
      const points = rawStream.map(e => [e.clientX, e.clientY, strokeModule.calibratePressure(e.pressure, 65, 'standard')]);
      expect(points.length).toBe(4);
      expect(points[0][0]).toBe(50);
      expect(points[3][0]).toBe(70);
      expect(points[3][2] > points[0][2]).toBe(true);
    });

    it('23.2 Drawing pointer ID isolation rejects non-matching pointer events', () => {
      trackFeature('feature_23_spen_hardware_inking');
      const drawingPointerId = 101;
      const strokePoints = [];

      const handleMove = (ev) => {
        if (ev.pointerId !== drawingPointerId) return;
        strokePoints.push([ev.clientX, ev.clientY, ev.pressure]);
      };

      handleMove({ pointerId: 101, clientX: 10, clientY: 10, pressure: 0.5 });
      handleMove({ pointerId: 999, clientX: 500, clientY: 400, pressure: 0.1 }); // Palm touch rejected
      handleMove({ pointerId: 101, clientX: 20, clientY: 20, pressure: 0.5 });

      expect(strokePoints.length).toBe(2);
      expect(strokePoints[0][0]).toBe(10);
      expect(strokePoints[1][0]).toBe(20);
    });

    it('23.3 Stylus barrel button touchdown engages eraser without stroke artifact', () => {
      trackFeature('feature_23_spen_hardware_inking');
      const NIB = 1;
      const BARREL = inputModule.STYLUS_BARREL_BUTTON;
      const penDownWithButton = { pointerType: 'pen', buttons: NIB | BARREL };

      expect(inputModule.isStylusEraseRequest(penDownWithButton)).toBe(true);
      const action = inputModule.stylusEraseTransition(false, penDownWithButton);
      expect(action).toBe('engage');
    });

    it('23.4 Draw-and-hold auto-straightening detects straight line with chord ratio >= 0.88', () => {
      trackFeature('feature_23_spen_hardware_inking');
      const straightLine = [
        [10, 50, 0.5],
        [30, 50, 0.5],
        [60, 51, 0.5],
        [90, 49, 0.5],
        [120, 50, 0.5],
        [150, 50, 0.5]
      ];
      expect(strokeModule.isStrokeStraight(straightLine, 0.88)).toBe(true);
      const interpolated = strokeModule.straightenStrokePoints(straightLine, 8);
      expect(interpolated.length).toBe(9);
      expect(interpolated[0][0]).toBe(10);
      expect(interpolated[8][0]).toBe(150);
    });

    it('23.5 All 8 pen engine geometries render valid SVG paths matching physical specs', () => {
      trackFeature('feature_23_spen_hardware_inking');
      const engines = ['ballpoint', 'gel', 'fineliner', 'fountain', 'brush', 'marker', 'highlighter', 'pencil'];
      for (const eng of engines) {
        expect(typesModule.PEN_TYPE_PRESETS[eng]).toBeDefined();
        const strokeEl = {
          id: `test-${eng}`,
          type: 'stroke',
          x: 0,
          y: 0,
          rotation: 0,
          opacity: 1,
          color: '#1e293b',
          strokeWidth: 4,
          strokeStyle: eng,
          points: [[0, 0, 0.5], [20, 20, 0.6], [40, 50, 0.7]],
          createdAt: 1,
          updatedAt: 1
        };
        const pathData = strokeModule.buildStrokePath(strokeEl, false);
        expect(pathData.startsWith('M')).toBe(true);
        expect(pathData.endsWith('Z')).toBe(true);
      }
    });

    it('23.6 Palm contact >= 45px or within 800ms suppression window is rejected', () => {
      trackFeature('feature_23_spen_hardware_inking');
      expect(palmModule.contactLooksLikePalm({ width: 50, height: 30 })).toBe(true);
      expect(palmModule.contactLooksLikePalm({ width: 20, height: 20 })).toBe(false);

      const now = 20000;
      const verdictRecent = palmModule.classifyTouch(
        { width: 20, height: 20 },
        { penDown: false, lastPenAt: now - 300, now }
      );
      expect(verdictRecent).toBe('pen-recent');

      const verdictAllowed = palmModule.classifyTouch(
        { width: 20, height: 20 },
        { penDown: false, lastPenAt: now - 900, now }
      );
      expect(verdictAllowed).toBe('allow');
    });

    it('23.7 Velocity thinning thins out rapid strokes while preserving deliberate slow writing', () => {
      trackFeature('feature_23_spen_hardware_inking');
      const slowPoints = [[0, 0, 0.5], [2, 0, 0.5], [4, 0, 0.5]];
      const fastPoints = [[0, 0, 0.5], [30, 0, 0.5], [70, 0, 0.5]];

      const slowDyn = strokeModule.applyPenDynamics(slowPoints, 'ballpoint', 65, 'standard');
      const fastDyn = strokeModule.applyPenDynamics(fastPoints, 'ballpoint', 65, 'standard');

      expect(fastDyn[2][2] < slowDyn[2][2]).toBe(true);
    });

    it('23.8 Anti-hook pruning removes terminal lift-off hooks without affecting checkmarks', () => {
      trackFeature('feature_23_spen_hardware_inking');
      const hookPoints = [
        [0, 0, 0.5], [30, 0, 0.5], [60, 0, 0.5], [90, 0, 0.5], [120, 0, 0.5], [105, 5, 0.15]
      ];
      const pruned = strokeModule.pruneTerminalHooks(hookPoints);
      expect(pruned.length).toBe(5);

      const checkmark = [
        [0, 50, 0.5], [20, 70, 0.5], [40, 90, 0.6], [60, 60, 0.5], [80, 30, 0.4]
      ];
      const preserved = strokeModule.pruneTerminalHooks(checkmark);
      expect(preserved.length).toBe(5);
    });
  });
});
