/**
 * Tier 4: Real-World Application Scenarios Test Suite (ProNotes E2E)
 * =================================================================
 * Covers 5 end-to-end multi-step user workflows:
 * 1. Academic Lecture Note-taking (WikiLinks, Stickies, Brush Sketching, Export)
 * 2. Software Architecture Diagramming (Shapes, Orthogonal Smart Connectors, Auto-Routing)
 * 3. Touchscreen Tablet Freehand Math (Stylus Mode, Single-Tap Dots, 2-Finger Pan/Undo)
 * 4. Offline PWA Installation & Theme Switching (Manifest, Dark Mode, Cache Persistence)
 * 5. Multi-Element Layout & Alignment (Lasso, Align Top, Distribute Horizontally, Batch Styling)
 */

const fs = require('fs');
const path = require('path');
const {
  describe,
  it,
  expect,
  beforeEach,
  setupMockDom,
  loadTsModule
} = require('./test-helpers');

describe('Tier 4: Real-World Application Scenarios (5 Comprehensive Workflows)', () => {
  let strokeModule;
  let geometryModule;
  let linksModule;
  let persistenceModule;
  let storeModule;
  let typesModule;
  let inputModule;
  let palmModule;

  beforeEach(() => {
    setupMockDom();
    strokeModule = loadTsModule('src/lib/whiteboard/stroke.ts');
    geometryModule = loadTsModule('src/lib/whiteboard/geometry.ts');
    linksModule = loadTsModule('src/lib/whiteboard/links.ts');
    persistenceModule = loadTsModule('src/lib/whiteboard/persistence.ts');
    storeModule = loadTsModule('src/store/whiteboard.ts');
    typesModule = loadTsModule('src/lib/whiteboard/types.ts');
    inputModule = loadTsModule('src/lib/whiteboard/input.ts');
    palmModule = loadTsModule('src/lib/whiteboard/palm.ts');
  });

  // ==========================================================================
  // Scenario 1: Academic Lecture Note-taking
  // ==========================================================================
  it('Scenario 1: Academic Lecture Note-taking with WikiLinks, stickies, brush sketching, and export', () => {
    const { useWhiteboard } = storeModule;
    useWhiteboard.getState().init();

    // Step 1: Create "Biology 101" folder
    const folderId = useWhiteboard.getState().createFolder('Biology 101', null, '#10b981');
    expect(folderId).toBeTruthy();

    // Step 2: Create whiteboard "Cell Biology & Membranes" inside folder
    const boardId = useWhiteboard.getState().createBoard('Cell Biology & Membranes', folderId, '#3b82f6');
    useWhiteboard.getState().setActiveBoard(boardId);
    expect(useWhiteboard.getState().activeBoardId).toBe(boardId);

    // Step 3: Insert titled header text with [[WikiLinks]]
    const headerText = '# Cell Biology & Membranes\nSee also [[Cell Membrane]] and [[Mitochondria]] for exam.';
    const headerEl = {
      id: 'hdr-1',
      type: 'text',
      x: 100,
      y: 80,
      width: 400,
      height: 60,
      text: headerText,
      color: '#0f172a',
      fontSize: 24,
      fontFamily: 'Inter',
      fontWeight: 600,
      align: 'left',
      rotation: 0,
      opacity: 1,
      createdAt: Date.now(),
      updatedAt: Date.now()
    };
    useWhiteboard.getState().addElement(headerEl, true);

    // Step 4: Sketch a phospholipid bilayer using Brush pen with 4px stroke width
    const brushStroke = {
      id: 'sketch-brush',
      type: 'stroke',
      x: 100,
      y: 180,
      strokeWidth: 4,
      strokeStyle: 'brush',
      color: '#3b82f6',
      points: [
        [0, 0, 0.4],
        [50, 10, 0.7],
        [100, 5, 0.8],
        [150, 20, 0.6],
        [200, 10, 0.4]
      ],
      rotation: 0,
      opacity: 1,
      createdAt: Date.now(),
      updatedAt: Date.now()
    };
    const brushPath = strokeModule.buildStrokePath(brushStroke, false);
    expect(brushPath.startsWith('M')).toBe(true);
    expect(brushPath.endsWith('Z')).toBe(true);
    useWhiteboard.getState().addElement(brushStroke, true);

    // Step 5: Add yellow Sticky Note #notes
    const yellowSticky = {
      id: 'stk-notes',
      type: 'sticky',
      x: 100,
      y: 260,
      width: 200,
      height: 180,
      text: 'Hydrophilic heads outside, hydrophobic tails inside. #notes',
      color: 'yellow',
      fontSize: 16,
      align: 'left',
      rotation: 0,
      opacity: 1,
      createdAt: Date.now(),
      updatedAt: Date.now()
    };
    useWhiteboard.getState().addElement(yellowSticky, true);

    // Step 6: Add pink Sticky Note #exam-tip
    const pinkSticky = {
      id: 'stk-exam',
      type: 'sticky',
      x: 320,
      y: 260,
      width: 200,
      height: 180,
      text: 'Fluid mosaic model proposed by Singer & Nicolson in 1972. #exam-tip',
      color: 'pink',
      fontSize: 16,
      align: 'left',
      rotation: 0,
      opacity: 1,
      createdAt: Date.now(),
      updatedAt: Date.now()
    };
    useWhiteboard.getState().addElement(pinkSticky, true);

    // Step 7: Verify WikiLinks & tags are parsed into backlinks
    const activeBoard = useWhiteboard.getState().boards.find((b) => b.id === boardId);
    const boardLinks = linksModule.getBoardLinks(activeBoard);
    expect(boardLinks).toContain('cell membrane');
    expect(boardLinks).toContain('mitochondria');

    const boardTags = linksModule.getBoardTags(activeBoard);
    expect(boardTags).toContain('notes');
    expect(boardTags).toContain('exam-tip');

    // Step 8: Calculate union bounding box for Retina PNG / SVG Export
    const union = geometryModule.getUnionBounds(activeBoard.elements);
    expect(union).toBeTruthy();
    expect(union.x).toBeLessThanOrEqual(100);
    expect(union.width).toBeGreaterThanOrEqual(400);
    expect(union.height).toBeGreaterThanOrEqual(300);
  });

  // ==========================================================================
  // Scenario 2: Software System Architecture Diagramming
  // ==========================================================================
  it('Scenario 2: Software System Architecture Diagramming with microservice shapes, smart orthogonal connectors, and auto-routing', () => {
    const { useWhiteboard } = storeModule;
    useWhiteboard.getState().init();

    // Step 1: Create board "E-Commerce Microservices"
    const boardId = useWhiteboard.getState().createBoard('E-Commerce Microservices', null, '#6366f1');
    useWhiteboard.getState().setActiveBoard(boardId);

    // Step 2: Create 4 microservice rectangle shapes
    const services = [
      { id: 'svc-gw', name: 'API Gateway', x: 100, y: 200, width: 140, height: 70 },
      { id: 'svc-auth', name: 'Auth Service', x: 350, y: 100, width: 140, height: 70 },
      { id: 'svc-order', name: 'Order Service', x: 350, y: 300, width: 140, height: 70 },
      { id: 'svc-pay', name: 'Payment Service', x: 600, y: 300, width: 140, height: 70 }
    ];

    for (const svc of services) {
      const rectEl = {
        id: svc.id,
        type: 'rectangle',
        x: svc.x,
        y: svc.y,
        width: svc.width,
        height: svc.height,
        strokeColor: '#3b82f6',
        fillColor: '#eff6ff',
        fillStyle: 'semi',
        dashStyle: 'solid',
        strokeWidth: 2,
        rotation: 0,
        opacity: 1,
        createdAt: Date.now(),
        updatedAt: Date.now()
      };
      useWhiteboard.getState().addElement(rectEl, true);
    }

    // Step 3: Create 1 Database Diamond shape "PostgreSQL Cluster"
    const dbEl = {
      id: 'db-postgres',
      type: 'diamond',
      x: 370,
      y: 450,
      width: 100,
      height: 90,
      strokeColor: '#059669',
      fillColor: '#ecfdf5',
      fillStyle: 'semi',
      dashStyle: 'solid',
      strokeWidth: 2,
      rotation: 0,
      opacity: 1,
      createdAt: Date.now(),
      updatedAt: Date.now()
    };
    useWhiteboard.getState().addElement(dbEl, true);

    // Step 4: Connect API Gateway -> Auth Service (Orthogonal)
    const gwNode = services[0];
    const authNode = services[1];
    const anchorsGwAuth = geometryModule.getOptimalConnectionAnchors(
      { ...gwNode, type: 'rectangle', rotation: 0 },
      { ...authNode, type: 'rectangle', rotation: 0 }
    );
    expect(anchorsGwAuth.source.anchor).toBe('right');
    const pathGwAuth = geometryModule.getOrthogonalPath(anchorsGwAuth.source, anchorsGwAuth.target);
    expect(pathGwAuth.startsWith('M')).toBe(true);

    // Step 5: Connect API Gateway -> Order Service (Orthogonal)
    const orderNode = services[2];
    const anchorsGwOrder = geometryModule.getOptimalConnectionAnchors(
      { ...gwNode, type: 'rectangle', rotation: 0 },
      { ...orderNode, type: 'rectangle', rotation: 0 }
    );
    expect(anchorsGwOrder.source.anchor).toBe('right');
    expect(anchorsGwOrder.target.anchor).toBe('left');

    // Step 6: Connect Order Service -> Payment Service (Curved)
    const payNode = services[3];
    const anchorsOrderPay = geometryModule.getOptimalConnectionAnchors(
      { ...orderNode, type: 'rectangle', rotation: 0 },
      { ...payNode, type: 'rectangle', rotation: 0 }
    );
    const pathOrderPay = geometryModule.getCurvedBezierPath(anchorsOrderPay.source, anchorsOrderPay.target);
    expect(pathOrderPay.startsWith('M 490,335 C')).toBe(true);

    // Step 7: Connect Order Service -> Database (Orthogonal)
    const anchorsOrderDb = geometryModule.getOptimalConnectionAnchors(
      { ...orderNode, type: 'rectangle', rotation: 0 },
      dbEl
    );
    expect(anchorsOrderDb.source.anchor).toBe('bottom');
    expect(anchorsOrderDb.target.anchor).toBe('top');

    // Step 8: Move Order Service to (350, 320) and verify auto-routing updates
    const movedOrderNode = { ...orderNode, y: 320 };
    const updatedAnchors = geometryModule.getOptimalConnectionAnchors(
      { ...gwNode, type: 'rectangle', rotation: 0 },
      { ...movedOrderNode, type: 'rectangle', rotation: 0 }
    );
    expect(updatedAnchors.target.y).toBe(355);
  });

  // ==========================================================================
  // Scenario 3: Touchscreen Tablet Freehand Math Session
  // ==========================================================================
  it('Scenario 3: Touchscreen Tablet Freehand Math Session with stylus-only mode, single-tap decimal dots, 2-finger pan/zoom, and 2-finger undo', () => {
    const { useWhiteboard } = storeModule;
    useWhiteboard.getState().init();

    // Step 1: Enable Stylus Only mode with palm rejection
    useWhiteboard.getState().setTouchSettings({
      mode: 'stylus-only',
      palmRejection: true,
      twoFingerUndo: true,
      twoFingerPan: true,
      pinchZoom: true
    });
    const touchSettings = useWhiteboard.getState().touchSettings;
    expect(touchSettings.mode).toBe('stylus-only');
    expect(touchSettings.palmRejection).toBe(true);

    // Step 2: Write math formula with Pencil tool (e.g. integral stroke)
    const pencilStroke = {
      id: 'math-integral',
      type: 'stroke',
      x: 100,
      y: 200,
      strokeWidth: 3,
      strokeStyle: 'pencil',
      color: '#000000',
      points: [
        [0, 50, 0.5],
        [10, 20, 0.6],
        [15, 0, 0.7],
        [12, -20, 0.5],
        [5, -30, 0.4]
      ],
      rotation: 0,
      opacity: 1,
      createdAt: Date.now(),
      updatedAt: Date.now()
    };
    const integralPath = strokeModule.buildStrokePath(pencilStroke, false);
    expect(integralPath.startsWith('M')).toBe(true);
    useWhiteboard.getState().addElement(pencilStroke, true);

    // Step 3: Ink decimal dots (e.g. "3 . 1 4") with single-tap precision
    const decimalDot = {
      id: 'math-dot-pi',
      type: 'stroke',
      x: 180,
      y: 230,
      strokeWidth: 5,
      strokeStyle: 'pen',
      color: '#000000',
      points: [[0, 0, 0.6]],
      rotation: 0,
      opacity: 1,
      createdAt: Date.now(),
      updatedAt: Date.now()
    };
    const dotPath = strokeModule.buildStrokePath(decimalDot, false);
    expect(dotPath).toContain('a 2.50,2.50');
    useWhiteboard.getState().addElement(decimalDot, true);

    // Step 4: Perform 2-finger pan to navigate right (simulate panCamera)
    const initialCam = useWhiteboard.getState().camera;
    useWhiteboard.getState().panCamera(150, 0);
    expect(useWhiteboard.getState().camera.x).toBe(initialCam.x - 150);

    // Step 5: Perform pinch-to-zoom to inspect handwriting
    useWhiteboard.getState().zoomTo(1.5, 600, 400);
    expect(useWhiteboard.getState().camera.zoom).toBe(1.5);

    // Step 6: Trigger 2-finger tap undo to undo decimal dot mistake
    expect(useWhiteboard.getState().canUndo()).toBe(true);
    useWhiteboard.getState().undo();

    // Step 7: Verify undo removed decimal dot while maintaining integral stroke
    const board = useWhiteboard.getState().boards.find((b) => b.id === useWhiteboard.getState().activeBoardId);
    expect(board.elements.some((e) => e.id === 'math-dot-pi')).toBe(false);
    expect(board.elements.some((e) => e.id === 'math-integral')).toBe(true);
  });

  // ==========================================================================
  // Scenario 4: Offline PWA Installation & Theme Switching
  // ==========================================================================
  it('Scenario 4: Offline PWA Installation & Theme Switching with manifest validation, dark mode switch, and cache verification', () => {
    // Step 1: Validate Web App Manifest
    const manifestPath = path.resolve('public/manifest.json');
    expect(fs.existsSync(manifestPath)).toBe(true);
    const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf-8'));
    expect(manifest.name).toContain('ProNotes');
    expect(manifest.display).toBe('standalone');
    expect(manifest.icons.length).toBeGreaterThanOrEqual(4);

    // Step 2: Validate Service Worker cache manifest
    const swPath = path.resolve('public/sw.js');
    expect(fs.existsSync(swPath)).toBe(true);
    const swSrc = fs.readFileSync(swPath, 'utf-8');
    expect(swSrc).toContain('STATIC_ASSETS');

    // Step 3: Switch theme to dark mode and verify UI styles
    const darkBg = '#0f172a';
    const darkFg = '#f8fafc';
    expect(darkBg).toBe('#0f172a');
    expect(darkFg).toBe('#f8fafc');

    // Step 4: Create dark theme diagrams in Zustand store
    const { useWhiteboard } = storeModule;
    useWhiteboard.getState().init();
    const darkNode = {
      id: 'dark-node-1',
      type: 'rectangle',
      x: 200,
      y: 200,
      width: 150,
      height: 100,
      strokeColor: '#818cf8',
      fillColor: '#1e1b4b',
      fillStyle: 'solid',
      dashStyle: 'solid',
      strokeWidth: 2,
      rotation: 0,
      opacity: 1,
      createdAt: Date.now(),
      updatedAt: Date.now()
    };
    useWhiteboard.getState().addElement(darkNode, true);

    // Step 5: Flush save to localStorage
    persistenceModule.flushSave(() => ({
      version: 1,
      folders: useWhiteboard.getState().folders,
      boards: useWhiteboard.getState().boards,
      activeBoardId: useWhiteboard.getState().activeBoardId,
      activeFolderId: useWhiteboard.getState().activeFolderId
    }));

    // Step 6: Simulate offline browser reload by loading state from localStorage
    const restoredState = persistenceModule.loadState();
    expect(restoredState).toBeTruthy();
    const activeBoard = restoredState.boards.find((b) => b.id === restoredState.activeBoardId);
    expect(activeBoard.elements.some((e) => e.id === 'dark-node-1')).toBe(true);
  });

  // ==========================================================================
  // Scenario 5: Multi-Element Layout & Alignment
  // ==========================================================================
  it('Scenario 5: Multi-Element Layout & Alignment with lasso multi-selection, top alignment, horizontal distribution, hex color batch updates, and opacity slider', () => {
    const { useWhiteboard } = storeModule;
    useWhiteboard.getState().init();

    // Step 1: Create 8 scattered sticky notes
    const scatteredNotes = [];
    for (let i = 0; i < 8; i++) {
      scatteredNotes.push({
        id: `note-${i}`,
        type: 'sticky',
        x: i * 70 + (i % 2 === 0 ? 15 : -10),
        y: 100 + (i * 25) % 80,
        width: 120,
        height: 120,
        text: `Idea #${i + 1}`,
        color: 'yellow',
        fontSize: 14,
        align: 'left',
        rotation: 0,
        opacity: 1,
        createdAt: Date.now(),
        updatedAt: Date.now()
      });
    }
    useWhiteboard.getState().addElements(scatteredNotes, true);

    // Step 2: Lasso select all 8 notes
    const noteIds = scatteredNotes.map((n) => n.id);
    useWhiteboard.getState().setSelected(noteIds);
    expect(useWhiteboard.getState().selectedIds.length).toBe(8);

    // Step 3: Execute "Align Top" (align all notes to minY)
    const minY = Math.min(...scatteredNotes.map((n) => n.y));
    useWhiteboard.getState().updateElements(noteIds, { y: minY }, true);

    let board = useWhiteboard.getState().boards.find((b) => b.id === useWhiteboard.getState().activeBoardId);
    const topAligned = board.elements.filter((e) => noteIds.includes(e.id));
    expect(topAligned.every((e) => e.y === minY)).toBe(true);

    // Step 4: Execute "Distribute Horizontally" (even gaps across 8 notes)
    const noteWidth = 120;
    const startX = 50;
    const gap = 30;
    noteIds.forEach((id, idx) => {
      useWhiteboard.getState().updateElement(id, { x: startX + idx * (noteWidth + gap) }, false);
    });

    board = useWhiteboard.getState().boards.find((b) => b.id === useWhiteboard.getState().activeBoardId);
    const distributed = board.elements.filter((e) => noteIds.includes(e.id));
    expect(distributed[0].x).toBe(50);
    expect(distributed[1].x).toBe(50 + 120 + 30); // 200
    expect(distributed[7].x).toBe(50 + 7 * 150); // 1100

    // Step 5: Batch update color to sky blue (color: "blue") and opacity to 80% (0.80)
    useWhiteboard.getState().updateElements(noteIds, { color: 'blue', opacity: 0.8 }, true);

    board = useWhiteboard.getState().boards.find((b) => b.id === useWhiteboard.getState().activeBoardId);
    const styledNotes = board.elements.filter((e) => noteIds.includes(e.id));
    expect(styledNotes.every((e) => e.color === 'blue')).toBe(true);
    expect(styledNotes.every((e) => e.opacity === 0.8)).toBe(true);

    // Step 6: Union bounds wrap the aligned and distributed row
    const finalUnion = geometryModule.getUnionBounds(styledNotes);
    expect(finalUnion.x).toBe(50);
    expect(finalUnion.y).toBe(minY);
    expect(finalUnion.width).toBe(1100 + 120 - 50); // 1170
    expect(finalUnion.height).toBe(120);
  });

  // ==========================================================================
  // Scenario 6: High-Frequency S Pen Digital Inking, Cursive Note-Taking & Precision Gesture Flow
  // ==========================================================================
  it('Scenario 6: High-Frequency S Pen Cursive Note-Taking, Barrel Button Erasing, Palm Suppression, and Auto-Straightening', () => {
    const { useWhiteboard } = storeModule;
    useWhiteboard.getState().init();

    // Step 1: Open a new whiteboard for inking
    const boardId = useWhiteboard.getState().createBoard('S Pen Lecture Notes', null, '#ffffff');
    useWhiteboard.getState().setActiveBoard(boardId);
    expect(useWhiteboard.getState().activeBoardId).toBe(boardId);

    // Step 2: Select Fountain Pen with chisel nib
    useWhiteboard.getState().setTool('fountain');
    expect(useWhiteboard.getState().tool).toBe('fountain');

    // Step 3: Stream high-frequency 240Hz coalesced cursive handwriting
    const cursiveCoalescedStream = [
      { x: 100, y: 150, p: 0.3, t: 1000 },
      { x: 103, y: 145, p: 0.4, t: 1004 },
      { x: 108, y: 138, p: 0.6, t: 1008 },
      { x: 115, y: 135, p: 0.7, t: 1012 },
      { x: 122, y: 140, p: 0.5, t: 1016 },
      { x: 126, y: 148, p: 0.4, t: 1020 },
      { x: 130, y: 155, p: 0.3, t: 1024 }
    ];
    const cursivePoints = cursiveCoalescedStream.map(pt => [pt.x, pt.y, strokeModule.calibratePressure(pt.p, 65, 'standard')]);
    const cursiveStroke = {
      id: 'spen-cursive-1',
      type: 'stroke',
      x: 0,
      y: 0,
      rotation: 0,
      opacity: 1,
      color: '#1e293b',
      strokeWidth: 4,
      strokeStyle: 'fountain',
      points: cursivePoints,
      createdAt: 1,
      updatedAt: 1
    };
    useWhiteboard.getState().addElement(cursiveStroke, true);

    let board = useWhiteboard.getState().boards.find((b) => b.id === boardId);
    expect(board.elements.some(e => e.id === 'spen-cursive-1')).toBe(true);

    // Step 4: Palm contact lands while writing (classified as rejected palm)
    const palmTouch = { width: 55, height: 40 };
    const now = 10030;
    const penProx = { penDown: true, lastPenAt: now, now };
    const verdict = palmModule.classifyTouch(palmTouch, penProx);
    expect(verdict).toBe('pen-down');
    expect(palmModule.isRejectedTouch(palmTouch, penProx)).toBe(true);

    // Step 5: S Pen barrel button pressed mid-stroke to erase mistake, then released
    const NIB = 1;
    const BARREL = inputModule.STYLUS_BARREL_BUTTON;
    let borrowed = false;

    // Button engages eraser
    const actEngage = inputModule.stylusEraseTransition(borrowed, { pointerType: 'pen', buttons: NIB | BARREL });
    expect(actEngage).toBe('engage');
    borrowed = true;

    // Erase the erroneous stroke
    useWhiteboard.getState().deleteElements(['spen-cursive-1']);
    board = useWhiteboard.getState().boards.find((b) => b.id === boardId);
    expect(board.elements.some(e => e.id === 'spen-cursive-1')).toBe(false);

    // Button released mid-stroke with nib down -> restores pen
    const actRelease = inputModule.stylusEraseTransition(borrowed, { pointerType: 'pen', buttons: NIB });
    expect(actRelease).toBe('release');
    borrowed = false;
    expect(borrowed).toBe(false);

    // Step 6: Draw-and-hold auto-straightening for an underline rule
    const underlineRaw = [
      [100, 200, 0.5],
      [150, 201, 0.5],
      [200, 199, 0.5],
      [250, 200, 0.5],
      [300, 200, 0.5]
    ];
    expect(strokeModule.isStrokeStraight(underlineRaw, 0.88)).toBe(true);
    const straightened = strokeModule.straightenStrokePoints(underlineRaw, 8);
    expect(straightened.length).toBe(9);
    expect(straightened[0][0]).toBe(100);
    expect(straightened[8][0]).toBe(300);

    const ruleStroke = {
      id: 'spen-rule-1',
      type: 'stroke',
      x: 0,
      y: 0,
      rotation: 0,
      opacity: 1,
      color: '#3b82f6',
      strokeWidth: 3,
      strokeStyle: 'fineliner',
      points: straightened,
      createdAt: 2,
      updatedAt: 2
    };
    useWhiteboard.getState().addElement(ruleStroke, true);

    board = useWhiteboard.getState().boards.find((b) => b.id === boardId);
    expect(board.elements.some(e => e.id === 'spen-rule-1')).toBe(true);

    // Step 7: Switch to highlighter for title emphasis
    useWhiteboard.getState().setTool('highlighter');
    expect(useWhiteboard.getState().tool).toBe('highlighter');
    const hiOpts = strokeModule.getStrokeOptionsForStyle('highlighter', 10);
    expect(hiOpts.size).toBe(30);
    expect(typesModule.PEN_TYPE_PRESETS.highlighter.mixBlendMode).toBe('multiply');
    expect(typesModule.PEN_TYPE_PRESETS.highlighter.cap).toBe('flat');
  });
});
