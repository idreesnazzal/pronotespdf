const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const ROOT = path.resolve(__dirname, '../../');

const mutations = [
  {
    id: 'MUT_01_STROKE_DOT',
    desc: 'Single-tap dot returns empty string instead of circular arc',
    file: 'src/lib/whiteboard/stroke.ts',
    find: 'if (cleanPoints.length === 1) {',
    replace: 'if (cleanPoints.length === 1) { return "";'
  },
  {
    id: 'MUT_02_HIGHLIGHTER_SCALE',
    desc: 'Highlighter size multiplier changed from 3x to 1x',
    file: 'src/lib/whiteboard/stroke.ts',
    find: 'const sizeMultiplier = style === "highlighter" ? 3 : 1;',
    replace: 'const sizeMultiplier = style === "highlighter" ? 1 : 1;'
  },
  {
    id: 'MUT_03_COORDINATE_SCREEN_TO_WORLD',
    desc: 'screenToWorld multiplies by zoom instead of dividing',
    file: 'src/lib/whiteboard/geometry.ts',
    find: '(sx - viewport.width / 2) / camera.zoom + camera.x',
    replace: '(sx - viewport.width / 2) * camera.zoom + camera.x'
  },
  {
    id: 'MUT_04_RECT_HIT_TEST',
    desc: 'Rectangle hit testing always returns false',
    file: 'src/lib/whiteboard/geometry.ts',
    find: 'case "rectangle":\n    case "text":\n    case "sticky":\n    case "image":\n      return (',
    replace: 'case "rectangle":\n    case "text":\n    case "sticky":\n    case "image":\n      return false && ('
  },
  {
    id: 'MUT_05_SMART_CONNECTOR_ANCHORS',
    desc: 'getOptimalConnectionAnchors returns inverted fixed anchors',
    file: 'src/lib/whiteboard/geometry.ts',
    find: 'return { source: sAnchor, target: tAnchor };',
    replace: 'return { source: { ...sAnchor, anchor: "top" }, target: { ...tAnchor, anchor: "bottom" } };'
  },
  {
    id: 'MUT_06_WIKILINK_PARSER',
    desc: 'WIKILINK_REGEX regex corrupted to curly braces {{...}}',
    file: 'src/lib/whiteboard/links.ts',
    find: 'const WIKILINK_REGEX = /\\[\\[([^\\]|]+)(?:\\|([^\\]]+))?\\]\\]/g;',
    replace: 'const WIKILINK_REGEX = /\\{\\{([^\\}|]+)\\}\\}/g;'
  },
  {
    id: 'MUT_07_STORE_UNDO',
    desc: 'Store undo made into a no-op',
    file: 'src/store/whiteboard.ts',
    find: 'undo: () => {\n    const state = get();',
    replace: 'undo: () => {\n    return;\n    const state = get();'
  },
  {
    id: 'MUT_08_ALIGN_TOP',
    desc: 'alignElements top alignment corrupted with 100px shift',
    file: 'src/lib/whiteboard/geometry.ts',
    find: 'case "top":\n        dy = union.y - b.y;\n        break;',
    replace: 'case "top":\n        dy = union.y - b.y + 100;\n        break;'
  },
  {
    id: 'MUT_09_CLAMP_MATH',
    desc: 'clamp function returns raw unconstrained input',
    file: 'src/lib/whiteboard/geometry.ts',
    find: 'export function clamp(v: number, min: number, max: number): number {\n  return Math.max(min, Math.min(max, v));\n}',
    replace: 'export function clamp(v: number, min: number, max: number): number {\n  return v;\n}'
  },
  {
    id: 'MUT_10_MANIFEST_BRANDING',
    desc: 'PWA manifest name corrupted from ProNotes to BogusNotes',
    file: 'public/manifest.json',
    find: '"name": "ProNotes — Infinite Whiteboard & Knowledge Canvas"',
    replace: '"name": "BogusNotes — Canvas"'
  },
  {
    id: 'MUT_11_TOUCH_SETTINGS',
    desc: 'DEFAULT_TOUCH_SETTINGS twoFingerUndo set to false',
    file: 'src/lib/whiteboard/types.ts',
    find: 'twoFingerUndo: true,',
    replace: 'twoFingerUndo: false,'
  },
  {
    id: 'MUT_12_ZOOM_MIN',
    desc: 'MIN_ZOOM changed from 0.05 to 0.5',
    file: 'src/lib/whiteboard/types.ts',
    find: 'export const MIN_ZOOM = 0.05;',
    replace: 'export const MIN_ZOOM = 0.5;'
  },
  {
    id: 'MUT_13_SW_FETCH_GET_ONLY',
    desc: 'Service Worker bypasses GET filtering allowing POST caching',
    file: 'public/sw.js',
    find: "if (request.method !== 'GET') {",
    replace: "if (request.method !== 'POST') {"
  },
  {
    id: 'MUT_14_PERSISTENCE_MIGRATION',
    desc: 'Persistence loadState migrate assigns wrong fallback color',
    file: 'src/lib/whiteboard/persistence.ts',
    find: 'color: typeof b.color === "string" ? b.color : "#3b82f6",',
    replace: 'color: typeof b.color === "string" ? b.color : "#ff0000",'
  },
  {
    id: 'MUT_15_BOUNDS_ELLIPSE',
    desc: 'getElementBounds on ellipse returns width 0',
    file: 'src/lib/whiteboard/geometry.ts',
    find: 'case "rectangle":\n    case "ellipse":',
    replace: 'case "rectangle":\n      return { x: el.x, y: el.y, width: el.width, height: el.height };\n    case "ellipse":\n      return { x: el.x, y: el.y, width: 0, height: el.height };'
  }
];

const results = [];

console.log('='.repeat(80));
console.log('  🔬  PRONOTES ADVERSARIAL MUTATION TESTING SUITE (15 MUTATIONS)');
console.log('='.repeat(80));

for (const m of mutations) {
  const filePath = path.join(ROOT, m.file);
  const original = fs.readFileSync(filePath, 'utf8');
  if (!original.includes(m.find)) {
    console.error(`❌ [SETUP ERROR] Target string not found for ${m.id} in ${m.file}`);
    results.push({ id: m.id, desc: m.desc, caught: false, error: 'Target not found in file' });
    continue;
  }
  const mutated = original.replace(m.find, m.replace);
  fs.writeFileSync(filePath, mutated, 'utf8');

  let caught = false;
  let output = '';
  try {
    output = execSync('node tests/e2e/runner.js', {
      cwd: ROOT,
      env: { ...process.env, PATH: 'C:\\Program Files\\nodejs;' + process.env.PATH },
      encoding: 'utf8',
      stdio: 'pipe'
    });
    caught = false; // If it exited 0, test suite missed the bug!
  } catch (err) {
    caught = true; // Exited non-zero -> bug was caught!
    output = (err.stdout || '') + '\n' + (err.stderr || '');
  } finally {
    fs.writeFileSync(filePath, original, 'utf8'); // ALWAYS RESTORE ORIGINAL
  }

  // Count failed tests in output
  const failMatches = output.match(/✗\s+([^\n]+)/g) || [];
  results.push({
    id: m.id,
    desc: m.desc,
    file: m.file,
    caught,
    failedTestCount: failMatches.length,
    sampleFailures: failMatches.slice(0, 3).map(s => s.trim())
  });

  const status = caught ? '✅ CAUGHT' : '❌ MISSED';
  console.log(`\n${status} [${m.id}] ${m.desc}`);
  console.log(`   Target File: ${m.file}`);
  console.log(`   Failed Test Assertions Triggered: ${failMatches.length}`);
  if (failMatches.length > 0) {
    console.log('   Sample Caught Tests:');
    failMatches.slice(0, 3).forEach(f => console.log(`     - ${f.trim()}`));
  }
}

console.log('\n' + '='.repeat(80));
console.log('  📊  MUTATION SCORE SUMMARY');
console.log('='.repeat(80));
const caughtCount = results.filter(r => r.caught).length;
const totalCount = results.length;
const score = ((caughtCount / totalCount) * 100).toFixed(1);

console.log(`  Total Injected Mutations : ${totalCount}`);
console.log(`  Mutations Caught         : ${caughtCount}`);
console.log(`  Mutations Missed         : ${totalCount - caughtCount}`);
console.log(`  Mutation Score           : ${score}%`);
console.log('='.repeat(80));

process.exit(caughtCount === totalCount ? 0 : 1);
