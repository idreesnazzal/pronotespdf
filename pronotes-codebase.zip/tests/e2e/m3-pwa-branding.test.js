/**
 * Milestone 3 Empirical Test Suite: Branding & PWA Integration
 * ==============================================================
 * Comprehensive, multi-tiered test suite verifying:
 * 1. Service Worker caching strategies, SWR, offline fallbacks, filters (public/sw.js)
 * 2. PWA registration lifecycle, beforeinstallprompt, appinstalled (PWARegister.tsx)
 * 3. Next.js 15 metadata, viewport, icon declarations (src/app/layout.tsx)
 * 4. PWA Web App Manifest schema & installability (public/manifest.json)
 * 5. Physical image asset dimensions, color channels, binary ICO headers (public/*)
 * 6. Global ProNotes branding consistency across UI, configs, and scripts
 * 7. Stress Tests, Fault Injection & Edge Cases
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');
const sharp = require('sharp');
const React = require('react');
const {
  describe,
  it,
  expect,
  beforeEach,
  afterEach,
  setupMockDom,
  loadTsModule,
  clearModuleCache,
  ctx
} = require('./test-helpers');

// The service worker's cache key, read from sw.js itself. These tests used to
// hardcode the very first key; the worker is bumped on every deploy (that is how it
// evicts stale chunks), so the frozen key failed every SW test once the suite
// stopped being run - and nobody noticed, because nothing ran it.
const SW_CACHE = (() => {
  const src = fs.readFileSync(path.join(__dirname, '..', '..', 'public', 'sw.js'), 'utf-8');
  const m = src.match(/const CACHE_VERSION = '([^']+)'/);
  if (!m) throw new Error('sw.js no longer declares CACHE_VERSION - update this suite');
  return m[1];
})();

const ROOT_DIR = path.resolve(__dirname, '../../');
const PUBLIC_DIR = path.resolve(ROOT_DIR, 'public');

// ============================================================================
// Mock Service Worker Environment
// ============================================================================

class MockCache {
  constructor(name) {
    this.name = name;
    this.store = new Map();
  }

  async add(url) {
    this.store.set(url, new MockResponse(`content-for-${url}`, { status: 200 }));
  }

  async addAll(urls) {
    for (const url of urls) {
      await this.add(url);
    }
  }

  async match(request) {
    const key = typeof request === 'string' ? request : request.url;
    if (this.store.has(key)) return this.store.get(key);
    try {
      const u = new URL(key, 'http://localhost:3000');
      if (this.store.has(u.pathname)) return this.store.get(u.pathname);
      if (this.store.has(u.href)) return this.store.get(u.href);
    } catch {
      // ignore
    }
    return undefined;
  }

  async put(request, response) {
    const key = typeof request === 'string' ? request : request.url;
    this.store.set(key, response);
  }

  async delete(request) {
    const key = typeof request === 'string' ? request : request.url;
    return this.store.delete(key);
  }
}

class MockCacheStorage {
  constructor() {
    this.caches = new Map();
  }

  async open(cacheName) {
    if (!this.caches.has(cacheName)) {
      this.caches.set(cacheName, new MockCache(cacheName));
    }
    return this.caches.get(cacheName);
  }

  async match(request) {
    for (const cache of this.caches.values()) {
      const match = await cache.match(request);
      if (match) return match;
    }
    return undefined;
  }

  async keys() {
    return Array.from(this.caches.keys());
  }

  async delete(cacheName) {
    return this.caches.delete(cacheName);
  }
}

class MockResponse {
  constructor(body = '', options = {}) {
    this.body = body;
    this.status = options.status !== undefined ? options.status : 200;
    this.statusText = options.statusText || 'OK';
    this.headers = options.headers || {};
  }

  clone() {
    return new MockResponse(this.body, {
      status: this.status,
      statusText: this.statusText,
      headers: { ...this.headers }
    });
  }

  async text() {
    return this.body;
  }
}

class MockRequest {
  constructor(input, init = {}) {
    this.url = typeof input === 'string' ? input : input.url;
    this.method = (init.method || 'GET').toUpperCase();
    this.mode = init.mode || 'cors';
    // A real Request's headers are a Headers object. sw.js now reads
    // `request.headers.get('RSC')` to keep App Router payloads out of the
    // cache, and a plain object made every fetch-strategy test throw.
    const raw = init.headers || {};
    const lower = new Map(Object.entries(raw).map(([k, v]) => [k.toLowerCase(), String(v)]));
    this.headers = {
      get: (name) => (lower.has(name.toLowerCase()) ? lower.get(name.toLowerCase()) : null),
      has: (name) => lower.has(name.toLowerCase()),
    };
  }
}

class MockExtendableEvent {
  constructor(type) {
    this.type = type;
    this.promises = [];
  }

  waitUntil(p) {
    this.promises.push(Promise.resolve(p));
  }

  async wait() {
    await Promise.all(this.promises);
  }
}

class MockFetchEvent extends MockExtendableEvent {
  constructor(request) {
    super('fetch');
    this.request = request;
    this.responsePromise = null;
    this.responded = false;
  }

  respondWith(p) {
    this.responded = true;
    this.responsePromise = Promise.resolve(p);
  }

  async getResponse() {
    if (!this.responsePromise) return null;
    return await this.responsePromise;
  }
}

function createSwEnvironment() {
  const listeners = new Map();
  const caches = new MockCacheStorage();
  let skipWaitingCalled = false;
  let claimCalled = false;

  const mockSelf = {
    addEventListener: (type, fn) => {
      if (!listeners.has(type)) listeners.set(type, []);
      listeners.get(type).push(fn);
    },
    skipWaiting: () => {
      skipWaitingCalled = true;
      return Promise.resolve();
    },
    clients: {
      claim: () => {
        claimCalled = true;
        return Promise.resolve();
      }
    }
  };

  const swCode = fs.readFileSync(path.join(PUBLIC_DIR, 'sw.js'), 'utf-8');

  // Helper to run SW
  const runInSw = (fetchMock) => {
    const fn = new Function(
      'self',
      'caches',
      'fetch',
      'Request',
      'Response',
      'URL',
      swCode
    );
    fn(
      mockSelf,
      caches,
      fetchMock,
      MockRequest,
      MockResponse,
      URL
    );
  };

  return {
    listeners,
    caches,
    mockSelf,
    getSkipWaitingCalled: () => skipWaitingCalled,
    getClaimCalled: () => claimCalled,
    runInSw
  };
}

// Helper to run React component effects
function mountComponent(compFn) {
  let cleanupFn = null;
  const originalUseEffect = React.useEffect;
  React.useEffect = (effectCallback) => {
    cleanupFn = effectCallback();
  };
  try {
    compFn();
  } finally {
    React.useEffect = originalUseEffect;
  }
  return {
    unmount: () => {
      if (typeof cleanupFn === 'function') {
        cleanupFn();
      }
    }
  };
}

// ============================================================================
// TEST SUITES
// ============================================================================

describe('M3.1 — Service Worker Implementation (public/sw.js)', () => {
  it('sw.js file exists and has non-empty content', () => {
    const swPath = path.join(PUBLIC_DIR, 'sw.js');
    expect(fs.existsSync(swPath)).toBe(true);
    const content = fs.readFileSync(swPath, 'utf-8');
    expect(content.length).toBeGreaterThan(100);
    expect(content).toContain(SW_CACHE);
  });

  it('declares all required STATIC_ASSETS and all files exist on disk', () => {
    const swContent = fs.readFileSync(path.join(PUBLIC_DIR, 'sw.js'), 'utf-8');
    const requiredAssets = [
      '/',
      '/manifest.json',
      '/favicon.ico',
      '/favicon.png',
      '/favicon-32x32.png',
      '/favicon-16x16.png',
      '/icon-192.png',
      '/icon-512.png',
      '/icon-192-maskable.png',
      '/icon-512-maskable.png',
      '/apple-touch-icon.png',
      '/logo.png',
    ];

    for (const asset of requiredAssets) {
      expect(swContent).toContain(`'${asset}'`);
      if (asset !== '/') {
        const filePath = path.join(PUBLIC_DIR, asset.replace('/', ''));
        expect(fs.existsSync(filePath)).toBe(true);
      }
    }
  });

  it('handles "install" event: pre-caches STATIC_ASSETS and calls skipWaiting', async () => {
    const env = createSwEnvironment();
    env.runInSw(async () => new MockResponse());

    const installListeners = env.listeners.get('install') || [];
    expect(installListeners.length).toBeGreaterThan(0);

    const installEvent = new MockExtendableEvent('install');
    installListeners[0](installEvent);
    await installEvent.wait();

    expect(env.getSkipWaitingCalled()).toBe(true);

    const cache = await env.caches.open(SW_CACHE);
    const rootCached = await cache.match('/');
    expect(rootCached).toBeDefined();
    const manifestCached = await cache.match('/manifest.json');
    expect(manifestCached).toBeDefined();
    const iconCached = await cache.match('/icon-192.png');
    expect(iconCached).toBeDefined();
  });

  it('handles "activate" event: purges stale caches and claims clients', async () => {
    const env = createSwEnvironment();
    env.runInSw(async () => new MockResponse());

    // Populate old caches
    const oldCache1 = await env.caches.open('pronotes-v0');
    await oldCache1.put('/old.js', new MockResponse('old'));
    const oldCache2 = await env.caches.open('legacy-cache');
    await oldCache2.put('/legacy.js', new MockResponse('legacy'));
    const currentCache = await env.caches.open(SW_CACHE);
    await currentCache.put('/current.js', new MockResponse('current'));

    const activateListeners = env.listeners.get('activate') || [];
    expect(activateListeners.length).toBeGreaterThan(0);

    const activateEvent = new MockExtendableEvent('activate');
    activateListeners[0](activateEvent);
    await activateEvent.wait();

    expect(env.getClaimCalled()).toBe(true);

    const remainingKeys = await env.caches.keys();
    expect(remainingKeys).toContain(SW_CACHE);
    expect(remainingKeys.includes('pronotes-v0')).toBe(false);
    expect(remainingKeys.includes('legacy-cache')).toBe(false);
  });

  it('fetch strategy: ignores non-GET requests (POST, PUT, DELETE)', async () => {
    const env = createSwEnvironment();
    let networkFetchCalled = false;
    env.runInSw(async () => {
      networkFetchCalled = true;
      return new MockResponse('ok');
    });

    const fetchListeners = env.listeners.get('fetch') || [];
    const postReq = new MockRequest('http://localhost:3000/api/save', { method: 'POST' });
    const fetchEvent = new MockFetchEvent(postReq);

    fetchListeners[0](fetchEvent);
    expect(fetchEvent.responded).toBe(false);
    expect(networkFetchCalled).toBe(false);
  });

  it('fetch strategy: ignores /api/* requests and non-http protocols', async () => {
    const env = createSwEnvironment();
    env.runInSw(async () => new MockResponse('ok'));
    const fetchListeners = env.listeners.get('fetch') || [];

    const apiReq = new MockRequest('http://localhost:3000/api/auth/session', { method: 'GET' });
    const apiEvent = new MockFetchEvent(apiReq);
    fetchListeners[0](apiEvent);
    expect(apiEvent.responded).toBe(false);

    const chromeExtReq = new MockRequest('chrome-extension://abcdefg/inject.js', { method: 'GET' });
    const extEvent = new MockFetchEvent(chromeExtReq);
    fetchListeners[0](extEvent);
    expect(extEvent.responded).toBe(false);
  });

  it('fetch strategy (Navigation): Network-First succeeds and updates cache on 200', async () => {
    const env = createSwEnvironment();
    let networkCalled = false;
    env.runInSw(async (req) => {
      networkCalled = true;
      return new MockResponse('<!DOCTYPE html><html>Fresh Network HTML</html>', { status: 200 });
    });

    const fetchListeners = env.listeners.get('fetch') || [];
    const navReq = new MockRequest('http://localhost:3000/whiteboard/123', {
      method: 'GET',
      mode: 'navigate'
    });
    const fetchEvent = new MockFetchEvent(navReq);
    fetchListeners[0](fetchEvent);

    expect(fetchEvent.responded).toBe(true);
    const res = await fetchEvent.getResponse();
    expect(networkCalled).toBe(true);
    expect(await res.text()).toContain('Fresh Network HTML');

    // Verify it updated the cache
    const cache = await env.caches.open(SW_CACHE);
    const cachedNav = await cache.match(navReq);
    expect(cachedNav).toBeDefined();
    expect(await cachedNav.text()).toContain('Fresh Network HTML');
  });

  it('fetch strategy (Navigation): Network-First falls back to cached "/" when offline', async () => {
    const env = createSwEnvironment();
    // Pre-cache root '/'
    const cache = await env.caches.open(SW_CACHE);
    await cache.put('/', new MockResponse('<!DOCTYPE html><html>Cached Offline App Shell</html>', { status: 200 }));

    // Simulate network error (offline)
    env.runInSw(async () => {
      throw new Error('Failed to fetch (offline)');
    });

    const fetchListeners = env.listeners.get('fetch') || [];
    const navReq = new MockRequest('http://localhost:3000/some/deep/route', {
      method: 'GET',
      mode: 'navigate'
    });
    const fetchEvent = new MockFetchEvent(navReq);
    fetchListeners[0](fetchEvent);

    expect(fetchEvent.responded).toBe(true);
    const res = await fetchEvent.getResponse();
    expect(res).toBeDefined();
    expect(await res.text()).toContain('Cached Offline App Shell');
  });

  it('fetch strategy (Static Assets): Cache-First returns cached item immediately and triggers SWR revalidation', async () => {
    const env = createSwEnvironment();
    const cache = await env.caches.open(SW_CACHE);
    const assetUrl = 'http://localhost:3000/static/bundle.js';
    await cache.put(assetUrl, new MockResponse('console.log("Cached v1");', { status: 200 }));

    let backgroundFetchTriggered = false;
    env.runInSw(async (req) => {
      backgroundFetchTriggered = true;
      return new MockResponse('console.log("Fresh v2");', { status: 200 });
    });

    const fetchListeners = env.listeners.get('fetch') || [];
    const assetReq = new MockRequest(assetUrl, { method: 'GET', mode: 'cors' });
    const fetchEvent = new MockFetchEvent(assetReq);
    fetchListeners[0](fetchEvent);

    expect(fetchEvent.responded).toBe(true);
    const res = await fetchEvent.getResponse();
    // Instant response is cached v1
    expect(await res.text()).toBe('console.log("Cached v1");');

    // Wait microtask for SWR background promise
    await new Promise((r) => setTimeout(r, 10));
    expect(backgroundFetchTriggered).toBe(true);

    // Cache updated to v2
    const updated = await cache.match(assetUrl);
    expect(await updated.text()).toBe('console.log("Fresh v2");');
  });

  it('fetch strategy (Static Assets): Cache-Miss fetches from network, caches, and returns response', async () => {
    const env = createSwEnvironment();
    const assetUrl = 'http://localhost:3000/logo.png';
    let networkFetched = false;

    env.runInSw(async (req) => {
      networkFetched = true;
      return new MockResponse('PNG_IMAGE_DATA_BYTES', { status: 200 });
    });

    const fetchListeners = env.listeners.get('fetch') || [];
    const assetReq = new MockRequest(assetUrl, { method: 'GET', mode: 'cors' });
    const fetchEvent = new MockFetchEvent(assetReq);
    fetchListeners[0](fetchEvent);

    expect(fetchEvent.responded).toBe(true);
    const res = await fetchEvent.getResponse();
    expect(networkFetched).toBe(true);
    expect(await res.text()).toBe('PNG_IMAGE_DATA_BYTES');

    // Cache now holds the newly fetched item
    const cache = await env.caches.open(SW_CACHE);
    const cachedItem = await cache.match(assetUrl);
    expect(cachedItem).toBeDefined();
    expect(await cachedItem.text()).toBe('PNG_IMAGE_DATA_BYTES');
  });
});

describe('M3.2 — PWA Client Lifecycle & Component (PWARegister.tsx)', () => {
  // These tests model the ONE environment the service worker is meant for: a
  // production web build served over http(s). PWARegister now refuses to
  // register anywhere else (dev server, the APK, Electron's pronotes://), so
  // the mock DOM has to say which environment it is - it used to have no
  // `location` at all, and no NODE_ENV.
  let savedNodeEnv;
  beforeEach(() => {
    clearModuleCache();
    setupMockDom();
    Object.defineProperty(global, 'navigator', {
      value: global.window.navigator,
      configurable: true,
      writable: true
    });
    global.window.location = { protocol: 'https:', pathname: '/', search: '', hash: '' };
    savedNodeEnv = process.env.NODE_ENV;
    process.env.NODE_ENV = 'production';
  });
  afterEach(() => {
    process.env.NODE_ENV = savedNodeEnv;
  });

  it('PWARegister source exists and compiles without TypeScript errors', () => {
    const compPath = path.join(ROOT_DIR, 'src/components/pwa/PWARegister.tsx');
    expect(fs.existsSync(compPath)).toBe(true);
    const mod = loadTsModule('src/components/pwa/PWARegister.tsx');
    expect(typeof mod.PWARegister).toBe('function');
  });

  it('Registers /sw.js on window load and sets up update lifecycle handler', async () => {
    const eventMap = {};
    let registeredSwPath = null;

    global.window.addEventListener = (event, handler) => {
      eventMap[event] = handler;
    };
    global.window.removeEventListener = (event, handler) => {
      delete eventMap[event];
    };

    let onUpdateFoundHandler = null;
    let stateChangeHandler = null;
    const mockInstallingWorker = {
      state: 'installing',
      set onstatechange(fn) {
        stateChangeHandler = fn;
      },
      get onstatechange() {
        return stateChangeHandler;
      }
    };

    const mockRegistration = {
      scope: '/',
      get installing() {
        return mockInstallingWorker;
      },
      set onupdatefound(fn) {
        onUpdateFoundHandler = fn;
      },
      get onupdatefound() {
        return onUpdateFoundHandler;
      }
    };

    const mockNavigator = {
      serviceWorker: {
        register: async (path) => {
          registeredSwPath = path;
          return mockRegistration;
        },
        controller: {}
      }
    };
    global.window.navigator = mockNavigator;
    Object.defineProperty(global, 'navigator', {
      value: mockNavigator,
      configurable: true,
      writable: true
    });

    const mod = loadTsModule('src/components/pwa/PWARegister.tsx');
    mountComponent(mod.PWARegister);

    // Verify window.load was subscribed
    expect(typeof eventMap['load']).toBe('function');

    // Trigger load event
    eventMap['load']();
    await new Promise((r) => setTimeout(r, 20));

    expect(registeredSwPath).toBe('/sw.js');

    // Test onupdatefound handler
    expect(typeof mockRegistration.onupdatefound).toBe('function');
    mockRegistration.onupdatefound();
    expect(typeof mockInstallingWorker.onstatechange).toBe('function');

    // Fire state change to installed
    mockInstallingWorker.state = 'installed';
    mockInstallingWorker.onstatechange();
  });

  it('Captures beforeinstallprompt and dispatches "pronotes:can-install"', () => {
    const eventMap = {};
    const dispatchedEvents = [];

    global.window.addEventListener = (event, handler) => {
      eventMap[event] = handler;
    };
    global.window.removeEventListener = (event, handler) => {
      delete eventMap[event];
    };
    global.window.dispatchEvent = (event) => {
      dispatchedEvents.push(event);
    };

    const mod = loadTsModule('src/components/pwa/PWARegister.tsx');
    mountComponent(mod.PWARegister);

    const fakePromptEvent = {
      platforms: ['web', 'windows'],
      prompt: async () => {},
      userChoice: Promise.resolve({ outcome: 'accepted', platform: 'windows' })
    };

    expect(typeof eventMap['beforeinstallprompt']).toBe('function');
    eventMap['beforeinstallprompt'](fakePromptEvent);

    expect(global.window.__PWA_INSTALL_PROMPT__).toBe(fakePromptEvent);
    expect(dispatchedEvents.some((e) => e.type === 'pronotes:can-install')).toBe(true);
  });

  it('Handles appinstalled, clears prompt state, and dispatches "pronotes:installed"', () => {
    const eventMap = {};
    const dispatchedEvents = [];

    global.window.addEventListener = (event, handler) => {
      eventMap[event] = handler;
    };
    global.window.removeEventListener = (event, handler) => {
      delete eventMap[event];
    };
    global.window.dispatchEvent = (event) => {
      dispatchedEvents.push(event);
    };

    const mod = loadTsModule('src/components/pwa/PWARegister.tsx');
    mountComponent(mod.PWARegister);
    global.window.__PWA_INSTALL_PROMPT__ = { fake: true };

    expect(typeof eventMap['appinstalled']).toBe('function');
    eventMap['appinstalled']();

    expect(global.window.__PWA_INSTALL_PROMPT__).toBeNull();
    expect(dispatchedEvents.some((e) => e.type === 'pronotes:installed')).toBe(true);
  });

  it('Cleans up event listeners on unmount', () => {
    const eventMap = {};

    global.window.addEventListener = (event, handler) => {
      eventMap[event] = handler;
    };
    global.window.removeEventListener = (event, handler) => {
      delete eventMap[event];
    };

    const mod = loadTsModule('src/components/pwa/PWARegister.tsx');
    const instance = mountComponent(mod.PWARegister);

    expect(eventMap['beforeinstallprompt']).toBeDefined();
    expect(eventMap['appinstalled']).toBeDefined();

    instance.unmount();

    expect(eventMap['beforeinstallprompt']).toBeUndefined();
    expect(eventMap['appinstalled']).toBeUndefined();
  });

  // --- where the service worker must NOT run -------------------------------
  // A cache-first worker inside the APK could serve an old, unhashed
  // pdf.worker.min.mjs after an update; under `npm run dev` it served stale
  // unhashed dev chunks. In both places it must stay unregistered and clean up
  // any worker an earlier build installed.
  const expectNoRegistration = async (label) => {
    let registered = false;
    let unregistered = 0;
    const eventMap = {};
    global.window.addEventListener = (event, handler) => { eventMap[event] = handler; };
    global.window.removeEventListener = (event) => { delete eventMap[event]; };
    const nav = {
      serviceWorker: {
        register: async () => { registered = true; return {}; },
        getRegistrations: async () => [{ unregister: async () => { unregistered++; return true; } }],
        controller: null,
      },
    };
    global.window.navigator = nav;
    Object.defineProperty(global, 'navigator', { value: nav, configurable: true, writable: true });

    const mod = loadTsModule('src/components/pwa/PWARegister.tsx');
    const instance = mountComponent(mod.PWARegister);
    if (eventMap['load']) eventMap['load']();
    await new Promise((r) => setTimeout(r, 20));
    expect(registered).toBe(false);
    expect(unregistered).toBe(1);
    instance.unmount();
  };

  it('does NOT register under the dev server, and removes an old worker', async () => {
    process.env.NODE_ENV = 'development';
    await expectNoRegistration('dev');
  });

  it('does NOT register outside http(s) (Electron pronotes://), and removes an old worker', async () => {
    global.window.location = { protocol: 'pronotes:', pathname: '/index.html', search: '', hash: '' };
    await expectNoRegistration('electron');
  });
});

describe('M3.3 — Next.js Layout Metadata & Viewport Exports (src/app/layout.tsx)', () => {
  it('src/app/layout.tsx exists and contains valid metadata and viewport exports', () => {
    const layoutPath = path.join(ROOT_DIR, 'src/app/layout.tsx');
    expect(fs.existsSync(layoutPath)).toBe(true);

    const layoutContent = fs.readFileSync(layoutPath, 'utf-8');
    expect(layoutContent).toContain('export const metadata');
    expect(layoutContent).toContain('export const viewport');
    expect(layoutContent).toContain('<PWARegister');
  });

  it('Metadata contains accurate ProNotes title, manifest, and icons', () => {
    const layoutContent = fs.readFileSync(path.join(ROOT_DIR, 'src/app/layout.tsx'), 'utf-8');

    expect(layoutContent).toContain('title: "ProNotes — Infinite Whiteboard & Knowledge Canvas"');
    expect(layoutContent).toContain('manifest: "/manifest.json"');
    expect(layoutContent).toContain('applicationName: "ProNotes"');
    expect(layoutContent).toContain('capable: true');
    expect(layoutContent).toContain('statusBarStyle: "black-translucent"');
    expect(layoutContent).toContain('url: "/favicon.ico"');
    expect(layoutContent).toContain('url: "/favicon.png"');
    expect(layoutContent).toContain('url: "/icon-192.png"');
    expect(layoutContent).toContain('url: "/icon-512.png"');
    expect(layoutContent).toContain('url: "/apple-touch-icon.png"');
  });

  it('Viewport exports Next.js 15 themeColor and scale constraints', () => {
    const layoutContent = fs.readFileSync(path.join(ROOT_DIR, 'src/app/layout.tsx'), 'utf-8');

    expect(layoutContent).toContain('themeColor: "#4f46e5"');
    expect(layoutContent).toContain('width: "device-width"');
    expect(layoutContent).toContain('initialScale: 1');
    expect(layoutContent).toContain('maximumScale: 1');
    expect(layoutContent).toContain('userScalable: false');
  });
});

describe('M3.4 — PWA Web App Manifest Compliance (public/manifest.json)', () => {
  const manifestPath = path.join(PUBLIC_DIR, 'manifest.json');

  it('manifest.json exists and is valid JSON', () => {
    expect(fs.existsSync(manifestPath)).toBe(true);
    const content = fs.readFileSync(manifestPath, 'utf-8');
    const parsed = JSON.parse(content);
    expect(typeof parsed).toBe('object');
  });

  it('Conforms to PWA installation standards (name, display, colors, start_url)', () => {
    const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf-8'));

    expect(manifest.name).toBe('ProNotes — Infinite Whiteboard & Knowledge Canvas');
    expect(manifest.short_name).toBe('ProNotes');
    expect(manifest.start_url).toBe('/');
    expect(manifest.scope).toBe('/');
    expect(manifest.display).toBe('standalone');
    expect(manifest.theme_color.toLowerCase()).toBe('#4f46e5');
    expect(manifest.background_color.toLowerCase()).toBe('#0f172a');
    expect(Array.isArray(manifest.display_override)).toBe(true);
    expect(manifest.display_override).toContain('window-controls-overlay');
  });

  it('Contains all required icons including standard and maskable variants', () => {
    const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf-8'));
    expect(Array.isArray(manifest.icons)).toBe(true);
    expect(manifest.icons.length).toBeGreaterThanOrEqual(4);

    const hasStandard192 = manifest.icons.some(
      (i) => i.sizes === '192x192' && (i.purpose === 'any' || !i.purpose) && i.src === '/icon-192.png'
    );
    const hasStandard512 = manifest.icons.some(
      (i) => i.sizes === '512x512' && (i.purpose === 'any' || !i.purpose) && i.src === '/icon-512.png'
    );
    const hasMaskable192 = manifest.icons.some(
      (i) => i.sizes === '192x192' && i.purpose === 'maskable' && i.src === '/icon-192-maskable.png'
    );
    const hasMaskable512 = manifest.icons.some(
      (i) => i.sizes === '512x512' && i.purpose === 'maskable' && i.src === '/icon-512-maskable.png'
    );

    expect(hasStandard192).toBe(true);
    expect(hasStandard512).toBe(true);
    expect(hasMaskable192).toBe(true);
    expect(hasMaskable512).toBe(true);

    // Verify all icon src paths resolve to actual files
    for (const icon of manifest.icons) {
      const relPath = icon.src.startsWith('/') ? icon.src.slice(1) : icon.src;
      expect(fs.existsSync(path.join(PUBLIC_DIR, relPath))).toBe(true);
    }
  });

  it('Defines shortcuts for New Whiteboard and Knowledge Graph with valid targets', () => {
    const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf-8'));
    expect(Array.isArray(manifest.shortcuts)).toBe(true);
    expect(manifest.shortcuts.length).toBeGreaterThanOrEqual(2);

    const newBoard = manifest.shortcuts.find((s) => s.url === '/?action=new');
    expect(newBoard).toBeDefined();
    expect(newBoard.name).toBe('New Whiteboard');

    const graph = manifest.shortcuts.find((s) => s.url === '/?view=graph');
    expect(graph).toBeDefined();
    expect(graph.name).toBe('Knowledge Graph');
  });
});

describe('M3.5 — Physical Brand Assets & Image Verification (Sharp & Binary)', () => {
  it('Validates binary structure of favicon.ico (32x32 and 16x16 formats embedded)', () => {
    const icoPath = path.join(PUBLIC_DIR, 'favicon.ico');
    expect(fs.existsSync(icoPath)).toBe(true);
    const buf = fs.readFileSync(icoPath);

    expect(buf.length).toBeGreaterThan(100);
    // Reserved 0x0000
    expect(buf.readUInt16LE(0)).toBe(0);
    // Type 1 (ICO)
    expect(buf.readUInt16LE(2)).toBe(1);
    // Count of images = 2
    const count = buf.readUInt16LE(4);
    expect(count).toBe(2);

    // Entry 1: 32x32
    expect(buf.readUInt8(6)).toBe(32);
    expect(buf.readUInt8(7)).toBe(32);

    // Entry 2: 16x16
    expect(buf.readUInt8(22)).toBe(16);
    expect(buf.readUInt8(23)).toBe(16);
  });

  it('Validates dimensions and RGBA color format of all raster icon assets', async () => {
    const expectedAssets = [
      { file: 'favicon.png', width: 32, height: 32 },
      { file: 'favicon-32x32.png', width: 32, height: 32 },
      { file: 'favicon-16x16.png', width: 16, height: 16 },
      { file: 'apple-touch-icon.png', width: 180, height: 180 },
      { file: 'icon-192.png', width: 192, height: 192 },
      { file: 'icon-512.png', width: 512, height: 512 },
      { file: 'icon-192-maskable.png', width: 192, height: 192 },
      { file: 'icon-512-maskable.png', width: 512, height: 512 },
      { file: 'logo.png', width: 512, height: 512 },
    ];

    for (const asset of expectedAssets) {
      const filePath = path.join(PUBLIC_DIR, asset.file);
      expect(fs.existsSync(filePath)).toBe(true);

      const metadata = await sharp(filePath).metadata();
      expect(metadata.format).toBe('png');
      expect(metadata.width).toBe(asset.width);
      expect(metadata.height).toBe(asset.height);
      expect(metadata.channels).toBeGreaterThanOrEqual(3);
    }
  });

  it('Verifies safe zone padding on maskable icons (padded with background #0f172a)', async () => {
    const maskable512 = path.join(PUBLIC_DIR, 'icon-512-maskable.png');
    const { data, info } = await sharp(maskable512)
      .raw()
      .toBuffer({ resolveWithObject: true });

    // Check top-left corner pixel (0, 0) is background slate #0f172a (r=15, g=23, b=42)
    const r = data[0];
    const g = data[1];
    const b = data[2];

    expect(r).toBe(15);
    expect(g).toBe(23);
    expect(b).toBe(42);
  });
});

describe('M3.6 — Global ProNotes Branding Consistency', () => {
  it('Sidebar header includes ProNotes logo and brand title', () => {
    const sidebarContent = fs.readFileSync(path.join(ROOT_DIR, 'src/components/whiteboard/Sidebar.tsx'), 'utf-8');
    expect(sidebarContent).toContain('src="/favicon.png"');
    expect(sidebarContent).toContain('alt="ProNotes Logo"');
    expect(sidebarContent).toContain('>ProNotes</h2>');
  });

  it('Tutorial modal welcomes user to ProNotes', () => {
    const tutContent = fs.readFileSync(path.join(ROOT_DIR, 'src/components/whiteboard/TutorialModal.tsx'), 'utf-8');
    expect(tutContent).toContain('Welcome to ProNotes');
    expect(tutContent).toContain('ProNotes is an infinite canvas');
  });

  it('package.json sets package name to "pronotes"', () => {
    const pkg = JSON.parse(fs.readFileSync(path.join(ROOT_DIR, 'package.json'), 'utf-8'));
    expect(pkg.name).toBe('pronotes');
  });

  it('README.md document has ProNotes as headline title', () => {
    const readmeContent = fs.readFileSync(path.join(ROOT_DIR, 'README.md'), 'utf-8');
    // Split on \r?\n: a Windows checkout (core.autocrlf=true) ends lines with
    // CRLF, which left a trailing \r on the title and failed in a fresh worktree.
    expect(readmeContent.split(/\r?\n/)[0]).toBe('# ProNotes');
  });
});

describe('M3.7 — Stress Tests, Fault Injection & Edge Cases', () => {
  it('SW Navigation Fault: Handles offline deep routes with query parameters gracefully', async () => {
    const env = createSwEnvironment();
    const cache = await env.caches.open(SW_CACHE);
    await cache.put('/', new MockResponse('<!DOCTYPE html><html>Offline Fallback Root</html>', { status: 200 }));

    env.runInSw(async () => {
      throw new Error('Network Connection Refused');
    });

    const fetchListeners = env.listeners.get('fetch') || [];
    const queryNavReq = new MockRequest('http://localhost:3000/board/matrix-123?action=new&theme=dark', {
      method: 'GET',
      mode: 'navigate'
    });

    const fetchEvent = new MockFetchEvent(queryNavReq);
    fetchListeners[0](fetchEvent);

    expect(fetchEvent.responded).toBe(true);
    const res = await fetchEvent.getResponse();
    expect(res).toBeDefined();
    expect(await res.text()).toBe('<!DOCTYPE html><html>Offline Fallback Root</html>');
  });

  it('SW Resilience: HTTP 500 server errors are NOT cached into STATIC cache', async () => {
    const env = createSwEnvironment();
    env.runInSw(async (req) => {
      return new MockResponse('Internal Server Error', { status: 500 });
    });

    const fetchListeners = env.listeners.get('fetch') || [];
    const assetReq = new MockRequest('http://localhost:3000/dynamic-chunk.js', { method: 'GET' });
    const fetchEvent = new MockFetchEvent(assetReq);
    fetchListeners[0](fetchEvent);

    expect(fetchEvent.responded).toBe(true);
    const res = await fetchEvent.getResponse();
    expect(res.status).toBe(500);

    const cache = await env.caches.open(SW_CACHE);
    const cachedItem = await cache.match(assetReq);
    expect(cachedItem).toBeUndefined();
  });

  it('SW Resilience: SWR background network failure does not disrupt cached delivery', async () => {
    const env = createSwEnvironment();
    const cache = await env.caches.open(SW_CACHE);
    const assetUrl = 'http://localhost:3000/app.css';
    await cache.put(assetUrl, new MockResponse('body { color: #fff; }', { status: 200 }));

    // Simulate network error during background revalidate
    env.runInSw(async () => {
      throw new Error('Network Timeout during SWR');
    });

    const fetchListeners = env.listeners.get('fetch') || [];
    const req = new MockRequest(assetUrl, { method: 'GET' });
    const fetchEvent = new MockFetchEvent(req);
    fetchListeners[0](fetchEvent);

    expect(fetchEvent.responded).toBe(true);
    const res = await fetchEvent.getResponse();
    expect(await res.text()).toBe('body { color: #fff; }');

    // Wait microtask
    await new Promise((r) => setTimeout(r, 15));
    // Cache remains intact
    const intact = await cache.match(assetUrl);
    expect(await intact.text()).toBe('body { color: #fff; }');
  });

  it('Icon Pipeline Idempotence: Running generate-icons.js regenerates identical valid assets', () => {
    const scriptPath = path.join(ROOT_DIR, 'scripts/generate-icons.js');
    expect(fs.existsSync(scriptPath)).toBe(true);

    const out = execSync(`node "${scriptPath}"`, {
      cwd: ROOT_DIR,
      env: { ...process.env, PATH: `C:\\Program Files\\nodejs;${process.env.PATH}` }
    }).toString();

    expect(out).toContain('All brand assets successfully generated!');
  });
});

// ============================================================================
// RUNNER
// ============================================================================

async function runTests() {
  console.log('\n================================================================');
  console.log('  M3 EMPIRICAL CHALLENGER TEST SUITE: Branding & PWA Integration');
  console.log('================================================================\n');

  let passedSuites = 0;
  let failedSuites = 0;
  let totalTests = 0;
  let passedTests = 0;
  let failedTests = 0;

  for (const suite of ctx.suites) {
    console.log(`\n• [SUITE] ${suite.name}`);
    let suiteFailed = false;

    for (const test of suite.tests) {
      totalTests++;
      ctx.currentTest = test;

      // Run beforeEach hooks
      for (const beforeFn of suite.beforeEachFns) {
        await beforeFn();
      }

      const start = Date.now();
      try {
        await test.fn();
        test.passed = true;
        test.durationMs = Date.now() - start;
        passedTests++;
        console.log(`   ✓ ${test.name} (${test.durationMs}ms)`);
      } catch (err) {
        test.passed = false;
        test.error = err;
        test.durationMs = Date.now() - start;
        failedTests++;
        suiteFailed = true;
        console.error(`   ✗ ${test.name} (${test.durationMs}ms)`);
        console.error(`     Error: ${err.message}`);
      }

      // Run afterEach hooks
      for (const afterFn of suite.afterEachFns) {
        await afterFn();
      }
    }

    if (suiteFailed) {
      failedSuites++;
    } else {
      passedSuites++;
    }
  }

  console.log('\n================================================================');
  console.log('  TEST EXECUTION SUMMARY');
  console.log('================================================================');
  console.log(`  Suites:     ${passedSuites} passed, ${failedSuites} failed, ${ctx.suites.length} total`);
  console.log(`  Tests:      ${passedTests} passed, ${failedTests} failed, ${totalTests} total`);
  console.log(`  Assertions: ${ctx.passedAssertions} passed, ${ctx.failedAssertions} failed, ${ctx.totalAssertions} total`);
  console.log('================================================================\n');

  if (failedTests > 0) {
    process.exit(1);
  }
}

runTests().catch((err) => {
  console.error('Fatal Runner Error:', err);
  process.exit(1);
});
