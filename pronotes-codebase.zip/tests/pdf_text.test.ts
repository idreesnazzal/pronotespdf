/**
 * Selectable, searchable text of PDF / Word / PowerPoint pages - the parts that
 * must hold without a browser.
 * - Reading order: lines kept in document order (two columns never interleave),
 *   runs of a Hebrew line read right to left with Latin/numbers kept LTR,
 *   glyph-per-item and whole-string visual-order Hebrew turned back.
 * - Hit testing, word / range geometry, the strokes a highlight makes.
 * - Search folding (case, accents, niqqud, harakat, presentation forms) and
 *   snippets whose match index is right.
 * - pdf.js items -> boxes; PowerPoint letter-by-letter drawing glued back.
 */

import assert from "node:assert/strict";
import {
  caretAt,
  dirOf,
  findAll,
  foldForSearch,
  groupLines,
  layoutPage,
  lineSegments,
  looksVisualOrder,
  markStrokes,
  mergeFragments,
  offsetAt,
  pageBoxOnSheet,
  rangeRects,
  runsFromPdfItems,
  selectedText,
  snippetAround,
  visualToLogical,
  wordRangeAt,
  type TextRun,
} from "../src/lib/whiteboard/pdfText";
import {
  mergeFragments as mergeFragmentsX,
  orderLine as orderLineX,
  queryTerms as queryTermsX,
  visualToLogical as visualToLogicalX,
} from "../src/lib/whiteboard/pdfText";
import { PEN_TYPE_PRESETS } from "../src/lib/whiteboard/types";

const NL = String.fromCharCode(10);
let passed = 0;
let failed = 0;
function test(name: string, fn: () => void) {
  try {
    fn();
    passed++;
    console.log(`  ✓ ${name}`);
  } catch (err) {
    failed++;
    console.error(`  ✗ ${name}`);
    console.error(`      ${(err as Error).message}`);
  }
}

const run = (t: string, x: number, y: number, w: number, h = 0.02): TextRun => ({ t, x, y, w, h });
const page = (runs: TextRun[]) => ({ w: 1, h: 1, runs });
const near = (a: number, b: number, eps = 1e-6) => assert.ok(Math.abs(a - b) < eps, `${a} != ${b}`);

console.log(NL + "── PDF / Office page text ──");

test("direction of a run: Hebrew, Arabic, Latin, digits, punctuation", () => {
  assert.equal(dirOf("שלום"), "r");
  assert.equal(dirOf("مرحبا"), "r");
  assert.equal(dirOf("hello"), "l");
  assert.equal(dirOf("2024"), "l");
  assert.equal(dirOf("—:"), "n");
});

test("words on one line join with a space; touching pieces of a word do not", () => {
  const l = layoutPage(page([run("Hel", 0.1, 0.1, 0.03), run("lo", 0.13, 0.1, 0.02), run("world", 0.17, 0.1, 0.05)]));
  assert.equal(l.text, "Hello world");
});

test("two columns keep document order: the left column is not interleaved with the right", () => {
  const runs = [
    run("left1", 0.1, 0.1, 0.2),
    run("left2", 0.1, 0.13, 0.2),
    run("right1", 0.6, 0.1, 0.2),
    run("right2", 0.6, 0.13, 0.2),
  ];
  assert.equal(groupLines(runs).length, 4);
  assert.equal(layoutPage(page(runs)).text, ["left1", "left2", "right1", "right2"].join(NL));
});

test("Hebrew stored one glyph per item, left to right, reads right to left", () => {
  // שלום drawn as ם ו ל ש from left to right, which is how it looks.
  const glyphs = ["ם", "ו", "ל", "ש"].map((g, i) => run(g, 0.5 + i * 0.01, 0.2, 0.01));
  assert.equal(layoutPage(page(glyphs)).text, "שלום");
});

test("a Hebrew line with English words and a number reads in the right order", () => {
  // Reading order: "ראה את Figure 3 בעמוד"; on screen (left to right): בעמוד | Figure 3 | את ראה
  const runs = [run("בעמוד", 0.1, 0.3, 0.08), run("Figure", 0.2, 0.3, 0.08), run("3", 0.29, 0.3, 0.01), run("את", 0.32, 0.3, 0.04), run("ראה", 0.38, 0.3, 0.05)];
  assert.equal(layoutPage(page(runs)).text, "ראה את Figure 3 בעמוד");
});

test("Office text keeps the order it was written in, whatever the renderer's word positions", () => {
  // The slide renderer placed Hebrew words left to right in reading order.
  const runs = [run("קיפאון", 0.05, 0.1, 0.1), run("-", 0.16, 0.1, 0.01), run("תנאים", 0.2, 0.1, 0.1)];
  assert.equal(layoutPage({ w: 1, h: 1, runs, ordered: true }).text, "קיפאון - תנאים");
  assert.equal(layoutPage(page(runs)).text, "תנאים - קיפאון");
});

test("a number ending a Hebrew sentence keeps its full stop after it", () => {
  // Drawn ". 12 עמוד ראו"; pdf.js hands the number over as ".12".
  const runs = [run(".12", 0.1, 0.4, 0.03), run("עמוד", 0.14, 0.4, 0.05), run("ראו", 0.2, 0.4, 0.04)];
  assert.equal(layoutPage(page(runs)).text, "ראו עמוד 12.");
});

test("Arabic presentation forms read (and copy) as plain letters", () => {
  const l = layoutPage(page([run("\uFEDF\uFEDC\uFEDE", 0.1, 0.1, 0.05)]));
  assert.equal(l.text, "لكل");
  assert.equal(findAll(l.text, "لكل").length, 1);
});

test("visual-order strings are turned back, numbers keep their order", () => {
  assert.equal(visualToLogical("12 םולש"), "שלום 12");
  assert.equal(visualToLogical("3.14 = יפ"), "פי = 3.14");
  assert.equal(looksVisualOrder("םולש םלוע ךלמ"), true);
  assert.equal(looksVisualOrder("שלום עולם מלך"), false);
  // A page of reversed words is repaired on layout.
  const l = layoutPage(page([run("םלוע", 0.1, 0.1, 0.1), run("םולש", 0.25, 0.1, 0.1)]));
  assert.equal(l.text, "שלום עולם");
});

test("hit testing: left-to-right from the left edge, right-to-left from the right edge", () => {
  const l = layoutPage(page([run("abcd", 0.1, 0.1, 0.4), run("אבגד", 0.1, 0.3, 0.4)]));
  assert.equal(offsetAt(l, 0.11, 0.11), 0);
  assert.equal(offsetAt(l, 0.49, 0.11), 4);
  const heb = l.runs[1].start;
  assert.equal(offsetAt(l, 0.49, 0.31), heb); // right edge = the first letter
  assert.equal(offsetAt(l, 0.11, 0.31), heb + 4);
  // Beside a line lands on that line, not on the nearest one diagonally.
  assert.equal(offsetAt(l, 0.9, 0.105), 4);
});

test("a range's boxes follow the text direction", () => {
  const l = layoutPage(page([run("abcd", 0.1, 0.1, 0.4), run("אבגד", 0.1, 0.3, 0.4)]));
  const [ltr] = rangeRects(l, 1, 3);
  near(ltr.x, 0.2);
  near(ltr.w, 0.2);
  const s = l.runs[1].start;
  const [rtl] = rangeRects(l, s, s + 1); // first Hebrew letter = rightmost quarter
  near(rtl.x, 0.4);
  near(rtl.w, 0.1);
  const c = caretAt(l, s, "start");
  near(c!.x, 0.5);
});

test("double tap picks the word; selected text drops invisible marks", () => {
  const text = "hello, world";
  assert.deepEqual(wordRangeAt(text, 2), [0, 5]);
  assert.deepEqual(wordRangeAt(text, 5), [0, 5]); // just after the word
  assert.deepEqual(wordRangeAt(text, 9), [7, 12]);
  assert.deepEqual(wordRangeAt("שלום עולם", 6), [5, 9]);
  const l = layoutPage(page([run("a\u200Fb", 0.1, 0.1, 0.1)]));
  assert.equal(selectedText(l, 0, 3), "ab");
});

test("line segments: pieces of a line merge, separate lines stay apart", () => {
  const segs = lineSegments([
    { x: 0.1, y: 0.1, w: 0.1, h: 0.02, line: 0 },
    { x: 0.205, y: 0.1, w: 0.1, h: 0.02, line: 0 },
    { x: 0.1, y: 0.2, w: 0.1, h: 0.02, line: 1 },
  ]);
  assert.equal(segs.length, 2);
  near(segs[0].w, 0.205);
});

test("highlight strokes are as tall as the line and exactly as long as the text", () => {
  const [hl] = markStrokes("highlight", [{ x: 100, y: 200, w: 150, h: 18 }], { fill: "#fde047", ink: "#ca8a04" }, () => "id");
  assert.equal(hl.strokeStyle, "highlighter");
  near(hl.strokeWidth * (PEN_TYPE_PRESETS.highlighter.sizeScale ?? 1), 18);
  assert.equal(hl.x, 100);
  assert.equal(hl.y, 209);
  assert.equal(hl.points[hl.points.length - 1][0], 150);
  assert.equal(hl.color, "#fde047");
  const [ul] = markStrokes("underline", [{ x: 0, y: 0, w: 50, h: 20 }], { fill: "#fde047", ink: "#ca8a04" }, () => "u");
  assert.equal(ul.strokeStyle, "fineliner");
  assert.equal(ul.color, "#ca8a04");
  assert.ok(ul.y > 15 && ul.y < 20);
  const [st] = markStrokes("strike", [{ x: 0, y: 0, w: 50, h: 20 }], { fill: "#fde047", ink: "#ca8a04" }, () => "s");
  assert.ok(st.y > 8 && st.y < 14);
});

test("search ignores case, accents, niqqud, harakat and Arabic letter forms", () => {
  assert.deepEqual(findAll("Café au lait", "CAFE"), [[0, 4]]);
  assert.deepEqual(findAll("ש\u05B8\u05C1לו\u05B9ם עולם", "שלום"), [[0, 7]]);
  assert.equal(findAll("م\u064Fح\u064Eم\u064E\u0651د", "محمد").length, 1);
  assert.equal(findAll("\uFEE3\uFEA4\uFEE4\uFEAA", "محمد").length, 1); // presentation forms
  assert.equal(findAll("أحمد", "احمد").length, 1); // alef with hamza
  assert.equal(findAll("hello" + NL + "world", "hello world").length, 1);
  assert.equal(findAll("عملیة أنھا", "عملية أنها").length, 1); // Persian yeh / heh look-alikes

  assert.equal(findAll("aaa", "").length, 0);
  const folded = foldForSearch("A\u00ADb").folded;
  assert.equal(folded, "ab");
});

test("a snippet is about 80 characters and its match index points at the match", () => {
  const text = "x ".repeat(100) + "needle" + " y".repeat(100);
  const [[s, e]] = findAll(text, "NEEDLE");
  const sn = snippetAround(text, s, e);
  assert.equal(sn.snippet.slice(sn.matchStart, sn.matchStart + sn.matchLength), "needle");
  assert.ok(sn.snippet.length <= 84, `length ${sn.snippet.length}`);
  const short = snippetAround("find me", 5, 7);
  assert.equal(short.snippet, "find me");
  assert.equal(short.matchStart, 5);
});

test("pdf.js items become page-fraction boxes above their baseline", () => {
  // A 612 x 792 pt page; pdf.js's scale-1 viewport flips y.
  const vp = { transform: [1, 0, 0, -1, 0, 792], width: 612, height: 792 };
  const [r] = runsFromPdfItems(
    [{ str: "Hello", transform: [12, 0, 0, 12, 72, 700], width: 30, fontName: "f1" }, { str: " ", transform: [12, 0, 0, 12, 102, 700], width: 3 }],
    { f1: { ascent: 0.8, descent: -0.2 } },
    vp
  );
  near(r.x, 72 / 612);
  near(r.w, 30 / 612);
  near(r.y, (92 - 9.6) / 792);
  near(r.h, 12 / 792);
});

test("PowerPoint letters drawn one by one are glued back; a repeat is dropped", () => {
  const frags = ["H", "e", "y"].map((c, i) => run(c, 0.1 + i * 0.01, 0.1, 0.01));
  frags.push(run("H", 0.1, 0.1, 0.01)); // drawn twice
  frags.push(run("next", 0.1, 0.2, 0.04));
  const merged = mergeFragments(frags);
  assert.deepEqual(merged.map((m) => m.t), ["Hey", "next"]);
  near(merged[0].w, 0.03);
});

test("a page letterboxed onto a sheet of another shape is centred", () => {
  const b = pageBoxOnSheet({ w: 200, h: 100 }, 400, 400);
  assert.deepEqual(b, { x: 0, y: 100, w: 400, h: 200 });
});

// ── Found in review ──
{
  const words = (xs: Array<[string, number]>) => xs.map(([t, x]) => ({ t, x, y: 0, w: t.length * 0.01, h: 0.02 }));
  const read = (runs: ReturnType<typeof words>) => orderLineX(runs).map((r) => r.t).join(" ");

  test("a Hebrew line with an English term reads from its first Hebrew word", () => {
    // Visual, left to right: עץ הוא Binary Search Tree :הגדרה (more Latin letters than Hebrew)
    const line = words([["עץ", 0.1], ["הוא", 0.14], ["Binary", 0.2], ["Search", 0.28], ["Tree", 0.36], ["הגדרה:", 0.44]]);
    assert.equal(read(line), "הגדרה: Binary Search Tree הוא עץ");
  });

  test("a Hebrew phrase inside an English line keeps its own order", () => {
    // Visual: The phrase עולם שלום means  (שלום is to the right of עולם)
    const line = words([["The", 0.1], ["phrase", 0.15], ["עולם", 0.25], ["שלום", 0.31], ["means", 0.4]]);
    assert.equal(read(line), "The phrase שלום עולם means");
  });

  test("slide words drawn one at a time stay separate words", () => {
    // pptx draws word by word and skips the spaces; a space's gap must not glue.
    const h = 0.02;
    const frags = ["This", "is", "a", "test", "of", "it"].reduce<Array<{ t: string; x: number; y: number; w: number; h: number }>>(
      (acc, t) => {
        const x = acc.length ? acc[acc.length - 1].x + acc[acc.length - 1].w + 0.25 * h : 0.1;
        acc.push({ t, x, y: 0.5, w: t.length * 0.5 * h, h });
        return acc;
      },
      []
    );
    const merged = mergeFragmentsX(frags);
    assert.ok(!merged.some((r) => /isa|testof|ofit/.test(r.t)), merged.map((r) => r.t).join("|"));
    // Letters drawn one by one, touching, are still glued.
    const letters = ["a", "b", "c"].map((t, i) => ({ t, x: 0.1 + i * 0.01, y: 0.5, w: 0.01, h }));
    assert.equal(mergeFragmentsX(letters).map((r) => r.t).join("|"), "abc");
  });

  test("brackets in visually stored Hebrew read the right way round", () => {
    // "עמוד (3)" stored in visual order as its logical characters: ")3( דומע"
    assert.equal(visualToLogicalX(")3( דומע"), "עמוד (3)");
  });

  test("search words: quotes dropped, each word once", () => {
    assert.deepEqual(queryTermsX('"exam" physics exam'), ["exam", "physics"]);
    assert.deepEqual(queryTermsX("   "), []);
  });
}

console.log(`  ${passed} passed, ${failed} failed`);
if (failed > 0) process.exit(1);
