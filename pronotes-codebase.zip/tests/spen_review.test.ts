/**
 * Regressions from the S Pen review:
 * - Pressure is calibrated once, when captured - never again when drawn, so
 *   strokes already in a notebook look exactly as they did when written.
 * - The default pressure setting is neutral: new strokes match older ones.
 */

import assert from "node:assert/strict";
import { applyPenDynamics, buildStrokePath, calibratePressure } from "../src/lib/whiteboard/stroke";
import { DEFAULT_TOUCH_SETTINGS, PEN_TYPES, penFeelFor, penUsesPressure, type StrokeElement, type StrokeStyle } from "../src/lib/whiteboard/types";

let passed = 0;
let failed = 0;
function test(name: string, fn: () => void) {
  try {
    fn();
    passed++;
    console.log(`  ✓ ${name}`);
  } catch (err) {
    failed++;
    console.error(`  ✗ ${name}`);
    console.error(`      ${(err as Error).message}`);
  }
}

console.log(String.fromCharCode(10) + "── S Pen review ──");

/** A stroke as an older build saved it: raw pressure, no smoothing field. */
function oldStroke(style: StrokeStyle): StrokeElement {
  const points: Array<[number, number, number]> = [];
  for (let i = 0; i < 40; i++) points.push([i * 3, Math.sin(i / 4) * 12, 0.15 + (i % 10) * 0.08]);
  return {
    id: "old",
    type: "stroke",
    x: 0,
    y: 0,
    rotation: 0,
    opacity: 1,
    createdAt: 0,
    updatedAt: 0,
    points,
    color: "#000",
    strokeWidth: 6,
    strokeStyle: style,
  } as StrokeElement;
}

test("drawing a stroke leaves its stored pressure alone (no second calibration)", () => {
  const pts: Array<[number, number, number]> = [
    [0, 0, 0.2],
    [0.5, 0, 0.8],
    [1, 0, 0.35],
  ];
  // Fineliner has no speed or nib dynamics: every pressure must pass through.
  assert.deepEqual(applyPenDynamics(pts, "fineliner"), pts);
  // Gel only thins with speed; at a crawl the pressure is essentially kept.
  const gel = applyPenDynamics(pts, "gel");
  gel.forEach((p, i) => assert.ok(Math.abs(p[2] - pts[i][2]) < 0.01, `gel point ${i}: ${p[2]} vs ${pts[i][2]}`));
});

test("strokes written before the pressure settings existed render unchanged", () => {
  // The same stroke drawn with the default smoothing must give the same path
  // whether or not the element carries the new field.
  for (const st of PEN_TYPES) {
    const a = buildStrokePath(oldStroke(st));
    const b = buildStrokePath({ ...oldStroke(st), smoothing: 50 });
    assert.equal(a, b, `${st} changed`);
  }
});

test("the default pressure setting is neutral: the curve exactly, no widening", () => {
  assert.equal(DEFAULT_TOUCH_SETTINGS.penPressureSensitivity, 50);
  assert.equal(DEFAULT_TOUCH_SETTINGS.penPressureCurve, "standard");
  for (const p of [0.05, 0.2, 0.5, 0.73, 0.95]) {
    const out = calibratePressure(p, DEFAULT_TOUCH_SETTINGS.penPressureSensitivity, DEFAULT_TOUCH_SETTINGS.penPressureCurve);
    assert.ok(Math.abs(out - p) < 1e-9, `default setting moved ${p} to ${out}`);
  }
});

test("pressure curves still shape the response in the right direction", () => {
  const soft = calibratePressure(0.3, 50, "soft");
  const firm = calibratePressure(0.3, 50, "firm");
  assert.ok(soft > 0.3 && firm < 0.3, `soft ${soft}, firm ${firm}`);
  assert.equal(calibratePressure(0.9, 50, "off"), 0.5);
});

test("the picker offers six pens that look different; old pens still draw", () => {
  assert.deepEqual(PEN_TYPES, ["gel", "fountain", "brush", "pencil", "marker", "highlighter"]);
  for (const legacy of ["ballpoint", "fineliner"] as StrokeStyle[]) {
    assert.ok(buildStrokePath(oldStroke(legacy)).length > 0, `${legacy} strokes must still render`);
  }
});

test("pressure settings are offered only to pens that react to pressure", () => {
  assert.equal(penUsesPressure("gel"), true);
  assert.equal(penUsesPressure("fountain"), true);
  assert.equal(penUsesPressure("pencil"), true);
  assert.equal(penUsesPressure("brush"), false, "brush width comes from speed");
  assert.equal(penUsesPressure("marker"), false);
  assert.equal(penUsesPressure("highlighter"), false);
});

test("each pen keeps its own feel; untuned pens use the shared one", () => {
  const ts = {
    ...DEFAULT_TOUCH_SETTINGS,
    penSmoothing: 40,
    penFeel: { fountain: { curve: "firm" as const, smoothing: 80 } },
  };
  assert.deepEqual(penFeelFor(ts, "fountain"), { curve: "firm", smoothing: 80, sensitivity: 50 });
  assert.deepEqual(penFeelFor(ts, "gel"), { curve: "standard", smoothing: 40, sensitivity: 50 });
});

console.log(`  ${passed} passed, ${failed} failed`);
if (failed > 0) process.exit(1);
