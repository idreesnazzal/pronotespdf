import assert from "node:assert/strict";
import {
  isPointInPolygon,
  isElementInPolygon,
  getElementBounds,
  getElementCenter,
  getUnionBounds,
  getNodeAnchorPorts,
  getResolvedAnchorPoint,
  getOptimalConnectionAnchors,
  getConnectionPath,
  getArrowheadPath,
  worldToScreen,
  screenToWorld,
  rotatePoint,
  clamp,
  lerp,
  alignElements,
  distributeElements,
  isVisibleInViewport,
  getResizeHandles,
  hitTestElement,
  HIT_THRESHOLD,
} from "../src/lib/whiteboard/geometry";
import { GRID_SIZE, snapToGrid, snapPointToGrid } from "../src/lib/whiteboard/grid";
import { exportBoardToSvg } from "../src/lib/whiteboard/export";
import type {
  Board,
  WhiteboardElement,
  StrokeElement,
  RectangleElement,
  EllipseElement,
  DiamondElement,
  TriangleElement,
  StarElement,
  CloudElement,
  LineElement,
  ArrowElement,
  ConnectionElement,
  TextElement,
  StickyElement,
  ImageElement,
} from "../src/lib/whiteboard/types";

console.log("================================================================================");
console.log("=== EMPIRICAL CHALLENGER 1: COMPREHENSIVE ADVERSARIAL STRESS SUITE           ===");
console.log("================================================================================");

let totalAssertions = 0;
function pass(msg: string) {
  totalAssertions++;
  console.log(`  ✓ ${msg}`);
}

// ============================================================================
// AREA 1: MATHEMATICAL PRECISION OF isPointInPolygon AND isElementInPolygon
// ============================================================================
console.log("\n--- [Area 1] Precision of isPointInPolygon & isElementInPolygon ---");

// 1.1 Concave Geometries (U-shape / Horseshoe with inner bay)
const uShapePolygon = [
  { x: 0, y: 0 },
  { x: 100, y: 0 },
  { x: 100, y: 100 },
  { x: 70, y: 100 },
  { x: 70, y: 30 },
  { x: 30, y: 30 },
  { x: 30, y: 100 },
  { x: 0, y: 100 },
];
// Points inside the solid arms
assert.equal(isPointInPolygon(15, 50, uShapePolygon), true, "Left vertical arm of U");
assert.equal(isPointInPolygon(85, 50, uShapePolygon), true, "Right vertical arm of U");
assert.equal(isPointInPolygon(50, 15, uShapePolygon), true, "Top horizontal bridge of U");

// Points in the hollow bay / cavity (within bounding box [0,0,100,100] but OUTSIDE polygon)
assert.equal(isPointInPolygon(50, 60, uShapePolygon), false, "Cavity inside U must be outside polygon");
assert.equal(isPointInPolygon(50, 90, uShapePolygon), false, "Deep cavity opening of U must be outside");
assert.equal(isPointInPolygon(-10, 50, uShapePolygon), false, "Far exterior point");
pass("Concave U-shape / cavity point containment verified");

// 1.2 Star Non-Convex Polygon (10 vertices)
const star5Polygon = [
  { x: 50, y: 0 },
  { x: 62, y: 35 },
  { x: 100, y: 35 },
  { x: 69, y: 57 },
  { x: 81, y: 95 },
  { x: 50, y: 72 },
  { x: 19, y: 95 },
  { x: 31, y: 57 },
  { x: 0, y: 35 },
  { x: 38, y: 35 },
];
// Star center is inside
assert.equal(isPointInPolygon(50, 50, star5Polygon), true, "Star center is inside");
// Star tips are inside
assert.equal(isPointInPolygon(50, 5, star5Polygon), true, "Near top tip is inside");
// Outer notches between tips (inside bounding box [0,0,100,95] but outside star body)
assert.equal(isPointInPolygon(10, 10, star5Polygon), false, "Top-left notch outside star");
assert.equal(isPointInPolygon(90, 10, star5Polygon), false, "Top-right notch outside star");
assert.equal(isPointInPolygon(50, 90, star5Polygon), false, "Bottom notch outside star");
pass("10-vertex non-convex Star polygon point containment verified");

// 1.3 Self-Intersecting / Bow-tie / Figure-8 Polygon (Even-Odd Rule)
const bowTiePolygon = [
  { x: 0, y: 0 },
  { x: 100, y: 100 },
  { x: 100, y: 0 },
  { x: 0, y: 100 },
];
// Left triangle (0,0)-(50,50)-(0,100): interior point (20, 50) -> IN
assert.equal(isPointInPolygon(20, 50, bowTiePolygon), true, "Left lobe of bow-tie polygon is inside");
// Right triangle (100,0)-(50,50)-(100,100): interior point (80, 50) -> IN
assert.equal(isPointInPolygon(80, 50, bowTiePolygon), true, "Right lobe of bow-tie polygon is inside");
// Top and bottom triangular cutouts (50, 10) and (50, 90) -> OUT (ray intersects 2 edges, even -> outside)
assert.equal(isPointInPolygon(50, 10, bowTiePolygon), false, "Top waist of bow-tie is outside (even-odd rule)");
assert.equal(isPointInPolygon(50, 90, bowTiePolygon), false, "Bottom waist of bow-tie is outside (even-odd rule)");
pass("Bow-tie / self-intersecting figure-8 polygon verified under Even-Odd rule");

// 1.4 Colinear Vertices and Horizontal/Vertical Segments
const colinearPolygon = [
  { x: 0, y: 0 },
  { x: 50, y: 0 }, // colinear with (0,0) and (100,0)
  { x: 100, y: 0 },
  { x: 100, y: 50 }, // colinear with (100,0) and (100,100)
  { x: 100, y: 100 },
  { x: 0, y: 100 },
];
assert.equal(isPointInPolygon(50, 50, colinearPolygon), true, "Center of colinear polygon is inside");
assert.equal(isPointInPolygon(50, -5, colinearPolygon), false, "Point just above colinear top edge is outside");
assert.equal(isPointInPolygon(105, 50, colinearPolygon), false, "Point just right of colinear right edge is outside");
pass("Colinear segment polygon verified");

// 1.5 Degenerate Polygon Inputs
assert.equal(isPointInPolygon(50, 50, []), false, "Empty polygon returns false");
assert.equal(isPointInPolygon(50, 50, [{ x: 10, y: 10 }]), false, "1-point polygon returns false");
assert.equal(isPointInPolygon(50, 50, [{ x: 10, y: 10 }, { x: 20, y: 20 }]), false, "2-point polygon returns false");
pass("Degenerate polygon edge cases return false safely without exception");

// 1.6 Massive 1,000-vertex polygon performance and precision test
const circlePointsCount = 1000;
const circlePoly: Array<{ x: number; y: number }> = [];
for (let i = 0; i < circlePointsCount; i++) {
  const theta = (i / circlePointsCount) * 2 * Math.PI;
  circlePoly.push({ x: 500 + 300 * Math.cos(theta), y: 500 + 300 * Math.sin(theta) });
}
const startTimer = performance.now();
for (let iter = 0; iter < 100; iter++) {
  assert.equal(isPointInPolygon(500, 500, circlePoly), true, "Center inside 1000-gon");
  assert.equal(isPointInPolygon(500, 790, circlePoly), true, "Near perimeter inside 1000-gon");
  assert.equal(isPointInPolygon(500, 810, circlePoly), false, "Outside 1000-gon perimeter");
  assert.equal(isPointInPolygon(0, 0, circlePoly), false, "Far outside 1000-gon");
}
const elapsedMs = performance.now() - startTimer;
assert.ok(elapsedMs < 100, `1000-gon 100 iterations took ${elapsedMs.toFixed(2)}ms (should be < 100ms)`);
pass(`1,000-vertex high-density polygon precision and performance verified (${elapsedMs.toFixed(2)}ms for 400 tests)`);

// 1.7 Element Containment across all element types with isElementInPolygon
const lassoRectPoly = [
  { x: 100, y: 100 },
  { x: 300, y: 100 },
  { x: 300, y: 300 },
  { x: 100, y: 300 },
];

const testElements: WhiteboardElement[] = [
  {
    id: "el-stroke",
    type: "stroke",
    x: 120,
    y: 120,
    rotation: 0,
    opacity: 1,
    points: [[0, 0, 0.5], [10, 10, 0.5]],
    color: "#000",
    strokeWidth: 2,
    strokeStyle: "pen",
    createdAt: 1,
    updatedAt: 1,
  },
  {
    id: "el-rect",
    type: "rectangle",
    x: 150,
    y: 150,
    width: 40,
    height: 40,
    rotation: 0,
    opacity: 1,
    strokeColor: "#000",
    fillColor: "#fff",
    fillStyle: "solid",
    dashStyle: "solid",
    strokeWidth: 2,
    createdAt: 1,
    updatedAt: 1,
  },
  {
    id: "el-ellipse",
    type: "ellipse",
    x: 200,
    y: 150,
    width: 40,
    height: 40,
    rotation: 0,
    opacity: 1,
    strokeColor: "#000",
    fillColor: "transparent",
    fillStyle: "transparent",
    dashStyle: "solid",
    strokeWidth: 2,
    createdAt: 1,
    updatedAt: 1,
  },
  {
    id: "el-diamond",
    type: "diamond",
    x: 150,
    y: 200,
    width: 40,
    height: 40,
    rotation: 0,
    opacity: 1,
    strokeColor: "#000",
    fillColor: "transparent",
    fillStyle: "transparent",
    dashStyle: "solid",
    strokeWidth: 2,
    createdAt: 1,
    updatedAt: 1,
  },
  {
    id: "el-line",
    type: "line",
    x: 120,
    y: 220,
    x2: 60,
    y2: 40,
    rotation: 0,
    opacity: 1,
    strokeColor: "#000",
    dashStyle: "solid",
    strokeWidth: 2,
    createdAt: 1,
    updatedAt: 1,
  },
  {
    id: "el-arrow",
    type: "arrow",
    x: 180,
    y: 220,
    x2: 50,
    y2: -30,
    startArrowhead: "none",
    endArrowhead: "arrow",
    arrowheadSize: 12,
    rotation: 0,
    opacity: 1,
    strokeColor: "#000",
    dashStyle: "solid",
    strokeWidth: 2,
    createdAt: 1,
    updatedAt: 1,
  },
  {
    id: "el-text",
    type: "text",
    x: 150,
    y: 260,
    width: 100,
    height: 30,
    rotation: 0,
    opacity: 1,
    text: "Hello",
    color: "#000",
    fontSize: 16,
    fontFamily: "Inter",
    fontWeight: 400,
    align: "left",
    createdAt: 1,
    updatedAt: 1,
  },
  {
    id: "el-sticky",
    type: "sticky",
    x: 140,
    y: 130,
    width: 60,
    height: 60,
    rotation: 0,
    opacity: 1,
    text: "Note",
    color: "yellow",
    fontSize: 14,
    align: "center",
    createdAt: 1,
    updatedAt: 1,
  },
  {
    id: "el-image",
    type: "image",
    x: 160,
    y: 160,
    width: 50,
    height: 50,
    naturalWidth: 100,
    naturalHeight: 100,
    rotation: 0,
    opacity: 1,
    src: "data:image/png;base64,123",
    createdAt: 1,
    updatedAt: 1,
  },
];

for (const el of testElements) {
  assert.equal(isElementInPolygon(el, lassoRectPoly), true, `${el.type} inside polygon must be detected`);
  const shiftedOutside: WhiteboardElement = { ...el, x: el.x + 500, y: el.y + 500 };
  assert.equal(isElementInPolygon(shiftedOutside, lassoRectPoly), false, `${el.type} shifted outside polygon must return false`);
}
pass("All element types correctly detected by isElementInPolygon (inside vs outside)");

// 1.8 Element in the cavity of a concave polygon
// A small rectangle located at (45, 55) is inside the bounding box of uShapePolygon, but in the hollow space!
const rectInCavity: RectangleElement = {
  id: "rect-cavity",
  type: "rectangle",
  x: 45,
  y: 55,
  width: 10,
  height: 10,
  rotation: 0,
  opacity: 1,
  strokeColor: "#000",
  fillColor: "#fff",
  fillStyle: "solid",
  dashStyle: "solid",
  strokeWidth: 2,
  createdAt: 1,
  updatedAt: 1,
};
assert.equal(isElementInPolygon(rectInCavity, uShapePolygon), false, "Element strictly inside concave cavity must NOT be selected");
pass("Concave cavity containment precision: elements in open bay are NOT erroneously selected");


// ============================================================================
// AREA 2: LINE & ARROW RESIZING VECTOR MATH ACROSS EXTREME ASPECT RATIOS & NEGATIVE COORDINATES
// ============================================================================
console.log("\n--- [Area 2] Line & Arrow Resizing Vector Math ---");

// Helper function to simulate handle resizing on a Line/Arrow according to canvas resize logic
function simulateLineResize(
  el: LineElement | ArrowElement,
  handle: string,
  dx: number,
  dy: number
): { x: number; y: number; x2: number; y2: number } {
  const b = getElementBounds(el);
  const p1 = { x: el.x, y: el.y };
  const p2 = { x: el.x + el.x2, y: el.y + el.y2 };
  const oldW = Math.max(b.width, 1);
  const oldH = Math.max(b.height, 1);

  let newX = b.x;
  let newY = b.y;
  let newW = b.width;
  let newH = b.height;

  if (handle.includes("e")) newW = Math.max(b.width + dx, 10);
  if (handle.includes("s")) newH = Math.max(b.height + dy, 10);
  if (handle.includes("w")) {
    const potentialW = b.width - dx;
    if (potentialW >= 10) {
      newX = b.x + dx;
      newW = potentialW;
    }
  }
  if (handle.includes("n")) {
    const potentialH = b.height - dy;
    if (potentialH >= 10) {
      newY = b.y + dy;
      newH = potentialH;
    }
  }

  const u1 = (p1.x - b.x) / oldW;
  const v1 = (p1.y - b.y) / oldH;
  const u2 = (p2.x - b.x) / oldW;
  const v2 = (p2.y - b.y) / oldH;

  const newP1x = newX + u1 * newW;
  const newP1y = newY + v1 * newH;
  const newP2x = newX + u2 * newW;
  const newP2y = newY + v2 * newH;

  return {
    x: newP1x,
    y: newP1y,
    x2: newP2x - newP1x,
    y2: newP2y - newP1y,
  };
}

// 2.1 Arrow with negative direction (pointing up-left: x2 < 0, y2 < 0) at negative origin
const negArrow: ArrowElement = {
  id: "neg-arrow",
  type: "arrow",
  x: -100,
  y: -100,
  x2: -200,
  y2: -150,
  startArrowhead: "none",
  endArrowhead: "arrow",
  arrowheadSize: 12,
  rotation: 0,
  opacity: 1,
  strokeColor: "#000",
  dashStyle: "solid",
  strokeWidth: 2,
  createdAt: 1,
  updatedAt: 1,
};
const negBounds = getElementBounds(negArrow);
// minX = min(-100, -300) = -300, minY = min(-100, -250) = -250, maxX = -100, maxY = -100
assert.equal(negBounds.x, -300);
assert.equal(negBounds.y, -250);
assert.equal(negBounds.width, 200);
assert.equal(negBounds.height, 150);

// Resize handle 'w' on negative arrow: dragging dx = -50 (expanding west)
const resW = simulateLineResize(negArrow, "w", -50, 0);
assert.ok(isFinite(resW.x) && isFinite(resW.y) && isFinite(resW.x2) && isFinite(resW.y2), "No NaN or Infinity");
// Origin p1 was at (-100, -100) (the east side of bounding box), endpoint p2 at (-300, -250) (west side)
// When west expands by 50, p1 should stay at x = -100, p2 should move to x = -350 -> x2 should become -250!
assert.equal(Math.round(resW.x), -100, "Fixed end stays at -100");
assert.equal(Math.round(resW.x + resW.x2), -350, "Moving end moves to -350");
assert.equal(Math.round(resW.x2), -250, "x2 vector expanded cleanly in negative direction");
pass("Negative coordinate Arrow with negative delta (x2 < 0, y2 < 0) resized without distortion");

// 2.2 Extreme Aspect Ratio: Perfectly horizontal line (y2 = 0)
const horizLine: LineElement = {
  id: "horiz-line",
  type: "line",
  x: 50,
  y: 50,
  x2: 300,
  y2: 0,
  rotation: 0,
  opacity: 1,
  strokeColor: "#000",
  dashStyle: "solid",
  strokeWidth: 2,
  createdAt: 1,
  updatedAt: 1,
};
const resHorizE = simulateLineResize(horizLine, "e", 100, 0);
assert.equal(resHorizE.x, 50);
assert.equal(resHorizE.y, 50);
assert.equal(resHorizE.x2, 400);
assert.equal(resHorizE.y2, 0);
assert.ok(!Number.isNaN(resHorizE.x2) && !Number.isNaN(resHorizE.y2), "No NaN on flat horizontal line");
pass("Perfect horizontal line (y2 = 0) resized cleanly via handle 'e'");

// 2.3 Extreme Aspect Ratio: Perfectly vertical line (x2 = 0)
const vertLine: LineElement = {
  id: "vert-line",
  type: "line",
  x: 50,
  y: 50,
  x2: 0,
  y2: 300,
  rotation: 0,
  opacity: 1,
  strokeColor: "#000",
  dashStyle: "solid",
  strokeWidth: 2,
  createdAt: 1,
  updatedAt: 1,
};
const resVertS = simulateLineResize(vertLine, "s", 0, 100);
assert.equal(resVertS.x, 50);
assert.equal(resVertS.y, 50);
assert.equal(resVertS.x2, 0);
assert.equal(resVertS.y2, 400);
assert.ok(!Number.isNaN(resVertS.x2) && !Number.isNaN(resVertS.y2), "No NaN on vertical line");
pass("Perfect vertical line (x2 = 0) resized cleanly via handle 's'");

// 2.4 Zero-length degenerate line (x2 = 0, y2 = 0)
const zeroLine: LineElement = {
  id: "zero-line",
  type: "line",
  x: 100,
  y: 100,
  x2: 0,
  y2: 0,
  rotation: 0,
  opacity: 1,
  strokeColor: "#000",
  dashStyle: "solid",
  strokeWidth: 2,
  createdAt: 1,
  updatedAt: 1,
};
const resZeroSE = simulateLineResize(zeroLine, "se", 50, 50);
assert.ok(isFinite(resZeroSE.x) && isFinite(resZeroSE.y) && isFinite(resZeroSE.x2) && isFinite(resZeroSE.y2));
pass("Zero-length line resize does not throw or produce NaN/Infinity");


// ============================================================================
// AREA 3: ROTATED ELEMENT RESIZE TRANSFORMATIONS WITH ARBITRARY ANGLES
// ============================================================================
console.log("\n--- [Area 3] Rotated Element Resize Transformations ---");

// Helper function to simulate rotated rectangle resize
function simulateRotatedResize(
  el: RectangleElement,
  handle: string,
  worldDx: number,
  worldDy: number
): { x: number; y: number; width: number; height: number } {
  const rot = el.rotation || 0;
  const cos = Math.cos(rot);
  const sin = Math.sin(rot);
  const localDx = worldDx * cos + worldDy * sin;
  const localDy = -worldDx * sin + worldDy * cos;

  const origW = el.width || 100;
  const origH = el.height || 100;
  const origCx = el.x + origW / 2;
  const origCy = el.y + origH / 2;

  let newW = origW;
  let newH = origH;
  let localCenterShiftX = 0;
  let localCenterShiftY = 0;

  if (handle.includes("e")) {
    newW = Math.max(origW + localDx, 20);
    localCenterShiftX += (newW - origW) / 2;
  }
  if (handle.includes("w")) {
    newW = Math.max(origW - localDx, 20);
    localCenterShiftX -= (newW - origW) / 2;
  }
  if (handle.includes("s")) {
    newH = Math.max(origH + localDy, 20);
    localCenterShiftY += (newH - origH) / 2;
  }
  if (handle.includes("n")) {
    newH = Math.max(origH - localDy, 20);
    localCenterShiftY -= (newH - origH) / 2;
  }

  const worldCenterShiftX = localCenterShiftX * cos - localCenterShiftY * sin;
  const worldCenterShiftY = localCenterShiftX * sin + localCenterShiftY * cos;

  const newCx = origCx + worldCenterShiftX;
  const newCy = origCy + worldCenterShiftY;

  const newX = newCx - newW / 2;
  const newY = newCy - newH / 2;

  return { x: newX, y: newY, width: newW, height: newH };
}

// Test arbitrary rotation angles: 30°, 45°, 90°, 180°, 270°
const testAngles = [
  { name: "30°", rad: Math.PI / 6 },
  { name: "45°", rad: Math.PI / 4 },
  { name: "90°", rad: Math.PI / 2 },
  { name: "180°", rad: Math.PI },
  { name: "270°", rad: (3 * Math.PI) / 2 },
];

for (const { name, rad } of testAngles) {
  const baseRect: RectangleElement = {
    id: `rot-${name}`,
    type: "rectangle",
    x: 200,
    y: 200,
    width: 100,
    height: 60,
    rotation: rad,
    opacity: 1,
    strokeColor: "#000",
    fillColor: "#fff",
    fillStyle: "solid",
    dashStyle: "solid",
    strokeWidth: 2,
    createdAt: 1,
    updatedAt: 1,
  };

  const origCx = baseRect.x + baseRect.width / 2;
  const origCy = baseRect.y + baseRect.height / 2;

  // Invariant: The un-dragged edge must remain fixed in world space!
  // Let's drag handle 'e' along local X direction by +40px:
  // In world coordinates, dragging along local X corresponds to:
  const dragAmount = 40;
  const worldDx = dragAmount * Math.cos(rad);
  const worldDy = dragAmount * Math.sin(rad);

  const resized = simulateRotatedResize(baseRect, "e", worldDx, worldDy);
  assert.equal(Math.round(resized.width), 140, `${name}: width expanded from 100 to 140`);
  assert.equal(Math.round(resized.height), 60, `${name}: height remained 60`);

  // Verify the west edge center in world coordinates did NOT move:
  // West edge unrotated local point: (origCx - origW/2, origCy) = (200, 230)
  const origWestPointWorld = rotatePoint(200, 230, origCx, origCy, rad);

  const newCx = resized.x + resized.width / 2;
  const newCy = resized.y + resized.height / 2;
  const newWestPointLocal = { x: newCx - resized.width / 2, y: newCy };
  const newWestPointWorld = rotatePoint(newWestPointLocal.x, newWestPointLocal.y, newCx, newCy, rad);

  const distShift = Math.hypot(origWestPointWorld.x - newWestPointWorld.x, origWestPointWorld.y - newWestPointWorld.y);
  assert.ok(distShift < 0.01, `${name}: Opposite West edge remained pinned in world space (shift = ${distShift.toFixed(4)})`);
  pass(`Rotated resize at angle ${name} preserved stationary opposite edge and local geometry`);
}

// 3.2 Anchor Ports under 90° and 180° rotation
const rect90: RectangleElement = {
  id: "rect-90",
  type: "rectangle",
  x: 100,
  y: 100,
  width: 100,
  height: 50,
  rotation: Math.PI / 2, // 90 deg
  opacity: 1,
  strokeColor: "#000",
  fillColor: "#fff",
  fillStyle: "solid",
  dashStyle: "solid",
  strokeWidth: 2,
  createdAt: 1,
  updatedAt: 1,
};
const ports90 = getNodeAnchorPorts(rect90);
// Center is at (150, 125)
// Unrotated Top port was at (150, 100). Rotated 90 deg clockwise around (150, 125):
// dx = 0, dy = -25 -> rx = 150 - (-25)*1 = 175, ry = 125 + 0 = 125 (points to world RIGHT!)
assert.equal(Math.round(ports90.top.x), 175);
assert.equal(Math.round(ports90.top.y), 125);
// Normal for top port rotated 90 deg: nx = sin(pi/2) = 1, ny = -cos(pi/2) = 0
assert.equal(Math.round(ports90.top.nx), 1);
assert.ok(Math.abs(ports90.top.ny) < 1e-6, "Top port ny normal is ~ 0");
pass("Anchor ports for 90° rotated node correctly rotate coordinates and outward normals");


// ============================================================================
// AREA 4: EXPORT SVG SERIALIZATION AGAINST MALFORMED CHARACTERS, XSS, & DEEP NESTING
// ============================================================================
console.log("\n--- [Area 4] Export SVG Serialization & Security Stress ---");

const adversarialBoard: Board = {
  id: "adv-board-1",
  folderId: "folder-1",
  name: `Adversarial Board <script>alert('XSS')</script> "test" & 'quotes'`,
  camera: { x: 0, y: 0, zoom: 1 },
  elements: [
    // 4.1 Malicious text with script injection, CDATA break, and XML special chars
    {
      id: "txt-xss",
      type: "text",
      x: 100,
      y: 100,
      width: 200,
      height: 50,
      rotation: 0,
      opacity: 1,
      text: `<script>alert("PWNED")</script>\n&amp; &lt; &gt; "quote" 'single'\n]]> <![CDATA[ evil() ]]>`,
      color: `"><svg onload="alert(1)" fill="`,
      fontSize: 16,
      fontFamily: `" onmouseover="alert('font')`,
      fontWeight: 400,
      align: "left",
      createdAt: 1,
      updatedAt: 1,
    } as TextElement,
    // 4.2 Malicious sticky note
    {
      id: "sticky-xss",
      type: "sticky",
      x: 350,
      y: 100,
      width: 150,
      height: 150,
      rotation: 0,
      opacity: 1,
      text: `Hello <b>World</b>\n<img src="x" onerror="alert(2)">\nUnicode: 🚀 ניקוד שָׁלוֹם مرحبا بالعالم`,
      color: "yellow",
      fontSize: 14,
      align: "center",
      createdAt: 1,
      updatedAt: 1,
    },
    // 4.3 Malicious connection label & custom hex
    {
      id: "conn-xss",
      type: "connection",
      x: 0,
      y: 0,
      rotation: 0,
      opacity: 1,
      source: { boardId: "adv-board-1", elementId: "txt-xss", anchor: "right" },
      target: { boardId: "adv-board-1", elementId: "sticky-xss", anchor: "left" },
      routing: "curved",
      linkType: "relates-to",
      label: `<svg/onload=alert('conn')> & "Test"`,
      dashStyle: "solid",
      startArrowhead: "none",
      endArrowhead: "arrow",
      strokeWidth: 2,
      createdAt: 1,
      updatedAt: 1,
    },
    // 4.4 Malicious image URL
    {
      id: "img-xss",
      type: "image",
      x: 100,
      y: 300,
      width: 100,
      height: 100,
      naturalWidth: 100,
      naturalHeight: 100,
      rotation: 0,
      opacity: 1,
      src: `javascript:alert('img') "><script>alert(3)</script>`,
      createdAt: 1,
      updatedAt: 1,
    },
  ],
  createdAt: 1,
  updatedAt: 1,
};

const exportedSvg = exportBoardToSvg(adversarialBoard, { background: "white" });

// Verification Assertions for SVG Security and Well-Formedness:
// 1. Must NOT contain raw unescaped `<script>` or `<svg/onload` inside text/attributes
assert.ok(!exportedSvg.includes("<script>alert("), "Raw <script> tag must be escaped to &lt;script&gt;");
assert.ok(!exportedSvg.includes("<svg/onload"), "Raw <svg/onload> must be escaped");
assert.ok(!exportedSvg.includes("<img src="), "Raw HTML <img> tag must be escaped");
assert.ok(exportedSvg.includes("&lt;script&gt;alert(&quot;PWNED&quot;)&lt;/script&gt;"), "Script tag properly XML escaped in text note");
assert.ok(exportedSvg.includes("&amp;amp; &amp;lt; &amp;gt;"), "Ampersands properly escaped");
assert.ok(exportedSvg.includes("ניקוד שָׁלוֹם"), "Hebrew unicode string preserved");
assert.ok(exportedSvg.includes("مرحبا بالعالم"), "Arabic unicode string preserved");
assert.ok(exportedSvg.includes("🚀"), "Emoji preserved");
assert.ok(exportedSvg.startsWith("<?xml version=\"1.0\" encoding=\"UTF-8\"?>"), "Starts with XML header");
assert.ok(exportedSvg.trim().endsWith("</svg>"), "Ends with closing svg tag");
pass("Export SVG security: All XSS vectors and injection payloads escaped; Unicode preserved");

// 4.5 Massive Board Export Stress (1,000 elements)
const massiveElements: WhiteboardElement[] = [];
for (let i = 0; i < 1000; i++) {
  massiveElements.push({
    id: `node-${i}`,
    type: "rectangle",
    x: (i % 50) * 80,
    y: Math.floor(i / 50) * 80,
    width: 60,
    height: 40,
    rotation: (i % 4) * (Math.PI / 4),
    opacity: 0.9,
    strokeColor: "#3b82f6",
    fillColor: "#eff6ff",
    fillStyle: "semi",
    dashStyle: i % 2 === 0 ? "solid" : "dashed",
    strokeWidth: 2,
    createdAt: 1,
    updatedAt: 1,
  });
}
const massiveBoard: Board = {
  id: "massive-board",
  folderId: "folder-1",
  name: "1000-Node Board",
  camera: { x: 0, y: 0, zoom: 1 },
  elements: massiveElements,
  createdAt: 1,
  updatedAt: 1,
};

const massiveStart = performance.now();
const massiveSvg = exportBoardToSvg(massiveBoard);
const massiveElapsed = performance.now() - massiveStart;
assert.ok(massiveSvg.length > 50000, "1000 elements generated complete SVG markup");
assert.ok(massiveElapsed < 100, `1000 element SVG export took ${massiveElapsed.toFixed(2)}ms (< 100ms)`);
pass(`Massive board export stress (1,000 elements) serialized in ${massiveElapsed.toFixed(2)}ms`);


// ============================================================================
// AREA 5: SNAP-TO-GRID QUANTIZATION BOUNDARIES
// ============================================================================
console.log("\n--- [Area 5] Snap-to-Grid Quantization Boundaries ---");

// Standard GRID_SIZE is 24
assert.equal(snapToGrid(0), 0, "snap(0) = 0");
assert.equal(snapToGrid(11.999), 0, "snap(11.999) = 0");
assert.equal(snapToGrid(12.0), 24, "snap(12.0) = 24 (midpoint rounds up)");
assert.equal(snapToGrid(12.001), 24, "snap(12.001) = 24");
assert.equal(snapToGrid(23.999), 24, "snap(23.999) = 24");
assert.equal(snapToGrid(24.0), 24, "snap(24.0) = 24");
assert.equal(snapToGrid(24.001), 24, "snap(24.001) = 24");
assert.equal(snapToGrid(35.999), 24, "snap(35.999) = 24");
assert.equal(snapToGrid(36.0), 48, "snap(36.0) = 48 (next midpoint rounds up)");

// Negative numbers & IEEE -0 normalization
assert.equal(Object.is(snapToGrid(-0.0001), 0), true, "snap(-0.0001) returns +0, not -0");
assert.equal(snapToGrid(-11.999), 0, "snap(-11.999) = 0");
assert.equal(snapToGrid(-12.0), 0, "snap(-12.0) rounds to 0 (Math.round(-0.5) is -0, normalized to +0)");
assert.equal(snapToGrid(-12.001), -24, "snap(-12.001) = -24");
assert.equal(snapToGrid(-24.0), -24, "snap(-24.0) = -24");
assert.equal(snapToGrid(-35.999), -24, "snap(-35.999) = -24");
assert.equal(snapToGrid(-36.0), -24, "snap(-36.0) = -24 (-1.5 rounds to -1 -> -24)");
assert.equal(snapToGrid(-36.001), -48, "snap(-36.001) = -48");

// Non-standard grid sizes
assert.equal(snapToGrid(15, 10), 20, "snap(15, gridSize=10) = 20");
assert.equal(snapToGrid(14, 10), 10, "snap(14, gridSize=10) = 10");
assert.equal(snapToGrid(47, 0), 47, "snap(47, gridSize=0) safely returns original val without division by zero");
assert.equal(snapToGrid(47, -10), 47, "snap(47, gridSize=-10) safely returns original val");

// 2D Point snapping
const pt1 = snapPointToGrid(12.5, -36.5);
assert.deepEqual(pt1, { x: 24, y: -48 });
pass("Snap-to-grid quantization boundaries, midpoints, negative float normalization and custom sizes verified");

console.log("\n================================================================================");
console.log(`=== ALL CHALLENGER 1 ADVERSARIAL TESTS PASSED SUCCESSFULLY! (${totalAssertions} assertions) ===`);
console.log("================================================================================");
