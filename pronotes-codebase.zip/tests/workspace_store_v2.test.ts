/**
 * Tests for the IndexedDB workspace store (the localStorage-quota fix).
 *
 * Background: a tablet workspace grew past ~4 MB against localStorage's ~5 MB
 * per-origin hard cap, and EVERY save began failing with QuotaExceededError
 * (dozens of "[whiteboard] Failed to save state" in the device logs). The fix
 * moves the workspace snapshot to IndexedDB (disk-scale quota), gzipped past
 * 1 MB, with the legacy localStorage path kept byte-identical for
 * environments without IndexedDB (which is exactly what the E2E suites run).
 */

import assert from "node:assert/strict";
import {
  GZIP_THRESHOLD_CHARS,
  HEARTBEAT_KEY,
  STORAGE_PRESSURE_RATIO,
  createMemoryWorkspaceBackend,
  decodeWorkspace,
  encodeWorkspace,
  measureStoragePressure,
  requestPersistentStorage,
  type WorkspaceBackend,
  type WorkspaceRecord,
} from "../src/lib/whiteboard/workspaceDb";
import {
  cleanHistoryEntry,
  loadState,
  loadWorkspace,
  saveState,
  saveWorkspaceToBackend,
  type PersistedState,
} from "../src/lib/whiteboard/persistence";

let passed = 0;
let failed = 0;
async function atest(name: string, fn: () => Promise<void> | void) {
  try {
    await fn();
    passed++;
    console.log(`  ✓ ${name}`);
  } catch (err) {
    failed++;
    console.error(`  ✗ ${name}`);
    console.error(`      ${(err as Error).message}`);
  }
}

// ---------------------------------------------------------------------------
// Minimal window mock. Optionally capped like the ~5 MB WebView quota so the
// tablet failure can be replayed deterministically.
// ---------------------------------------------------------------------------
interface MockWindow {
  localStorage: {
    getItem(k: string): string | null;
    setItem(k: string, v: string): void;
    removeItem(k: string): void;
  };
  dispatchEvent(e: { type: string }): boolean;
}

function makeWindow(capChars = Infinity): { win: MockWindow; events: string[]; store: Map<string, string> } {
  const store = new Map<string, string>();
  const events: string[] = [];
  let used = 0;
  const win: MockWindow = {
    localStorage: {
      getItem: (k: string) => store.get(k) ?? null,
      setItem: (k: string, v: string) => {
        const prev = store.get(k);
        const next = used - (prev ? prev.length : 0) + v.length;
        if (next > capChars) {
          const err = new Error("Quota exceeded") as Error & { name: string };
          err.name = "QuotaExceededError";
          throw err;
        }
        store.set(k, v);
        used = next;
      },
      removeItem: (k: string) => {
        const prev = store.get(k);
        if (prev !== undefined) {
          used -= prev.length;
          store.delete(k);
        }
      },
    },
    dispatchEvent: (e: { type: string }) => {
      events.push(e.type);
      return true;
    },
  };
  return { win, events, store };
}

function setWindow(win: MockWindow | undefined) {
  const g = globalThis as Record<string, unknown>;
  if (win === undefined) delete g.window;
  else g.window = win;
}

type Point = [number, number, number];

function makeStroke(id: string, seed: number, points: number) {
  const pts: Point[] = [];
  for (let i = 0; i < points; i++) {
    pts.push([seed + i * 0.731, seed + Math.sin(i * 0.3) * 50, 0.5]);
  }
  return {
    id,
    type: "stroke",
    x: 0,
    y: 0,
    rotation: 0,
    opacity: 1,
    color: "#000000",
    strokeWidth: 2,
    strokeStyle: "ballpoint",
    points: pts,
    createdAt: 1,
    updatedAt: 1,
  };
}

/** A workspace of at least targetBytes of JSON — the tablet scenario. */
function makeBigState(targetBytes: number): PersistedState {
  const strokes: Array<ReturnType<typeof makeStroke>> = [];
  let n = 0;
  const base = {
    id: "big",
    name: "Big",
    folderId: null,
    camera: { x: 0, y: 0, zoom: 1 },
    createdAt: 1,
    updatedAt: 1,
    accessedAt: 1,
    tags: [],
    starred: false,
    color: "#3b82f6",
  };
  const probe = () => JSON.stringify(strokes).length;
  while (probe() < targetBytes) {
    strokes.push(makeStroke(`s${n}`, n, 200));
    n++;
  }
  const pageStroke = makeStroke("pageStroke", 999, 50);
  return {
    version: 1,
    folders: [{ id: "f1", name: "F", parentId: null, expanded: true, createdAt: 1, color: "#f59e0b" }],
    boards: [
      { ...base, elements: strokes },
      {
        ...base,
        id: "nb",
        name: "Nb",
        kind: "notebook",
        pageSize: "a4",
        pages: [{ id: "p1", elements: [pageStroke], createdAt: 1, updatedAt: 1 }],
        activePageId: "p1",
      },
    ],
    activeBoardId: "big",
    activeFolderId: null,
  } as unknown as PersistedState;
}

function failingBackend(): WorkspaceBackend {
  const fail = () => Promise.reject(new Error("disk on fire"));
  return { load: fail, save: () => fail(), clear: fail };
}

async function main() {
  console.log("\n── Workspace store v2 (IndexedDB quota fix) ──");

  await atest("codec stores small payloads raw and round-trips", async () => {
    const json = JSON.stringify({ hello: "world", n: 42 });
    const rec = await encodeWorkspace(json);
    assert.equal(rec.format, "raw");
    assert.equal(typeof rec.data, "string");
    assert.equal(await decodeWorkspace(rec), json);
  });

  await atest("codec gzips large payloads and round-trips", async () => {
    if (typeof CompressionStream === "undefined" || typeof DecompressionStream === "undefined") {
      console.log("      (no CompressionStream here — skipped)");
      return;
    }
    const json = JSON.stringify({ pts: "0123456789abcdef".repeat(GZIP_THRESHOLD_CHARS / 16) });
    assert.ok(json.length >= GZIP_THRESHOLD_CHARS, "payload must clear the gzip threshold");
    const rec = await encodeWorkspace(json);
    assert.equal(rec.format, "gzip");
    assert.ok(rec.data instanceof Uint8Array);
    assert.equal(await decodeWorkspace(rec), json);
  });

  await atest("gzip shrinks ink-like JSON to less than half", async () => {
    if (typeof CompressionStream === "undefined" || typeof DecompressionStream === "undefined") {
      console.log("      (no CompressionStream here — skipped)");
      return;
    }
    const strokes = [];
    for (let i = 0; i < 300; i++) strokes.push(makeStroke(`ink${i}`, i, 200));
    const json = JSON.stringify({ boards: [{ elements: strokes }] });
    assert.ok(json.length > GZIP_THRESHOLD_CHARS, "payload must clear the gzip threshold");
    const rec = await encodeWorkspace(json);
    assert.equal(rec.format, "gzip");
    const stored = (rec.data as Uint8Array).byteLength;
    assert.ok(stored / json.length < 0.5, `ratio ${stored / json.length} must be under 0.5`);
    assert.equal(await decodeWorkspace(rec), json);
  });

  await atest("decode rejects corrupt records instead of returning garbage", async () => {
    await assert.rejects(decodeWorkspace(null as unknown as WorkspaceRecord));
    await assert.rejects(decodeWorkspace({ v: 2, format: "raw", savedAt: 1, data: "{}" } as unknown as WorkspaceRecord));
    await assert.rejects(decodeWorkspace({ v: 1, format: "zip", savedAt: 1, data: "{}" } as unknown as WorkspaceRecord));
    await assert.rejects(
      decodeWorkspace({ v: 1, format: "raw", savedAt: 1, data: 42 } as unknown as WorkspaceRecord)
    );
    await assert.rejects(
      decodeWorkspace({ v: 1, format: "gzip", savedAt: 1, data: "not-bytes" } as unknown as WorkspaceRecord)
    );
    if (typeof DecompressionStream !== "undefined") {
      await assert.rejects(
        decodeWorkspace({ v: 1, format: "gzip", savedAt: 1, data: new Uint8Array([1, 2, 3, 4]) })
      );
    }
  });

  await atest("TABLET REPLAY: 6 MB workspace fails the legacy capped store but saves + reloads via the backend", async () => {
    const big = makeBigState(6_000_000);
    const rawLen = JSON.stringify(big).length;
    assert.ok(rawLen >= 6_000_000, `state must be >= 6 MB, got ${rawLen}`);

    // Old world: ~5 MB localStorage cap. The save (and its degraded retry)
    // both throw, wb:save-failed fires, and NOTHING is readable afterwards.
    const capped = makeWindow(5_000_000);
    setWindow(capped.win);
    try {
      saveState(big);
      assert.ok(capped.events.includes("wb:save-failed"), "legacy path must report save-failed");
      assert.equal(loadState(), null, "legacy path must leave nothing readable");
    } finally {
      setWindow(undefined);
    }

    // New world: the same bytes go through the backend uncapped.
    const backend = createMemoryWorkspaceBackend();
    const outcome = await saveWorkspaceToBackend(big, backend);
    assert.equal(outcome, "ok");
    const rec = backend.records.get("workspace");
    assert.ok(rec, "backend must hold the record");
    assert.equal(rec!.format, "gzip", "a 6 MB workspace must be stored gzipped");
    const { state: loaded, migratedFromLs } = await loadWorkspace(backend);
    assert.equal(migratedFromLs, false);
    assert.ok(loaded, "reloaded state must exist");
    // migrate() backfills defaults (e.g. bookmarked:false on pages), so the
    // comparison is at the content level: every folder, board and stroke.
    assert.equal(JSON.stringify(loaded!.folders), JSON.stringify(big.folders));
    assert.equal(loaded!.boards.length, 2);
    const loadedEls = (loaded!.boards[0] as unknown as { elements: unknown[] }).elements;
    const bigEls = (big.boards[0] as unknown as { elements: unknown[] }).elements;
    assert.equal(loadedEls.length, bigEls.length, "every stroke must survive the round-trip");
    assert.equal(JSON.stringify(loadedEls), JSON.stringify(bigEls));
    const loadedPages = (loaded!.boards[1] as unknown as { pages: Array<{ id: string; elements: unknown }> }).pages;
    const bigPages = (big.boards[1] as unknown as { pages: Array<{ id: string; elements: unknown }> }).pages;
    assert.equal(loadedPages.length, bigPages.length);
    assert.equal(loadedPages[0].id, bigPages[0].id);
    assert.equal(JSON.stringify(loadedPages[0].elements), JSON.stringify(bigPages[0].elements));
  });

  await atest("migration adopts the legacy localStorage copy and deletes it only after storing", async () => {
    const small = makeBigState(10_000);
    const ctx = makeWindow();
    setWindow(ctx.win);
    try {
      ctx.win.localStorage.setItem("z-whiteboard-state-v1", JSON.stringify(small));
      const backend = createMemoryWorkspaceBackend();
      const { state, migratedFromLs } = await loadWorkspace(backend);
      assert.equal(migratedFromLs, true);
      assert.ok(state, "migrated state must load");
      assert.equal(state!.boards.length, 2);
      assert.ok(backend.records.get("workspace"), "backend must hold the migrated record");
      assert.equal(
        ctx.win.localStorage.getItem("z-whiteboard-state-v1"),
        null,
        "legacy key must be deleted after a successful migration"
      );
      // Second boot reads straight from the backend, no migration.
      const second = await loadWorkspace(backend);
      assert.equal(second.migratedFromLs, false);
      assert.equal(second.state!.boards.length, 2);
    } finally {
      setWindow(undefined);
    }
  });

  await atest("corrupt backend record falls back to localStorage and repairs the store", async () => {
    const small = makeBigState(10_000);
    const ctx = makeWindow();
    setWindow(ctx.win);
    try {
      ctx.win.localStorage.setItem("z-whiteboard-state-v1", JSON.stringify(small));
      const backend = createMemoryWorkspaceBackend();
      backend.records.set("workspace", { v: 1, format: "zip", savedAt: 1, data: "junk" } as unknown as WorkspaceRecord);
      const { state } = await loadWorkspace(backend);
      assert.ok(state, "must fall back to the localStorage copy");
      assert.equal(state!.boards.length, 2);
      // The fallback copy is written back, repairing the store — and what
      // lands there is the readable content, not the corruption.
      const repaired = backend.records.get("workspace")!;
      assert.ok(repaired.format === "raw" || repaired.format === "gzip");
      const repairedJson = JSON.parse(await decodeWorkspace(repaired)) as {
        boards: Array<{ elements?: unknown[]; pages?: Array<{ elements: unknown }> }>;
      };
      assert.equal(repairedJson.boards.length, 2);
      assert.equal(
        JSON.stringify(repairedJson.boards[0].elements ?? []),
        JSON.stringify((small.boards[0] as unknown as { elements: unknown }).elements ?? [])
      );
      assert.equal(repairedJson.boards[1].pages!.length, 1);
    } finally {
      setWindow(undefined);
    }
  });

  await atest("total backend failure reports failed and keeps the app alive", async () => {
    const ctx = makeWindow();
    setWindow(ctx.win);
    try {
      const small = makeBigState(10_000);
      const outcome = await saveWorkspaceToBackend(small, failingBackend());
      assert.equal(outcome, "failed");
      assert.ok(ctx.events.includes("wb:save-failed"));
    } finally {
      setWindow(undefined);
    }
  });

  await atest("image-heavy state that cannot fit degrades instead of dying", async () => {
    const ctx = makeWindow();
    setWindow(ctx.win);
    try {
      const withImage = makeBigState(10_000);
      const bigSrc = "data:image/png;base64," + "X".repeat(20_000);
      (withImage.boards[0] as unknown as { elements: unknown[] }).elements.push({
        id: "img1",
        type: "image",
        x: 0,
        y: 0,
        rotation: 0,
        opacity: 1,
        src: bigSrc,
        createdAt: 1,
        updatedAt: 1,
      });
      // Backend that only fits the image-stripped retry.
      const fullLen = JSON.stringify(withImage).length;
      const backend = createMemoryWorkspaceBackend();
      const picky: WorkspaceBackend = {
        load: () => backend.load(),
        clear: () => backend.clear(),
        save: async (rec: WorkspaceRecord) => {
          const len = typeof rec.data === "string" ? rec.data.length : rec.data.byteLength;
          if (len >= fullLen) throw new Error("QuotaExceededError");
          return backend.save(rec);
        },
      };
      const outcome = await saveWorkspaceToBackend(withImage, picky);
      assert.equal(outcome, "degraded");
      assert.ok(ctx.events.includes("wb:save-degraded"));
      const { state } = await loadWorkspace(picky);
      assert.ok(state, "degraded save must still reload");
      const img = (state!.boards[0] as unknown as { elements: Array<{ type: string; src?: string }> }).elements.find(
        (el) => el.type === "image"
      );
      assert.ok(img, "image element shell must survive");
      assert.equal(img!.src, "", "image pixels must be stripped in the degraded copy");
    } finally {
      setWindow(undefined);
    }
  });

  await atest("successful save stamps the cross-tab heartbeat", async () => {
    const ctx = makeWindow();
    setWindow(ctx.win);
    try {
      const outcome = await saveWorkspaceToBackend(makeBigState(10_000), createMemoryWorkspaceBackend());
      assert.equal(outcome, "ok");
      const beat = ctx.win.localStorage.getItem(HEARTBEAT_KEY);
      assert.ok(beat, "heartbeat key must be written");
      assert.ok((JSON.parse(beat!) as { rev: number }).rev >= 1);
    } finally {
      setWindow(undefined);
    }
  });

  await atest("storage helpers honor the Storage API when present", async () => {
    const g = globalThis as Record<string, unknown>;
    const prevDesc = Object.getOwnPropertyDescriptor(g, "navigator");
    Object.defineProperty(g, "navigator", {
      value: {
        storage: {
          estimate: () => Promise.resolve({ usage: 9_000_000, quota: 10_000_000 }),
          persist: () => Promise.resolve(true),
        },
      },
      configurable: true,
      writable: true,
    });
    try {
      const pressure = await measureStoragePressure();
      assert.ok(pressure, "pressure must be measurable");
      assert.equal(pressure!.ratio, 0.9);
      assert.ok(pressure!.ratio >= STORAGE_PRESSURE_RATIO, "0.9 must trip the pressure line");
      assert.equal(await requestPersistentStorage(), true);
    } finally {
      if (prevDesc) Object.defineProperty(g, "navigator", prevDesc);
      else delete g.navigator;
    }
    assert.equal(await requestPersistentStorage(), false, "no Storage API means no persistence");
    assert.equal(await measureStoragePressure(), null, "no Storage API means no measurement");
  });

  await atest("legacy history entries still validate (untouched path)", async () => {
    assert.ok(
      cleanHistoryEntry({ boardId: "b", elements: [{ id: "e1", type: "stroke" }] }),
      "elements-only history entry must stay valid"
    );
  });

  console.log(`\n${passed} passed, ${failed} failed.`);
  if (failed > 0) process.exit(1);
}

void main();
