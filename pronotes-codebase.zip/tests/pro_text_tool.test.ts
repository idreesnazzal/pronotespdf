/**
 * Test Suite for Pro Text Tool & Typography Architecture
 * =======================================================
 * Tests:
 * 1. Markdown block parsing (Headings, Checklists, Lists, Quotes, Codeblocks)
 * 2. Inline tokenization (Bold, Italic, Underline, Strikethrough, Code, Highlight, LaTeX, WikiLinks, Tags)
 * 3. Interactive canvas checklist toggling (toggleChecklistAtLine)
 * 4. Intelligent list auto-continuation on Enter (getNextLinePrefix)
 * 5. Voice dictation controller initialization & safety
 * 6. Card mode properties integrity on TextElement
 */

import assert from "node:assert/strict";
import {
  parseMarkdownBlocks,
  tokenizeInline,
  toggleChecklistAtLine,
  getNextLinePrefix,
} from "../src/lib/whiteboard/textParser";
import {
  VoiceDictationController,
  isSpeechRecognitionSupported,
  requestMicrophonePermission,
} from "../src/lib/whiteboard/speechRecognition";
import { useWhiteboard } from "../src/store/whiteboard";
import { getBoardElements } from "../src/lib/whiteboard/notebook";
import type { TextElement } from "../src/lib/whiteboard/types";

let passed = 0;
let failed = 0;
async function test(name: string, fn: () => void | Promise<void>) {
  try {
    await fn();
    passed++;
    console.log(`  ✓ ${name}`);
  } catch (err) {
    failed++;
    console.error(`  ✗ ${name}`);
    console.error(`      ${(err as Error).message}`);
  }
}

async function runTests() {
  console.log("\n── Professional Text Tool & Markdown Engine Tests ──");

  // 1. Markdown Block Tokenization
  await test("parseMarkdownBlocks: correctly parses headings, checklists, lists, quotes, and code blocks", () => {
    const markdown = [
      "# Heading 1",
      "## Heading 2",
      "### Heading 3",
      "- [ ] Pending task",
      "- [x] Completed task",
      "- Bullet item",
      "1. Numbered item 1",
      "> Blockquote text",
      "```",
      "const x = 42;",
      "```",
      "Normal paragraph",
    ].join("\n");

    const blocks = parseMarkdownBlocks(markdown);
    assert.equal(blocks.length, 10);

    assert.equal(blocks[0].type, "h1");
    assert.equal(blocks[0].tokens[0].text, "Heading 1");

    assert.equal(blocks[1].type, "h2");
    assert.equal(blocks[1].tokens[0].text, "Heading 2");

    assert.equal(blocks[2].type, "h3");
    assert.equal(blocks[2].tokens[0].text, "Heading 3");

    assert.equal(blocks[3].type, "checklist");
    assert.equal(blocks[3].checked, false);
    assert.equal(blocks[3].tokens[0].text, "Pending task");

    assert.equal(blocks[4].type, "checklist");
    assert.equal(blocks[4].checked, true);
    assert.equal(blocks[4].tokens[0].text, "Completed task");

    assert.equal(blocks[5].type, "bullet");
    assert.equal(blocks[5].tokens[0].text, "Bullet item");

    assert.equal(blocks[6].type, "numbered");
    assert.equal(blocks[6].number, 1);
    assert.equal(blocks[6].tokens[0].text, "Numbered item 1");

    assert.equal(blocks[7].type, "quote");
    assert.equal(blocks[7].tokens[0].text, "Blockquote text");

    assert.equal(blocks[8].type, "codeblock");
    assert.equal(blocks[8].rawText, "const x = 42;");

    assert.equal(blocks[9].type, "paragraph");
    assert.equal(blocks[9].tokens[0].text, "Normal paragraph");
  });

  // 2. Inline Tokenization
  await test("tokenizeInline: parses bold, italic, underline, strike, code, highlight, math, wikilinks, tags", () => {
    const line =
      "Plain **bold** *italic* <u>under</u> ~~strike~~ `code` ==highlight== $E=mc^2$ [[Target Board|My Link]] #tag https://pronotes.app";
    const tokens = tokenizeInline(line);

    const boldTok = tokens.find((t) => t.type === "bold");
    assert.ok(boldTok);
    assert.equal(boldTok.text, "bold");

    const italicTok = tokens.find((t) => t.type === "italic");
    assert.ok(italicTok);
    assert.equal(italicTok.text, "italic");

    const underTok = tokens.find((t) => t.type === "underline");
    assert.ok(underTok);
    assert.equal(underTok.text, "under");

    const strikeTok = tokens.find((t) => t.type === "strike");
    assert.ok(strikeTok);
    assert.equal(strikeTok.text, "strike");

    const codeTok = tokens.find((t) => t.type === "code");
    assert.ok(codeTok);
    assert.equal(codeTok.text, "code");

    const highlightTok = tokens.find((t) => t.type === "highlight");
    assert.ok(highlightTok);
    assert.equal(highlightTok.text, "highlight");

    const mathTok = tokens.find((t) => t.type === "math");
    assert.ok(mathTok);
    assert.equal(mathTok.text, "E=mc^2");

    const linkTok = tokens.find((t) => t.type === "link");
    assert.ok(linkTok);
    assert.equal(linkTok.text, "My Link");
    assert.equal(linkTok.value, "Target Board");

    const tagTok = tokens.find((t) => t.type === "tag");
    assert.ok(tagTok);
    assert.equal(tagTok.text, "#tag");

    const urlTok = tokens.find((t) => t.type === "url");
    assert.ok(urlTok);
    assert.equal(urlTok.text, "https://pronotes.app");
  });

  // 3. Interactive Checklist Toggling
  await test("toggleChecklistAtLine: toggles check state between [ ] and [x] at target line", () => {
    const text = [
      "- [ ] Item 1",
      "- [ ] Item 2",
      "- [x] Item 3",
    ].join("\n");

    // Toggle item 2 to checked
    const toggled2 = toggleChecklistAtLine(text, 1);
    const lines2 = toggled2.split("\n");
    assert.equal(lines2[0], "- [ ] Item 1");
    assert.equal(lines2[1], "- [x] Item 2");
    assert.equal(lines2[2], "- [x] Item 3");

    // Toggle item 3 back to unchecked
    const toggled3 = toggleChecklistAtLine(toggled2, 2);
    const lines3 = toggled3.split("\n");
    assert.equal(lines3[2], "- [ ] Item 3");

    // Non-target or invalid line is safe no-op
    assert.equal(toggleChecklistAtLine(text, 99), text);
  });

  // 4. Intelligent List Auto-continuation on Enter
  await test("getNextLinePrefix: handles continuation and clean exit on empty list items", () => {
    // Checklists
    assert.deepEqual(getNextLinePrefix("- [ ] Task 1"), { prefix: "- [ ] ", shouldExit: false });
    assert.deepEqual(getNextLinePrefix("- [ ] "), { prefix: "", shouldExit: true });
    assert.deepEqual(getNextLinePrefix("- [x] Done"), { prefix: "- [ ] ", shouldExit: false });
    assert.deepEqual(getNextLinePrefix("- [x] "), { prefix: "", shouldExit: true });

    // Bullet lists
    assert.deepEqual(getNextLinePrefix("- Apple"), { prefix: "- ", shouldExit: false });
    assert.deepEqual(getNextLinePrefix("- "), { prefix: "", shouldExit: true });
    assert.deepEqual(getNextLinePrefix("* Banana"), { prefix: "* ", shouldExit: false });
    assert.deepEqual(getNextLinePrefix("* "), { prefix: "", shouldExit: true });

    // Numbered lists
    assert.deepEqual(getNextLinePrefix("1. First step"), { prefix: "2. ", shouldExit: false });
    assert.deepEqual(getNextLinePrefix("2. Second step"), { prefix: "3. ", shouldExit: false });
    assert.deepEqual(getNextLinePrefix("3. "), { prefix: "", shouldExit: true });

    // Blockquotes
    assert.deepEqual(getNextLinePrefix("> Wise words"), { prefix: "> ", shouldExit: false });
    assert.deepEqual(getNextLinePrefix("> "), { prefix: "", shouldExit: true });

    // Ordinary line: no prefix
    assert.deepEqual(getNextLinePrefix("Ordinary sentence."), { prefix: "", shouldExit: false });
  });

  // 5. Voice Dictation Controller Lifecycle & Permission
  await test("VoiceDictationController: instantiates safely, verifies permissions and reports status", async () => {
    const controller = new VoiceDictationController();
    assert.equal(controller.getStatus(), "idle");
    assert.equal(typeof isSpeechRecognitionSupported(), "boolean");

    const perm = await requestMicrophonePermission();
    assert.equal(typeof perm.granted, "boolean");

    const started = await controller.start();
    assert.equal(typeof started, "boolean");

    // Stopping or aborting while idle is safe no-op
    controller.stop();
    assert.equal(controller.getStatus(), "idle");
    controller.abort();
    assert.equal(controller.getStatus(), "idle");
  });

  // 5b. Bug fix: stop() and abort() clear interim text via onInterim("")
  await test("VoiceDictationController: stop/abort clears interim text callback", async () => {
    const interimCalls: string[] = [];
    const controller = new VoiceDictationController({
      onInterim: (text) => interimCalls.push(text),
    });

    // stop() should call onInterim("") to clear lingering preview text
    controller.stop();
    assert.ok(interimCalls.includes(""), "stop() should emit onInterim('') to clear preview");

    interimCalls.length = 0;

    // abort() should also clear
    controller.abort();
    assert.ok(interimCalls.includes(""), "abort() should emit onInterim('') to clear preview");
  });

  // 5c. Bug fix: multiple start() calls reset internal state cleanly
  await test("VoiceDictationController: start() resets state for fresh session", async () => {
    const statusChanges: string[] = [];
    const controller = new VoiceDictationController({
      onStatusChange: (s) => statusChanges.push(s),
    });

    // In Node.js, window is undefined so start() returns false immediately.
    // We still verify that stop() after a failed start is safe, and that
    // a second start() doesn't throw or leave stale state.
    const started1 = await controller.start();
    assert.equal(started1, false, "start() returns false in Node (no window)");

    // Stop explicitly — should be safe even after a failed start
    controller.stop();
    assert.equal(controller.getStatus(), "idle");

    statusChanges.length = 0;

    // Second start — should not throw or leave stale error state
    const started2 = await controller.start();
    assert.equal(started2, false, "second start() also returns false in Node");
    // After stop(), status should be clean idle
    controller.stop();
    assert.equal(controller.getStatus(), "idle");
    assert.equal(controller.getErrorMessage(), "", "No lingering error after clean stop");
  });

  // 5d. Bug fix: getErrorMessage() returns empty string after fresh start
  await test("VoiceDictationController: getErrorMessage() is empty on fresh controller", () => {
    const controller = new VoiceDictationController();
    assert.equal(controller.getErrorMessage(), "", "Fresh controller should have no error message");
  });

  // 6. Card Mode & TextElement Properties Integrity
  await test("TextElement: supports cardMode, backgroundColor, borderRadius, and padding in store", () => {
    const store = useWhiteboard.getState();
    const boardId = store.createBoard("Text Test Board", null);
    store.setActiveBoard(boardId);

    const cardElement: TextElement = {
      id: "card_test_123",
      type: "text",
      x: 100,
      y: 100,
      width: 280,
      height: 120,
      rotation: 0,
      opacity: 1,
      text: "# Card Note\n- [ ] Task A\n- [ ] Task B",
      color: "#1e293b",
      fontSize: 16,
      fontFamily: "Inter",
      fontWeight: 400,
      align: "left",
      cardMode: true,
      backgroundColor: "#eff6ff",
      borderColor: "#bfdbfe",
      borderRadius: 12,
      padding: 16,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };

    store.addElement(cardElement, false);
    const activeBoard = useWhiteboard.getState().boards.find((b) => b.id === boardId)!;
    const elements = getBoardElements(activeBoard);
    const saved = elements.find((e) => e.id === "card_test_123") as TextElement;

    assert.ok(saved, "Card element was saved");
    assert.equal(saved.cardMode, true);
    assert.equal(saved.backgroundColor, "#eff6ff");
    assert.equal(saved.borderColor, "#bfdbfe");
    assert.equal(saved.borderRadius, 12);
    assert.equal(saved.padding, 16);
  });

  console.log(`\n${passed} passed, ${failed} failed.\n`);
  if (failed > 0) {
    process.exit(1);
  }
}

runTests();
