import assert from "node:assert/strict";
import {
  hitTestElement,
  getElementBounds,
  getElementCenter,
  getUnionBounds,
  getNodeAnchorPorts,
  getResolvedAnchorPoint,
  getOptimalConnectionAnchors,
  getCurvedBezierPath,
  getOrthogonalPath,
  getStraightPath,
  getConnectionPath,
  getArrowheadPath,
  worldToScreen,
  screenToWorld,
  worldToScreenDelta,
  screenToWorldDelta,
  rotatePoint,
  clamp,
  lerp,
  alignElements,
  distributeElements,
  isVisibleInViewport,
  getResizeHandles,
} from "../src/lib/whiteboard/geometry";
import type {
  StrokeElement,
  RectangleElement,
  EllipseElement,
  DiamondElement,
  TriangleElement,
  StarElement,
  CloudElement,
  LineElement,
  ArrowElement,
  ConnectionElement,
  TextElement,
  StickyElement,
} from "../src/lib/whiteboard/types";

console.log("===================================================================");
console.log("=== RUNNING CHALLENGER STRESS SUITE: GEOMETRY & HIT-TESTING     ===");
console.log("===================================================================");

let totalChecks = 0;
function pass(msg: string) {
  totalChecks++;
  // console.log(`  ✓ ${msg}`);
}

// ----------------------------------------------------------------------------
// Section 1: Single-Tap Dot & Stroke Hit-Testing Stress
// ----------------------------------------------------------------------------
console.log("\n[Section 1] Single-Tap Dot & Stroke Hit-Testing Adversarial Tests...");

// 1.1 Single Dot at world (0, 0), strokeWidth = 2 -> radius = max(2/2, 2) = 2. Tolerance = 8 -> hit radius = 10
const dotBasic: StrokeElement = {
  id: "dot-basic",
  type: "stroke",
  x: 0,
  y: 0,
  rotation: 0,
  opacity: 1,
  points: [[0, 0, 0.5]],
  color: "#000",
  strokeWidth: 2,
  strokeStyle: "pen",
  createdAt: Date.now(),
  updatedAt: Date.now(),
};

assert.equal(hitTestElement(dotBasic, 0, 0), true, "Center hit must be true");
assert.equal(hitTestElement(dotBasic, 10, 0), true, "Hit at exactly boundary distance (10px) must be true");
assert.equal(hitTestElement(dotBasic, 0, 10), true, "Hit at y-boundary (10px) must be true");
assert.equal(hitTestElement(dotBasic, 7.07, 7.07), true, "Hit at diagonal ~10px must be true");
assert.equal(hitTestElement(dotBasic, 10.01, 0), false, "Hit just outside boundary (10.01px) must be false");
assert.equal(hitTestElement(dotBasic, 0, -10.01), false, "Hit just outside negative boundary must be false");
pass("Basic single dot radial boundary hit testing verified");

// 1.2 Single Dot with custom tolerance (0px, 20px)
assert.equal(hitTestElement(dotBasic, 2.0, 0, 0), true, "Hit with tol=0 at r=2 must be true");
assert.equal(hitTestElement(dotBasic, 2.01, 0, 0), false, "Hit with tol=0 at r=2.01 must be false");
assert.equal(hitTestElement(dotBasic, 22.0, 0, 20), true, "Hit with tol=20 at r=22 must be true");
assert.equal(hitTestElement(dotBasic, 22.01, 0, 20), false, "Hit with tol=20 at r=22.01 must be false");
pass("Single dot hit testing with custom tolerance parameters (0px and 20px) verified");

// 1.3 Dot with large strokeWidth = 50 -> radius = 25. Tolerance = 8 -> hit radius = 33
const dotLarge: StrokeElement = {
  ...dotBasic,
  strokeWidth: 50,
};
assert.equal(hitTestElement(dotLarge, 33, 0), true, "Hit large dot at boundary (33px) must be true");
assert.equal(hitTestElement(dotLarge, 33.1, 0), false, "Hit large dot outside boundary must be false");
pass("Large single dot (strokeWidth=50) hit testing verified");

// 1.4 Single Dot at negative coordinates with element offset
const dotNeg: StrokeElement = {
  ...dotBasic,
  x: -500,
  y: -300,
  points: [[10, 20, 0.5]], // world pos = (-490, -280)
};
assert.equal(hitTestElement(dotNeg, -490, -280), true, "Hit at negative world pos must be true");
assert.equal(hitTestElement(dotNeg, -490 + 9, -280), true, "Hit near negative world pos must be true");
assert.equal(hitTestElement(dotNeg, -490 + 11, -280), false, "Hit outside negative world pos must be false");
pass("Single dot at negative world coordinates verified");

// 1.5 Locked stroke should NEVER hit
const dotLocked: StrokeElement = {
  ...dotBasic,
  locked: true,
};
assert.equal(hitTestElement(dotLocked, 0, 0), false, "Locked stroke must never hit");
pass("Locked stroke element returns false");

// 1.6 Multi-point stroke hit testing
const strokeMulti: StrokeElement = {
  id: "stroke-multi",
  type: "stroke",
  x: 100,
  y: 100,
  rotation: 0,
  opacity: 1,
  points: [
    [0, 0, 0.5],
    [50, 0, 0.5],
    [50, 50, 0.5],
  ],
  color: "#000",
  strokeWidth: 4, // radius = 2, hit radius with tol(8) = 10
  strokeStyle: "pen",
  createdAt: Date.now(),
  updatedAt: Date.now(),
};
// World coords: (100,100) -> (150,100) -> (150,150)
assert.equal(hitTestElement(strokeMulti, 125, 100), true, "Segment 1 midpoint hits");
assert.equal(hitTestElement(strokeMulti, 125, 109), true, "Near segment 1 within tolerance hits");
assert.equal(hitTestElement(strokeMulti, 125, 111), false, "Outside segment 1 tolerance misses");
assert.equal(hitTestElement(strokeMulti, 150, 125), true, "Segment 2 midpoint hits");
assert.equal(hitTestElement(strokeMulti, 141, 125), true, "Near segment 2 hits");
assert.equal(hitTestElement(strokeMulti, 139, 125), false, "Far from segment 2 misses");
pass("Multi-segment stroke hit-testing along segments verified");

// ----------------------------------------------------------------------------
// Section 2: All 8 Vector Shape Tools Hit-Testing Stress
// ----------------------------------------------------------------------------
console.log("\n[Section 2] All 8 Vector Shapes (Rect, Ellipse, Diamond, Triangle, Star, Cloud, Line, Arrow)...");

// 2.1 Rectangle (x=100, y=100, w=200, h=100, tol=8)
const rect: RectangleElement = {
  id: "rect-test",
  type: "rectangle",
  x: 100,
  y: 100,
  width: 200,
  height: 100,
  rotation: 0,
  opacity: 1,
  strokeColor: "#000",
  fillColor: "transparent",
  fillStyle: "transparent",
  dashStyle: "solid",
  strokeWidth: 2,
  createdAt: Date.now(),
  updatedAt: Date.now(),
};
assert.equal(hitTestElement(rect, 200, 150), true, "Center of rectangle hits");
assert.equal(hitTestElement(rect, 100 - 8, 100 - 8), true, "Top-left corner within tolerance hits");
assert.equal(hitTestElement(rect, 300 + 8, 200 + 8), true, "Bottom-right corner within tolerance hits");
assert.equal(hitTestElement(rect, 100 - 8.1, 150), false, "Outside left boundary misses");
assert.equal(hitTestElement(rect, 300 + 8.1, 150), false, "Outside right boundary misses");

// Rotated Rectangle (45 deg)
const rectRot: RectangleElement = {
  ...rect,
  rotation: Math.PI / 4,
};
// Center remains (200, 150)
assert.equal(hitTestElement(rectRot, 200, 150), true, "Center of rotated rectangle hits");
// Original top-left unrotated (100, 100) rotated around (200, 150) by 45 deg
const origTLRot = rotatePoint(100, 100, 200, 150, Math.PI / 4);
assert.equal(hitTestElement(rectRot, origTLRot.x, origTLRot.y), true, "Rotated corner hits");
// Point far from rotated rectangle
assert.equal(hitTestElement(rectRot, 0, 0), false, "Point outside rotated rectangle misses");
pass("Rectangle unrotated and rotated 45° hit testing verified");

// 2.2 Ellipse (x=100, y=100, w=200, h=100) -> center (200, 150), rx=100, ry=50
const ellipse: EllipseElement = {
  id: "ellipse-test",
  type: "ellipse",
  x: 100,
  y: 100,
  width: 200,
  height: 100,
  rotation: 0,
  opacity: 1,
  strokeColor: "#000",
  fillColor: "transparent",
  fillStyle: "transparent",
  dashStyle: "solid",
  strokeWidth: 2,
  createdAt: Date.now(),
  updatedAt: Date.now(),
};
assert.equal(hitTestElement(ellipse, 200, 150), true, "Ellipse center hits");
assert.equal(hitTestElement(ellipse, 300, 150), true, "Ellipse right vertex (200+100, 150) hits");
assert.equal(hitTestElement(ellipse, 200, 200), true, "Ellipse bottom vertex (200, 150+50) hits");
// Bounding box corner (100, 100): dx=100, dy=50 -> (100/(100+8))^2 + (50/(50+8))^2 = (100/108)^2 + (50/58)^2 = 0.857 + 0.743 = 1.6 > 1 -> MISS!
assert.equal(hitTestElement(ellipse, 100, 100), false, "Bounding box corner outside ellipse misses");
pass("Ellipse curvature boundary testing verified (correctly excludes bounding box corners)");

// 2.3 Diamond (x=100, y=100, w=200, h=100) -> center (200, 150)
const diamond: DiamondElement = {
  id: "dia-test",
  type: "diamond",
  x: 100,
  y: 100,
  width: 200,
  height: 100,
  rotation: 0,
  opacity: 1,
  strokeColor: "#000",
  fillColor: "transparent",
  fillStyle: "transparent",
  dashStyle: "solid",
  strokeWidth: 2,
  createdAt: Date.now(),
  updatedAt: Date.now(),
};
assert.equal(hitTestElement(diamond, 200, 150), true, "Diamond center hits");
assert.equal(hitTestElement(diamond, 300, 150), true, "Diamond right point hits");
assert.equal(hitTestElement(diamond, 200, 100), true, "Diamond top point hits");
// Bounding box top-left corner (100, 100): |dx| + |dy| = 100/(100+8) + 50/(50+8) = 1.78 > 1 -> MISS!
assert.equal(hitTestElement(diamond, 100, 100), false, "Bounding box corner outside diamond misses");
pass("Diamond equation |x/w| + |y/h| <= 1 hit testing verified");

// 2.4 Triangle, Star, Cloud (Conservative Bounds)
const tri: TriangleElement = { ...rect, type: "triangle", id: "tri-test" };
const star: StarElement = { ...rect, type: "star", id: "star-test" };
const cloud: CloudElement = { ...rect, type: "cloud", id: "cloud-test" };

for (const el of [tri, star, cloud]) {
  assert.equal(hitTestElement(el, 200, 150), true, `${el.type} center hits`);
  assert.equal(hitTestElement(el, 50, 50), false, `${el.type} far outside misses`);
}
pass("Triangle, Star, Cloud shape hit testing verified");

// 2.5 Line & Arrow (Segment Distance with strokeWidth & tolerance)
// Line from (100, 100) to (300, 100) (horizontal dx=200, dy=0), strokeWidth=4, tol=8 -> hit dist <= 10
const line: LineElement = {
  id: "line-test",
  type: "line",
  x: 100,
  y: 100,
  x2: 200,
  y2: 0,
  rotation: 0,
  opacity: 1,
  strokeColor: "#000",
  strokeWidth: 4,
  dashStyle: "solid",
  createdAt: Date.now(),
  updatedAt: Date.now(),
};
assert.equal(hitTestElement(line, 200, 100), true, "Line midpoint hits");
assert.equal(hitTestElement(line, 200, 110), true, "Line perpendicular distance 10px hits");
assert.equal(hitTestElement(line, 200, 111), false, "Line perpendicular distance 11px misses");
assert.equal(hitTestElement(line, 90, 100), true, "Line start endpoint with 10px tolerance hits");
assert.equal(hitTestElement(line, 89, 100), false, "Line before start beyond tolerance misses");

// Arrow
const arrow: ArrowElement = {
  ...line,
  id: "arrow-test",
  type: "arrow",
  startArrowhead: "none",
  endArrowhead: "arrow",
  arrowheadSize: 10,
};
assert.equal(hitTestElement(arrow, 200, 100), true, "Arrow shaft hits");
assert.equal(hitTestElement(arrow, 300, 100), true, "Arrow tip hits");
assert.equal(hitTestElement(arrow, 300, 110), true, "Arrow tip with 10px tolerance hits");
assert.equal(hitTestElement(arrow, 300, 112), false, "Arrow tip beyond tolerance misses");

// Degenerate zero-length line (x2=0, y2=0)
const zeroLine: LineElement = {
  ...line,
  x2: 0,
  y2: 0,
};
assert.equal(hitTestElement(zeroLine, 100, 100), true, "Zero length line at start point hits");
assert.equal(hitTestElement(zeroLine, 110, 100), true, "Zero length line within tolerance hits");
assert.equal(hitTestElement(zeroLine, 111, 100), false, "Zero length line beyond tolerance misses");
pass("Line and Arrow hit testing along segments and zero-length degenerate cases verified");

// ----------------------------------------------------------------------------
// Section 3: Smart Anchor Ports & 3 Routing Engines Stress
// ----------------------------------------------------------------------------
console.log("\n[Section 3] Smart Anchor Ports & 3 Routing Engines...");

// 3.1 Anchor Ports with Rotation
const nodeRect: RectangleElement = {
  ...rect,
  x: 100,
  y: 100,
  width: 100,
  height: 50,
  rotation: Math.PI / 2, // 90 deg rotation around center (150, 125)
};
const portsRot = getNodeAnchorPorts(nodeRect);
// With 90 deg rotation, unrotated Top (150, 100) rotated around (150, 125) by 90 deg -> (150 - 0, 125 - 25) -> becomes (175, 125)
assert.equal(Math.round(portsRot.top.x), 175, "Rotated top port X correct");
assert.equal(Math.round(portsRot.top.y), 125, "Rotated top port Y correct");
pass("Anchor ports rotation affine transformation verified");

// 3.2 3 Routing Engines Stress
const p1 = { x: 100, y: 100, nx: 1, ny: 0, anchor: "right" as const };
const p2 = { x: 300, y: 200, nx: -1, ny: 0, anchor: "left" as const };

// Curved
const curvedPath = getCurvedBezierPath(p1, p2);
assert.ok(curvedPath.startsWith("M 100,100 C"), "Curved path starts with M...C");
assert.ok(curvedPath.endsWith("300,200"), "Curved path ends at p2");

// Curved with degenerate distance (< 2px)
const pClose = { x: 100.5, y: 100.5, nx: 1, ny: 0, anchor: "right" as const };
const curvedClose = getCurvedBezierPath(p1, pClose);
assert.equal(curvedClose, "M 100,100 L 100.5,100.5", "Close curved points (<2px) fallback to linear segment");

// Orthogonal
const orthoPath = getOrthogonalPath(p1, p2);
assert.ok(orthoPath.startsWith("M 100,100 L"), "Orthogonal path generated");

// Orthogonal with degenerate distance (< 4px)
const orthoClose = getOrthogonalPath(p1, pClose);
assert.equal(orthoClose, "M 100,100 L 100.5,100.5", "Close orthogonal points (<4px) fallback to linear segment");

// Straight
const straightPath = getStraightPath(p1, p2);
assert.equal(straightPath, "M 100,100 L 300,200", "Straight path is exact line");

// getConnectionPath dispatch
assert.equal(getConnectionPath(p1, p2, "straight"), straightPath);
assert.equal(getConnectionPath(p1, p2, "orthogonal"), orthoPath);
assert.equal(getConnectionPath(p1, p2, "curved"), curvedPath);
pass("All 3 routing engines (Curved, Orthogonal, Straight) and degenerate distances verified");

// 3.3 All Arrowhead Types
const arrowTypes = ["none", "triangle", "arrow", "stealth", "diamond", "circle"] as const;
for (const at of arrowTypes) {
  const head = getArrowheadPath(100, 100, 50, 100, at, 12);
  if (at === "none") {
    assert.equal(head, null, "None arrowhead is null");
  } else {
    assert.ok(head !== null, `${at} arrowhead produced`);
    assert.ok(!head.path.includes("NaN"), `${at} arrowhead has no NaN`);
  }
}

// Arrowhead with zero distance (tip == from) -> returns null
const nullHead = getArrowheadPath(100, 100, 100, 100, "arrow", 12);
assert.equal(nullHead, null, "Zero distance arrowhead safely returns null");
pass("All arrowhead polygon generators and zero-distance guard verified");

// ----------------------------------------------------------------------------
// Section 4: Screen <-> World Transforms & Sidebar Offset Invariance
// ----------------------------------------------------------------------------
console.log("\n[Section 4] Screen <-> World Transformations Invertibility & Viewport Math...");

// 4.1 Invertibility Stress: 1,000 points across zoom ranges [0.01 to 100.0]
const testZooms = [0.01, 0.1, 0.5, 1.0, 2.5, 10.0, 50.0, 100.0];
const testVps = [
  { width: 1280, height: 800 },
  { width: 375, height: 667 }, // mobile
  { width: 3840, height: 2160 }, // 4K
];

for (const zoom of testZooms) {
  for (const vp of testVps) {
    const cam = { x: 1234.56, y: -789.12, zoom };
    for (let i = 0; i < 20; i++) {
      const worldX = (Math.random() - 0.5) * 20000;
      const worldY = (Math.random() - 0.5) * 20000;
      const screen = worldToScreen(worldX, worldY, cam, vp);
      const recovered = screenToWorld(screen.x, screen.y, cam, vp);

      assert.ok(Math.abs(recovered.x - worldX) < 1e-6, `World X invertibility at zoom ${zoom}`);
      assert.ok(Math.abs(recovered.y - worldY) < 1e-6, `World Y invertibility at zoom ${zoom}`);
    }
  }
}
pass("Screen <-> World transforms strictly invertible across all zoom scales and viewports");

// 4.2 Delta transforms
assert.equal(worldToScreenDelta(10, 2.5), 25);
assert.equal(screenToWorldDelta(25, 2.5), 10);
pass("Delta transformations verified");

// ----------------------------------------------------------------------------
// Section 5: Alignment & Distribution Stress
// ----------------------------------------------------------------------------
console.log("\n[Section 5] Alignment & Distribution Math Stress...");

const r1: RectangleElement = { ...rect, id: "r1", x: 10, y: 10, width: 20, height: 20 };
const r2: RectangleElement = { ...rect, id: "r2", x: 50, y: 30, width: 40, height: 30 };
const r3: RectangleElement = { ...rect, id: "r3", x: 120, y: 80, width: 30, height: 40 };

// Align Center
const alignedCenter = alignElements([r1, r2, r3], "center");
// Union x: 10 to 150 -> union center = 80
// r1 width 20 -> x = 80 - 10 = 70
// r2 width 40 -> x = 80 - 20 = 60
// r3 width 30 -> x = 80 - 15 = 65
assert.equal(alignedCenter[0].x, 70);
assert.equal(alignedCenter[1].x, 60);
assert.equal(alignedCenter[2].x, 65);

// Align Middle
const alignedMiddle = alignElements([r1, r2, r3], "middle");
// Union y: 10 to 120 -> union center = 65
// r1 height 20 -> y = 65 - 10 = 55
// r2 height 30 -> y = 65 - 15 = 50
// r3 height 40 -> y = 65 - 20 = 45
assert.equal(alignedMiddle[0].y, 55);
assert.equal(alignedMiddle[1].y, 50);
assert.equal(alignedMiddle[2].y, 45);

// Align with single element -> no-op
assert.deepEqual(alignElements([r1], "left"), [r1]);

// Distribute Vertical with 3 elements
const distributedV = distributeElements([r1, r2, r3], "vertical");
// Total height = 20 + 30 + 40 = 90
// Span = 120 - 10 = 110
// Gap = (110 - 90) / 2 = 10
// r1 y = 10
// r2 y = 10 + 20 + 10 = 40
// r3 y = 40 + 30 + 10 = 80
assert.equal(distributedV[0].y, 10);
assert.equal(distributedV[1].y, 40);
assert.equal(distributedV[2].y, 80);

// Distribute with < 3 elements -> returns original
assert.deepEqual(distributeElements([r1, r2], "horizontal"), [r1, r2]);
pass("Alignment (left, center, right, top, middle, bottom) and Distribution math verified");

console.log(`\n===================================================================`);
console.log(`=== GEOMETRY STRESS SUITE: ALL ${totalChecks} ASSERTIONS PASSED (100%) ===`);
console.log(`===================================================================\n`);
