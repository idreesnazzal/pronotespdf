/**
 * Voice dictation robustness — the "weak and buggy" report.
 *
 * - Stop mid-sentence used to unhook the engine at once: the last words
 *   were lost. They are written now, and a late final revises them.
 * - Every silent pause used an auto-restart and 5 of them switched
 *   dictation off (~30 s of thinking). Pauses are limited by time now.
 * - One "network" blip ended dictation for good; it is retried now.
 * - Words appear in the note while you speak (interim written in place).
 */

import assert from "node:assert/strict";
import {
  VoiceDictationController,
  SILENCE_LIMIT_MS,
  placeInterim,
  spliceDictationChunk,
  stripInterim,
  type DictationRange,
} from "../src/lib/whiteboard/speechRecognition";

const NL = String.fromCharCode(10);

let passed = 0;
let failed = 0;
async function test(name: string, fn: () => void | Promise<void>) {
  try {
    await fn();
    passed++;
    console.log(`  ✓ ${name}`);
  } catch (err) {
    failed++;
    console.error(`  ✗ ${name}`);
    console.error(`      ${(err as Error).message}`);
  }
}

type Handler = ((ev: unknown) => void) | null;
class FakeRecognition {
  static last: FakeRecognition | null = null;
  static made = 0;
  continuous = false;
  interimResults = false;
  lang = "";
  maxAlternatives = 1;
  stopped = false;
  onstart: Handler = null;
  onresult: Handler = null;
  onerror: Handler = null;
  onend: Handler = null;
  onaudiostart: Handler = null;
  onaudioend: Handler = null;
  onsoundstart: Handler = null;
  onsoundend: Handler = null;
  onspeechstart: Handler = null;
  onspeechend: Handler = null;
  onnomatch: Handler = null;
  constructor() {
    FakeRecognition.last = this;
    FakeRecognition.made++;
  }
  start() {
    this.onstart?.({});
  }
  stop() {
    this.stopped = true;
  }
  abort() {}
  end() {
    this.onend?.({});
  }
  error(code: string) {
    this.onerror?.({ error: code });
  }
  /** One event: results as [isFinal, text] pairs from index `from`. */
  emit(results: Array<[boolean, string]>, from = 0) {
    const list = results.map(([isFinal, text]) => {
      const alt = { transcript: text, confidence: 0 };
      return Object.assign([alt], { isFinal, item: () => alt });
    });
    this.onresult?.({ resultIndex: from, results: Object.assign(list, { item: (i: number) => list[i] }) });
  }
}

const tick = (ms = 0) => new Promise((r) => setTimeout(r, ms));

function install() {
  (globalThis as unknown as { window: unknown }).window = { webkitSpeechRecognition: FakeRecognition };
}

/** Plays controller output into a text the way the editor does. */
function editorSim() {
  let text = "";
  let cursor = 0;
  let last: DictationRange | null = null;
  let interim: DictationRange | null = null;
  return {
    onInterim(words: string) {
      if (!interim && !words.trim()) return;
      const out = placeInterim(text, cursor, cursor, interim, words);
      text = out.text;
      cursor = out.cursor;
      interim = out.range;
    },
    onFinal(chunk: string, revises: boolean) {
      const base = stripInterim(text, cursor, cursor, interim);
      interim = null;
      const out = spliceDictationChunk(base.value, base.selStart, base.selEnd, chunk, last, revises);
      text = out.text;
      cursor = out.cursor;
      last = out.range;
    },
    get text() {
      return text;
    },
  };
}

async function main() {
  console.log(NL + "── Dictation robustness ──");

  await test("Stop mid-sentence keeps the words being said", async () => {
    install();
    const ed = editorSim();
    const c = new VoiceDictationController({
      onInterim: (w) => ed.onInterim(w),
      onFinal: (t, o) => ed.onFinal(t, o?.revisesPrevious ?? false),
    });
    await c.start();
    const rec = FakeRecognition.last!;
    rec.emit([[true, "first sentence"]]);
    rec.emit([[true, "first sentence"], [false, "and the last"]], 1);
    c.stop();
    assert.equal(ed.text, "first sentence and the last ");
    assert.equal(rec.stopped, true);
  });

  await test("the engine's own final after Stop revises the flushed words, never doubles them", async () => {
    install();
    const ed = editorSim();
    const c = new VoiceDictationController({
      onInterim: (w) => ed.onInterim(w),
      onFinal: (t, o) => ed.onFinal(t, o?.revisesPrevious ?? false),
    });
    await c.start();
    const rec = FakeRecognition.last!;
    rec.emit([[false, "see you tomor"]]);
    c.stop();
    // Moments later the engine delivers the real final for that phrase.
    rec.emit([[true, "see you tomorrow"]]);
    assert.equal(ed.text, "see you tomorrow ");
    rec.end();
  });

  await test("a final exactly equal to the flushed words is not written twice", async () => {
    install();
    const ed = editorSim();
    const c = new VoiceDictationController({
      onInterim: (w) => ed.onInterim(w),
      onFinal: (t, o) => ed.onFinal(t, o?.revisesPrevious ?? false),
    });
    await c.start();
    const rec = FakeRecognition.last!;
    rec.emit([[false, "buy milk"]]);
    c.stop();
    rec.emit([[true, "buy milk"]]);
    assert.equal(ed.text, "buy milk ");
  });

  await test("words appear in the note while speaking, then settle to the final", async () => {
    install();
    const seen: string[] = [];
    const ed = editorSim();
    const c = new VoiceDictationController({
      onInterim: (w) => {
        ed.onInterim(w);
        seen.push(ed.text);
      },
      onFinal: (t, o) => ed.onFinal(t, o?.revisesPrevious ?? false),
    });
    await c.start();
    const rec = FakeRecognition.last!;
    rec.emit([[false, "how"]]);
    rec.emit([[false, "how are"]]);
    rec.emit([[false, "how are you"]]);
    rec.emit([[true, "how are you"]]);
    assert.ok(seen.includes("how are"), `live text: ${JSON.stringify(seen)}`);
    assert.equal(ed.text, "how are you ");
    c.abort();
  });

  await test("thinking in silence does not switch dictation off after 5 pauses", async () => {
    install();
    let status = "";
    const c = new VoiceDictationController({ onStatusChange: (s) => (status = s) });
    await c.start();
    const realNow = Date.now;
    let offset = 0;
    try {
      Date.now = () => realNow() + offset;
      for (let i = 0; i < 10; i++) {
        offset += 6000; // each silent session lasts ~6 s before Android ends it
        FakeRecognition.last!.end();
        await tick(1050);
      }
      assert.equal(status, "listening", "still listening after 60 s of pauses");
    } finally {
      Date.now = realNow;
      c.abort();
    }
  });

  await test("long silence ends dictation with a message, not silently", async () => {
    install();
    let status = "";
    const notes: string[] = [];
    const c = new VoiceDictationController({ onStatusChange: (s) => (status = s), onError: (m) => notes.push(m) });
    await c.start();
    const realNow = Date.now;
    try {
      Date.now = () => realNow() + SILENCE_LIMIT_MS + 1000;
      FakeRecognition.last!.end();
    } finally {
      Date.now = realNow;
    }
    assert.equal(status, "idle");
    assert.ok(notes.some((n) => /silence/i.test(n)), JSON.stringify(notes));
  });

  await test("an engine that dies instantly is given up on, with a message", async () => {
    install();
    const notes: string[] = [];
    let status = "";
    const c = new VoiceDictationController({ onStatusChange: (s) => (status = s), onError: (m) => notes.push(m) });
    await c.start();
    for (let i = 0; i < 6 && status === "listening"; i++) {
      FakeRecognition.last!.end(); // ends at once, nothing heard
      await tick(1050);
    }
    assert.equal(status, "idle");
    assert.ok(notes.some((n) => /keeps stopping/i.test(n)), JSON.stringify(notes));
  });

  await test("one network blip is retried; dictation keeps going", async () => {
    install();
    let status = "";
    const c = new VoiceDictationController({ onStatusChange: (s) => (status = s) });
    await c.start();
    const before = FakeRecognition.made;
    FakeRecognition.last!.error("network");
    FakeRecognition.last!.end();
    await tick(1050);
    assert.equal(status, "listening");
    assert.ok(FakeRecognition.made > before, "a new session was started");
    c.abort();
  });

  await test("repeated network failures are reported", async () => {
    install();
    let status = "";
    const notes: string[] = [];
    const c = new VoiceDictationController({ onStatusChange: (s) => (status = s), onError: (m) => notes.push(m) });
    await c.start();
    for (let i = 0; i < 4; i++) FakeRecognition.last!.error("network");
    assert.equal(status, "error");
    assert.ok(notes.length > 0);
    c.abort();
  });

  await test("a session ending mid-phrase keeps the words heard so far", async () => {
    install();
    const ed = editorSim();
    const c = new VoiceDictationController({
      onInterim: (w) => ed.onInterim(w),
      onFinal: (t, o) => ed.onFinal(t, o?.revisesPrevious ?? false),
    });
    await c.start();
    const rec = FakeRecognition.last!;
    rec.emit([[false, "the meeting is at"]]);
    rec.end(); // Android cut the session before sending a final
    assert.equal(ed.text, "the meeting is at ");
    c.abort();
  });

  await test("typed text around the live words is never eaten", () => {
    // Existing text, caret at the end; interim shown, then replaced by final.
    const a = placeInterim("Notes:", 6, 6, null, "hello");
    assert.equal(a.text, "Notes: hello");
    const b = placeInterim(a.text, a.cursor, a.cursor, a.range, "hello world");
    assert.equal(b.text, "Notes: hello world");
    const s = stripInterim(b.text, b.cursor, b.cursor, b.range);
    assert.equal(s.value, "Notes:");
    assert.equal(s.selStart, 6);
    const cleared = placeInterim(b.text, b.cursor, b.cursor, b.range, "");
    assert.equal(cleared.text, "Notes:");
    assert.equal(cleared.range, null);
  });

  console.log(`  ${passed} passed, ${failed} failed`);
  if (failed > 0) process.exit(1);
  process.exit(0);
}

main();
