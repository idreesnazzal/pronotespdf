/**
 * Sidebar pro work: batch duplicate + batch export packing.
 *
 * Duplicating several boards reuses the single duplicateBoard path (full
 * notebook copies included); packing several exports into one .zip reuses
 * the per-board SVG pipeline. Both are store/lib-level and node-testable.
 */

import assert from "node:assert/strict";
import { zipSync, unzipSync, strToU8, strFromU8 } from "fflate";
import { useWhiteboard } from "../src/store/whiteboard";
import {
  exportBoardToSvg,
  exportFilename,
  zipExportFiles,
} from "../src/lib/whiteboard/export";
import type { Board } from "../src/lib/whiteboard/types";

const NL = String.fromCharCode(10);

let passed = 0;
let failed = 0;
function test(name: string, fn: () => void) {
  try {
    fn();
    passed++;
    console.log(`  ✓ ${name}`);
  } catch (err) {
    failed++;
    console.error(`  ✗ ${name}`);
    console.error(`      ${(err as Error).message}`);
  }
}

function resetStore() {
  useWhiteboard.setState({
    boards: [],
    folders: [],
    activeBoardId: null,
    activeFolderId: null,
    selectedIds: [],
    editingId: null,
    history: { past: [], future: [] },
  });
  useWhiteboard.getState().discardTrash();
}

let seq = 0;
function board(partial: Partial<Board> = {}): Board {
  seq++;
  return {
    id: `d${seq}`,
    name: `Doc ${seq}`,
    folderId: null,
    elements: [],
    background: { pattern: "plain" },
    camera: { x: 0, y: 0, zoom: 1 },
    createdAt: seq,
    updatedAt: seq,
    ...partial,
  } as Board;
}

function main() {
  console.log(NL + "── Sidebar batch ops ──");

  test("batchDuplicateBoards copies canvas boards with fresh ids", () => {
    resetStore();
    const S = () => useWhiteboard.getState();
    const a = board({ id: "a", name: "A" });
    useWhiteboard.setState({ boards: [a], activeBoardId: "a" });
    const ids = S().batchDuplicateBoards(["a", "missing"]);
    assert.equal(ids.length, 1, "unknown ids are skipped");
    const copy = S().boards.find((b) => b.id === ids[0])!;
    assert.ok(copy, "copy exists");
    assert.notEqual(copy.id, "a");
    assert.equal(copy.name, "A (Copy)");
  });

  test("batchDuplicateBoards copies every notebook page", () => {
    resetStore();
    const S = () => useWhiteboard.getState();
    const nb = board({
      id: "nb",
      name: "NB",
      kind: "notebook",
      pages: [1, 2, 3].map((n) => ({
        id: `p${n}`,
        elements: [
          { id: `e${n}`, type: "text", x: 0, y: 0, rotation: 0, opacity: 1, text: `page ${n}`, createdAt: 1, updatedAt: 1 } as never,
        ],
        createdAt: 1,
        updatedAt: 1,
      })),
    });
    useWhiteboard.setState({ boards: [nb], activeBoardId: "nb" });
    const ids = S().batchDuplicateBoards(["nb"]);
    const copy = S().boards.find((b) => b.id === ids[0])!;
    assert.equal(copy.pages?.length, 3, "all pages copied");
    assert.equal(copy.pages?.[0]?.elements.length, 1);
    assert.notEqual(copy.pages?.[0]?.elements[0]?.id, "e1", "elements get fresh ids");
  });

  test("fflate itself round-trips (library sanity for the zip path)", () => {
    const zipped = zipSync({ "a.svg": strToU8("<svg/>") });
    const back = unzipSync(zipped);
    assert.equal(strFromU8(back["a.svg"]), "<svg/>");
  });

  test("two board SVGs pack into one zip under their export filenames", () => {
    const b1 = board({ id: "z1", name: "First" });
    const b2 = board({ id: "z2", name: "Second" });
    const files = [b1, b2].map((b) => ({
      filename: exportFilename(b, "svg"),
      data: strToU8(exportBoardToSvg(b)),
    }));
    assert.deepEqual(
      files.map((f) => f.filename),
      ["First.svg", "Second.svg"]
    );
    const back = unzipSync(zipExportFiles(files));
    assert.deepEqual(Object.keys(back).sort(), ["First.svg", "Second.svg"]);
    assert.ok(strFromU8(back["First.svg"]).includes("<svg"));
  });

  console.log(`  ${passed} passed, ${failed} failed`);
  if (failed > 0) process.exit(1);
}

void main();
