/**
 * Voice dictation: cumulative finals, language choice, mic setup.
 *
 * The reported bug: saying "how to do this" writes
 *   "how how to how to do how to do this".
 * The tablet engine re-sends the sentence-so-far as a new FINAL
 * ("how", then "how to", then "how to do", ...). The old guard only
 * dropped byte-identical repeats, so every longer copy was appended.
 * The fix: a final that CONTINUES the previous one revises it in place.
 */

import assert from "node:assert/strict";
import {
  VoiceDictationController,
  isContinuationOfFinal,
  spliceDictationChunk,
  SUPPORTED_DICTATION_LANGS,
  resolveDictationLang,
} from "../src/lib/whiteboard/speechRecognition";

const NL = String.fromCharCode(10);

let passed = 0;
let failed = 0;
async function test(name: string, fn: () => void | Promise<void>) {
  try {
    await fn();
    passed++;
    console.log(`  ✓ ${name}`);
  } catch (err) {
    failed++;
    console.error(`  ✗ ${name}`);
    console.error(`      ${(err as Error).message}`);
  }
}

// ---------------------------------------------------------------------------
// Stand-in speech engine (same shape as review_fixes.test.ts).
// ---------------------------------------------------------------------------

type Handler = ((ev: unknown) => void) | null;
class FakeRecognition {
  static last: FakeRecognition | null = null;
  continuous = false;
  interimResults = false;
  lang = "";
  maxAlternatives = 1;
  onstart: Handler = null;
  onresult: Handler = null;
  onerror: Handler = null;
  onend: Handler = null;
  onaudiostart: Handler = null;
  onaudioend: Handler = null;
  onsoundstart: Handler = null;
  onsoundend: Handler = null;
  onspeechstart: Handler = null;
  onspeechend: Handler = null;
  onnomatch: Handler = null;
  constructor() {
    FakeRecognition.last = this;
  }
  start() {
    this.onstart?.({});
  }
  /** Engine silence timeout: ends the session, triggering auto-restart. */
  end() {
    this.onend?.({});
  }
  stop() {}
  abort() {}
  addEventListener() {}
  removeEventListener() {}
  dispatchEvent() {
    return true;
  }
  emitFinal(text: string) {
    const alt = { transcript: text, confidence: 0 };
    const result = Object.assign([alt], { isFinal: true, item: () => alt });
    const results = Object.assign([result], { item: () => result });
    this.onresult?.({ resultIndex: 0, results });
  }
}

async function main() {
  console.log(NL + "── Dictation continuation ──");

  await test("isContinuationOfFinal: growing prefixes continue, new words do not", () => {
    assert.equal(isContinuationOfFinal("how", 1000, "how to", 1500), true);
    assert.equal(isContinuationOfFinal("how to", 1500, "how to do this", 2000), true);
    assert.equal(isContinuationOfFinal("how", 1000, "second sentence", 1500), false);
    assert.equal(isContinuationOfFinal("buy milk", 1000, "buy milk", 1500), false);
    assert.equal(isContinuationOfFinal("yes", 1000, "yesterday", 1500), false);
    assert.equal(isContinuationOfFinal("how", 1000, "how to", 9000), false);
    assert.equal(isContinuationOfFinal("", 1000, "how", 1500), false);
  });

  await test("isContinuationOfFinal: a revised word still revises, a shrink appends", () => {
    // Tablet case: "are you want to fix the" -> "are you going to fix the problem".
    assert.equal(
      isContinuationOfFinal("are you want to fix the", 1000, "are you going to fix the problem", 1500),
      true
    );
    // A shorter re-send is a new phrase — revising would delete confirmed words.
    assert.equal(isContinuationOfFinal("how to do this", 1000, "how to", 1500), false);
  });

  await test("tablet sentence revises to exactly what was said", async () => {
    (globalThis as unknown as { window: unknown }).window = { webkitSpeechRecognition: FakeRecognition };
    const calls: Array<{ text: string; revisesPrevious: boolean }> = [];
    const c = new VoiceDictationController({
      onFinal: (t, opts) => calls.push({ text: t, revisesPrevious: opts?.revisesPrevious ?? false }),
    });
    assert.equal(await c.start(), true);
    const rec = FakeRecognition.last!;
    rec.emitFinal("are");
    rec.emitFinal("are you");
    rec.emitFinal("are you want to fix");
    rec.emitFinal("are you want to fix the");
    rec.emitFinal("are you going to fix the problem");
    assert.deepEqual(
      calls.map((x) => x.revisesPrevious),
      [false, true, true, true, true]
    );
    let text = "";
    let cursor = 0;
    let range: { start: number; length: number } | null = null;
    for (const { text: chunk, revisesPrevious } of calls) {
      const out = spliceDictationChunk(text, cursor, cursor, chunk, range, revisesPrevious);
      text = out.text;
      cursor = out.cursor;
      range = out.range;
    }
    assert.equal(text, "are you going to fix the problem ");
    c.stop();
  });

  await test("controller flags cumulative finals as revisions, not appends", async () => {
    (globalThis as unknown as { window: unknown }).window = { webkitSpeechRecognition: FakeRecognition };
    const calls: Array<{ text: string; revisesPrevious: boolean }> = [];
    const c = new VoiceDictationController({
      onFinal: (t, opts) => calls.push({ text: t, revisesPrevious: opts?.revisesPrevious ?? false }),
    });
    assert.equal(await c.start(), true);
    const rec = FakeRecognition.last!;
    rec.emitFinal("how");
    rec.emitFinal("how to");
    rec.emitFinal("how to do");
    rec.emitFinal("how to do this");
    assert.deepEqual(calls, [
      { text: "how", revisesPrevious: false },
      { text: "how to", revisesPrevious: true },
      { text: "how to do", revisesPrevious: true },
      { text: "how to do this", revisesPrevious: true },
    ]);
    c.stop();
  });

  await test("revised chunks splice to exactly what was said", () => {
    // Simulates the editor: append first chunk, revise in place after that.
    let text = "";
    let cursor = 0;
    let range: { start: number; length: number } | null = null;
    const chunks: Array<{ chunk: string; revises: boolean }> = [
      { chunk: "how", revises: false },
      { chunk: "how to", revises: true },
      { chunk: "how to do", revises: true },
      { chunk: "how to do this", revises: true },
    ];
    for (const { chunk, revises } of chunks) {
      const out = spliceDictationChunk(text, cursor, cursor, chunk, range, revises);
      text = out.text;
      cursor = out.cursor;
      range = out.range;
    }
    assert.equal(text, "how to do this ");
  });

  await test("a genuinely new sentence still appends after a revision", () => {
    let text = "";
    let cursor = 0;
    let range: { start: number; length: number } | null = null;
    for (const step of [
      { chunk: "how to do this", revises: false },
      { chunk: "second sentence", revises: false },
    ]) {
      const out = spliceDictationChunk(text, cursor, cursor, step.chunk, range, step.revises);
      text = out.text;
      cursor = out.cursor;
      range = out.range;
    }
    assert.equal(text, "how to do this second sentence ");
  });

  await test("revision is ignored when the user moved the cursor (falls back to append)", () => {
    const first = spliceDictationChunk("", 0, 0, "how", null, false);
    // User taps back to the start before the revised final arrives.
    const out = spliceDictationChunk(first.text, 0, 0, "how to", first.range, true);
    assert.equal(out.text, "how to how ");
  });

  await test("pause then continue: a restarted session does not rewrite everything", async () => {
    (globalThis as unknown as { window: unknown }).window = { webkitSpeechRecognition: FakeRecognition };
    const calls: Array<{ text: string; revisesPrevious: boolean }> = [];
    const c = new VoiceDictationController({
      onFinal: (t, opts) => calls.push({ text: t, revisesPrevious: opts?.revisesPrevious ?? false }),
    });
    assert.equal(await c.start(), true);
    const rec = FakeRecognition.last!;
    rec.emitFinal("are you going");
    // A long pause: the engine session ends and auto-restarts behind us.
    const realNow = Date.now;
    try {
      Date.now = () => realNow() + 30000;
      rec.end();
      await new Promise((r) => setTimeout(r, 150));
      const rec2 = FakeRecognition.last!;
      assert.notEqual(rec2, rec, "auto-restart should open a new engine session");
      // Engine catch-up: exact re-send, then a grown re-send, then new words.
      rec2.emitFinal("are you going");
      rec2.emitFinal("are you going home");
      rec2.emitFinal("and then we deploy");
    } finally {
      Date.now = realNow;
    }
    assert.deepEqual(calls, [
      { text: "are you going", revisesPrevious: false },
      { text: "are you going home", revisesPrevious: true },
      { text: "and then we deploy", revisesPrevious: false },
    ]);
    let text = "";
    let cursor = 0;
    let range: { start: number; length: number } | null = null;
    for (const { text: chunk, revisesPrevious } of calls) {
      const out = spliceDictationChunk(text, cursor, cursor, chunk, range, revisesPrevious);
      text = out.text;
      cursor = out.cursor;
      range = out.range;
    }
    assert.equal(text, "are you going home and then we deploy ");
    c.stop();
  });

  await test("same segment re-sent mid-session after a pause is skipped", async () => {
    (globalThis as unknown as { window: unknown }).window = { webkitSpeechRecognition: FakeRecognition };
    const calls: string[] = [];
    const c = new VoiceDictationController({ onFinal: (t) => calls.push(t) });
    assert.equal(await c.start(), true);
    const rec = FakeRecognition.last!;
    rec.emitFinal("hello there");
    const realNow = Date.now;
    try {
      Date.now = () => realNow() + 30000;
      // Same session, same result index, same words: a list re-send, not speech.
      rec.emitFinal("hello there");
    } finally {
      Date.now = realNow;
    }
    assert.deepEqual(calls, ["hello there"]);
    c.stop();
  });

  await test("a fresh Dictate press repeats nothing: same words append", async () => {
    (globalThis as unknown as { window: unknown }).window = { webkitSpeechRecognition: FakeRecognition };
    const calls: Array<{ text: string; revisesPrevious: boolean }> = [];
    const c = new VoiceDictationController({
      onFinal: (t, opts) => calls.push({ text: t, revisesPrevious: opts?.revisesPrevious ?? false }),
    });
    assert.equal(await c.start(), true);
    FakeRecognition.last!.emitFinal("hello");
    c.stop();
    assert.equal(await c.start(), true);
    FakeRecognition.last!.emitFinal("hello");
    assert.deepEqual(calls, [
      { text: "hello", revisesPrevious: false },
      { text: "hello", revisesPrevious: false },
    ]);
    c.stop();
  });

  await test("supported languages include Hebrew and Arabic, default resolves sensibly", () => {
    const ids = SUPPORTED_DICTATION_LANGS.map((l) => l.id);
    assert.ok(ids.includes("en-US"));
    assert.ok(ids.includes("he-IL"));
    assert.ok(ids.includes("ar-SA"));
    assert.equal(resolveDictationLang("he-IL"), "he-IL");
    assert.equal(resolveDictationLang("he"), "he-IL");
    assert.equal(resolveDictationLang("xx-YY"), "en-US");
    assert.equal(resolveDictationLang(undefined), "en-US");
  });

  console.log(`  ${passed} passed, ${failed} failed`);
  if (failed > 0) process.exit(1);
}

void main();
