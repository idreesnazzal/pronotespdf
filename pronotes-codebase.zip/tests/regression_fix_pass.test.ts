/**
 * Regression suite for the 2026-08-17 audit & fix pass (CHANGELOG_FIXES.md).
 * Each test pins a specific defect that was found and fixed — if any of these
 * fail, the fix regressed.
 */

import assert from "node:assert/strict";

// ---- libraries under test ---------------------------------------------------
import {
  parseText,
  buildGraph,
  elementNodeId,
  parseElementNodeId,
} from "../src/lib/whiteboard/links";
import { getSvgPathFromStroke, eraseFromStroke } from "../src/lib/whiteboard/stroke";
import { migrateState } from "../src/lib/whiteboard/persistence";
import {
  looksLikeMouseWheel,
  normalizeWheelDelta,
  resolveWheelAction,
  type RawWheel,
} from "../src/lib/whiteboard/input";
import { exportBoardToSvg } from "../src/lib/whiteboard/export";
import {
  classifyTouch,
  contactLooksLikePalm,
  exceedsLongPressSlop,
  isRejectedTouch,
  LONG_PRESS_SLOP_PX,
  PALM_CONTACT_PX,
  PEN_SUPPRESSION_MS,
} from "../src/lib/whiteboard/palm";
import {
  hitTestElement,
  isElementInPolygon,
  screenSpaceOverlayTransform,
} from "../src/lib/whiteboard/geometry";
import type {
  Board,
  Folder,
  ToolType,
  StrokeElement,
  TextElement,
  StickyElement,
  ConnectionElement,
  RectangleElement,
  WhiteboardElement,
} from "../src/lib/whiteboard/types";
import { useWhiteboard } from "../src/store/whiteboard";
import { getToolColor, getToolSize, setToolInk, PEN_TYPES } from "../src/lib/whiteboard/types";
import { isUndoCombo, isRedoCombo, type ComboEvent } from "../src/lib/whiteboard/shortcuts";
import {
  mergeWorkspaces,
  parseWorkspace,
  serializeWorkspace,
  WorkspaceParseError,
} from "../src/lib/whiteboard/workspace";

console.log("=== Regression Suite: 2026-08-17 Fix Pass ===");

function makeBoard(id: string, elements: WhiteboardElement[] = []): Board {
  return {
    id,
    name: `Board ${id}`,
    folderId: null,
    elements,
    camera: { x: 0, y: 0, zoom: 1 },
    createdAt: 1,
    updatedAt: 1,
    tags: [],
    starred: false,
    accessedAt: 1,
  };
}

function makeRect(id: string, x = 0, y = 0, w = 100, h = 80): RectangleElement {
  return {
    id, type: "rectangle", x, y, width: w, height: h, rotation: 0, opacity: 1,
    strokeColor: "#000", fillColor: "transparent", fillStyle: "solid", dashStyle: "solid",
    strokeWidth: 2, createdAt: 1, updatedAt: 1,
  };
}

// ============================================================================
// B1: moveFolder must reject cycles (folder into its own descendant)
// ============================================================================
console.log("\n[REG-B1] moveFolder cycle rejection...");
{
  const s = useWhiteboard.getState();
  const a = useWhiteboard.getState().createFolder("A", null);
  const b = useWhiteboard.getState().createFolder("B", a);
  const c = useWhiteboard.getState().createFolder("C", b);
  // Move A into C (its own grandchild) -> must be rejected
  useWhiteboard.getState().moveFolder(a, c);
  const folders = useWhiteboard.getState().folders;
  const folderA = folders.find((f) => f.id === a)!;
  assert.equal(folderA.parentId, null, "A must stay at root (cycle rejected)");
  // Legit move still works
  useWhiteboard.getState().moveFolder(c, a);
  assert.equal(useWhiteboard.getState().folders.find((f) => f.id === c)!.parentId, a);
}

// ============================================================================
// B5: deleteFolder removes the FULL descendant chain
// ============================================================================
console.log("[REG-B5] deleteFolder full-descendant removal...");
{
  const st = useWhiteboard.getState();
  const p = st.createFolder("P", null);
  const child = st.createFolder("child", p);
  const grand = st.createFolder("grand", child);
  const boardInGrand = st.createBoard("kept-board", grand);
  useWhiteboard.getState().deleteFolder(p);
  const s2 = useWhiteboard.getState();
  assert.ok(!s2.folders.some((f) => f.id === child), "child deleted");
  assert.ok(!s2.folders.some((f) => f.id === grand), "grandchild deleted too (was orphaned before)");
  const movedBoard = s2.boards.find((b) => b.id === boardInGrand)!;
  assert.equal(movedBoard.folderId, null, "board inside deleted subtree moves to root");
}

// ============================================================================
// B4: deleting a NON-active board must not hijack the active board
// ============================================================================
console.log("[REG-B4] deleteBoard non-active no-hijack...");
{
  const st = useWhiteboard.getState();
  const active = st.activeBoardId!;
  const other = st.createBoard("background", null);
  useWhiteboard.getState().setActiveBoard(active);
  const before = useWhiteboard.getState();
  const camBefore = { ...before.camera };
  useWhiteboard.getState().deleteBoard(other);
  const after = useWhiteboard.getState();
  assert.equal(after.activeBoardId, active, "active board unchanged");
  assert.deepEqual(after.camera, camBefore, "camera unchanged");
}

// ============================================================================
// B4b: cross-board connections referencing a deleted board are cleaned
// ============================================================================
console.log("[REG-B4b] dangling cross-board connections cleaned...");
{
  const st = useWhiteboard.getState();
  const boardX = st.createBoard("X", null);
  const boardY = st.createBoard("Y", null);
  const r1 = makeRect("xr1", 0, 0);
  const r2 = makeRect("yr1", 400, 0);
  useWhiteboard.getState().addElementToBoard(boardX, r1, false);
  useWhiteboard.getState().addElementToBoard(boardY, r2, false);
  const conn: ConnectionElement = {
    id: "xconn", type: "connection", x: 0, y: 0, rotation: 0, opacity: 1,
    source: { boardId: boardX, elementId: "xr1", anchor: "auto" },
    target: { boardId: boardY, elementId: "yr1", anchor: "auto" },
    linkType: "relates", routing: "straight", dashStyle: "solid",
    startArrowhead: "none", endArrowhead: "arrow", strokeWidth: 2, createdAt: 1, updatedAt: 1,
  };
  useWhiteboard.getState().addElementToBoard(boardX, conn, false);
  useWhiteboard.getState().deleteBoard(boardY);
  const bx = useWhiteboard.getState().boards.find((b) => b.id === boardX)!;
  assert.ok(!bx.elements.some((e) => e.id === "xconn"), "connection to deleted board removed");
}

// ============================================================================
// B8: history snapshots must be DEEP clones
// ============================================================================
console.log("[REG-B8] history deep-clone isolation...");
{
  const st = useWhiteboard.getState();
  const boardId = st.createBoard("history-board", null);
  const stroke: StrokeElement = {
    id: "s1", type: "stroke", x: 0, y: 0, rotation: 0, opacity: 1,
    points: [[0, 0, 0.5], [10, 0, 0.5], [20, 5, 0.5]],
    color: "#000", strokeWidth: 3, strokeStyle: "pen", createdAt: 1, updatedAt: 1,
  };
  useWhiteboard.getState().addElements([stroke], true);
  useWhiteboard.getState().commitHistory();
  // Mutate the LIVE element's nested points in place (simulating a rogue writer)
  const live = useWhiteboard.getState().boards.find((b) => b.id === boardId)!.elements[0] as StrokeElement;
  live.points.push([999, 999, 0.5]);
  // Undo must restore the snapshot WITHOUT the in-place mutation leaking in
  useWhiteboard.getState().undo();
  const restored = useWhiteboard.getState().boards.find((b) => b.id === boardId)!.elements[0] as StrokeElement;
  assert.equal(restored.points.length, 3, "snapshot must not share points array with live state");
}

// ============================================================================
// D3: locked elements cannot be deleted via deleteElements / excluded by selectAll
// ============================================================================
console.log("[REG-D3] lock protection...");
{
  const st = useWhiteboard.getState();
  const boardId = st.createBoard("lock-board", null);
  const locked = makeRect("locked-1");
  locked.locked = true;
  const free = makeRect("free-1", 300, 0);
  useWhiteboard.getState().addElements([locked, free], false);
  useWhiteboard.getState().setSelected(["locked-1", "free-1"]);
  useWhiteboard.getState().deleteElements(useWhiteboard.getState().selectedIds, true);
  const els = useWhiteboard.getState().boards.find((b) => b.id === boardId)!.elements;
  assert.ok(els.some((e) => e.id === "locked-1"), "locked element survives delete");
  assert.ok(!els.some((e) => e.id === "free-1"), "unlocked element deleted");
  useWhiteboard.getState().selectAll();
  assert.ok(
    !useWhiteboard.getState().selectedIds.includes("locked-1"),
    "selectAll excludes locked"
  );
}

// ============================================================================
// D6: undo/redo are blocked while the inline editor is open
// ============================================================================
console.log("[REG-D6] undo/redo blocked during editing...");
{
  const st = useWhiteboard.getState();
  const boardId = st.createBoard("edit-board", null);
  const txt: TextElement = {
    id: "t1", type: "text", x: 0, y: 0, width: 200, height: 50, rotation: 0, opacity: 1,
    text: "before", color: "#000", fontSize: 18, fontFamily: "Inter", fontWeight: 400,
    align: "left", createdAt: 1, updatedAt: 1,
  };
  useWhiteboard.getState().addElements([txt], true);
  useWhiteboard.getState().commitHistory();
  useWhiteboard.getState().setEditingId("t1");
  useWhiteboard.getState().undo(); // must be a no-op mid-edit
  const stillThere = useWhiteboard.getState().boards.find((b) => b.id === boardId)!.elements.find((e) => e.id === "t1");
  assert.ok(stillThere, "undo mid-edit must not revert the board");
  useWhiteboard.getState().setEditingId(null);
}

// ============================================================================
// B15: bringForward/sendBackward are single-layer steps
// ============================================================================
console.log("[REG-B15] single-step layer ordering...");
{
  const st = useWhiteboard.getState();
  const boardId = st.createBoard("zorder-board", null);
  const a = makeRect("z-a");
  const b = makeRect("z-b", 10, 10);
  const c = makeRect("z-c", 20, 20);
  useWhiteboard.getState().addElements([a, b, c], false);
  useWhiteboard.getState().bringForward(["z-a"]);
  let order = useWhiteboard.getState().boards.find((x) => x.id === boardId)!.elements.map((e) => e.id);
  assert.deepEqual(order, ["z-b", "z-a", "z-c"], "bringForward swaps one layer, not to front");
  useWhiteboard.getState().sendBackward(["z-c"]);
  order = useWhiteboard.getState().boards.find((x) => x.id === boardId)!.elements.map((e) => e.id);
  assert.deepEqual(order, ["z-b", "z-c", "z-a"], "sendBackward swaps one layer, not to back");
}

// ============================================================================
// B7/D13: camera is persisted into boards and survives switching
// ============================================================================
console.log("[REG-B7] camera persistence across board switches...");
{
  const st = useWhiteboard.getState();
  const b1 = st.createBoard("cam1", null);
  const b2 = st.createBoard("cam2", null);
  useWhiteboard.getState().setActiveBoard(b1);
  useWhiteboard.getState().panCamera(120, 60);
  useWhiteboard.getState().setActiveBoard(b2);
  const persisted = useWhiteboard.getState().getPersistedState();
  const cam1 = persisted.boards.find((b) => b.id === b1)!.camera;
  assert.equal(cam1.x, -120, "outgoing board camera captured on switch");
  assert.equal(cam1.y, -60, "outgoing board camera captured on switch (y)");
}

// ============================================================================
// B10: saved state with ZERO boards is honored (no demo re-injection logic here;
// we verify getPersistedState round-trips an empty board list intact)
// ============================================================================
console.log("[REG-B10] empty-boards state integrity...");
{
  const persisted = useWhiteboard.getState().getPersistedState();
  assert.ok(Array.isArray(persisted.boards), "boards always an array");
  assert.ok(Array.isArray(persisted.folders), "folders always an array");
}

// ============================================================================
// B11: WikiLink alias edge cases
// ============================================================================
console.log("[REG-B11] wikilink alias semantics...");
{
  const parsed = parseText("see [[Target|]] and [[A|b|c]] and [[Plain]]");
  assert.equal(parsed.links.length, 3, "all three links match");
  assert.equal(parsed.links[0].display, "Target", "[[Target|]] displays target");
  assert.equal(parsed.links[1].display, "b", "[[A|b|c]] displays first alias segment");
  assert.equal(parsed.links[1].target, "A", "[[A|b|c]] targets A");
  assert.equal(parsed.links[2].display, "Plain", "plain link unchanged");
}

// ============================================================================
// B9/B12/D10: export escaping, alignment anchors, custom link colors, blend
// ============================================================================
console.log("[REG-B9/B12/D10] export serialization...");
{
  const txt: TextElement = {
    id: "t", type: "text", x: 100, y: 100, width: 300, height: 50, rotation: 0, opacity: 1,
    text: "centered [[Link|shown]]", color: "#111", fontSize: 20, fontFamily: "Inter",
    fontWeight: 400, align: "center", createdAt: 1, updatedAt: 1,
  };
  const hostile = makeRect("hostile");
  hostile.fillColor = `red" onload="alert(1)`;
  hostile.fillStyle = "solid";
  const board = makeBoard("exp", [txt, hostile]);
  const svg = exportBoardToSvg(board, { background: "white" });
  assert.ok(!svg.includes(`red" onload=`), "fill attribute injection escaped");
  // Center-aligned text anchors at x + width/2
  assert.ok(svg.includes('x="250.00"'), "center anchor uses x + width/2");
  // Wikilink rendered as its alias display text, not raw brackets
  assert.ok(svg.includes(">centered shown<"), "wikilink alias text exported");
  assert.ok(!svg.includes("[[Link|shown]]"), "raw wikilink markup not exported");

  // Custom link type color flows through export
  const r1 = makeRect("ca", 0, 0);
  const r2 = makeRect("cb", 400, 0);
  const conn: ConnectionElement = {
    id: "cc", type: "connection", x: 0, y: 0, rotation: 0, opacity: 1,
    source: { boardId: "exp", elementId: "ca", anchor: "auto" },
    target: { boardId: "exp", elementId: "cb", anchor: "auto" },
    linkType: "custom:xyz", routing: "straight", dashStyle: "solid",
    startArrowhead: "arrow", endArrowhead: "arrow", strokeWidth: 2, createdAt: 1, updatedAt: 1,
  };
  const board2 = makeBoard("exp2", [r1, r2, conn]);
  const svg2 = exportBoardToSvg(board2, {}, [{ id: "custom:xyz", name: "My Link", color: "#ff00aa" }]);
  assert.ok(svg2.includes("#ff00aa"), "custom link color used in export");
  // Start arrowhead rendered (both heads present -> at least 2 filled arrow paths)
  const arrowPaths = (svg2.match(/fill="#ff00aa"/g) || []).length;
  assert.ok(arrowPaths >= 2, "start AND end arrowheads exported");

  // Highlighter blend mode preserved
  const hl: StrokeElement = {
    id: "hl", type: "stroke", x: 0, y: 0, rotation: 0, opacity: 1,
    points: [[0, 0, 0.5], [50, 10, 0.5], [100, 20, 0.5]],
    color: "#ffff00", strokeWidth: 20, strokeStyle: "highlighter", createdAt: 1, updatedAt: 1,
  };
  const svg3 = exportBoardToSvg(makeBoard("exp3", [hl]));
  assert.ok(svg3.includes("mix-blend-mode: multiply"), "highlighter multiply blend exported");
}

// ============================================================================
// A10/A10b: rotated stroke & line hit-testing follows visible geometry
// ============================================================================
console.log("[REG-A10] rotated stroke/line hit-test...");
{
  // Stroke along y=0 from x=0..100, rotated 90° about its center -> vertical
  const stroke: StrokeElement = {
    id: "rot", type: "stroke", x: 0, y: 0, rotation: 0, opacity: 1,
    points: [[0, 0, 0.5], [50, 0, 0.5], [100, 0, 0.5]],
    color: "#000", strokeWidth: 6, strokeStyle: "pen", createdAt: 1, updatedAt: 1,
  };
  assert.ok(hitTestElement(stroke, 50, 0, 6), "unrotated stroke hit at midpoint");
  assert.ok(!hitTestElement(stroke, 50, 60, 6), "unrotated stroke miss far away");
  const rotated = { ...stroke, rotation: Math.PI / 2 };
  // After 90° rotation about center (50,0): the stroke runs vertically at x=50
  assert.ok(hitTestElement(rotated, 50, -40, 6), "rotated stroke hit along rotated axis");
  assert.ok(hitTestElement(rotated, 50, 40, 6), "rotated stroke hit other direction");
  assert.ok(!hitTestElement(rotated, 10, 0, 6), "rotated stroke misses its OLD position");

  const line = {
    id: "rl", type: "line" as const, x: 0, y: 0, rotation: 0, opacity: 1,
    x2: 100, y2: 0, strokeColor: "#000", strokeWidth: 4, dashStyle: "solid" as const,
    createdAt: 1, updatedAt: 1,
  };
  const rotatedLine = { ...line, rotation: Math.PI / 2 };
  assert.ok(hitTestElement(rotatedLine, 50, -30, 5), "rotated line hit on rotated axis");
  assert.ok(!hitTestElement(rotatedLine, 10, 0, 5), "rotated line misses old position");
}

// ============================================================================
// A11: lasso polygon containment uses ROTATED corners
// ============================================================================
console.log("[REG-A11] rotated lasso containment...");
{
  const rect = makeRect("r", 0, 0, 100, 100);
  const rotated = { ...rect, rotation: Math.PI / 2 }; // same AABB, same corners for 90°
  // Use 45° so rotated corners differ from AABB corners
  const diag = { ...rect, rotation: Math.PI / 4 };
  // Lasso a small polygon around the top corner of the rotated square.
  // Rotated 45°, the top corner sits at (50, 50 - 70.71) ≈ (50, -20.7)
  const lasso = [
    { x: 40, y: -30 },
    { x: 60, y: -30 },
    { x: 60, y: -10 },
    { x: 40, y: -10 },
  ];
  assert.ok(isElementInPolygon(diag, lasso), "lasso catches rotated corner region");
  // A polygon far from the shape must not contain it
  const far = [{ x: 500, y: 500 }, { x: 600, y: 500 }, { x: 550, y: 600 }];
  assert.ok(!isElementInPolygon(diag, far), "far lasso misses");
  void rotated;
}

// ============================================================================
// B2-equivalent: corrupt persisted payload sanitization happens in migrate()
// (indirect test: the store must never expose a non-array elements list)
// ============================================================================
console.log("[REG-B2] store invariant: elements always an array...");
{
  for (const b of useWhiteboard.getState().boards) {
    assert.ok(Array.isArray(b.elements), `board ${b.id} elements is an array`);
    assert.ok(typeof b.camera.zoom === "number" && b.camera.zoom > 0, `board ${b.id} camera valid`);
  }
}

// ============================================================================
// B1-store: addElementToBoard writes without switching the active board
// ============================================================================
console.log("[REG-D2] addElementToBoard isolation...");
{
  const st = useWhiteboard.getState();
  const keepActive = st.activeBoardId!;
  const target = st.createBoard("bg-write", null);
  useWhiteboard.getState().setActiveBoard(keepActive);
  const before = useWhiteboard.getState();
  const histBefore = before.history.past.length;
  useWhiteboard.getState().addElementToBoard(target, makeRect("bg-el"), false);
  const after = useWhiteboard.getState();
  assert.equal(after.activeBoardId, keepActive, "active board unchanged by background write");
  assert.equal(after.camera, before.camera, "camera untouched");
  assert.ok(after.boards.find((b) => b.id === target)!.elements.some((e) => e.id === "bg-el"), "element written to target board");
  assert.equal(after.history.past.length, histBefore, "history untouched");
}

// ============================================================================
// F1: Link Manager links whose endpoint is a FOLDER must appear in the graph.
// buildGraph used to key edges off endpoint.boardId only, so a board→folder
// link collapsed to a self-loop and was dropped, and a folder→board link was
// drawn from the wrong (board) node. Endpoints now resolve through elementId.
// ============================================================================
console.log("[REG-F1] graph edges resolve folder endpoints...");
{
  const folders: Folder[] = [
    { id: "fRoot", name: "Root", createdAt: 1, parentId: null, expanded: true },
    { id: "fKid", name: "Kid", createdAt: 1, parentId: "fRoot", expanded: true },
  ];
  const mkLink = (id: string, filedOn: string, sourceId: string, targetId: string): ConnectionElement => ({
    id,
    type: "connection",
    x: 0,
    y: 0,
    rotation: 0,
    opacity: 1,
    source: { boardId: filedOn, elementId: sourceId, anchor: "auto" },
    // This mirrors what LinkManager writes: only a BOARD target lands in
    // boardId; a folder (or an on-canvas shape) leaves the storage board's id
    // there, so boardId alone cannot identify the endpoint.
    target: { boardId: targetId.startsWith("b") ? targetId : filedOn, elementId: targetId, anchor: "auto" },
    linkType: "leads_to",
    routing: "curved",
    dashStyle: "solid",
    startArrowhead: "none",
    endArrowhead: "arrow",
    strokeWidth: 2,
    createdAt: 1,
    updatedAt: 1,
  });

  const bA = makeBoard("bA");
  const bB = makeBoard("bB");

  // board -> folder (used to vanish entirely)
  bA.elements = [mkLink("l1", "bA", "bA", "fKid")];
  const g1 = buildGraph([bA, bB], [], folders);
  const e1 = g1.edges.find((e) => e.id === "conn-l1");
  assert.ok(e1, "board→folder link produces a graph edge");
  assert.equal(e1!.source, "bA", "edge starts at the source board");
  assert.equal(e1!.target, "fKid", "edge ends at the FOLDER node");

  // folder -> board (used to start from an arbitrary board inside the folder)
  bA.elements = [mkLink("l2", "bA", "fRoot", "bB")];
  const g2 = buildGraph([bA, bB], [], folders);
  const e2 = g2.edges.find((e) => e.id === "conn-l2");
  assert.ok(e2, "folder→board link produces a graph edge");
  assert.equal(e2!.source, "fRoot", "edge starts at the FOLDER node, not its first board");
  assert.equal(e2!.target, "bB", "edge ends at the target board");

  // folder -> folder
  bA.elements = [mkLink("l3", "bA", "fRoot", "fKid")];
  const g3 = buildGraph([bA, bB], [], folders);
  const e3 = g3.edges.find((e) => e.id === "conn-l3");
  assert.ok(e3, "folder→folder link produces a graph edge");
  assert.equal(e3!.source, "fRoot", "folder→folder source");
  assert.equal(e3!.target, "fKid", "folder→folder target");

  // A plain on-canvas arrow between two shapes on ONE board is NOT a
  // board-level relationship and must stay out of the global graph.
  bA.elements = [mkLink("l4", "bA", "shape-1", "shape-2")];
  const g4 = buildGraph([bA, bB], [], folders);
  assert.equal(
    g4.edges.find((e) => e.id === "conn-l4"),
    undefined,
    "same-board shape-to-shape arrow stays out of the global graph"
  );

  // A custom label overrides the link-type name on the edge.
  const labelled = mkLink("l5", "bA", "bA", "bB");
  labelled.label = "blocks release";
  bA.elements = [labelled];
  const g5 = buildGraph([bA, bB], [], folders);
  assert.equal(
    g5.edges.find((e) => e.id === "conn-l5")!.label,
    "blocks release",
    "custom label wins over the type name"
  );
}

// ============================================================================
// F2: Favorite pens bar — pins are independent (same pen type, different
// colors), reorder is a real move, and applying a pin writes to the ACTIVE
// tool's style fields (not penColor, which the canvas ignores for other pens).
// ============================================================================
console.log("[REG-F2] favorite pens: pin, reorder, apply...");
{
  useWhiteboard.getState().pinnedPens.forEach((p) => useWhiteboard.getState().removePinnedPen(p.id));

  const redHl = useWhiteboard.getState().addPinnedPen({ tool: "highlighter", color: "#ef4444", size: 20 });
  const blueHl = useWhiteboard.getState().addPinnedPen({ tool: "highlighter", color: "#3b82f6", size: 8 });
  const pen = useWhiteboard.getState().addPinnedPen({ tool: "pen", color: "#1e293b", size: 3 });

  assert.equal(useWhiteboard.getState().pinnedPens.length, 3, "three independent pins");
  assert.equal(
    useWhiteboard.getState().pinnedPens.filter((p) => p.tool === "highlighter").length,
    2,
    "same pen type can be pinned twice in different colors"
  );

  // Reorder: move the last pin to the front.
  useWhiteboard.getState().reorderPinnedPens(2, 0);
  assert.deepEqual(
    useWhiteboard.getState().pinnedPens.map((p) => p.id),
    [pen, redHl, blueHl],
    "reorder moves the pin, it does not swap or duplicate"
  );

  // Out-of-range reorders must be no-ops, not corruptions.
  const beforeOrder = useWhiteboard.getState().pinnedPens.map((p) => p.id);
  useWhiteboard.getState().reorderPinnedPens(0, 99);
  useWhiteboard.getState().reorderPinnedPens(-1, 0);
  assert.deepEqual(
    useWhiteboard.getState().pinnedPens.map((p) => p.id),
    beforeOrder,
    "bad indices are ignored"
  );

  // Applying a highlighter pin must set the HIGHLIGHTER's ink — writing the
  // pen's would leave the highlighter drawing its old colour. Asserted through
  // the accessor rather than a named field, so this keeps testing the behaviour
  // if the storage shape changes again.
  useWhiteboard.getState().applyPinnedPen(redHl);
  const applied = useWhiteboard.getState();
  assert.equal(applied.tool, "highlighter", "pin activates its own tool");
  assert.equal(getToolColor(applied.style, "highlighter"), "#ef4444", "colour lands on the highlighter");
  assert.equal(getToolSize(applied.style, "highlighter"), 20, "size lands on the highlighter");
  // ...and must NOT have leaked onto another pen.
  assert.notEqual(getToolColor(applied.style, "gel"), "#ef4444", "another pen's ink is untouched");

  useWhiteboard.getState().applyPinnedPen(blueHl);
  assert.equal(
    getToolColor(useWhiteboard.getState().style, "highlighter"),
    "#3b82f6",
    "second same-type pin switches color"
  );

  // Deleting a pin leaves the rest intact.
  useWhiteboard.getState().removePinnedPen(redHl);
  assert.deepEqual(
    useWhiteboard.getState().pinnedPens.map((p) => p.id),
    [pen, blueHl],
    "removing a pin leaves the others in order"
  );
}

// ============================================================================
// F3: Selection overlay drew its box and resize handles in the wrong place at
// any zoom !== 1. The overlay computes SCREEN coordinates inside the canvas'
// world group, so it must apply the exact inverse of that group's transform.
// The three operations were listed in forward order instead of reversed, which
// composes to the identity only at zoom 1; elsewhere it offsets everything by
// (camera + viewport/2) * (1 - zoom) — handles far from the image they resize.
// ============================================================================
console.log("[REG-F3] selection overlay transform is a true inverse...");
{
  // Parse the transform string and apply it, then apply the canvas' world
  // transform: the round trip must return the original screen point exactly.
  const applyOverlayThenWorld = (
    screen: { x: number; y: number },
    camera: { x: number; y: number; zoom: number },
    viewport: { width: number; height: number }
  ) => {
    const t = screenSpaceOverlayTransform(camera, viewport);
    const nums = t.match(/-?\d+(\.\d+)?(e-?\d+)?/g)!.map(Number);
    const [t1x, t1y, scale, t2x, t2y] = nums;
    // SVG applies a transform list right-to-left.
    const afterT2 = { x: screen.x + t2x, y: screen.y + t2y };
    const afterScale = { x: afterT2.x * scale, y: afterT2.y * scale };
    const local = { x: afterScale.x + t1x, y: afterScale.y + t1y };
    // Canvas world group: translate(vw/2, vh/2) scale(z) translate(-cx, -cy)
    return {
      x: (local.x - camera.x) * camera.zoom + viewport.width / 2,
      y: (local.y - camera.y) * camera.zoom + viewport.height / 2,
    };
  };

  const viewport = { width: 1600, height: 900 };
  const point = { x: 640, y: 380 };
  for (const zoom of [0.25, 0.5, 0.75, 1, 1.5, 2.4, 6]) {
    for (const camera of [
      { x: 0, y: 0, zoom },
      { x: 320, y: -180, zoom },
      { x: -2100, y: 940, zoom },
    ]) {
      const out = applyOverlayThenWorld(point, camera, viewport);
      const drift = Math.hypot(out.x - point.x, out.y - point.y);
      assert.ok(
        drift < 1e-6,
        `overlay transform must round-trip at zoom ${zoom}, camera (${camera.x},${camera.y}) — drift was ${drift.toFixed(2)}px`
      );
    }
  }
}

// ============================================================================
// F4: Undo/redo combos matched on event.key, which carries the SHIFTED/caps
// character. Ctrl+Shift+Z therefore arrived as "Z" and never matched "z", so
// the documented redo combo was dead, and Ctrl+Z stopped undoing with Caps
// Lock on. Matching moved to event.code (the physical key).
// ============================================================================
console.log("[REG-F4] undo/redo key combos (case + layout safe)...");
{
  const ev = (code: string, mods: Partial<ComboEvent> = {}): ComboEvent => ({
    code,
    ctrlKey: true,
    metaKey: false,
    shiftKey: false,
    ...mods,
  });

  assert.ok(isUndoCombo(ev("KeyZ")), "Ctrl+Z undoes");
  assert.ok(isUndoCombo({ ...ev("KeyZ"), ctrlKey: false, metaKey: true }), "Cmd+Z undoes");
  assert.ok(!isUndoCombo(ev("KeyZ", { shiftKey: true })), "Ctrl+Shift+Z is NOT undo");
  assert.ok(!isUndoCombo({ ...ev("KeyZ"), ctrlKey: false }), "bare Z is not undo");

  assert.ok(isRedoCombo(ev("KeyY")), "Ctrl+Y redoes");
  assert.ok(isRedoCombo({ ...ev("KeyY"), ctrlKey: false, metaKey: true }), "Cmd+Y redoes");
  assert.ok(
    isRedoCombo(ev("KeyZ", { shiftKey: true })),
    "Ctrl+Shift+Z redoes — this is the combo that was dead"
  );
  assert.ok(!isRedoCombo(ev("KeyZ")), "plain Ctrl+Z is not redo");
  assert.ok(!isRedoCombo({ ...ev("KeyY"), ctrlKey: false }), "bare Y is not redo");

  // Undo and redo must never both claim the same event.
  for (const code of ["KeyZ", "KeyY"]) {
    for (const shiftKey of [true, false]) {
      const e = ev(code, { shiftKey });
      assert.ok(
        !(isUndoCombo(e) && isRedoCombo(e)),
        `${code}${shiftKey ? "+Shift" : ""} must not match both undo and redo`
      );
    }
  }
}

// ============================================================================
// F5: Workspace backup/restore/merge — the rules that decide whether work
// survives syncing the same account on two devices.
// ============================================================================
console.log("[REG-F5] workspace backup + per-board sync merge...");
{
  const snap = (boards: Board[], folders: Folder[] = []) => ({
    folders,
    boards,
    activeBoardId: boards[0]?.id ?? null,
    activeFolderId: null,
    customLinkTypes: [] as Array<{ id: string; name: string; color: string }>,
  });
  const board = (id: string, updatedAt: number, elements: WhiteboardElement[] = []): Board => ({
    ...makeBoard(id, elements),
    updatedAt,
  });

  // --- round trip -----------------------------------------------------------
  const original = snap([board("b1", 100, [makeRect("r1", 5, 6)])]);
  const restored = parseWorkspace(serializeWorkspace(original, "test device"));
  assert.equal(restored.boards.length, 1, "round trip keeps the board");
  assert.equal(restored.boards[0].elements.length, 1, "round trip keeps elements");
  assert.equal((restored.boards[0].elements[0] as RectangleElement).x, 5, "element data intact");

  // --- rejects foreign / corrupt files --------------------------------------
  assert.throws(() => parseWorkspace("not json"), WorkspaceParseError, "rejects non-JSON");
  assert.throws(
    () => parseWorkspace(JSON.stringify({ app: "something-else", format: 1, boards: [] })),
    WorkspaceParseError,
    "rejects a file from another app"
  );
  assert.throws(
    () => parseWorkspace(JSON.stringify({ app: "pronotes", format: 99, boards: [] })),
    WorkspaceParseError,
    "rejects a backup from a newer version"
  );

  // --- the merge that matters ------------------------------------------------
  // Board A edited only locally, board B edited only remotely: BOTH must
  // survive. Whole-document last-write-wins would destroy one of them.
  const local = snap([board("A", 200), board("B", 100)]);
  const remote = snap([board("A", 100), board("B", 300), board("C", 50)]);
  const { merged, report } = mergeWorkspaces(local, remote);

  const byId = new Map(merged.boards.map((b) => [b.id, b]));
  assert.equal(byId.size, 3, "union of both devices' boards");
  assert.equal(byId.get("A")!.updatedAt, 200, "locally-newer board keeps the LOCAL version");
  assert.equal(byId.get("B")!.updatedAt, 300, "remotely-newer board takes the REMOTE version");
  assert.ok(byId.has("C"), "board that exists only remotely is pulled in");
  assert.equal(report.added, 1, "one board added");
  assert.equal(report.updatedFromRemote, 1, "one board updated from remote");
  assert.equal(report.keptLocal, 1, "one board kept local");

  // The device keeps looking at whatever it was looking at.
  assert.equal(merged.activeBoardId, "A", "active board preserved across a merge");

  // Custom link types are unioned — losing one would render its connections
  // as unlabelled grey lines on the device that lost it.
  const l2 = { ...snap([board("A", 1)]), customLinkTypes: [{ id: "c1", name: "L", color: "#111" }] };
  const r2 = { ...snap([board("A", 1)]), customLinkTypes: [{ id: "c2", name: "R", color: "#222" }] };
  const merged2 = mergeWorkspaces(l2, r2).merged;
  assert.equal(merged2.customLinkTypes!.length, 2, "custom link types are unioned, never dropped");

  // A merge must never lose a board that only one side has, in either direction.
  const onlyLocal = mergeWorkspaces(snap([board("X", 1)]), snap([])).merged;
  assert.ok(onlyLocal.boards.some((b) => b.id === "X"), "empty remote does not wipe local boards");
}

// ============================================================================
// F6: A tapered stroke end is emitted by perfect-freehand as SEVERAL
// COINCIDENT vertices. Zero-length edges have no defined angle, so the
// sharp-corner test bailed out and the tip was smoothed away — the stroke
// finished in a flat chisel cut instead of a point. Duplicates are now
// collapsed before the path is built.
// ============================================================================
console.log("[REG-F6] stroke ends finish in a point, not a flat cut...");
{
  // An outline converging to a point via three coincident vertices, exactly as
  // perfect-freehand emits for a tapered end.
  const tip: number[] = [100, 0];
  const outline: number[][] = [
    [0, 20],
    [50, 14],
    tip,
    [...tip],
    [...tip],
    [50, -14],
    [0, -20],
  ];
  const path = getSvgPathFromStroke(outline, true);
  assert.ok(
    path.includes(`L ${tip[0].toFixed(2)},${tip[1].toFixed(2)}`),
    "the tip must be an on-curve point, not rounded off into a flat end"
  );

  // A smooth outline must still be fully curved, so collapsing duplicates
  // cannot regress into faceting ordinary strokes.
  const circle: number[][] = [];
  for (let i = 0; i < 40; i++) {
    circle.push([Math.cos((i / 40) * Math.PI * 2) * 60, Math.sin((i / 40) * Math.PI * 2) * 60]);
  }
  assert.equal(
    (getSvgPathFromStroke(circle, true).match(/ L /g) || []).length,
    0,
    "a smooth outline still uses no straight segments"
  );

  // Degenerate input (every point identical) must not crash or emit NaN.
  const degenerate = [
    [5, 5],
    [5, 5],
    [5, 5],
    [5, 5],
  ];
  assert.ok(
    !getSvgPathFromStroke(degenerate, true).includes("NaN"),
    "coincident-only outline produces no NaN"
  );
}

// ============================================================================
// F7: Tool setup and preferences were never persisted. Pen colours/sizes, font
// size, sticky colour, snap-to-grid, the minimap, the favourites bar and — on a
// tablet, most painfully — the stylus mode all reset to defaults on every
// launch, because getPersistedState() omitted them and their setters never
// scheduled a save.
// ============================================================================
console.log("[REG-F7] tool setup and preferences survive a restart...");
{
  const st = useWhiteboard.getState();

  st.setStyle({ fontSize: 42, penColor: "#ff00aa", penSize: 19, stickyColor: "green" });
  st.setTouchSettings({ mode: "stylus-only", palmRejection: true });
  if (!useWhiteboard.getState().snapToGrid) useWhiteboard.getState().toggleSnapToGrid();

  const persisted = useWhiteboard.getState().getPersistedState();

  // Everything the user configured must be in the saved payload.
  assert.equal(persisted.style?.fontSize, 42, "font size is saved");
  assert.equal(persisted.style?.penColor, "#ff00aa", "pen colour is saved");
  assert.equal(persisted.style?.penSize, 19, "pen size is saved");
  assert.equal(persisted.style?.stickyColor, "green", "sticky colour is saved");
  assert.equal(persisted.touchSettings?.mode, "stylus-only", "stylus mode is saved");
  assert.equal(persisted.touchSettings?.palmRejection, true, "palm rejection is saved");
  assert.equal(persisted.snapToGrid, true, "snap-to-grid is saved");
  assert.equal(typeof persisted.minimapOpen, "boolean", "minimap visibility is saved");
  assert.equal(typeof persisted.pinnedBarOpen, "boolean", "favourites bar visibility is saved");

  // A save produced now must round-trip through the loader's validation.
  const reloaded = migrateState(persisted as never) as typeof persisted;
  assert.equal(reloaded.style?.fontSize, 42, "font size survives migrate()");
  assert.equal(reloaded.touchSettings?.mode, "stylus-only", "stylus mode survives migrate()");
  assert.equal(reloaded.snapToGrid, true, "snap-to-grid survives migrate()");

  // Corrupt preferences must be dropped, not merged in — init() falls back to
  // the defaults for anything that comes back undefined.
  const corruptInput = {
    ...(persisted as unknown as Record<string, unknown>),
    style: "not an object",
    touchSettings: 42,
    tool: "definitely-not-a-tool",
    snapToGrid: "yes",
  };
  const corrupt = migrateState(corruptInput as never) as typeof persisted;
  assert.equal(corrupt.style, undefined, "a non-object style is dropped");
  assert.equal(corrupt.touchSettings, undefined, "non-object touch settings are dropped");
  assert.equal(corrupt.tool, undefined, "an unknown tool is dropped");
  assert.equal(corrupt.snapToGrid, undefined, "a non-boolean toggle is dropped");
}

// ============================================================================
// F8: Pixel eraser. Point-sampling failed in ways that made the eraser feel
// broken, all measured on a stroke with 30px point spacing:
//   - an eraser passing BETWEEN two recorded points erased nothing;
//   - a 24px eraser removed 60px of stroke, because a cut could only land on
//     an existing point;
//   - only the CURRENT position was tested, so a fast drag skipped gaps.
// The eraser is now a swept capsule and each segment is clipped analytically.
// ============================================================================
console.log("[REG-F8] pixel eraser clips segments along the swept path...");
{
  // Deliberately sparse, like a quickly drawn stroke.
  const sparse: Array<[number, number, number]> = [];
  for (let x = 0; x <= 300; x += 30) sparse.push([x, 0, 0.5]);

  // 1. An eraser BETWEEN two recorded points must still cut.
  assert.ok(
    eraseFromStroke(sparse, 15, 0, 15, 0, 12),
    "an eraser between two recorded points must still erase"
  );

  // 2. The cut must land at the eraser's EDGE, not on a recorded point.
  const cut = eraseFromStroke(sparse, 150, 0, 150, 0, 12);
  assert.equal(cut!.length, 2, "erasing the middle splits the stroke in two");
  const leftEnd = cut![0][cut![0].length - 1][0];
  const rightStart = cut![1][0][0];
  assert.ok(
    Math.abs(leftEnd - 138) < 0.5 && Math.abs(rightStart - 162) < 0.5,
    `cut must land on the eraser edge (138/162), got ${leftEnd}/${rightStart}`
  );
  assert.ok(
    rightStart - leftEnd < 25,
    `a 24px eraser must not remove ${(rightStart - leftEnd).toFixed(0)}px of stroke`
  );

  // 3. A fast drag erases the whole swept path, not just its end.
  assert.deepEqual(
    eraseFromStroke(sparse, 0, 0, 300, 0, 12),
    [],
    "a drag along the stroke erases all of it"
  );

  // Erasing one end trims it and leaves a single piece.
  const trimmed = eraseFromStroke(sparse, 0, 0, 0, 0, 25);
  assert.equal(trimmed!.length, 1, "erasing an end leaves one piece");
  assert.ok(trimmed![0][0][0] >= 24.9, "the erased end is gone up to the eraser edge");

  // A miss reports no change, so an erase drag over empty canvas does no work.
  assert.equal(
    eraseFromStroke(sparse, 0, 400, 300, 400, 12),
    null,
    "a miss reports no change"
  );

  // A perpendicular sweep across the stroke cuts it, even between points.
  const across = eraseFromStroke(sparse, 15, -50, 15, 50, 5);
  assert.ok(across && across.length === 2, "a sweep across the line splits it");

  // Surviving fragments must never be a single stray point.
  const short: Array<[number, number, number]> = [
    [0, 0, 0.5],
    [10, 0, 0.5],
    [100, 0, 0.5],
  ];
  assert.ok(
    (eraseFromStroke(short, 5, 0, 5, 0, 12) ?? []).every((run) => run.length >= 2),
    "single-point fragments are discarded, not left as dots"
  );

  // Direction independence: the cut width must depend on the eraser SIZE and
  // how far it travelled, never on the angle between eraser and stroke.
  const gapOf = (runs: Array<Array<[number, number, number]>> | null): number => {
    if (!runs || runs.length < 2) return -1;
    const a = runs[0][runs[0].length - 1];
    const b = runs[1][0];
    return Math.hypot(b[0] - a[0], b[1] - a[1]);
  };
  const R = 12;
  const horiz: Array<[number, number, number]> = [];
  for (let x = 0; x <= 300; x += 30) horiz.push([x, 0, 0.5]);
  const vert: Array<[number, number, number]> = [];
  for (let y = 0; y <= 300; y += 30) vert.push([0, y, 0.5]);
  const diag: Array<[number, number, number]> = [];
  for (let i = 0; i <= 10; i++) diag.push([i * 30, i * 30, 0.5]);

  // A STATIONARY eraser cuts exactly its own diameter, whatever the stroke's
  // orientation — this is what "direction must not matter" means.
  for (const [name, pts, x, y] of [
    ["horizontal", horiz, 150, 0],
    ["vertical", vert, 0, 150],
    ["diagonal", diag, 150, 150],
  ] as const) {
    const g = gapOf(eraseFromStroke(pts, x, y, x, y, R));
    assert.ok(
      Math.abs(g - 2 * R) < 1.5,
      `${name} stroke: a stationary eraser must cut its own diameter (${2 * R}px), got ${g.toFixed(1)}px`
    );
  }

  // A sweep ACROSS a stroke also cuts one diameter — the travel is
  // perpendicular, so it must not widen the cut.
  assert.ok(
    Math.abs(gapOf(eraseFromStroke(horiz, 150, -40, 150, 40, R)) - 2 * R) < 1.5,
    "a perpendicular sweep cuts exactly the eraser's diameter"
  );

  // A sweep ALONG a stroke removes travel + diameter, because that is the area
  // the eraser actually passed over.
  const along = gapOf(eraseFromStroke(horiz, 140, 0, 160, 0, R));
  assert.ok(
    Math.abs(along - (20 + 2 * R)) < 1.5,
    `a 20px sweep along the stroke removes 20+${2 * R}px, got ${along.toFixed(1)}px`
  );

  // A dot (single-point stroke) is removed only when actually touched.
  const dot: Array<[number, number, number]> = [[50, 50, 0.5]];
  assert.deepEqual(eraseFromStroke(dot, 50, 50, 50, 50, 10), [], "a touched dot is erased");
  assert.equal(
    eraseFromStroke(dot, 200, 200, 200, 200, 10),
    null,
    "an untouched dot is left alone"
  );
}

// ============================================================================
// F9: Wheel input. deltaMode was never read, so Firefox's LINE units (3 per
// notch) were treated as 3 pixels — the wheel felt inert and pinch-zoom crawled
// at 0.2% per event. Pinch also has to be recognised: browsers deliver a
// trackpad pinch as a wheel event with ctrlKey set.
// ============================================================================
console.log("[REG-F9] wheel input: units, pinch, and mouse vs trackpad...");
{
  const ev = (o: Partial<RawWheel>): RawWheel => ({
    deltaX: 0,
    deltaY: 0,
    deltaMode: 0,
    ctrlKey: false,
    metaKey: false,
    shiftKey: false,
    ...o,
  });

  // Line and page units are converted to pixels.
  assert.equal(normalizeWheelDelta(ev({ deltaY: 3, deltaMode: 1 })).dy, 48, "3 lines = 48px");
  assert.equal(normalizeWheelDelta(ev({ deltaY: 1, deltaMode: 2 })).dy, 800, "1 page = 800px");
  assert.equal(normalizeWheelDelta(ev({ deltaY: 100, deltaMode: 0 })).dy, 100, "pixels pass through");

  // A Firefox notch must move the canvas comparably to a Chrome notch, rather
  // than 3px vs 100px.
  const chromeNotch = resolveWheelAction(ev({ deltaY: 100 }), "trackpad");
  const firefoxNotch = resolveWheelAction(ev({ deltaY: 3, deltaMode: 1 }), "trackpad");
  assert.equal(chromeNotch.kind, "pan");
  assert.equal(firefoxNotch.kind, "pan");
  const ratio =
    (firefoxNotch as { dy: number }).dy / (chromeNotch as { dy: number }).dy;
  assert.ok(ratio > 0.3 && ratio < 3, `notch sizes must be comparable, got ratio ${ratio}`);

  // A pinch always zooms, in every mode.
  for (const mode of ["auto", "trackpad", "mouse"] as const) {
    assert.equal(
      resolveWheelAction(ev({ deltaY: -8, ctrlKey: true }), mode).kind,
      "zoom",
      `pinch zooms in ${mode} mode`
    );
  }

  // Zooming is symmetric: in then out returns exactly to the start, or the
  // canvas drifts every time the user scrubs the wheel.
  const zin = resolveWheelAction(ev({ deltaY: -120, ctrlKey: true }), "auto");
  const zout = resolveWheelAction(ev({ deltaY: 120, ctrlKey: true }), "auto");
  const roundTrip =
    (zin as { factor: number }).factor * (zout as { factor: number }).factor;
  assert.ok(Math.abs(roundTrip - 1) < 1e-9, `zoom in then out must return to 1, got ${roundTrip}`);

  // Mode behaviour.
  assert.equal(
    resolveWheelAction(ev({ deltaY: 100 }), "mouse").kind,
    "zoom",
    "in mouse mode the wheel zooms"
  );
  assert.equal(
    resolveWheelAction(ev({ deltaY: 4.2, deltaX: 1.1 }), "trackpad").kind,
    "pan",
    "in trackpad mode two-finger scroll pans"
  );

  // Auto-detection: a quantised vertical-only step is a wheel; small
  // fractional deltas with sideways drift are a trackpad.
  assert.ok(looksLikeMouseWheel(ev({ deltaY: 100 })), "100px vertical step is a wheel");
  assert.ok(!looksLikeMouseWheel(ev({ deltaY: 4.2, deltaX: 1.1 })), "fractional drift is a trackpad");
  assert.ok(looksLikeMouseWheel(ev({ deltaY: 3, deltaMode: 1 })), "line units only come from a wheel");

  // Shift scrolls sideways on a device with only a vertical wheel.
  const sideways = resolveWheelAction(ev({ deltaY: 100, shiftKey: true }), "trackpad");
  assert.equal(sideways.kind, "pan");
  assert.equal((sideways as { dx: number }).dx, 100, "shift moves the vertical delta to X");
  assert.equal((sideways as { dy: number }).dy, 0, "shift leaves no vertical movement");
}

// ============================================================================
// F10: Paper size is per board and must survive a reload — and be clamped. A
// size of 0 or NaN would make the SVG pattern tile infinitely small and lock
// the renderer, so a corrupt value must never reach the canvas.
// ============================================================================
console.log("[REG-F10] board paper size persists and is clamped...");
{
  const st = useWhiteboard.getState();
  const boardId = st.createBoard("paper-size-board", null);

  useWhiteboard.getState().setBoardBackground(boardId, { pattern: "grid", size: 64 });
  const saved = useWhiteboard.getState().getPersistedState();
  const savedBoard = saved.boards.find((b) => b.id === boardId)!;
  assert.equal(savedBoard.background?.size, 64, "paper size is saved");
  assert.equal(savedBoard.background?.pattern, "grid", "pattern is saved alongside it");

  // Each board keeps its own paper: setting one board must not leak into
  // another. (New boards start with the app default paper, so "own paper"
  // now means the untouched default, not undefined.)
  const other = useWhiteboard.getState().createBoard("other-paper", null);
  const otherSaved = useWhiteboard
    .getState()
    .getPersistedState()
    .boards.find((b) => b.id === other)!;
  assert.equal(otherSaved.background?.pattern, "plain", "a different board keeps its own paper");
  assert.equal(
    otherSaved.background?.size,
    undefined,
    "untouched by the other board's 64px spacing"
  );

  // Round trip through the loader's validation.
  const reloaded = migrateState(saved as never) as typeof saved;
  assert.equal(
    reloaded.boards.find((b) => b.id === boardId)!.background?.size,
    64,
    "paper size survives migrate()"
  );

  // Values that would break the renderer are clamped, not passed through.
  const corrupt = migrateState({
    ...(saved as unknown as Record<string, unknown>),
    boards: saved.boards.map((b) =>
      b.id === boardId ? { ...b, background: { pattern: "grid", size: 0 } } : b
    ),
  } as never) as typeof saved;
  const clamped = corrupt.boards.find((b) => b.id === boardId)!.background?.size;
  assert.ok(
    clamped !== undefined && clamped >= 6,
    `a zero paper size must be clamped to a usable value, got ${clamped}`
  );

  const nan = migrateState({
    ...(saved as unknown as Record<string, unknown>),
    boards: saved.boards.map((b) =>
      b.id === boardId ? { ...b, background: { pattern: "grid", size: Number.NaN } } : b
    ),
  } as never) as typeof saved;
  assert.equal(
    nan.boards.find((b) => b.id === boardId)!.background?.size,
    undefined,
    "a NaN paper size is dropped so the default applies"
  );
}

// ============================================================================
// F11 (security): the export preview renders the produced SVG through
// dangerouslySetInnerHTML, so hostile board text must not be able to introduce
// an element or an event handler. innerHTML does NOT execute <script>, but it
// DOES fire handlers such as <img onerror>, so escaping is the whole defence.
// ============================================================================
console.log("[REG-F11] export escapes hostile text (no injectable handlers)...");
{
  const payloads = [
    `</text><img src=x onerror="alert(1)">`,
    `"><svg onload="alert(1)">`,
    `</tspan></text><foreignObject><body onload="alert(1)">`,
    `<script>alert(1)</script>`,
  ];

  const board = makeBoard("xss-board");
  board.elements = payloads.map((text, i): TextElement => ({
    id: `x${i}`,
    type: "text",
    x: i * 10,
    y: i * 10,
    width: 200,
    height: 40,
    rotation: 0,
    opacity: 1,
    text,
    color: "#000000",
    fontSize: 16,
    fontFamily: "sans-serif",
    fontWeight: 400,
    align: "left",
    createdAt: 1,
    updatedAt: 1,
  }));

  const svg = exportBoardToSvg(board, { background: "white" });
  const tags = [...svg.matchAll(/<([a-zA-Z][^\s/>]*)([^>]*)>/g)];

  // Escaped text legitimately CONTAINS the characters "onerror=", so assert on
  // parsed tags rather than on substrings anywhere in the document — a naive
  // substring check reports a false positive here.
  const withHandler = tags.filter((m) => / on[a-z]+\s*=/i.test(m[2]));
  assert.equal(withHandler.length, 0, "no exported tag may carry an on* event handler");

  const injected = tags.filter((m) => /^(img|script|body|iframe)$/i.test(m[1]));
  assert.equal(injected.length, 0, "hostile text must not introduce new elements");

  for (const p of payloads) {
    assert.ok(!svg.includes(p), `payload must be escaped, not emitted raw: ${p.slice(0, 24)}`);
  }
}

// ============================================================================
// F12: element-level graph vertices. A link lives in a specific text box, so
// that box is the vertex — the graph must show WHICH note points at the target,
// and clicking it must be able to reach the object itself.
// ============================================================================
console.log("[REG-F12] element vertices, shapes and navigation ids...");
{
  const note = (id: string, text: string): TextElement => ({
    id, type: "text", x: 40, y: 60, width: 200, height: 80,
    rotation: 0, opacity: 1, text, color: "#000", fontSize: 16,
    fontFamily: "sans-serif", fontWeight: 400, align: "left",
    createdAt: 1, updatedAt: 1,
  });

  const source = makeBoard("bSrc");
  source.name = "Source";
  const target = makeBoard("bTgt");
  target.name = "Physics";
  source.elements = [note("n1", "see [[Physics|the notes]] here"), note("n2", "unrelated")];

  const g = buildGraph([source, target], [], []);

  // The vertex is the NOTE, not the board.
  const wl = g.edges.find((e) => e.linkType === "wikilink")!;
  assert.ok(wl, "the wikilink produces an edge");
  assert.equal(wl.source, elementNodeId("bSrc", "n1"), "edge starts at the note that holds the link");
  assert.equal(wl.target, "bTgt", "edge ends at the linked board");
  assert.equal(wl.label, "the notes", "edge is labelled with the link's display alias");

  // That vertex exists, is typed, and knows where it lives.
  const elNode = g.nodes.find((n) => n.id === elementNodeId("bSrc", "n1"))!;
  assert.ok(elNode, "the linking element has its own vertex");
  assert.equal(elNode.kind, "element", "vertex is marked as an element");
  assert.equal(elNode.elementType, "text", "vertex carries its type so it can be drawn as one");
  assert.equal(elNode.boardId, "bSrc", "vertex knows its board");
  assert.equal(elNode.elementId, "n1", "vertex knows its element");
  assert.ok(elNode.name.includes("the notes"), "label shows display text, not raw [[markup]]");
  assert.ok(!elNode.name.includes("[["), "raw wikilink markup never reaches the label");

  // A note with no links must NOT become a vertex, or the graph fills with noise.
  assert.equal(
    g.nodes.find((n) => n.id === elementNodeId("bSrc", "n2")),
    undefined,
    "an element with no links stays out of the graph"
  );

  // Element vertices hang off their board rather than floating unattached.
  assert.ok(
    g.edges.some((e) => e.source === "bSrc" && e.target === elementNodeId("bSrc", "n1")),
    "board owns its element vertex"
  );

  // The id round-trips, which is what makes click-to-navigate possible.
  const parsed = parseElementNodeId(elementNodeId("bSrc", "n1"))!;
  assert.deepEqual(parsed, { boardId: "bSrc", elementId: "n1" }, "element node id round-trips");
  assert.equal(parseElementNodeId("bSrc"), null, "a board id is not mistaken for an element id");

  // An on-canvas arrow between two shapes now shows as element-to-element,
  // where it used to collapse into a self-loop and vanish.
  const canvas = makeBoard("bCanvas");
  const r1 = makeRect("r1", 0, 0);
  const r2 = makeRect("r2", 300, 0);
  const arrow: ConnectionElement = {
    id: "c1", type: "connection", x: 0, y: 0, rotation: 0, opacity: 1,
    source: { boardId: "bCanvas", elementId: "r1", anchor: "auto" },
    target: { boardId: "bCanvas", elementId: "r2", anchor: "auto" },
    linkType: "relates", routing: "curved", dashStyle: "solid",
    startArrowhead: "none", endArrowhead: "arrow", strokeWidth: 2,
    createdAt: 1, updatedAt: 1,
  };
  canvas.elements = [r1, r2, arrow];
  const g2 = buildGraph([canvas], [], []);
  const connEdge = g2.edges.find((e) => e.id === "conn-c1")!;
  assert.ok(connEdge, "same-board shape-to-shape arrow now appears");
  assert.equal(connEdge.source, elementNodeId("bCanvas", "r1"), "arrow starts at the source shape");
  assert.equal(connEdge.target, elementNodeId("bCanvas", "r2"), "arrow ends at the target shape");
  assert.equal(
    g2.nodes.find((n) => n.id === elementNodeId("bCanvas", "r1"))!.elementType,
    "rectangle",
    "shape vertices carry their own type"
  );
}

// ============================================================================
// F13: focusElement centres the camera ON the object and selects it.
// ============================================================================
console.log("[REG-F13] focusElement lands on the object, not the board...");
{
  const st = useWhiteboard.getState();
  const boardId = st.createBoard("focus-target", null);
  const far = makeRect("far-rect", 4000, 2500, 200, 100);
  useWhiteboard.getState().addElementToBoard(boardId, far, false);

  // Stand somewhere else entirely, on another board.
  const other = useWhiteboard.getState().createBoard("elsewhere", null);
  useWhiteboard.getState().setActiveBoard(other);

  useWhiteboard.getState().focusElement(boardId, "far-rect");
  const after = useWhiteboard.getState();

  assert.equal(after.activeBoardId, boardId, "switches to the element's board");
  // The camera is the world point at the viewport centre, so centring means
  // camera === the element's centre.
  assert.equal(after.camera.x, 4100, "camera centred on the element's x");
  assert.equal(after.camera.y, 2550, "camera centred on the element's y");
  assert.deepEqual(after.selectedIds, ["far-rect"], "the element is selected on arrival");
  assert.ok(after.camera.zoom >= 0.6, "never arrives so zoomed out the element is a speck");

  // A missing element must be a no-op, not a jump to (0,0).
  const before = useWhiteboard.getState().camera;
  useWhiteboard.getState().focusElement(boardId, "does-not-exist");
  assert.deepEqual(useWhiteboard.getState().camera, before, "unknown element leaves the camera alone");
}

// ============================================================================
// F14: "switch away from my pen and back and my settings reset."
// FOUR separate causes, all from hand-written lists that were not updated when
// the pen set grew from 6 to 8. Each is pinned here.
// ============================================================================
console.log("[REG-F14] per-pen ink is independent and survives a round trip...");
{
  // (1) Every pen must have its OWN ink. ballpoint/gel/fineliner/fountain had
  //     no case in the accessor switch and all fell through to `strokeColor`,
  //     sharing one colour and size with each other AND with shape borders.
  const base = useWhiteboard.getState().style;
  let style = { ...base };
  const paint = (tool: ToolType, color: string, size: number) => {
    style = { ...style, ...setToolInk(style, tool, { color, size }) };
  };

  paint("ballpoint" as ToolType, "#111111", 3);
  paint("gel" as ToolType, "#222222", 5);
  paint("fineliner" as ToolType, "#333333", 2);
  paint("fountain" as ToolType, "#444444", 7);
  paint("highlighter" as ToolType, "#ffff00", 24);

  assert.equal(getToolColor(style, "ballpoint" as ToolType), "#111111", "ballpoint keeps its own colour");
  assert.equal(getToolColor(style, "gel" as ToolType), "#222222", "gel keeps its own colour");
  assert.equal(getToolColor(style, "fineliner" as ToolType), "#333333", "fineliner keeps its own colour");
  assert.equal(getToolColor(style, "fountain" as ToolType), "#444444", "fountain keeps its own colour");
  assert.equal(getToolSize(style, "fountain" as ToolType), 7, "fountain keeps its own size");
  assert.equal(getToolSize(style, "fineliner" as ToolType), 2, "fineliner keeps its own size");

  // A pen must never write through to the SHAPE border, which is what the
  // fall-through did.
  assert.notEqual(style.strokeColor, "#444444", "pen ink does not leak into shape borders");

  // Every pen offered in the picker must be independently addressable — this is
  // the assertion that fails the moment someone adds a pen and forgets the map.
  const inks = new Set(PEN_TYPES.map((t) => getToolColor(style, t as ToolType) + "/" + getToolSize(style, t as ToolType)));
  assert.equal(inks.size >= 6, true, "the pens do not collapse onto shared ink");

  // (2) setToolInk writes colour and size in ONE patch. Two separate patches
  //     spread together would both carry `toolInk` and the second would win,
  //     silently dropping the colour.
  const both = setToolInk(style, "brush" as ToolType, { color: "#abcdef", size: 19 });
  const merged = { ...style, ...both };
  assert.equal(getToolColor(merged, "brush" as ToolType), "#abcdef", "combined patch keeps the colour");
  assert.equal(getToolSize(merged, "brush" as ToolType), 19, "combined patch keeps the size");

  // (3) A saved payload must survive migrate(). The tool whitelist was
  //     hand-written and still named only the pre-rework pens, so a saved
  //     `tool: "fountain"` was rejected and the pen reset on every reload.
  const savedFountain = migrateState({
    version: 1, folders: [], boards: [], activeBoardId: null, activeFolderId: null,
    tool: "fountain" as ToolType,
  } as Parameters<typeof migrateState>[0]);
  assert.equal(savedFountain.tool, "fountain", "a saved new-generation pen survives a reload");

  // (4) A pinned pen of a new generation must survive too — the pin whitelist
  //     had the same stale list, so pinning a gel pen DELETED it on reload.
  const savedPins = migrateState({
    version: 1, folders: [], boards: [], activeBoardId: null, activeFolderId: null,
    pinnedPens: [
      { id: "p1", tool: "gel", color: "#123456", size: 4 },
      { id: "p2", tool: "fountain", color: "#654321", size: 6 },
      { id: "p3", tool: "not-a-pen", color: "#000000", size: 4 },
    ],
  } as unknown as Parameters<typeof migrateState>[0]);
  const keptTools = (savedPins.pinnedPens ?? []).map((p) => p.tool);
  assert.deepEqual(keptTools, ["gel", "fountain"], "new-generation pins survive; junk is still rejected");
}

// ============================================================================
// F15: reaching for "the pen" returns the pen you were last holding.
// ============================================================================
console.log("[REG-F15] the pen button restores your pen, not a default...");
{
  useWhiteboard.getState().setTool("fountain" as ToolType);
  assert.equal(useWhiteboard.getState().lastStrokeTool, "fountain", "the pen in hand is remembered");

  useWhiteboard.getState().setTool("eraser");
  assert.equal(
    useWhiteboard.getState().lastStrokeTool,
    "fountain",
    "a non-drawing tool does not overwrite the remembered pen"
  );

  useWhiteboard.getState().setTool("select");
  useWhiteboard.getState().setTool(useWhiteboard.getState().lastStrokeTool);
  assert.equal(useWhiteboard.getState().tool, "fountain", "returning to the pen returns to FOUNTAIN");
}

// ============================================================================
// F16: a hand resting on the glass must not select, move or resize anything.
//
// The reported symptom: a palm coming down on a line of already-typed text
// opened the transform box mid-sentence. The canvas only suppressed touch
// while the nib was actually ON the glass, which misses both ways a palm
// really arrives — it lands BEFORE you start writing, and it stays down while
// you lift the pen between words.
// ============================================================================
console.log("[REG-F16] palm rejection and deliberate touch...");
{
  const finger = { width: 20, height: 22 };
  const palmEdge = { width: 30, height: 70 };
  const unknown = { width: 1, height: 1 };
  const T = 100_000; // an arbitrary "now"

  // -- the pen is decisive ---------------------------------------------------
  assert.equal(
    classifyTouch(finger, { penDown: true, lastPenAt: T, now: T }),
    "pen-down",
    "a touch while the nib is down is a palm"
  );

  // THE BUG: the pen lifts between words and the hand stays put. The old guard
  // went false the instant the nib left the glass, so every palm contact in
  // that gap reached the select tool and grabbed whatever it rested on.
  assert.equal(
    classifyTouch(finger, { penDown: false, lastPenAt: T - 200, now: T }),
    "pen-recent",
    "a touch 200ms after the pen lifted is still the same resting hand"
  );
  assert.equal(
    classifyTouch(finger, { penDown: false, lastPenAt: T - (PEN_SUPPRESSION_MS - 1), now: T }),
    "pen-recent",
    "suppression holds right up to the edge of the window"
  );
  assert.equal(
    classifyTouch(finger, { penDown: false, lastPenAt: T - PEN_SUPPRESSION_MS, now: T }),
    "allow",
    "and releases exactly at the window, so the pen never locks touch out"
  );

  // -- no stylus, no cost ----------------------------------------------------
  // This is what lets palm rejection be always-on rather than a setting nobody
  // finds: a device that has never seen a pen can never open the window.
  assert.equal(
    classifyTouch(finger, { penDown: false, lastPenAt: 0, now: T }),
    "allow",
    "a pure-touch device is completely unaffected by the pen rules"
  );

  // -- contact geometry ------------------------------------------------------
  assert.equal(contactLooksLikePalm(palmEdge), true, "the edge of a hand is a palm");
  assert.equal(contactLooksLikePalm(finger), false, "a fingertip is not");
  assert.equal(
    contactLooksLikePalm(unknown),
    false,
    "1x1 is the spec default for 'cannot measure' — abstain, do not call it a fingertip"
  );
  assert.equal(contactLooksLikePalm({}), false, "a browser reporting nothing must not reject");
  assert.equal(
    contactLooksLikePalm({ width: 8, height: PALM_CONTACT_PX }),
    true,
    "a palm reports a long thin ellipse, so the LARGER dimension decides"
  );
  assert.equal(
    classifyTouch(palmEdge, { penDown: false, lastPenAt: 0, now: T }),
    "contact-size",
    "size alone still catches a palm on a stylus-free tablet"
  );

  assert.equal(isRejectedTouch(finger, { penDown: false, lastPenAt: 0, now: T }), false);
  assert.equal(isRejectedTouch(finger, { penDown: true, lastPenAt: T, now: T }), true);

  // -- long press: hold selects, move pans -----------------------------------
  assert.equal(exceedsLongPressSlop(0, 0), false, "a perfectly still finger is a press");
  assert.equal(
    exceedsLongPressSlop(4, 4),
    false,
    "fingers always wobble; a few pixels is still a press"
  );
  assert.equal(
    exceedsLongPressSlop(LONG_PRESS_SLOP_PX + 1, 0),
    true,
    "past the slop the user is panning and meant to grab nothing"
  );
  assert.equal(
    exceedsLongPressSlop(-20, 15),
    true,
    "slop is a radius, so direction cannot smuggle a drag past it"
  );
}

console.log("\n=== ALL REGRESSION TESTS PASSED (fix pass pinned) ===");
