import assert from "node:assert/strict";
import {
  screenToWorld,
  worldToScreen,
  worldToScreenDelta,
  screenToWorldDelta,
  clamp,
  getElementBounds,
  hitTestElement,
  type Viewport,
} from "../src/lib/whiteboard/geometry";
import {
  MIN_ZOOM,
  MAX_ZOOM,
  type Camera,
  type WhiteboardElement,
  type StrokeElement,
  type RectangleElement,
  type TextElement,
} from "../src/lib/whiteboard/types";

console.log("================================================================================");
console.log("CHALLENGER STRESS TEST: Camera Zoom Geometry, Viewport Math & Touch Gestures");
console.log("================================================================================\n");

let passedCount = 0;
let failedCount = 0;

function runTest(name: string, fn: () => void) {
  try {
    fn();
    console.log(`  ✓ PASS: ${name}`);
    passedCount++;
  } catch (err: any) {
    console.error(`  ✗ FAIL: ${name}`);
    console.error(`    ${err.message}`);
    failedCount++;
  }
}

// ============================================================================
// SUITE 1: Coordinate Roundtrip & Invertibility across Extreme Conditions
// ============================================================================
console.log("--- Suite 1: Screen <-> World Coordinate Roundtrips ---");

const testViewports: Viewport[] = [
  { width: 1280, height: 800 },   // Standard laptop
  { width: 1920, height: 1080 },  // 1080p Desktop
  { width: 800, height: 600 },    // Small window
  { width: 3840, height: 2160 },  // 4K Ultra HD
  { width: 375, height: 667 },    // iPhone SE mobile
  { width: 3440, height: 1440 },  // Ultrawide
  { width: 1024, height: 768 },   // iPad
  { width: 1, height: 1 },        // 1px micro-viewport
];

const testZooms = [
  MIN_ZOOM,       // 0.05
  0.1,
  0.25,
  0.5,
  1.0,
  1.5,
  2.0,
  3.14159,
  4.0,
  MAX_ZOOM,       // 8.0
];

const testPoints = [
  { x: 0, y: 0 },
  { x: 100, y: 200 },
  { x: -500, y: -800 },
  { x: 123.4567, y: 987.6543 },
  { x: 1000000, y: -1000000 },
  { x: -999999.99, y: 999999.99 },
];

runTest("Screen -> World -> Screen roundtrip exactness across all viewports, zooms, and coordinates", () => {
  for (const vp of testViewports) {
    for (const zoom of testZooms) {
      const camera: Camera = { x: 150.5, y: -275.25, zoom };
      for (const pt of testPoints) {
        const world = screenToWorld(pt.x, pt.y, camera, vp);
        const screen = worldToScreen(world.x, world.y, camera, vp);
        const errX = Math.abs(screen.x - pt.x);
        const errY = Math.abs(screen.y - pt.y);
        assert.ok(
          errX < 1e-7 && errY < 1e-7,
          `Roundtrip failed for vp=${vp.width}x${vp.height}, zoom=${zoom}, pt=(${pt.x},${pt.y}). errX=${errX}, errY=${errY}`
        );
      }
    }
  }
});

runTest("World -> Screen -> World roundtrip exactness across all viewports, zooms, and coordinates", () => {
  for (const vp of testViewports) {
    for (const zoom of testZooms) {
      const camera: Camera = { x: -500, y: 300, zoom };
      for (const pt of testPoints) {
        const screen = worldToScreen(pt.x, pt.y, camera, vp);
        const world = screenToWorld(screen.x, screen.y, camera, vp);
        const errX = Math.abs(world.x - pt.x);
        const errY = Math.abs(world.y - pt.y);
        assert.ok(
          errX < 1e-7 && errY < 1e-7,
          `World roundtrip failed for vp=${vp.width}x${vp.height}, zoom=${zoom}, pt=(${pt.x},${pt.y}). errX=${errX}, errY=${errY}`
        );
      }
    }
  }
});

runTest("Delta conversions worldToScreenDelta and screenToWorldDelta are exact inverses", () => {
  for (const zoom of testZooms) {
    const d = 42.195;
    const sDelta = worldToScreenDelta(d, zoom);
    const wDelta = screenToWorldDelta(sDelta, zoom);
    assert.ok(Math.abs(wDelta - d) < 1e-10, `Delta roundtrip failed for zoom=${zoom}`);
  }
});

// ============================================================================
// SUITE 2: zoomTo Cursor Fixed-Point Invariance & Sidebar Offset Invariance
// ============================================================================
console.log("\n--- Suite 2: zoomTo Cursor Invariance & Sidebar Offset ---");

function simulateZoomTo(
  currentCamera: Camera,
  targetZoom: number,
  cursorScreenX: number,
  cursorScreenY: number,
  vp: Viewport
): Camera {
  const newZoom = clamp(targetZoom, MIN_ZOOM, MAX_ZOOM);
  const worldX = (cursorScreenX - vp.width / 2) / currentCamera.zoom + currentCamera.x;
  const worldY = (cursorScreenY - vp.height / 2) / currentCamera.zoom + currentCamera.y;
  const newCameraX = worldX - (cursorScreenX - vp.width / 2) / newZoom;
  const newCameraY = worldY - (cursorScreenY - vp.height / 2) / newZoom;
  return { x: newCameraX, y: newCameraY, zoom: newZoom };
}

runTest("Cursor fixed point invariance: Point under cursor MUST NOT MOVE on screen during zoomTo", () => {
  const testCursors = [
    { x: 0, y: 0 },             // Top-left corner of viewport
    { x: 640, y: 400 },         // Exact center of 1280x800
    { x: 1280, y: 800 },       // Bottom-right corner of 1280x800
    { x: 123, y: 789 },         // Arbitrary screen point
    { x: -100, y: 900 },        // Off-screen cursor
  ];

  for (const vp of testViewports) {
    for (const startZoom of [0.1, 0.5, 1.0, 2.0, 4.0]) {
      for (const targetZoom of [0.05, 0.2, 0.8, 1.5, 3.0, 6.0, 8.0]) {
        for (const cursor of testCursors) {
          const cam: Camera = { x: 250, y: -180, zoom: startZoom };
          const worldBefore = screenToWorld(cursor.x, cursor.y, cam, vp);
          const newCam = simulateZoomTo(cam, targetZoom, cursor.x, cursor.y, vp);
          const screenAfter = worldToScreen(worldBefore.x, worldBefore.y, newCam, vp);

          const errX = Math.abs(screenAfter.x - cursor.x);
          const errY = Math.abs(screenAfter.y - cursor.y);
          assert.ok(
            errX < 1e-7 && errY < 1e-7,
            `Zoom cursor fixed point broken: moved by (${errX}, ${errY})`
          );
        }
      }
    }
  }
});

runTest("Sidebar offset invariance: Opening/closing sidebar changes container width, container viewport preserves center", () => {
  const vpOpen: Viewport = { width: 1280, height: 864 };
  const vpClosed: Viewport = { width: 1536, height: 864 };

  const cam: Camera = { x: 0, y: 0, zoom: 1.0 };

  const worldPointOpen = screenToWorld(640, 432, cam, vpOpen);
  assert.equal(worldPointOpen.x, 0, "Container center maps to world (0,0) when sidebar is open");
  assert.equal(worldPointOpen.y, 0, "Container center maps to world (0,0) when sidebar is open");

  const zoomedCam = simulateZoomTo(cam, 2.0, 640, 432, vpOpen);
  assert.equal(zoomedCam.x, 0, "Camera center does not drift");
  assert.equal(zoomedCam.y, 0, "Camera center does not drift");
});

// ============================================================================
// SUITE 3: zoomToFit Math, Bounding Boxes & Viewport Extremes
// ============================================================================
console.log("\n--- Suite 3: zoomToFit Viewport Math & Edge Cases ---");

function simulateZoomToFit(
  elements: WhiteboardElement[],
  vp: Viewport
): Camera {
  if (elements.length === 0) {
    return { x: 0, y: 0, zoom: 1 };
  }
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  for (const el of elements) {
    if (el.type === "connection") continue;
    const b = getElementBounds(el);
    if (b.x < minX) minX = b.x;
    if (b.y < minY) minY = b.y;
    if (b.x + b.width > maxX) maxX = b.x + b.width;
    if (b.y + b.height > maxY) maxY = b.y + b.height;
  }
  if (!isFinite(minX)) {
    return { x: 0, y: 0, zoom: 1 };
  }
  const padding = 120;
  const contentW = maxX - minX + padding * 2;
  const contentH = maxY - minY + padding * 2;
  const cx = (minX + maxX) / 2;
  const cy = (minY + maxY) / 2;
  const zoom = clamp(Math.min(vp.width / contentW, vp.height / contentH), MIN_ZOOM, 2.0);
  return { x: cx, y: cy, zoom };
}

runTest("zoomToFit on empty board returns default camera (0,0,1)", () => {
  const cam = simulateZoomToFit([], { width: 1280, height: 800 });
  assert.deepEqual(cam, { x: 0, y: 0, zoom: 1 });
});

runTest("zoomToFit with single small element centers content and caps zoom at 2.0", () => {
  const el: RectangleElement = {
    id: "r1",
    type: "rectangle",
    x: 500,
    y: 300,
    width: 100,
    height: 100,
    rotation: 0,
    opacity: 1,
    strokeColor: "#000",
    fillColor: "#fff",
    fillStyle: "solid",
    dashStyle: "solid",
    strokeWidth: 2,
    createdAt: 0,
    updatedAt: 0,
  };
  const vp: Viewport = { width: 1280, height: 800 };
  const cam = simulateZoomToFit([el], vp);

  assert.equal(cam.x, 550, "Camera x is center of element");
  assert.equal(cam.y, 350, "Camera y is center of element");
  assert.equal(cam.zoom, 2.0, "Zoom is capped at 2.0 for small content");

  const centerScreen = worldToScreen(550, 350, cam, vp);
  assert.equal(centerScreen.x, 640);
  assert.equal(centerScreen.y, 400);
});

runTest("zoomToFit with huge spread scales down and never goes below MIN_ZOOM", () => {
  const el1: RectangleElement = {
    id: "r1",
    type: "rectangle",
    x: -50000,
    y: -50000,
    width: 100,
    height: 100,
    rotation: 0,
    opacity: 1,
    strokeColor: "#000",
    fillColor: "#fff",
    fillStyle: "solid",
    dashStyle: "solid",
    strokeWidth: 2,
    createdAt: 0,
    updatedAt: 0,
  };
  const el2: RectangleElement = {
    id: "r2",
    type: "rectangle",
    x: 50000,
    y: 50000,
    width: 100,
    height: 100,
    rotation: 0,
    opacity: 1,
    strokeColor: "#000",
    fillColor: "#fff",
    fillStyle: "solid",
    dashStyle: "solid",
    strokeWidth: 2,
    createdAt: 0,
    updatedAt: 0,
  };
  const vp: Viewport = { width: 1280, height: 800 };
  const cam = simulateZoomToFit([el1, el2], vp);

  assert.equal(cam.zoom, MIN_ZOOM, "Zoom clamps to MIN_ZOOM (0.05)");
  assert.equal(cam.x, 50, "Camera X is exact centroid");
  assert.equal(cam.y, 50, "Camera Y is exact centroid");
});

runTest("zoomToFit with 0x0 or degenerated viewport produces safe numbers (no NaN or Infinity)", () => {
  const el: RectangleElement = {
    id: "r1",
    type: "rectangle",
    x: 100,
    y: 100,
    width: 200,
    height: 200,
    rotation: 0,
    opacity: 1,
    strokeColor: "#000",
    fillColor: "#fff",
    fillStyle: "solid",
    dashStyle: "solid",
    strokeWidth: 2,
    createdAt: 0,
    updatedAt: 0,
  };
  const cam0 = simulateZoomToFit([el], { width: 0, height: 0 });
  assert.ok(Number.isFinite(cam0.x), "cam.x must be finite");
  assert.ok(Number.isFinite(cam0.y), "cam.y must be finite");
  assert.ok(Number.isFinite(cam0.zoom), "cam.zoom must be finite");
  assert.equal(cam0.zoom, MIN_ZOOM, "0x0 viewport clamps to MIN_ZOOM");
});

// ============================================================================
// SUITE 4: Touch Gestures Math & Directional Pan Analysis
// ============================================================================
console.log("\n--- Suite 4: Touch Gestures, Pan Direction & Pinch Zoom ---");

function simulatePanCamera(camera: Camera, dx: number, dy: number): Camera {
  return {
    ...camera,
    x: camera.x - dx / camera.zoom,
    y: camera.y - dy / camera.zoom,
  };
}

runTest("Verified panCamera forward delta direction (1-Finger Pointer & 2-Finger Touch)", () => {
  const startCam: Camera = { x: 0, y: 0, zoom: 1.0 };
  const vp: Viewport = { width: 1000, height: 1000 };
  const worldPoint = { x: 0, y: 0 };

  const initialScreen = worldToScreen(worldPoint.x, worldPoint.y, startCam, vp);
  const lastX = 500;
  const currX = 600;

  // In WhiteboardCanvas.tsx:
  // Forward displacement: dx = cp.x - interaction.lastX = 600 - 500 = +100
  const dx = currX - lastX;

  const newCam = simulatePanCamera(startCam, dx, 0);
  const screenAfter = worldToScreen(worldPoint.x, worldPoint.y, newCam, vp);

  const screenDelta = screenAfter.x - initialScreen.x;
  const pointerDelta = currX - lastX;

  console.log(`      [Pan Implementation] Pointer dragged: +${pointerDelta}px | Canvas moved on screen: +${screenDelta}px`);
  assert.equal(screenDelta, pointerDelta, "Canvas on screen must move in the exact same direction and magnitude as pointer drag (+100px)");

  // Verify at multiple zoom levels (0.25x, 2.0x, 4.0x)
  for (const zoom of [0.25, 0.5, 2.0, 4.0]) {
    const camZ: Camera = { x: 50, y: 50, zoom };
    const pDeltaX = 80;
    const pDeltaY = -40;
    const pBefore = worldToScreen(worldPoint.x, worldPoint.y, camZ, vp);
    const camAfter = simulatePanCamera(camZ, pDeltaX, pDeltaY);
    const pAfter = worldToScreen(worldPoint.x, worldPoint.y, camAfter, vp);

    assert.ok(
      Math.abs(pAfter.x - pBefore.x - pDeltaX) < 1e-7,
      `Screen X translation must equal pointer delta at zoom=${zoom}`
    );
    assert.ok(
      Math.abs(pAfter.y - pBefore.y - pDeltaY) < 1e-7,
      `Screen Y translation must equal pointer delta at zoom=${zoom}`
    );
  }
});

runTest("Pinch-to-zoom math preserves midpoint world position on screen", () => {
  const startCam: Camera = { x: 100, y: 100, zoom: 1.0 };
  const vp: Viewport = { width: 1280, height: 800 };

  const touch1 = { x: 500, y: 400 };
  const touch2 = { x: 700, y: 400 };
  const startDist = Math.hypot(touch1.x - touch2.x, touch1.y - touch2.y);
  const midScreen = { x: (touch1.x + touch2.x) / 2, y: (touch1.y + touch2.y) / 2 };

  const worldMidBefore = screenToWorld(midScreen.x, midScreen.y, startCam, vp);

  const currDist = 400;
  const scale = currDist / startDist;
  const targetZoom = startCam.zoom * scale; // 2.0

  const newCam = simulateZoomTo(startCam, targetZoom, midScreen.x, midScreen.y, vp);
  const screenMidAfter = worldToScreen(worldMidBefore.x, worldMidBefore.y, newCam, vp);

  assert.ok(
    Math.abs(screenMidAfter.x - midScreen.x) < 1e-7 &&
    Math.abs(screenMidAfter.y - midScreen.y) < 1e-7,
    "Pinch zoom did not preserve midpoint screen position"
  );
});

// ============================================================================
// SUITE 5: Drag Erasing Across Multiple Element Types
// ============================================================================
console.log("\n--- Suite 5: Continuous Drag Erasing Hit Detection ---");

runTest("Continuous drag path intersects multiple elements and hit tests all of them", () => {
  const elDot: StrokeElement = {
    id: "s_dot",
    type: "stroke",
    x: 100,
    y: 100,
    rotation: 0,
    opacity: 1,
    points: [[0, 0, 0.5]],
    color: "#000",
    strokeWidth: 4,
    strokeStyle: "pen",
    createdAt: 0,
    updatedAt: 0,
  };

  const elRect: RectangleElement = {
    id: "s_rect",
    type: "rectangle",
    x: 200,
    y: 80,
    width: 60,
    height: 60,
    rotation: 0,
    opacity: 1,
    strokeColor: "#000",
    fillColor: "#fff",
    fillStyle: "solid",
    dashStyle: "solid",
    strokeWidth: 2,
    createdAt: 0,
    updatedAt: 0,
  };

  const elText: TextElement = {
    id: "s_text",
    type: "text",
    x: 350,
    y: 90,
    width: 100,
    height: 40,
    rotation: 0,
    opacity: 1,
    text: "Hello",
    color: "#000",
    fontSize: 16,
    fontFamily: "sans-serif",
    fontWeight: 400,
    align: "left",
    createdAt: 0,
    updatedAt: 0,
  };

  const elements: WhiteboardElement[] = [elDot, elRect, elText];

  const dragSteps = [
    { x: 50, y: 100 },
    { x: 100, y: 100 }, // hits dot
    { x: 150, y: 100 },
    { x: 230, y: 100 }, // hits rect
    { x: 300, y: 100 },
    { x: 380, y: 100 }, // hits text
    { x: 450, y: 100 },
  ];

  const erasedIds = new Set<string>();

  for (const pt of dragSteps) {
    for (const el of elements) {
      if (hitTestElement(el, pt.x, pt.y)) {
        erasedIds.add(el.id);
      }
    }
  }

  assert.ok(erasedIds.has("s_dot"), "Single dot must be hit during drag-erase");
  assert.ok(erasedIds.has("s_rect"), "Rectangle must be hit during drag-erase");
  assert.ok(erasedIds.has("s_text"), "Text must be hit during drag-erase");
  assert.equal(erasedIds.size, 3, "All 3 elements along drag path must be erased");
});

console.log("\n================================================================================");
console.log(`CHALLENGER STRESS TEST SUMMARY: Passed: ${passedCount}, Failed: ${failedCount}`);
console.log("================================================================================\n");
