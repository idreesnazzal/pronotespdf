/**
 * Favorite pens bar: one home shared by every board — left edge, centred.
 *
 * Reported on startup: the bar opened in the middle of the notebook page
 * instead of docking to the left side. The default only applies when there is
 * no saved drag (a fresh workspace); a persisted position must keep winning.
 * These pin the default so it cannot drift back to the top corner.
 */

import assert from "node:assert/strict";
import {
  defaultPensBarPosition,
  PENS_BAR_EDGE_GAP,
  PENS_BAR_HEIGHT_ESTIMATE,
} from "../src/lib/whiteboard/placement";

let passed = 0;
let failed = 0;
function test(name: string, fn: () => void) {
  try {
    fn();
    passed++;
    console.log(`  ✓ ${name}`);
  } catch (err) {
    failed++;
    console.error(`  ✗ ${name}`);
    console.error(`      ${(err as Error).message}`);
  }
}

const near = (a: number, b: number, eps = 1) => Math.abs(a - b) <= eps;

// A typical phone-sized canvas pane.
const AREA = { left: 80, top: 0, right: 880, bottom: 1700 };
const BAR_H = 320;

console.log("\n── Pens bar default placement ──");

test("parks on the left edge of the canvas pane", () => {
  const p = defaultPensBarPosition(AREA, BAR_H);
  assert.equal(p.x, AREA.left + PENS_BAR_EDGE_GAP, `x ${p.x}, expected ${AREA.left + PENS_BAR_EDGE_GAP}`);
});

test("is vertically centred in the pane, not near the top", () => {
  const p = defaultPensBarPosition(AREA, BAR_H);
  const barMiddle = p.y + BAR_H / 2;
  const areaMiddle = (AREA.top + AREA.bottom) / 2;
  assert.ok(
    near(barMiddle, areaMiddle),
    `bar middle ${barMiddle}, pane middle ${areaMiddle}`
  );
});

test("stays clear of the top toolbar zone", () => {
  const p = defaultPensBarPosition(AREA, BAR_H);
  assert.ok(p.y > 120, `y ${p.y} sits inside the top toolbar/zoom-pill zone`);
});

test("same inputs give the same spot on any board (one global home)", () => {
  const a = defaultPensBarPosition(AREA, BAR_H);
  const b = defaultPensBarPosition(AREA, BAR_H);
  assert.deepEqual(a, b, "default must be deterministic, not per-board");
});

test("a short pane still keeps the bar inside instead of centring off-screen", () => {
  const short = { left: 0, top: 0, right: 800, bottom: 200 };
  const p = defaultPensBarPosition(short, BAR_H);
  // The bar (320) is taller than this pane (200): it cannot fit, so it pins
  // to the top and the render-time clamp owns it from there — never centred
  // off-screen, never NaN.
  assert.equal(p.y, short.top + 8, `y ${p.y} should pin to the top`);
  assert.equal(p.x, short.left + PENS_BAR_EDGE_GAP, "still on the left edge");
});

test("garbage heights and degenerate areas never yield NaN", () => {
  for (const h of [0, -50, NaN, Infinity]) {
    const p = defaultPensBarPosition(AREA, h);
    assert.ok(Number.isFinite(p.x) && Number.isFinite(p.y), `height ${h} gave ${p.x},${p.y}`);
  }
  const p = defaultPensBarPosition({ left: 0, top: 0, right: 0, bottom: 0 }, BAR_H);
  assert.ok(Number.isFinite(p.x) && Number.isFinite(p.y), "zero area gave NaN");
});

test("height estimate constant is sane", () => {
  assert.ok(
    PENS_BAR_HEIGHT_ESTIMATE >= 150 && PENS_BAR_HEIGHT_ESTIMATE <= 600,
    `estimate ${PENS_BAR_HEIGHT_ESTIMATE} is not bar-shaped`
  );
});

console.log(`\n${passed} passed, ${failed} failed.`);
if (failed > 0) process.exit(1);
