/**
 * Customisable tool bar and the laser pointer's settings.
 * - A saved tool bar keeps only known, distinct buttons; junk means "default".
 * - The laser's colour and size live in their own fields, so changing them
 *   never touches a pen's ink or a shape's border.
 */

import assert from "node:assert/strict";
import {
  DEFAULT_STYLE,
  ALL_TOOLBAR_ITEMS,
  DEFAULT_TOOLBAR_ITEMS,
  cleanToolbarItems,
  mergeToolbarItems,
  getToolColor,
  getToolSize,
  setToolColor,
  setToolSize,
} from "../src/lib/whiteboard/types";

const NL = String.fromCharCode(10);
let passed = 0;
let failed = 0;
function test(name: string, fn: () => void) {
  try {
    fn();
    passed++;
    console.log(`  ✓ ${name}`);
  } catch (err) {
    failed++;
    console.error(`  ✗ ${name}`);
    console.error(`      ${(err as Error).message}`);
  }
}

console.log(NL + "── Tool bar & laser ──");

test("the default tool bar has the laser but not the hand, which can be added back", () => {
  assert.ok(DEFAULT_TOOLBAR_ITEMS.includes("laser"));
  assert.ok(!DEFAULT_TOOLBAR_ITEMS.includes("pan"));
  assert.ok(ALL_TOOLBAR_ITEMS.includes("pan"));
  assert.deepEqual(cleanToolbarItems(["pan", "pen"]), ["pan", "pen"]);
  assert.equal(new Set(ALL_TOOLBAR_ITEMS).size, ALL_TOOLBAR_ITEMS.length);
});

test("a saved tool bar keeps its order and drops unknown or repeated buttons", () => {
  assert.deepEqual(cleanToolbarItems(["text", "pen", "bogus", "pen", 3, "laser"]), ["text", "pen", "laser"]);
});

test("an empty or broken saved tool bar means the default", () => {
  assert.equal(cleanToolbarItems([]), undefined);
  assert.equal(cleanToolbarItems(["nope"]), undefined);
  assert.equal(cleanToolbarItems("pen"), undefined);
  assert.equal(cleanToolbarItems(undefined), undefined);
});

test("laser colour and size are its own, not a pen's or a shape's", () => {
  const style = { ...DEFAULT_STYLE };
  const next = { ...style, ...setToolColor(style, "laser", "#22c55e"), ...setToolSize(style, "laser", 24) };
  assert.equal(getToolColor(next, "laser"), "#22c55e");
  assert.equal(getToolSize(next, "laser"), 24);
  assert.equal(next.strokeColor, style.strokeColor);
  assert.equal(next.strokeWidth, style.strokeWidth);
  assert.deepEqual(next.toolInk, style.toolInk);
});

test("a style saved before the laser existed still gives it a colour and size", () => {
  const old = { ...DEFAULT_STYLE } as Partial<typeof DEFAULT_STYLE>;
  delete old.laserColor;
  delete old.laserSize;
  assert.equal(getToolColor(old as typeof DEFAULT_STYLE, "laser"), DEFAULT_STYLE.laserColor);
  assert.equal(getToolSize(old as typeof DEFAULT_STYLE, "laser"), DEFAULT_STYLE.laserSize);
});

test("a tool added after the bar was saved appears; one the user removed does not", () => {
  // Saved before "Select text" existed (and without a removed-list).
  const old = DEFAULT_TOOLBAR_ITEMS.filter((id) => id !== "textselect");
  const merged = mergeToolbarItems(old, undefined);
  assert.ok(merged.includes("textselect"), "the new tool shows up");
  assert.ok(!merged.includes("pan"), "the hand stays off");
  assert.ok(merged.indexOf("textselect") < merged.indexOf("pen"), "at its default place");
  // Removed on purpose: stays removed.
  assert.ok(!mergeToolbarItems(old, ["textselect"]).includes("textselect"));
  // The user's own order is kept.
  assert.deepEqual(mergeToolbarItems(["text", "pen"], ALL_TOOLBAR_ITEMS.filter((i) => i !== "text" && i !== "pen")), ["text", "pen"]);
  assert.deepEqual(mergeToolbarItems(undefined, undefined), DEFAULT_TOOLBAR_ITEMS);
});

console.log(`  ${passed} passed, ${failed} failed`);
if (failed > 0) process.exit(1);
