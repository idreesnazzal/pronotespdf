/**
 * CHALLENGER 2 EMPIRICAL TEST SUITE
 * =================================
 * 
 * Exhaustive Stress Harnesses covering:
 * 1. Smart Connector 3 routing modes (Curved Bezier, Orthogonal step, Straight) under extreme coordinates and intersecting nodes.
 * 2. Board duplication ID remapping integrity across 100 duplicated boards with dense interconnected node graphs.
 * 3. 50-step circular undo/redo history stack stress test (overflows, boundary edge cases, branching, deep restores).
 */

import {
  getCurvedBezierPath,
  getOrthogonalPath,
  getStraightPath,
  getConnectionPath,
  getArrowheadPath,
  getNodeAnchorPorts,
  getResolvedAnchorPoint,
  getOptimalConnectionAnchors,
  getElementBounds,
  type AnchorPoint,
} from "../src/lib/whiteboard/geometry";
import { useWhiteboard } from "../src/store/whiteboard";
import type {
  Board,
  ConnectionElement,
  RectangleElement,
  StickyElement,
  TextElement,
  StarElement,
  CloudElement,
  EllipseElement,
  DiamondElement,
  WhiteboardElement,
} from "../src/lib/whiteboard/types";

let passedAssertions = 0;
let totalAssertions = 0;

function assert(condition: boolean, message: string) {
  totalAssertions++;
  if (!condition) {
    console.error(`❌ FAILED ASSERTION [${totalAssertions}]: ${message}`);
    throw new Error(`Assertion failed: ${message}`);
  }
  passedAssertions++;
}

console.log("===================================================================");
console.log("=== RUNNING CHALLENGER 2 EMPIRICAL ADVERSARIAL STRESS SUITE     ===");
console.log("===================================================================\n");

// ============================================================================
// SECTION 1: SMART CONNECTOR 3 ROUTING MODES UNDER EXTREME COORDINATES & OVERLAPS
// ============================================================================
console.log("[Section 1] Smart Connector 3 Routing Modes & Intersecting Nodes Stress...");

// 1.1 Extreme Coordinate Values & Numerical Stability
const extremeCoordinates = [
  -1e7, -1e6, -99999.99, -1000, -1, -0.0001, 0, 0.0001, 1, 1000, 99999.99, 1e6, 1e7,
];

for (const x1 of [-1e6, -500, 0, 500, 1e6]) {
  for (const y1 of [-1e6, -500, 0, 500, 1e6]) {
    for (const x2 of [-1e6, -200, 0, 200, 1e6]) {
      for (const y2 of [-1e6, -200, 0, 200, 1e6]) {
        const p1: AnchorPoint = { x: x1, y: y1, nx: 1, ny: 0, anchor: "right" };
        const p2: AnchorPoint = { x: x2, y: y2, nx: -1, ny: 0, anchor: "left" };

        const curved = getCurvedBezierPath(p1, p2);
        const ortho = getOrthogonalPath(p1, p2);
        const straight = getStraightPath(p1, p2);

        // Verify all 3 paths return non-empty strings with NO NaN, Infinity, or undefined
        assert(typeof curved === "string" && curved.startsWith("M"), `Curved path valid string for (${x1},${y1})->(${x2},${y2})`);
        assert(!curved.includes("NaN") && !curved.includes("undefined") && !curved.includes("Infinity"), `Curved path has no NaN/Infinity`);

        assert(typeof ortho === "string" && ortho.startsWith("M"), `Ortho path valid string for (${x1},${y1})->(${x2},${y2})`);
        assert(!ortho.includes("NaN") && !ortho.includes("undefined") && !ortho.includes("Infinity"), `Ortho path has no NaN/Infinity`);

        assert(typeof straight === "string" && straight.startsWith("M"), `Straight path valid string for (${x1},${y1})->(${x2},${y2})`);
        assert(!straight.includes("NaN") && !straight.includes("undefined") && !straight.includes("Infinity"), `Straight path has no NaN/Infinity`);
      }
    }
  }
}
console.log("  ✓ Extreme coordinates numerical stability verified (no NaN / Infinity / undefined)");

// 1.2 Boundary Distances (Zero, Sub-pixel, Exact threshold values)
const boundaryDistances = [0, 0.00001, 0.5, 1.99, 2.0, 2.01, 3.99, 4.0, 4.01, 10, 50];
for (const dist of boundaryDistances) {
  const p1: AnchorPoint = { x: 100, y: 100, nx: 1, ny: 0, anchor: "right" };
  const p2: AnchorPoint = { x: 100 + dist, y: 100, nx: -1, ny: 0, anchor: "left" };

  const curved = getCurvedBezierPath(p1, p2);
  const ortho = getOrthogonalPath(p1, p2);
  const straight = getStraightPath(p1, p2);

  if (dist < 2) {
    // Curved Bezier falls back to straight line when dist < 2
    assert(curved === `M 100,100 L ${100 + dist},100`, `Curved Bezier falls back to linear L on dist < 2`);
  } else {
    assert(curved.includes("C"), `Curved Bezier uses cubic C for dist >= 2`);
  }

  if (dist < 4) {
    // Orthogonal falls back to straight line when dist < 4
    assert(ortho === `M 100,100 L ${100 + dist},100`, `Orthogonal falls back to linear L on dist < 4`);
  } else {
    assert(ortho.includes("L"), `Orthogonal path contains line segments`);
  }

  assert(straight === `M 100,100 L ${100 + dist},100`, `Straight path exact linear segment`);
}
console.log("  ✓ Boundary distance thresholds (<2px, <4px, sub-pixel, 0px) verified");

// 1.3 Intersecting, Overlapping & Concentric Nodes
const concentricSource: RectangleElement = {
  id: "node-source",
  type: "rectangle",
  x: 0,
  y: 0,
  width: 200,
  height: 200,
  rotation: 0,
  opacity: 1,
  strokeColor: "#000",
  fillColor: "#fff",
  fillStyle: "solid",
  dashStyle: "solid",
  strokeWidth: 2,
  createdAt: Date.now(),
  updatedAt: Date.now(),
};

const concentricTarget: RectangleElement = {
  id: "node-target",
  type: "rectangle",
  x: 50,
  y: 50,
  width: 100,
  height: 100,
  rotation: 0,
  opacity: 1,
  strokeColor: "#000",
  fillColor: "#fff",
  fillStyle: "solid",
  dashStyle: "solid",
  strokeWidth: 2,
  createdAt: Date.now(),
  updatedAt: Date.now(),
};

// Target inside source (concentric)
const concentricAnchors = getOptimalConnectionAnchors(concentricSource, concentricTarget, "auto", "auto");
assert(concentricAnchors.source !== undefined && concentricAnchors.target !== undefined, "Concentric nodes anchor resolution");
const concentricCurved = getConnectionPath(concentricAnchors.source, concentricAnchors.target, "curved");
const concentricOrtho = getConnectionPath(concentricAnchors.source, concentricAnchors.target, "orthogonal");
const concentricStraight = getConnectionPath(concentricAnchors.source, concentricAnchors.target, "straight");

assert(!concentricCurved.includes("NaN"), "Concentric curved path valid");
assert(!concentricOrtho.includes("NaN"), "Concentric ortho path valid");
assert(!concentricStraight.includes("NaN"), "Concentric straight path valid");

// 1.4 Rotated & Overlapping Nodes
for (const rotDeg of [0, 30, 45, 90, 135, 180, 270, 315]) {
  const rotRad = (rotDeg * Math.PI) / 180;
  const rotatedSource: StickyElement = {
    id: `rot-s-${rotDeg}`,
    type: "sticky",
    x: 100,
    y: 100,
    width: 150,
    height: 150,
    rotation: rotRad,
    opacity: 1,
    text: "Source",
    color: "yellow",
    fontSize: 16,
    align: "left",
    createdAt: Date.now(),
    updatedAt: Date.now(),
  };

  const rotatedTarget: StickyElement = {
    id: `rot-t-${rotDeg}`,
    type: "sticky",
    x: 180, // Overlapping partially with source
    y: 120,
    width: 150,
    height: 150,
    rotation: -rotRad,
    opacity: 1,
    text: "Target",
    color: "blue",
    fontSize: 16,
    align: "left",
    createdAt: Date.now(),
    updatedAt: Date.now(),
  };

  const anchors = getOptimalConnectionAnchors(rotatedSource, rotatedTarget, "auto", "auto");
  const portsSource = getNodeAnchorPorts(rotatedSource);
  const portsTarget = getNodeAnchorPorts(rotatedTarget);

  assert(isFinite(portsSource.top.x) && isFinite(portsSource.top.y), `Rotated source top port finite for ${rotDeg}°`);
  assert(isFinite(portsSource.right.nx) && isFinite(portsSource.right.ny), `Rotated source normals finite for ${rotDeg}°`);

  for (const mode of ["curved", "orthogonal", "straight"] as const) {
    const path = getConnectionPath(anchors.source, anchors.target, mode);
    assert(!path.includes("NaN") && !path.includes("undefined") && path.length > 5, `Rotated ${rotDeg}° ${mode} path valid`);
  }
}
console.log("  ✓ Intersecting, overlapping, concentric, and rotated nodes routing verified");

// 1.5 Arrowheads Stress
const arrowheadTypes = ["arrow", "triangle", "stealth", "diamond", "circle", "none"] as const;
for (const type of arrowheadTypes) {
  // Normal delta
  const normalHead = getArrowheadPath(100, 100, 80, 100, type, 12);
  if (type === "none") {
    assert(normalHead === null, "Arrowhead type 'none' returns null");
  } else {
    assert(normalHead !== null && normalHead.path.startsWith("M"), `Arrowhead ${type} produces valid SVG path`);
    assert(!normalHead!.path.includes("NaN"), `Arrowhead ${type} contains no NaN`);
  }

  // Zero delta (fromX === tipX, fromY === tipY)
  const zeroHead = getArrowheadPath(100, 100, 100, 100, type, 12);
  assert(zeroHead === null, `Arrowhead with zero delta safely returns null (no division by zero)`);

  // Sub-millimeter delta (len < 0.001)
  const subMilliHead = getArrowheadPath(100, 100, 100.0001, 100.0001, type, 12);
  assert(subMilliHead === null, `Arrowhead with sub-millimeter delta safely returns null`);
}
console.log("  ✓ Arrowhead generator stress and zero-division defenses verified\n");


// ============================================================================
// SECTION 2: BOARD DUPLICATION ID REMAPPING INTEGRITY ACROSS 100 BOARDS
// ============================================================================
console.log("[Section 2] Board Duplication ID Remapping Integrity (100 Duplicated Boards)...");

// Build an initial complex board with 8 nodes and 8 connections
const store = useWhiteboard.getState();
const initialBoardId = store.createBoard("Master Template Board", null, "#6366f1");

const sampleNodes: WhiteboardElement[] = [
  { id: "n1", type: "rectangle", x: 0, y: 0, width: 120, height: 80, rotation: 0, opacity: 1, strokeColor: "#000", fillColor: "#fff", fillStyle: "solid", dashStyle: "solid", strokeWidth: 2, createdAt: Date.now(), updatedAt: Date.now() },
  { id: "n2", type: "ellipse", x: 200, y: 0, width: 120, height: 80, rotation: 0, opacity: 1, strokeColor: "#000", fillColor: "#fff", fillStyle: "solid", dashStyle: "solid", strokeWidth: 2, createdAt: Date.now(), updatedAt: Date.now() },
  { id: "n3", type: "diamond", x: 400, y: 0, width: 100, height: 100, rotation: 0, opacity: 1, strokeColor: "#000", fillColor: "#fff", fillStyle: "solid", dashStyle: "solid", strokeWidth: 2, createdAt: Date.now(), updatedAt: Date.now() },
  { id: "n4", type: "sticky", x: 0, y: 200, width: 150, height: 120, rotation: 0.05, opacity: 1, text: "Idea 1", color: "yellow", fontSize: 16, align: "left", createdAt: Date.now(), updatedAt: Date.now() },
  { id: "n5", type: "sticky", x: 200, y: 200, width: 150, height: 120, rotation: -0.02, opacity: 1, text: "Idea 2", color: "blue", fontSize: 16, align: "left", createdAt: Date.now(), updatedAt: Date.now() },
  { id: "n6", type: "text", x: 400, y: 200, width: 180, height: 60, rotation: 0, opacity: 1, text: "Conclusion text", color: "#000", fontSize: 18, fontFamily: "var(--font-inter)", fontWeight: 400, align: "left", createdAt: Date.now(), updatedAt: Date.now() },
  { id: "n7", type: "star", x: 600, y: 100, width: 100, height: 100, rotation: 0, opacity: 1, strokeColor: "#000", fillColor: "#fff", fillStyle: "solid", dashStyle: "solid", strokeWidth: 2, createdAt: Date.now(), updatedAt: Date.now() },
  { id: "n8", type: "cloud", x: 600, y: 300, width: 140, height: 90, rotation: 0, opacity: 1, strokeColor: "#000", fillColor: "#fff", fillStyle: "solid", dashStyle: "solid", strokeWidth: 2, createdAt: Date.now(), updatedAt: Date.now() },
];

const sampleConnections: ConnectionElement[] = [
  { id: "c1", type: "connection", x: 0, y: 0, rotation: 0, opacity: 1, source: { boardId: initialBoardId, elementId: "n1", anchor: "right" }, target: { boardId: initialBoardId, elementId: "n2", anchor: "left" }, linkType: "relates", routing: "curved", dashStyle: "solid", startArrowhead: "none", endArrowhead: "arrow", strokeWidth: 2, createdAt: Date.now(), updatedAt: Date.now() },
  { id: "c2", type: "connection", x: 0, y: 0, rotation: 0, opacity: 1, source: { boardId: initialBoardId, elementId: "n2", anchor: "right" }, target: { boardId: initialBoardId, elementId: "n3", anchor: "left" }, linkType: "leads_to", routing: "orthogonal", dashStyle: "solid", startArrowhead: "none", endArrowhead: "arrow", strokeWidth: 2, createdAt: Date.now(), updatedAt: Date.now() },
  { id: "c3", type: "connection", x: 0, y: 0, rotation: 0, opacity: 1, source: { boardId: initialBoardId, elementId: "n1", anchor: "bottom" }, target: { boardId: initialBoardId, elementId: "n4", anchor: "top" }, linkType: "contains", routing: "straight", dashStyle: "solid", startArrowhead: "none", endArrowhead: "arrow", strokeWidth: 2, createdAt: Date.now(), updatedAt: Date.now() },
  { id: "c4", type: "connection", x: 0, y: 0, rotation: 0, opacity: 1, source: { boardId: initialBoardId, elementId: "n4", anchor: "right" }, target: { boardId: initialBoardId, elementId: "n5", anchor: "left" }, linkType: "causes", routing: "curved", dashStyle: "solid", startArrowhead: "none", endArrowhead: "arrow", strokeWidth: 2, createdAt: Date.now(), updatedAt: Date.now() },
  { id: "c5", type: "connection", x: 0, y: 0, rotation: 0, opacity: 1, source: { boardId: initialBoardId, elementId: "n5", anchor: "right" }, target: { boardId: initialBoardId, elementId: "n6", anchor: "left" }, linkType: "relates", routing: "orthogonal", dashStyle: "solid", startArrowhead: "none", endArrowhead: "arrow", strokeWidth: 2, createdAt: Date.now(), updatedAt: Date.now() },
  { id: "c6", type: "connection", x: 0, y: 0, rotation: 0, opacity: 1, source: { boardId: initialBoardId, elementId: "n3", anchor: "right" }, target: { boardId: initialBoardId, elementId: "n7", anchor: "left" }, linkType: "depends_on", routing: "curved", dashStyle: "solid", startArrowhead: "none", endArrowhead: "arrow", strokeWidth: 2, createdAt: Date.now(), updatedAt: Date.now() },
  { id: "c7", type: "connection", x: 0, y: 0, rotation: 0, opacity: 1, source: { boardId: initialBoardId, elementId: "n6", anchor: "right" }, target: { boardId: initialBoardId, elementId: "n8", anchor: "left" }, linkType: "supports", routing: "straight", dashStyle: "solid", startArrowhead: "none", endArrowhead: "arrow", strokeWidth: 2, createdAt: Date.now(), updatedAt: Date.now() },
  // Cyclic connection n8 -> n1
  { id: "c8", type: "connection", x: 0, y: 0, rotation: 0, opacity: 1, source: { boardId: initialBoardId, elementId: "n8", anchor: "bottom" }, target: { boardId: initialBoardId, elementId: "n1", anchor: "left" }, linkType: "relates", routing: "curved", dashStyle: "solid", startArrowhead: "none", endArrowhead: "arrow", strokeWidth: 2, createdAt: Date.now(), updatedAt: Date.now() },
];

// Add elements to initial board
store.addElements([...sampleNodes, ...sampleConnections], false);

const duplicatedBoardIds: string[] = [];
let currentSourceBoardId = initialBoardId;

const allSeenElementIds = new Set<string>();
for (const el of sampleNodes) allSeenElementIds.add(el.id);
for (const el of sampleConnections) allSeenElementIds.add(el.id);

// Duplicate 50 in sequential chain (A -> B -> C -> ...)
for (let i = 1; i <= 50; i++) {
  const dupId = store.duplicateBoard(currentSourceBoardId);
  assert(dupId !== null, `Duplicate sequential board ${i} returned valid ID`);
  duplicatedBoardIds.push(dupId!);
  currentSourceBoardId = dupId!;
}

// Duplicate 50 from master root (A -> B1, A -> B2, ...)
for (let i = 51; i <= 100; i++) {
  const dupId = store.duplicateBoard(initialBoardId);
  assert(dupId !== null, `Duplicate radial board ${i} returned valid ID`);
  duplicatedBoardIds.push(dupId!);
}

assert(duplicatedBoardIds.length === 100, "Created 100 duplicated boards");

// Verify integrity of all 100 duplicated boards
const allBoards = useWhiteboard.getState().boards;
for (let idx = 0; idx < duplicatedBoardIds.length; idx++) {
  const boardId = duplicatedBoardIds[idx];
  const board = allBoards.find((b) => b.id === boardId);
  assert(board !== undefined, `Duplicated board ${idx + 1} exists in store`);
  assert(board!.elements.length === sampleNodes.length + sampleConnections.length, `Board ${idx + 1} has exact element count (16)`);

  const boardElementIds = new Set<string>();
  const nonConnElements = board!.elements.filter((e) => e.type !== "connection");
  const connElements = board!.elements.filter((e) => e.type === "connection") as ConnectionElement[];

  // 1. Verify every element ID is unique and not previously seen in other boards
  for (const el of board!.elements) {
    assert(!allSeenElementIds.has(el.id), `Element ID ${el.id} in board ${idx + 1} is globally unique and not colliding`);
    allSeenElementIds.add(el.id);
    assert(!boardElementIds.has(el.id), `Element ID ${el.id} is unique within board ${idx + 1}`);
    boardElementIds.add(el.id);
  }

  // 2. Verify connection source and target element IDs point to elements inside THIS board
  for (const conn of connElements) {
    assert(conn.source.boardId === boardId, `Connection ${conn.id} source.boardId is remapped to new board ${boardId}`);
    assert(conn.target.boardId === boardId, `Connection ${conn.id} target.boardId is remapped to new board ${boardId}`);
    assert(boardElementIds.has(conn.source.elementId), `Connection ${conn.id} source.elementId ${conn.source.elementId} exists in board`);
    assert(boardElementIds.has(conn.target.elementId), `Connection ${conn.id} target.elementId ${conn.target.elementId} exists in board`);
    
    // Verify source and target do not point to old IDs ("n1", "n2", etc.)
    assert(!["n1","n2","n3","n4","n5","n6","n7","n8"].includes(conn.source.elementId), `Source ID was remapped away from old prototype ID`);
    assert(!["n1","n2","n3","n4","n5","n6","n7","n8"].includes(conn.target.elementId), `Target ID was remapped away from old prototype ID`);
  }
}
console.log("  ✓ 100 duplicated boards verified: 0 dangling IDs, 0 stale IDs, 100% topological remapping integrity\n");


// ============================================================================
// SECTION 3: 50-STEP CIRCULAR UNDO/REDO HISTORY STACK STRESS TEST
// ============================================================================
console.log("[Section 3] 50-Step Circular Undo/Redo History Stack Stress Test...");

const historyBoardId = store.createBoard("History Test Board", null, "#10b981");
store.setActiveBoard(historyBoardId);

// 3.1 Verify initial history state
assert(!store.canUndo(), "Initial board canUndo is false");
assert(!store.canRedo(), "Initial board canRedo is false");

// 3.2 Add 100 sequential elements with commitHistory to test 100-step circular bound
for (let i = 1; i <= 100; i++) {
  const el: StickyElement = {
    id: `history-sticky-${i}`,
    type: "sticky",
    x: i * 10,
    y: i * 10,
    width: 100,
    height: 100,
    rotation: 0,
    opacity: 1,
    text: `Note ${i}`,
    color: "yellow",
    fontSize: 16,
    align: "left",
    createdAt: Date.now(),
    updatedAt: Date.now(),
  };
  store.addElement(el, true);

  const historyPastLen = useWhiteboard.getState().history.past.length;
  // History past is capped at 99 (which with current active board makes 100 total discrete steps)
  assert(historyPastLen <= 100, `History past length (${historyPastLen}) is strictly bounded <= 100 on step ${i}`);
}

const finalElementsCount = useWhiteboard.getState().boards.find((b) => b.id === historyBoardId)!.elements.length;
assert(finalElementsCount === 100, "100 elements added successfully");
assert(useWhiteboard.getState().canUndo(), "canUndo is true after 100 additions");

// 3.3 Perform 100 consecutive Undos
let undoCount = 0;
while (useWhiteboard.getState().canUndo() && undoCount < 110) {
  store.undo();
  undoCount++;
}

assert(undoCount === 99 || undoCount === 100, `Exactly ${undoCount} undos performed (bounded by 100-step capacity)`);
assert(!useWhiteboard.getState().canUndo(), "canUndo is false after exhausting past stack");
assert(useWhiteboard.getState().canRedo(), "canRedo is true after undos");

const elementsAfterUndo = useWhiteboard.getState().boards.find((b) => b.id === historyBoardId)!.elements.length;
assert(elementsAfterUndo === 100 - undoCount, `Elements count restored to ${100 - undoCount}`);

// 3.4 Boundary: Extra Undos on empty past stack (must be safe no-op)
for (let i = 0; i < 10; i++) {
  store.undo();
  assert(!useWhiteboard.getState().canUndo(), "canUndo remains false on over-undo");
}
assert(useWhiteboard.getState().boards.find((b) => b.id === historyBoardId)!.elements.length === elementsAfterUndo, "Elements unchanged on over-undo");

// 3.5 Perform Redos back to latest state
let redoCount = 0;
while (useWhiteboard.getState().canRedo() && redoCount < 110) {
  store.redo();
  redoCount++;
}

assert(redoCount === undoCount, `Redid exact number of steps (${redoCount})`);
assert(!useWhiteboard.getState().canRedo(), "canRedo is false after exhausting future stack");
assert(useWhiteboard.getState().boards.find((b) => b.id === historyBoardId)!.elements.length === 100, "Restored all 100 elements on full redo");

// 3.6 Boundary: Extra Redos on empty future stack (must be safe no-op)
for (let i = 0; i < 10; i++) {
  store.redo();
  assert(!useWhiteboard.getState().canRedo(), "canRedo remains false on over-redo");
}

// 3.7 Branching History Invariant
// Undo 20 steps
for (let i = 0; i < 20; i++) {
  store.undo();
}
assert(useWhiteboard.getState().history.future.length === 20, "Future stack holds 20 undone actions");

// Commit a new divergent action (add a Text element)
const branchingText: TextElement = {
  id: "branch-text-1",
  type: "text",
  x: 999,
  y: 999,
  width: 200,
  height: 50,
  rotation: 0,
  opacity: 1,
  text: "Branching Action",
  color: "#000",
  fontSize: 20,
  fontFamily: "var(--font-inter)",
  fontWeight: 400,
  align: "left",
  createdAt: Date.now(),
  updatedAt: Date.now(),
};
store.addElement(branchingText, true);

// Future history must be cleared on divergent action
assert(useWhiteboard.getState().history.future.length === 0, "Branching action completely clears future redo history");
assert(!useWhiteboard.getState().canRedo(), "canRedo is false after new branch committed");

// Verify undoing the branch restores the pre-branch state
store.undo();
const currentElements = useWhiteboard.getState().boards.find((b) => b.id === historyBoardId)!.elements;
assert(!currentElements.some((e) => e.id === "branch-text-1"), "Undoing branch removes the divergent element");
assert(useWhiteboard.getState().canRedo(), "canRedo is true after undoing branch");

store.redo();
const redoneElements = useWhiteboard.getState().boards.find((b) => b.id === historyBoardId)!.elements;
assert(redoneElements.some((e) => e.id === "branch-text-1"), "Redoing branch restores the divergent element");

console.log("  ✓ 50-step circular history stack, boundary overflows, and branching invariants verified\n");

// ============================================================================
// FINAL SUMMARY
// ============================================================================
console.log("===================================================================");
console.log(`=== CHALLENGER 2 SUITE COMPLETE: ${passedAssertions}/${totalAssertions} ASSERTIONS PASSED (100%) ===`);
console.log("===================================================================");
