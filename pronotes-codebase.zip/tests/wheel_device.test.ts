/**
 * Wheel device classification.
 *
 * The bug this pins: "sometimes when I drag down it zooms in instead".
 * `looksLikeMouseWheel` judged a single event, and a Windows precision
 * touchpad flicked straight down produces deltaX exactly 0 with an integer
 * deltaY over 50 — byte-for-byte what a wheel notch looks like. The same
 * gesture with a little sideways drift read as a trackpad. One gesture, two
 * answers, so the canvas zoomed at random.
 */

import assert from "node:assert/strict";

import {
  cameraPanForScroll,
  createWheelDeviceState,
  observeWheel,
  resolveWheelAction,
  wheelSourceOf,
  TRACKPAD_STREAM_GAP_MS,
  WHEEL_GESTURE_GAP_MS,
  type RawWheel,
  type WheelDeviceState,
} from "../src/lib/whiteboard/input";

let passed = 0;
let failed = 0;
function test(name: string, fn: () => void) {
  try {
    fn();
    passed++;
    console.log(`  ✓ ${name}`);
  } catch (err) {
    failed++;
    console.error(`  ✗ ${name}`);
    console.error(`      ${(err as Error).message}`);
  }
}

function ev(dy: number, dx = 0, deltaMode = 0): RawWheel {
  return { deltaX: dx, deltaY: dy, deltaMode, ctrlKey: false, metaKey: false, shiftKey: false };
}

/** Feeds a stream of events and returns the state plus the final source. */
function feed(
  frames: Array<{ dy: number; dx?: number; deltaMode?: number; gap?: number }>,
  start = 1000
): { state: WheelDeviceState; source: string } {
  let state = createWheelDeviceState();
  let t = start;
  let last = ev(0);
  for (const f of frames) {
    t += f.gap ?? 8; // touchpads stream at roughly 8-16ms
    last = ev(f.dy, f.dx ?? 0, f.deltaMode ?? 0);
    state = observeWheel(state, { deltaX: last.deltaX, deltaY: last.deltaY, deltaMode: last.deltaMode, time: t });
  }
  return { state, source: wheelSourceOf(state, last) };
}

console.log("\n── Wheel device classification ──");

// --- the reported bug --------------------------------------------------------

test("a straight-down touchpad flick is NOT mistaken for a mouse wheel", () => {
  // Every frame looks exactly like a wheel notch on its own: dx=0, integer, >=50.
  const { source } = feed([
    { dy: 53 }, { dy: 61 }, { dy: 72 }, { dy: 66 }, { dy: 54 },
  ]);
  assert.equal(source, "trackpad", "the stream cadence gives the device away");
});

test("and that gesture pans instead of zooming", () => {
  const { state } = feed([{ dy: 53 }, { dy: 61 }, { dy: 72 }]);
  const action = resolveWheelAction(ev(72), "auto", wheelSourceOf(state, ev(72)));
  assert.equal(action.kind, "pan", "this is the zoom-instead-of-scroll bug");
});

test("one sideways-drifting frame settles the whole gesture as trackpad", () => {
  // The old per-event test flipped mid-gesture: drifting frames panned and
  // straight frames zoomed. The verdict must carry.
  const { source } = feed([{ dy: 40, dx: 3 }, { dy: 55 }, { dy: 60 }]);
  assert.equal(source, "trackpad");
});

test("a real mouse wheel still zooms", () => {
  // Discrete notches, far apart, no horizontal component.
  const { state } = feed([{ dy: 100, gap: 180 }, { dy: 100, gap: 200 }]);
  const action = resolveWheelAction(ev(100), "auto", wheelSourceOf(state, ev(100)));
  assert.equal(action.kind, "zoom");
  assert.ok(action.kind === "zoom" && action.factor < 1, "scrolling down zooms out");
});

test("a single isolated notch with no history is read as a wheel", () => {
  const state = createWheelDeviceState();
  assert.equal(wheelSourceOf(state, ev(120)), "mouse", "falls back to the one-event guess");
});

// --- decisive signals --------------------------------------------------------

test("line units mean a real wheel, whatever the cadence", () => {
  const { source } = feed([{ dy: 3, deltaMode: 1 }, { dy: 3, deltaMode: 1 }, { dy: 3, deltaMode: 1 }]);
  assert.equal(source, "mouse");
});

test("a fractional delta can only be a trackpad", () => {
  const { source } = feed([{ dy: 12.5, gap: 200 }]);
  assert.equal(source, "trackpad");
});

test("any horizontal movement means a trackpad", () => {
  const { source } = feed([{ dy: 80, dx: -2, gap: 300 }]);
  assert.equal(source, "trackpad");
});

// --- memory and re-decision --------------------------------------------------

test("the verdict is held across the gesture, not recomputed each event", () => {
  let { state } = feed([{ dy: 10.5 }, { dy: 11 }]); // fraction proves trackpad
  // A later frame that looks exactly like a wheel notch must not flip it.
  state = observeWheel(state, { deltaX: 0, deltaY: 120, deltaMode: 0, time: 1100 });
  assert.equal(wheelSourceOf(state, ev(120)), "trackpad");
});

test("a long pause starts a new gesture and re-decides", () => {
  let { state } = feed([{ dy: 10.5 }, { dy: 11 }]);
  assert.equal(wheelSourceOf(state, ev(11)), "trackpad");

  // Switch devices: pause, then discrete notches.
  let t = 5000;
  for (let i = 0; i < 3; i++) {
    t += WHEEL_GESTURE_GAP_MS + 100;
    state = observeWheel(state, { deltaX: 0, deltaY: 100, deltaMode: 0, time: t });
  }
  assert.equal(wheelSourceOf(state, ev(100)), "mouse", "the old verdict must not stick forever");
});

test("events right at the stream threshold are not called a stream", () => {
  const { source } = feed([
    { dy: 100, gap: TRACKPAD_STREAM_GAP_MS },
    { dy: 100, gap: TRACKPAD_STREAM_GAP_MS },
    { dy: 100, gap: TRACKPAD_STREAM_GAP_MS },
  ]);
  assert.equal(source, "mouse", "the cadence rule is strictly below the threshold");
});

// --- settings still win ------------------------------------------------------

test("an explicit Mouse setting overrides the detector", () => {
  const { state } = feed([{ dy: 12.5 }, { dy: 11.2 }, { dy: 10.9 }]);
  const action = resolveWheelAction(ev(12.5), "mouse", wheelSourceOf(state, ev(12.5)));
  assert.equal(action.kind, "zoom");
});

test("an explicit Trackpad setting overrides the detector", () => {
  const { state } = feed([{ dy: 100, gap: 300 }, { dy: 100, gap: 300 }]);
  const action = resolveWheelAction(ev(100), "trackpad", wheelSourceOf(state, ev(100)));
  assert.equal(action.kind, "pan");
});

test("a pinch always zooms, on either device", () => {
  const pinch: RawWheel = { ...ev(-8.5), ctrlKey: true };
  assert.equal(resolveWheelAction(pinch, "trackpad", "trackpad").kind, "zoom");
  assert.equal(resolveWheelAction(pinch, "auto", "trackpad").kind, "zoom");
});

// --- scroll direction --------------------------------------------------------
//
// `panCamera(dx, dy)` does `camera -= delta`: it takes a DRAG delta and moves
// the content with your hand. A scroll delta means the opposite, so these
// tests pin the conversion end to end — the bug was scrolling backwards.

/** What the camera's y becomes after scrolling by `deltaY`, from y = 0. */
function cameraYAfterScroll(deltaY: number, zoom = 1): number {
  const action = resolveWheelAction(ev(deltaY), "trackpad", "trackpad");
  assert.equal(action.kind, "pan", "trackpad mode must pan, not zoom");
  const pan = cameraPanForScroll(action as { kind: "pan"; dx: number; dy: number });
  // mirrors the store's panCamera
  return 0 - pan.dy / zoom;
}

test("scrolling DOWN moves the view down the page", () => {
  assert.ok(cameraYAfterScroll(120) > 0, "camera.y must increase, or the page scrolls backwards");
});

test("swiping UP on the touchpad does not move the view up", () => {
  // The reported bug, stated as the user hit it.
  assert.ok(cameraYAfterScroll(-120) < 0);
});

test("scrolling is symmetric: down then up returns to the start", () => {
  assert.equal(cameraYAfterScroll(120) + cameraYAfterScroll(-120), 0);
});

test("horizontal scroll follows the same convention", () => {
  const action = resolveWheelAction(
    { deltaX: 90, deltaY: 0, deltaMode: 0, ctrlKey: false, metaKey: false, shiftKey: false },
    "trackpad",
    "trackpad"
  );
  const pan = cameraPanForScroll(action as { kind: "pan"; dx: number; dy: number });
  assert.ok(0 - pan.dx > 0, "scrolling right shows content further right");
});

test("cameraPanForScroll is its own inverse", () => {
  const once = cameraPanForScroll({ dx: 7, dy: -3 });
  assert.deepEqual(cameraPanForScroll(once), { dx: 7, dy: -3 });
});

console.log(`\n  ${passed} passed, ${failed} failed\n`);
if (failed > 0) process.exit(1);
