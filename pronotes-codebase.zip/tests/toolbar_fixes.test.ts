/**
 * Tests for the Toolbar & Navigation Architecture Fixes:
 * - Shape stroke & fill color consistency in setToolInk and StyleState
 * - Sticky note color integration in getToolColor / setToolInk
 * - Context-aware undo/redo (canUndo/canRedo) scoped to active board
 * - Selection filter enforcement (passesSelectFilter) for single-click selection
 * - Store pagePanelOpen toggle, setter, and initial state
 * - Favorite pens bar pushOutOfRect screen boundary clamping
 */

import assert from "node:assert/strict";
import {
  DEFAULT_STYLE,
  setToolInk,
  getToolColor,
  type ToolType,
  passesSelectFilter,
  type SelectCategory,
  STICKY_COLORS,
} from "../src/lib/whiteboard/types";
import { useWhiteboard } from "../src/store/whiteboard";

let passed = 0;
let failed = 0;
function test(name: string, fn: () => void) {
  try {
    fn();
    passed++;
    console.log(`  ✓ ${name}`);
  } catch (err) {
    failed++;
    console.error(`  ✗ ${name}`);
    console.error(`      ${(err as Error).message}`);
  }
}

console.log("\n── Toolbar & Navigation Architecture Fixes ──");

test("BUG-06 & BUG-07: setToolInk on shape tools sets shapeStrokeColor, shapeFillColor, and strokeColor", () => {
  const shapes: ToolType[] = ["rectangle", "ellipse", "diamond", "triangle", "star", "cloud"];
  for (const tool of shapes) {
    const patch = setToolInk(DEFAULT_STYLE, tool, { color: "#3b82f6" });
    assert.equal(
      (patch as { shapeStrokeColor?: string }).shapeStrokeColor,
      "#3b82f6",
      `${tool}: shapeStrokeColor must be set`
    );
    assert.equal(
      (patch as { shapeFillColor?: string }).shapeFillColor,
      "#3b82f6",
      `${tool}: shapeFillColor must follow color pick`
    );
    assert.equal(
      (patch as { strokeColor?: string }).strokeColor,
      "#3b82f6",
      `${tool}: strokeColor must be set for backward compatibility`
    );
  }
});

test("BUG-16: Sticky note color is properly read and updated via getToolColor and setToolInk", () => {
  const customStyle = { ...DEFAULT_STYLE, stickyColor: "pink" as const };
  assert.equal(getToolColor(customStyle, "sticky"), STICKY_COLORS.pink.bg);

  const updated = setToolInk(DEFAULT_STYLE, "sticky", { color: "blue" });
  assert.equal((updated as { stickyColor?: string }).stickyColor, "blue");

  // Invalid color falls back to yellow
  const fallback = setToolInk(DEFAULT_STYLE, "sticky", { color: "nonexistent_color" });
  assert.equal((fallback as { stickyColor?: string }).stickyColor, "yellow");
});

test("BUG-08: passesSelectFilter strictly filters elements according to active filter category", () => {
  const strokeEl = { type: "stroke" as const };
  const textEl = { type: "text" as const };
  const stickyEl = { type: "sticky" as const };
  const rectEl = { type: "rectangle" as const };
  const starEl = { type: "star" as const };
  const imgEl = { type: "image" as const };

  const inkOnly = new Set<SelectCategory>(["ink"]);
  assert.equal(passesSelectFilter(strokeEl, inkOnly), true);
  assert.equal(passesSelectFilter(textEl, inkOnly), false);
  assert.equal(passesSelectFilter(stickyEl, inkOnly), false);
  assert.equal(passesSelectFilter(rectEl, inkOnly), false);
  assert.equal(passesSelectFilter(imgEl, inkOnly), false);

  const textAndShapes = new Set<SelectCategory>(["text", "shapes"]);
  assert.equal(passesSelectFilter(strokeEl, textAndShapes), false);
  assert.equal(passesSelectFilter(textEl, textAndShapes), true);
  assert.equal(passesSelectFilter(stickyEl, textAndShapes), true);
  assert.equal(passesSelectFilter(rectEl, textAndShapes), true);
  assert.equal(passesSelectFilter(starEl, textAndShapes), true);
  assert.equal(passesSelectFilter(imgEl, textAndShapes), false);
});

test("BUG-09: canUndo and canRedo are strictly scoped to the active board context", () => {
  const store = useWhiteboard.getState();
  const boardA = store.createBoard("Board A", null);
  const boardB = store.createBoard("Board B", null);

  // Switch to board A and commit an entry
  store.setActiveBoard(boardA);
  assert.equal(store.canUndo(), false, "Board A has no history yet");
  assert.equal(store.canRedo(), false);

  store.commitHistory();
  assert.equal(store.canUndo(), true, "Board A has undo after commit");

  // Switch to board B: should NOT see Board A's undo
  store.setActiveBoard(boardB);
  assert.equal(store.canUndo(), false, "Board B must not inherit Board A's undo history");

  // Switch back to Board A: undo is restored
  store.setActiveBoard(boardA);
  assert.equal(store.canUndo(), true, "Board A retains its undo history");
});

test("BUG-01: pagePanelOpen store property toggles and updates correctly", () => {
  const store = useWhiteboard.getState();
  store.setPagePanelOpen(false);
  assert.equal(useWhiteboard.getState().pagePanelOpen, false);

  store.togglePagePanel();
  assert.equal(useWhiteboard.getState().pagePanelOpen, true);

  store.togglePagePanel();
  assert.equal(useWhiteboard.getState().pagePanelOpen, false);

  store.setPagePanelOpen(true);
  assert.equal(useWhiteboard.getState().pagePanelOpen, true);
  store.setPagePanelOpen(false);
});

test("BUG-15: zoomTo(1) resets zoom level while preserving user pan coordinates (x, y)", () => {
  useWhiteboard.getState().setCamera({ x: 540, y: 720, zoom: 2.4 });
  assert.equal(useWhiteboard.getState().camera.zoom, 2.4);
  assert.equal(useWhiteboard.getState().camera.x, 540);
  assert.equal(useWhiteboard.getState().camera.y, 720);

  // Zooming to 100% via zoomTo(1) preserves the pan coordinates
  useWhiteboard.getState().zoomTo(1);
  const cam = useWhiteboard.getState().camera;
  assert.equal(cam.zoom, 1);
  assert.equal(cam.x, 540, "Pan X coordinate must not be clobbered");
  assert.equal(cam.y, 720, "Pan Y coordinate must not be clobbered");
});

console.log(`\n${passed} passed, ${failed} failed.\n`);
if (failed > 0) {
  process.exit(1);
}
