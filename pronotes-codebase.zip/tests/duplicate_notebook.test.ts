/**
 * Tests for Duplicating a Notebook with Page Range & Destination,
 * and Single-Step Undo/Redo for Notebook Page Merges.
 */

import assert from "node:assert/strict";
import { useWhiteboard } from "../src/store/whiteboard";
import { getPages } from "../src/lib/whiteboard/notebook";
import type {
  Board,
  ConnectionElement,
  NotebookPage,
  StrokeElement,
} from "../src/lib/whiteboard/types";
import { cleanHistoryEntry } from "../src/lib/whiteboard/persistence";

let passed = 0;
let failed = 0;
function test(name: string, fn: () => void) {
  try {
    fn();
    passed++;
    console.log(`  ✓ ${name}`);
  } catch (err) {
    failed++;
    console.error(`  ✗ ${name}`);
    console.error(`      ${(err as Error).message}`);
  }
}

const S = () => useWhiteboard.getState();
const getBoard = (id: string): Board => S().boards.find((b) => b.id === id)!;

let seq = 0;
function makeBlankNotebook(name: string, pageCount: number): Board {
  const id = `nb_${Date.now()}_${++seq}`;
  const pages: NotebookPage[] = [];
  for (let i = 0; i < pageCount; i++) {
    pages.push({
      id: `page_${id}_${i}`,
      elements: [],
      createdAt: 1000 + i,
      updatedAt: 1000 + i,
    });
  }
  return {
    id,
    name,
    kind: "notebook",
    pageSize: "a4",
    folderId: null,
    elements: [],
    pages,
    activePageId: pages[0]?.id ?? "",
    camera: { x: 0, y: 0, zoom: 1 },
    createdAt: 1000,
    updatedAt: 1000,
  };
}

function makeStroke(id: string, x: number, y: number): StrokeElement {
  return {
    id,
    type: "stroke",
    x,
    y,
    rotation: 0,
    opacity: 1,
    color: "#000000",
    strokeWidth: 2,
    strokeStyle: "ballpoint",
    points: [[0, 0, 0.5], [10, 10, 0.5]],
    createdAt: 1000,
    updatedAt: 1000,
  };
}

function makeConnection(id: string, fromId: string, toId: string, boardId: string): ConnectionElement {
  return {
    id,
    type: "connection",
    x: 0,
    y: 0,
    rotation: 0,
    opacity: 1,
    source: { boardId, elementId: fromId, anchor: "center" },
    target: { boardId, elementId: toId, anchor: "center" },
    routing: "straight",
    linkType: "relates",
    dashStyle: "solid",
    startArrowhead: "none",
    endArrowhead: "arrow",
    strokeWidth: 2,
    createdAt: 1000,
    updatedAt: 1000,
  } as ConnectionElement;
}

function resetStoreWithBoards(boards: Board[], activeId?: string) {
  useWhiteboard.setState({
    boards,
    activeBoardId: activeId ?? boards[0]?.id ?? null,
    folders: [
      {
        id: "folder_1",
        name: "Semester 1",
        parentId: null,
        expanded: true,
        createdAt: 1000,
      },
    ],
    selectedIds: [],
    editingId: null,
    history: { past: [], future: [] },
  });
}

console.log("\n── Duplicate Notebook & Single-Step Merge Undo Tests ──");

test("duplicateNotebook copies only chosen page indices into a new notebook in target folder", () => {
  const nb = makeBlankNotebook("Calculus", 5);
  const nbPages = getPages(nb);
  nbPages.forEach((p, idx) => {
    p.elements.push(makeStroke(`el_${idx}`, 10 * idx, 10 * idx));
  });

  resetStoreWithBoards([nb], nb.id);

  // Duplicate pages 1 and 3 (0-based indices 1 and 3) to folder_1
  const copyId = S().duplicateNotebook(nb.id, {
    name: "Calculus Subset",
    folderId: "folder_1",
    pageIndices: [1, 3],
  });

  assert.ok(copyId, "Must return new notebook id");
  const copy = getBoard(copyId!);
  assert.ok(copy, "New notebook must exist in store");
  assert.equal(copy.name, "Calculus Subset");
  assert.equal(copy.folderId, "folder_1");
  assert.equal(copy.kind, "notebook");
  assert.equal(copy.elements.length, 0, "board.elements must be strictly empty for notebooks");

  const copyPages = getPages(copy);
  assert.equal(copyPages.length, 2, "Must contain exactly 2 pages");
  assert.equal(copyPages[0].elements[0].id.startsWith("el_1"), false, "Element ID must be remapped");
  assert.equal(copyPages[0].elements[0].x, 10, "First copied page should have page index 1's content");
  assert.equal(copyPages[1].elements[0].x, 30, "Second copied page should have page index 3's content");

  // Verify active board was NOT switched
  assert.equal(S().activeBoardId, nb.id, "Active board must not switch on duplicate");
});

test("duplicateNotebook ensures every copied element receives a fresh id", () => {
  const nb = makeBlankNotebook("Physics", 2);
  const nbPages = getPages(nb);
  nbPages[0].elements.push(makeStroke("orig_stroke_1", 0, 0));

  resetStoreWithBoards([nb], nb.id);

  const copyId = S().duplicateNotebook(nb.id, {
    name: "Physics Copy",
    folderId: null,
    pageIndices: [0],
  })!;

  const copy = getBoard(copyId);
  const copyPages = getPages(copy);
  const copyElem = copyPages[0].elements[0];
  assert.notEqual(copyElem.id, "orig_stroke_1", "Copied element must have a fresh id");
  assert.equal(copyElem.type, "stroke");
});

test("duplicateNotebook remaps connections between copied elements and prunes dangling connections", () => {
  const nb = makeBlankNotebook("Diagrams", 2);
  const strokeA = makeStroke("stroke_a", 10, 10);
  const strokeB = makeStroke("stroke_b", 100, 100);
  const internalConn = makeConnection("conn_ab", "stroke_a", "stroke_b", nb.id);
  const strokeOnPage2 = makeStroke("stroke_page2", 200, 200);
  const crossPageConn = makeConnection("conn_cross", "stroke_a", "stroke_page2", nb.id);

  const nbPages = getPages(nb);
  nbPages[0].elements.push(strokeA, strokeB, internalConn, crossPageConn);
  nbPages[1].elements.push(strokeOnPage2);

  resetStoreWithBoards([nb], nb.id);

  // Duplicate ONLY Page 0
  const copyId = S().duplicateNotebook(nb.id, {
    name: "Diagrams Page 1 Only",
    folderId: null,
    pageIndices: [0],
  })!;

  const copy = getBoard(copyId);
  const copyPages = getPages(copy);
  const elements = copyPages[0].elements;

  // The internal connection between A and B must be remapped and kept
  const remappedConn = elements.find((el) => el.type === "connection") as ConnectionElement;
  assert.ok(remappedConn, "Internal connection must be preserved");
  assert.notEqual(remappedConn.id, "conn_ab", "Connection must have new id");
  assert.notEqual(remappedConn.source.elementId, "stroke_a");
  assert.notEqual(remappedConn.target.elementId, "stroke_b");
  assert.equal(remappedConn.source.boardId, copyId);
  assert.equal(remappedConn.target.boardId, copyId);

  // The cross-page connection to Page 2 must be pruned
  const crossConnInCopy = elements.find((el) => el.id === "conn_cross");
  assert.equal(crossConnInCopy, undefined, "Dangling connection must be pruned");
  assert.equal(elements.filter((el) => el.type === "connection").length, 1);
});

test("duplicateNotebook preserves referenced pdfDocIds on the new board and omits unreferenced ones", () => {
  const nb = makeBlankNotebook("Lecture", 2);
  nb.pdfDocIds = ["pdf_lecture_notes_1", "pdf_unreferenced_page2"];
  const nbPages = getPages(nb);
  nbPages[0].pdf = { docId: "pdf_lecture_notes_1", pageNumber: 3 };
  nbPages[1].pdf = { docId: "pdf_unreferenced_page2", pageNumber: 1 };

  resetStoreWithBoards([nb], nb.id);

  const copyId = S().duplicateNotebook(nb.id, {
    name: "Lecture Page 1",
    folderId: null,
    pageIndices: [0],
  })!;

  const copy = getBoard(copyId);
  // Only the referenced PDF doc must be preserved, not unreferenced ones
  assert.deepEqual(copy.pdfDocIds, ["pdf_lecture_notes_1"]);
  const copyPages = getPages(copy);
  assert.equal(copyPages[0].pdf?.docId, "pdf_lecture_notes_1");
  assert.equal(copyPages[0].pdf?.pageNumber, 3);
});

test("duplicateNotebook leaves the source notebook strictly unmodified (byte-identical)", () => {
  const nb = makeBlankNotebook("Original", 3);
  const nbPages = getPages(nb);
  nbPages[0].elements.push(makeStroke("el1", 5, 5));

  resetStoreWithBoards([nb], nb.id);
  const snapshotBefore = JSON.stringify(getBoard(nb.id));

  S().duplicateNotebook(nb.id, {
    name: "Copy",
    folderId: null,
    pageIndices: [0, 1],
  });

  const snapshotAfter = JSON.stringify(getBoard(nb.id));
  assert.equal(snapshotBefore, snapshotAfter, "Source notebook must be byte-identical after duplicate");
});

test("insertPagesFromBoard into arbitrary target notebook is undoable in exactly ONE step", () => {
  const source = makeBlankNotebook("Source", 3);
  const sourcePages = getPages(source);
  sourcePages[0].pdf = { docId: "pdf_from_source", pageNumber: 1 };
  const target = makeBlankNotebook("Target", 2);
  target.pdfDocIds = [];

  resetStoreWithBoards([source, target], target.id);

  const initialTargetPages = JSON.stringify(getPages(getBoard(target.id)));

  // Merge pages 0 and 2 from source into target at index 1 (between page 1 and page 2)
  const insertedCount = S().insertPagesFromBoard(
    source.id,
    { indices: [0, 2] },
    1,
    target.id
  );

  assert.equal(insertedCount, 2, "Must insert 2 pages");
  const postMergePages = getPages(getBoard(target.id));
  assert.equal(postMergePages.length, 4, "Target must now have 4 pages");
  assert.deepEqual(getBoard(target.id).pdfDocIds, ["pdf_from_source"]);

  // Verify exactly 1 history entry was added
  const history = S().history;
  assert.equal(history.past.length, 1, "Exactly one history entry must be pushed for the merge");
  assert.equal(history.past[0].boardId, target.id);
  assert.ok(history.past[0].pages, "History entry must carry pages snapshot");
  assert.equal(history.past[0].pages?.length, 2, "Snapshot must preserve 2 pre-merge pages");

  // Verify source notebook does NOT appear in history at all
  assert.ok(
    history.past.every((e) => e.boardId !== source.id),
    "Source notebook must not appear in history"
  );

  // Press UNDO once: must completely revert the merge AND the pdfDocIds
  S().undo();

  const undoneTargetPages = JSON.stringify(getPages(getBoard(target.id)));
  assert.equal(undoneTargetPages, initialTargetPages, "Target notebook must revert to exact pre-merge pages");
  assert.deepEqual(getBoard(target.id).pdfDocIds, [], "Undo must restore pre-merge pdfDocIds");
  assert.equal(S().history.past.length, 0, "Past history must be empty after undo");
  assert.equal(S().history.future.length, 1, "Future history must have 1 redo entry");

  // Press REDO: must symmetrically restore the merged pages AND pdfDocIds
  S().redo();

  const redoneTargetPages = getPages(getBoard(target.id));
  assert.equal(redoneTargetPages.length, 4, "Redo must restore 4 pages");
  assert.deepEqual(getBoard(target.id).pdfDocIds, ["pdf_from_source"]);

  // Press UNDO again: reverts again
  S().undo();
  assert.equal(
    JSON.stringify(getPages(getBoard(target.id))),
    initialTargetPages,
    "Second undo must revert back to pre-merge pages"
  );
  assert.deepEqual(getBoard(target.id).pdfDocIds, []);
});

test("merging into an inactive notebook leaves active board unchanged, and undo cleanly reverts the inactive notebook", () => {
  const activeNb = makeBlankNotebook("ActiveNotebook", 2);
  const inactiveTarget = makeBlankNotebook("InactiveTarget", 2);
  const sourceNb = makeBlankNotebook("SourceNotebook", 3);

  resetStoreWithBoards([activeNb, inactiveTarget, sourceNb], activeNb.id);

  // Set camera and selection on active board
  useWhiteboard.setState({
    camera: { x: 42, y: 99, zoom: 1.5 },
    selectedIds: ["dummy_sel"],
  });

  const preMergeInactive = JSON.stringify(getPages(getBoard(inactiveTarget.id)));

  // Merge into inactiveTarget
  S().insertPagesFromBoard(sourceNb.id, { indices: [1] }, 2, inactiveTarget.id);

  // Verify active board state is completely untouched
  assert.equal(S().activeBoardId, activeNb.id, "Active board ID must remain untouched");
  assert.deepEqual(S().camera, { x: 42, y: 99, zoom: 1.5 }, "Camera must remain untouched");
  assert.deepEqual(S().selectedIds, ["dummy_sel"], "Selected IDs must remain untouched");

  // Verify inactive target received the page
  assert.equal(getPages(getBoard(inactiveTarget.id)).length, 3);

  // Press undo
  S().undo();

  // Inactive target reverted
  assert.equal(
    JSON.stringify(getPages(getBoard(inactiveTarget.id))),
    preMergeInactive,
    "Inactive target must revert to pre-merge state in background"
  );
  // Active board still untouched
  assert.equal(S().activeBoardId, activeNb.id);
  assert.deepEqual(S().camera, { x: 42, y: 99, zoom: 1.5 });
  assert.deepEqual(S().selectedIds, ["dummy_sel"]);
});

test("duplicateNotebook on a canvas remaps connections to the new board with fresh ids", () => {
  const canvasId = `canvas_${Date.now()}_${++seq}`;
  const strokeA = makeStroke("c_stroke_a", 10, 10);
  const strokeB = makeStroke("c_stroke_b", 100, 100);
  const conn = makeConnection("c_conn_ab", "c_stroke_a", "c_stroke_b", canvasId);
  const canvas: Board = {
    id: canvasId,
    name: "Sketch",
    kind: "canvas",
    folderId: null,
    elements: [strokeA, strokeB, conn],
    camera: { x: 0, y: 0, zoom: 1 },
    createdAt: 1000,
    updatedAt: 1000,
  };

  resetStoreWithBoards([canvas], canvas.id);

  const copyId = S().duplicateNotebook(canvas.id, {
    name: "Sketch Copy",
    folderId: null,
  })!;

  const copy = getBoard(copyId);
  assert.equal(copy.kind, "notebook");
  assert.equal(copy.elements.length, 0, "board.elements must be strictly empty for notebooks");
  const copyPages = getPages(copy);
  assert.equal(copyPages.length, 1, "Canvas duplicate must become a single-page notebook");
  const elements = copyPages[0].elements;
  assert.equal(elements.length, 3, "All canvas elements must be carried over");

  // Every element id must be fresh — none of the canvas ids may survive.
  const ids = new Set(elements.map((el) => el.id));
  assert.equal(ids.size, 3, "Copied element ids must be unique");
  for (const oldId of ["c_stroke_a", "c_stroke_b", "c_conn_ab"]) {
    assert.ok(!ids.has(oldId), `Old id ${oldId} must not survive the copy`);
  }

  // The connection must point at the NEW board and the NEW element ids.
  const copyConn = elements.find((el) => el.type === "connection") as ConnectionElement;
  assert.ok(copyConn, "Connection must survive the canvas copy");
  assert.equal(copyConn.source.boardId, copyId, "Connection source must target the new board");
  assert.equal(copyConn.target.boardId, copyId, "Connection target must target the new board");
  assert.ok(ids.has(copyConn.source.elementId), "Connection source must reference a copied element");
  assert.ok(ids.has(copyConn.target.elementId), "Connection target must reference a copied element");

  // Source canvas must be untouched.
  assert.equal(getBoard(canvasId).elements.length, 3, "Source canvas must be unmodified");
});

test("duplicateNotebook dedupes repeated page indices instead of colliding element ids", () => {
  const nb = makeBlankNotebook("Repeat", 2);
  const nbPages = getPages(nb);
  nbPages[0].elements.push(makeStroke("rep_el_0", 1, 1));
  nbPages[1].elements.push(makeStroke("rep_el_1", 2, 2));

  resetStoreWithBoards([nb], nb.id);

  const copyId = S().duplicateNotebook(nb.id, {
    name: "Repeat Copy",
    folderId: null,
    pageIndices: [0, 0, 1],
  })!;

  const copy = getBoard(copyId);
  const copyPages = getPages(copy);
  assert.equal(copyPages.length, 2, "Repeated indices must be deduped to 2 pages");
  const allIds = copyPages.flatMap((p) => p.elements.map((el) => el.id));
  assert.equal(new Set(allIds).size, allIds.length, "Element ids must be unique across copied pages");
});

test("insertPagesFromBoard dedupes repeated indices into a single insertion", () => {
  const source = makeBlankNotebook("DupSource", 2);
  const target = makeBlankNotebook("DupTarget", 1);

  resetStoreWithBoards([source, target], target.id);
  const before = S().history.past.length;

  const inserted = S().insertPagesFromBoard(source.id, { indices: [0, 0, 1] }, 1, target.id);

  assert.equal(inserted, 2, "Repeated indices must insert 2 pages, not 3");
  assert.equal(getPages(getBoard(target.id)).length, 3, "Target must grow by exactly 2 pages");
  assert.equal(S().history.past.length, before + 1, "Deduped merge must still push exactly one history entry");

  S().undo();
  assert.equal(getPages(getBoard(target.id)).length, 1, "Single undo must revert the deduped merge");
});

test("persistence cleanHistoryEntry validates both legacy elements-only entries and pages entries", () => {
  // Legacy entry with elements only
  const legacyRaw = {
    boardId: "board_123",
    pageId: "page_1",
    elements: [
      { id: "e1", type: "stroke" },
      { id: "e2", type: "text" },
    ],
    at: 5000,
  };
  const legacyCleaned = cleanHistoryEntry(legacyRaw);
  assert.ok(legacyCleaned, "Legacy entry must be valid");
  assert.equal(legacyCleaned?.boardId, "board_123");
  assert.equal(legacyCleaned?.elements.length, 2);
  assert.equal(legacyCleaned?.pages, undefined);

  // New entry with pages snapshot
  const newRaw = {
    boardId: "board_456",
    pageId: "page_2",
    elements: [],
    pages: [
      {
        id: "p1",
        elements: [{ id: "el_p1", type: "stroke" }],
      },
      {
        id: "p2",
        elements: [],
      },
    ],
    at: 6000,
  };
  const newCleaned = cleanHistoryEntry(newRaw);
  assert.ok(newCleaned, "Pages history entry must be valid");
  assert.equal(newCleaned?.boardId, "board_456");
  assert.equal(newCleaned?.pages?.length, 2);
  assert.equal(newCleaned?.pages?.[0].elements[0].id, "el_p1");

  // Corrupt entries must be rejected safely
  assert.equal(cleanHistoryEntry(null), null);
  assert.equal(cleanHistoryEntry({}), null);
  assert.equal(cleanHistoryEntry({ boardId: 123 }), null);
  assert.equal(cleanHistoryEntry({ boardId: "b", elements: "not_array" }), null);
  assert.equal(cleanHistoryEntry({ boardId: "b", elements: [{ id: 123 }] }), null);
});

console.log(`\n${passed} passed, ${failed} failed.`);
if (failed > 0) process.exit(1);
