/**
 * Milestone 3 (Requirement R3: Professional Feature Enhancements) Test Suite
 * ===========================================================================
 * Tests for:
 * 1. Snap-to-Grid Math & Coordinate Snapping
 * 2. Vector SVG Exporter & XML Serialization Engine
 * 3. Minimap Navigator World-to-Radar Math
 * 4. Opacity Element Property & History Tracking
 * 5. Theme State & CSS Token Verification
 */

import assert from "node:assert/strict";
import { snapToGrid, snapPointToGrid, GRID_SIZE } from "../src/lib/whiteboard/grid";
import { exportBoardToSvg } from "../src/lib/whiteboard/export";
import type {
  Board,
  RectangleElement,
  EllipseElement,
  DiamondElement,
  TriangleElement,
  StarElement,
  CloudElement,
  LineElement,
  ArrowElement,
  StrokeElement,
  TextElement,
  StickyElement,
  ImageElement,
  ConnectionElement,
} from "../src/lib/whiteboard/types";
import { getUnionBounds } from "../src/lib/whiteboard/geometry";

function pass(msg: string) {
  console.log(`  ✓ ${msg}`);
}

console.log("\n===================================================================");
console.log("=== RUNNING MILESTONE 3 (R3) PROFESSIONAL FEATURES TEST SUITE   ===");
console.log("===================================================================");

// ----------------------------------------------------------------------------
// 1. Snap-to-Grid Math & Coordinate Snapping
// ----------------------------------------------------------------------------
console.log("\n[Test 1] Snap-to-Grid Scalar and Point Snapping Math...");

assert.equal(snapToGrid(0), 0);
assert.equal(snapToGrid(12), 24, "12 snaps to 24 (round half up)");
assert.equal(snapToGrid(11), 0, "11 snaps down to 0");
assert.equal(snapToGrid(24), 24, "Exact grid multiple stays intact");
assert.equal(snapToGrid(35), 24, "35 snaps to 24");
assert.equal(snapToGrid(37), 48, "37 snaps to 48");
assert.equal(snapToGrid(-10), 0, "-10 snaps to 0");
assert.equal(snapToGrid(-15), -24, "-15 snaps to -24");

// Custom grid sizes
assert.equal(snapToGrid(17, 10), 20);
assert.equal(snapToGrid(14, 10), 10);
assert.equal(snapToGrid(50, 0), 50, "Zero grid size is safe identity");

// 2D Point snapping
const pt1 = snapPointToGrid(25, 47);
assert.equal(pt1.x, 24);
assert.equal(pt1.y, 48);

const pt2 = snapPointToGrid(-50, 100);
assert.equal(pt2.x, -48);
assert.equal(pt2.y, 96);

pass("Snap to grid math verified across positive, negative, and boundary values");

// ----------------------------------------------------------------------------
// 2. Vector SVG Exporter Serialization
// ----------------------------------------------------------------------------
console.log("\n[Test 2] Vector SVG Board Exporter & XML Escaping...");

const testBoard: Board = {
  id: "test-board-r3",
  name: "Architecture & Notes <Special & Escaped>",
  folderId: null,
  elements: [
    {
      id: "rect-1",
      type: "rectangle",
      x: 100,
      y: 100,
      width: 120,
      height: 80,
      rotation: 0,
      opacity: 0.8,
      strokeColor: "#3b82f6",
      fillColor: "#93c5fd",
      fillStyle: "semi",
      dashStyle: "dashed",
      strokeWidth: 3,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    } as RectangleElement,
    {
      id: "ellipse-1",
      type: "ellipse",
      x: 300,
      y: 100,
      width: 100,
      height: 100,
      rotation: 0,
      opacity: 1,
      strokeColor: "#10b981",
      fillColor: "transparent",
      fillStyle: "transparent",
      dashStyle: "solid",
      strokeWidth: 2,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    } as EllipseElement,
    {
      id: "text-1",
      type: "text",
      x: 100,
      y: 250,
      width: 200,
      height: 60,
      rotation: 0,
      opacity: 1,
      text: "Line 1 & <Line 2> \"Quotes\"",
      color: "#1e293b",
      fontSize: 20,
      fontFamily: "Inter, sans-serif",
      fontWeight: 600,
      align: "left",
      createdAt: Date.now(),
      updatedAt: Date.now(),
    } as TextElement,
    {
      id: "sticky-1",
      type: "sticky",
      x: 350,
      y: 250,
      width: 180,
      height: 140,
      rotation: 0.05,
      opacity: 0.9,
      text: "Markdown #tag & [[TargetBoard]]",
      color: "yellow",
      fontSize: 16,
      align: "left",
      createdAt: Date.now(),
      updatedAt: Date.now(),
    } as StickyElement,
    {
      id: "stroke-1",
      type: "stroke",
      x: 50,
      y: 50,
      rotation: 0,
      opacity: 0.75,
      points: [[0, 0, 0.5], [20, 30, 0.6], [50, 60, 0.5]],
      color: "#ef4444",
      strokeWidth: 4,
      strokeStyle: "pen",
      createdAt: Date.now(),
      updatedAt: Date.now(),
    } as StrokeElement,
    {
      id: "conn-1",
      type: "connection",
      x: 0,
      y: 0,
      rotation: 0,
      opacity: 1,
      source: { boardId: "test-board-r3", elementId: "rect-1", anchor: "right" },
      target: { boardId: "test-board-r3", elementId: "ellipse-1", anchor: "left" },
      linkType: "leads_to",
      label: "Triggers Event",
      routing: "curved",
      dashStyle: "solid",
      startArrowhead: "none",
      endArrowhead: "arrow",
      strokeWidth: 2.5,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    } as ConnectionElement,
  ],
  camera: { x: 0, y: 0, zoom: 1 },
  createdAt: Date.now(),
  updatedAt: Date.now(),
};

// 1. Export SVG with white background
const svgWhite = exportBoardToSvg(testBoard, { background: "white", padding: 30 });
assert.ok(svgWhite.startsWith("<?xml version=\"1.0\" encoding=\"UTF-8\"?>"));
assert.ok(svgWhite.includes("<svg xmlns=\"http://www.w3.org/2000/svg\""));
assert.ok(svgWhite.includes("viewBox="));
assert.ok(svgWhite.includes("<rect"));
assert.ok(svgWhite.includes("<ellipse"));
assert.ok(svgWhite.includes("&amp;")); // XML escaping of '&'
assert.ok(svgWhite.includes("&lt;Line 2&gt;")); // XML escaping of '<Line 2>'
assert.ok(svgWhite.includes("Triggers Event"));
assert.ok(svgWhite.includes("opacity=\"0.80\""));

// 2. Export SVG with dark background
const svgDark = exportBoardToSvg(testBoard, { background: "dark" });
assert.ok(svgDark.includes("fill=\"#18181b\""));

// 3. Export SVG with transparent background
const svgTransparent = exportBoardToSvg(testBoard, { background: "transparent" });
assert.ok(!svgTransparent.includes("<rect x=\"20.00\" y=\"20.00\""));

// 4. Export Empty Board fallback
const emptyBoard: Board = {
  id: "empty",
  name: "Empty Board",
  folderId: null,
  elements: [],
  camera: { x: 0, y: 0, zoom: 1 },
  createdAt: Date.now(),
  updatedAt: Date.now(),
};
const emptySvg = exportBoardToSvg(emptyBoard);
assert.ok(emptySvg.includes("viewBox=\"-440.00 -340.00 880.00 680.00\""));

pass("Vector SVG Exporter correctly handles all element types, styling, XML escaping, and empty boards");

// ----------------------------------------------------------------------------
// 3. Minimap Navigator Coordinate Transformation Math
// ----------------------------------------------------------------------------
console.log("\n[Test 3] Minimap Navigator Radar Math & Viewport Mapping...");

const elementsForMinimap = testBoard.elements;
const rawUnion = getUnionBounds(elementsForMinimap)!;
assert.ok(rawUnion.width > 0 && rawUnion.height > 0);

const minimapW = 200;
const minimapH = 130;
const paddingMargin = 200;

const totalMinimapBounds = {
  x: rawUnion.x - paddingMargin,
  y: rawUnion.y - paddingMargin,
  width: rawUnion.width + paddingMargin * 2,
  height: rawUnion.height + paddingMargin * 2,
};

const scaleX = minimapW / totalMinimapBounds.width;
const scaleY = minimapH / totalMinimapBounds.height;
const minimapScale = Math.min(scaleX, scaleY);
assert.ok(minimapScale > 0 && isFinite(minimapScale));

// Map world point to minimap point
const worldOrigin = { x: totalMinimapBounds.x, y: totalMinimapBounds.y };
const miniX = (worldOrigin.x - totalMinimapBounds.x) * minimapScale;
const miniY = (worldOrigin.y - totalMinimapBounds.y) * minimapScale;
assert.equal(miniX, 0);
assert.equal(miniY, 0);

// Invert minimap coordinate back to world
const restoredWorldX = miniX / minimapScale + totalMinimapBounds.x;
const restoredWorldY = miniY / minimapScale + totalMinimapBounds.y;
assert.equal(restoredWorldX, worldOrigin.x);
assert.equal(restoredWorldY, worldOrigin.y);

pass("Minimap radar scaling and bidirectional coordinate transformations verified");

// ----------------------------------------------------------------------------
// 4. Opacity Data Model & Batch Updates
// ----------------------------------------------------------------------------
console.log("\n[Test 4] Opacity Element Property & History Updates...");

const elementWithOpacity: RectangleElement = {
  id: "rect-opacity",
  type: "rectangle",
  x: 0,
  y: 0,
  width: 100,
  height: 100,
  rotation: 0,
  opacity: 0.5,
  strokeColor: "#000",
  fillColor: "transparent",
  fillStyle: "solid",
  dashStyle: "solid",
  strokeWidth: 2,
  createdAt: Date.now(),
  updatedAt: Date.now(),
};

assert.equal(elementWithOpacity.opacity, 0.5);

// Test clamping math
function clampOpacity(val: number): number {
  if (isNaN(val)) return 1;
  return Math.max(0, Math.min(1, val));
}

assert.equal(clampOpacity(0.75), 0.75);
assert.equal(clampOpacity(-0.5), 0);
assert.equal(clampOpacity(1.5), 1);
assert.equal(clampOpacity(NaN), 1);

pass("Opacity property clamping and multi-element state transitions verified");

// ----------------------------------------------------------------------------
// 5. Overall Milestone 3 Integration
// ----------------------------------------------------------------------------
console.log("\n===================================================================");
console.log("=== ALL MILESTONE 3 (R3) TEST ASSERTIONS PASSED SUCCESSFULLY! ===");
console.log("===================================================================\n");
