/**
 * Inserting an image: where it lands, how big it is, how it resizes and turns.
 *
 * Reported on a Galaxy Tab S9: an added image "is just added to a random
 * place", could not be placed where wanted, and could not be resized or
 * rotated. These pin the placement rules that fix the first half.
 */

import assert from "node:assert/strict";
import {
  placeImage,
  lockAspect,
  snapRotation,
  IMAGE_FIT_FRACTION,
  IMAGE_MIN_SIDE,
} from "../src/lib/whiteboard/placement";

let passed = 0;
let failed = 0;
function test(name: string, fn: () => void) {
  try {
    fn();
    passed++;
    console.log(`  ✓ ${name}`);
  } catch (err) {
    failed++;
    console.error(`  ✗ ${name}`);
    console.error(`      ${(err as Error).message}`);
  }
}

const A4 = { width: 794, height: 1123 };
const near = (a: number, b: number, eps = 1e-6) => Math.abs(a - b) <= eps;

console.log("\n── Image placement ──");

test("lands in the middle of what you can SEE on the page", () => {
  // Looking at the lower half of the sheet.
  const r = placeImage({
    naturalWidth: 400, naturalHeight: 300,
    camera: { x: 397, y: 800, zoom: 1 },
    viewport: { width: 794, height: 600 },
    page: A4,
  });
  const cy = r.y + r.height / 2;
  // Visible part of the sheet is y 500..1100 -> centre 800.
  assert.ok(near(cy, 800, 0.5), `centre y ${cy}, expected 800`);
});

test("never lands off the sheet, even when the view is mostly desk", () => {
  // Camera far to the right: only a sliver of the page is visible.
  const r = placeImage({
    naturalWidth: 1000, naturalHeight: 800,
    camera: { x: 1100, y: 500, zoom: 1 },
    viewport: { width: 800, height: 800 },
    page: A4,
  });
  assert.ok(r.x >= 0 && r.y >= 0, "top-left on the paper");
  assert.ok(r.x + r.width <= A4.width + 1e-6, "right edge on the paper");
  assert.ok(r.y + r.height <= A4.height + 1e-6, "bottom edge on the paper");
});

test("a photo larger than the view is fitted, keeping its proportions", () => {
  const r = placeImage({
    naturalWidth: 4000, naturalHeight: 3000,
    camera: { x: 397, y: 561, zoom: 1 },
    viewport: { width: 794, height: 1123 },
    page: A4,
  });
  assert.ok(r.width <= A4.width * IMAGE_FIT_FRACTION + 1e-6, `width ${r.width}`);
  assert.ok(near(r.width / r.height, 4000 / 3000, 1e-9), "aspect ratio preserved");
});

test("a small image is not blown up past its own pixels", () => {
  const r = placeImage({
    naturalWidth: 120, naturalHeight: 80,
    camera: { x: 397, y: 561, zoom: 1 },
    viewport: { width: 794, height: 1123 },
    page: A4,
  });
  assert.equal(r.width, 120);
  assert.equal(r.height, 80);
});

test("a tiny icon is enlarged to something you can actually grab", () => {
  const r = placeImage({
    naturalWidth: 16, naturalHeight: 16,
    camera: { x: 0, y: 0, zoom: 1 },
    viewport: { width: 800, height: 800 },
    page: null,
  });
  assert.ok(Math.min(r.width, r.height) >= IMAGE_MIN_SIDE - 1e-9);
});

test("a paste at the pointer centres on the pointer, then stays on the paper", () => {
  const r = placeImage({
    naturalWidth: 200, naturalHeight: 100,
    camera: { x: 397, y: 561, zoom: 1 },
    viewport: { width: 794, height: 1123 },
    page: A4,
    at: { x: 790, y: 20 }, // right at the top-right corner
  });
  assert.ok(near(r.x + r.width, A4.width), "pushed back inside the right edge");
  assert.ok(near(r.y, 0), "pushed back inside the top edge");
});

test("zoomed out, it still fits the visible page (region is in WORLD units)", () => {
  const r = placeImage({
    naturalWidth: 3000, naturalHeight: 3000,
    camera: { x: 397, y: 561, zoom: 0.5 },
    viewport: { width: 800, height: 800 },
    page: A4,
  });
  // At zoom 0.5 the view spans 1600 world units, so the whole page is visible
  // and the limit is the page itself.
  assert.ok(r.width <= A4.width * IMAGE_FIT_FRACTION + 1e-6);
});

console.log("\n── Resize and rotate ──");

test("dragging a corner keeps a photo's proportions", () => {
  const s = lockAspect(400, 300, 600, 310);
  assert.ok(near(s.width / s.height, 400 / 300, 1e-9));
  assert.ok(near(s.width, 600), "follows the axis moved most");
});

test("shrinking below the minimum stops at the minimum, still in proportion", () => {
  const s = lockAspect(400, 200, 2, 1);
  assert.ok(near(Math.min(s.width, s.height), 20));
  assert.ok(near(s.width / s.height, 2, 1e-9));
});

test("rotation snaps to straight when you are within a few degrees", () => {
  const deg = (d: number) => (d * Math.PI) / 180;
  assert.ok(near(snapRotation(deg(2.5)), 0));
  assert.ok(near(snapRotation(deg(88)), deg(90)));
  assert.ok(near(snapRotation(deg(-3)), 0));
});

test("rotation is left alone when you clearly meant an angle", () => {
  const deg = (d: number) => (d * Math.PI) / 180;
  assert.ok(near(snapRotation(deg(30)), deg(30)));
});

console.log(`\n  ${passed} passed, ${failed} failed\n`);
if (failed > 0) process.exit(1);
