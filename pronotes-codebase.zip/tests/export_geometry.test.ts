/**
 * Where exported ink actually LANDS.
 *
 * The bug this pins lost people's handwriting. A stroke stores its points
 * RELATIVE to the element's own origin - the on-screen renderer wraps every
 * element in `translate(x, y)` and draws the path inside it. The exporter
 * emitted the same path with NO translate, so every stroke on every page
 * collapsed into the top-left corner of the sheet and was clipped away.
 *
 * On screen the notebook looked perfect. The exported PDF came out with the
 * text and sticky notes in place and the handwriting simply gone. It survived
 * review because the test fixtures had been written with ABSOLUTE points,
 * which real strokes never have - so the fixtures below deliberately use the
 * real convention, taken from a device's stored notebook:
 *
 *     stroke.x = 252, stroke.y = 159, points ≈ [[-26, -7], [10, 28], ...]
 *
 * The general rule these tests defend: an element's exported geometry must sit
 * where `getElementBounds` says it sits. Anything else means the file does not
 * match the screen.
 */

import assert from "node:assert/strict";

import { buildExportSvg } from "../src/lib/whiteboard/export";
import { getElementBounds } from "../src/lib/whiteboard/geometry";
import type { Board, NotebookPage, StrokeElement, WhiteboardElement } from "../src/lib/whiteboard/types";

let passed = 0;
let failed = 0;
function test(name: string, fn: () => void) {
  try {
    fn();
    passed++;
    console.log(`  ✓ ${name}`);
  } catch (err) {
    failed++;
    console.error(`  ✗ ${name}`);
    console.error(`      ${(err as Error).message}`);
  }
}

const A4 = { w: 794, h: 1123 };

/** A stroke the way the app really stores one: points around a local origin. */
function realStroke(x: number, y: number, extra: Partial<StrokeElement> = {}): StrokeElement {
  return {
    id: `s_${x}_${y}`,
    type: "stroke",
    x,
    y,
    width: 40,
    height: 35,
    rotation: 0,
    opacity: 1,
    points: [
      [-26, -7, 0.5],
      [-10, 12, 0.6],
      [10, 28, 0.6],
      [14, 5, 0.5],
    ],
    color: "#111111",
    strokeWidth: 3,
    strokeStyle: "pen",
    createdAt: 1,
    updatedAt: 1,
    ...extra,
  } as StrokeElement;
}

function page(elements: WhiteboardElement[]): NotebookPage {
  return { id: "pg1", elements, createdAt: 1, updatedAt: 1 };
}

function notebook(elements: WhiteboardElement[]): Board {
  return {
    id: "b1",
    name: "N",
    folderId: null,
    elements: [],
    camera: { x: 0, y: 0, zoom: 1 },
    kind: "notebook",
    pages: [page(elements)],
    activePageId: "pg1",
    pageSize: "a4",
    createdAt: 1,
    updatedAt: 1,
  } as Board;
}

/** Every number inside the `d` of the stroke's path. */
function pathNumbers(svg: string): number[] {
  const m = /<g transform="translate\([^"]*\)"><path d="([^"]*)"/.exec(svg);
  if (!m) return [];
  return (m[1].match(/-?\d+(\.\d+)?/g) ?? []).map(Number);
}

console.log("\n── Exported strokes land where the screen puts them ──");

test("a stroke is placed by a translate, not drawn at the origin", () => {
  const svg = buildExportSvg(notebook([realStroke(252, 159)])).svg;
  assert.ok(
    svg.includes('transform="translate(252, 159)"'),
    "the stroke carries the same translate the renderer applies"
  );
});

test("the path itself stays in LOCAL coordinates", () => {
  // If someone "fixes" this by baking x/y into the points instead, the
  // translate would double the offset. The path must stay small and local.
  const nums = pathNumbers(buildExportSvg(notebook([realStroke(252, 159)])).svg);
  assert.ok(nums.length > 0, "the stroke produced a path");
  const maxAbs = Math.max(...nums.map(Math.abs));
  assert.ok(maxAbs < 120, `path coordinates should be local, saw max |${maxAbs}|`);
});

test("ink does NOT collapse into the top-left corner", () => {
  // The exact failure users saw: every stroke stacked in the corner, clipped.
  const svg = buildExportSvg(notebook([realStroke(252, 159), realStroke(600, 900)])).svg;
  const translates = [...svg.matchAll(/translate\((\d+(?:\.\d+)?), (\d+(?:\.\d+)?)\)/g)]
    .map((m) => ({ x: +m[1], y: +m[2] }))
    .filter((t) => !(t.x === 0)); // sheet groups translate(0, offset)
  assert.equal(translates.length, 2, "both strokes are placed");
  assert.ok(
    translates.some((t) => t.x === 600 && t.y === 900),
    "the far stroke keeps its own position"
  );
});

test("the placed stroke matches getElementBounds", () => {
  // The invariant that generalises past strokes: what the exporter draws has
  // to occupy the same box the rest of the app thinks the element occupies.
  const s = realStroke(252, 159);
  const bounds = getElementBounds(s);
  const svg = buildExportSvg(notebook([s])).svg;
  const m = /translate\((\d+(?:\.\d+)?), (\d+(?:\.\d+)?)\)"><path d="([^"]*)"/.exec(svg);
  assert.ok(m, "found the placed stroke");
  const tx = +m![1], ty = +m![2];
  const nums = (m![3].match(/-?\d+(\.\d+)?/g) ?? []).map(Number);
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  for (let i = 0; i + 1 < nums.length; i += 2) {
    const x = nums[i] + tx, y = nums[i + 1] + ty;
    if (x < minX) minX = x; if (x > maxX) maxX = x;
    if (y < minY) minY = y; if (y > maxY) maxY = y;
  }
  // Stroke outlines are fattened by width, so allow generous slack; the point
  // is that it sits at ~(252,159), not at ~(0,0).
  assert.ok(Math.abs(minX - bounds.x) < 60, `x ${minX} vs bounds ${bounds.x}`);
  assert.ok(Math.abs(minY - bounds.y) < 60, `y ${minY} vs bounds ${bounds.y}`);
});

test("strokes stay ON the sheet", () => {
  const svg = buildExportSvg(notebook([realStroke(252, 159), realStroke(400, 700)])).svg;
  for (const m of svg.matchAll(/translate\((\d+(?:\.\d+)?), (\d+(?:\.\d+)?)\)"><path/g)) {
    const x = +m[1], y = +m[2];
    assert.ok(x > 0 && x < A4.w, `stroke x ${x} is on the sheet`);
    assert.ok(y > 0 && y < A4.h, `stroke y ${y} is on the sheet`);
  }
});

console.log("\n── The stale path cache is never trusted ──");

test("a legacy cached `path` is ignored in favour of the points", () => {
  // `path` froze a stroke's geometry at draw time and is stripped on load.
  // The renderer always rebuilds from points; the exporter must agree, or a
  // file can disagree with the screen.
  const s = realStroke(252, 159, { path: "M 9999,9999 L 9998,9998 Z" } as Partial<StrokeElement>);
  const svg = buildExportSvg(notebook([s])).svg;
  assert.ok(!svg.includes("9999"), "the frozen path was not used");
  assert.ok(svg.includes('translate(252, 159)'), "the stroke is still placed correctly");
});

console.log("\n── Other element types keep their absolute coordinates ──");

test("text is written at its own x/y, not translated twice", () => {
  const text = {
    id: "t1", type: "text", x: 300, y: 500, width: 200, height: 40, rotation: 0, opacity: 1,
    text: "Hello", color: "#000", fontSize: 20, fontFamily: "Inter", fontWeight: 400,
    align: "left", createdAt: 1, updatedAt: 1,
  } as unknown as WhiteboardElement;
  const svg = buildExportSvg(notebook([text])).svg;
  const m = /<text x="([\d.]+)"/.exec(svg);
  assert.ok(m, "the text was exported");
  const x = +m![1];
  assert.ok(Math.abs(x - 300) < 20, `text x ${x} should be ~300, not re-offset`);
});

test("a line spans from its origin to its far end", () => {
  const line = {
    id: "l1", type: "line", x: 100, y: 200, x2: 150, y2: 60, width: 150, height: 60,
    rotation: 0, opacity: 1, strokeColor: "#000", strokeWidth: 2, dashStyle: "solid",
    createdAt: 1, updatedAt: 1,
  } as unknown as WhiteboardElement;
  const svg = buildExportSvg(notebook([line])).svg;
  assert.ok(/x1="100" y1="200" x2="250" y2="260"/.test(svg), "line endpoints are absolute");
});

console.log(`\n  ${passed} passed, ${failed} failed\n`);
if (failed > 0) process.exit(1);
