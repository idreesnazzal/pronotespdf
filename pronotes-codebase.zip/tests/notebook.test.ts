/**
 * Notebook page model.
 *
 * The theme of these tests is "no stroke may ever become unreachable". Every
 * app in this category has been criticised for losing user work on an upgrade,
 * so the page model is tested for the ways a stroke could end up written to a
 * field nothing renders.
 */

import assert from "node:assert/strict";

import {
  addPage,
  allElements,
  backgroundForPage,
  createPage,
  deletePage,
  duplicatePage,
  getActivePage,
  getActivePageIndex,
  getBoardElements,
  getPages,
  insertPageAt,
  isNotebook,
  makeNotebook,
  mapBoardElements,
  movePage,
  pageSizeOf,
  setActivePage,
  setPageBackground,
  stepPage,
  PAGE_GAP,
  pageOffsetY,
  notebookContentHeight,
  pageIndexAtY,
  paperForPage,
  toPageLocalY,
  isOnSheet,
  visiblePageRange,
  clampToSheet,
  clampBoxToSheet,
  isOnActiveSheet,
  SHEET_INK_INSET,
  sheetIndexAt,
} from "../src/lib/whiteboard/notebook";
import type { Board, WhiteboardElement } from "../src/lib/whiteboard/types";
import { migrateState } from "../src/lib/whiteboard/persistence";
import { saveState } from "../src/lib/whiteboard/persistence";
import { exportBoardToSvg, buildExportSvg } from "../src/lib/whiteboard/export";
import { getUnionBounds } from "../src/lib/whiteboard/geometry";

let passed = 0;
let failed = 0;
function test(name: string, fn: () => void) {
  try {
    fn();
    passed++;
    console.log(`  ✓ ${name}`);
  } catch (err) {
    failed++;
    console.error(`  ✗ ${name}\n      ${(err as Error).message}`);
  }
}

function el(id: string): WhiteboardElement {
  return {
    id,
    type: "rectangle",
    x: 0,
    y: 0,
    width: 10,
    height: 10,
    angle: 0,
    strokeColor: "#000",
    backgroundColor: "transparent",
    fillStyle: "transparent",
    strokeWidth: 2,
    strokeStyle: "solid",
    dashStyle: "solid",
    opacity: 1,
    seed: 1,
  } as unknown as WhiteboardElement;
}

function canvas(elements: WhiteboardElement[] = []): Board {
  const now = Date.now();
  return {
    id: "b1",
    name: "Board",
    folderId: null,
    elements,
    camera: { x: 0, y: 0, zoom: 1 },
    createdAt: now,
    updatedAt: now,
  } as Board;
}

console.log("\n── Notebook page model ──");

// --- kind ------------------------------------------------------------------

test("a board with no kind is still a canvas (no migration needed)", () => {
  const b = canvas([el("a")]);
  assert.equal(isNotebook(b), false);
  assert.deepEqual(getBoardElements(b).map((e) => e.id), ["a"]);
});

test("makeNotebook keeps whatever was already drawn as page 1", () => {
  const nb = makeNotebook(canvas([el("a"), el("b")]));
  assert.equal(isNotebook(nb), true);
  assert.equal(getPages(nb).length, 1);
  assert.deepEqual(getBoardElements(nb).map((e) => e.id), ["a", "b"]);
  // and must not leave a second copy stranded on the canvas field
  assert.deepEqual(nb.elements, []);
});

test("page size defaults to A4 and is looked up by id", () => {
  assert.equal(pageSizeOf(canvas()).label, "A4");
  const nb = makeNotebook(canvas(), "letter-landscape");
  assert.equal(pageSizeOf(nb).width, 1056);
  assert.equal(pageSizeOf(nb).height, 816);
});

// --- the element funnel ----------------------------------------------------

test("mapBoardElements writes to the active page, not the canvas field", () => {
  const nb = addPage(makeNotebook(canvas()));
  const after = mapBoardElements(nb, (els) => [...els, el("x")]);

  assert.deepEqual(getBoardElements(after).map((e) => e.id), ["x"]);
  assert.deepEqual(after.elements, [], "canvas field must stay empty for a notebook");
  assert.deepEqual(getPages(after)[0].elements, [], "page 1 must be untouched");
  assert.deepEqual(getPages(after)[1].elements.map((e) => e.id), ["x"]);
});

test("mapBoardElements writes to board.elements for a canvas", () => {
  const after = mapBoardElements(canvas(), (els) => [...els, el("x")]);
  assert.deepEqual(after.elements.map((e) => e.id), ["x"]);
  assert.equal(after.pages, undefined);
});

test("a notebook with no pages gets one rather than dropping the write", () => {
  const broken = { ...makeNotebook(canvas()), pages: [] } as Board;
  const after = mapBoardElements(broken, (els) => [...els, el("rescued")]);
  assert.equal(getPages(after).length, 1);
  assert.deepEqual(getBoardElements(after).map((e) => e.id), ["rescued"]);
});

test("a stale activePageId falls back to page 1 instead of losing the write", () => {
  const nb = { ...makeNotebook(canvas()), activePageId: "does-not-exist" } as Board;
  assert.equal(getActivePage(nb)?.id, getPages(nb)[0].id);
  assert.equal(getActivePageIndex(nb), 0);

  const after = mapBoardElements(nb, (els) => [...els, el("safe")]);
  assert.deepEqual(getPages(after)[0].elements.map((e) => e.id), ["safe"]);
});

test("a malformed pages field does not throw", () => {
  const broken = { ...makeNotebook(canvas()), pages: undefined } as Board;
  assert.deepEqual(getPages(broken), []);
  assert.deepEqual(getBoardElements(broken), []);
  assert.equal(getActivePage(broken), null);
});

// --- page operations -------------------------------------------------------

test("addPage inserts after the anchor and selects the new page", () => {
  let nb = makeNotebook(canvas());
  const first = getPages(nb)[0].id;
  nb = addPage(nb);
  const second = nb.activePageId!;
  nb = addPage(nb, first); // insert between

  const ids = getPages(nb).map((p) => p.id);
  assert.equal(ids.length, 3);
  assert.equal(ids[0], first);
  assert.equal(ids[2], second);
  assert.equal(nb.activePageId, ids[1], "the inserted page becomes active");
});

test("insertPageAt the end appends the last page and selects it", () => {
  // The page bar's + Page always grows the notebook at the end.
  let nb = addPage(makeNotebook(canvas()));
  const at = getPages(nb).length;
  nb = insertPageAt(nb, at);
  const ids = getPages(nb).map((p) => p.id);
  assert.equal(ids.length, at + 1);
  assert.equal(nb.activePageId, ids[ids.length - 1], "the new last page is active");
});

test("a new page starts with the notebook default paper, not the neighbour's", () => {
  let nb: Board = {
    ...makeNotebook(canvas()),
    background: { pattern: "grid" as const, size: 40 },
  };
  nb = setPageBackground(nb, getPages(nb)[0].id, { pattern: "lines" });
  nb = addPage(nb);
  assert.equal(getPages(nb)[1].background?.pattern, "grid");
  assert.equal(getPages(nb)[1].background?.size, 40);
});

test("pages can mix paper templates in one notebook", () => {
  let nb = addPage(makeNotebook(canvas()));
  const [p1, p2] = getPages(nb);
  nb = setPageBackground(nb, p1.id, { pattern: "grid" });
  nb = setPageBackground(nb, p2.id, { pattern: "plain" });
  assert.equal(getPages(nb)[0].background?.pattern, "grid");
  assert.equal(getPages(nb)[1].background?.pattern, "plain");
});

test("duplicatePage gives the copy fresh element ids", () => {
  let nb = makeNotebook(canvas([el("shared")]));
  nb = duplicatePage(nb, getPages(nb)[0].id);

  const [a, b] = getPages(nb);
  assert.equal(a.elements.length, 1);
  assert.equal(b.elements.length, 1);
  assert.notEqual(a.elements[0].id, b.elements[0].id, "duplicated ids would alias on delete");
  assert.equal(nb.activePageId, b.id);
});

test("deletePage selects the page that took its place", () => {
  let nb = addPage(addPage(makeNotebook(canvas())));
  const ids = getPages(nb).map((p) => p.id);
  nb = deletePage(nb, ids[1]);
  assert.deepEqual(getPages(nb).map((p) => p.id), [ids[0], ids[2]]);
  assert.equal(nb.activePageId, ids[2]);
});

test("deleting the last page leaves a blank one, never zero", () => {
  let nb = makeNotebook(canvas([el("a")]));
  nb = deletePage(nb, getPages(nb)[0].id);
  assert.equal(getPages(nb).length, 1);
  assert.deepEqual(getPages(nb)[0].elements, []);
  assert.equal(nb.activePageId, getPages(nb)[0].id);
});

test("deleting the last page in a list selects the new last page", () => {
  let nb = addPage(makeNotebook(canvas()));
  const ids = getPages(nb).map((p) => p.id);
  nb = deletePage(nb, ids[1]);
  assert.equal(nb.activePageId, ids[0]);
});

test("movePage reorders and clamps out-of-range targets", () => {
  let nb = addPage(addPage(makeNotebook(canvas())));
  const ids = getPages(nb).map((p) => p.id);

  nb = movePage(nb, ids[0], 2);
  assert.deepEqual(getPages(nb).map((p) => p.id), [ids[1], ids[2], ids[0]]);

  nb = movePage(nb, ids[0], 99);
  assert.deepEqual(getPages(nb).map((p) => p.id), [ids[1], ids[2], ids[0]], "clamped, no throw");

  nb = movePage(nb, ids[0], -5);
  assert.deepEqual(getPages(nb).map((p) => p.id), [ids[0], ids[1], ids[2]]);
});

test("movePage on an unknown id is a no-op", () => {
  const nb = addPage(makeNotebook(canvas()));
  assert.deepEqual(movePage(nb, "nope", 0), nb);
});

test("stepPage stops at both ends", () => {
  let nb = addPage(addPage(makeNotebook(canvas())));
  nb = setActivePage(nb, getPages(nb)[0].id);

  assert.equal(getActivePageIndex(stepPage(nb, -1)), 0, "cannot step before page 1");
  assert.equal(getActivePageIndex(stepPage(nb, 1)), 1);
  assert.equal(getActivePageIndex(stepPage(nb, 99)), 2, "cannot step past the last page");
});

test("setActivePage refuses an id that is not in the notebook", () => {
  const nb = makeNotebook(canvas());
  assert.deepEqual(setActivePage(nb, "ghost"), nb);
});

// --- whole-document reads --------------------------------------------------

test("allElements spans every page, for search, export and the graph", () => {
  let nb = makeNotebook(canvas([el("p1a")]));
  nb = addPage(nb);
  nb = mapBoardElements(nb, () => [el("p2a"), el("p2b")]);

  assert.deepEqual(allElements(nb).map((e) => e.id), ["p1a", "p2a", "p2b"]);
  assert.deepEqual(getBoardElements(nb).map((e) => e.id), ["p2a", "p2b"], "but the live list is one page");
});

test("allElements on a canvas is just its elements", () => {
  assert.deepEqual(allElements(canvas([el("a")])).map((e) => e.id), ["a"]);
});

test("backgroundForPage falls back to the notebook's paper", () => {
  const nb = { ...makeNotebook(canvas()), background: { pattern: "grid" as const } };
  assert.equal(backgroundForPage(nb, getPages(nb)[0])?.pattern, "grid");

  const withOwn = setPageBackground(nb, getPages(nb)[0].id, { pattern: "lines" });
  assert.equal(backgroundForPage(withOwn, getPages(withOwn)[0])?.pattern, "lines");
});

// --- per-page paper --------------------------------------------------------
//
// Every visible sheet must wear its OWN paper. The canvas painted all sheets
// with the ACTIVE page's paper, so a grid page showed grid while it sat below
// the page above and turned blank the moment you navigated to it.

test("paperForPage resolves each page's own paper, not the active page's", () => {
  let nb: Board = {
    ...makeNotebook(canvas()),
    background: { pattern: "plain" as const },
  };
  nb = addPage(nb);
  const [p1, p2] = getPages(nb);
  nb = setPageBackground(nb, p1.id, { pattern: "grid" });
  nb = setPageBackground(nb, p2.id, { pattern: "lines" });
  const pages = getPages(nb);
  assert.equal(paperForPage(nb, pages[0]).pattern, "grid");
  assert.equal(paperForPage(nb, pages[1]).pattern, "lines");
});

test("paperForPage falls back to dots at default spacing with no paper anywhere", () => {
  const nb = makeNotebook(canvas());
  const sheet = paperForPage(nb, getPages(nb)[0]);
  assert.equal(sheet.pattern, "dots");
  assert.equal(sheet.size, 24);
  assert.equal(sheet.color, undefined);
});

test("paperForPage clamps spacing and keeps the raw colour", () => {
  let nb: Board = {
    ...makeNotebook(canvas()),
    background: { pattern: "grid" as const, size: 500, color: "sky" },
  };
  const sheet = paperForPage(nb, getPages(nb)[0]);
  assert.equal(sheet.size, 120, "spacing clamps to the sane maximum");
  assert.equal(sheet.color, "sky");
  nb = setPageBackground(nb, getPages(nb)[0].id, { size: 1 });
  assert.equal(paperForPage(nb, getPages(nb)[0]).size, 6, "and to the minimum");
});

test("an added page in a plain-default notebook can take its own ruling", () => {
  // A PDF notebook defaults to plain; a blank page added to it must still be
  // settable per page — pattern and spacing both.
  let nb: Board = {
    ...makeNotebook(canvas()),
    background: { pattern: "plain" as const },
  };
  nb = addPage(nb);
  const added = getPages(nb)[1];
  assert.equal(paperForPage(nb, added).pattern, "plain");
  nb = setPageBackground(nb, added.id, { pattern: "grid", size: 40 });
  const sheet = paperForPage(nb, getPages(nb)[1]);
  assert.equal(sheet.pattern, "grid");
  assert.equal(sheet.size, 40);
});

test("createPage produces unique ids", () => {
  const ids = new Set(Array.from({ length: 500 }, () => createPage().id));
  assert.equal(ids.size, 500);
});

// --- loading a saved notebook ------------------------------------------------

/** migrateState is what every load path runs, including imported backups. */
function load(board: Record<string, unknown>): Board {
  const out = migrateState({ boards: [board] } as never);
  return (out.boards as Board[])[0];
}

test("a saved canvas still loads as a canvas", () => {
  const b = load({ id: "b", name: "N", elements: [el("a")] });
  assert.equal(b.kind, undefined);
  assert.deepEqual(getBoardElements(b).map((e) => e.id), ["a"]);
});

test("a saved notebook keeps its pages and their elements", () => {
  const b = load({
    id: "b",
    name: "N",
    kind: "notebook",
    pageSize: "letter",
    activePageId: "p2",
    pages: [
      { id: "p1", elements: [el("x")] },
      { id: "p2", elements: [el("y")] },
    ],
  });
  assert.equal(b.kind, "notebook");
  assert.equal(getPages(b).length, 2);
  assert.equal(b.pageSize, "letter");
  assert.deepEqual(getBoardElements(b).map((e) => e.id), ["y"], "activePageId honoured");
  assert.deepEqual(allElements(b).map((e) => e.id), ["x", "y"]);
});

test("a notebook saved with no pages is recovered with one, not left blank", () => {
  const b = load({ id: "b", name: "N", kind: "notebook", pages: [] });
  assert.equal(getPages(b).length, 1);
  assert.ok(b.activePageId, "and it is selected");
  assert.equal(getActivePage(b)?.id, getPages(b)[0].id);
});

test("a stale saved activePageId is repointed at a real page on load", () => {
  const b = load({
    id: "b",
    name: "N",
    kind: "notebook",
    activePageId: "gone",
    pages: [{ id: "p1", elements: [el("x")] }],
  });
  assert.equal(b.activePageId, "p1");
  assert.deepEqual(getBoardElements(b).map((e) => e.id), ["x"]);
});

test("an unknown page size falls back to A4 rather than rendering nothing", () => {
  const b = load({ id: "b", name: "N", kind: "notebook", pageSize: "poster", pages: [{ id: "p1" }] });
  assert.equal(b.pageSize, "a4");
});

test("page elements get the same sanitising as canvas elements", () => {
  const b = load({
    id: "b",
    name: "N",
    kind: "notebook",
    pages: [
      {
        id: "p1",
        elements: [
          { id: "s1", type: "stroke", points: [[0, 0]], path: "M0 0" },
          { type: "rectangle" },
          null,
        ],
      },
    ],
  });
  const els = getPages(b)[0].elements as unknown as Array<Record<string, unknown>>;
  assert.equal(els.length, 1, "malformed elements dropped");
  assert.equal("path" in els[0], false, "legacy cached stroke path stripped on pages too");
});

test("a page with a malformed elements field loads as an empty page", () => {
  const b = load({ id: "b", name: "N", kind: "notebook", pages: [{ id: "p1", elements: "oops" }] });
  assert.deepEqual(getPages(b)[0].elements, []);
});

test("a bad page paper pattern is dropped, and page size is clamped", () => {
  const b = load({
    id: "b",
    name: "N",
    kind: "notebook",
    pages: [
      { id: "p1", background: { pattern: "hexagons" } },
      { id: "p2", background: { pattern: "grid", size: 0 } },
      { id: "p3", background: { pattern: "grid", size: 9999 } },
    ],
  });
  assert.equal(getPages(b)[0].background, undefined, "unknown pattern dropped");
  assert.equal(getPages(b)[1].background?.size, 6, "size 0 would tile infinitely; clamped to min");
  assert.equal(getPages(b)[2].background?.size, 120, "clamped to max");
});

// --- continuous scroll layout ------------------------------------------------

const H = 1123; // A4 height
const W = 794;

test("pages stack down the canvas with a gap between sheets", () => {
  assert.equal(pageOffsetY(0, H), 0);
  assert.equal(pageOffsetY(1, H), H + PAGE_GAP);
  assert.equal(pageOffsetY(4, H), 4 * (H + PAGE_GAP));
});

test("total height counts gaps between pages but not after the last", () => {
  assert.equal(notebookContentHeight(1, H), H);
  assert.equal(notebookContentHeight(3, H), 3 * H + 2 * PAGE_GAP);
  assert.equal(notebookContentHeight(0, H), 0);
});

test("a world Y maps to the page it lands on", () => {
  assert.equal(pageIndexAtY(0, H, 5), 0);
  assert.equal(pageIndexAtY(H - 1, H, 5), 0);
  assert.equal(pageIndexAtY(pageOffsetY(2, H) + 10, H, 5), 2);
  assert.equal(pageIndexAtY(pageOffsetY(4, H) + H - 1, H, 5), 4);
});

test("a point in the gap belongs to the page above, not the one below", () => {
  // Writing just past the bottom edge should not jump to the next page.
  const inGap = H + PAGE_GAP / 2;
  assert.equal(pageIndexAtY(inGap, H, 5), 0);
});

test("points beyond the stack clamp to the first and last page", () => {
  assert.equal(pageIndexAtY(-5000, H, 5), 0);
  assert.equal(pageIndexAtY(999999, H, 5), 4);
  assert.equal(pageIndexAtY(0, H, 0), -1, "no pages, no answer");
});

test("world Y converts to page-local Y", () => {
  assert.equal(toPageLocalY(pageOffsetY(3, H) + 50, 3, H), 50);
  assert.equal(toPageLocalY(0, 0, H), 0);
});

test("isOnSheet distinguishes the paper from the gap and the margins", () => {
  assert.equal(isOnSheet(100, 100, 0, W, H), true);
  assert.equal(isOnSheet(-5, 100, 0, W, H), false, "left of the sheet");
  assert.equal(isOnSheet(W + 5, 100, 0, W, H), false, "right of the sheet");
  assert.equal(isOnSheet(100, H + 10, 0, W, H), false, "in the gap below page 1");
  assert.equal(isOnSheet(100, pageOffsetY(1, H) + 10, 1, W, H), true, "on page 2");
});

test("only the pages near the viewport are rendered", () => {
  // Looking at page 10 in a 200-page notebook.
  const top = pageOffsetY(10, H);
  const r = visiblePageRange(top, top + 900, H, 200);
  assert.ok(r.start <= 10 && r.end >= 10, "the page you are looking at is included");
  assert.ok(r.end - r.start < 5, `rendered ${r.end - r.start + 1} pages, not 200`);
});

test("the visible range clamps at both ends of the notebook", () => {
  const first = visiblePageRange(-500, 400, H, 3);
  assert.equal(first.start, 0);

  const last = visiblePageRange(pageOffsetY(2, H), pageOffsetY(2, H) + 99999, H, 3);
  assert.equal(last.end, 2, "never past the final page");

  assert.deepEqual(visiblePageRange(0, 100, H, 0), { start: 0, end: -1 }, "empty notebook");
});

// --- running out of storage --------------------------------------------------
//
// When localStorage is full the save falls back to dropping image payloads.
// That path only ever stripped the canvas field, so a NOTEBOOK's images — which
// live on its pages — were left in, the retry was still over quota, and nothing
// was written at all. Losing pixels is bad; silently saving nothing is worse.

function imageEl(id: string, bytes: number): WhiteboardElement {
  return { ...el(id), type: "image", src: "data:image/png;base64," + "A".repeat(bytes) } as unknown as WhiteboardElement;
}

test("a full disk still saves a notebook, minus the image pixels", () => {
  const store: Record<string, string> = {};
  const quota = 4096;
  const g = globalThis as unknown as { window?: unknown; localStorage?: unknown };
  const fake = {
    getItem: (k: string) => store[k] ?? null,
    setItem: (k: string, v: string) => {
      if (v.length > quota) throw new Error("QuotaExceededError");
      store[k] = v;
    },
    removeItem: (k: string) => { delete store[k]; },
  };
  const prevWindow = g.window;
  g.window = { localStorage: fake, dispatchEvent: () => true, CustomEvent: function () {} };

  const nb = makeNotebook(canvas());
  const withImages = {
    ...nb,
    pages: getPages(nb).map((p) => ({ ...p, elements: [imageEl("big", 8000)] })),
  } as Board;

  try {
    saveState({ boards: [withImages], folders: [] } as never);
    const written = store["z-whiteboard-state-v1"];
    assert.ok(written, "something must be saved — the old code wrote nothing at all");

    const back = JSON.parse(written);
    const pageEls = back.boards[0].pages[0].elements;
    assert.equal(pageEls.length, 1, "the element survives, only its pixels are dropped");
    assert.equal(pageEls[0].src, "", "the image payload was stripped from the PAGE, not just the canvas");
  } finally {
    g.window = prevWindow;
  }
});

// --- exporting a notebook ----------------------------------------------------

test("exporting a notebook exports the page, not an empty sheet", () => {
  // Export read `board.elements` — the CANVAS field — so every notebook
  // exported blank, because a notebook's content lives on its pages.
  let nb = makeNotebook(canvas());
  nb = mapBoardElements(nb, () => [
    { ...el("r1"), x: 10, y: 10, width: 50, height: 40 } as WhiteboardElement,
  ]);

  const svg = exportBoardToSvg(nb);
  assert.match(svg, /<rect/, "the page's element must appear in the export");
});

test("exporting a canvas is unchanged", () => {
  const b = canvas([{ ...el("r1"), width: 30, height: 30 } as WhiteboardElement]);
  assert.match(exportBoardToSvg(b), /<rect/);
});

test("exporting the second page exports THAT page", () => {
  let nb = makeNotebook(canvas());
  nb = mapBoardElements(nb, () => [{ ...el("onPage1"), width: 20, height: 20 } as WhiteboardElement]);
  nb = addPage(nb);
  nb = mapBoardElements(nb, () => [
    { ...el("onPage2"), type: "ellipse", width: 60, height: 60 } as unknown as WhiteboardElement,
  ]);

  const svg = exportBoardToSvg(nb);
  assert.match(svg, /<ellipse/, "page 2 is the active page, so it is what exports");
});

test("a notebook exports EVERY page by default", () => {
  // The dialog counted every page's elements while export wrote only the
  // active page, so a 20-page notebook advertised all of it and saved one.
  let nb = makeNotebook(canvas());
  nb = mapBoardElements(nb, () => [{ ...el("p1"), width: 20, height: 20 } as WhiteboardElement]);
  nb = addPage(nb);
  nb = mapBoardElements(nb, () => [
    { ...el("p2"), type: "ellipse", width: 60, height: 60 } as unknown as WhiteboardElement,
  ]);

  const { svg, report, height } = buildExportSvg(nb);
  assert.equal(report.pages, 2);
  assert.match(svg, /<ellipse/, "page 2's content is exported");
  // Page 1's rect sits inside the first sheet's clip group.
  assert.ok(svg.includes('clip-path="url(#pn-sheet-0)"') && svg.includes('clip-path="url(#pn-sheet-1)"'));
  const { height: h } = pageSizeOf(nb);
  assert.equal(height, 2 * h + PAGE_GAP, "sheets are stacked with the scroll view's gap");
});

test('pages: "current" exports only the page on screen', () => {
  let nb = makeNotebook(canvas());
  nb = mapBoardElements(nb, () => [{ ...el("p1"), width: 20, height: 20 } as WhiteboardElement]);
  nb = addPage(nb);
  const { report, height, svg } = buildExportSvg(nb, { pages: "current" });
  assert.equal(report.pages, 1);
  assert.equal(height, pageSizeOf(nb).height, "exactly one sheet");
  assert.equal(svg.includes("pn-sheet-1"), false);
});

test("a notebook page exports as the SHEET, clipped - not the ink's bounding box", () => {
  // Ink from before sheets were enforced can sit far off the page. On screen it
  // is invisible past the paper edge; exporting its bounds produced a smear.
  let nb = makeNotebook(canvas());
  nb = mapBoardElements(nb, () => [
    { ...el("offsheet"), x: -900, y: -900, width: 30, height: 30 } as WhiteboardElement,
  ]);
  const { svg, width, height } = buildExportSvg(nb, { pages: "current" });
  const size = pageSizeOf(nb);
  assert.equal(width, size.width);
  assert.equal(height, size.height);
  assert.match(svg, new RegExp(`viewBox="0 0 ${size.width} ${size.height}"`));
  assert.match(svg, /<clipPath id="pn-sheet-0">/);
});

test("the notebook's ruling is exported with the page", () => {
  let nb = makeNotebook(canvas());
  nb = setPageBackground(nb, getActivePage(nb)!.id, { pattern: "lines" });
  const { svg } = buildExportSvg(nb);
  assert.match(svg, /<pattern id="pn-paper-0"/, "lined paper is part of the page");
});

test("a picture whose pixels are missing is COUNTED, not silently greyed", () => {
  const b = canvas([
    { ...el("i1"), type: "image", src: "asset:img_gone", width: 40, height: 40 } as unknown as WhiteboardElement,
  ]);
  const { report, svg } = buildExportSvg(b);
  assert.equal(report.missingImages, 1);
  assert.match(svg, /fill="#e4e4e7"/, "still drawn as a placeholder so the layout holds");
});

test("a PDF-backed page with no PDF loaded is reported, and exports as paper", () => {
  let nb = makeNotebook(canvas());
  const page = getActivePage(nb)!;
  nb = { ...nb, pages: [{ ...page, pdf: { docId: "gone", pageNumber: 1 } }] };
  const { report } = buildExportSvg(nb);
  assert.equal(report.missingPdfPages, 1);
});

test("an unrecognised element with no position does not drag bounds to the origin", () => {
  // The fallback used `?? 0`, so one corrupt element pinned export and
  // zoom-to-fit to 0,0 however far away the real content was.
  const real = { ...el("r"), x: 5000, y: 5000, width: 100, height: 100 } as WhiteboardElement;
  const junk = { id: "junk", type: "hologram" } as unknown as WhiteboardElement;
  const b = getUnionBounds([real, junk])!;
  assert.equal(b.x, 5000);
  assert.equal(b.y, 5000);
});

test("an unrecognised element WITH a position still counts toward bounds", () => {
  const real = { ...el("r"), x: 100, y: 100, width: 10, height: 10 } as WhiteboardElement;
  const future = { id: "f", type: "hologram", x: 400, y: 400 } as unknown as WhiteboardElement;
  const b = getUnionBounds([real, future])!;
  assert.equal(b.x + b.width, 410, "the placed unknown element is still inside the frame");
});

test("an unresolved image reference is omitted, never written as a broken href", () => {
  const b = canvas([
    { ...el("i1"), type: "image", src: "asset:img_missing", width: 40, height: 40 } as unknown as WhiteboardElement,
  ]);
  const svg = exportBoardToSvg(b);
  assert.equal(/asset:/.test(svg), false, "an asset: href means nothing outside the app");
});

test("a resolved image reference is written as its real data URL", () => {
  const b = canvas([
    { ...el("i1"), type: "image", src: "asset:img_1", width: 40, height: 40 } as unknown as WhiteboardElement,
  ]);
  const svg = exportBoardToSvg(b, {}, [], new Map([["asset:img_1", "data:image/png;base64,AAAA"]]));
  assert.match(svg, /data:image\/png;base64,AAAA/);
});

// ---------------------------------------------------------------------------
// Ink stays on the paper
// ---------------------------------------------------------------------------
// A notebook used to share the whiteboard's unbounded world, so you could write
// beside a sheet or in the dead gap between two of them. That ink was saved but
// never exported, never printed, and impossible to find again once you
// scrolled. These pin the rule that it cannot happen.

const SHEET_W = 794;
const SHEET_H = 1123;

test("a point on the page is left exactly where it is", () => {
  const p = clampToSheet(400, 500, SHEET_W, SHEET_H);
  assert.deepEqual(p, { x: 400, y: 500 }, "clamping must not nudge valid ink");
});

test("a point to the RIGHT of the page is pulled back onto it", () => {
  const p = clampToSheet(SHEET_W + 600, 500, SHEET_W, SHEET_H);
  assert.equal(p.x, SHEET_W - SHEET_INK_INSET, "lands on the margin, not off in space");
  assert.equal(p.y, 500, "the other axis is untouched");
});

test("a point in the gap BETWEEN two sheets is pulled onto the sheet", () => {
  const p = clampToSheet(300, SHEET_H + PAGE_GAP / 2, SHEET_W, SHEET_H);
  assert.equal(p.y, SHEET_H - SHEET_INK_INSET, "no ink may live in the gap");
});

test("a point far above and left of the page is pulled back", () => {
  const p = clampToSheet(-5000, -5000, SHEET_W, SHEET_H);
  assert.deepEqual(p, { x: SHEET_INK_INSET, y: SHEET_INK_INSET });
});

test("the inset keeps a stroke's width off the page border", () => {
  assert.ok(SHEET_INK_INSET > 0, "a point on the edge paints half its width off the page");
  const p = clampToSheet(SHEET_W, SHEET_H, SHEET_W, SHEET_H);
  assert.ok(p.x < SHEET_W && p.y < SHEET_H);
});

test("isOnActiveSheet answers for the page at the origin", () => {
  assert.equal(isOnActiveSheet(10, 10, SHEET_W, SHEET_H), true);
  assert.equal(isOnActiveSheet(SHEET_W + 10, 10, SHEET_W, SHEET_H), false, "beside the page");
  assert.equal(isOnActiveSheet(10, SHEET_H + 10, SHEET_W, SHEET_H), false, "in the gap below");
  assert.equal(
    isOnActiveSheet(SHEET_W + 10, 10, SHEET_W, SHEET_H, 24),
    true,
    "the grab margin forgives a press just outside the border"
  );
});

test("a dragged element is MOVED back onto the sheet, never resized", () => {
  const box = clampBoxToSheet(SHEET_W - 10, 50, 200, 100, SHEET_W, SHEET_H);
  assert.equal(box.x, SHEET_W - 200, "its right edge sits on the page edge");
  assert.equal(box.y, 50, "vertical position is untouched");
});

test("an element too big for the page is pinned, not squashed", () => {
  const box = clampBoxToSheet(-300, -300, SHEET_W + 500, SHEET_H + 500, SHEET_W, SHEET_H);
  assert.deepEqual(box, { x: 0, y: 0 }, "stays whole and reachable at the top-left");
});

test("clamping is idempotent", () => {
  const once = clampToSheet(99999, -99999, SHEET_W, SHEET_H);
  const twice = clampToSheet(once.x, once.y, SHEET_W, SHEET_H);
  assert.deepEqual(twice, once, "re-clamping a clamped point must not drift");
});

// ---------------------------------------------------------------------------
// Which sheet is under the pen (several are visible when zoomed out)
// ---------------------------------------------------------------------------

{
  const W = 794, H = 1123, STRIDE = H + PAGE_GAP;
  // Page 3 of 5 is live (index 2) and sits at y = 0.
  test("a point on the live sheet is the live sheet", () => {
    assert.equal(sheetIndexAt(400, 500, 2, 5, W, H), 2);
  });
  test("a point on the sheet ABOVE the live one finds that sheet", () => {
    assert.equal(sheetIndexAt(400, -STRIDE + 300, 2, 5, W, H), 1);
  });
  test("a point on the sheet BELOW the live one finds that sheet", () => {
    assert.equal(sheetIndexAt(400, STRIDE + 10, 2, 5, W, H), 3);
  });
  test("the gap between two sheets is no sheet", () => {
    assert.equal(sheetIndexAt(400, H + PAGE_GAP / 2, 2, 5, W, H), null);
  });
  test("above the first page and below the last are no sheet", () => {
    assert.equal(sheetIndexAt(400, -3 * STRIDE + 10, 2, 5, W, H), null, "there is no page -1");
    assert.equal(sheetIndexAt(400, 3 * STRIDE + 10, 2, 5, W, H), null, "there is no page 6");
  });
  test("beside the paper is no sheet, unless within the grab margin", () => {
    assert.equal(sheetIndexAt(W + 30, 500, 2, 5, W, H), null);
    assert.equal(sheetIndexAt(W + 20, 500, 2, 5, W, H, 24), 2);
  });
}

console.log(`\n  ${passed} passed, ${failed} failed\n`);
if (failed > 0) process.exit(1);
