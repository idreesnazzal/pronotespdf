/**
 * Regressions from the review of the text-tool / toolbar work:
 * - Dictation: back-to-back phrases are all kept; only a true echo is dropped
 * - Export: the text a PDF shows matches the canvas, not the raw markup
 * - Inline markup: prices, arithmetic and issue numbers stay plain text
 * - Sticky colour: reading a colour and writing it back keeps it
 */

import assert from "node:assert/strict";
import { VoiceDictationController, isRepeatedFinal } from "../src/lib/whiteboard/speechRecognition";
import { markdownToPlainLines, tokenizeInline } from "../src/lib/whiteboard/textParser";
import { DEFAULT_STYLE, STICKY_COLORS, getToolColor, setToolInk, stickyColorKey } from "../src/lib/whiteboard/types";

const NL = String.fromCharCode(10);

let passed = 0;
let failed = 0;
async function test(name: string, fn: () => void | Promise<void>) {
  try {
    await fn();
    passed++;
    console.log(`  ✓ ${name}`);
  } catch (err) {
    failed++;
    console.error(`  ✗ ${name}`);
    console.error(`      ${(err as Error).message}`);
  }
}

// ---------------------------------------------------------------------------
// A stand-in speech engine: the test plays the results Android delivers.
// ---------------------------------------------------------------------------

type Handler = ((ev: unknown) => void) | null;
class FakeRecognition {
  static last: FakeRecognition | null = null;
  continuous = false;
  interimResults = false;
  lang = "";
  maxAlternatives = 1;
  onstart: Handler = null;
  onresult: Handler = null;
  onerror: Handler = null;
  onend: Handler = null;
  onaudiostart: Handler = null;
  onaudioend: Handler = null;
  onsoundstart: Handler = null;
  onsoundend: Handler = null;
  onspeechstart: Handler = null;
  onspeechend: Handler = null;
  onnomatch: Handler = null;
  constructor() {
    FakeRecognition.last = this;
  }
  start() {
    this.onstart?.({});
  }
  stop() {}
  abort() {}
  addEventListener() {}
  removeEventListener() {}
  dispatchEvent() {
    return true;
  }
  /** One onresult carrying final phrases only - how Android sends most. */
  finalOnly(text: string, confidence = 0) {
    const alt = { transcript: text, confidence };
    const result = Object.assign([alt], { isFinal: true, item: () => alt });
    const results = Object.assign([result], { item: () => result });
    this.onresult?.({ resultIndex: 0, results });
  }
}

async function startedController(finals: string[]) {
  (globalThis as unknown as { window: unknown }).window = { webkitSpeechRecognition: FakeRecognition };
  const c = new VoiceDictationController({ onFinal: (t) => finals.push(t) });
  const ok = await c.start();
  assert.equal(ok, true, "controller should start on the fake engine");
  return FakeRecognition.last!;
}

async function main() {
  console.log(NL + "── Review fixes ──");

  await test("dictation keeps two different phrases that arrive back-to-back", async () => {
    const finals: string[] = [];
    const rec = await startedController(finals);
    rec.finalOnly("first sentence");
    rec.finalOnly("second sentence");
    rec.finalOnly("third sentence");
    // The old guard dropped every second final-only result: 2 of 3 survived.
    assert.deepEqual(finals, ["first sentence", "second sentence", "third sentence"]);
  });

  await test("dictation keeps phrases Android reports with confidence 0", async () => {
    const finals: string[] = [];
    const rec = await startedController(finals);
    rec.finalOnly("hello there", 0);
    assert.deepEqual(finals, ["hello there"]);
  });

  await test("dictation drops the engine echoing the same phrase", async () => {
    const finals: string[] = [];
    const rec = await startedController(finals);
    rec.finalOnly("buy milk");
    rec.finalOnly("Buy milk ");
    assert.deepEqual(finals, ["buy milk"]);
  });

  await test("isRepeatedFinal: same words later on are a new phrase", () => {
    assert.equal(isRepeatedFinal("yes", 1000, "yes", 1500), true);
    assert.equal(isRepeatedFinal("yes", 1000, "yes", 9000), false);
    assert.equal(isRepeatedFinal("yes", 1000, "no", 1500), false);
    assert.equal(isRepeatedFinal("", 1000, "", 1500), false);
  });

  await test("export text: markers become what the canvas shows", () => {
    const text = ["# Title", "- [ ] Buy **milk**", "- [x] Done", "- item", "3. third", "> quoted", "plain [[Board|alias]] text"].join(NL);
    const lines = markdownToPlainLines(text);
    assert.deepEqual(
      lines.map((l) => l.text),
      ["Title", "☐ Buy milk", "☑ Done", "• item", "3. third", "│ quoted", "plain alias text"]
    );
    assert.ok(lines[0].scale > 1 && (lines[0].weight ?? 0) >= 600, "a heading is bigger and bold");
    assert.equal(lines[1].scale, 1);
  });

  await test("export text: blank lines and code blocks keep their lines", () => {
    const fence = "```";
    const text = ["a", "", fence, "x = 1", "y = 2", fence, "b"].join(NL);
    assert.deepEqual(
      markdownToPlainLines(text).map((l) => l.text),
      ["a", "", "x = 1", "y = 2", "b"]
    );
  });

  await test("prices are not maths, but real maths still is", () => {
    const kinds = (s: string) => tokenizeInline(s).map((t) => t.type);
    assert.ok(!kinds("costs $5 and $10 today").includes("math"));
    assert.ok(kinds("area is $x^2$ here").includes("math"));
    assert.ok(kinds("$$E = mc^2$$").includes("math"));
  });

  await test("arithmetic is not italic, but *emphasis* still is", () => {
    const kinds = (s: string) => tokenizeInline(s).map((t) => t.type);
    assert.ok(!kinds("2*3*4 = 24").includes("italic"));
    assert.ok(kinds("this is *important* ok").includes("italic"));
    assert.ok(kinds("**bold** word").includes("bold"));
  });

  await test("issue numbers are not tags, but words (Hebrew too) are", () => {
    const tags = (s: string) => tokenizeInline(s).filter((t) => t.type === "tag").map((t) => t.value);
    assert.deepEqual(tags("see issue #42"), []);
    assert.deepEqual(tags("todo #urgent now"), ["urgent"]);
    assert.deepEqual(tags("#שיעורים"), ["שיעורים"]);
    assert.deepEqual(tags("page.html#section"), []);
  });

  await test("sticky colour survives a read-then-write round trip", () => {
    for (const key of Object.keys(STICKY_COLORS) as (keyof typeof STICKY_COLORS)[]) {
      const style = { ...DEFAULT_STYLE, stickyColor: key };
      const read = getToolColor(style, "sticky");
      const written = setToolInk(style, "sticky", { color: read });
      assert.equal(written.stickyColor, key, `${key} came back as ${written.stickyColor}`);
    }
  });

  await test("an unknown colour leaves the sticky colour alone", () => {
    const style = { ...DEFAULT_STYLE, stickyColor: "pink" as const };
    assert.equal(setToolInk(style, "sticky", { color: "#123456" }).stickyColor, "pink");
    assert.equal(stickyColorKey("#FCE7F3"), "pink");
    assert.equal(stickyColorKey("nonsense"), null);
  });

  console.log(`  ${passed} passed, ${failed} failed`);
  if (failed > 0) process.exit(1);
}

void main();
