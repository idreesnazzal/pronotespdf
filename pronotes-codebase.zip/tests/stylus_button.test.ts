/**
 * Stylus barrel button -> hold to erase, release to get your pen back.
 *
 * The bug this pins: the first implementation read the button on pointerdown
 * and handed the pen back on pointerup, so the eraser was keyed to the NIB.
 * You had to touch the paper before the eraser appeared, and once it did you
 * were stuck in it until you lifted off - releasing the button changed
 * nothing. Holding the button while hovering did nothing at all.
 *
 * stylusEraseTransition reports EDGES on the button instead, which is what
 * lets the canvas run the same check from pointerdown and pointermove alike.
 */

import assert from "node:assert/strict";

import {
  stylusEraseTransition,
  isStylusEraseRequest,
  STYLUS_BARREL_BUTTON,
  STYLUS_ERASER_TIP,
  type StylusButtonState,
} from "../src/lib/whiteboard/input";

let passed = 0;
let failed = 0;
function test(name: string, fn: () => void) {
  try {
    fn();
    passed++;
    console.log(`  ✓ ${name}`);
  } catch (err) {
    failed++;
    console.error(`  ✗ ${name}`);
    console.error(`      ${(err as Error).message}`);
  }
}

const pen = (buttons: number): StylusButtonState => ({ pointerType: "pen", buttons });
const NIB = 1; // primary "button" = the tip is on the glass

console.log("\n── Stylus button erase ──");

test("button held while merely hovering arms the eraser", () => {
  // buttons === 2 with no nib bit: pen in the air, side button down.
  assert.equal(stylusEraseTransition(false, pen(STYLUS_BARREL_BUTTON)), "engage");
});

test("button held with the nib down also arms it", () => {
  assert.equal(stylusEraseTransition(false, pen(NIB | STYLUS_BARREL_BUTTON)), "engage");
});

test("the eraser END of the pen arms it too", () => {
  assert.equal(stylusEraseTransition(false, pen(STYLUS_ERASER_TIP)), "engage");
});

test("releasing the button gives the pen back WITH THE NIB STILL DOWN", () => {
  // This is the whole point: mid-stroke, button up, nib still on the glass.
  assert.equal(stylusEraseTransition(true, pen(NIB)), "release");
});

test("releasing the button while hovering gives the pen back", () => {
  assert.equal(stylusEraseTransition(true, pen(0)), "release");
});

test("holding the button does not re-engage every event", () => {
  // Re-engaging would overwrite the stored tool with "eraser" and strand the
  // user there forever - the exact trap the `borrowed` flag exists to avoid.
  assert.equal(stylusEraseTransition(true, pen(STYLUS_BARREL_BUTTON)), "none");
});

test("an idle pen with no button does nothing", () => {
  assert.equal(stylusEraseTransition(false, pen(0)), "none");
  assert.equal(stylusEraseTransition(false, pen(NIB)), "none");
});

test("a finger never releases an eraser the pen is holding", () => {
  // Palm and finger events interleave with pen events on a tablet. If touch
  // could answer for the pen, resting a hand mid-erase would snap the tool
  // back underneath you.
  assert.equal(stylusEraseTransition(true, { pointerType: "touch", buttons: 0 }), "none");
  assert.equal(stylusEraseTransition(true, { pointerType: "touch", buttons: 1 }), "none");
});

test("a mouse never engages it", () => {
  // buttons === 2 on a mouse is right-click, which must stay a context menu.
  assert.equal(stylusEraseTransition(false, { pointerType: "mouse", buttons: 2 }), "none");
  assert.equal(stylusEraseTransition(true, { pointerType: "mouse", buttons: 0 }), "none");
});

test("transition agrees with isStylusEraseRequest on every button mask", () => {
  for (let b = 0; b < 64; b++) {
    const wants = isStylusEraseRequest(pen(b));
    assert.equal(stylusEraseTransition(false, pen(b)), wants ? "engage" : "none", `mask ${b} from idle`);
    assert.equal(stylusEraseTransition(true, pen(b)), wants ? "none" : "release", `mask ${b} while borrowed`);
  }
});

test("a full press-hover-draw-release cycle ends back on the pen", () => {
  let borrowed = false;
  const step = (buttons: number) => {
    const a = stylusEraseTransition(borrowed, pen(buttons));
    if (a === "engage") borrowed = true;
    if (a === "release") borrowed = false;
    return a;
  };
  assert.equal(step(STYLUS_BARREL_BUTTON), "engage");          // hover, button down
  assert.equal(step(STYLUS_BARREL_BUTTON), "none");            // still hovering
  assert.equal(step(NIB | STYLUS_BARREL_BUTTON), "none");      // nib lands, erasing
  assert.equal(step(NIB | STYLUS_BARREL_BUTTON), "none");      // sweeping
  assert.equal(step(NIB), "release");                          // button up, nib down
  assert.equal(borrowed, false, "the pen is back before the nib ever lifts");
  assert.equal(step(0), "none");                               // lift off: nothing left to undo
});

console.log(`\n  ${passed} passed, ${failed} failed\n`);
if (failed > 0) process.exit(1);
