/**
 * Word / PowerPoint import: the parts that must hold without a browser.
 * - Which files are Word, PowerPoint, or the old binary formats.
 * - The slide clean-up that fixed a real Hebrew deck: a text box whose
 *   position lives on the layout gets it written in, and two boxes sharing a
 *   layout slot are separated (the renderer drew the main text as a column
 *   one letter wide).
 */

import assert from "node:assert/strict";
import {
  DOCUMENT_ACCEPT,
  hasRtl,
  normalizeSlideXml,
  officeKindOf,
  placeholderGeometry,
  restoreGlobals,
  pictureFromFilledBox,
  preferFallbackContent,
} from "../src/lib/whiteboard/officeImport";

const NL = String.fromCharCode(10);
let passed = 0;
let failed = 0;
function test(name: string, fn: () => void) {
  try {
    fn();
    passed++;
    console.log(`  ✓ ${name}`);
  } catch (err) {
    failed++;
    console.error(`  ✗ ${name}`);
    console.error(`      ${(err as Error).message}`);
  }
}

console.log(NL + "── Office import ──");

test("recognises Word, PowerPoint and the old formats by name or type", () => {
  assert.equal(officeKindOf({ name: "Lecture 3.pptx" }), "pptx");
  assert.equal(officeKindOf({ name: "show.PPSX" }), "pptx");
  assert.equal(officeKindOf({ name: "notes.docx" }), "docx");
  assert.equal(
    officeKindOf({ name: "x", type: "application/vnd.openxmlformats-officedocument.presentationml.presentation" }),
    "pptx"
  );
  assert.equal(officeKindOf({ name: "old.doc" }), "legacy");
  assert.equal(officeKindOf({ name: "old.ppt" }), "legacy");
  assert.equal(officeKindOf({ name: "paper.pdf", type: "application/pdf" }), null);
  assert.equal(officeKindOf({ name: "photo.jpg", type: "image/jpeg" }), null);
});

test("the file picker offers PDF, Word and PowerPoint", () => {
  for (const ext of [".pdf", ".docx", ".pptx"]) assert.ok(DOCUMENT_ACCEPT.includes(ext), ext);
});

test("Hebrew and Arabic are detected; Latin text is not", () => {
  assert.equal(hasRtl("כתיבת פתרון"), true);
  assert.equal(hasRtl("مرحبا"), true);
  assert.equal(hasRtl("O(log n) and AVL"), false);
});

const LAYOUT = `<p:sldLayout><p:cSld><p:spTree>
<p:sp><p:nvSpPr><p:nvPr><p:ph type="title"/></p:nvPr></p:nvSpPr><p:spPr><a:xfrm><a:off x="100" y="200"/><a:ext cx="1000" cy="300"/></a:xfrm></p:spPr></p:sp>
<p:sp><p:nvSpPr><p:nvPr><p:ph idx="1"/></p:nvPr></p:nvSpPr><p:spPr><a:xfrm><a:off x="100" y="600"/><a:ext cx="1000" cy="4000"/></a:xfrm></p:spPr></p:sp>
</p:spTree></p:cSld></p:sldLayout>`;

test("layout placeholders are read with their positions", () => {
  const g = placeholderGeometry(LAYOUT);
  assert.equal(g.length, 2);
  assert.equal(g[0].type, "title");
  assert.equal(g[1].idx, "1");
  assert.match(g[1].xfrm, /y="600"/);
});

test("a text box without a position gets its layout slot's", () => {
  const slide = `<p:sld><p:sp><p:nvSpPr><p:nvPr><p:ph idx="1"/></p:nvPr></p:nvSpPr><p:spPr/><p:txBody><a:p><a:r><a:t>שלום</a:t></a:r></a:p></p:txBody></p:sp></p:sld>`;
  const out = normalizeSlideXml(slide, LAYOUT);
  assert.match(out, /<p:spPr><a:xfrm><a:off x="100" y="600"\/>/);
  assert.match(out, /שלום/);
  const titled = normalizeSlideXml(
    `<p:sld><p:sp><p:nvSpPr><p:nvPr><p:ph type="title"/></p:nvPr></p:nvSpPr><p:spPr></p:spPr></p:sp></p:sld>`,
    LAYOUT
  );
  assert.match(titled, /<p:spPr><a:xfrm><a:off x="100" y="200"\/>/);
});

test("two boxes sharing one slot are separated; the first keeps it", () => {
  const box = (text: string) =>
    `<p:sp><p:nvSpPr><p:nvPr><p:ph idx="1"/></p:nvPr></p:nvSpPr><p:spPr/><p:txBody><a:p><a:r><a:t>${text}</a:t></a:r></a:p></p:txBody></p:sp>`;
  const out = normalizeSlideXml(`<p:sld>${box("main")}${box("second")}</p:sld>`, LAYOUT);
  const idxs = [...out.matchAll(/<p:ph idx="(\d+)"/g)].map((m) => m[1]);
  assert.equal(idxs.length, 2);
  assert.equal(idxs[0], "1", "the first box keeps the layout slot");
  assert.notEqual(idxs[1], "1", "the second gets a slot of its own");
  // Both got a real position before the second lost its link to the layout.
  assert.equal((out.match(/<a:xfrm>/g) ?? []).length, 2);
});

test("boxes that already have positions, and non-placeholders, are untouched", () => {
  const slide = `<p:sld><p:sp><p:nvSpPr><p:nvPr><p:ph idx="1"/></p:nvPr></p:nvSpPr><p:spPr><a:xfrm><a:off x="5" y="6"/><a:ext cx="7" cy="8"/></a:xfrm></p:spPr></p:sp><p:sp><p:nvSpPr><p:nvPr/></p:nvSpPr><p:spPr/></p:sp></p:sld>`;
  assert.equal(normalizeSlideXml(slide, LAYOUT), slide);
});

test("a library that overwrites browser globals gets them put back", () => {
  // pptxviewjs assigns window.FileReader on load; after one PowerPoint import
  // every file read in the app failed. Changed globals are restored.
  class RealReader {}
  class FakeReader {}
  const win: Record<string, unknown> = { FileReader: RealReader, keep: 1 };
  const before = new Map(Object.entries(win));
  win.FileReader = FakeReader; // what the library does on load
  win.Logger = "added by the library";
  const restored = restoreGlobals(win, before);
  assert.deepEqual(restored, ["FileReader"]);
  assert.equal(win.FileReader, RealReader);
  assert.equal(win.Logger, "added by the library", "names it only added are left alone");
});

test("a text box with an equation uses PowerPoint's own picture of it", () => {
  // The Office-2010 maths version drew as a one-letter column; the fallback
  // is PowerPoint's rendering of the same box.
  const slide =
    '<p:sld><mc:AlternateContent><mc:Choice Requires="a14"><p:sp><p:txBody><a14:m>O(n)</a14:m></p:txBody></p:sp></mc:Choice>' +
    '<mc:Fallback><p:sp><p:spPr><a:blipFill><a:blip r:embed="rId2"/></a:blipFill></p:spPr></p:sp></mc:Fallback></mc:AlternateContent></p:sld>';
  const out = preferFallbackContent(slide);
  assert.ok(!out.includes("AlternateContent") && !out.includes("a14:m"), out);
  assert.match(out, /<a:blip r:embed="rId2"\/>/);
  // No fallback: the choice is kept rather than losing the shape.
  const onlyChoice = '<mc:AlternateContent><mc:Choice Requires="x"><p:sp>kept</p:sp></mc:Choice></mc:AlternateContent>';
  assert.equal(preferFallbackContent(onlyChoice), "<p:sp>kept</p:sp>");
  assert.equal(preferFallbackContent("<p:sld/>"), "<p:sld/>");
});

test("an equation box's fallback picture becomes a real picture, in place", () => {
  const box =
    '<p:sp><p:nvSpPr><p:cNvPr id="3" name="Content Placeholder 2"/><p:nvPr><p:ph idx="1"/></p:nvPr></p:nvSpPr>' +
    '<p:spPr/><p:txBody><a:p><a:r><a:t> </a:t></a:r></a:p></p:txBody></p:sp>';
  const fallback = box.replace("<p:spPr/>", '<p:spPr><a:blipFill><a:blip r:embed="rId2"/><a:stretch><a:fillRect l="-1273"/></a:stretch></a:blipFill></p:spPr>');
  const out = normalizeSlideXml(`<p:sld>${fallback}</p:sld>`, LAYOUT);
  assert.match(out, /<p:pic>/);
  assert.match(out, /<p:blipFill><a:blip r:embed="rId2"\/><a:stretch><a:fillRect l="-1273"\/><\/a:stretch><\/p:blipFill>/);
  assert.match(out, /<a:off x="100" y="600"\/>/, "at the layout slot's position");
  // A box with real text is never turned into a picture.
  const texty = fallback.replace("<a:t> </a:t>", "<a:t>hello</a:t>");
  assert.equal(pictureFromFilledBox(texty.replace("<p:spPr>", '<p:spPr><a:xfrm><a:off x="1" y="1"/><a:ext cx="1" cy="1"/></a:xfrm>')), null);
});

console.log(`  ${passed} passed, ${failed} failed`);
if (failed > 0) process.exit(1);
