/**
 * S Pen Dynamics, Pressure Calibration, & Stabilization Test Suite
 * ===============================================================
 * Validates the inking engine capabilities:
 * 1. S Pen pressure calibration curves (soft, standard, firm, off) and dynamic sensitivity.
 * 2. 0-100% stabilization and streamline scaling across all 8 pen types.
 * 3. 8 distinct pen presets (ballpoint, gel, fineliner, fountain, brush, marker, highlighter, pencil).
 * 4. Draw-and-hold auto-straightening geometry detection and point interpolation.
 * 5. Terminal anti-hook filter on pen lift-off.
 * 6. buildStrokePath geometry generation with smoothing override.
 */

import assert from "node:assert/strict";
import {
  calibratePressure,
  getStrokeOptionsForStyle,
  applyPenDynamics,
  buildStrokePath,
  isStrokeStraight,
  straightenStrokePoints,
  pruneTerminalHooks,
} from "../src/lib/whiteboard/stroke";
import {
  PEN_TYPE_PRESETS,
  PEN_TYPES,
  type StrokeStyle,
  type StrokeElement,
} from "../src/lib/whiteboard/types";

let passed = 0;
let failed = 0;

function test(name: string, fn: () => void) {
  try {
    fn();
    passed++;
    console.log(`  ✓ ${name}`);
  } catch (err) {
    failed++;
    console.error(`  ✗ ${name}`);
    console.error(`      ${(err as Error).message}`);
  }
}

console.log("\n── S Pen Dynamics & Pressure Calibration ──");

test("pressure calibration: 'off' curve always returns uniform 0.5", () => {
  assert.equal(calibratePressure(0.1, 80, "off"), 0.5);
  assert.equal(calibratePressure(0.5, 80, "off"), 0.5);
  assert.equal(calibratePressure(0.9, 80, "off"), 0.5);
});

test("pressure calibration: 0 sensitivity always returns uniform 0.5", () => {
  assert.equal(calibratePressure(0.1, 0, "standard"), 0.5);
  assert.equal(calibratePressure(0.9, 0, "soft"), 0.5);
});

test("pressure calibration: 'soft' curve reaches higher pressure for light touch", () => {
  const lightRaw = 0.25;
  const softCalibrated = calibratePressure(lightRaw, 50, "soft");
  const standardCalibrated = calibratePressure(lightRaw, 50, "standard");
  assert.ok(
    softCalibrated > standardCalibrated,
    `Soft curve (${softCalibrated}) should exceed standard (${standardCalibrated}) for light touch`
  );
});

test("pressure calibration: 'firm' curve requires heavier touch for thick ink", () => {
  const mediumRaw = 0.4;
  const firmCalibrated = calibratePressure(mediumRaw, 50, "firm");
  const standardCalibrated = calibratePressure(mediumRaw, 50, "standard");
  assert.ok(
    firmCalibrated < standardCalibrated,
    `Firm curve (${firmCalibrated}) should be lower than standard (${standardCalibrated}) for medium touch`
  );
});

test("pressure calibration: clamps extreme raw inputs safely into [0.02, 1.0]", () => {
  const low = calibratePressure(-0.5, 100, "standard");
  const high = calibratePressure(2.5, 100, "standard");
  assert.ok(low >= 0.02, "Low pressure must clamp at or above 0.02");
  assert.ok(high <= 1.0, "High pressure must clamp at or below 1.0");
});

test("applyPenDynamics: applies speed dynamics to stroke points", () => {
  const rawPoints: Array<[number, number, number]> = [
    [0, 0, 0.5],
    [5, 0, 0.5],
    [50, 0, 0.5], // fast movement -> velocity response for ballpoint
  ];
  const dynamicPoints = applyPenDynamics(rawPoints, "ballpoint");
  assert.equal(dynamicPoints.length, rawPoints.length);
  // Point 2 moved 45px (fast) -> speed response reduces effective pressure/width
  assert.ok(dynamicPoints[2][2] < dynamicPoints[1][2], "Fast movement should thin stroke in ballpoint");
});

console.log("\n── Stroke Stabilization & Smoothing (0–100%) ──");

test("smoothing: default 50% exactly matches preset default parameters", () => {
  for (const st of PEN_TYPES) {
    const preset = PEN_TYPE_PRESETS[st];
    const opts = getStrokeOptionsForStyle(st, 10, true, 50);
    assert.equal(
      opts.smoothing,
      preset.smoothing,
      `${st} smoothing at 50% must equal preset default (${preset.smoothing})`
    );
    assert.equal(
      opts.streamline,
      preset.streamline,
      `${st} streamline at 50% must equal preset default (${preset.streamline})`
    );
  }
});

test("smoothing: 0% scales down smoothing and streamline to minimal boundary", () => {
  const opts = getStrokeOptionsForStyle("gel", 10, true, 0);
  assert.equal(opts.smoothing, 0.02);
  assert.equal(opts.streamline, 0.02);
});

test("smoothing: 100% doubles smoothing and streamline up to safety clamps", () => {
  const gelPreset = PEN_TYPE_PRESETS.gel;
  const opts = getStrokeOptionsForStyle("gel", 10, true, 100);
  const expectedSmoothing = Math.min(0.98, gelPreset.smoothing * 2.0);
  const expectedStreamline = Math.min(0.95, gelPreset.streamline * 2.0);
  assert.equal(opts.smoothing, expectedSmoothing);
  assert.equal(opts.streamline, expectedStreamline);
});

console.log("\n── 8 Distinct Pen Engines Characteristics ──");

test("all 8 core pen engines are registered and defined", () => {
  const requiredPens: StrokeStyle[] = [
    "ballpoint",
    "gel",
    "fineliner",
    "fountain",
    "brush",
    "marker",
    "highlighter",
    "pencil",
  ];
  for (const pen of requiredPens) {
    assert.ok(PEN_TYPE_PRESETS[pen], `Preset for ${pen} must exist`);
    // Ballpoint and fineliner keep their presets (old strokes still draw)
    // but are not offered in the picker: they looked like the gel pen.
    if (pen !== "ballpoint" && pen !== "fineliner") {
      assert.ok(PEN_TYPES.includes(pen), `PEN_TYPES must include ${pen}`);
    }
  }
});

test("pen characteristics: ballpoint has speed thinning and round cap", () => {
  const p = PEN_TYPE_PRESETS.ballpoint;
  assert.equal(p.cap, "round");
  assert.ok(p.speedResponse && p.speedResponse > 0, "Ballpoint must respond to speed");
  assert.equal(p.sizeScale, 0.7, "Ballpoint sizeScale should be 0.7 for fine notes");
});

test("pen characteristics: fineliner is monoline technical drafting pen", () => {
  const p = PEN_TYPE_PRESETS.fineliner;
  assert.equal(p.thinning, 0, "Fineliner must have zero thinning");
  assert.equal(p.startTaper, 0, "Fineliner must have zero start taper");
  assert.equal(p.endTaper, 0, "Fineliner must have zero end taper");
  assert.equal(p.sizeScale, 0.5, "Fineliner must be fine 0.5 scale");
});

test("pen characteristics: fountain pen has 40° chisel nib and taper", () => {
  const p = PEN_TYPE_PRESETS.fountain;
  assert.equal(p.nibAngle, 40, "Fountain pen must have 40 deg nib angle");
  assert.ok(p.endTaper > 0, "Fountain pen must taper at end of stroke");
  assert.ok(p.thinning >= 0.5, "Fountain pen must have dynamic thinning");
});

test("pen characteristics: brush pen has fluid taper and pressure response", () => {
  const p = PEN_TYPE_PRESETS.brush;
  assert.equal(p.simulatePressure, true);
  assert.ok(p.startTaper > 0 && p.endTaper > 0, "Brush must taper at both ends");
  assert.ok(p.sizeScale >= 1.2, "Brush should be bold");
});

test("pen characteristics: highlighter has multiply blend mode and flat chisel cap", () => {
  const p = PEN_TYPE_PRESETS.highlighter;
  assert.equal(p.mixBlendMode, "multiply", "Highlighter must multiply so text stays sharp");
  assert.equal(p.cap, "flat", "Highlighter must have flat chisel cap");
  assert.ok(p.opacity <= 0.4, "Highlighter must be translucent");
  assert.equal(p.sizeScale, 3.0, "Highlighter must be broad 3x scale");
});

test("pen characteristics: pencil has graphite grain texture and multiply blend", () => {
  const p = PEN_TYPE_PRESETS.pencil;
  assert.equal(p.grain, true, "Pencil must have grain texture flag");
  assert.equal(p.mixBlendMode, "multiply");
  assert.ok(p.opacity < 1.0, "Pencil has slight tooth translucency");
});

console.log("\n── Draw-and-Hold Auto-Straighten Detection ──");

test("isStrokeStraight: detects intentional straight line", () => {
  // Horizontal straight line with 10 points
  const straightPoints: Array<[number, number, number]> = [
    [10, 50, 0.5],
    [30, 50, 0.5],
    [50, 50, 0.5],
    [70, 50, 0.5],
    [90, 50, 0.5],
    [110, 50, 0.5],
    [130, 50, 0.5],
    [150, 50, 0.5],
  ];
  assert.ok(isStrokeStraight(straightPoints), "Horizontal line must be classified as straight");
});

test("isStrokeStraight: rejects curved or zigzag strokes", () => {
  // Zigzag stroke
  const zigzagPoints: Array<[number, number, number]> = [
    [10, 10, 0.5],
    [30, 50, 0.5],
    [50, 10, 0.5],
    [70, 50, 0.5],
    [90, 10, 0.5],
    [110, 50, 0.5],
  ];
  assert.ok(!isStrokeStraight(zigzagPoints), "Zigzag stroke must not be classified as straight");
});

test("isStrokeStraight: rejects short strokes under 28px chord threshold", () => {
  const shortPoints: Array<[number, number, number]> = [
    [10, 10, 0.5],
    [12, 10, 0.5],
    [14, 10, 0.5],
    [16, 10, 0.5],
    [18, 10, 0.5],
    [20, 10, 0.5],
  ];
  assert.ok(!isStrokeStraight(shortPoints), "Stroke with chord < 28px must return false");
});

test("straightenStrokePoints: generates straight interpolated line preserving endpoints and average pressure", () => {
  const input: Array<[number, number, number]> = [
    [0, 0, 0.4],
    [20, 5, 0.6],
    [40, -5, 0.8],
    [100, 0, 0.6],
  ];
  const straightened = straightenStrokePoints(input, 5);
  assert.equal(straightened.length, 6);
  assert.deepEqual(straightened[0], [0, 0, 0.6]); // start point with average pressure (0.4+0.6+0.8+0.6)/4 = 0.6
  assert.deepEqual(straightened[5], [100, 0, 0.6]); // end point
  // Midpoint x must be 40% of chord at segment 2
  assert.equal(straightened[2][0], 40);
  assert.equal(straightened[2][1], 0);
});

console.log("\n── Anti-Hook Lift-Off Filter ──");

test("pruneTerminalHooks: trims sharp reverse hook flick at stroke end", () => {
  // A forward stroke that sharply hooks back on lift-off
  const hookedPoints: Array<[number, number, number]> = [
    [10, 100, 0.5],
    [30, 100, 0.5],
    [50, 100, 0.5],
    [70, 100, 0.5],
    [90, 100, 0.5],
    [110, 100, 0.5],
    [95, 95, 0.2], // sharp terminal hook backward on lift-off
  ];
  const pruned = pruneTerminalHooks(hookedPoints);
  assert.ok(pruned.length < hookedPoints.length, "Terminal hook should be pruned");
  assert.equal(pruned[pruned.length - 1][0], 110, "Last point should be before the hook turn");
});

test("pruneTerminalHooks: preserves smooth natural strokes without hooks", () => {
  const smoothPoints: Array<[number, number, number]> = [
    [10, 100, 0.5],
    [30, 105, 0.5],
    [50, 112, 0.5],
    [70, 120, 0.5],
    [90, 130, 0.5],
  ];
  const result = pruneTerminalHooks(smoothPoints);
  assert.equal(result.length, smoothPoints.length, "Smooth strokes must not be pruned");
});

console.log("\n── buildStrokePath with Smoothing Override ──");

test("buildStrokePath generates valid SVG path data", () => {
  const testStroke: StrokeElement = {
    id: "test-stroke",
    type: "stroke",
    x: 10,
    y: 10,
    rotation: 0,
    opacity: 1,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    points: [
      [10, 10, 0.5],
      [20, 15, 0.5],
      [30, 25, 0.5],
      [40, 40, 0.5],
    ],
    color: "#3b82f6",
    strokeWidth: 4,
    strokeStyle: "gel",
  };
  const pathNormal = buildStrokePath(testStroke, false);
  assert.ok(pathNormal.startsWith("M"), "SVG path must start with M");

  const pathSmoothed = buildStrokePath(testStroke, false, 85);
  assert.ok(pathSmoothed.startsWith("M"), "Overridden smoothing path must be valid SVG");
});

console.log(`\n==================================================`);
console.log(`Pen Dynamics & Stabilization: ${passed} passed, ${failed} failed`);
console.log(`==================================================\n`);

if (failed > 0) {
  process.exit(1);
}
