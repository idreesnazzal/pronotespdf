/**
 * Split view: switching which side is live must change nothing you can see,
 * and must not cost you your undo.
 *
 * Both were broken, and both were reproduced on a real build before being
 * fixed:
 *
 *  - Tapping the other pane moved it. Its camera went from y 561 to 640,
 *    because the live canvas clamps a notebook's camera to the paper and the
 *    other pane did not - so every switch was followed by a "correction".
 *  - Reading page 5 in the other pane and tapping it put you on page 8. That
 *    pane kept a private page counter while the notebook's own active page
 *    never moved.
 *  - Every switch wiped the undo history, because a switch is a board change
 *    and setActiveBoard emptied the whole list.
 *
 * The guarantee that makes "nothing moves" hold is idempotence: the other pane
 * shows the stored camera PUT THROUGH the live canvas's rules, so when the
 * canvas takes over and applies those same rules, there is nothing left to
 * change. Those properties are pinned directly below.
 */

import assert from "node:assert/strict";

import { useWhiteboard } from "../src/store/whiteboard";
import {
  clampNotebookCamera,
  getActivePageIndex,
  getPages,
  minNotebookZoom,
  PAGE_GAP,
  reanchorDirection,
  visibleSheets,
  allElements,
} from "../src/lib/whiteboard/notebook";
import { cleanHistoryEntry, migrateState } from "../src/lib/whiteboard/persistence";
import { dividerRatio, MIN_PANE_PX } from "../src/lib/whiteboard/split";
import type { Board, Camera, NotebookPage, WhiteboardElement } from "../src/lib/whiteboard/types";

let passed = 0;
let failed = 0;
function test(name: string, fn: () => void) {
  try {
    fn();
    passed++;
    console.log(`  ✓ ${name}`);
  } catch (err) {
    failed++;
    console.error(`  ✗ ${name}`);
    console.error(`      ${(err as Error).message}`);
  }
}

const S = () => useWhiteboard.getState();
const board = (id: string): Board => S().boards.find((b) => b.id === id)!;

const A4 = { width: 794, height: 1123 };
const PANE = { width: 512, height: 800 };

let seq = 0;
function text(label: string): WhiteboardElement {
  seq++;
  return {
    id: `t${seq}`,
    type: "text",
    x: 60,
    y: 120,
    width: 300,
    height: 40,
    rotation: 0,
    opacity: 1,
    text: label,
    color: "#111",
    fontSize: 24,
    fontFamily: "Inter",
    fontWeight: 400,
    align: "left",
    createdAt: 1,
    updatedAt: 1,
  } as unknown as WhiteboardElement;
}

function notebook(id: string, pageCount: number, camera: Camera = { x: 397, y: 561, zoom: 0.5 }): Board {
  const pages: NotebookPage[] = Array.from({ length: pageCount }, (_, i) => ({
    id: `${id}_p${i + 1}`,
    elements: [text(`${id} page ${i + 1}`)],
    createdAt: 1,
    updatedAt: 1,
  }));
  return {
    id,
    name: id,
    folderId: null,
    elements: [],
    camera,
    kind: "notebook",
    pages,
    activePageId: pages[0].id,
    pageSize: "a4",
    createdAt: 1,
    updatedAt: 1,
  } as Board;
}

/** Two notebooks in split view: `left` live, `right` in the other pane. */
function split(left: Board, right: Board) {
  useWhiteboard.setState({
    boards: [left, right],
    activeBoardId: left.id,
    camera: { ...left.camera },
    splitBoardId: right.id,
    splitSide: "left",
    splitRatio: 0.5,
    selectedIds: [],
    editingId: null,
    history: { past: [], future: [] },
  });
}

/** The live canvas's settle rules, in the order it applies them. */
function settle(cam: Camera, b: Board, vp = PANE): Camera {
  const floor = minNotebookZoom(vp, A4);
  const zoom = floor > 0 && cam.zoom < floor - 1e-3 ? floor : cam.zoom;
  const { x, y } = clampNotebookCamera({ ...cam, zoom }, vp, A4, {
    pageCount: getPages(b).length,
    activeIndex: getActivePageIndex(b),
  });
  return { x, y, zoom };
}

console.log("\n── One layout for every pane ──");

test("visibleSheets reproduces the live canvas's own neighbour rule", () => {
  // The canvas's inline logic, restated: every page a stride apart relative to
  // the active one, skipping anything more than a stride outside the band.
  const reference = (count: number, active: number, camY: number, halfH: number) => {
    const stride = A4.height + PAGE_GAP;
    const out: Array<{ index: number; offsetY: number }> = [];
    for (let i = 0; i < count; i++) {
      const offsetY = (i - active) * stride;
      if (offsetY + A4.height < camY - halfH - stride) continue;
      if (offsetY > camY + halfH + stride) continue;
      out.push({ index: i, offsetY });
    }
    return out;
  };
  for (const [count, active, camY, halfH] of [
    [8, 0, 561, 800],
    [8, 4, 200, 400],
    [8, 7, 1100, 1600],
    [200, 120, 561, 800],
    [1, 0, 0, 800],
  ]) {
    assert.deepEqual(visibleSheets(count, active, A4.height, camY, halfH), reference(count, active, camY, halfH));
  }
});

test("a 200-page notebook draws a handful of sheets, not 200", () => {
  const sheets = visibleSheets(200, 100, A4.height, 561, 800);
  assert.ok(sheets.length > 0 && sheets.length <= 5, `drew ${sheets.length}`);
  assert.ok(sheets.some((s) => s.index === 100 && s.offsetY === 0), "the anchored page sits at y = 0");
});

test("re-anchoring hands the page on at the middle of the gap, both ways", () => {
  const h = A4.height;
  assert.equal(reanchorDirection(h + PAGE_GAP / 2 + 1, h, 2, 8), 1);
  assert.equal(reanchorDirection(h + PAGE_GAP / 2 - 1, h, 2, 8), 0);
  assert.equal(reanchorDirection(-PAGE_GAP / 2 - 1, h, 2, 8), -1);
  assert.equal(reanchorDirection(-PAGE_GAP / 2 + 1, h, 2, 8), 0);
  assert.equal(reanchorDirection(99999, h, 7, 8), 0, "no page after the last one");
  assert.equal(reanchorDirection(-99999, h, 0, 8), 0, "no page before the first one");
});

console.log("\n── Switching must move nothing ──");

test("settling is idempotent - the property that makes a switch invisible", () => {
  // The other pane shows settle(stored). When the canvas takes over it applies
  // settle() again. If a second pass changed anything, the page would jump.
  const b = notebook("N", 8);
  for (const cam of [
    { x: 397, y: 561, zoom: 0.5 },
    { x: 0, y: -900, zoom: 0.2 },
    { x: 2000, y: 9000, zoom: 3 },
    { x: 397, y: 284.77, zoom: 0.7167 },
  ]) {
    const once = settle(cam, b);
    const twice = settle(once, b);
    assert.deepEqual(twice, once, `second pass moved ${JSON.stringify(cam)}`);
  }
});

test("the camera that used to jump on a switch is already settled when shown", () => {
  // Reproduced on the build: stored y 561 was shown at 561 in the other pane,
  // then corrected to 640 the moment the canvas took over.
  const b = notebook("N", 8);
  const shown = settle({ x: 397, y: 561, zoom: 0.5 }, b);
  assert.equal(Math.round(shown.y), 640, "shown where the canvas would put it");
  assert.deepEqual(settle(shown, b), shown, "so the canvas has nothing to correct");
});

test("focusing the other pane leaves both documents' cameras exactly as they were", () => {
  const L = notebook("L", 8, { x: 397, y: 284.77, zoom: 0.7167 });
  const R = notebook("R", 8, { x: 397, y: 640, zoom: 0.5 });
  split(L, R);
  const before = { L: { ...S().camera }, R: { ...board("R").camera } };

  S().focusSplitSide("right");
  assert.equal(S().activeBoardId, "R", "the other pane is now live");
  assert.deepEqual(S().camera, before.R, "R shows exactly what it showed before");
  assert.deepEqual(board("L").camera, before.L, "L keeps its view as it becomes the other pane");

  S().focusSplitSide("left");
  assert.deepEqual(S().camera, before.L, "and back again, still untouched");
  assert.deepEqual(board("R").camera, before.R);
});

console.log("\n── The page you read is the page you write on ──");

test("turning the other pane's page moves THAT notebook's own page", () => {
  const L = notebook("L", 8);
  const R = notebook("R", 8);
  split(L, R);
  S().goToBoardPage("R", "R_p5", PANE.height);
  assert.equal(getActivePageIndex(board("R")), 4, "R is on page 5");
  assert.equal(getActivePageIndex(board("L")), 0, "the live notebook did not move");
  assert.equal(S().activeBoardId, "L", "turning a page does not by itself switch the store");
});

test("…so switching to it opens on page 5, not wherever it was before", () => {
  const L = notebook("L", 8);
  const R = notebook("R", 8);
  split(L, R);
  S().goToBoardPage("R", "R_p5", PANE.height);
  S().focusSplitSide("right");
  assert.equal(getActivePageIndex(board("R")), 4, "still page 5 once live");
});

test("the page opens at its top, framed like the live canvas's own page buttons", () => {
  const L = notebook("L", 8);
  const R = notebook("R", 8, { x: 397, y: 561, zoom: 0.5 });
  split(L, R);
  S().goToBoardPage("R", "R_p3", PANE.height);
  // goToPage's framing: the page top 24 px below the top of the pane.
  assert.equal(board("R").camera.y, PANE.height / 2 / 0.5 - 24 / 0.5);
});

test("scrolling the other pane across a page hands the anchor on without moving", () => {
  const L = notebook("L", 8);
  const R = notebook("R", 8, { x: 397, y: 1200, zoom: 0.5 });
  split(L, R);
  const stride = A4.height + PAGE_GAP;
  S().reanchorBoardPage("R", 1, stride);
  assert.equal(getActivePageIndex(board("R")), 1, "page 2 is now the anchor");
  assert.equal(board("R").camera.y, 1200 - stride, "and the camera slid one stride to match");
  assert.equal(getActivePageIndex(board("L")), 0, "the live notebook is untouched");
});

console.log("\n── Undo survives switching sides ──");

test("switching panes no longer wipes the undo history", () => {
  const L = notebook("L", 2);
  const R = notebook("R", 2);
  split(L, R);
  S().addElement(text("drawn on L"), true);
  const depth = S().history.past.length;
  assert.ok(depth > 0);
  S().focusSplitSide("right");
  S().focusSplitSide("left");
  assert.equal(S().history.past.length, depth, "still there after going across and back");
});

test("undo on the live side undoes the live side's work", () => {
  const L = notebook("L", 2);
  const R = notebook("R", 2);
  split(L, R);
  S().addElement(text("on L"), true);
  const lAfter = allElements(board("L")).length;
  S().focusSplitSide("right");
  S().addElement(text("on R"), true);
  const rAfter = allElements(board("R")).length;

  S().undo();
  assert.equal(allElements(board("R")).length, rAfter - 1, "R's stroke came off");
  assert.equal(allElements(board("L")).length, lAfter, "L was not touched");
});

test("undo never reaches across the divider into the pane you are not in", () => {
  const L = notebook("L", 2);
  const R = notebook("R", 2);
  split(L, R);
  S().addElement(text("on L"), true);
  const lAfter = allElements(board("L")).length;
  S().focusSplitSide("right");
  // Nothing done on R yet: undo here must do nothing at all.
  S().undo();
  S().undo();
  assert.equal(allElements(board("L")).length, lAfter, "L's work is safe while you are on R");
  assert.equal(S().canUndo(), false, "and the UI can say there is nothing to undo here");
});

test("going back to the other side brings its undo back with it", () => {
  const L = notebook("L", 2);
  const R = notebook("R", 2);
  split(L, R);
  const lStart = allElements(board("L")).length;
  S().addElement(text("on L"), true);
  S().focusSplitSide("right");
  S().addElement(text("on R"), true);
  S().focusSplitSide("left");
  S().undo();
  assert.equal(allElements(board("L")).length, lStart, "L's own edit is undone on L");
});

test("a new edit on one side keeps the other side's redo", () => {
  const L = notebook("L", 2);
  const R = notebook("R", 2);
  split(L, R);
  S().focusSplitSide("right");
  S().addElement(text("on R"), true);
  S().undo();
  assert.equal(S().canRedo(), true, "R has something to redo");
  S().focusSplitSide("left");
  S().addElement(text("on L"), true); // a fresh edit on L...
  S().focusSplitSide("right");
  assert.equal(S().canRedo(), true, "...did not throw away R's redo");
});

test("merging into a closed notebook is still undone from where you did it", () => {
  // The Duplicate dialog's promise: one Ctrl+Z cancels the merge, even though
  // the pages changed are in a notebook that is not on screen.
  const here = notebook("HERE", 2);
  const closed = notebook("CLOSED", 2);
  const source = notebook("SRC", 3);
  useWhiteboard.setState({
    boards: [here, closed, source],
    activeBoardId: "HERE",
    camera: { ...here.camera },
    splitBoardId: null,
    selectedIds: [],
    editingId: null,
    history: { past: [], future: [] },
  });
  S().insertPagesFromBoard("SRC", { indices: [1] }, 2, "CLOSED");
  assert.equal(getPages(board("CLOSED")).length, 3);
  S().undo();
  assert.equal(getPages(board("CLOSED")).length, 2, "one undo from HERE cancelled it");
});

test("switching notebooks from the sidebar never lets undo edit one you cannot see", () => {
  const A = notebook("A", 1);
  const B = notebook("B", 1);
  useWhiteboard.setState({
    boards: [A, B],
    activeBoardId: "A",
    camera: { ...A.camera },
    splitBoardId: null,
    selectedIds: [],
    editingId: null,
    history: { past: [], future: [] },
  });
  S().addElement(text("on A"), true);
  const aAfter = allElements(board("A")).length;
  S().setActiveBoard("B");
  S().undo();
  assert.equal(allElements(board("A")).length, aAfter, "A, off screen, was not changed");
});

console.log("\n── Older saves still load ──");

test("history entries saved before `activeAt` existed still load and still undo", () => {
  const legacy = { boardId: "A", elements: [], at: 5 };
  const clean = cleanHistoryEntry(legacy);
  assert.ok(clean, "accepted");
  assert.equal(clean!.activeAt, undefined, "no context recorded - it means the board itself");
});

test("the recorded context survives a save and reload", () => {
  const clean = cleanHistoryEntry({ boardId: "CLOSED", activeAt: "HERE", elements: [], at: 5 });
  assert.equal(clean!.activeAt, "HERE");
});

// ---------------------------------------------------------------------------
// Top & bottom
// ---------------------------------------------------------------------------

test("the divider keeps both panes big enough for the tools", () => {
  // 800px tall tablet, stacked: neither pane below MIN_PANE_PX.
  assert.equal(dividerRatio(10, 800), MIN_PANE_PX / 800);
  assert.equal(dividerRatio(790, 800), 1 - MIN_PANE_PX / 800);
  assert.equal(dividerRatio(400, 800), 0.5);
  // A wide row still allows 20/80.
  assert.equal(dividerRatio(0, 2000), 0.2);
  // A tiny row can't honour the minimum twice: it stays near the middle.
  assert.ok(Math.abs(dividerRatio(0, 300) - 0.45) < 1e-9);
  assert.equal(dividerRatio(5, 0), 0.5);
});

test("the layout can be picked when opening a split and switched later", () => {
  const s = useWhiteboard.getState();
  const a = s.createBoard("Stack A", null);
  const b = s.createBoard("Stack B", null);
  useWhiteboard.getState().setSplitPair(a, b, "stacked");
  let st = useWhiteboard.getState();
  assert.equal(st.splitOrientation, "stacked");
  assert.equal(st.activeBoardId, a, "the first (top) one is editable");
  assert.equal(st.splitBoardId, b);
  // Switching the layout keeps the same documents in the same slots.
  useWhiteboard.getState().setSplitOrientation("side");
  st = useWhiteboard.getState();
  assert.equal(st.splitOrientation, "side");
  assert.equal(st.activeBoardId, a);
  assert.equal(st.splitSide, "left");
  // Swapping keeps the layout.
  useWhiteboard.getState().setSplitOrientation("stacked");
  useWhiteboard.getState().swapSplit();
  assert.equal(useWhiteboard.getState().splitOrientation, "stacked");
  assert.equal(useWhiteboard.getState().splitSide, "right");
  useWhiteboard.getState().setSplitBoard(null);
});

test("the layout survives a save and reload; old saves open side by side", () => {
  const base = {
    version: 2,
    boards: [],
    activeBoardId: null,
    activeFolderId: null,
    folders: [],
  } as unknown as Parameters<typeof migrateState>[0];
  assert.equal(migrateState({ ...base, splitOrientation: "stacked" }).splitOrientation, "stacked");
  assert.equal(migrateState(base).splitOrientation, "side");
  assert.equal(migrateState({ ...base, splitOrientation: "diagonal" as never }).splitOrientation, "side");
});

console.log(`\n  ${passed} passed, ${failed} failed\n`);
if (failed > 0) process.exit(1);
