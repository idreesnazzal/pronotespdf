/**
 * Automated Verification Suite:
 * Top-Right Tools Panel, Sidebar Sorting Engine & Pro Selection Actions
 */

import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import ts from "typescript";
import { sortItems } from "../src/lib/whiteboard/sort";
import { useWhiteboard } from "../src/store/whiteboard";
import type {
  StrokeElement,
  TextElement,
  StickyElement,
  RectangleElement,
  EllipseElement,
  CloudElement,
  ImageElement,
  ConnectionElement,
} from "../src/lib/whiteboard/types";

console.log("=== Testing Top-Right Tools Panel & Sidebar Sorting Engine ===");

function resetStore() {
  useWhiteboard.setState({
    boards: [],
    folders: [],
    activeBoardId: null,
    selectedIds: [],
    editingId: null,
    sidebarSortBy: "updated",
    sidebarSortOrder: "desc",
    history: { past: [], future: [] },
  });
}

// ---------------------------------------------------------------------------
// 1. Sidebar Sorting Engine Tests (sortItems)
// ---------------------------------------------------------------------------
console.log("\n── 1. Sidebar Sorting Engine (sortItems) ──");

{
  const items = [
    { name: "Note 10", createdAt: 1000, updatedAt: 5000 },
    { name: "Note 2", createdAt: 3000, updatedAt: 2000 },
    { name: "Note 1", createdAt: 2000, updatedAt: 8000 },
    { name: "Folder B", createdAt: 4000 }, // no updatedAt
  ];

  // Sort by Updated (desc - newest first)
  const byUpdatedDesc = sortItems(items, "updated", "desc");
  assert.equal(byUpdatedDesc[0].name, "Note 1", "Note 1 has latest updatedAt (8000)");
  assert.equal(byUpdatedDesc[1].name, "Note 10", "Note 10 has updatedAt 5000");
  assert.equal(byUpdatedDesc[2].name, "Folder B", "Folder B falls back to createdAt 4000");
  assert.equal(byUpdatedDesc[3].name, "Note 2", "Note 2 has updatedAt 2000");
  console.log("  ✓ sortItems: by 'updated' desc correctly uses updatedAt fallback to createdAt");

  // Sort by Updated (asc - oldest first)
  const byUpdatedAsc = sortItems(items, "updated", "asc");
  assert.equal(byUpdatedAsc[0].name, "Note 2", "Note 2 oldest (2000)");
  assert.equal(byUpdatedAsc[3].name, "Note 1", "Note 1 newest (8000)");
  console.log("  ✓ sortItems: by 'updated' asc correctly orders oldest first");

  // Sort by Created (desc - newest first)
  const byCreatedDesc = sortItems(items, "created", "desc");
  assert.equal(byCreatedDesc[0].name, "Folder B", "Folder B created newest (4000)");
  assert.equal(byCreatedDesc[1].name, "Note 2", "Note 2 created at 3000");
  assert.equal(byCreatedDesc[2].name, "Note 1", "Note 1 created at 2000");
  assert.equal(byCreatedDesc[3].name, "Note 10", "Note 10 created at 1000");
  console.log("  ✓ sortItems: by 'created' desc correctly orders newest createdAt first");

  // Sort by Created (asc - oldest first)
  const byCreatedAsc = sortItems(items, "created", "asc");
  assert.equal(byCreatedAsc[0].name, "Note 10", "Note 10 created oldest (1000)");
  assert.equal(byCreatedAsc[3].name, "Folder B", "Folder B created newest (4000)");
  console.log("  ✓ sortItems: by 'created' asc correctly orders oldest createdAt first");

  // Sort by Natural Name (A-Z)
  const byNameAsc = sortItems(items, "name", "asc");
  assert.equal(byNameAsc[0].name, "Folder B");
  assert.equal(byNameAsc[1].name, "Note 1");
  assert.equal(byNameAsc[2].name, "Note 2");
  assert.equal(byNameAsc[3].name, "Note 10", "Natural sort puts Note 2 before Note 10");
  console.log("  ✓ sortItems: by 'name' asc natural numeric sort (Note 2 before Note 10)");

  // Sort by Natural Name (Z-A)
  const byNameDesc = sortItems(items, "name", "desc");
  assert.equal(byNameDesc[0].name, "Note 10");
  assert.equal(byNameDesc[3].name, "Folder B");
  console.log("  ✓ sortItems: by 'name' desc correctly reverses natural alphabetical order");
}

// ---------------------------------------------------------------------------
// 2. Store Sort State Mutations
// ---------------------------------------------------------------------------
console.log("\n── 2. Store Sorting Actions (setSidebarSort) ──");

{
  resetStore();
  const S = useWhiteboard.getState();

  assert.equal(S.sidebarSortBy, "updated");
  assert.equal(S.sidebarSortOrder, "desc");

  // Setting same field toggles direction
  S.setSidebarSort("updated");
  assert.equal(useWhiteboard.getState().sidebarSortOrder, "asc");

  S.setSidebarSort("updated");
  assert.equal(useWhiteboard.getState().sidebarSortOrder, "desc");

  // Switching field to "name" defaults to "asc"
  S.setSidebarSort("name");
  assert.equal(useWhiteboard.getState().sidebarSortBy, "name");
  assert.equal(useWhiteboard.getState().sidebarSortOrder, "asc");

  // Explicit order override
  S.setSidebarSort("created", "desc");
  assert.equal(useWhiteboard.getState().sidebarSortBy, "created");
  assert.equal(useWhiteboard.getState().sidebarSortOrder, "desc");

  console.log("  ✓ setSidebarSort updates sort field, toggles direction, and respects explicit order");
}

// ---------------------------------------------------------------------------
// 3. Pro Canvas Selection: selectByType
// ---------------------------------------------------------------------------
console.log("\n── 3. Pro Canvas Selection (selectByType) ──");

{
  resetStore();
  const S = useWhiteboard.getState();
  S.createBoard("Test Selection Board", null);
  const activeBoard = useWhiteboard.getState().boards[0];

  const strokeEl: StrokeElement = {
    id: "str-1",
    type: "stroke",
    x: 0,
    y: 0,
    points: [[10, 10, 0.5]],
    color: "#000",
    strokeWidth: 2,
    strokeStyle: "ballpoint",
    opacity: 1,
    locked: false,
    rotation: 0,
    createdAt: 1,
    updatedAt: 1,
  };

  const lockedStrokeEl: StrokeElement = {
    id: "str-2",
    type: "stroke",
    x: 0,
    y: 0,
    points: [[20, 20, 0.5]],
    color: "#000",
    strokeWidth: 2,
    strokeStyle: "ballpoint",
    opacity: 1,
    locked: true,
    rotation: 0,
    createdAt: 1,
    updatedAt: 1,
  };

  const textEl: TextElement = {
    id: "txt-1",
    type: "text",
    x: 100,
    y: 100,
    width: 150,
    height: 40,
    text: "Hello World",
    fontSize: 16,
    fontFamily: "sans",
    fontWeight: 400,
    align: "left",
    color: "#000",
    opacity: 1,
    locked: false,
    rotation: 0,
    createdAt: 1,
    updatedAt: 1,
  };

  const stickyEl: StickyElement = {
    id: "stk-1",
    type: "sticky",
    x: 200,
    y: 200,
    width: 120,
    height: 120,
    text: "Sticky Idea",
    fontSize: 14,
    color: "yellow",
    align: "center",
    opacity: 1,
    locked: false,
    rotation: 0,
    createdAt: 1,
    updatedAt: 1,
  };

  const rectEl: RectangleElement = {
    id: "shp-1",
    type: "rectangle",
    x: 300,
    y: 300,
    width: 100,
    height: 80,
    strokeColor: "#000",
    strokeWidth: 2,
    fillColor: "transparent",
    fillStyle: "solid",
    dashStyle: "solid",
    opacity: 1,
    locked: false,
    rotation: 0,
    createdAt: 1,
    updatedAt: 1,
  };

  const ellipseEl: EllipseElement = {
    id: "shp-2",
    type: "ellipse",
    x: 450,
    y: 300,
    width: 80,
    height: 80,
    strokeColor: "#000",
    strokeWidth: 2,
    fillColor: "transparent",
    fillStyle: "solid",
    dashStyle: "solid",
    opacity: 1,
    locked: false,
    rotation: 0,
    createdAt: 1,
    updatedAt: 1,
  };

  const cloudEl: CloudElement = {
    id: "shp-3",
    type: "cloud",
    x: 550,
    y: 300,
    width: 90,
    height: 60,
    strokeColor: "#000",
    strokeWidth: 2,
    fillColor: "transparent",
    fillStyle: "solid",
    dashStyle: "solid",
    opacity: 1,
    locked: false,
    rotation: 0,
    createdAt: 1,
    updatedAt: 1,
  };

  const imgEl: ImageElement = {
    id: "img-1",
    type: "image",
    x: 600,
    y: 200,
    width: 200,
    height: 150,
    naturalWidth: 200,
    naturalHeight: 150,
    src: "data:image/png;base64,abc",
    opacity: 1,
    locked: false,
    rotation: 0,
    createdAt: 1,
    updatedAt: 1,
  };

  const connEl: ConnectionElement = {
    id: "con-1",
    type: "connection",
    x: 0,
    y: 0,
    source: { elementId: "shp-1", anchor: "right", boardId: activeBoard.id },
    target: { elementId: "shp-2", anchor: "left", boardId: activeBoard.id },
    linkType: "relates",
    routing: "curved",
    dashStyle: "solid",
    startArrowhead: "none",
    endArrowhead: "arrow",
    strokeWidth: 2,
    opacity: 1,
    locked: false,
    rotation: 0,
    createdAt: 1,
    updatedAt: 1,
  };

  S.addElement(strokeEl);
  S.addElement(lockedStrokeEl);
  S.addElement(textEl);
  S.addElement(stickyEl);
  S.addElement(rectEl);
  S.addElement(ellipseEl);
  S.addElement(cloudEl);
  S.addElement(imgEl);
  S.addElement(connEl);

  // 3.1 Select by Stroke (should select str-1, skip locked str-2)
  useWhiteboard.getState().selectByType("stroke");
  const selectedStrokes = useWhiteboard.getState().selectedIds;
  assert.deepEqual(selectedStrokes, ["str-1"], "Selects only unlocked stroke");
  console.log("  ✓ selectByType('stroke'): selects unlocked ink strokes, ignores locked");

  // 3.2 Select by Text
  useWhiteboard.getState().selectByType("text");
  assert.deepEqual(useWhiteboard.getState().selectedIds, ["txt-1"]);
  console.log("  ✓ selectByType('text'): selects text cards");

  // 3.3 Select by Sticky
  useWhiteboard.getState().selectByType("sticky");
  assert.deepEqual(useWhiteboard.getState().selectedIds, ["stk-1"]);
  console.log("  ✓ selectByType('sticky'): selects sticky notes");

  // 3.4 Select by Shape (rectangle, ellipse, cloud)
  useWhiteboard.getState().selectByType("shape");
  assert.deepEqual(useWhiteboard.getState().selectedIds.sort(), ["shp-1", "shp-2", "shp-3"].sort());
  console.log("  ✓ selectByType('shape'): selects all shape elements (rectangles, ellipses, clouds)");

  // 3.5 Select by Image
  useWhiteboard.getState().selectByType("image");
  assert.deepEqual(useWhiteboard.getState().selectedIds, ["img-1"]);
  console.log("  ✓ selectByType('image'): selects images");

  // 3.6 Select by Connection
  useWhiteboard.getState().selectByType("connection");
  assert.deepEqual(useWhiteboard.getState().selectedIds, ["con-1"]);
  console.log("  ✓ selectByType('connection'): selects connection arrows");

  // 3.7 Invert Selection
  // When 'img-1' is selected, invertSelection() should select all other unlocked elements
  useWhiteboard.getState().selectByType("image"); // img-1 selected
  useWhiteboard.getState().invertSelection();
  const inverted = useWhiteboard.getState().selectedIds.sort();
  const expectedInverted = ["str-1", "txt-1", "stk-1", "shp-1", "shp-2", "shp-3", "con-1"].sort();
  assert.deepEqual(inverted, expectedInverted, "Inverts selection to all other unlocked elements");
  console.log("  ✓ invertSelection(): inverts selection to all unlocked unselected elements");

  // Invert again should return back to ['img-1']
  useWhiteboard.getState().invertSelection();
  assert.deepEqual(useWhiteboard.getState().selectedIds, ["img-1"]);
  console.log("  ✓ invertSelection(): involution property holds (inverting twice restores selection)");
}

// ---------------------------------------------------------------------------
// 4. Batch Operations (Move, Star, Delete)
// ---------------------------------------------------------------------------
console.log("\n── 4. Batch Sidebar Operations (Move, Star, Delete) ──");

{
  resetStore();
  const S = useWhiteboard.getState();

  S.createFolder("Target Folder", null);
  const targetFolder = useWhiteboard.getState().folders[0];

  S.createBoard("Board Alpha", null);
  S.createBoard("Board Beta", null);
  S.createBoard("Board Gamma", null);
  const [bAlpha, bBeta, bGamma] = useWhiteboard.getState().boards;

  // 4.1 Batch Move
  useWhiteboard.getState().batchMoveBoards([bAlpha.id, bBeta.id], targetFolder.id);
  const boardsAfterMove = useWhiteboard.getState().boards;
  assert.equal(boardsAfterMove.find((b) => b.id === bAlpha.id)?.folderId, targetFolder.id);
  assert.equal(boardsAfterMove.find((b) => b.id === bBeta.id)?.folderId, targetFolder.id);
  assert.equal(boardsAfterMove.find((b) => b.id === bGamma.id)?.folderId, null);
  console.log("  ✓ batchMoveBoards: moves multiple boards into target folder atomically");

  // 4.2 Batch Star
  useWhiteboard.getState().batchStarBoards([bAlpha.id, bGamma.id], true);
  const boardsAfterStar = useWhiteboard.getState().boards;
  assert.equal(boardsAfterStar.find((b) => b.id === bAlpha.id)?.starred, true);
  assert.equal(Boolean(boardsAfterStar.find((b) => b.id === bBeta.id)?.starred), false);
  assert.equal(boardsAfterStar.find((b) => b.id === bGamma.id)?.starred, true);

  useWhiteboard.getState().batchStarBoards([bAlpha.id, bGamma.id], false);
  const boardsAfterUnstar = useWhiteboard.getState().boards;
  assert.equal(boardsAfterUnstar.find((b) => b.id === bAlpha.id)?.starred, false);
  assert.equal(boardsAfterUnstar.find((b) => b.id === bGamma.id)?.starred, false);
  console.log("  ✓ batchStarBoards: stars and unstars multiple boards in a single action");

  // 4.3 Batch Delete
  // Add cross-board connection between Alpha and Gamma
  const conn: ConnectionElement = {
    id: "conn-cross",
    type: "connection",
    x: 0,
    y: 0,
    source: { elementId: "x", anchor: "top", boardId: bAlpha.id },
    target: { elementId: "y", anchor: "bottom", boardId: bGamma.id },
    linkType: "relates",
    routing: "straight",
    strokeWidth: 2,
    dashStyle: "solid",
    startArrowhead: "none",
    endArrowhead: "arrow",
    opacity: 1,
    rotation: 0,
    createdAt: 1,
    updatedAt: 1,
  };
  useWhiteboard.getState().addElement(conn);

  // Batch delete Alpha and Beta
  useWhiteboard.getState().batchDeleteBoards([bAlpha.id, bBeta.id]);
  const boardsAfterDelete = useWhiteboard.getState().boards;
  assert.equal(boardsAfterDelete.length, 1);
  assert.equal(boardsAfterDelete[0].id, bGamma.id);
  assert.equal(useWhiteboard.getState().activeBoardId, bGamma.id, "Selects remaining board as active");

  // Connection should have been cleaned from bGamma because source was deleted
  const gammaElements = boardsAfterDelete[0].elements;
  assert.equal(gammaElements.some((el) => el.id === "conn-cross"), false, "Prunes dangling cross-board connections");
  console.log("  ✓ batchDeleteBoards: deletes boards, cleans dangling connections, and maintains active board");
}

// ---------------------------------------------------------------------------
// 5. Sidebar Performance & Re-render Prevention Guardrails
// ---------------------------------------------------------------------------
console.log("\n── 5. Sidebar Performance & Re-render Guardrails ──");

{
  const sidebarPath = path.resolve(__dirname, "../../src/components/whiteboard/Sidebar.tsx");
  const sidebarSrc = fs.readFileSync(sidebarPath, "utf-8");

  // Rule 1: BoardItem must be wrapped in React.memo(BoardItemImpl, boardItemPropsEqual)
  assert.ok(
    sidebarSrc.includes("React.memo(BoardItemImpl, boardItemPropsEqual)"),
    "BoardItem must be wrapped in React.memo with boardItemPropsEqual"
  );
  console.log("  ✓ BoardItem is wrapped in React.memo(BoardItemImpl, boardItemPropsEqual)");

  // Rule 1b: boardItemPropsEqual must check multiSelectMode and isSelected
  assert.ok(
    sidebarSrc.includes("a.multiSelectMode !== b.multiSelectMode") &&
    sidebarSrc.includes("a.isSelected !== b.isSelected"),
    "boardItemPropsEqual must compare multiSelectMode and isSelected"
  );
  console.log("  ✓ boardItemPropsEqual includes multiSelectMode and isSelected checks");

  // Rule 2: Sidebar must listen to boardListKey(s.boards) and NEVER s.boards directly
  assert.ok(
    sidebarSrc.includes("useWhiteboard((s) => boardListKey(s.boards))"),
    "Sidebar must subscribe to boardListKey(s.boards)"
  );
  assert.ok(
    !sidebarSrc.includes("const boards = useWhiteboard((s) => s.boards)"),
    "Sidebar must NEVER subscribe to s.boards directly"
  );
  console.log("  ✓ Sidebar subscribes via boardListKey(s.boards), avoiding s.boards direct subscription");

  // Rule 3: boardListKey must use sorted order of IDs and NEVER raw updatedAt timestamps
  assert.ok(
    sidebarSrc.includes(".sort((a, b) => (b.updatedAt || b.createdAt || 0) - (a.updatedAt || a.createdAt || 0))"),
    "boardListKey sorts boards to include ID order"
  );
  assert.ok(
    sidebarSrc.includes(".map((b) => b.id)"),
    "boardListKey extracts board IDs rather than timestamps"
  );
  assert.ok(
    !sidebarSrc.includes("b.updatedAt.toString()") && !sidebarSrc.includes("${b.updatedAt}"),
    "boardListKey does not serialize raw updatedAt timestamps"
  );
  console.log("  ✓ boardListKey incorporates sorted ID sequence, omitting raw updatedAt timestamps");

  // Rule 4: Functional validation of boardListKey stability & boardItemPropsEqual
  // Extract and evaluate the actual functions from Sidebar.tsx
  const keyFnMatch = sidebarSrc.match(/export function boardListKey\([^)]*\): string \{[\s\S]*?\n\}/);
  assert.ok(keyFnMatch, "boardListKey function definition found in Sidebar.tsx");
  const keyJs = ts.transpileModule(keyFnMatch[0], { compilerOptions: { module: ts.ModuleKind.CommonJS } }).outputText;
  const execBoardListKey = new Function("boards", "const exports = {}; " + keyJs + "; return exports.boardListKey(boards);");

  const equalFnMatch = sidebarSrc.match(/export function boardItemPropsEqual\([^)]*\): boolean \{[\s\S]*?\n\}/);
  assert.ok(equalFnMatch, "boardItemPropsEqual function definition found in Sidebar.tsx");
  const equalJs = ts.transpileModule(equalFnMatch[0], { compilerOptions: { module: ts.ModuleKind.CommonJS } }).outputText;
  const execBoardItemPropsEqual = new Function("a", "b", "const exports = {}; " + equalJs + "; return exports.boardItemPropsEqual(a, b);");

  // Test 5.1: Inking in active board preserves boardListKey identically across strokes
  const boardA = { id: "nb-A", name: "Notebook A", folderId: null, starred: false, color: "#3b82f6", kind: "notebook" as const, tags: [], elements: [], createdAt: 1000, updatedAt: 5000 };
  const boardB = { id: "nb-B", name: "Notebook B", folderId: null, starred: false, color: "#10b981", kind: "notebook" as const, tags: [], elements: [], createdAt: 1000, updatedAt: 2000 };
  const initialKey = execBoardListKey([boardA, boardB]);

  // Simulate 10 consecutive pen strokes drawn on active notebook A
  for (let s = 1; s <= 10; s++) {
    const strokedA = {
      ...boardA,
      updatedAt: 5000 + s * 100,
      elements: [...boardA.elements, { id: `stroke-${s}`, type: "stroke" }]
    };
    const keyAfterStroke = execBoardListKey([strokedA, boardB]);
    assert.equal(keyAfterStroke, initialKey, `boardListKey must remain identical after stroke ${s} (prevents 240ms pen-lift freeze)`);
  }
  console.log("  ✓ boardListKey remains strictly byte-identical across 10 inking strokes on active notebook");

  // Test 5.2: Notebook ranking re-order correctly triggers key change
  const bumpedB = { ...boardB, updatedAt: 9000 };
  const keyAfterOrderChange = execBoardListKey([boardA, bumpedB]);
  assert.notEqual(keyAfterOrderChange, initialKey, "boardListKey must update when sorted order of notebook IDs changes");
  assert.ok(keyAfterOrderChange.startsWith("nb-B,nb-A"), "Updated notebook B moves to the front of sorted IDs sequence");
  console.log("  ✓ boardListKey detects ranking re-order and updates sorted ID sequence");

  // Test 5.3: boardItemPropsEqual memoization semantics
  const baseItemProps = {
    board: boardA,
    isActive: true,
    depth: 0,
    multiSelectMode: false,
    isSelected: false,
    onClick: () => {},
  };

  // Adding strokes or bumping updatedAt does NOT invalidate BoardItem memoization
  const strokedItemProps = {
    ...baseItemProps,
    board: { ...boardA, updatedAt: 6000, elements: [{ id: "str-1" }] }
  };
  assert.equal(execBoardItemPropsEqual(baseItemProps, strokedItemProps), true, "boardItemPropsEqual must return true on stroke updates");
  console.log("  ✓ boardItemPropsEqual returns true when only elements or updatedAt change (no row re-render)");

  // Visual/selection props MUST invalidate BoardItem memoization
  assert.equal(execBoardItemPropsEqual(baseItemProps, { ...baseItemProps, isSelected: true }), false, "Invalidated on isSelected");
  assert.equal(execBoardItemPropsEqual(baseItemProps, { ...baseItemProps, multiSelectMode: true }), false, "Invalidated on multiSelectMode");
  assert.equal(execBoardItemPropsEqual(baseItemProps, { ...baseItemProps, isActive: false }), false, "Invalidated on isActive");
  assert.equal(execBoardItemPropsEqual(baseItemProps, { ...baseItemProps, depth: 1 }), false, "Invalidated on depth");
  assert.equal(execBoardItemPropsEqual(baseItemProps, { ...baseItemProps, board: { ...boardA, name: "Renamed" } }), false, "Invalidated on name");
  assert.equal(execBoardItemPropsEqual(baseItemProps, { ...baseItemProps, board: { ...boardA, starred: true } }), false, "Invalidated on starred");
  assert.equal(execBoardItemPropsEqual(baseItemProps, { ...baseItemProps, board: { ...boardA, color: "#ef4444" } }), false, "Invalidated on color");
  assert.equal(execBoardItemPropsEqual(baseItemProps, { ...baseItemProps, board: { ...boardA, folderId: "fld-1" } }), false, "Invalidated on folderId");
  assert.equal(execBoardItemPropsEqual(baseItemProps, { ...baseItemProps, board: { ...boardA, tags: ["science"] } }), false, "Invalidated on tags");
  console.log("  ✓ boardItemPropsEqual accurately detects all selection, multi-select, and metadata changes");
}

console.log("\n========================================================");
console.log("ALL TOP-RIGHT TOOLS & SIDEBAR SORTING TESTS PASSED (100%)");
console.log("========================================================");

