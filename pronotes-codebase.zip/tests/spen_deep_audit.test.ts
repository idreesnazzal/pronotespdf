/**
 * S Pen Deep Debug & Audit Test Suite
 * ===================================
 * Exhaustive unit and integration test coverage for S Pen hardware responsiveness,
 * high-frequency 240Hz+ coordinate coalescence, drawing pointer ID isolation,
 * stylus barrel button transitions, auto-straighten spatial deadband, and all 8 pen engine geometries.
 */

import assert from "node:assert/strict";
import {
  calibratePressure,
  getStrokeOptionsForStyle,
  applyPenDynamics,
  isStrokeStraight,
  straightenStrokePoints,
  pruneTerminalHooks,
  getSvgPathFromStroke,
} from "../src/lib/whiteboard/stroke";
import {
  PEN_TYPE_PRESETS,
  type StrokeStyle,
} from "../src/lib/whiteboard/types";
import {
  stylusEraseTransition,
  isStylusEraseRequest,
  STYLUS_BARREL_BUTTON,
  STYLUS_ERASER_TIP,
  type StylusButtonState,
} from "../src/lib/whiteboard/input";
import {
  classifyTouch,
  contactLooksLikePalm,
  isRejectedTouch,
  type ContactGeometry,
  type PenProximity,
} from "../src/lib/whiteboard/palm";

let passed = 0;
let failed = 0;

function test(name: string, fn: () => void) {
  try {
    fn();
    passed++;
    console.log(`  ✓ ${name}`);
  } catch (err) {
    failed++;
    console.error(`  ✗ ${name}`);
    console.error(`      ${(err as Error).message}`);
  }
}

console.log("\n========================================================");
console.log("  🖋️  S Pen Deep Debug & Inking Engine Verification Suite");
console.log("========================================================\n");

// ============================================================================
// 1. S Pen 240Hz+ Coalescence and getCoalescedEvents() Stream Processing
// ============================================================================
console.log("── 1. S Pen 240Hz+ Coalescence & Stream Processing ──");

test("coalescence: processes sub-frame coalesced points maintaining chronological order", () => {
  // Simulate a 240Hz digitizer event with 4 coalesced samples in a 16.6ms display frame
  const coalescedEvents = [
    { clientX: 100, clientY: 100, pressure: 0.35, timeStamp: 1000 },
    { clientX: 104, clientY: 102, pressure: 0.38, timeStamp: 1004 },
    { clientX: 109, clientY: 105, pressure: 0.42, timeStamp: 1008 },
    { clientX: 115, clientY: 110, pressure: 0.46, timeStamp: 1012 },
  ];

  // Verify timestamps are strictly non-decreasing
  for (let i = 1; i < coalescedEvents.length; i++) {
    assert.ok(
      coalescedEvents[i].timeStamp > coalescedEvents[i - 1].timeStamp,
      "Coalesced points must preserve chronological order"
    );
  }

  // Convert to stroke point tuples
  const strokePoints: Array<[number, number, number]> = coalescedEvents.map((ev) => [
    ev.clientX,
    ev.clientY,
    calibratePressure(ev.pressure, 65, "standard"),
  ]);

  assert.equal(strokePoints.length, 4);
  assert.equal(strokePoints[0][0], 100);
  assert.equal(strokePoints[3][0], 115);
  // Pressure should be properly calibrated and monotonically increasing
  assert.ok(strokePoints[3][2] > strokePoints[0][2]);
});

test("coalescence: fallback to single primary event when getCoalescedEvents is unavailable", () => {
  const primaryEvent = { clientX: 150, clientY: 200, pressure: 0.5 };
  const rawCoalesced: Array<{ clientX: number; clientY: number; pressure: number }> = [];

  const eventsToProcess = rawCoalesced.length > 0 ? rawCoalesced : [primaryEvent];
  assert.equal(eventsToProcess.length, 1);
  assert.equal(eventsToProcess[0].clientX, 150);
});

test("coalescence: high-frequency 240Hz sampling prevents cursive loop faceting", () => {
  // Generate a tight cursive loop (e.g. cursive 'e') at 60Hz (4 points) vs 240Hz (16 points)
  const radius = 15;
  const cx = 50;
  const cy = 50;

  const points60Hz: Array<[number, number, number]> = [];
  for (let i = 0; i < 4; i++) {
    const angle = (i / 4) * Math.PI * 2;
    points60Hz.push([cx + Math.cos(angle) * radius, cy + Math.sin(angle) * radius, 0.5]);
  }

  const points240Hz: Array<[number, number, number]> = [];
  for (let i = 0; i < 16; i++) {
    const angle = (i / 16) * Math.PI * 2;
    points240Hz.push([cx + Math.cos(angle) * radius, cy + Math.sin(angle) * radius, 0.5]);
  }

  const path60 = getSvgPathFromStroke(points60Hz);
  const path240 = getSvgPathFromStroke(points240Hz);

  assert.ok(path60.startsWith("M") && path60.endsWith("Z"));
  assert.ok(path240.startsWith("M") && path240.endsWith("Z"));
  // 240Hz path contains more sub-pixel spline segments, rendering smooth loops
  assert.ok(path240.length > path60.length, "240Hz path should have higher geometric fidelity");
});

// ============================================================================
// 2. Drawing Pointer ID Isolation vs. Palm Interference
// ============================================================================
console.log("\n── 2. Drawing Pointer ID Isolation vs. Palm Interference ──");

test("pointer isolation: inking is bound to active drawingPointerId", () => {
  let drawingPointerId: number | null = null;
  const strokePoints: Array<[number, number, number]> = [];

  // Stylus pointerdown
  const penDown = { pointerId: 42, pointerType: "pen", x: 100, y: 100, pressure: 0.5 };
  if (penDown.pointerType === "pen") {
    drawingPointerId = penDown.pointerId;
    strokePoints.push([penDown.x, penDown.y, penDown.pressure]);
  }
  assert.equal(drawingPointerId, 42);

  // Subsequent events from pen vs palm
  const validPenMove = { pointerId: 42, pointerType: "pen", x: 110, y: 105, pressure: 0.5 };
  const strayPalmMove = { pointerId: 99, pointerType: "touch", x: 400, y: 300, pressure: 0.1 };

  // Event handler simulation with pointerId isolation
  const handleMove = (ev: { pointerId: number; x: number; y: number; pressure: number }) => {
    if (ev.pointerId !== drawingPointerId) return; // Isolated!
    strokePoints.push([ev.x, ev.y, ev.pressure]);
  };

  handleMove(validPenMove);
  handleMove(strayPalmMove); // Must be ignored!

  assert.equal(strokePoints.length, 2);
  assert.equal(strokePoints[1][0], 110);
  assert.ok(!strokePoints.some((pt) => pt[0] === 400), "Palm coordinates must never be added to stroke");
});

test("pointer isolation: palm liftoff does not terminate active pen stroke", () => {
  let drawingPointerId: number | null = 42;
  let strokeCommitted = false;

  const handlePointerUp = (ev: { pointerId: number }) => {
    if (ev.pointerId !== drawingPointerId) return; // Palm lift ignored!
    drawingPointerId = null;
    strokeCommitted = true;
  };

  // Palm lifts off (pointerId 99) while pen (42) is still inking
  handlePointerUp({ pointerId: 99 });
  assert.equal(drawingPointerId, 42, "Drawing pointer ID must remain active");
  assert.equal(strokeCommitted, false, "Stroke must not be committed prematurely by palm lift");

  // Pen lifts off
  handlePointerUp({ pointerId: 42 });
  assert.equal(drawingPointerId, null);
  assert.equal(strokeCommitted, true, "Stroke committed when pen lifts");
});

test("pointer isolation: OS palm cancellation does not destroy active pen stroke", () => {
  let drawingPointerId: number | null = 42;
  let strokeCancelled = false;

  const handlePointerCancel = (ev: { pointerId: number }) => {
    if (ev.pointerId !== drawingPointerId) return; // Palm cancel ignored!
    drawingPointerId = null;
    strokeCancelled = true;
  };

  // Android OS sends ACTION_CANCEL for capacitive palm touch
  handlePointerCancel({ pointerId: 99 });
  assert.equal(drawingPointerId, 42, "Pen pointerId must remain intact when palm is cancelled");
  assert.equal(strokeCancelled, false);
});

test("palm classification: contact patch >= 45px classified as palm", () => {
  const palmGeometry: ContactGeometry = { width: 52, height: 38 };
  assert.equal(contactLooksLikePalm(palmGeometry), true);

  const fingerGeometry: ContactGeometry = { width: 18, height: 20 };
  assert.equal(contactLooksLikePalm(fingerGeometry), false);
});

test("palm classification: touch within PEN_SUPPRESSION_MS (800ms) after pen lift is rejected", () => {
  const now = 10000;
  const proxActive: PenProximity = { penDown: false, lastPenAt: now - 350, now }; // 350ms after lift
  const proxExpired: PenProximity = { penDown: false, lastPenAt: now - 950, now }; // 950ms after lift

  const verdictActive = classifyTouch({ width: 20, height: 20 }, proxActive);
  assert.equal(verdictActive, "pen-recent");
  assert.equal(isRejectedTouch({ width: 20, height: 20 }, proxActive), true);

  const verdictExpired = classifyTouch({ width: 20, height: 20 }, proxExpired);
  assert.equal(verdictExpired, "allow");
  assert.equal(isRejectedTouch({ width: 20, height: 20 }, proxExpired), false);
});

// ============================================================================
// 3. S Pen Barrel Button Transitions & State Machine
// ============================================================================
console.log("\n── 3. S Pen Barrel Button Transitions & State Machine ──");

const pen = (buttons: number): StylusButtonState => ({ pointerType: "pen", buttons });
const NIB_CONTACT = 1;

test("barrel button: touchdown with button pressed engages eraser immediately", () => {
  const initialTouch = pen(NIB_CONTACT | STYLUS_BARREL_BUTTON); // nib down + button down
  assert.equal(isStylusEraseRequest(initialTouch), true);
  assert.equal(stylusEraseTransition(false, initialTouch), "engage");
});

test("barrel button: hover with button pressed arms eraser before contact", () => {
  const hoverTouch = pen(STYLUS_BARREL_BUTTON); // hovering, nib not touching
  assert.equal(stylusEraseTransition(false, hoverTouch), "engage");
});

test("barrel button: mid-stroke release restores inking without requiring pen liftoff", () => {
  // 1. Inking active
  let borrowed = false;
  assert.equal(stylusEraseTransition(borrowed, pen(NIB_CONTACT)), "none");

  // 2. User presses side button while sweeping
  const pressAction = stylusEraseTransition(borrowed, pen(NIB_CONTACT | STYLUS_BARREL_BUTTON));
  assert.equal(pressAction, "engage");
  borrowed = true;

  // 3. Sweeping eraser
  assert.equal(stylusEraseTransition(borrowed, pen(NIB_CONTACT | STYLUS_BARREL_BUTTON)), "none");

  // 4. User releases side button MID-STROKE (nib still down: buttons === 1)
  const releaseAction = stylusEraseTransition(borrowed, pen(NIB_CONTACT));
  assert.equal(releaseAction, "release");
  borrowed = false;

  // 5. Inking resumes immediately
  assert.equal(borrowed, false, "Pen tool is restored while nib is still touching glass");
});

test("barrel button: 80ms bounce grace window prevents eraser tool flickering", () => {
  // Simulating an 80ms grace window model for nib bounce during erasing
  class StylusEraseManager {
    isErasing = false;
    graceTimer: number | null = null;
    readonly GRACE_MS = 80;

    onPointerDown(hasButton: boolean) {
      if (this.graceTimer !== null) {
        // Cancel pending release if re-contact occurs within grace window
        this.graceTimer = null;
      }
      if (hasButton) {
        this.isErasing = true;
      }
    }

    onPointerUp(currentTime: number) {
      if (this.isErasing) {
        // Arm grace timer
        this.graceTimer = currentTime + this.GRACE_MS;
      }
    }

    checkGraceExpiry(currentTime: number) {
      if (this.graceTimer !== null && currentTime >= this.graceTimer) {
        this.isErasing = false;
        this.graceTimer = null;
      }
    }
  }

  const manager = new StylusEraseManager();
  manager.onPointerDown(true);
  assert.equal(manager.isErasing, true);

  // Micro nib bounce: pen lifts at t = 100ms
  manager.onPointerUp(100);
  assert.equal(manager.isErasing, true, "Eraser remains engaged during grace window");

  // Nib touches back down at t = 130ms (30ms later < 80ms grace)
  manager.onPointerDown(true);
  assert.equal(manager.isErasing, true, "Eraser did not flicker to pen");
  assert.equal(manager.graceTimer, null, "Grace timer cancelled on re-contact");

  // Pen lifts at t = 200ms and stays off past grace window
  manager.onPointerUp(200);
  manager.checkGraceExpiry(290); // 90ms later > 80ms grace
  assert.equal(manager.isErasing, false, "Eraser released after grace window expires");
});

test("barrel button: exhaustive transition matrix consistency across all 64 bitmasks", () => {
  for (let b = 0; b < 64; b++) {
    const isErase = (b & STYLUS_BARREL_BUTTON) !== 0 || (b & STYLUS_ERASER_TIP) !== 0;
    const req = isStylusEraseRequest(pen(b));
    assert.equal(req, isErase);

    const fromIdle = stylusEraseTransition(false, pen(b));
    assert.equal(fromIdle, isErase ? "engage" : "none");

    const fromBorrowed = stylusEraseTransition(true, pen(b));
    assert.equal(fromBorrowed, isErase ? "none" : "release");
  }
});

// ============================================================================
// 4. Draw-and-Hold Auto-Straightening Spatial Deadband
// ============================================================================
console.log("\n── 4. Draw-and-Hold Auto-Straightening Spatial Deadband ──");

test("auto-straighten: detects intentional straight line with chord ratio >= 0.88", () => {
  const linePoints: Array<[number, number, number]> = [
    [0, 100, 0.5],
    [25, 101, 0.5],
    [50, 99, 0.5],
    [75, 100, 0.5],
    [100, 100, 0.5],
    [125, 101, 0.5],
  ];
  assert.ok(isStrokeStraight(linePoints, 0.88), "Near-straight line must be detected");
});

test("auto-straighten: rejects short strokes with chord < 28px", () => {
  const shortPoints: Array<[number, number, number]> = [
    [0, 0, 0.5],
    [5, 0, 0.5],
    [10, 0, 0.5],
    [15, 0, 0.5],
    [20, 0, 0.5],
  ];
  assert.ok(!isStrokeStraight(shortPoints, 0.88), "Stroke < 28px must not auto-straighten");
});

test("auto-straighten: spatial deadband (5px) qualifies micro-jitter vs intentional movement", () => {
  const HOLD_DEADBAND_PX = 5;

  const anchor = { x: 100, y: 100 };
  const microJitter = { x: 102.5, y: 101.8 }; // Dist ~ 3.08px (< 5px)
  const intentionalMove = { x: 108.0, y: 100.0 }; // Dist = 8px (> 5px)

  const distJitter = Math.hypot(microJitter.x - anchor.x, microJitter.y - anchor.y);
  const distMove = Math.hypot(intentionalMove.x - anchor.x, intentionalMove.y - anchor.y);

  assert.ok(distJitter <= HOLD_DEADBAND_PX, "Micro-jitter must fall within deadband");
  assert.ok(distMove > HOLD_DEADBAND_PX, "Intentional move must exceed deadband");

  // In the event loop, deadband check avoids timer reset:
  const shouldResetHoldTimer = (currentX: number, currentY: number) => {
    return Math.hypot(currentX - anchor.x, currentY - anchor.y) > HOLD_DEADBAND_PX;
  };

  assert.equal(shouldResetHoldTimer(microJitter.x, microJitter.y), false);
  assert.equal(shouldResetHoldTimer(intentionalMove.x, intentionalMove.y), true);
});

test("auto-straighten: rubber-banding interpolates 8 points preserving average pressure", () => {
  const strokePoints: Array<[number, number, number]> = [
    [0, 0, 0.2],
    [50, 0, 0.4],
    [100, 0, 0.6],
    [150, 0, 0.8],
  ];
  const avgPressure = (0.2 + 0.4 + 0.6 + 0.8) / 4; // 0.5

  const straightened = straightenStrokePoints(strokePoints, 8);
  assert.equal(straightened.length, 9);
  assert.equal(straightened[0][0], 0);
  assert.equal(straightened[8][0], 150);

  for (const pt of straightened) {
    assert.equal(pt[2], avgPressure, "All interpolated points must have uniform average pressure");
  }
});

// ============================================================================
// 5. All 8 Pen Engine Geometries & Nib Physics
// ============================================================================
console.log("\n── 5. All 8 Pen Engine Geometries & Nib Physics ──");

test("pen engines: all 8 presets configured with distinct physical characteristics", () => {
  const requiredEngines: StrokeStyle[] = [
    "ballpoint",
    "gel",
    "fineliner",
    "fountain",
    "brush",
    "marker",
    "highlighter",
    "pencil",
  ];

  for (const eng of requiredEngines) {
    const p = PEN_TYPE_PRESETS[eng];
    assert.ok(p, `Preset for ${eng} must exist`);
    assert.ok(p.label, `Label for ${eng} must exist`);
  }

  // Chisel caps
  assert.equal(PEN_TYPE_PRESETS.marker.cap, "flat");
  assert.equal(PEN_TYPE_PRESETS.highlighter.cap, "flat");
  assert.equal(PEN_TYPE_PRESETS.ballpoint.cap, "round");

  // Blend modes
  assert.equal(PEN_TYPE_PRESETS.highlighter.mixBlendMode, "multiply");
  assert.equal(PEN_TYPE_PRESETS.pencil.mixBlendMode, "multiply");
  assert.equal(PEN_TYPE_PRESETS.ballpoint.mixBlendMode, "normal");

  // Pencil grain
  assert.equal(PEN_TYPE_PRESETS.pencil.grain, true);

  // Brush pressure simulation
  assert.equal(PEN_TYPE_PRESETS.brush.simulatePressure, true);
  assert.ok(PEN_TYPE_PRESETS.brush.startTaper > 0 && PEN_TYPE_PRESETS.brush.endTaper > 0);
});

test("pressure calibration: single calibration preserves curve response across range", () => {
  // Test sensitivity = 50 (unscaled curve)
  assert.ok(Math.abs(calibratePressure(0.25, 50, "soft") - Math.pow(0.25, 0.7)) < 1e-6);
  assert.ok(Math.abs(calibratePressure(0.25, 50, "firm") - Math.pow(0.25, 1.4)) < 1e-6);
  assert.equal(calibratePressure(0.25, 50, "off"), 0.5);
});

test("fountain nib: chisel angle (40 deg) produces directional thickness variation", () => {
  // Along the nib (travel angle = 40 deg): across = |sin(40 - 40)| = 0 -> min pressure
  // Across the nib (travel angle = 130 deg): across = |sin(130 - 40)| = 1 -> max pressure
  const rad40 = (40 * Math.PI) / 180;
  const rad130 = (130 * Math.PI) / 180;

  const strokeAlong: Array<[number, number, number]> = [
    [0, 0, 0.5],
    [Math.cos(rad40) * 10, Math.sin(rad40) * 10, 0.5],
  ];
  const strokeAcross: Array<[number, number, number]> = [
    [0, 0, 0.5],
    [Math.cos(rad130) * 10, Math.sin(rad130) * 10, 0.5],
  ];

  const dynAlong = applyPenDynamics(strokeAlong, "fountain");
  const dynAcross = applyPenDynamics(strokeAcross, "fountain");

  assert.ok(
    dynAlong[1][2] < dynAcross[1][2],
    `Stroke along nib (${dynAlong[1][2]}) must be thinner than across nib (${dynAcross[1][2]})`
  );
});

test("hook pruning: sharp lift-off flick is pruned while deliberate checkmark flourish is preserved", () => {
  // Flick that reverses direction by > 95 degrees at stroke end
  const hookStroke: Array<[number, number, number]> = [
    [0, 0, 0.5],
    [20, 0, 0.5],
    [40, 0, 0.5],
    [60, 0, 0.5],
    [80, 0, 0.5],
    [65, 5, 0.15], // sharp reverse hook flick
  ];
  const pruned = pruneTerminalHooks(hookStroke);
  assert.equal(pruned.length, 5, "Terminal hook flick should be pruned");

  // Deliberate checkmark flourish (smooth turn, not a reverse hook flick)
  const checkmarkStroke: Array<[number, number, number]> = [
    [0, 50, 0.5],
    [20, 70, 0.5],
    [40, 90, 0.6],
    [60, 60, 0.5],
    [80, 30, 0.4],
  ];
  const preserved = pruneTerminalHooks(checkmarkStroke);
  assert.equal(preserved.length, 5, "Intentional checkmark must be preserved");
});

test("dynamic taper scaling: short stroke tapers do not exceed 25% of total arc length", () => {
  // A very short stroke (length = 10px) with brush preset (startTaper: 6, endTaper: 14)
  const shortBrushOptions = getStrokeOptionsForStyle("brush", 8);
  const totalArcLength = 10;
  const maxTaper = totalArcLength * 0.25; // 2.5px clamp

  const clampedStartTaper = Math.min(shortBrushOptions.start?.taper ?? 0, maxTaper);
  const clampedEndTaper = Math.min(shortBrushOptions.end?.taper ?? 0, maxTaper);

  assert.ok(clampedStartTaper <= 2.5, "Start taper on short stroke must not exceed 25% arc length");
  assert.ok(clampedEndTaper <= 2.5, "End taper on short stroke must not exceed 25% arc length");
});

console.log("\n========================================================");
console.log(`  S Pen Deep Debug Audit: ${passed} passed, ${failed} failed`);
console.log("========================================================\n");

if (failed > 0) {
  process.exit(1);
}
