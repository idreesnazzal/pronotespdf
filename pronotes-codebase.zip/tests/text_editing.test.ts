/**
 * Text boxes: started-but-empty boxes are thrown away, however editing ends.
 *
 * The bug this pins: tapping with the text tool creates a box straight away so
 * you can type. Tap away without typing and the box stayed forever, invisible
 * except for a "Type thoughts..." placeholder - and they piled up, because the
 * editor only deleted an empty box when called with a flag nothing ever set.
 *
 * The fix lives in the STORE (a subscription on `editingId`), so it covers every
 * way editing can end - Done, tapping away, switching tools, turning the page,
 * switching board - including the dozen places that reset editingId directly.
 */

import assert from "node:assert/strict";

import { useWhiteboard } from "../src/store/whiteboard";
import { getBoardElements, allElements } from "../src/lib/whiteboard/notebook";
import { isAbandonedTextBox } from "../src/lib/whiteboard/textbox";
import {
  detectLineDir,
  prefixSelectedLines,
  resolveLineDir,
  setLineDirs,
  spliceFormatMarkers,
} from "../src/lib/whiteboard/textParser";
import { migrateState } from "../src/lib/whiteboard/persistence";
import type { Board, TextElement, WhiteboardElement } from "../src/lib/whiteboard/types";

let passed = 0;
let failed = 0;
function test(name: string, fn: () => void) {
  try {
    fn();
    passed++;
    console.log(`  ✓ ${name}`);
  } catch (err) {
    failed++;
    console.error(`  ✗ ${name}`);
    console.error(`      ${(err as Error).message}`);
  }
}

const S = () => useWhiteboard.getState();
const board = (id: string): Board => S().boards.find((b) => b.id === id)!;
const has = (boardId: string, elId: string) => allElements(board(boardId)).some((e) => e.id === elId);

let seq = 0;
function textBox(text = "", extra: Partial<TextElement> = {}): TextElement {
  seq++;
  return {
    id: `t${seq}_${Math.random().toString(36).slice(2, 6)}`,
    type: "text",
    x: 10 * seq,
    y: 10,
    width: 220,
    height: 48,
    rotation: 0,
    opacity: 1,
    text,
    color: "#1e293b",
    fontSize: 18,
    fontFamily: "Inter",
    fontWeight: 400,
    align: "left",
    createdAt: Date.now(),
    updatedAt: Date.now(),
    ...extra,
  } as TextElement;
}

function freshCanvas(): string {
  const id = S().createBoard(`C ${Math.random().toString(36).slice(2, 7)}`, null);
  S().setActiveBoard(id);
  return id;
}
function freshNotebook(): string {
  const id = S().createNotebook(`NB ${Math.random().toString(36).slice(2, 7)}`, null);
  S().setActiveBoard(id);
  return id;
}

/** What the canvas does on a text-tool tap: add, start editing, back to Select. */
function placeText(el: TextElement) {
  S().addElement(el, true);
  S().setEditingId(el.id);
  S().setTool("select");
}

console.log("\n── Text boxes: abandoned-box clean-up ──");

test("an empty box is removed when editing ends", () => {
  const b = freshCanvas();
  const t = textBox();
  placeText(t);
  assert.ok(has(b, t.id), "the box exists while being edited");
  S().setEditingId(null);
  assert.equal(has(b, t.id), false, "tapping away with nothing typed removes it");
});

test("placing a box does NOT remove it (Select switch right after starting the edit)", () => {
  // The canvas starts the edit and switches to Select in the same breath. If
  // that tool switch ended editing, every new box would vanish immediately.
  const b = freshCanvas();
  const t = textBox();
  placeText(t);
  assert.equal(S().editingId, t.id);
  assert.ok(has(b, t.id));
  S().setEditingId(null);
});

test("a box with text is kept", () => {
  const b = freshCanvas();
  const t = textBox();
  placeText(t);
  S().updateElement(t.id, { text: "hello" } as Partial<TextElement>);
  S().setEditingId(null);
  assert.ok(has(b, t.id));
});

test("whitespace-only counts as empty", () => {
  const b = freshCanvas();
  const t = textBox();
  placeText(t);
  S().updateElement(t.id, { text: "  \n\t " } as Partial<TextElement>);
  S().setEditingId(null);
  assert.equal(has(b, t.id), false);
});

test("switching to a drawing tool ends the edit (and cleans up)", () => {
  // Picking up a pen used to leave the editor open, still holding the keyboard.
  const b = freshCanvas();
  const t = textBox();
  placeText(t);
  S().setTool("pen");
  assert.equal(S().editingId, null, "the edit ended");
  assert.equal(has(b, t.id), false, "the empty box went with it");
});

test("starting a second box finishes the first", () => {
  const b = freshCanvas();
  const first = textBox();
  placeText(first);
  const second = textBox();
  placeText(second);
  assert.equal(has(b, first.id), false, "the untouched first box is gone");
  assert.ok(has(b, second.id), "the new one is being edited");
  S().setEditingId(null);
});

test("switching board while editing cleans up the box on the board you left", () => {
  const a = freshCanvas();
  const t = textBox();
  placeText(t);
  freshCanvas(); // setActiveBoard resets editingId directly
  assert.equal(has(a, t.id), false);
});

test("works inside a notebook page", () => {
  const nb = freshNotebook();
  const t = textBox();
  placeText(t);
  assert.ok(getBoardElements(board(nb)).some((e) => e.id === t.id));
  S().setEditingId(null);
  assert.equal(has(nb, t.id), false);
});

test("sticky notes are never auto-removed", () => {
  const b = freshCanvas();
  const sticky = { ...textBox(), type: "sticky", color: "yellow" } as unknown as WhiteboardElement;
  S().addElement(sticky, true);
  S().setEditingId(sticky.id);
  S().setEditingId(null);
  assert.ok(has(b, sticky.id));
});

test("an empty box styled as a shape (fill) is kept", () => {
  const b = freshCanvas();
  const t = textBox("", { backgroundColor: "#fde68a" });
  placeText(t);
  S().setEditingId(null);
  assert.ok(has(b, t.id));
});

console.log("\n── Text boxes: undo after the clean-up ──");

test("no dead undo step is left behind", () => {
  // Placing the box pushed a pre-creation snapshot. Left there, the next undo
  // would visibly do nothing - the one right after would undo real work.
  const b = freshCanvas();
  const r = textBox("keep me");
  S().addElement(r, true);
  const depthBefore = S().history.past.length;
  const t = textBox();
  placeText(t);
  S().setEditingId(null);
  assert.equal(S().history.past.length, depthBefore, "the box's creation entry was removed");
  S().undo();
  assert.equal(has(b, r.id), false, "the FIRST undo now undoes the real last action");
});

test("an earlier real edit's undo entry is not eaten", () => {
  const b = freshCanvas();
  const r = textBox("moved");
  S().addElement(r, true);
  S().updateElement(r.id, { x: 999 } as Partial<TextElement>, true); // a real, undoable move
  const t = textBox();
  placeText(t);
  S().setEditingId(null);
  S().undo();
  const back = allElements(board(b)).find((e) => e.id === r.id)!;
  assert.notEqual(back.x, 999, "undo still reverts the move");
  assert.ok(has(b, r.id), "and only the move");
});

console.log("\n── Text boxes: loading older saves ──");

test("the loader drops boxes older builds left behind, and keeps real ones", () => {
  const saved = {
    version: 1,
    boards: [
      {
        id: "old",
        name: "Old board",
        folderId: null,
        elements: [textBox(""), textBox("   "), textBox("real text"), textBox("", { borderColor: "#000" })],
        camera: { x: 0, y: 0, zoom: 1 },
        createdAt: 1,
        updatedAt: 1,
      },
    ],
    folders: [],
    activeBoardId: "old",
  };
  const out = migrateState(saved as never);
  const els = out.boards[0].elements;
  assert.equal(els.length, 2, "two empty boxes dropped");
  assert.ok(els.some((e) => (e as TextElement).text === "real text"));
  assert.ok(els.some((e) => (e as TextElement).borderColor === "#000"), "a bordered box is a shape, kept");
});

test("format with no selection inserts empty markers, cursor between them", () => {
  assert.deepEqual(spliceFormatMarkers("", 0, 0, "**", "**"), { updated: "****", cursor: 2 });
  assert.deepEqual(spliceFormatMarkers("hi", 2, 2, "$", "$"), { updated: "hi$$", cursor: 3 });
  assert.deepEqual(spliceFormatMarkers("hi", 2, 2, "[[", "]]"), { updated: "hi[[]]", cursor: 4 });
});

test("format with a selection still wraps it, cursor at its end", () => {
  assert.deepEqual(spliceFormatMarkers("hello", 1, 4, "**", "**"), { updated: "h**ell**o", cursor: 6 });
});

test("selection wrap holds mid-text, full-text and multi-char markers", () => {
  // Whole text selected.
  assert.deepEqual(spliceFormatMarkers("hi", 0, 2, "*", "*"), { updated: "*hi*", cursor: 3 });
  // Underline tags around one word mid-sentence.
  assert.deepEqual(spliceFormatMarkers("a b c", 2, 3, "<u>", "</u>"), {
    updated: "a <u>b</u> c",
    cursor: 6,
  });
  // WikiLink around a word.
  assert.deepEqual(spliceFormatMarkers("see Board now", 4, 9, "[[", "]]"), {
    updated: "see [[Board]] now",
    cursor: 11,
  });
  // Math around a word.
  assert.deepEqual(spliceFormatMarkers("area x here", 5, 6, "$", "$"), {
    updated: "area $x$ here",
    cursor: 7,
  });
  // Empty markers mid-text park the cursor between them.
  assert.deepEqual(spliceFormatMarkers("ab", 1, 1, "**", "**"), { updated: "a****b", cursor: 3 });
});

test("line prefix with collapsed cursor keeps the single-line toggle", () => {
  assert.deepEqual(prefixSelectedLines("hello", 2, 2, "- "), { updated: "- hello", cursor: 7 });
  assert.deepEqual(prefixSelectedLines("- hello", 2, 2, "- "), { updated: "hello", cursor: 5 });
  assert.deepEqual(prefixSelectedLines("# Title", 0, 0, "## "), { updated: "## Title", cursor: 8 });
});

test("line prefix with a multi-line selection prefixes every touched line", () => {
  assert.deepEqual(prefixSelectedLines("a\nb", 0, 3, "- "), { updated: "- a\n- b", cursor: 7 });
  // All prefixed already: toggles off.
  assert.deepEqual(prefixSelectedLines("- a\n- b", 0, 5, "- "), { updated: "a\nb", cursor: 3 });
  // Mixed: the bare line gains it, the prefixed one keeps it.
  assert.deepEqual(prefixSelectedLines("- a\nb", 0, 5, "- "), { updated: "- a\n- b", cursor: 7 });
  // Selection ending at a line start does not claim that line.
  assert.deepEqual(prefixSelectedLines("a\nb", 0, 2, "- "), { updated: "- a\nb", cursor: 3 });
});

test("line direction auto-detects Hebrew/Arabic as RTL, Latin as LTR", () => {
  assert.equal(detectLineDir("שלום עולם"), "rtl");
  assert.equal(detectLineDir("من اظلم ممن"), "rtl");
  assert.equal(detectLineDir("Hello world"), "ltr");
  assert.equal(detectLineDir("3. third item"), "ltr");
  assert.equal(detectLineDir("12 אבג"), "rtl");
  assert.equal(detectLineDir(""), "ltr");
  assert.equal(detectLineDir("123 !!!"), "ltr");
});

test("line direction override wins, missing means auto", () => {
  assert.equal(resolveLineDir(undefined, 0), "auto");
  assert.equal(resolveLineDir([], 0), "auto");
  assert.equal(resolveLineDir(["rtl"], 0), "rtl");
  assert.equal(resolveLineDir(["rtl"], 1), "auto");
  assert.equal(resolveLineDir(["auto"], 0), "auto");
});

test("direction sets every selected line and trims back to auto", () => {
  assert.deepEqual(setLineDirs(undefined, "a\nb", 0, 3, "rtl"), ["rtl", "rtl"]);
  assert.deepEqual(setLineDirs(["rtl", "rtl"], "a\nb", 0, 3, "auto"), []);
  assert.deepEqual(setLineDirs(undefined, "a\nb\nc", 2, 5, "rtl"), ["auto", "rtl", "rtl"]);
  // Partial selection still covers whole touched lines.
  assert.deepEqual(setLineDirs(undefined, "hello\nworld", 1, 8, "rtl"), ["rtl", "rtl"]);
});

test("isAbandonedTextBox is the single rule", () => {
  assert.equal(isAbandonedTextBox(textBox("")), true);
  assert.equal(isAbandonedTextBox(textBox("x")), false);
  assert.equal(isAbandonedTextBox(null), false);
  assert.equal(isAbandonedTextBox({ ...textBox(""), type: "sticky" } as unknown as WhiteboardElement), false);
});

console.log(`\n  ${passed} passed, ${failed} failed\n`);
if (failed > 0) process.exit(1);
