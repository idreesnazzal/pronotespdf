/**
 * Undo history persistence — no DOM, no network.
 *
 * History lives on its own localStorage key (never inside the workspace
 * payload), capped at 100 undo steps, oldest-first shrinking under a byte
 * budget. Fakes `window.localStorage` on globalThis like notebook.test.ts.
 */

import assert from "node:assert/strict";

import {
  saveHistory,
  loadHistory,
  flushHistorySave,
  restorableHistory,
  HISTORY_PAST_MAX,
  type SavedHistoryEntry,
} from "../src/lib/whiteboard/persistence";
import type { WhiteboardElement } from "../src/lib/whiteboard/types";

let passed = 0;
let failed = 0;
function test(name: string, fn: () => void) {
  try {
    fn();
    passed++;
    console.log(`  ✓ ${name}`);
  } catch (err) {
    failed++;
    console.error(`  ✗ ${name}\n      ${(err as Error).message}`);
  }
}

const g = globalThis as unknown as { window?: unknown };
const prevWindow = g.window;
const store: Record<string, string> = {};
const normalWindow = {
  localStorage: {
    getItem: (k: string) => (k in store ? store[k] : null),
    setItem: (k: string, v: string) => {
      store[k] = String(v);
    },
    removeItem: (k: string) => {
      delete store[k];
    },
  },
};
g.window = normalWindow;

function entry(boardId: string, at: number, fill = "x"): SavedHistoryEntry {
  return {
    boardId,
    pageId: `pg_${at}`,
    elements: [{ id: `e${at}`, type: "stroke", note: fill } as unknown as WhiteboardElement],
    at,
  };
}

console.log("\n── Undo history persistence ──");

test("round trip keeps entries in time order", () => {
  saveHistory({ past: [entry("b", 1), entry("b", 2)], future: [entry("b", 3)] });
  const back = loadHistory();
  assert.ok(back, "something must load");
  assert.deepEqual(back.past.map((e) => e.at), [1, 2]);
  assert.deepEqual(back.future.map((e) => e.at), [3]);
  assert.equal(back.past[0].boardId, "b");
});

test("past caps at 100, newest kept", () => {
  const past = Array.from({ length: 150 }, (_, i) => entry("b", i));
  saveHistory({ past, future: [] });
  const back = loadHistory();
  assert.ok(back, "something must load");
  assert.equal(back.past.length, HISTORY_PAST_MAX);
  assert.equal(back.past[0].at, 50, "oldest dropped first");
  assert.equal(back.past[back.past.length - 1].at, 149, "newest kept");
});

test("byte budget shrinks oldest first and keeps the newest step", () => {
  const big = "y".repeat(30 * 1024);
  const past = Array.from({ length: 100 }, (_, i) => entry("b", i, big));
  saveHistory({ past, future: [] });
  const raw = store["z-whiteboard-history-v1"];
  assert.ok(raw, "something must be written");
  assert.ok(raw.length <= 1_500_000, `payload ${raw.length} must fit the budget`);
  const back = loadHistory();
  assert.ok(back && back.past.length < 100, "oldest steps were shed");
  assert.equal(
    back.past[back.past.length - 1].at,
    99,
    "the newest step always survives"
  );
});

test("corrupt entries are rejected, valid ones kept", () => {
  g.window = {
    localStorage: {
      getItem: () => JSON.stringify({ past: [{ nope: 1 }, entry("b", 7)], future: "junk" }),
      setItem: (k: string, v: string) => {
        store[k] = String(v);
      },
      removeItem: (k: string) => {
        delete store[k];
      },
    },
  };
  const back = loadHistory();
  assert.ok(back, "load must not throw the whole history away");
  assert.equal(back.past.length, 1);
  assert.equal(back.past[0].at, 7);
  assert.deepEqual(back.future, []);
  g.window = normalWindow;
});

test("restorableHistory drops deleted boards and caps", () => {
  const ghost = Array.from({ length: 120 }, (_, i) => entry("gone", i));
  const mine = Array.from({ length: 120 }, (_, i) => entry("b", 1000 + i));
  const out = restorableHistory(["b"], { past: [...ghost, ...mine], future: ghost });
  assert.ok(out.past.every((e) => e.boardId === "b"), "no steps for deleted boards");
  assert.equal(out.past.length, HISTORY_PAST_MAX);
  assert.deepEqual(out.future, [], "future for deleted boards is dropped too");
});

test("flushHistorySave writes through immediately", () => {
  flushHistorySave(() => ({ past: [entry("b", 9)], future: [] }));
  const back = loadHistory();
  assert.equal(back?.past.length, 1);
  assert.equal(back?.past[0].at, 9);
});

test("missing key loads as null", () => {
  delete store["z-whiteboard-history-v1"];
  assert.equal(loadHistory(), null);
});

g.window = prevWindow;

console.log(`\n  ${passed} passed, ${failed} failed\n`);
if (failed > 0) process.exit(1);
