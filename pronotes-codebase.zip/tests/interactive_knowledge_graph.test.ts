/**
 * Interactive Knowledge Graph Intelligence & Gesture Verification Tests
 * ======================================================================
 * Tests for:
 * 1. Tag clustering (#tags) node and edge generation in buildGraph
 * 2. Backwards compatibility of buildGraph with existing callers
 * 3. Rich node metadata (snippet, tags, folderName)
 * 4. Neighborhood extraction (filterGraphNeighborhood at 1-hop and 2-hop)
 * 5. Gesture disambiguation: Drag deadband (>6px) vs Tap selection
 * 6. Multi-touch pinch-to-zoom math & focal point preservation
 * 7. Bounding-box Auto-Fit (Zoom to Extents) calculation
 */

import assert from "node:assert/strict";
import {
  buildGraph,
  filterGraphNeighborhood,
  type GraphData,
} from "../src/lib/whiteboard/links";
import type { Board, TextElement, StickyElement, Folder } from "../src/lib/whiteboard/types";

let passed = 0;
let failed = 0;

async function test(name: string, fn: () => void | Promise<void>) {
  try {
    await fn();
    passed++;
    console.log(`  ✓ ${name}`);
  } catch (err) {
    failed++;
    console.error(`  ✗ ${name}`);
    console.error(`      ${(err as Error).message}`);
  }
}

function makeBoard(id: string, name: string, folderId: string | null = null, tags: string[] = []): Board {
  return {
    id,
    name,
    folderId,
    tags,
    elements: [],
    camera: { x: 0, y: 0, zoom: 1 },
    updatedAt: Date.now(),
    createdAt: Date.now(),
  };
}

function makeTextElement(id: string, text: string): TextElement {
  return {
    id,
    type: "text",
    x: 100,
    y: 100,
    width: 250,
    height: 80,
    rotation: 0,
    opacity: 1,
    text,
    color: "#1e293b",
    fontSize: 16,
    fontFamily: "Inter",
    fontWeight: 400,
    align: "left",
    createdAt: Date.now(),
    updatedAt: Date.now(),
  };
}

async function runTests() {
  console.log("=== Testing Interactive Knowledge Graph Engine ===");

  await test("1. buildGraph backwards compatibility with 1, 2, or 3 arguments", () => {
    const b1 = makeBoard("b1", "Alpha");
    const b2 = makeBoard("b2", "Beta");
    b1.elements = [makeTextElement("t1", "Check out [[Beta]] for details")];

    // Call with 1 arg
    const g1 = buildGraph([b1, b2]);
    assert.ok(g1.nodes.length >= 2, "g1 has at least 2 nodes");
    assert.ok(g1.edges.some((e) => e.target === "b2"), "edge points to b2");

    // Call with 2 args
    const g2 = buildGraph([b1, b2], []);
    assert.equal(g2.nodes.length, g1.nodes.length);

    // Call with 3 args
    const folders: Folder[] = [{ id: "f1", name: "Projects", createdAt: 1, parentId: null, expanded: true }];
    const g3 = buildGraph([b1, b2], [], folders);
    assert.ok(g3.nodes.length >= 2);
  });

  await test("2. buildGraph extracts rich snippet, tags, and folderName metadata", () => {
    const folders: Folder[] = [{ id: "f1", name: "Physics Department", createdAt: 1, parentId: null, expanded: true }];
    const b1 = makeBoard("b1", "Quantum Mechanics", "f1", ["quantum", "physics"]);
    b1.elements = [
      makeTextElement("t1", "Schrodinger equation describes wave function dynamics."),
    ];

    const g = buildGraph([b1], [], folders);
    const node = g.nodes.find((n) => n.id === "b1");
    assert.ok(node, "b1 node exists");
    assert.equal(node!.folderName, "Physics Department", "folderName correctly resolved");
    assert.deepEqual(node!.tags, ["quantum", "physics"], "tags array preserved");
    assert.ok(node!.snippet?.includes("Schrodinger equation"), "snippet extracted from element text");
  });

  await test("3. buildGraph with includeTags creates emerald tag nuclei & connecting edges", () => {
    const b1 = makeBoard("b1", "Board One", null, ["exam2026", "math"]);
    const b2 = makeBoard("b2", "Board Two", null, ["exam2026", "cs"]);
    b2.elements = [makeTextElement("t2", "Review #algorithms before deadline.")];

    const g = buildGraph([b1, b2], [], [], { includeTags: true });

    // Check tag node existence
    const tagExam = g.nodes.find((n) => n.id === "tag:exam2026");
    assert.ok(tagExam, "tag:exam2026 node created");
    assert.equal(tagExam!.kind, "tag");
    assert.equal(tagExam!.color, "#10b981", "emerald tag color");
    assert.equal(tagExam!.name, "#exam2026");

    const tagAlgo = g.nodes.find((n) => n.id === "tag:algorithms");
    assert.ok(tagAlgo, "tag:algorithms parsed from element text created");

    // Check edges connecting to tag
    const edgesToExam = g.edges.filter((e) => e.target === "tag:exam2026");
    assert.equal(edgesToExam.length, 2, "both b1 and b2 connect to tag:exam2026");
    assert.ok(edgesToExam.some((e) => e.source === "b1"));
    assert.ok(edgesToExam.some((e) => e.source === "b2"));
  });

  await test("4. filterGraphNeighborhood extracts exact 1-hop and 2-hop subgraphs", () => {
    const b1 = makeBoard("b1", "Center");
    const b2 = makeBoard("b2", "Hop 1");
    const b3 = makeBoard("b3", "Hop 2");
    const b4 = makeBoard("b4", "Isolated");

    b1.elements = [makeTextElement("t1", "Links to [[Hop 1]]")];
    b2.elements = [makeTextElement("t2", "Links to [[Hop 2]]")];

    const globalGraph = buildGraph([b1, b2, b3, b4]);

    // 1-Hop around b1
    const sub1 = filterGraphNeighborhood(globalGraph, "b1", 1);
    const sub1Ids = new Set(sub1.nodes.map((n) => n.id));
    assert.ok(sub1Ids.has("b1"), "contains center");
    assert.ok(sub1Ids.has("b2"), "contains 1-hop neighbor b2");
    assert.ok(!sub1Ids.has("b3"), "does not contain 2-hop neighbor b3 at depth 1");
    assert.ok(!sub1Ids.has("b4"), "does not contain isolated node b4");

    // 2-Hop around b1
    const sub2 = filterGraphNeighborhood(globalGraph, "b1", 2);
    const sub2Ids = new Set(sub2.nodes.map((n) => n.id));
    assert.ok(sub2Ids.has("b1"));
    assert.ok(sub2Ids.has("b2"));
    assert.ok(sub2Ids.has("b3"), "contains 2-hop neighbor b3 at depth 2");
    assert.ok(!sub2Ids.has("b4"), "still excludes isolated node b4");
  });

  await test("5. Gesture deadband disambiguates Tap (<6px) vs Drag (>=6px)", () => {
    const isDrag = (dx: number, dy: number): boolean => {
      const travel = Math.hypot(dx, dy);
      return travel > 6;
    };

    // Micro-motion on stylus tap (hand tremors 1-3px)
    assert.equal(isDrag(1.5, 2.0), false, "small jitter (<6px) is NOT a drag -> triggers tap");
    assert.equal(isDrag(0, 5.8), false, "5.8px travel is NOT a drag -> triggers tap");

    // Intentional drag to rearrange node
    assert.equal(isDrag(12, 18), true, "21.6px travel IS a drag -> suppresses tap/navigation");
    assert.equal(isDrag(150, 0), true, "large pan IS a drag -> suppresses tap/navigation");
  });

  await test("6. Multi-touch pinch-to-zoom ratio & focal midpoint tracking", () => {
    // Initial touch: p1 = (100, 200), p2 = (300, 200) -> distance = 200, mid = (200, 200)
    const p1_start = { x: 100, y: 200 };
    const p2_start = { x: 300, y: 200 };
    const initialDist = Math.hypot(p2_start.x - p1_start.x, p2_start.y - p1_start.y);
    assert.equal(initialDist, 200);

    // Finger spread: p1 = (50, 200), p2 = (350, 200) -> distance = 300
    const p1_cur = { x: 50, y: 200 };
    const p2_cur = { x: 350, y: 200 };
    const currentDist = Math.hypot(p2_cur.x - p1_cur.x, p2_cur.y - p1_cur.y);
    assert.equal(currentDist, 300);

    const initialZoom = 1.0;
    const scale = currentDist / initialDist;
    assert.equal(scale, 1.5, "zoom scales up by 1.5x on spread");

    const newZoom = initialZoom * scale;
    assert.equal(newZoom, 1.5);
  });

  await test("7. Auto-Fit (Zoom to Extents) bounding box computation", () => {
    const testNodes = [
      { x: 100, y: 150 },
      { x: 500, y: 450 },
      { x: 300, y: 200 },
    ];
    const containerDims = { width: 1000, height: 700 };
    const padding = 70;

    let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
    for (const n of testNodes) {
      if (n.x < minX) minX = n.x;
      if (n.x > maxX) maxX = n.x;
      if (n.y < minY) minY = n.y;
      if (n.y > maxY) maxY = n.y;
    }

    assert.equal(minX, 100);
    assert.equal(maxX, 500);
    assert.equal(minY, 150);
    assert.equal(maxY, 450);

    const graphWidth = maxX - minX; // 400
    const graphHeight = maxY - minY; // 300
    const availWidth = containerDims.width - padding * 2; // 860
    const availHeight = containerDims.height - padding * 2; // 560

    const targetZoom = Math.min(availWidth / graphWidth, availHeight / graphHeight);
    // 860 / 400 = 2.15; 560 / 300 = 1.866...
    assert.ok(targetZoom > 1.8 && targetZoom < 1.9, "calculates optimal zoom without clipping");
  });

  console.log(`\nResults: ${passed} passed, ${failed} failed`);
  if (failed > 0) process.exit(1);
}

runTests();
