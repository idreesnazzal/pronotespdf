/**
 * Split-view pointer hand-off: every replayed press gets exactly one release.
 *
 * The bug this pins: the canvas counts fingers (in on pointerdown, out on
 * pointerup). The split pane replays a press a couple of frames after focus
 * switches sides, so a quick tap had usually lifted already - its real release
 * reached the canvas FIRST and removed nothing (Map.delete of an unknown id
 * is a silent no-op), then the late replay added a finger that was never
 * lifted. Every later one-finger touch then counted as the second finger of a
 * pinch: scrolling zoomed (measured 0.5 -> 0.355 on one drag), drawing and
 * typing did nothing, and closing the split did not help.
 *
 * These tests drive handOff/handOffPress against a stub DOM (separate node
 * process per test file, so stubbing globals is safe) and assert the pairing:
 * a press released before the replay is never dispatched; a held press gets
 * exactly one release, real if it lands inside the canvas, synthetic if not.
 */

import assert from "node:assert/strict";

import { handOff, handOffPress } from "../src/lib/whiteboard/pointerHandoff";

// ---------------------------------------------------------------------------
// Stub DOM: just enough for the hand-off (listeners, hit-testing, dispatch).
// Synthetic events do NOT bubble back to window here; in a real browser the
// re-dispatched release would, but it can never loop: the pairing check only
// synthesises when the real target is OUTSIDE the canvas, and
// Node.contains(itself) is true, so a second pass always sees "inside".
// ---------------------------------------------------------------------------

class FakeNode {}

class FakeEvent {
  readonly type: string;
  target: FakeNode | null = null;
  constructor(type: string, init: Record<string, unknown> = {}) {
    this.type = type;
    for (const [k, v] of Object.entries(init)) {
      (this as unknown as Record<string, unknown>)[k] = v;
    }
  }
}

class FakePointerEvent extends FakeEvent {}

class FakeElement extends FakeNode {
  readonly name: string;
  readonly dispatched: FakeEvent[] = [];
  readonly seenSelectors: string[] = [];
  private readonly contained = new Set<FakeNode>();
  closestResult: FakeElement | null = null;

  constructor(name: string) {
    super();
    this.name = name;
    this.contained.add(this);
    this.closestResult = this;
  }

  addContained(n: FakeNode): this {
    this.contained.add(n);
    return this;
  }

  dispatchEvent(e: FakeEvent): boolean {
    if (!e.target) e.target = this;
    this.dispatched.push(e);
    return true;
  }

  closest(selector: string): FakeElement | null {
    this.seenSelectors.push(selector);
    return this.closestResult;
  }

  contains(n: FakeNode | null): boolean {
    return n !== null && this.contained.has(n);
  }
}

type Listener = (e: FakeEvent) => void;

interface Harness {
  listeners: Map<string, Listener[]>;
  fire: (type: string, e: FakeEvent) => void;
  listenerCount: (type: string) => number;
  rafQueue: Array<() => void>;
  timerQueue: Array<{ cb: () => void; delay: number }>;
  drainRaf: () => void;
  drainTimers: (delay: number) => void;
  setElementAtPoint: (el: FakeElement | null) => void;
  lastHitPoint: () => { x: number; y: number } | null;
}

function installHarness(): Harness {
  const listeners = new Map<string, Listener[]>();
  const rafQueue: Array<() => void> = [];
  const timerQueue: Array<{ cb: () => void; delay: number }> = [];
  let elementAtPoint: FakeElement | null = null;
  let hitPoint: { x: number; y: number } | null = null;
  const g = globalThis as unknown as Record<string, unknown>;

  g.window = {
    addEventListener: (t: string, fn: Listener) => {
      const list = listeners.get(t) ?? [];
      list.push(fn);
      listeners.set(t, list);
    },
    removeEventListener: (t: string, fn: Listener) => {
      listeners.set(t, (listeners.get(t) ?? []).filter((f) => f !== fn));
    },
  };
  g.document = {
    elementFromPoint: (x: number, y: number) => {
      hitPoint = { x, y };
      return elementAtPoint;
    },
  };
  g.PointerEvent = FakePointerEvent;
  g.Node = FakeNode;
  g.requestAnimationFrame = (cb: () => void) => {
    rafQueue.push(cb);
    return rafQueue.length;
  };
  g.setTimeout = ((cb: () => void, delay?: number) => {
    timerQueue.push({ cb, delay: delay ?? 0 });
    return timerQueue.length;
  }) as unknown as typeof setTimeout;

  return {
    listeners,
    fire: (type, e) => {
      [...(listeners.get(type) ?? [])].forEach((f) => f(e));
    },
    listenerCount: (type) => listeners.get(type)?.length ?? 0,
    rafQueue,
    timerQueue,
    drainRaf: () => {
      while (rafQueue.length > 0) rafQueue.splice(0).forEach((cb) => cb());
    },
    drainTimers: (delay) => {
      const due = timerQueue.filter((t) => t.delay === delay);
      for (const t of due) {
        const i = timerQueue.indexOf(t);
        if (i >= 0) timerQueue.splice(i, 1);
        t.cb();
      }
    },
    setElementAtPoint: (el) => {
      elementAtPoint = el;
    },
    lastHitPoint: () => hitPoint,
  };
}

function field(e: FakeEvent, key: string): unknown {
  return (e as unknown as Record<string, unknown>)[key];
}

const PRESS = {
  pointerId: 7,
  pointerType: "touch",
  clientX: 100,
  clientY: 100,
  button: 0,
  buttons: 1,
  pressure: 0.5,
  isPrimary: true,
};

let passed = 0;
let failed = 0;
function test(name: string, fn: () => void) {
  try {
    fn();
    passed++;
    console.log(`  ✓ ${name}`);
  } catch (err) {
    failed++;
    console.error(`  ✗ ${name}`);
    console.error(`      ${(err as Error).message}`);
  }
}

test("a tap released before the replay dispatches nothing (the ghost, pinned)", () => {
  const h = installHarness();
  const canvas = new FakeElement("canvas");
  const elsewhere = new FakeElement("elsewhere");
  h.setElementAtPoint(canvas);

  handOffPress({ ...PRESS }, 100, 100);
  // The real release lands first, before React has swapped the panes.
  const up = new FakePointerEvent("pointerup", { pointerId: 7, clientX: 100, clientY: 100, buttons: 0 });
  up.target = elsewhere;
  h.fire("pointerup", up);
  // Now let the replay moment pass.
  h.drainRaf();
  h.drainTimers(50);

  assert.equal(canvas.dispatched.length, 0, "no press may be replayed after its release");
  assert.equal(elsewhere.dispatched.length, 0, "nothing dispatched anywhere");
  assert.equal(h.listenerCount("pointerup"), 0, "listeners cleaned up");
  assert.equal(h.listenerCount("pointercancel"), 0, "listeners cleaned up");
});

test("a held press replays, and a release outside gets exactly one synthetic release", () => {
  const h = installHarness();
  const canvas = new FakeElement("canvas");
  const outside = new FakeElement("outside");
  h.setElementAtPoint(canvas);

  handOffPress({ ...PRESS }, 100, 100);
  h.drainRaf();
  assert.equal(canvas.dispatched.length, 1, "the held press replays once");
  const press = canvas.dispatched[0];
  assert.equal(press.type, "pointerdown");
  assert.equal(field(press, "pointerId"), 7);
  assert.equal(field(press, "clientX"), 100);
  assert.equal(field(press, "bubbles"), true);
  assert.deepEqual(h.lastHitPoint(), { x: 100, y: 100 }, "replay targets the press point");

  // The finger lifts off the canvas (sidebar, toolbar, another app surface).
  const up = new FakePointerEvent("pointerup", { pointerId: 7, clientX: 140, clientY: 130, buttons: 0 });
  up.target = outside;
  h.fire("pointerup", up);

  assert.equal(canvas.dispatched.length, 2, "exactly one release follows the press");
  const syn = canvas.dispatched[1];
  assert.equal(syn.type, "pointerup", "release type preserved");
  assert.equal(field(syn, "pointerId"), 7, "paired to the same finger");
  assert.equal(field(syn, "buttons"), 0, "a release carries no buttons");
  assert.equal(field(syn, "pressure"), 0, "a release carries no pressure");
  assert.equal(field(syn, "clientX"), 140, "at the release point, not the press point");
  assert.equal(field(syn, "clientY"), 130, "at the release point, not the press point");
  assert.equal(field(syn, "pointerType"), "touch", "original contact kind preserved");
  assert.ok(
    canvas.seenSelectors.includes("[data-wb-canvas-area]"),
    "pairing resolves through the canvas area, not the raw target"
  );
  assert.equal(h.listenerCount("pointerup"), 0, "listeners cleaned up");
});

test("a release inside the canvas after the replay sends nothing extra", () => {
  const h = installHarness();
  const canvas = new FakeElement("canvas");
  const inner = new FakeElement("inner");
  canvas.addContained(inner);
  h.setElementAtPoint(canvas);

  handOffPress({ ...PRESS }, 100, 100);
  h.drainRaf();
  assert.equal(canvas.dispatched.length, 1, "press replayed");

  // The canvas got the real release itself: one press, one release, done.
  const up = new FakePointerEvent("pointerup", { pointerId: 7, clientX: 110, clientY: 105, buttons: 0 });
  up.target = inner;
  h.fire("pointerup", up);

  assert.equal(canvas.dispatched.length, 1, "no synthetic duplicate");
  assert.equal(h.listenerCount("pointerup"), 0, "listeners cleaned up");
});

test("pointercancel pairs exactly like pointerup", () => {
  const h = installHarness();
  const canvas = new FakeElement("canvas");
  const outside = new FakeElement("outside");
  h.setElementAtPoint(canvas);

  handOffPress({ ...PRESS }, 100, 100);
  h.drainRaf();
  assert.equal(canvas.dispatched.length, 1, "press replayed");

  const cancel = new FakePointerEvent("pointercancel", { pointerId: 7, clientX: 100, clientY: 100, buttons: 0 });
  cancel.target = outside;
  h.fire("pointercancel", cancel);

  assert.equal(canvas.dispatched.length, 2, "cancel paired");
  assert.equal(canvas.dispatched[1].type, "pointercancel", "cancel type preserved, not rewritten as up");
});

test("another finger's release is ignored", () => {
  const h = installHarness();
  const canvas = new FakeElement("canvas");
  h.setElementAtPoint(canvas);

  handOffPress({ ...PRESS }, 100, 100);
  const other = new FakePointerEvent("pointerup", { pointerId: 9, clientX: 0, clientY: 0, buttons: 0 });
  other.target = canvas;
  h.fire("pointerup", other);
  h.drainRaf();

  assert.equal(canvas.dispatched.length, 1, "finger 7 still replays; finger 9 changed nothing");
  assert.equal(canvas.dispatched[0].type, "pointerdown");
});

test("handOff dispatches made events and skips nulls", () => {
  const h = installHarness();
  const el = new FakeElement("el");
  h.setElementAtPoint(el);

  handOff(() => new FakeEvent("wheel", {}) as unknown as Event, 5, 5);
  h.drainRaf();
  assert.equal(el.dispatched.length, 1, "made event dispatched");
  assert.equal(el.dispatched[0].type, "wheel");

  handOff(() => null, 5, 5);
  h.drainRaf();
  h.drainTimers(50);
  assert.equal(el.dispatched.length, 1, "cancelled replay dispatches nothing");
});

console.log(`\n  ${passed} passed, ${failed} failed\n`);
if (failed > 0) process.exit(1);
