/**
 * OneDrive sign-in storage behaviour — no network.
 *
 * Fakes `window` / `localStorage` / `sessionStorage` / `fetch` on globalThis
 * (the module reads the bare globals, exactly like a browser) and covers:
 *
 *  1. A verifier that cannot be saved fails BEFORE the Microsoft redirect,
 *     with an actionable message, and never navigates.
 *  2. Working storage navigates to Microsoft and stores the verifier.
 *  3. signOut clears the verifier from sessionStorage (where it lives), not
 *     localStorage (where it never was), plus tokens and the return URL.
 *  4. A failing token write does not reject sign-in completion.
 */

import assert from "node:assert/strict";

import {
  beginSignIn,
  completeSignInIfRedirected,
  signOut,
} from "../src/lib/whiteboard/onedrive";

const LS_TOKENS = "pronotes.ms.tokens";
const LS_VERIFIER = "pronotes.ms.pkce";
const LS_RETURN = "pronotes.ms.return";

let passed = 0;
let failed = 0;
async function testAsync(name: string, fn: () => Promise<void>): Promise<void> {
  try {
    await fn();
    passed++;
    console.log(`  ✓ ${name}`);
  } catch (err) {
    failed++;
    console.error(`  ✗ ${name}\n      ${(err as Error).message}`);
  }
}

// --- fakes ---------------------------------------------------------------

function makeStore(throwOnSet: boolean) {
  const map = new Map<string, string>();
  const removed: string[] = [];
  return {
    map,
    removed,
    getItem: (k: string) => (map.has(k) ? (map.get(k) as string) : null),
    setItem: (k: string, v: string) => {
      if (throwOnSet) throw new Error("QuotaExceededError: storage is blocked");
      map.set(k, String(v));
    },
    removeItem: (k: string) => {
      removed.push(k);
      map.delete(k);
    },
  };
}

type Store = ReturnType<typeof makeStore>;

const g = globalThis as unknown as Record<string, unknown>;
let assignedUrl: string | null = null;

interface Installed {
  prev: Record<string, unknown>;
  local: Store;
  session: Store;
}

function install(opts: {
  localThrowOnSet?: boolean;
  sessionThrowOnSet?: boolean;
  href?: string;
}): Installed {
  const prev: Record<string, unknown> = {
    window: g.window,
    localStorage: g.localStorage,
    sessionStorage: g.sessionStorage,
    fetch: g.fetch,
  };
  assignedUrl = null;
  const local = makeStore(opts.localThrowOnSet ?? false);
  const session = makeStore(opts.sessionThrowOnSet ?? false);
  const href = opts.href ?? "https://localhost/";
  g.localStorage = local;
  g.sessionStorage = session;
  g.window = {
    location: {
      href,
      origin: "https://localhost",
      pathname: "/",
      assign: (url: string) => {
        assignedUrl = url;
      },
    },
    history: { replaceState: () => undefined },
  };
  process.env.NEXT_PUBLIC_MS_CLIENT_ID = "test-client-id";
  return { prev, local, session };
}

function restore(installed: Installed): void {
  g.window = installed.prev.window;
  g.localStorage = installed.prev.localStorage;
  g.sessionStorage = installed.prev.sessionStorage;
  g.fetch = installed.prev.fetch;
  delete process.env.NEXT_PUBLIC_MS_CLIENT_ID;
}

// --- tests ---------------------------------------------------------------

async function main(): Promise<void> {
  await testAsync(
    "beginSignIn rejects with the storage message and never navigates when the verifier cannot be saved",
    async () => {
      const installed = install({ sessionThrowOnSet: true });
      try {
        await assert.rejects(beginSignIn(), /blocking storage/);
        assert.equal(
          assignedUrl,
          null,
          "must not send the user to Microsoft when the return trip cannot succeed"
        );
      } finally {
        restore(installed);
      }
    }
  );

  await testAsync(
    "beginSignIn with working storage navigates to Microsoft and stores the verifier",
    async () => {
      const installed = install({});
      try {
        await beginSignIn();
        assert.ok(
          assignedUrl?.startsWith("https://login.microsoftonline.com/"),
          `expected a Microsoft authorize URL, got ${assignedUrl}`
        );
        assert.ok(
          assignedUrl?.includes("code_challenge="),
          "the PKCE challenge must travel with the redirect"
        );
        const verifier = installed.session.map.get(LS_VERIFIER);
        assert.ok(verifier, "the verifier must be stored before redirecting");
        assert.equal(
          installed.session.map.get(LS_RETURN),
          "https://localhost/",
          "the return URL is stored alongside the verifier"
        );
      } finally {
        restore(installed);
      }
    }
  );

  await testAsync(
    "signOut clears tokens from localStorage and the verifier from sessionStorage",
    async () => {
      const installed = install({});
      try {
        installed.local.map.set(LS_TOKENS, JSON.stringify({ accessToken: "a" }));
        installed.session.map.set(LS_VERIFIER, "verifier");
        installed.session.map.set(LS_RETURN, "https://localhost/");
        signOut();
        assert.equal(installed.local.map.has(LS_TOKENS), false, "tokens are gone");
        assert.equal(installed.session.map.has(LS_VERIFIER), false, "verifier is gone");
        assert.equal(installed.session.map.has(LS_RETURN), false, "return URL is gone");
        assert.ok(
          !installed.local.removed.includes(LS_VERIFIER),
          "must not clear the verifier from localStorage — it was never there"
        );
      } finally {
        restore(installed);
      }
    }
  );

  await testAsync(
    "a failing token write does not reject sign-in completion",
    async () => {
      const installed = install({
        localThrowOnSet: true,
        href: "https://localhost/?code=test-code",
      });
      try {
        installed.session.map.set(LS_VERIFIER, "verifier");
        g.fetch = async (url: unknown) => {
          if (String(url).includes("/oauth2/")) {
            return {
              ok: true,
              json: async () => ({ access_token: "a", refresh_token: "r", expires_in: 3600 }),
            };
          }
          return {
            ok: true,
            json: async () => ({ displayName: "Tester", mail: "t@example.com" }),
          };
        };
        // storeTokens throws on both writes inside; completion must still resolve.
        const completed = await completeSignInIfRedirected();
        assert.equal(completed, true, "sign-in completes even though tokens could not be persisted");
      } finally {
        restore(installed);
      }
    }
  );

  console.log(`\n  ${passed} passed, ${failed} failed\n`);
  if (failed > 0) process.exit(1);
}

void main();
