/**
 * How much bare desk may surround the paper.
 *
 * The bug this pins: the camera guard only asked that 120 px of the active
 * sheet stay somewhere on screen. On a tablet in portrait, zoomed out, that let
 * the page be shoved against one edge with most of a screenful of empty grey
 * beside it - and the same above and below the stack. Measured on the device:
 * an A4 sheet 349 px wide sitting at the left of a 1250 px screen, with about
 * 900 px of nothing to its right.
 *
 * Every assertion below is written in SCREEN pixels of visible desk, because
 * that is the thing being complained about. Re-deriving the formula here would
 * only prove the formula equals itself.
 */

import assert from "node:assert/strict";

import { useWhiteboard } from "../src/store/whiteboard";
import {
  PAGE_GAP,
  DESK_MARGIN_PX,
  clampNotebookCamera,
  minNotebookZoom,
} from "../src/lib/whiteboard/notebook";

let passed = 0;
let failed = 0;
function test(name: string, fn: () => void) {
  try {
    fn();
    passed++;
    console.log(`  ✓ ${name}`);
  } catch (err) {
    failed++;
    console.error(`  ✗ ${name}`);
    console.error(`      ${(err as Error).message}`);
  }
}

const A4 = { width: 794, height: 1123 };
const TABLET = { width: 1250, height: 1126 }; // Galaxy Tab S9, portrait
const DESKTOP = { width: 1000, height: 1400 };

/**
 * The strip of empty desk visible on each side, in screen pixels.
 * Negative means the paper runs off that edge, so no desk shows there.
 */
function desk(
  cam: { x: number; y: number; zoom: number },
  vp: { width: number; height: number },
  page: { width: number; height: number },
  doc: { pageCount: number; activeIndex: number }
) {
  const z = cam.zoom;
  const stride = page.height + PAGE_GAP;
  const docTop = -(doc.activeIndex * stride);
  const docBottom = (doc.pageCount - 1 - doc.activeIndex) * stride + page.height;
  const left = cam.x - vp.width / 2 / z;
  const right = cam.x + vp.width / 2 / z;
  const top = cam.y - vp.height / 2 / z;
  const bottom = cam.y + vp.height / 2 / z;
  return {
    left: (0 - left) * z,
    right: (right - page.width) * z,
    top: (docTop - top) * z,
    bottom: (bottom - docBottom) * z,
  };
}

const SLACK = 0.5; // sub-pixel rounding

/**
 * The whole rule, on one axis: either the desk past the paper is at most
 * DESK_MARGIN_PX, or the paper is smaller than the screen on that axis and is
 * therefore centred - which is the least wasteful position that exists. What
 * is forbidden is the third case, the one being complained about: paper pushed
 * against one edge with the waste piled up on the other.
 */
function assertTidy(
  near: number,
  far: number,
  paperPx: number,
  screenPx: number,
  where: string
) {
  if (paperPx >= screenPx) {
    assert.ok(near <= DESK_MARGIN_PX + SLACK, `${where}: ${near.toFixed(0)}px of desk`);
    assert.ok(far <= DESK_MARGIN_PX + SLACK, `${where}: ${far.toFixed(0)}px of desk`);
  } else {
    assert.ok(Math.abs(near - far) < SLACK, `${where}: off-centre by ${(near - far).toFixed(0)}px`);
  }
}
const at = (x: number, y: number, zoom: number) => ({ x, y, zoom });

console.log("\n── Notebook camera: the desk around the paper ──");

test("a page shoved to the left edge is pulled back", () => {
  // The camera measured on the tablet: page at the left, screenful of grey.
  const doc = { pageCount: 14, activeIndex: 8 };
  const c = clampNotebookCamera(at(1420, 0, 0.44), TABLET, A4, doc);
  const d = desk({ ...c, zoom: 0.44 }, TABLET, A4, doc);
  // Before the fix this camera was legal and put ~900px of grey on the right.
  assert.ok(d.right < 500, `right desk ${d.right.toFixed(0)}px is still a wasteland`);
  assertTidy(d.left, d.right, A4.width * 0.44, TABLET.width, "x");
});

test("a sheet narrower than the screen is centred, not parked on one side", () => {
  const doc = { pageCount: 14, activeIndex: 8 };
  // 794 * 0.44 = 349px of paper on a 1250px screen: desk on both sides is
  // unavoidable, but the two sides must match.
  for (const pushed of [-4000, -500, 0, 500, 4000]) {
    const c = clampNotebookCamera(at(pushed, 0, 0.44), TABLET, A4, doc);
    const d = desk({ ...c, zoom: 0.44 }, TABLET, A4, doc);
    assert.ok(
      Math.abs(d.left - d.right) < SLACK,
      `off-centre by ${(d.left - d.right).toFixed(0)}px starting from x=${pushed}`
    );
  }
});

test("you cannot pan into an empty void above the first page", () => {
  const doc = { pageCount: 10, activeIndex: 0 };
  const c = clampNotebookCamera(at(397, -3000, 0.9), DESKTOP, A4, doc);
  const d = desk({ ...c, zoom: 0.9 }, DESKTOP, A4, doc);
  assert.ok(d.top <= DESK_MARGIN_PX + SLACK, `${d.top.toFixed(0)}px of grey above page 1`);
});

test("nor below the last page", () => {
  const doc = { pageCount: 10, activeIndex: 9 };
  const c = clampNotebookCamera(at(397, 9000, 0.9), DESKTOP, A4, doc);
  const d = desk({ ...c, zoom: 0.9 }, DESKTOP, A4, doc);
  assert.ok(d.bottom <= DESK_MARGIN_PX + SLACK, `${d.bottom.toFixed(0)}px of grey below the last page`);
});

test("the desk that is left is a real strip, not a hairline", () => {
  // "smaller, but not zero": there must still be something to see and to grab.
  const doc = { pageCount: 10, activeIndex: 0 };
  const c = clampNotebookCamera(at(397, -3000, 0.9), DESKTOP, A4, doc);
  const d = desk({ ...c, zoom: 0.9 }, DESKTOP, A4, doc);
  assert.ok(d.top > 40, `only ${d.top.toFixed(0)}px of desk above the page`);
});

test("the middle of the notebook still scrolls freely", () => {
  // The page turn fires when the camera passes the middle of the gap. If the
  // bound stopped short of that, the notebook would jam on one page forever.
  const doc = { pageCount: 10, activeIndex: 5 };
  const reanchorForward = A4.height + PAGE_GAP / 2;
  const reanchorBack = -PAGE_GAP / 2;
  for (const z of [0.3, 0.44, 0.9, 1.6, 2]) {
    const fwd = clampNotebookCamera(at(397, reanchorForward + 1, z), TABLET, A4, doc);
    assert.ok(fwd.y > reanchorForward, `zoom ${z}: cannot reach the next page (y=${fwd.y.toFixed(0)})`);
    const back = clampNotebookCamera(at(397, reanchorBack - 1, z), TABLET, A4, doc);
    assert.ok(back.y < reanchorBack, `zoom ${z}: cannot reach the previous page (y=${back.y.toFixed(0)})`);
  }
});

test("zoomed in, both edges of the sheet are still reachable", () => {
  const doc = { pageCount: 3, activeIndex: 1 };
  const z = 2.5; // the page is 1985px wide, far wider than the screen
  const leftEnd = clampNotebookCamera(at(-9999, 0, z), TABLET, A4, doc);
  const dL = desk({ ...leftEnd, zoom: z }, TABLET, A4, doc);
  assert.ok(dL.left > 0 && dL.left <= DESK_MARGIN_PX + SLACK, `left edge desk ${dL.left.toFixed(0)}px`);
  const rightEnd = clampNotebookCamera(at(9999, 0, z), TABLET, A4, doc);
  const dR = desk({ ...rightEnd, zoom: z }, TABLET, A4, doc);
  assert.ok(dR.right > 0 && dR.right <= DESK_MARGIN_PX + SLACK, `right edge desk ${dR.right.toFixed(0)}px`);
});

test("a one-page notebook that fits is centred on both axes", () => {
  const doc = { pageCount: 1, activeIndex: 0 };
  const z = 0.4; // 318 x 449 of paper inside 1250 x 1126
  const c = clampNotebookCamera(at(-2000, 5000, z), TABLET, A4, doc);
  const d = desk({ ...c, zoom: z }, TABLET, A4, doc);
  assert.ok(Math.abs(d.left - d.right) < SLACK, `x off-centre by ${(d.left - d.right).toFixed(0)}px`);
  assert.ok(Math.abs(d.top - d.bottom) < SLACK, `y off-centre by ${(d.top - d.bottom).toFixed(0)}px`);
});

test("clamping twice changes nothing (two guards compose)", () => {
  // The store bounds the camera and the canvas bounds it again a frame later.
  // If this were not idempotent, those two would push each other forever.
  const doc = { pageCount: 14, activeIndex: 8 };
  for (const z of [0.2, 0.44, 1, 2.5]) {
    for (const start of [at(-5000, -5000, z), at(5000, 5000, z), at(397, 500, z)]) {
      const once = clampNotebookCamera(start, TABLET, A4, doc);
      const twice = clampNotebookCamera({ ...once, zoom: z }, TABLET, A4, doc);
      assert.ok(
        Math.abs(twice.x - once.x) < 1e-6 && Math.abs(twice.y - once.y) < 1e-6,
        `zoom ${z} from ${start.x},${start.y}`
      );
    }
  }
});

test("a camera already inside the bounds is left alone", () => {
  const doc = { pageCount: 14, activeIndex: 8 };
  const start = at(397, 560, 1.4);
  const c = clampNotebookCamera(start, TABLET, A4, doc);
  assert.equal(c.x, start.x);
  assert.equal(c.y, start.y);
});

test("nonsense input is returned untouched rather than producing NaN", () => {
  const doc = { pageCount: 5, activeIndex: 0 };
  assert.deepEqual(clampNotebookCamera(at(10, 20, 0), TABLET, A4, doc), { x: 10, y: 20 });
  assert.deepEqual(clampNotebookCamera(at(10, 20, 1), { width: 0, height: 0 }, A4, doc), { x: 10, y: 20 });
  assert.deepEqual(clampNotebookCamera(at(10, 20, 1), TABLET, { width: 0, height: 0 }, doc), { x: 10, y: 20 });
});

test("a PDF-sized page (landscape slides) obeys the same rule", () => {
  const SLIDE = { width: 1280, height: 720 };
  const doc = { pageCount: 40, activeIndex: 20 };
  for (const z of [0.8, 1.2]) {
    const c = clampNotebookCamera(at(-4000, 0, z), TABLET, SLIDE, doc);
    const d = desk({ ...c, zoom: z }, TABLET, SLIDE, doc);
    assertTidy(d.left, d.right, SLIDE.width * z, TABLET.width, `slides at ${z}`);
  }
});

console.log("\n── Notebook camera: how far out you may zoom ──");

/** What fraction of the screen the paper covers at a given zoom. */
function coverage(z: number, vp: { width: number; height: number }, page: { width: number; height: number }) {
  return (Math.min(page.width * z, vp.width) * Math.min(page.height * z, vp.height)) / (vp.width * vp.height);
}

test("the floor always leaves the whole page visible", () => {
  // The point of stopping there: one more step out shows no more paper.
  for (const vp of [TABLET, DESKTOP, { width: 1250, height: 1980 }, { width: 375, height: 812 }]) {
    for (const page of [A4, { width: 1280, height: 720 }, { width: 900, height: 900 }]) {
      const z = minNotebookZoom(vp, page);
      assert.ok(page.width * z <= vp.width + SLACK, `${vp.width}x${vp.height}: page too wide at the floor`);
      assert.ok(page.height * z <= vp.height + SLACK, `${vp.width}x${vp.height}: page too tall at the floor`);
    }
  }
});

test("and leaves the desk margin around it, not a hairline", () => {
  const z = minNotebookZoom(TABLET, A4);
  const spare = Math.min(TABLET.width - A4.width * z, TABLET.height - A4.height * z);
  assert.ok(spare >= DESK_MARGIN_PX * 2 - SLACK, `only ${spare.toFixed(0)}px spare around the page`);
});

test("the page cannot be shrunk to a stamp any more", () => {
  // The reported state: A4 at 44% on the tablet covered 12% of the screen.
  const vp = { width: 1250, height: 1980 };
  const before = coverage(0.44, vp, A4);
  const after = coverage(minNotebookZoom(vp, A4), vp, A4);
  assert.ok(before < 0.15, `sanity: the old state covered ${(before * 100).toFixed(0)}%`);
  // Not the whole screen: the floor deliberately allows a fifth past the fit
  // so the next sheet shows. What that extra room shows is paper, not desk -
  // vertically it is the neighbouring page, and only the sides are bare.
  assert.ok(after > 0.4, `the floor still only covers ${(after * 100).toFixed(0)}% of the screen`);
});

test("the tablet that was reported can reach 60%", () => {
  // 1600 x 2560 at density 340 is 753 x 1126 CSS pixels, which is what the
  // app actually measures. The ask was "let me reach 60%".
  const z = minNotebookZoom({ width: 753, height: 1126 }, A4);
  assert.ok(z > 0.57 && z < 0.63, `floor is ${(z * 100).toFixed(0)}%, not about 60%`);
});

test("at the floor you can see past the page you are on", () => {
  // The reason to zoom out at all. Stopping exactly at the fit hid the next
  // sheet, which made the floor feel like a cage.
  for (const vp of [{ width: 753, height: 1126 }, TABLET, DESKTOP]) {
    const z = minNotebookZoom(vp, A4);
    const visibleWorldH = vp.height / z;
    assert.ok(
      visibleWorldH > A4.height + PAGE_GAP,
      `${vp.width}x${vp.height}: only ${Math.round(visibleWorldH)} of ${A4.height + PAGE_GAP} world px visible`
    );
  }
});

test("the join between sheets is a seam, not a band", () => {
  // What the reference app does: pages run together with a hairline. A gap
  // you can measure in centimetres is what made zooming out feel empty.
  for (const vp of [{ width: 753, height: 1126 }, TABLET, DESKTOP]) {
    const seamPx = PAGE_GAP * minNotebookZoom(vp, A4);
    assert.ok(seamPx > 0, "the boundary must stay visible");
    assert.ok(seamPx < 12, `the seam is ${seamPx.toFixed(0)}px of dead space`);
  }
});

test("the floor follows the screen, which a fixed percentage cannot", () => {
  // "40%" is a full page on a phone and a stamp on a monitor. Same paper,
  // three screens, three different answers - all of them showing a whole page.
  const phone = minNotebookZoom({ width: 375, height: 812 }, A4);
  const tablet = minNotebookZoom({ width: 1250, height: 1980 }, A4);
  const monitor = minNotebookZoom({ width: 1800, height: 1000 }, A4);
  assert.ok(phone < tablet, `phone ${phone.toFixed(2)} should be below tablet ${tablet.toFixed(2)}`);
  assert.ok(monitor < tablet, `a short monitor runs out of height first`);
  assert.ok(coverage(0.4, { width: 1800, height: 1000 }, A4) < 0.2, "40% on a monitor is indeed a stamp");
});

test("a wide screen can still show a whole A4 page", () => {
  // The floor must not be taken from the width alone, or a landscape monitor
  // would be pinned so far in that the bottom of the page is unreachable.
  const vp = { width: 1800, height: 1000 };
  const z = minNotebookZoom(vp, A4);
  assert.ok(A4.height * z <= vp.height, `page bottom off screen at the floor (${z.toFixed(2)})`);
});

test("no floor when the screen is smaller than the margins", () => {
  assert.equal(minNotebookZoom({ width: 100, height: 100 }, A4), 0);
  assert.equal(minNotebookZoom(TABLET, { width: 0, height: 0 }), 0);
});

console.log("\n── Notebook camera: the floor follows the canvas, not the window ──");

test("zoomTo clamps to the floor for the canvas size the store was told", () => {
  const S = () => useWhiteboard.getState();
  const id = S().createNotebook("Floor NB", null);
  S().setActiveBoard(id);

  // Narrow canvas (sidebar open): a low floor.
  S().setCanvasViewport({ width: 544, height: 1126 });
  S().zoomTo(0.05);
  const narrow = S().camera.zoom;
  assert.ok(Math.abs(narrow - minNotebookZoom({ width: 544, height: 1126 }, A4)) < 1e-6, `got ${narrow}`);

  // The sidebar is hidden and the canvas grows. The floor must grow with it -
  // this is the bug: the observer updated the component and not the store, so
  // the floor stayed at the narrow canvas and the page could still shrink.
  S().setCanvasViewport({ width: 800, height: 1126 });
  S().zoomTo(0.05);
  const wide = S().camera.zoom;
  assert.ok(wide > narrow, `floor did not follow the canvas: ${narrow} -> ${wide}`);
  assert.ok(Math.abs(wide - minNotebookZoom({ width: 800, height: 1126 }, A4)) < 1e-6, `got ${wide}`);
});

test("a whiteboard still zooms out freely", () => {
  const S = () => useWhiteboard.getState();
  const id = S().createBoard("Floor WB", null);
  S().setActiveBoard(id);
  S().setCanvasViewport({ width: 800, height: 1126 });
  S().zoomTo(0.05);
  assert.ok(S().camera.zoom <= 0.05 + 1e-9, `whiteboard was clamped to ${S().camera.zoom}`);
});

test("a nonsense canvas size is ignored rather than stored", () => {
  const S = () => useWhiteboard.getState();
  S().setCanvasViewport({ width: 800, height: 1126 });
  S().setCanvasViewport({ width: 0, height: 0 });
  assert.deepEqual(S().canvasViewport, { width: 800, height: 1126 });
});

console.log(`\n  ${passed} passed, ${failed} failed\n`);
if (failed > 0) process.exit(1);
