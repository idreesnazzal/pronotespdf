/**
 * Capture (screenshot of an area).
 * - The area is measured in the canvas' world frame, trimmed to the paper in
 *   a notebook, and may span two sheets.
 * - The picture is built by the export engine: paper, ruling, PDF page and
 *   elements per the chosen background; a freeform loop masks it.
 * - Adding it to a document is one undoable step, taken from where you are.
 * - Screenshot mode only borrows the SELECT gestures.
 */

import assert from "node:assert/strict";
import {
  boundsOfPoints,
  buildCaptureSvg,
  captureFilename,
  captureKeep,
  capturePixelSize,
  clampCaptureRegion,
  defaultCaptureScale,
  intersectRect,
  polygonArea,
  rectFromCorners,
  selectionCaptureRegion,
  sheetsInRegion,
  type CaptureSource,
} from "../src/lib/whiteboard/capture";
import { placeCaptureBeside, placeCaptureOnPage } from "../src/lib/whiteboard/placement";
import { PAGE_GAP, getActivePage, getPages, getBoardElements, pageSizeOf } from "../src/lib/whiteboard/notebook";
import { appClipForPaste, clearAppClip, putAppClipImage } from "../src/lib/whiteboard/appClipboard";
import { screenshotShapeFor } from "../src/store/capture";
import { useWhiteboard } from "../src/store/whiteboard";
import type { Board, NotebookPage, WhiteboardElement } from "../src/lib/whiteboard/types";

const NL = String.fromCharCode(10);
let passed = 0;
let failed = 0;
function test(name: string, fn: () => void) {
  try {
    fn();
    passed++;
    console.log(`  ✓ ${name}`);
  } catch (err) {
    failed++;
    console.error(`  ✗ ${name}`);
    console.error(`      ${(err as Error).message}`);
  }
}

function rect(id: string, x: number, y: number, w = 20, h = 20): WhiteboardElement {
  return {
    id,
    type: "rectangle",
    x,
    y,
    width: w,
    height: h,
    rotation: 0,
    opacity: 1,
    strokeColor: "#112233",
    fillColor: "transparent",
    fillStyle: "transparent",
    dashStyle: "solid",
    strokeWidth: 2,
    createdAt: 0,
    updatedAt: 0,
  } as unknown as WhiteboardElement;
}

function page(id: string, elements: WhiteboardElement[] = [], extra: Partial<NotebookPage> = {}): NotebookPage {
  return { id, elements, createdAt: 0, updatedAt: 0, ...extra };
}

function notebook(pages: NotebookPage[], activeIndex = 0): Board {
  return {
    id: "nb",
    name: "Physics notes",
    kind: "notebook",
    pageSize: "a4",
    pages,
    activePageId: pages[activeIndex].id,
    elements: [],
    background: { pattern: "lines", size: 24 },
    createdAt: 0,
    updatedAt: 0,
  } as unknown as Board;
}

function canvas(elements: WhiteboardElement[]): Board {
  return {
    id: "wb",
    name: "Board",
    elements,
    background: { pattern: "dots", size: 24 },
    createdAt: 0,
    updatedAt: 0,
  } as unknown as Board;
}

const A4 = pageSizeOf(notebook([page("p")]));
const STRIDE = A4.height + PAGE_GAP;

console.log(NL + "── Capture: region maths ──");

test("a box is the same whichever corner you start from", () => {
  assert.deepEqual(rectFromCorners({ x: 50, y: 80 }, { x: 10, y: 20 }), { x: 10, y: 20, width: 40, height: 60 });
});

test("a loop's bounds ignore non-finite samples, and a scribble has no area", () => {
  assert.deepEqual(boundsOfPoints([{ x: 1, y: 2 }, { x: NaN, y: 0 }, { x: 5, y: 9 }]), { x: 1, y: 2, width: 4, height: 7 });
  assert.equal(boundsOfPoints([]), null);
  assert.equal(polygonArea([{ x: 0, y: 0 }, { x: 10, y: 0 }, { x: 10, y: 10 }, { x: 0, y: 10 }]), 100);
  assert.equal(polygonArea([{ x: 0, y: 0 }, { x: 5, y: 5 }, { x: 10, y: 10 }]), 0);
});

test("rectangles that only touch do not intersect", () => {
  assert.equal(intersectRect({ x: 0, y: 0, width: 10, height: 10 }, { x: 10, y: 0, width: 5, height: 5 }), null);
});

test("in a notebook the desk is trimmed away; on a whiteboard the area is kept as drawn", () => {
  const nb = notebook([page("a"), page("b")]);
  const drawn = { x: -200, y: 100, width: A4.width + 400, height: 300 };
  assert.deepEqual(clampCaptureRegion(nb, 0, drawn), { x: 0, y: 100, width: A4.width, height: 300 });
  assert.deepEqual(clampCaptureRegion(canvas([]), 0, drawn), drawn);
});

test("an area entirely on the desk, or a sliver, is not a capture", () => {
  const nb = notebook([page("a")]);
  assert.equal(clampCaptureRegion(nb, 0, { x: -300, y: 0, width: 200, height: 200 }), null);
  assert.equal(clampCaptureRegion(nb, 0, { x: 10, y: 10, width: 2, height: 200 }), null);
});

test("an area across the gap between two sheets takes both, at their stride", () => {
  const nb = notebook([page("a"), page("b"), page("c")], 1);
  // Anchored on page 2 (index 1): page 1 sits one stride above y = 0.
  const region = { x: 0, y: -100, width: 300, height: 200 };
  const hit = sheetsInRegion(nb, 1, region).map((s) => [s.page.id, s.offsetY]);
  assert.deepEqual(hit, [["a", -STRIDE], ["b", 0]]);
});

test("the notebook bounds follow the anchored page", () => {
  const nb = notebook([page("a"), page("b"), page("c")], 2);
  const r = clampCaptureRegion(nb, 2, { x: 0, y: -10_000, width: 50, height: 20_000 })!;
  assert.equal(r.y, -2 * STRIDE);
  assert.equal(r.height, 3 * A4.height + 2 * PAGE_GAP);
});

test("a selection is captured with a little air, constant on screen", () => {
  const els = [rect("a", 100, 100, 50, 50), rect("b", 300, 100, 10, 10)];
  const at1 = selectionCaptureRegion(els, ["a"], 1)!;
  const at2 = selectionCaptureRegion(els, ["a"], 2)!;
  assert.deepEqual(at1, { x: 86, y: 86, width: 78, height: 78 });
  assert.equal(at2.x, 93);
  assert.equal(selectionCaptureRegion(els, ["nope"], 1), null);
});

test("sharpness starts at what the screen showed, between 2x and 3x", () => {
  assert.equal(defaultCaptureScale(1, 1), 2);
  assert.equal(defaultCaptureScale(1, 2), 2);
  assert.equal(defaultCaptureScale(1.4, 2), 3);
  assert.equal(defaultCaptureScale(0.4, 2), 2);
  assert.equal(defaultCaptureScale(0, 0), 2);
});

test("a huge area is scaled down to what a canvas can hold", () => {
  const small = capturePixelSize({ x: 0, y: 0, width: 400, height: 300 }, 3);
  assert.deepEqual([small.width, small.height], [1200, 900]);
  const huge = capturePixelSize({ x: 0, y: 0, width: 8000, height: 8000 }, 3);
  assert.ok(huge.width * huge.height <= 40_000_000 + 16_000, `area ${huge.width * huge.height}`);
  assert.ok(huge.scale < 3);
});

test("selection only keeps a connector just when both its ends were picked", () => {
  const keep = captureKeep(["a", "b"])!;
  const conn = (s: string, t: string) =>
    ({ id: `c${s}${t}`, type: "connection", source: { elementId: s }, target: { elementId: t } }) as unknown as WhiteboardElement;
  assert.equal(keep(rect("a", 0, 0)), true);
  assert.equal(keep(rect("z", 0, 0)), false);
  assert.equal(keep(conn("a", "b")), true);
  assert.equal(keep(conn("a", "z")), false);
  assert.equal(captureKeep(undefined), undefined);
});

console.log(NL + "── Capture: the picture ──");

function srcFor(board: Board, extra: Partial<CaptureSource> = {}): CaptureSource {
  return { board, region: { x: 0, y: 0, width: 200, height: 100 }, anchorIndex: 0, ...extra };
}

test("the SVG's viewBox IS the area", () => {
  const { svg, width, height } = buildCaptureSvg(
    srcFor(canvas([rect("a", 10, 10)]), { region: { x: -50, y: 25.5, width: 120, height: 80 } }),
    { background: "page", dark: false }
  );
  assert.ok(svg.includes('viewBox="-50 25.5 120 80"'), svg.slice(0, 300));
  assert.deepEqual([width, height], [120, 80]);
});

test("'page' paints the sheet, its ruling and the PDF page; ink on top", () => {
  const nb = notebook([page("p1", [rect("ink", 20, 20)], { pdf: { docId: "d", pageNumber: 1 } })]);
  const { svg } = buildCaptureSvg(srcFor(nb), { background: "page", dark: false }, [], undefined, new Map([["p1", "data:image/png;base64,AAA"]]));
  assert.ok(svg.includes("<pattern"), "ruling");
  assert.ok(svg.includes("data:image/png;base64,AAA"), "PDF page");
  assert.ok(svg.includes('preserveAspectRatio="xMidYMid meet"'), "PDF letterboxed like the canvas");
  assert.ok(svg.indexOf("data:image/png;base64,AAA") < svg.indexOf("#112233"), "ink over the page");
});

test("'white' drops ruling and paper colour but keeps the PDF page", () => {
  const nb = notebook([page("p1", [rect("ink", 20, 20)], { pdf: { docId: "d", pageNumber: 1 } })]);
  const { svg } = buildCaptureSvg(srcFor(nb), { background: "white", dark: true }, [], undefined, new Map([["p1", "data:x"]]));
  assert.ok(!svg.includes("<pattern"));
  assert.ok(svg.includes('fill="#ffffff"'));
  assert.ok(svg.includes("data:x"));
});

test("'none' leaves only the ink: no paper, no ruling, no PDF page", () => {
  const nb = notebook([page("p1", [rect("ink", 20, 20)], { pdf: { docId: "d", pageNumber: 1 } })]);
  const { svg, report } = buildCaptureSvg(srcFor(nb), { background: "transparent", dark: false }, [], undefined, new Map([["p1", "data:x"]]));
  assert.ok(!svg.includes("<pattern"));
  assert.ok(!svg.includes("data:x"));
  assert.ok(!/<rect x="0" y="0" width="\d+" height="\d+" fill=/.test(svg), "no sheet fill");
  assert.ok(svg.includes("#112233"));
  assert.equal(report.missingPdfPages, 0, "a PDF left out on purpose is not 'missing'");
});

test("a PDF page that could not be loaded is reported", () => {
  const nb = notebook([page("p1", [], { pdf: { docId: "d", pageNumber: 1 } })]);
  assert.equal(buildCaptureSvg(srcFor(nb), { background: "page", dark: false }).report.missingPdfPages, 1);
});

test("a freeform loop masks the picture", () => {
  const polygon = [{ x: 0, y: 0 }, { x: 100, y: 0 }, { x: 50, y: 80 }];
  const { svg } = buildCaptureSvg(srcFor(canvas([rect("a", 10, 10)]), { polygon }), { background: "white", dark: false });
  assert.ok(svg.includes('<clipPath id="pn-capture-mask"><polygon points="0,0 100,0 50,80" />'));
  assert.ok(svg.includes('clip-path="url(#pn-capture-mask)"'));
});

test("selection only draws just the chosen elements", () => {
  const board = canvas([rect("a", 10, 10), { ...rect("b", 40, 10), strokeColor: "#abcdef" } as WhiteboardElement]);
  const { svg } = buildCaptureSvg(srcFor(board, { onlyIds: ["a"] }), { background: "transparent", dark: false });
  assert.ok(svg.includes("#112233"));
  assert.ok(!svg.includes("#abcdef"));
});

test("the canvas' own text markup and embedded fonts are used when given", () => {
  const board = canvas([{ ...rect("t", 0, 0), type: "text", text: "hello" } as unknown as WhiteboardElement]);
  const live = { markup: new Map([["t", "<g id=\"LIVE\"/>"]]), fontCss: "@font-face{font-family:X}" };
  const { svg } = buildCaptureSvg(srcFor(board), { background: "page", dark: false }, [], undefined, undefined, live);
  assert.ok(svg.includes('<g id="LIVE"/>'));
  assert.ok(svg.includes("<![CDATA["));
  assert.ok(svg.includes("@font-face{font-family:X}"));
  assert.ok(!svg.includes(">hello<"), "the serializer's own text is not drawn as well");
});

test("a whiteboard with no colour of its own captures the theme's background", () => {
  const board = canvas([]);
  assert.ok(buildCaptureSvg(srcFor(board), { background: "page", dark: false }).svg.includes('fill="#ffffff"'));
  assert.ok(buildCaptureSvg(srcFor(board), { background: "page", dark: true }).svg.includes('fill="#0a0a0a"'));
});

test("file names are safe and distinct to the second", () => {
  const when = new Date(2026, 8, 29, 14, 3, 7);
  assert.equal(captureFilename("Physics / notes: ch.1", when), "Physics___notes__ch_1_capture_2026-09-29_140307.png");
  assert.equal(captureFilename("", when), "capture_capture_2026-09-29_140307.png");
});

console.log(NL + "── Capture: where it lands ──");

test("on a fresh page: its own size, centred at the top, only ever shrunk", () => {
  assert.deepEqual(placeCaptureOnPage({ width: 800, height: 1000 }, { width: 200, height: 100 }), {
    x: 300, y: 48, width: 200, height: 100,
  });
  const big = placeCaptureOnPage({ width: 800, height: 1000 }, { width: 1408, height: 704 });
  assert.equal(Math.round(big.width), 704);
  assert.equal(Math.round(big.height), 352);
});

test("on a whiteboard: beside what is already there, or at the origin", () => {
  assert.deepEqual(placeCaptureBeside([rect("a", 0, 10, 100, 50)], { width: 30, height: 20 }), {
    x: 180, y: 10, width: 30, height: 20,
  });
  assert.deepEqual(placeCaptureBeside([], { width: 30, height: 20 }), { x: -15, y: -10, width: 30, height: 20 });
});

const S = () => useWhiteboard.getState();
const img = { src: "asset:img_x", naturalWidth: 400, naturalHeight: 200, size: { width: 200, height: 100 } };

test("'new page' inserts after the current page and one undo removes it", () => {
  const id = S().createNotebook("Cap NB", null);
  S().setActiveBoard(id);
  S().addPage();
  const b0 = S().boards.find((b) => b.id === id)!;
  const first = getPages(b0)[0].id;
  S().setActivePage(first);
  const res = S().addCaptureToBoard(id, { ...img, afterPageId: first })!;
  const b1 = S().boards.find((b) => b.id === id)!;
  assert.equal(getPages(b1).length, 3);
  assert.equal(getPages(b1)[1].id, res.pageId);
  assert.equal(res.pageNumber, 2);
  const el = getPages(b1)[1].elements[0] as WhiteboardElement & { src: string; locked?: boolean };
  assert.equal(el.src, "asset:img_x");
  assert.ok(!el.locked, "a clipping can be moved");
  S().undo();
  const b2 = S().boards.find((b) => b.id === id)!;
  assert.equal(getPages(b2).length, 2);
  assert.equal(getActivePage(b2)!.id, first);
});

test("adding to ANOTHER document is undone THERE, never from where you captured", () => {
  const here = S().createNotebook("Here", null);
  const there = S().createBoard("There", null);
  S().setActiveBoard(there);
  S().addElement(rect("existing", 0, 0, 100, 100));
  S().setActiveBoard(here);
  const res = S().addCaptureToBoard(there, img)!;
  const t1 = S().boards.find((b) => b.id === there)!;
  const placed = getBoardElements(t1).find((e) => e.id === res.elementId)!;
  assert.ok(placed.x >= 100, "placed beside the existing content");
  assert.equal(S().activeBoardId, here, "the current document stays current");
  // Undo here must not reach into the other document: its whole-document
  // snapshot would wipe anything written there since.
  S().undo();
  const t2 = S().boards.find((b) => b.id === there)!;
  assert.ok(getBoardElements(t2).some((e) => e.id === res.elementId), "undo here leaves the other document alone");
  // Work done in the other document afterwards survives, and Undo there takes
  // the steps back in order: the later edit first, then the capture.
  S().setActiveBoard(there);
  S().addElement(rect("later", 400, 0, 50, 50));
  S().undo();
  const t3 = S().boards.find((b) => b.id === there)!;
  assert.deepEqual(getBoardElements(t3).map((e) => e.id).sort(), ["existing", res.elementId].sort());
  S().undo();
  const t4 = S().boards.find((b) => b.id === there)!;
  assert.deepEqual(getBoardElements(t4).map((e) => e.id), ["existing"]);
});

test("an unknown document adds nothing", () => {
  assert.equal(S().addCaptureToBoard("no-such-board", img), null);
});

console.log(NL + "── Capture: mode and clipboard ──");

test("screenshot mode only takes over the select tool's gestures", () => {
  assert.equal(screenshotShapeFor(true, "select"), "rectangle");
  assert.equal(screenshotShapeFor(true, "lasso"), "lasso");
  assert.equal(screenshotShapeFor(true, "gel"), null);
  assert.equal(screenshotShapeFor(true, "laser"), null);
  assert.equal(screenshotShapeFor(false, "select"), null);
});

test("the app clipboard stands in only when the system refused the copy", () => {
  clearAppClip();
  assert.equal(appClipForPaste(), null);
  putAppClipImage({ dataUrl: "data:a", width: 2, height: 2, systemCopied: true });
  assert.equal(appClipForPaste(), null, "the system clipboard has it: it is the truth");
  putAppClipImage({ dataUrl: "data:b", width: 2, height: 2, systemCopied: false });
  assert.equal(appClipForPaste()?.dataUrl, "data:b");
  clearAppClip();
});

console.log(`  ${passed} passed, ${failed} failed`);
if (failed > 0) process.exit(1);
