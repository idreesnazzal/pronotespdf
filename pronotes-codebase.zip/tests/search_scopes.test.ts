/**
 * Search scopes and nearest-first ranking (lib/whiteboard/search.ts).
 * - "This note" finds only the open note's content, in page order.
 * - "This folder" covers the folder and its sub-folders, not the rest.
 * - "Everywhere" puts this note, then its folder, then the folders around
 *   it, then everything else; within a group better matches come first.
 * - Markdown, case and Hebrew niqqud do not stop a match; handwriting,
 *   shapes and pictures are never results.
 */

import assert from "node:assert/strict";
import {
  buildSearchIndex,
  foldText,
  groupHits,
  highlightParts,
  makeSnippet,
  matchEntry,
  pdfHit,
  plainText,
  scopeInfo,
  searchEntries,
  sortHits,
  type SearchContext,
} from "../src/lib/whiteboard/search";
import type { Board, Folder, WhiteboardElement } from "../src/lib/whiteboard/types";
import { getPages } from "../src/lib/whiteboard/notebook";
import { useWhiteboard } from "../src/store/whiteboard";

const NL = String.fromCharCode(10);
let passed = 0;
let failed = 0;
function test(name: string, fn: () => void) {
  try {
    fn();
    passed++;
    console.log(`  ✓ ${name}`);
  } catch (err) {
    failed++;
    console.error(`  ✗ ${name}`);
    console.error(`      ${(err as Error).message}`);
  }
}

function folder(id: string, name: string, parentId: string | null): Folder {
  return { id, name, parentId, expanded: true, createdAt: 1 };
}

function text(id: string, body: string, y = 0, updatedAt = 1): WhiteboardElement {
  return {
    id, type: "text", x: 0, y, width: 100, height: 20, rotation: 0, opacity: 1,
    createdAt: 1, updatedAt, text: body, color: "#000", fontSize: 16,
    fontFamily: "inter", fontWeight: 400, align: "left",
  } as WhiteboardElement;
}

function sticky(id: string, body: string, y = 0): WhiteboardElement {
  return {
    id, type: "sticky", x: 0, y, width: 100, height: 100, rotation: 0, opacity: 1,
    createdAt: 1, updatedAt: 1, text: body, color: "yellow", fontSize: 16, align: "left",
  } as WhiteboardElement;
}

function stroke(id: string): WhiteboardElement {
  return {
    id, type: "stroke", x: 0, y: 0, rotation: 0, opacity: 1, createdAt: 1, updatedAt: 1,
    points: [[0, 0, 0.5], [10, 10, 0.5]], color: "#000", size: 3,
  } as unknown as WhiteboardElement;
}

function canvas(id: string, name: string, folderId: string | null, elements: WhiteboardElement[], updatedAt = 1): Board {
  return {
    id, name, folderId, elements, camera: { x: 0, y: 0, zoom: 1 },
    createdAt: 1, updatedAt,
  };
}

function notebook(id: string, name: string, folderId: string | null, pages: WhiteboardElement[][]): Board {
  return {
    id, name, folderId, elements: [], camera: { x: 0, y: 0, zoom: 1 },
    createdAt: 1, updatedAt: 1, kind: "notebook",
    pages: pages.map((els, i) => ({ id: `${id}-p${i}`, elements: els, createdAt: 1, updatedAt: 1 })),
    activePageId: `${id}-p0`,
  };
}

// Uni ─┬─ Physics ── Labs
//      └─ Maths
// Old (top level)
const folders = [
  folder("uni", "Uni", null),
  folder("phys", "Physics", "uni"),
  folder("labs", "Labs", "phys"),
  folder("maths", "Maths", "uni"),
  folder("old", "Old", null),
];

const boards: Board[] = [
  notebook("lect", "Lecture notes", "phys", [
    [text("a", "Momentum is conserved", 300)],
    [sticky("b", "**Exam** momentum question", 50), stroke("ink")],
    [text("c", "momentum again", 10)],
  ]),
  canvas("hw", "Homework", "phys", [text("d", "momentum homework")], 5),
  canvas("lab1", "Lab 1", "labs", [text("e", "measure momentum")]),
  canvas("alg", "Algebra", "maths", [text("f", "momentum of a group?")]),
  canvas("arch", "Archive", "old", [text("g", "momentum archive", 0, 99)], 99),
  canvas("mom", "Momentum", "old", []),
];

const ctx: SearchContext = { activeBoardId: "lect", folderId: "phys", folders };
const index = buildSearchIndex(boards, folders);

console.log(NL + "── Search scopes & ranking ──");

test("'This note' finds only the open note's content, in page order", () => {
  const hits = searchEntries(index, "momentum", "note", ctx);
  assert.deepEqual(hits.map((h) => h.entry.elementId), ["a", "b", "c"]);
  assert.deepEqual(hits.map((h) => h.entry.pageIndex), [0, 1, 2]);
});

test("'This folder' covers the folder and its sub-folders only", () => {
  const ids = searchEntries(index, "momentum", "folder", ctx).map((h) => h.entry.boardId);
  assert.ok(ids.includes("lect") && ids.includes("hw") && ids.includes("lab1"));
  assert.ok(!ids.includes("alg"), "a sibling folder is outside");
  assert.ok(!ids.includes("arch") && !ids.includes("mom"), "another tree is outside");
});

test("'Everywhere' is nearest first: note, folder, around it, elsewhere", () => {
  const hits = searchEntries(index, "momentum", "everywhere", ctx);
  const groups = groupHits(hits, "everywhere", ctx);
  assert.deepEqual(groups.map((g) => g.id), ["note", "folder", "near", "elsewhere"]);
  assert.deepEqual(groups.map((g) => g.label), ["In this note", "In Physics", "Sub-folders & parent", "Elsewhere"]);
  assert.deepEqual(groups[1].hits.map((h) => h.entry.boardId), ["hw"]);
  assert.deepEqual(groups[2].hits.map((h) => h.entry.boardId), ["lab1"]);
  // A note NAMED "Momentum" is the best match of all, yet it is far away, so
  // it still comes after everything nearby - then leads its own group.
  assert.deepEqual(groups[3].hits.map((h) => h.entry.id), ["board:mom", "arch:g", "alg:f"]);
});

test("the parent folder counts as near; a sibling does not", () => {
  const inMaths = { ...ctx, activeBoardId: "alg", folderId: "maths" };
  const hits = searchEntries(index, "momentum", "everywhere", inMaths);
  const near = hits.filter((h) => h.nearness === "near").map((h) => h.entry.boardId);
  assert.deepEqual(near, [], "Uni itself holds no notes, and Physics is a sibling");
  const physics = hits.find((h) => h.entry.boardId === "hw");
  assert.equal(physics?.nearness, "elsewhere");
  const fromLabs = searchEntries(index, "homework", "everywhere", { ...ctx, activeBoardId: "lab1", folderId: "labs" });
  assert.equal(fromLabs[0]?.nearness, "near", "Physics is the parent of Labs");
});

test("within a group: title beats whole word beats prefix beats substring", () => {
  const title = matchEntry(index.find((e) => e.id === "board:mom")!, ["momentum"])!;
  const word = matchEntry(index.find((e) => e.id === "arch:g")!, ["momentum"])!;
  const idx = buildSearchIndex(
    [canvas("x", "X", null, [text("p", "momentums"), text("s", "antimomentum"), text("w", "the momentum")])],
    []
  );
  const q = (id: string) => matchEntry(idx.find((e) => e.id === `x:${id}`)!, ["momentum"])!.score;
  assert.ok(title.score > word.score, "title first");
  assert.ok(q("w") > q("p") && q("p") > q("s"), "word > prefix > substring");
});

test("equal matches fall back to the most recently edited", () => {
  const idx = buildSearchIndex(
    [canvas("x", "X", null, [text("old", "alpha", 0, 10), text("new", "alpha", 50, 20)])],
    []
  );
  const hits = searchEntries(idx, "alpha", "everywhere", { activeBoardId: null, folderId: null, folders: [] });
  assert.deepEqual(hits.map((h) => h.entry.elementId), ["new", "old"]);
});

test("every word must match; the whole phrase is highlighted as one", () => {
  assert.equal(searchEntries(index, "momentum banana", "everywhere", ctx).length, 0);
  const hit = searchEntries(index, "exam momentum", "note", ctx)[0];
  assert.equal(hit.entry.elementId, "b");
  const parts = highlightParts(makeSnippet(hit)).filter((p) => p.hit).map((p) => p.text);
  assert.deepEqual(parts, ["Exam momentum"]);
});

test("markdown is searched as displayed; ink is never a result", () => {
  assert.equal(plainText("## **Bold** [[Target|alias]] ==hi=="), "Bold alias hi");
  assert.ok(!index.some((e) => e.elementId === "ink"));
});

test("case, accents and Hebrew niqqud are ignored, highlight lands on the written text", () => {
  assert.equal(foldText("CAFÉ"), "cafe");
  const idx = buildSearchIndex([canvas("h", "H", null, [text("t", "אמר שָׁלוֹם לכולם")])], []);
  const hit = searchEntries(idx, "שלום", "everywhere", { activeBoardId: null, folderId: null, folders: [] })[0];
  assert.ok(hit, "found without niqqud");
  const marked = highlightParts(makeSnippet(hit)).find((p) => p.hit)?.text;
  assert.equal(marked, "שָׁלוֹם");
});

test("folder names, note names and tags are found in the wide scopes, not in 'This note'", () => {
  const tagged = { ...canvas("t", "Tagged", "phys", []), tags: ["exam"] };
  const idx = buildSearchIndex([...boards, tagged], folders);
  const kinds = searchEntries(idx, "exam", "everywhere", ctx).map((h) => h.entry.kind);
  assert.ok(kinds.includes("tag"));
  const labs = searchEntries(idx, "labs", "everywhere", ctx);
  assert.equal(labs[0].entry.kind, "folder");
  assert.ok(searchEntries(idx, "lecture", "note", ctx).length === 0, "the note's own name is not 'in' it");
});

test("a long text is cut to a window around the match", () => {
  const long = "word ".repeat(60) + "needle " + "tail ".repeat(60);
  const idx = buildSearchIndex([canvas("l", "L", null, [text("t", long)])], []);
  const hit = searchEntries(idx, "needle", "everywhere", { activeBoardId: null, folderId: null, folders: [] })[0];
  const snip = makeSnippet(hit, 60);
  assert.ok(snip.text.startsWith("…") && snip.text.endsWith("…"));
  assert.ok(snip.text.length <= 62);
  const [at, len] = snip.ranges[0];
  assert.equal(snip.text.slice(at, at + len), "needle");
});

test("PDF text hits take the note's place and sort by page within 'This note'", () => {
  const info = scopeInfo(ctx);
  const lect = boards[0];
  const p = pdfHit(lect, { pageIndex: 1, snippet: "the momentum of a body", matchStart: 4, matchLength: 8 }, "momentum", 0, info);
  assert.equal(p.nearness, "note");
  assert.equal(p.entry.pageId, "lect-p1", "page id filled in from the index");
  const merged = sortHits([...searchEntries(index, "momentum", "note", ctx), p], "note");
  assert.deepEqual(merged.map((h) => h.entry.elementId ?? "pdf"), ["a", "pdf", "b", "c"]);
  const marked = highlightParts(makeSnippet(p)).find((x) => x.hit)?.text;
  assert.equal(marked, "momentum");
});

test("at the top level, 'This folder' means the loose top-level notes", () => {
  const top = [canvas("loose", "Loose", null, [text("z", "zeta")]), canvas("in", "In", "uni", [text("y", "zeta")])];
  const idx = buildSearchIndex(top, folders);
  const hits = searchEntries(idx, "zeta", "folder", { activeBoardId: "loose", folderId: null, folders });
  assert.deepEqual(hits.map((h) => h.entry.boardId), ["loose"]);
});

test("re-indexing reuses unchanged boards", () => {
  const again = buildSearchIndex(boards, folders);
  const a = index.find((e) => e.id === "hw:d");
  const b = again.find((e) => e.id === "hw:d");
  assert.equal(a, b, "same entry object: the board was not re-read");
});

test("opening a result on another notebook page turns to it and centres it, unselected", () => {
  const S = () => useWhiteboard.getState();
  const id = S().createNotebook("Find me", null);
  S().setActiveBoard(id);
  S().addPage(); // page 2 is now active
  S().addElement(text("far-note", "deep in the notebook", 400));
  const page2 = S().boards.find((b) => b.id === id)!.activePageId;
  S().goToPage(getPages(S().boards.find((b) => b.id === id))[0].id, 800);

  S().focusElement(id, "far-note", { select: false });
  const after = S();
  assert.equal(after.boards.find((b) => b.id === id)!.activePageId, page2, "turned to the element's page");
  assert.equal(after.camera.x, 50);
  assert.equal(after.camera.y, 410, "centred on the element in page coordinates");
  assert.deepEqual(after.selectedIds, [], "search shows, it does not select");
});

console.log(`  ${passed} passed, ${failed} failed`);
if (failed > 0) process.exit(1);
