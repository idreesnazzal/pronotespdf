import assert from "node:assert/strict";
import {
  hitTestElement,
  getElementBounds,
  getElementCenter,
  getNodeAnchorPorts,
  getResolvedAnchorPoint,
  getOptimalConnectionAnchors,
  getConnectionPath,
  isPointInPolygon,
  isElementInPolygon,
  worldToScreen,
  screenToWorld,
} from "../src/lib/whiteboard/geometry";
import type {
  StrokeElement,
  RectangleElement,
  EllipseElement,
  DiamondElement,
  LineElement,
  ArrowElement,
  ConnectionElement,
  TextElement,
  StickyElement,
  ImageElement,
  Board,
} from "../src/lib/whiteboard/types";

console.log("===================================================================");
console.log("=== RUNNING MILESTONE 2 (R2) QA & TOOL BUG FIXING TEST SUITE    ===");
console.log("===================================================================");

let passCount = 0;
function pass(msg: string) {
  passCount++;
  console.log(`  ✓ ${msg}`);
}

// ----------------------------------------------------------------------------
// 1. True Lasso Freeform Polygon Selection & Ray-Casting Point-in-Polygon Tests
// ----------------------------------------------------------------------------
console.log("\n[Test 1] Lasso Ray-Casting & Element Containment Tests...");

// 1.1 Triangle Polygon
const trianglePoly = [
  { x: 0, y: 0 },
  { x: 100, y: 0 },
  { x: 50, y: 100 },
];
assert.equal(isPointInPolygon(50, 30, trianglePoly), true, "Interior point in triangle");
assert.equal(isPointInPolygon(50, 150, trianglePoly), false, "Exterior point below triangle");
assert.equal(isPointInPolygon(-10, 50, trianglePoly), false, "Exterior point left of triangle");
pass("Triangle polygon ray casting point-in-polygon containment verified");

// 1.2 Concave / L-shaped Polygon
const lPoly = [
  { x: 0, y: 0 },
  { x: 100, y: 0 },
  { x: 100, y: 50 },
  { x: 50, y: 50 },
  { x: 50, y: 100 },
  { x: 0, y: 100 },
];
assert.equal(isPointInPolygon(20, 20, lPoly), true, "Inside top-left arm of L");
assert.equal(isPointInPolygon(20, 80, lPoly), true, "Inside bottom-left foot of L");
assert.equal(isPointInPolygon(75, 75, lPoly), false, "In the cut-out corner of L (must be outside)");
pass("Concave polygon ray casting handles non-convex geometries");

// 1.3 Element Containment in Polygon
const rectInside: RectangleElement = {
  id: "rect-in",
  type: "rectangle",
  x: 20,
  y: 20,
  width: 40,
  height: 40,
  rotation: 0,
  opacity: 1,
  strokeColor: "#000",
  fillColor: "#fff",
  fillStyle: "solid",
  dashStyle: "solid",
  strokeWidth: 2,
  createdAt: Date.now(),
  updatedAt: Date.now(),
};

const rectOutside: RectangleElement = {
  ...rectInside,
  id: "rect-out",
  x: 200,
  y: 200,
};

const lassoLoop = [
  { x: 0, y: 0 },
  { x: 120, y: 0 },
  { x: 120, y: 120 },
  { x: 0, y: 120 },
];

assert.equal(isElementInPolygon(rectInside, lassoLoop), true, "Element inside lasso polygon returns true");
assert.equal(isElementInPolygon(rectOutside, lassoLoop), false, "Element outside lasso polygon returns false");

// 1.4 Freehand Stroke containment in lasso
const strokeInLasso: StrokeElement = {
  id: "stroke-in",
  type: "stroke",
  x: 30,
  y: 30,
  rotation: 0,
  opacity: 1,
  points: [[0, 0, 0.5], [20, 20, 0.5]],
  color: "#000",
  strokeWidth: 2,
  strokeStyle: "pen",
  createdAt: Date.now(),
  updatedAt: Date.now(),
};
assert.equal(isElementInPolygon(strokeInLasso, lassoLoop), true, "Stroke inside lasso returns true");
pass("Element and stroke containment in freeform lasso polygons verified");

// ----------------------------------------------------------------------------
// 2. Line & Arrow Resizing Endpoint Vector Updates
// ----------------------------------------------------------------------------
console.log("\n[Test 2] Line & Arrow Endpoint (x2, y2) Vector Resizing...");

const testLine: LineElement = {
  id: "line-1",
  type: "line",
  x: 100,
  y: 100,
  x2: 150,
  y2: 80,
  rotation: 0,
  opacity: 1,
  strokeColor: "#000",
  dashStyle: "solid",
  strokeWidth: 2,
  createdAt: Date.now(),
  updatedAt: Date.now(),
};

const lineBounds = getElementBounds(testLine);
assert.equal(lineBounds.x, 100);
assert.equal(lineBounds.y, 100);
assert.equal(lineBounds.width, 150);
assert.equal(lineBounds.height, 80);

// Simulate handle 'e' resize (+50px dx)
const dx = 50;
const dy = 0;
const p1 = { x: testLine.x, y: testLine.y };
const p2 = { x: testLine.x + testLine.x2, y: testLine.y + testLine.y2 };
const oldW = Math.max(lineBounds.width, 1);
const oldH = Math.max(lineBounds.height, 1);

const newX = lineBounds.x;
const newY = lineBounds.y;
const newW = lineBounds.width + dx;
const newH = lineBounds.height;

const u1 = (p1.x - lineBounds.x) / oldW;
const v1 = (p1.y - lineBounds.y) / oldH;
const u2 = (p2.x - lineBounds.x) / oldW;
const v2 = (p2.y - lineBounds.y) / oldH;

const newP1x = newX + u1 * newW;
const newP1y = newY + v1 * newH;
const newP2x = newX + u2 * newW;
const newP2y = newY + v2 * newH;

const updatedLine: LineElement = {
  ...testLine,
  x: newP1x,
  y: newP1y,
  x2: newP2x - newP1x,
  y2: newP2y - newP1y,
};

assert.equal(updatedLine.x, 100);
assert.equal(updatedLine.y, 100);
assert.equal(updatedLine.x2, 200);
assert.equal(updatedLine.y2, 80);
pass("Line and Arrow endpoint (x2, y2) vector updates accurately during resize");

// ----------------------------------------------------------------------------
// 3. Rotated Element Resizing in Local Coordinate Space
// ----------------------------------------------------------------------------
console.log("\n[Test 3] Rotated Element Resizing along Local Axes...");

const rotRect: RectangleElement = {
  ...rectInside,
  id: "rot-rect",
  x: 100,
  y: 100,
  width: 100,
  height: 60,
  rotation: Math.PI / 2, // 90 deg clockwise
};

const rot = rotRect.rotation;
const cos = Math.cos(rot);
const sin = Math.sin(rot);

// Dragging handle 'e' in world space (+40px in Y direction corresponds to +40px in local X direction)
const worldDx = 0;
const worldDy = 40;
const localDx = worldDx * cos + worldDy * sin; // 0 * 0 + 40 * 1 = +40
const localDy = -worldDx * sin + worldDy * cos; // 0 + 0 = 0

assert.equal(Math.round(localDx), 40, "World Y displacement maps to local X displacement for 90-deg rotation");
assert.equal(Math.round(localDy), 0, "World X displacement maps to local Y displacement");

const origW = rotRect.width;
const origH = rotRect.height;
const origCx = rotRect.x + origW / 2;
const origCy = rotRect.y + origH / 2;

const newWidth = Math.max(origW + localDx, 20); // 140
const localShiftX = (newWidth - origW) / 2; // +20
const localShiftY = 0;

const worldShiftX = localShiftX * cos - localShiftY * sin; // 20 * 0 - 0 = 0
const worldShiftY = localShiftX * sin + localShiftY * cos; // 20 * 1 + 0 = 20

const newRotCx = origCx + worldShiftX;
const newRotCy = origCy + worldShiftY;

assert.equal(newWidth, 140, "Local width expanded along rotated X-axis");
assert.equal(Math.round(newRotCy), Math.round(origCy + 20), "Center translated along rotated orientation");
pass("Rotated element local coordinate space resize calculation verified");

// ----------------------------------------------------------------------------
// 4. Eraser Size Tolerance Hit-Testing
// ----------------------------------------------------------------------------
console.log("\n[Test 4] Continuous Eraser Size Tolerance Hit-Testing...");

const dotForEraser: StrokeElement = {
  id: "dot-eraser",
  type: "stroke",
  x: 50,
  y: 50,
  rotation: 0,
  opacity: 1,
  points: [[0, 0, 0.5]],
  color: "#000",
  strokeWidth: 2,
  strokeStyle: "pen",
  createdAt: Date.now(),
  updatedAt: Date.now(),
};

// Default threshold (8px) -> hit radius = 10px
assert.equal(hitTestElement(dotForEraser, 50, 60), true, "Hit at 10px with default tolerance");
assert.equal(hitTestElement(dotForEraser, 50, 65), false, "Miss at 15px with default tolerance");

// Eraser size slider set to 48px -> tolerance = 24px -> hit radius = 26px
const eraserTolerance = 24;
assert.equal(hitTestElement(dotForEraser, 50, 76, eraserTolerance), true, "Hit at 26px boundary with large eraser size");
assert.equal(hitTestElement(dotForEraser, 50, 77, eraserTolerance), false, "Miss at 27px outside large eraser size");
pass("Eraser size tolerance scaling directly influences stroke and object hit testing");

// ----------------------------------------------------------------------------
// 5. Smart Connector Selection & Duplication ID Remapping
// ----------------------------------------------------------------------------
console.log("\n[Test 5] Smart Connector Curve Hit-Testing & Duplication Remapping...");

const nodeA: RectangleElement = {
  id: "node-A",
  type: "rectangle",
  x: 100,
  y: 100,
  width: 100,
  height: 50,
  rotation: 0,
  opacity: 1,
  strokeColor: "#000",
  fillColor: "#fff",
  fillStyle: "solid",
  dashStyle: "solid",
  strokeWidth: 2,
  createdAt: Date.now(),
  updatedAt: Date.now(),
};

const nodeB: RectangleElement = {
  id: "node-B",
  type: "rectangle",
  x: 400,
  y: 100,
  width: 100,
  height: 50,
  rotation: 0,
  opacity: 1,
  strokeColor: "#000",
  fillColor: "#fff",
  fillStyle: "solid",
  dashStyle: "solid",
  strokeWidth: 2,
  createdAt: Date.now(),
  updatedAt: Date.now(),
};

const connectionStraight: ConnectionElement = {
  id: "conn-straight",
  type: "connection",
  x: 0,
  y: 0,
  rotation: 0,
  opacity: 1,
  source: { boardId: "board-1", elementId: "node-A", anchor: "right" },
  target: { boardId: "board-1", elementId: "node-B", anchor: "left" },
  linkType: "relates",
  routing: "straight",
  strokeWidth: 3,
  dashStyle: "solid",
  startArrowhead: "none",
  endArrowhead: "arrow",
  createdAt: Date.now(),
  updatedAt: Date.now(),
};

const allEls = [nodeA, nodeB, connectionStraight];

// Node A right port is (200, 125). Node B left port is (400, 125).
// Midpoint is (300, 125).
assert.equal(hitTestElement(connectionStraight, 300, 125, 8, allEls), true, "Hit test straight connection at midpoint");
assert.equal(hitTestElement(connectionStraight, 300, 133, 8, allEls), true, "Hit test straight connection within tolerance");
assert.equal(hitTestElement(connectionStraight, 300, 160, 8, allEls), false, "Miss straight connection far from path");
pass("Direct hit-testing of connection lines on canvas verified");

// Connection Curved hit-testing
const connectionCurved: ConnectionElement = {
  ...connectionStraight,
  id: "conn-curved",
  routing: "curved",
};
assert.equal(hitTestElement(connectionCurved, 300, 125, 8, [nodeA, nodeB, connectionCurved]), true, "Hit test curved connection");
pass("Curved connection bezier path hit-testing verified");

// Duplicate Board ID Remapping Test
const origBoard: Board = {
  id: "board-orig",
  name: "Original Architecture",
  folderId: null,
  camera: { x: 0, y: 0, zoom: 1 },
  elements: [nodeA, nodeB, connectionStraight],
  createdAt: Date.now(),
  updatedAt: Date.now(),
  accessedAt: Date.now(),
};

const idMap = new Map<string, string>();
for (const el of origBoard.elements) {
  idMap.set(el.id, `new-${el.id}`);
}

const duplicatedElements = origBoard.elements.map((el) => {
  const newId = idMap.get(el.id)!;
  if (el.type === "connection") {
    const conn = el as ConnectionElement;
    return {
      ...conn,
      id: newId,
      source: {
        ...conn.source,
        boardId: "board-copy",
        elementId: idMap.get(conn.source.elementId) || conn.source.elementId,
      },
      target: {
        ...conn.target,
        boardId: "board-copy",
        elementId: idMap.get(conn.target.elementId) || conn.target.elementId,
      },
      updatedAt: Date.now(),
    };
  }
  return {
    ...el,
    id: newId,
    updatedAt: Date.now(),
  };
});

const duplicatedConn = duplicatedElements.find((e) => e.type === "connection") as ConnectionElement;
assert.equal(duplicatedConn.source.elementId, "new-node-A", "Source elementId remapped to duplicated node ID");
assert.equal(duplicatedConn.target.elementId, "new-node-B", "Target elementId remapped to duplicated node ID");
assert.equal(duplicatedConn.source.boardId, "board-copy", "Source boardId remapped to new board ID");
assert.equal(duplicatedConn.target.boardId, "board-copy", "Target boardId remapped to new board ID");
pass("Board duplication remaps connection node IDs and board IDs completely");

// ----------------------------------------------------------------------------
// 6. Clipboard Image Paste Coordinate & Placement Tests
// ----------------------------------------------------------------------------
console.log("\n[Test 6] Clipboard Image Aspect Ratio & Placement Math...");

// Image aspect scaling logic test
const originalImgWidth = 1920;
const originalImgHeight = 1080;
const maxDim = 500;
let w = originalImgWidth;
let h = originalImgHeight;
const aspect = w / h;
if (w > maxDim || h > maxDim) {
  if (aspect >= 1) {
    w = maxDim;
    h = maxDim / aspect;
  } else {
    h = maxDim;
    w = maxDim * aspect;
  }
}

assert.equal(w, 500, "Image width clamped to max dimension 500px");
assert.equal(Math.round(h), Math.round(500 / (1920 / 1080)), "Image height scaled maintaining 16:9 aspect ratio");

// Coordinate centering test: place at cursor world coordinates
const cursorWorld = { x: 350, y: 250 };
const imagePlacedX = cursorWorld.x - w / 2;
const imagePlacedY = cursorWorld.y - h / 2;

assert.equal(imagePlacedX, 100, "Image placed centered at cursor X");
assert.equal(Math.round(imagePlacedY), Math.round(250 - h / 2), "Image placed centered at cursor Y");
pass("Clipboard image aspect ratio scaling and cursor-centered placement math verified");

console.log("\n===================================================================");
console.log(`=== ALL ${passCount} MILESTONE 2 (R2) TEST ASSERTIONS PASSED (100%) ===`);
console.log("===================================================================\n");
