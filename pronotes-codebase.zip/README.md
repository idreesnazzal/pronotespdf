# ProNotes

An infinite whiteboard **and** a paged notebook — one app, three ways to run it:
in a browser, as a Windows `.exe`, and as an Android `.apk`.

Everything is local. No server, no account, no internet required.

## Start here

| I want to... | Read |
|---|---|
| understand and run the project | **[HANDOFF.md](HANDOFF.md)** |
| find a particular file | **[MAP.md](MAP.md)** |
| know what to build next | [ROADMAP.md](ROADMAP.md) |

## Quick start

```bash
npm install
npm run dev       # http://localhost:3000
npm test          # 259 E2E tests + unit suites
```

## Building

```bash
npm run dist:win  # Windows installer + portable .exe
npm run apk       # Android APK
```

## One thing to know before editing

A board is either a canvas or a paged notebook. Never read `board.elements`
directly — use `getBoardElements()` / `allElements()` from
`src/lib/whiteboard/notebook.ts`. Reading the raw field returns **empty** for a
notebook, with no error, so the feature silently does nothing. See §2 of
[MAP.md](MAP.md).
