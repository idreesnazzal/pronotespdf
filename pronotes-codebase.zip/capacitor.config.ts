import type { CapacitorConfig } from "@capacitor/cli";

/**
 * Capacitor wraps the STATIC export (`npm run build:apk` -> ./out) into a
 * native Android app. Everything runs from files inside the APK, so the app
 * works with no server and no internet — boards live in the WebView's local
 * storage exactly as they do in the browser.
 */
const config: CapacitorConfig = {
  appId: "com.idrees.pronotes",
  appName: "ProNotes",
  webDir: "out",
  android: {
    // Keeps the drawing surface responsive to stylus/touch without the
    // browser's 300ms tap delay heuristics.
    allowMixedContent: false,
  },
  server: {
    androidScheme: "https",
  },
};

export default config;
