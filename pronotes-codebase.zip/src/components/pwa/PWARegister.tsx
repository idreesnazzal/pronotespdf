"use client";

/**
 * PWARegister Component
 * =====================
 * Registers the ProNotes Service Worker (/sw.js) - but ONLY where it helps -
 * and manages PWA install prompt lifecycle events.
 *
 * Where it must NOT run
 * ---------------------
 * - Inside the Android APK. Every file is already on the device, so it adds no
 *   offline ability, and it is actively harmful: sw.js is cache-first for
 *   static files, and `pdf.worker.min.mjs` has no content hash in its name.
 *   After an APK update that bumps pdf.js, the first PDF opened would get the
 *   OLD cached worker and fail with a version mismatch.
 * - In the Electron app (`pronotes://`): service workers need http(s).
 * - Under `npm run dev`: dev chunks are not hashed either, so cache-first
 *   serves the previous code after an edit.
 *
 * Where it is not wanted it is also UNREGISTERED and its caches deleted,
 * because APKs built before this change already installed one.
 */

import React, { useEffect } from "react";
import { Capacitor } from "@capacitor/core";

/** Cache names written by sw.js all start with this. */
const SW_CACHE_PREFIX = "pronotes-";

function serviceWorkerWanted(): boolean {
  if (typeof window === "undefined" || !("serviceWorker" in navigator)) return false;
  if (Capacitor.isNativePlatform()) return false;
  if (!/^https?:$/.test(window.location?.protocol ?? "")) return false;
  return process.env.NODE_ENV === "production";
}

/** Removes a service worker and its caches left by an earlier build. */
async function removeServiceWorker(): Promise<void> {
  try {
    if ("serviceWorker" in navigator) {
      const regs = await navigator.serviceWorker.getRegistrations();
      await Promise.all(regs.map((r) => r.unregister()));
      if (regs.length) console.log(`[PWA] Unregistered ${regs.length} service worker(s) - not used here.`);
    }
    if (typeof caches !== "undefined") {
      const keys = await caches.keys();
      await Promise.all(keys.filter((k) => k.startsWith(SW_CACHE_PREFIX)).map((k) => caches.delete(k)));
    }
  } catch (err) {
    console.warn("[PWA] Could not remove an old service worker:", err);
  }
}

// Global interface extension for BeforeInstallPromptEvent
declare global {
  interface WindowEventMap {
    beforeinstallprompt: BeforeInstallPromptEvent;
  }

  interface BeforeInstallPromptEvent extends Event {
    readonly platforms: string[];
    readonly userChoice: Promise<{
      outcome: "accepted" | "dismissed";
      platform: string;
    }>;
    prompt(): Promise<void>;
  }
}

export function PWARegister() {
  useEffect(() => {
    // 1. Register Service Worker - or remove one an older build left behind.
    if (!serviceWorkerWanted()) {
      void removeServiceWorker();
    } else {
      // This effect runs after React mounts, which is often AFTER the window
      // `load` event. Waiting for `load` unconditionally meant the worker was
      // frequently never registered at all.
      const register = () => {
        navigator.serviceWorker
          .register("/sw.js")
          .then((registration) => {
            console.log("[PWA] Service Worker registered with scope:", registration.scope);

            // Check for updates
            registration.onupdatefound = () => {
              const installingWorker = registration.installing;
              if (installingWorker) {
                installingWorker.onstatechange = () => {
                  if (installingWorker.state === "installed") {
                    if (navigator.serviceWorker.controller) {
                      console.log("[PWA] New content available; please refresh.");
                    } else {
                      console.log("[PWA] Content cached for offline use.");
                    }
                  }
                };
              }
            };
          })
          .catch((error) => {
            console.warn("[PWA] Service Worker registration failed:", error);
          });
      };
      if (document.readyState === "complete") register();
      else window.addEventListener("load", register, { once: true });
    }

    // 2. Intercept BeforeInstallPrompt
    const handleBeforeInstallPrompt = (e: BeforeInstallPromptEvent) => {
      // Store event on window for UI triggers
      (window as any).__PWA_INSTALL_PROMPT__ = e;
      window.dispatchEvent(new CustomEvent("pronotes:can-install"));
      console.log("[PWA] App is installable. Prompt captured.");
    };

    // 3. Handle App Installed
    const handleAppInstalled = () => {
      (window as any).__PWA_INSTALL_PROMPT__ = null;
      window.dispatchEvent(new CustomEvent("pronotes:installed"));
      console.log("[PWA] ProNotes was successfully installed!");
    };

    window.addEventListener("beforeinstallprompt", handleBeforeInstallPrompt);
    window.addEventListener("appinstalled", handleAppInstalled);

    return () => {
      window.removeEventListener("beforeinstallprompt", handleBeforeInstallPrompt);
      window.removeEventListener("appinstalled", handleAppInstalled);
    };
  }, []);

  return null;
}
