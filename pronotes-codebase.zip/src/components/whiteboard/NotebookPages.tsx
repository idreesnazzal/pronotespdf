"use client";

/**
 * Notebook page navigation
 * ========================
 * Two pieces: a compact page bar that is always visible in a notebook, and a
 * page panel you can open beside it.
 *
 * The panel was rebuilt for touch after it was tested on a Galaxy Tab S9:
 *
 *  - Most page actions only appeared on mouse HOVER (`opacity-0
 *    group-hover:opacity-100`). A tablet has no hover, so bookmark, insert and
 *    save-as-template were invisible, and the two that showed were 11 px icons.
 *    Every action now lives in an always-visible ⋯ menu with full-size items.
 *
 *  - Reordering was HTML5 drag-and-drop, which a finger cannot drive in an
 *    Android WebView, and its drop handler called `movePage(target, from)` -
 *    moving the page you dropped ONTO back to where you started. It only looked
 *    right for neighbours. Reorder is now a pointer drag on a grip, and it moves
 *    the page you are holding to where you let go.
 *
  *  - Thumbnails were grey bounding boxes, so every page of a handwritten or PDF
  *    notebook looked the same. They now draw the page's own paper, real ink
  *    and the PDF page.
 *
 *  - Deleting a page was one unconfirmed tap next to Duplicate, and page
 *    deletion is not undoable. It now asks, unless the page is empty.
 *
 *  - Going to a page kept the scroll offset of the page you left, so you often
 *    arrived half way down. It now shows the top of the page.
 */

import React from "react";
import { useTheme } from "next-themes";
import {
  ArrowDownToLine,
  ArrowUpToLine,
  Check,
  ChevronLeft,
  ChevronRight,
  Copy,
  GripVertical,
  ImagePlus,
  LayoutGrid,
  ListOrdered,
  MoreHorizontal,
  Plus,
  Save,
  Star,
  Trash2,
  X,
} from "lucide-react";
import { useWhiteboard, useActiveBoard } from "@/store/whiteboard";
import {
  bookmarkedPages,
  getActivePageIndex,
  getPages,
  isNotebook,
  pageSizeOf,
  paperForPage,
} from "@/lib/whiteboard/notebook";
import { PaperTiles, paperColorFor } from "./PaperPattern";
import {
  BOARD_PATTERNS,
  BOARD_PATTERN_DEFAULT_SIZE,
  BOARD_PATTERN_MAX_SIZE,
  BOARD_PATTERN_MIN_SIZE,
  type BoardPattern,
  type NotebookPage,
} from "@/lib/whiteboard/types";
import { StepperRow } from "./StepperControl";
import { storeImage } from "@/lib/whiteboard/imagestore";
import { ElementRenderer } from "./ElementRenderer";
import { PdfPageLayer } from "./PdfPageLayer";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { cn } from "@/lib/utils";

/** Width of the page panel. The page bar sits just to its right when open. */
export const PANEL_W = 212;

/** Press-and-hold this long (without moving) to pick a page card up for dragging. */
const HOLD_TO_DRAG_MS = 300;
/**
 * Moving further than this before the hold fires means a scroll, not a
 * pickup. Generous on purpose: a hand holding a tablet trembles, and every
 * cancelled hold is a drag that never starts.
 */
const HOLD_MOVE_PX = 24;
/** Dragging within this far of the panel's top/bottom edge scrolls it. */
const DRAG_SCROLL_EDGE_PX = 64;
const DRAG_SCROLL_STEP_PX = 24;

/** The canvas fills the window height closely enough to aim "page top" at. */
const viewportH = () => (typeof window !== "undefined" ? window.innerHeight : 800);

// ---------------------------------------------------------------------------
// Page bar
// ---------------------------------------------------------------------------

/**
 * The page panel's mount point. The compact controls that used to live here
 * too are now `NotebookPageControls`, rendered inside the tool dock.
 */
export function NotebookPagePanelHost() {
  const panelOpen = useWhiteboard((s) => s.pagePanelOpen);
  const setPagePanelOpen = useWhiteboard((s) => s.setPagePanelOpen);
  return panelOpen ? <PagePanel onClose={() => setPagePanelOpen(false)} /> : null;
}

/**
 * Which page you are on, and how to get to another one — sized and shaped to
 * sit INSIDE the tool dock, immediately beside the tools.
 *
 * It used to be a floating bar pinned to the bottom-left corner, which meant
 * it drifted into the dock on a narrow pane and needed a ResizeObserver that
 * measured both and lifted the bar out of the way. Living in the dock's own
 * row, it cannot collide with the dock: flexbox simply puts it alongside.
 *
 * There is no "add page" here. Adding is a deliberate, occasional act that
 * belongs with the other page management in the panel; what you want at the
 * edge of the canvas, constantly, is to know where you are and jump.
 */
export function NotebookPageControls() {
  const activeBoard = useActiveBoard();
  const goToPage = useWhiteboard((s) => s.goToPage);
  const panelOpen = useWhiteboard((s) => s.pagePanelOpen);
  const togglePagePanel = useWhiteboard((s) => s.togglePagePanel);

  const pages = getPages(activeBoard);
  const index = getActivePageIndex(activeBoard);

  // Typing a page number beats tapping "next" forty times in a long notebook.
  const [typing, setTyping] = React.useState(false);
  const [draft, setDraft] = React.useState("");
  const inputRef = React.useRef<HTMLInputElement>(null);
  React.useEffect(() => {
    if (typing) inputRef.current?.select();
  }, [typing]);

  if (!isNotebook(activeBoard) || pages.length === 0) return null;

  const atFirst = index <= 0;
  const atLast = index >= pages.length - 1;

  const go = (i: number) => {
    const target = pages[i];
    if (target) goToPage(target.id, viewportH());
  };

  const commit = () => {
    setTyping(false);
    const n = Number.parseInt(draft, 10);
    if (!Number.isFinite(n)) return;
    // Out-of-range is clamped rather than refused: "500" in a 30-page notebook
    // plainly means the end, and an error for that would be pedantry.
    go(Math.min(pages.length, Math.max(1, n)) - 1);
  };

  // Compact: it shares the dock's line with the tools, on their left. In a
  // narrow pane the arrows step aside (the number is tap-to-type, the grid
  // opens every page), so the tools keep the width.
  const arrowBtn =
    "flex h-8 w-6 @max-[40rem]:hidden items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-muted hover:text-foreground disabled:pointer-events-none disabled:opacity-40";

  return (
    <div className="flex shrink-0 items-center gap-0 rounded-2xl border border-border/80 bg-white/95 p-1 shadow-2xl backdrop-blur-xl dark:bg-zinc-900/95">
      <button
        onClick={togglePagePanel}
        title="All pages"
        aria-label="All pages"
        aria-pressed={panelOpen}
        className={cn(
          "flex h-8 w-8 items-center justify-center rounded-lg transition-colors",
          panelOpen ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-muted"
        )}
      >
        <LayoutGrid size={15} />
      </button>

      <span className="mx-0.5 h-5 w-px shrink-0 bg-border" />

      <button
        onClick={() => go(index - 1)}
        disabled={atFirst}
        title="Previous page"
        aria-label="Previous page"
        className={arrowBtn}
      >
        <ChevronLeft size={15} />
      </button>

      {typing ? (
        <input
          ref={inputRef}
          value={draft}
          onChange={(e) => setDraft(e.target.value.replace(/[^0-9]/g, ""))}
          onKeyDown={(e) => {
            e.stopPropagation(); // the canvas owns single-key shortcuts
            if (e.key === "Enter") commit();
            else if (e.key === "Escape") setTyping(false);
          }}
          onBlur={commit}
          type="text"
          inputMode="numeric"
          aria-label={`Page number, 1 to ${pages.length}`}
          className="h-8 w-[46px] rounded-lg border border-primary bg-transparent px-0.5 text-center text-[11px] font-semibold tabular-nums outline-none"
        />
      ) : (
        <button
          onClick={() => {
            setDraft(String(index + 1));
            setTyping(true);
          }}
          title="Go to page…"
          aria-label={`Page ${index + 1} of ${pages.length}. Go to page…`}
          className="h-8 min-w-[46px] rounded-lg px-0.5 text-center text-[11px] font-semibold tabular-nums text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
        >
          {index + 1} / {pages.length}
        </button>
      )}

      <button
        onClick={() => go(index + 1)}
        disabled={atLast}
        title="Next page"
        aria-label="Next page"
        className={arrowBtn}
      >
        <ChevronRight size={15} />
      </button>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Page panel
// ---------------------------------------------------------------------------

function PagePanel({ onClose }: { onClose: () => void }) {
  const activeBoard = useActiveBoard();
  const goToPage = useWhiteboard((s) => s.goToPage);
  const insertPageAt = useWhiteboard((s) => s.insertPageAt);
  const pageTemplates = useWhiteboard((s) => s.pageTemplates);
  const addPageFromTemplate = useWhiteboard((s) => s.addPageFromTemplate);
  const deletePageTemplate = useWhiteboard((s) => s.deletePageTemplate);
  const createImageTemplate = useWhiteboard((s) => s.createImageTemplate);
  const movePage = useWhiteboard((s) => s.movePage);
  const [tab, setTab] = React.useState<"all" | "fav">("all");
  const imageInputRef = React.useRef<HTMLInputElement>(null);

  const pages = getPages(activeBoard);
  const favourites = bookmarkedPages(activeBoard);
  const activeIndex = getActivePageIndex(activeBoard);
  const dim = pageSizeOf(activeBoard);
  const { resolvedTheme } = useTheme();

  // --- pointer-drag reorder --------------------------------------------------
  const cardRefs = React.useRef<Array<HTMLDivElement | null>>([]);
  const [drag, setDrag] = React.useState<{ from: number; to: number } | null>(null);

  const targetIndexFor = (clientY: number, from: number) => {
    // New position = how many OTHER cards have their middle above the pointer.
    let to = 0;
    cardRefs.current.forEach((el, i) => {
      if (!el || i === from) return;
      const r = el.getBoundingClientRect();
      if (r.top + r.height / 2 < clientY) to++;
    });
    return to;
  };

  const startDrag = (e: React.PointerEvent, from: number) => {
    e.preventDefault();
    try {
      (e.currentTarget as Element).setPointerCapture?.(e.pointerId);
    } catch {
      // Throws if the pointer is no longer active - a real race when a finger
      // lifts before the handler runs. Unguarded it aborted the drag before
      // it started; losing capture only costs moves outside the panel.
    }
    setDrag({ from, to: from });
  };
  const moveDrag = (e: React.PointerEvent) => {
    if (!drag) return;
    // Auto-scroll near the edges so a page can be dragged past the viewport:
    // without this a drag dies at the visible top/bottom and far positions
    // are unreachable. Nudged per move event; moves fire continuously mid-drag.
    const scroller = e.currentTarget as HTMLElement;
    const r = scroller.getBoundingClientRect();
    if (e.clientY < r.top + DRAG_SCROLL_EDGE_PX) scroller.scrollTop -= DRAG_SCROLL_STEP_PX;
    else if (e.clientY > r.bottom - DRAG_SCROLL_EDGE_PX)
      scroller.scrollTop += DRAG_SCROLL_STEP_PX;
    const to = targetIndexFor(e.clientY, drag.from);
    if (to !== drag.to) setDrag({ ...drag, to });
  };
  const endDrag = () => {
    if (drag && drag.to !== drag.from) movePage(pages[drag.from].id, drag.to);
    setDrag(null);
  };

  if (!activeBoard) return null;

  // Thumbnails keep the page's real proportions, so landscape looks landscape.
  const thumbW = PANEL_W - 40;
  const thumbH = Math.round((dim.height / dim.width) * thumbW);

  return (
    <div
      className="pointer-events-auto absolute bottom-0 left-0 top-0 z-50 flex flex-col border-r border-border/80 bg-white/95 shadow-2xl backdrop-blur-xl dark:bg-zinc-900/95"
      style={{ width: PANEL_W }}
    >
      <div className="flex items-center justify-between border-b border-border/60 px-3 py-2">
        <span className="text-[12px] font-semibold text-muted-foreground">
          {pages.length} page{pages.length === 1 ? "" : "s"}
        </span>
        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={onClose} title="Close">
          <X size={16} />
        </Button>
      </div>

      <div className="flex gap-1 border-b border-border/60 p-1.5">
        {([
          { id: "all", label: "Pages" },
          { id: "fav", label: `★ Favourites ${favourites.length}` },
        ] as const).map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={cn(
              "flex-1 rounded-lg px-1 py-1.5 text-[11px] font-medium transition-colors",
              tab === t.id ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-muted"
            )}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === "fav" && (
        <div className="flex-1 space-y-3 overflow-y-auto p-3">
          {favourites.length === 0 ? (
            <p className="px-1 py-4 text-center text-[12px] leading-snug text-muted-foreground">
              No favourite pages yet. Open a page&apos;s ⋯ menu and choose “Add to favourites”.
            </p>
          ) : (
            favourites.map(({ page, index }) => {
              const sheet = paperForPage(activeBoard, page);
              const sheetFill =
                paperColorFor(page.background ?? activeBoard?.background, resolvedTheme) ||
                (resolvedTheme === "dark" ? "#18181b" : "#ffffff");
              return (
              <button
                key={page.id}
                onClick={() => goToPage(page.id, viewportH())}
                title={`Go to page ${index + 1}`}
                className="block w-full text-left"
              >
                <div
                  className={cn(
                    "overflow-hidden rounded-lg border-2 bg-white dark:bg-zinc-800",
                    index === activeIndex ? "border-primary" : "border-border"
                  )}
                  style={{ height: thumbH }}
                >
                  <PageThumb
                    page={page}
                    dim={dim}
                    sheetPattern={sheet.pattern}
                    sheetSize={sheet.size}
                    sheetFill={sheetFill}
                  />
                </div>
                <span className="mt-1 block text-[11px] tabular-nums text-muted-foreground">
                  Page {index + 1}
                </span>
              </button>
              );
            })
          )}
        </div>
      )}

      {tab === "all" && (
        <div
          className="flex-1 overflow-y-auto p-3"
          onPointerMove={moveDrag}
          onPointerUp={endDrag}
          onPointerCancel={() => setDrag(null)}
        >
          {pages.map((page, i) => {
            const dropBefore = drag && drag.to === i && drag.from > i;
            const dropAfter = drag && drag.to === i && drag.from < i;
            return (
              <div key={page.id}>
                {dropBefore && <DropLine />}
                <PageCard
                  refCb={(el) => (cardRefs.current[i] = el)}
                  page={page}
                  index={i}
                  count={pages.length}
                  active={i === activeIndex}
                  dragging={drag?.from === i}
                  dim={dim}
                  thumbH={thumbH}
                  onOpen={() => goToPage(page.id, viewportH())}
                  onGripDown={(e) => startDrag(e, i)}
                  onHoldPickup={(i) => setDrag({ from: i, to: i })}
                />
                {dropAfter && <DropLine />}
              </div>
            );
          })}

          <button
            onClick={() => {
              insertPageAt(pages.length);
              const b = useWhiteboard.getState().boards.find((x) => x.id === activeBoard.id);
              if (b?.activePageId) goToPage(b.activePageId, viewportH());
            }}
            className="mt-1 flex w-full items-center justify-center gap-1.5 rounded-lg border-2 border-dashed border-border py-3.5 text-[12px] font-medium text-muted-foreground transition-colors hover:border-primary hover:text-primary"
          >
            <Plus size={16} /> Add page
          </button>

          {/* Template library: any saved page, or an imported image, becomes a
              sheet you can add again - the GoodNotes planner/worksheet pattern. */}
          <div className="mt-4 border-t border-border/60 pt-3">
            <div className="mb-2 flex items-center justify-between">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                Templates
              </span>
              <button
                onClick={() => imageInputRef.current?.click()}
                title="Use an image as a page template"
                aria-label="Import image as template"
                className="flex h-8 w-8 items-center justify-center rounded-lg text-muted-foreground hover:bg-muted hover:text-foreground"
              >
                <ImagePlus size={16} />
              </button>
            </div>

            <input
              ref={imageInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (!file) return;
                const reader = new FileReader();
                reader.onload = () => {
                  const src = String(reader.result);
                  const img = new Image();
                  img.onload = () => {
                    // Pixels to IndexedDB; the template keeps only a reference,
                    // since one template is reused on many pages.
                    storeImage(src).then((stored) =>
                      createImageTemplate(
                        file.name.replace(/\.[^.]+$/, ""),
                        stored,
                        img.naturalWidth,
                        img.naturalHeight
                      )
                    );
                  };
                  img.src = src;
                };
                reader.readAsDataURL(file);
                e.target.value = "";
              }}
            />

            {pageTemplates.length === 0 ? (
              <p className="text-[11px] leading-snug text-muted-foreground">
                Choose “Save as template” in a page&apos;s ⋯ menu, or import an image, to reuse it as a sheet.
              </p>
            ) : (
              <div className="space-y-1.5">
                {pageTemplates.map((t) => (
                  <div key={t.id} className="flex items-center gap-1">
                    <button
                      onClick={() => {
                        addPageFromTemplate(t.id, pages[activeIndex]?.id);
                        const b = useWhiteboard.getState().boards.find((x) => x.id === activeBoard.id);
                        if (b?.activePageId) goToPage(b.activePageId, viewportH());
                      }}
                      title={`Add a page from "${t.name}"`}
                      className="flex-1 truncate rounded-lg border border-border px-2 py-2 text-left text-[12px] transition-colors hover:border-primary hover:text-primary"
                    >
                      {t.name}
                    </button>
                    <button
                      onClick={() => {
                        if (window.confirm(`Delete the template “${t.name}”?`)) deletePageTemplate(t.id);
                      }}
                      title="Delete template"
                      aria-label={`Delete template ${t.name}`}
                      className="flex h-8 w-8 items-center justify-center rounded-lg text-muted-foreground hover:bg-muted hover:text-destructive"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function DropLine() {
  return <div className="my-1 h-1 rounded-full bg-primary" />;
}

// ---------------------------------------------------------------------------
// One page in the panel
// ---------------------------------------------------------------------------

function PageCard({
  refCb,
  page,
  index,
  count,
  active,
  dragging,
  dim,
  thumbH,
  onOpen,
  onGripDown,
  onHoldPickup,
}: {
  refCb: (el: HTMLDivElement | null) => void;
  page: NotebookPage;
  index: number;
  count: number;
  active: boolean;
  dragging: boolean;
  dim: { width: number; height: number };
  thumbH: number;
  onOpen: () => void;
  onGripDown: (e: React.PointerEvent) => void;
  onHoldPickup: (index: number) => void;
}) {
  const activeBoard = useActiveBoard();
  const insertPageAt = useWhiteboard((s) => s.insertPageAt);
  const goToPage = useWhiteboard((s) => s.goToPage);
  const duplicatePage = useWhiteboard((s) => s.duplicatePage);
  const deletePage = useWhiteboard((s) => s.deletePage);
  const movePage = useWhiteboard((s) => s.movePage);
  const togglePageBookmark = useWhiteboard((s) => s.togglePageBookmark);
  const setPageBackground = useWhiteboard((s) => s.setPageBackground);
  const savePageAsTemplate = useWhiteboard((s) => s.savePageAsTemplate);

  const pattern = page.background?.pattern ?? activeBoard?.background?.pattern ?? "dots";
  const rulingSize =
    page.background?.size ?? activeBoard?.background?.size ?? BOARD_PATTERN_DEFAULT_SIZE;

  // The Set-order dialog overlays the panel without unmounting it, so the
  // page list stays exactly where it was when the dialog closes.
  const [orderOpen, setOrderOpen] = React.useState(false);

  // The thumbnail wears the same paper as the canvas sheet (primitives, so
  // the memoised PageThumb below still skips re-renders when nothing changed).
  const { resolvedTheme } = useTheme();
  const sheet = paperForPage(activeBoard, page);
  const sheetFill =
    paperColorFor(page.background ?? activeBoard?.background, resolvedTheme) ||
    (resolvedTheme === "dark" ? "#18181b" : "#ffffff");

  /** Insert, then show the new page's top. */
  const insertAndShow = (at: number) => {
    insertPageAt(at);
    const b = useWhiteboard.getState().boards.find((x) => x.id === activeBoard?.id);
    if (b?.activePageId) goToPage(b.activePageId, viewportH());
  };

  const confirmDelete = () => {
    const n = page.elements.length + (page.pdf ? 1 : 0);
    // Page deletion is not undoable, so anything with content asks first.
    if (n === 0 || window.confirm(`Delete page ${index + 1}? It has content, and this can't be undone.`)) {
      deletePage(page.id);
    }
  };

  // Hold-to-pick-up: press and hold anywhere on the card, then drag to
  // reorder — the touch-friendly alternative to the small grip below. Moving
  // before the hold fires means a scroll, so the panel still scrolls from the
  // card. The grip and the ⋯ menu keep their own gestures (data-hold-ignore).
  const cardRef = React.useRef<HTMLDivElement | null>(null);
  const holdTimer = React.useRef<ReturnType<typeof setTimeout> | null>(null);
  const holdStart = React.useRef<{ x: number; y: number; pointerId: number } | null>(null);
  const suppressClick = React.useRef(false);

  const cancelHold = React.useCallback(() => {
    if (holdTimer.current) clearTimeout(holdTimer.current);
    holdTimer.current = null;
    holdStart.current = null;
  }, []);
  React.useEffect(() => cancelHold, [cancelHold]);

  return (
    <div
      ref={(el) => {
        cardRef.current = el;
        refCb(el);
      }}
      className={cn("mb-3", dragging && "opacity-40")}
      onPointerDown={(e) => {
        if (!e.isPrimary) return;
        if ((e.target as Element).closest?.("[data-hold-ignore]")) return;
        suppressClick.current = false;
        holdStart.current = { x: e.clientX, y: e.clientY, pointerId: e.pointerId };
        holdTimer.current = setTimeout(() => {
          holdTimer.current = null;
          const s = holdStart.current;
          holdStart.current = null;
          if (!s) return;
          // Capture so the finger drags the page instead of scrolling the
          // panel from here on; moves still bubble to the panel's move handler.
          try {
            cardRef.current?.setPointerCapture?.(s.pointerId);
          } catch {
            /* capture only helps; the drop works without it */
          }
          suppressClick.current = true;
          try {
            navigator.vibrate?.(15);
          } catch {
            /* haptic is a courtesy, never required */
          }
          onHoldPickup(index);
        }, HOLD_TO_DRAG_MS);
      }}
      onPointerMove={(e) => {
        const s = holdStart.current;
        if (s && Math.hypot(e.clientX - s.x, e.clientY - s.y) > HOLD_MOVE_PX) cancelHold();
      }}
      onPointerUp={cancelHold}
      onPointerCancel={cancelHold}
    >
      <button
        onClick={() => {
          // A hold that picked the page up is not a tap: swallow the click
          // that follows the release (a real drag also ends here, and must
          // not navigate away after reordering).
          if (suppressClick.current) {
            suppressClick.current = false;
            return;
          }
          onOpen();
        }}
        title={`Go to page ${index + 1}`}
        className={cn(
          "relative block w-full overflow-hidden rounded-lg border-2 bg-white transition-colors dark:bg-zinc-800",
          active ? "border-primary shadow-md" : "border-border hover:border-muted-foreground/50"
        )}
        style={{ height: thumbH }}
      >
        <PageThumb
          page={page}
          dim={dim}
          sheetPattern={sheet.pattern}
          sheetSize={sheet.size}
          sheetFill={sheetFill}
        />
        {page.bookmarked && (
          <Star size={14} className="absolute right-1.5 top-1.5 text-amber-500" fill="currentColor" />
        )}
      </button>

      <div className="mt-1 flex items-center gap-0.5">
        {/* Grip: press and drag to reorder. touch-action none so the finger
            drags the page instead of scrolling the panel. (Or press-and-hold
            anywhere on the card, then drag.) */}
        <span
          data-hold-ignore
          onPointerDown={onGripDown}
          title="Drag to reorder"
          aria-label={`Drag page ${index + 1} to reorder`}
          className="flex h-8 w-7 cursor-grab touch-none items-center justify-center rounded-md text-muted-foreground hover:bg-muted"
        >
          <GripVertical size={16} />
        </span>

        <span
          className={cn(
            "flex-1 text-[12px] tabular-nums",
            active ? "font-bold text-primary" : "text-muted-foreground"
          )}
        >
          {index + 1}
        </span>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button
              data-hold-ignore
              title="Page options"
              aria-label={`Options for page ${index + 1}`}
              className="flex h-8 w-8 items-center justify-center rounded-md text-muted-foreground hover:bg-muted hover:text-foreground"
            >
              <MoreHorizontal size={18} />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            <DropdownMenuLabel>Page {index + 1}</DropdownMenuLabel>
            <DropdownMenuItem className="py-2.5" onSelect={() => insertAndShow(index)}>
              <ArrowUpToLine size={16} className="mr-2" /> Insert page above
            </DropdownMenuItem>
            <DropdownMenuItem className="py-2.5" onSelect={() => insertAndShow(index + 1)}>
              <ArrowDownToLine size={16} className="mr-2" /> Insert page below
            </DropdownMenuItem>
            <DropdownMenuItem className="py-2.5" onSelect={() => duplicatePage(page.id)}>
              <Copy size={16} className="mr-2" /> Duplicate
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem className="py-2.5" onSelect={() => setOrderOpen(true)}>
              <ListOrdered size={16} className="mr-2" /> Set order…
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem className="py-2.5" onSelect={() => togglePageBookmark(page.id)}>
              <Star
                size={16}
                className={cn("mr-2", page.bookmarked && "text-amber-500")}
                fill={page.bookmarked ? "currentColor" : "none"}
              />
              {page.bookmarked ? "Remove from favourites" : "Add to favourites"}
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            {/* Paper directly in this menu — NOT a nested submenu radio group:
                submenu radios swallow taps in the Android WebView, so picking
                Grid there never reached the store while everything around it
                worked. Plain items fire onSelect reliably on touch; the check
                shows the page's current ruling. */}
            <DropdownMenuLabel>Paper</DropdownMenuLabel>
            {BOARD_PATTERNS.map((pt) => (
              <DropdownMenuItem
                key={pt.id}
                className="py-2.5"
                onSelect={() => setPageBackground(page.id, { pattern: pt.id })}
              >
                {pt.id === pattern ? (
                  <Check size={16} className="mr-2 text-primary" />
                ) : (
                  <span className="mr-2 inline-block w-4" aria-hidden />
                )}
                {pt.label}
              </DropdownMenuItem>
            ))}
            <DropdownMenuSeparator />
            <div className="flex items-center justify-between px-2 pb-1 pt-1.5">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                Ruling size
              </span>
              <span className="rounded-md bg-muted px-1.5 py-0.5 text-[11px] font-semibold tabular-nums">
                {rulingSize}px
              </span>
            </div>
            {/* Slider plus −/+ steppers, like the font-size control: drag for
                roughly, hold a stepper for exact. Plain controls, not menu
                items, so the menu stays open while you adjust. */}
            <div className="px-2 pb-1.5">
              <StepperRow
                value={rulingSize}
                min={BOARD_PATTERN_MIN_SIZE}
                max={BOARD_PATTERN_MAX_SIZE}
                onChange={(size) => setPageBackground(page.id, { size })}
              >
                <input
                  type="range"
                  min={BOARD_PATTERN_MIN_SIZE}
                  max={BOARD_PATTERN_MAX_SIZE}
                  value={rulingSize}
                  aria-label="Ruling size"
                  onChange={(e) => setPageBackground(page.id, { size: Number(e.target.value) })}
                  className="h-1.5 w-full cursor-pointer appearance-none rounded-lg bg-muted accent-primary"
                />
              </StepperRow>
            </div>
            <DropdownMenuSeparator />
            <DropdownMenuItem
              className="py-2.5"
              onSelect={() => savePageAsTemplate(page.id, `Page ${index + 1} template`)}
            >
              <Save size={16} className="mr-2" /> Save as template
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem
              className="py-2.5 text-destructive focus:text-destructive"
              onSelect={confirmDelete}
            >
              <Trash2 size={16} className="mr-2" /> Delete page…
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
      {/* Move-to-position: a tap-friendly number grid instead of repeated
          Move up/down taps (and of the fiddly drag on a tablet). The panel
          stays mounted behind the dialog. */}
      <Dialog open={orderOpen} onOpenChange={setOrderOpen}>
        <DialogContent className="max-w-xs">
          <DialogHeader>
            <DialogTitle>Move page {index + 1} to…</DialogTitle>
            <DialogDescription className="text-xs">
              Pick the position this page should move to.
            </DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-4 gap-2 py-1">
            {Array.from({ length: count }, (_, k) => (
              <button
                key={k}
                disabled={k === index}
                onClick={() => {
                  movePage(page.id, k);
                  setOrderOpen(false);
                }}
                aria-label={`Move to position ${k + 1}`}
                className={cn(
                  "h-11 rounded-lg border text-sm font-medium tabular-nums transition-colors",
                  k === index
                    ? "border-primary bg-primary/10 text-primary"
                    : "border-border hover:border-primary/50 hover:bg-muted"
                )}
              >
                {k + 1}
              </button>
            ))}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

/**
 * A real thumbnail: the page's own paper, ink and PDF page, scaled down.
 *
 * Memoised on the page object, which the store replaces whenever that page is
 * edited - so drawing on page 3 redraws page 3's thumbnail and no other. The
 * PDF raster is requested at the page width, the same key the canvas uses, so
 * it comes straight from the cache rather than being rendered twice.
 */
const PageThumb = React.memo(function PageThumb({
  page,
  dim,
  sheetPattern,
  sheetSize,
  sheetFill,
}: {
  page: NotebookPage;
  dim: { width: number; height: number };
  sheetPattern: BoardPattern;
  sheetSize: number;
  sheetFill: string;
}) {
  const thumbPatternId = `thumb-paper-${page.id}`;
  return (
    <svg
      width="100%"
      height="100%"
      viewBox={`0 0 ${dim.width} ${dim.height}`}
      preserveAspectRatio="xMidYMid meet"
      style={{ pointerEvents: "none" }}
    >
      <defs>
        <pattern
          id={thumbPatternId}
          x={0}
          y={0}
          width={sheetSize}
          height={sheetSize}
          patternUnits="userSpaceOnUse"
        >
          <PaperTiles pattern={sheetPattern} size={sheetSize} />
        </pattern>
      </defs>
      <rect x={0} y={0} width={dim.width} height={dim.height} fill={sheetFill} />
      {page.pdf && <PdfPageLayer pdf={page.pdf} width={dim.width} height={dim.height} />}
      {sheetPattern !== "plain" && (
        <rect
          x={0}
          y={0}
          width={dim.width}
          height={dim.height}
          fill={`url(#${thumbPatternId})`}
        />
      )}
      {page.elements.slice(0, 400).map((el) => (
        <ElementRenderer key={el.id} element={el} isSelected={false} />
      ))}
    </svg>
  );
});
