"use client";

/**
 * Laser pointer
 * =============
 * Points at the page without writing on it. Nothing here touches the board:
 * no element, no undo step, no save. It lives on its own canvas above the
 * board, in screen pixels, and only runs an animation loop while something is
 * visible.
 *
 * Points are kept in WORLD coordinates and projected with the live camera each
 * frame, so a circle you drew stays around the word it circles even if the
 * page scrolls while it fades.
 *
 * The canvas input code drives it through `laser` (down / move / up / hover);
 * the look comes from the laser settings in the style (mode, colour, size).
 */

import React, { useEffect, useRef } from "react";
import { useWhiteboard } from "@/store/whiteboard";
import { DEFAULT_STYLE } from "@/lib/whiteboard/types";
import { getActivePageIndex } from "@/lib/whiteboard/notebook";

interface LaserPoint {
  x: number;
  y: number;
  t: number;
}

/** How long each mode's tail lasts behind the dot. */
const TAIL_MS = { dot: 90, trail: 550 } as const;
/** "draw" lines take this long to fade out once their time is up. */
const DRAW_FADE_OUT_MS = 350;
/**
 * The hover dot disappears when the pen stops reporting for this long (it has
 * left hover range). A mouse stays put without reporting, and with the laser
 * the dot IS its cursor, so a mouse dot never times out - it goes on leave.
 */
const HOVER_TIMEOUT_MS = 1500;

const state = {
  /** Pointer currently pressing with the laser, if any. */
  pointerId: null as number | null,
  /** Recent points of the live pointer (tail for dot / trail). */
  tail: [] as LaserPoint[],
  /** "draw" mode: finished and live lines, kept until they fade together. */
  lines: [] as LaserPoint[][],
  /** When the last line was lifted; the fade counts from here. */
  liftedAt: 0,
  /** Where the dot is (pressing or hovering), and when it was last seen. */
  head: null as LaserPoint | null,
  /** The dot belongs to a hovering mouse: no timeout. */
  headSticky: false,
  wake: null as (() => void) | null,
};

function now() {
  return performance.now();
}

/** Imperative handle used by the canvas input handlers. */
export const laser = {
  isActive(pointerId: number) {
    return state.pointerId === pointerId;
  },
  down(pointerId: number, x: number, y: number) {
    const p = { x, y, t: now() };
    state.pointerId = pointerId;
    state.head = p;
    state.tail = [p];
    // A new line joins the ones still showing; they all fade together later.
    state.lines.push([p]);
    state.wake?.();
  },
  move(x: number, y: number) {
    const p = { x, y, t: now() };
    state.head = p;
    state.tail.push(p);
    state.lines[state.lines.length - 1]?.push(p);
    state.wake?.();
  },
  up(pointerId: number) {
    if (state.pointerId !== pointerId) return;
    state.pointerId = null;
    state.liftedAt = now();
    state.wake?.();
  },
  /** A hovering pen or mouse: the dot follows without drawing. */
  hover(x: number, y: number, pointerType = "pen") {
    if (state.pointerId !== null) return;
    state.head = { x, y, t: now() };
    state.headSticky = pointerType === "mouse";
    state.wake?.();
  },
  hideHover() {
    if (state.pointerId === null) state.head = null;
    state.wake?.();
  },
  /** Everything off at once (tool changed, pinch started). */
  clear() {
    state.pointerId = null;
    state.tail = [];
    state.lines = [];
    state.head = null;
    state.wake?.();
  },
};

/** Draws one polyline as a glowing beam: coloured halo, white-hot core. */
function beam(
  ctx: CanvasRenderingContext2D,
  pts: Array<{ x: number; y: number }>,
  color: string,
  width: number,
  alpha: number
) {
  if (pts.length === 0 || alpha <= 0) return;
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  const path = new Path2D();
  path.moveTo(pts[0].x, pts[0].y);
  // A lone point still shows: a zero-length round-capped line is a dot.
  if (pts.length === 1) path.lineTo(pts[0].x + 0.01, pts[0].y);
  for (let i = 1; i < pts.length; i++) {
    const a = pts[i - 1];
    const b = pts[i];
    path.quadraticCurveTo(a.x, a.y, (a.x + b.x) / 2, (a.y + b.y) / 2);
  }
  if (pts.length > 1) path.lineTo(pts[pts.length - 1].x, pts[pts.length - 1].y);
  ctx.shadowColor = color;
  ctx.shadowBlur = width * 1.6;
  ctx.strokeStyle = color;
  ctx.lineWidth = width;
  ctx.stroke(path);
  ctx.shadowBlur = 0;
  ctx.strokeStyle = "rgba(255,255,255,0.9)";
  ctx.lineWidth = Math.max(1, width * 0.34);
  ctx.stroke(path);
  ctx.restore();
}

/** The pointer itself: a glowing disc with a bright centre. */
function dot(ctx: CanvasRenderingContext2D, x: number, y: number, color: string, size: number, alpha = 1) {
  const r = size / 2;
  ctx.save();
  ctx.globalAlpha = alpha;
  const halo = ctx.createRadialGradient(x, y, 0, x, y, r * 2.6);
  halo.addColorStop(0, color);
  halo.addColorStop(0.35, color);
  halo.addColorStop(1, "rgba(0,0,0,0)");
  ctx.globalAlpha = alpha * 0.45;
  ctx.fillStyle = halo;
  ctx.beginPath();
  ctx.arc(x, y, r * 2.6, 0, Math.PI * 2);
  ctx.fill();
  ctx.globalAlpha = alpha;
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.arc(x, y, r, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "rgba(255,255,255,0.92)";
  ctx.beginPath();
  ctx.arc(x, y, r * 0.42, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

/**
 * The canvas the laser draws on. Mount it inside the board's container, above
 * the board; it never takes a pointer event.
 */
export function LaserLayer() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let raf = 0;
    let running = false;

    const frame = () => {
      raf = 0;
      const { camera, style } = useWhiteboard.getState();
      const color = style.laserColor ?? DEFAULT_STYLE.laserColor;
      const size = style.laserSize ?? DEFAULT_STYLE.laserSize;
      const mode = style.laserMode ?? DEFAULT_STYLE.laserMode;
      const holdMs = style.laserFadeMs ?? DEFAULT_STYLE.laserFadeMs;

      const dpr = window.devicePixelRatio || 1;
      const w = canvas.clientWidth;
      const h = canvas.clientHeight;
      if (canvas.width !== Math.round(w * dpr) || canvas.height !== Math.round(h * dpr)) {
        canvas.width = Math.round(w * dpr);
        canvas.height = Math.round(h * dpr);
      }
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, w, h);

      const toScreen = (p: { x: number; y: number }) => ({
        x: (p.x - camera.x) * camera.zoom + w / 2,
        y: (p.y - camera.y) * camera.zoom + h / 2,
      });

      const t = now();
      const pressing = state.pointerId !== null;
      let busy = pressing;

      if (mode === "draw") {
        // Lines stay while you keep drawing, then all fade together.
        let alpha = 1;
        if (!pressing && state.lines.length > 0) {
          const past = t - state.liftedAt - holdMs;
          alpha = past <= 0 ? 1 : 1 - past / DRAW_FADE_OUT_MS;
          if (alpha <= 0) {
            state.lines = [];
          } else {
            busy = true;
          }
        }
        for (const line of state.lines) beam(ctx, line.map(toScreen), color, size * 0.6, alpha);
        state.tail = [];
      } else {
        state.lines = [];
        // A tail that thins and fades towards its end.
        const life = TAIL_MS[mode];
        state.tail = state.tail.filter((p) => t - p.t < life);
        const tail = state.tail;
        if (tail.length > 1) {
          busy = true;
          const pts = tail.map(toScreen);
          for (let i = 1; i < pts.length; i++) {
            const k = 1 - (t - tail[i].t) / life; // 1 at the head, 0 at the end
            beam(ctx, [pts[i - 1], pts[i]], color, Math.max(1, size * 0.75 * k), k * 0.9);
          }
        }
      }

      // The dot: while pressing, or while a pen/mouse hovers with the laser.
      const head = state.head;
      if (head) {
        const stale = !pressing && !state.headSticky && t - head.t > HOVER_TIMEOUT_MS;
        if (stale) {
          state.head = null;
        } else {
          const s = toScreen(head);
          dot(ctx, s.x, s.y, color, pressing ? size : size * 0.8, pressing ? 1 : 0.85);
          busy = true;
        }
      }

      if (busy) raf = requestAnimationFrame(frame);
      else running = false;
    };

    const wake = () => {
      if (running) return;
      running = true;
      raf = requestAnimationFrame(frame);
    };
    state.wake = wake;

    // Which page of which note the points belong to. Points are in that
    // page's coordinates: on another note (split view) or after the notebook
    // re-anchors on the next page, they would land in the wrong place.
    const placeOf = (s: ReturnType<typeof useWhiteboard.getState>) => {
      const b = s.boards.find((x) => x.id === s.activeBoardId);
      return `${s.activeBoardId}:${b ? getActivePageIndex(b) : 0}`;
    };
    let place = placeOf(useWhiteboard.getState());
    // The camera moves the drawn lines; redraw when it does.
    const unsub = useWhiteboard.subscribe((s, prev) => {
      if (s.camera !== prev.camera) wake();
      // Put the laser down when another tool is picked.
      if (s.tool !== prev.tool && prev.tool === "laser") laser.clear();
      if (s.activeBoardId !== prev.activeBoardId || s.boards !== prev.boards) {
        const next = placeOf(s);
        if (next !== place) {
          place = next;
          laser.clear();
        }
      }
    });
    wake();

    return () => {
      unsub();
      if (raf) cancelAnimationFrame(raf);
      if (state.wake === wake) state.wake = null;
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      aria-hidden
      className="pointer-events-none absolute inset-0 h-full w-full"
      style={{ zIndex: 5 }}
    />
  );
}

/** The laser's tool-bar icon: a pointer pen with a beam and a lit spot. */
export function LaserIcon({ size = 18, className }: { size?: number; className?: string }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={2}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden
    >
      {/* body */}
      <path d="M3.5 20.5 12 12" />
      <path d="M2.8 18.4 5.6 21.2" />
      {/* beam */}
      <path d="M13.5 10.5 16 8" strokeDasharray="1.5 2.2" />
      {/* lit spot with rays */}
      <circle cx="18.5" cy="5.5" r="2" fill="currentColor" />
      <path d="M18.5 1.2v1.2M22.8 5.5h-1.2M21.6 2.4l-.85.85" />
    </svg>
  );
}
