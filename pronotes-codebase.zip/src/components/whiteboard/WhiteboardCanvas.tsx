"use client";

/**
 * Whiteboard Infinite Canvas (v4.2 — Clean Touchscreen & Single-Dot Precision)
 * ==============================================================================
 * Key Fixes:
 * - Single-tap dots (e.g. for letter dots, i/j, Hebrew niqqud, Arabic dots, periods)
 *   are preserved with exact radius and color (no more vanishing!).
 * - Removed annoying pinging ripple balls on tap.
 * - Multi-touch gestures: 2-finger pinch to zoom & 2-finger pan.
 * - 2-finger tap = Undo, 3-finger tap = Redo.
 * - Accurate container-relative coordinate tracking.
 */

import React, { useCallback, useEffect, useLayoutEffect, useRef, useState, useMemo } from "react";
import { LaserLayer, laser } from "./LaserPointer";
import { ShapeNoteChip, type ShapeNote } from "./ShapeAssist";
import { joinLine, lineBetween, recognizeShape, shapeLabel, type JoinTarget } from "@/lib/whiteboard/shapeRecognition";
import { usePdfTextSelect } from "./PdfTextSelect";
import { flushSync } from "react-dom";
import { nanoid } from "nanoid";
import { useWhiteboard, useActiveBoard } from "@/store/whiteboard";
import {
  DEFAULT_STYLE,
  BOARD_PATTERN_MAX_SIZE,
  BOARD_PATTERN_MIN_SIZE,
  isStrokeTool,
  getToolColor,
  getToolSize,
  type ArrowElement,
  type ConnectionElement,
  type EllipseElement,
  type ImageElement,
  type LineElement,
  type RectangleElement,
  type DiamondElement,
  type TriangleElement,
  type StarElement,
  type CloudElement,
  type StrokeElement,
  type StickyElement,
  type TextElement,
  type WhiteboardElement,
  type ToolType,
  type ResizeHandle,
  type NodeAnchor,
  type Camera,
  PEN_TYPE_PRESETS,
  type StrokeStyle,
} from "@/lib/whiteboard/types";
import {
  getElementBounds,
  getElementCenter,
  rotatePoint,
  getNodeAnchorPorts,
  getResolvedAnchorPoint,
  getConnectionPath,
  hitTestElement,
  HIT_THRESHOLD,
  isElementFullyInPolygon,
  isElementInPolygon,
  isPointInPolygon,
  screenToWorld,
  worldToScreen,
  type Viewport,
} from "@/lib/whiteboard/geometry";
import {
  buildStrokePath,
  calibratePressure,
  computePressureFromSpeed,
  eraseFromStroke,
  settledStrokePoints,
  isStrokeStraight,
  pruneTerminalHooks,
  straightenStrokePoints,
  trimHoldTail,
} from "@/lib/whiteboard/stroke";
import { ElementRenderer, StrokeFilterDefs } from "./ElementRenderer";
import { SelectionOverlay } from "./SelectionOverlay";
import { CanvasContextMenu } from "./CanvasContextMenu";
import { GRID_SIZE, snapToGrid, snapPointToGrid } from "@/lib/whiteboard/grid";
import {
  backgroundForPage,
  clampBoxToSheet,
  clampNotebookCamera,
  minNotebookZoom,
  clampToSheet,
  getActivePage,
  getActivePageIndex,
  getBoardElements,
  getPages,
  isNotebook,
  isOnActiveSheet,
  paperForPage,
  sheetIndexAt,
  PAGE_GAP,
  pageSizeOf,
} from "@/lib/whiteboard/notebook";
import { PaperTiles, paperColorFor } from "./PaperPattern";
import { PdfPageLayer } from "./PdfPageLayer";
import { placeImage, lockAspect, snapRotation, tapShapeRect, TAP_DRAG_SLOP_PX } from "@/lib/whiteboard/placement";
import { effectiveSelectFilter, passesSelectFilter, penFeelFor, pickableNow } from "@/lib/whiteboard/types";
import { deferSavesWhileWriting } from "@/lib/whiteboard/persistence";
import {
  CAPTURE_MIN_SIDE,
  boundsOfPoints,
  clampCaptureRegion,
  polygonArea,
  rectFromCorners,
  type CaptureShape,
} from "@/lib/whiteboard/capture";
import { screenshotShapeFor, useCapture } from "@/store/capture";
import { appClipForPaste } from "@/lib/whiteboard/appClipboard";
import { CaptureMarquee } from "./CaptureMarquee";

/** How far (screen px) a held pen may drift and still count as holding still. */
const HOLD_SLOP_PX = 6;
import { assetIdOf, isAssetRef, loadImage, storeImage } from "@/lib/whiteboard/imagestore";
import { isUndoCombo, isRedoCombo } from "@/lib/whiteboard/shortcuts";
import { stylusEraseTransition } from "@/lib/whiteboard/input";
import {
  classifyTouch,
  contactLooksLikePalm,
  exceedsLongPressSlop,
  shouldSelectOnTouchTap,
  LONG_PRESS_MS,
  PEN_FAST_BYPASS_MS,
} from "@/lib/whiteboard/palm";
import type { TouchVerdict } from "@/lib/whiteboard/palm";
import {
  cameraPanForScroll,
  createWheelDeviceState,
  observeWheel,
  resolveWheelAction,
  wheelSourceOf,
} from "@/lib/whiteboard/input";
import { useTheme } from "next-themes";


type InteractionMode =
  | { kind: "idle" }
  | { kind: "drawing"; elementId: string; tool: string }
  | { kind: "panning"; lastX: number; lastY: number }
  | { kind: "erasing" }
  | { kind: "selecting"; startX: number; startY: number; worldX: number; worldY: number }
  | { kind: "lasso-selecting"; points: Array<{ x: number; y: number }>; screenPoints: Array<{ x: number; y: number }>; strict: boolean }
  /** Drawing the area to capture: a box (first and last point) or a loop.
   *  Tied to ONE pointer, so a palm lifting mid-drag cannot end it. */
  | {
      kind: "capturing";
      shape: CaptureShape;
      pointerId: number;
      /** Begun by a finger: a pen arriving takes it over (a palm got there first). */
      byTouch?: boolean;
      points: Array<{ x: number; y: number }>;
    }
  | { kind: "moving"; startWorldX: number; startWorldY: number; originalElements: WhiteboardElement[] }
  | { kind: "resizing"; handle: ResizeHandle; originalElement: WhiteboardElement; startWorldX: number; startWorldY: number }
  | { kind: "rotating"; originalElement: WhiteboardElement; startAngle: number; centerX: number; centerY: number }
  | { kind: "creating-shape"; elementId: string; startX: number; startY: number }
  | {
      kind: "connecting";
      sourceElementId: string;
      sourceAnchor: NodeAnchor;
      currentWorldX: number;
      currentWorldY: number;
      targetElementId?: string;
      targetAnchor?: NodeAnchor;
    };

/**
 * How far outside a notebook sheet a press still counts as aimed at the page.
 *
 * World units, so it shrinks on screen as you zoom out — which is correct: at
 * low zoom the whole page is small and the surrounding desk is large, and you
 * want the desk to pan, not to absorb strokes.
 */
const SHEET_GRAB_MARGIN = 24;

// ---------------------------------------------------------------------------
// Fling (momentum) — platform values, not invented ones
// ---------------------------------------------------------------------------
// iOS UIScrollView: velocity decays by DecelerationRate.normal = 0.998 per
//   millisecond, so a throw travels about v0 * 0.998 / (1 - 0.998) = 499 * v0.
// Android ViewConfiguration: a fling starts at 50 dp/s and is capped at
//   8000 dp/s. Android's VelocityTracker only looks at the last 100 ms of
//   movement and treats a finger that has not moved for 40 ms as STOPPED.
//
// That last rule is what the first attempt here got wrong. It smoothed the
// velocity across the whole drag, so a drag you had already brought to a stop
// still launched when the finger lifted, and every ordinary scroll overshot.
// With the 40 ms rule, stop-then-lift scrolls exactly where you put it, and
// only a real throw coasts. (A WebView CSS pixel is one dp.)
const FLING_DECEL_PER_MS = 0.998;
const FLING_MIN_V = 0.05; // px/ms = 50 dp/s
const FLING_MAX_V = 8; // px/ms = 8000 dp/s
const FLING_STOP_V = 0.02; // px/ms: settled
const VELOCITY_HORIZON_MS = 100;
const POINTER_STOPPED_MS = 40;

/**
 * Where the camera has to be so the paper keeps the screen.
 * Shared by the settle-guard and the fling, so a throw stops at exactly the
 * edge the guard would enforce instead of fighting it frame by frame.
 *
 * The rule lives in notebook.ts (`clampNotebookCamera`): at most
 * `DESK_MARGIN_PX` of bare desk past the paper on any side. The earlier rule
 * here asked only that 120 px of the sheet stay somewhere on screen, which let
 * the page be shoved against one edge with most of a screenful of grey beside
 * it - a whole empty half-screen on a tablet in portrait.
 */
function clampCameraToSheet(
  cam: { x: number; y: number; zoom: number },
  vp: { width: number; height: number },
  page: { width: number; height: number },
  doc?: { pageCount: number; activeIndex: number }
): { x: number; y: number } {
  return clampNotebookCamera(cam, vp, page, doc);
}

interface LiveDraftStroke {
  id: string;
  originX: number;
  originY: number;
  color: string;
  strokeWidth: number;
  strokeStyle: StrokeStyle;
  smoothing: number;
  createdAt: number;
  points: Array<[number, number, number]>;
}

export function WhiteboardCanvas() {
  const svgRef = useRef<SVGSVGElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const [viewport, setViewport] = useState<Viewport>({ width: 1200, height: 800 });
  const [interaction, setInteraction] = useState<InteractionMode>({ kind: "idle" });
  const [draftElement, setDraftElement] = useState<WhiteboardElement | null>(null);
  const [rubberBand, setRubberBand] = useState<{ x: number; y: number; w: number; h: number } | null>(null);
  const [lassoPoints, setLassoPoints] = useState<Array<{ x: number; y: number }>>([]);
  const [spaceHeld, setSpaceHeld] = useState(false);

  // --- Direct DOM Live Inking Overlay Refs (R1-DEF-01, R1-DEF-02, R1-DEF-04, D5) ---
  const liveDraftStrokeRef = useRef<LiveDraftStroke | null>(null);
  const liveDraftGroupRef = useRef<SVGGElement | null>(null);
  const liveDraftPathRef = useRef<SVGPathElement | null>(null);
  const draftStrokeRafRef = useRef<number | null>(null);
  const drawingPointerIdRef = useRef<number | null>(null);
  const autoStraightenAnchorRef = useRef<{ x: number; y: number } | null>(null);
  const predictedPointsRef = useRef<Array<[number, number, number]>>([]);
  /** Last real (non-zero) pen pressure of the stroke in progress. */
  const lastPenPressureRef = useRef(0.5);
  const rejectedPalmsRef = useRef<Set<number>>(new Set());

  // Multi-touch tracking (finger pointers only — mouse/pen are never "fingers")
  const activeTouchesRef = useRef<Map<number, { x: number; y: number; startX: number; startY: number }>>(new Map());
  const pinchStartDistanceRef = useRef<number | null>(null);
  /** True once a gesture has been judged a pinch rather than a scroll. */
  const pinchEngagedRef = useRef(false);
  const pinchStartZoomRef = useRef<number>(1);
  const lastTouchMidRef = useRef<{ x: number; y: number } | null>(null);
  const touchStartTimeRef = useRef<number>(0);
  const maxTouchCountRef = useRef<number>(0);
  const touchMovedRef = useRef<boolean>(false);
  const lastTapRef = useRef<{ time: number; x: number; y: number }>({ time: 0, x: 0, y: 0 });
  const lastPointerPosRef = useRef<{ clientX: number; clientY: number } | null>(null);
  const penActiveRef = useRef<boolean>(false);
  /**
   * When the stylus was last in contact. Palm suppression outlives the pen —
   * the hand rests on the glass BEFORE the nib lands and stays there while you
   * lift between words, so a during-contact-only guard never sees it.
   */
  const lastPenAtRef = useRef<number>(0);
  /**
   * The selection a touch-started transform replaced, so that a stylus landing
   * a moment later can retract the whole thing: a hand that turns out to have
   * been a palm should leave no trace, not merely stop.
   */
  const touchInteractionRef = useRef<{ pointerId: number; priorSelection: string[] } | null>(null);
  /** Armed long-press-to-select (finger only). */
  const longPressRef = useRef<{
    timer: ReturnType<typeof setTimeout>;
    pointerId: number;
    elementId: string;
    startX: number;
    startY: number;
  } | null>(null);
  /**
   * Set when a long press has selected an object: the NEXT move event promotes
   * the pan into a drag, using that event's own world point as the origin so
   * the object cannot jump by however far the finger wobbled while holding.
   */
  const pendingMoveRef = useRef<{ pointerId: number; elementId: string } | null>(null);
  /**
   * Whether the canvas context menu may open. Radix opens it on a 700ms long
   * press for every pointer that is not a mouse, and its trigger sits on this
   * same <svg> — so a resting palm, or a stylus paused mid-thought, opened the
   * "Bring Forward / Send Backward / Delete" menu on its own. Disarming is
   * state rather than a ref because Radix reads the prop, and its own effect
   * cancels the pending timer the moment the prop flips.
   */
  const [contextMenuArmed, setContextMenuArmed] = useState(true);
  /** The coasting fling's frame, if one is running. */
  const momentumRafRef = useRef<number | null>(null);
  const contextMenuArmedRef = useRef(true);
  /** Tool to hand back when the stylus button is released. */
  const stylusEraseRestoreRef = useRef<ToolType | null>(null);
  // Previous eraser position, so a drag erases the swept path, not just points.
  const lastErasePosRef = useRef<{ x: number; y: number } | null>(null);
  // Read by the wheel listener, which is attached once.
  const cameraRef = useRef<Camera>({ x: 0, y: 0, zoom: 1 });
  const viewportRef = useRef<Viewport>({ width: 1200, height: 800 });
  // True when a gesture was sealed (committed) during the current touch
  // sequence — suppresses the 2/3-finger tap undo/redo for that sequence.
  const gestureSealedRef = useRef<boolean>(false);

  // Store
  const camera = useWhiteboard((s) => s.camera);
  const tool = useWhiteboard((s) => s.tool);
  const style = useWhiteboard((s) => s.style);
  const selectedIds = useWhiteboard((s) => s.selectedIds);
  // Membership test for the render loop. `selectedIds.includes` inside
  // `elements.map` is O(elements x selection) on EVERY render, and renders
  // happen on every pointer move while dragging a big selection.
  const selectedSet = useMemo(() => new Set(selectedIds), [selectedIds]);
  const editingId = useWhiteboard((s) => s.editingId);
  const touchSettings = useWhiteboard((s) => s.touchSettings);
  const snapToGridActive = useWhiteboard((s) => s.snapToGrid);
  const toggleSnapToGrid = useWhiteboard((s) => s.toggleSnapToGrid);
  const toggleMinimap = useWhiteboard((s) => s.toggleMinimap);
  const panCamera = useWhiteboard((s) => s.panCamera);
  const zoomTo = useWhiteboard((s) => s.zoomTo);
  const zoomToFit = useWhiteboard((s) => s.zoomToFit);
  const resetCamera = useWhiteboard((s) => s.resetCamera);
  const setCamera = useWhiteboard((s) => s.setCamera);
  const selectAll = useWhiteboard((s) => s.selectAll);
  const selectFilterSaved = useWhiteboard((s) => s.touchSettings.selectFilter);
  const selectFilter = useMemo(
    () => effectiveSelectFilter(selectFilterSaved),
    [selectFilterSaved]
  );
  const duplicateElements = useWhiteboard((s) => s.duplicateElements);
  const toggleLock = useWhiteboard((s) => s.toggleLock);
  const lockedMode = useWhiteboard((s) => s.lockedMode);
  const setImageStudioId = useWhiteboard((s) => s.setImageStudioId);
  const bringForward = useWhiteboard((s) => s.bringForward);
  const sendBackward = useWhiteboard((s) => s.sendBackward);
  const setTool = useWhiteboard((s) => s.setTool);
  const lastStrokeTool = useWhiteboard((s) => s.lastStrokeTool);
  const setSelected = useWhiteboard((s) => s.setSelected);
  const addToSelection = useWhiteboard((s) => s.addToSelection);
  const clearSelection = useWhiteboard((s) => s.clearSelection);
  const setEditingId = useWhiteboard((s) => s.setEditingId);
  const addElement = useWhiteboard((s) => s.addElement);
  const addElements = useWhiteboard((s) => s.addElements);
  const updateElement = useWhiteboard((s) => s.updateElement);
  const deleteElements = useWhiteboard((s) => s.deleteElements);
  const commitHistory = useWhiteboard((s) => s.commitHistory);
  const createConnection = useWhiteboard((s) => s.createConnection);
  const undo = useWhiteboard((s) => s.undo);
  const redo = useWhiteboard((s) => s.redo);
  const stepPage = useWhiteboard((s) => s.stepPage);
  const wheelDeviceRef = useRef(createWheelDeviceState());
  const activeBoardId = useWhiteboard((s) => s.activeBoardId);
  // Screenshot mode (Select menu): the select tool's box or loop takes a
  // picture of the area instead of selecting. Null whenever a press should do
  // what it always does - the mode is off, or the tool is not Select/Lasso.
  const screenshotMode = useCapture((s) => s.screenshotMode);
  const captureArmed = screenshotShapeFor(screenshotMode, tool);

  cameraRef.current = camera;
  viewportRef.current = viewport;

  const activeBoard = useActiveBoard();
  const elements = getBoardElements(activeBoard);

  // Notebook page geometry. The page lives in WORLD space from (0,0) to
  // (w,h), so all the existing tools, hit-testing and camera maths keep
  // working unchanged — a page is just a marked-out region of the canvas.
  const isNb = isNotebook(activeBoard);
  const activePage = getActivePage(activeBoard);
  const pageDim = pageSizeOf(activeBoard);
  const pageStride = pageDim.height + PAGE_GAP;
  const allPages = getPages(activeBoard);
  const activeIndex = getActivePageIndex(activeBoard);

  // The pages to draw around the active one. The active page sits at world
  // Y = 0 and its neighbours are offset by whole strides, so the notebook
  // reads as one continuous scroll while the coordinate system stays anchored.
  // Only what the viewport can reach is built — a 200-page notebook must not
  // render 200 sheets of ink on every frame.
  const neighbourPages = React.useMemo(() => {
    if (!isNb || allPages.length === 0) return [];
    const halfWorld = viewport.height / 2 / Math.max(camera.zoom, 0.01);
    const topY = camera.y - halfWorld;
    const bottomY = camera.y + halfWorld;
    const out: Array<{ id: string; index: number; offsetY: number }> = [];
    for (let i = 0; i < allPages.length; i++) {
      if (i === activeIndex) continue;
      const offsetY = (i - activeIndex) * pageStride;
      // Skip pages whose sheet is entirely outside the visible band.
      if (offsetY + pageDim.height < topY - pageStride) continue;
      if (offsetY > bottomY + pageStride) continue;
      out.push({ id: allPages[i].id, index: i, offsetY });
    }
    return out;
  }, [isNb, allPages, activeIndex, pageStride, pageDim.height, camera.y, camera.zoom, viewport.height]);

  // Board paper. An explicit colour wins; otherwise the theme's own background
  // shows through (no rect painted), so the board still follows light/dark.
  const { resolvedTheme } = useTheme();
  // A notebook page carries its own paper, falling back to the notebook's —
  // which is how one document can mix templates, the thing Notability is
  // criticised for not allowing.
  const paperSource = isNb
    ? backgroundForPage(activeBoard!, activePage) ?? activeBoard?.background
    : activeBoard?.background;
  const paperPattern = paperSource?.pattern ?? "dots";
  // Paper spacing. Snapping uses the SAME value, so the grid you snap to is
  // always the grid you can see — snapping to an invisible 24px lattice while
  // looking at 64px paper is disorienting.
  const paperSize = Math.min(
    BOARD_PATTERN_MAX_SIZE,
    Math.max(BOARD_PATTERN_MIN_SIZE, paperSource?.size ?? GRID_SIZE)
  );
  const paperColor = paperColorFor(paperSource, resolvedTheme);

  // Continuous scrolling. Once the viewport centre crosses the middle of the
  // gap between two sheets, the next page takes over as the anchored page and
  // the camera slides by exactly one stride to compensate — the two cancel, so
  // scrolling feels like one long strip while the coordinate system, and every
  // piece of code that depends on it, stays put.
  const reanchorPage = useWhiteboard((s) => s.reanchorPage);
  /**
   * Set when the PEN picked the live page (see the pointer-down handler).
   * While the camera has not moved since, the scroll rule below must not hand
   * the page back to whichever sheet is under the centre of the screen -
   * otherwise it switched back the moment you lifted the pen, clearing the
   * selection you had just made on the page you were working on.
   */
  const anchorLockRef = useRef<{ camY: number } | null>(null);
  useEffect(() => {
    if (!isNb || allPages.length <= 1) return;
    // Not mid-gesture: re-anchoring under an in-progress stroke would move the
    // world out from under the points already captured.
    if (interaction.kind !== "idle") return;
    if (anchorLockRef.current) {
      if (Math.abs(camera.y - anchorLockRef.current.camY) < 0.5) return;
      anchorLockRef.current = null; // you scrolled: centre-of-screen rules again
    }

    const forward = pageDim.height + PAGE_GAP / 2;
    const backward = -PAGE_GAP / 2;
    if (camera.y > forward && activeIndex < allPages.length - 1) {
      reanchorPage(1, pageStride);
    } else if (camera.y < backward && activeIndex > 0) {
      reanchorPage(-1, pageStride);
    }
  }, [camera.y, isNb, allPages.length, activeIndex, pageDim.height, pageStride, interaction.kind, reanchorPage]);

  // ---------------------------------------------------------------------
  // The active sheet may never leave the screen
  // ---------------------------------------------------------------------
  // A bound expressed as a fraction of PAGE height cannot do this job: what
  // counts as "off screen" depends on the viewport and the zoom, not on the
  // paper. Measured on a Galaxy Tab S9 the camera sat at world y = -1250 with
  // the sheet's top edge at screen y 1420 in a 1126-tall viewport — the page
  // was completely below the screen, on an empty grey desk, and because only
  // the anchored page is drawn there was nothing else to see or aim at.
  //
  // So the rule is stated in the terms that actually matter: after the camera
  // settles, at least `MIN_VISIBLE` of the active sheet must intersect the
  // viewport. If it does not, the camera is pulled back to the nearest
  // position where it does. This also repairs a camera restored from storage
  // that was already out of range.
  useEffect(() => {
    if (!isNb) return;
    if (interaction.kind !== "idle") return;      // never mid-gesture
    if (liveCamRef.current) return;               // nor mid-pan

    if (momentumRafRef.current !== null) return; // the fling stops itself

    // Zoom first: a camera restored from storage (or a window that just got
    // bigger) can sit below the floor, and no amount of panning fixes a page
    // that is simply too small for the screen it is on.
    const floor = minNotebookZoom(viewport, pageDim);
    if (floor > 0 && camera.zoom < floor - 1e-3) {
      zoomTo(floor, viewport.width / 2, viewport.height / 2, viewport);
      return; // the position is settled on the next pass, at the new zoom
    }

    // Keep the paper on screen, with only a small strip of desk around it.
    const next = clampCameraToSheet(camera, viewport, pageDim, {
      pageCount: allPages.length,
      activeIndex,
    });
    // Half a world unit of drift is invisible; correcting it anyway would be a
    // set -> re-render -> set loop if the store's own bound ever disagreed.
    if (Math.abs(next.y - camera.y) > 0.5 || Math.abs(next.x - camera.x) > 0.5) {
      setCamera(next);
    }
  }, [
    isNb,
    interaction.kind,
    camera.x,
    camera.y,
    camera.zoom,
    viewport.width,
    viewport.height,
    pageDim.width,
    pageDim.height,
    allPages.length,
    activeIndex,
    setCamera,
    zoomTo,
  ]);

  // ---------------------------------------------------------------------
  // "+" in the gap between two sheets (and above the first, below the last)
  // ---------------------------------------------------------------------
  // Hover the pen over the blank strip between two pages - or tap it - and a
  // "+" appears there; tapping it inserts a page in exactly that place, with
  // nothing above it moving (see insertPageAt in the store). GoodNotes'
  // equivalent lives in its thumbnail view; here it is where you are writing.
  //
  // Gap k sits just above page k in the anchored frame, so its centre is
  // (k - activeIndex) * stride - GAP/2 for every k from 0 (above the first
  // page) to allPages.length (below the last) - one formula for all three.
  const insertPageAt = useWhiteboard((s) => s.insertPageAt);
  const [gapPlus, setGapPlus] = useState<number | null>(null);
  const gapPlusRef = useRef<number | null>(null);
  const gapPlusTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const gapAt = useCallback(
    (wx: number, wy: number, extraPx = 0): number | null => {
      if (!isNb || allPages.length === 0) return null;
      const k = Math.round((wy + PAGE_GAP / 2) / pageStride) + activeIndex;
      if (k < 0 || k > allPages.length) return null;
      const cy = (k - activeIndex) * pageStride - PAGE_GAP / 2;
      // The gap ONLY - not the paper either side of it. A wider band showed
      // the "+" while the pen was over the edge of a page, and a press there
      // then added a page instead of writing. Measured at 44% zoom, the old
      // band reached 11 px into each sheet. `extraPx` widens it for a finger
      // TAP, which has no hover and is much less precise than a nib.
      // Half the seam plus a few SCREEN pixels. The seam is a hairline now, so
      // a band of `PAGE_GAP / 2` alone would be a couple of pixels and the "+"
      // would be unhittable; a band in world units would grow into the paper
      // as you zoom out, which is the bug the note above describes.
      const slack = PAGE_GAP / 2 + (6 + extraPx) / camera.zoom;
      if (Math.abs(wy - cy) > slack) return null;
      const side = 40 / camera.zoom;
      if (wx < -side || wx > pageDim.width + side) return null;
      return k;
    },
    [isNb, allPages.length, pageStride, activeIndex, camera.zoom, pageDim.width]
  );

  const isTouchPress = (e: { pointerType: string }) => e.pointerType === "touch";

  /** Show (k) or hide (null) the gap button, touching state only on change. */
  const showGapPlus = useCallback((k: number | null, holdMs = 0) => {
    if (gapPlusTimerRef.current) {
      clearTimeout(gapPlusTimerRef.current);
      gapPlusTimerRef.current = null;
    }
    if (k !== gapPlusRef.current) {
      gapPlusRef.current = k;
      setGapPlus(k);
    }
    // A finger has no hover, so a tap pins the button long enough to reach it.
    if (k !== null && holdMs > 0) {
      gapPlusTimerRef.current = setTimeout(() => {
        gapPlusTimerRef.current = null;
        gapPlusRef.current = null;
        setGapPlus(null);
      }, holdMs);
    }
  }, []);

  useEffect(
    () => () => {
      if (gapPlusTimerRef.current) clearTimeout(gapPlusTimerRef.current);
    },
    []
  );

  // Track exact viewport size with ResizeObserver
  useEffect(() => {
    if (!containerRef.current) return;
    /**
     * ONE place that records the canvas size, because there are two readers
     * and they must never disagree: this component (the camera bound) and the
     * store (the notebook zoom floor).
     *
     * The observer used to update only the local state, so the store kept
     * whatever size the canvas had when the app started. Hide the sidebar -
     * which the canvas resizes for, and the window does not - and the zoom
     * floor was still computed for the narrower canvas, letting a notebook
     * zoom out further than it should and leaving exactly the grey desk this
     * was meant to remove.
     */
    const apply = (width: number, height: number) => {
      if (!(width > 0) || !(height > 0)) return;
      setViewport({ width, height });
      useWhiteboard.getState().setCanvasViewport({ width, height });
    };
    const updateSize = () => {
      if (containerRef.current) {
        const rect = containerRef.current.getBoundingClientRect();
        apply(rect.width, rect.height);
      }
    };
    updateSize();

    const observer = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const { width, height } = entry.contentRect;
        apply(width, height);
      }
    });

    observer.observe(containerRef.current);
    window.addEventListener("resize", updateSize);
    return () => {
      observer.disconnect();
      window.removeEventListener("resize", updateSize);
    };
  }, []);

  // Keyboard shortcuts
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (editingId) return;

      // Ignore shortcuts if focused on input-ish elements — including BUTTON:
      // Space must keep activating a focused toolbar button, not arm pan mode.
      const activeEl = e.target as HTMLElement | null;
      const interactive =
        !!activeEl &&
        (activeEl.tagName === "INPUT" ||
          activeEl.tagName === "TEXTAREA" ||
          activeEl.tagName === "BUTTON" ||
          activeEl.tagName === "SELECT" ||
          activeEl.isContentEditable ||
          activeEl.closest?.('[role="button"], [role="slider"]'));
      if (interactive) {
        // Only Space matters here (button activation is native); everything
        // else falls through so Ctrl+Z etc. still work while a button has focus.
        if (e.code === "Space") return;
      }
      if (activeEl && (activeEl.tagName === "INPUT" || activeEl.tagName === "TEXTAREA" || activeEl.isContentEditable)) {
        return;
      }

      // Never run canvas shortcuts while any modal overlay is open — Radix
      // dialogs focus a plain DIV, and GraphView/LinkManager/etc. are custom
      // overlays tagged with [data-wb-modal].
      if (
        typeof document !== "undefined" &&
        document.querySelector('[role="dialog"][data-state="open"], [data-wb-modal]')
      ) {
        return;
      }

      if (e.code === "Space" && !spaceHeld) {
        e.preventDefault();
        setSpaceHeld(true);
      }

      if (e.key === "Delete" || e.key === "Backspace") {
        if (selectedIds.length > 0) {
          e.preventDefault();
          deleteElements(selectedIds, true);
        }
      }

      // Undo/redo must not fire mid-gesture: the running move/resize loop
      // would re-apply itself over the undone snapshot and desync history.
      //
      // Match on e.code, not e.key: e.key carries the SHIFTED/caps character,
      // so Ctrl+Shift+Z arrives as "Z" and never matched `e.key === "z"` —
      // the documented redo combo was dead, and Ctrl+Z itself stopped undoing
      // with Caps Lock on. e.code is the physical key and is layout-stable.
      if (isUndoCombo(e)) {
        e.preventDefault();
        if (interaction.kind === "idle") undo();
        return;
      }
      if (isRedoCombo(e)) {
        e.preventDefault();
        if (interaction.kind === "idle") redo();
        return;
      }

      // Page turns in a notebook. PageUp/PageDown are what every reader and
      // note app uses; the bracket pair gives a one-hand alternative on
      // keyboards where the tablet's cover has no PageUp.
      if (isNb && !e.ctrlKey && !e.metaKey && !e.altKey) {
        if (e.code === "PageUp" || (e.shiftKey && e.code === "BracketLeft")) {
          e.preventDefault();
          if (interaction.kind === "idle") stepPage(-1);
          return;
        }
        if (e.code === "PageDown" || (e.shiftKey && e.code === "BracketRight")) {
          e.preventDefault();
          if (interaction.kind === "idle") stepPage(1);
          return;
        }
      }

      // Ctrl/Cmd + A -> Select all
      if ((e.ctrlKey || e.metaKey) && e.code === "KeyA") {
        e.preventDefault();
        selectAll();
        return;
      }

      // Ctrl/Cmd + D -> Duplicate selection (must preventDefault or the
      // browser opens its bookmark dialog)
      if ((e.ctrlKey || e.metaKey) && e.code === "KeyD" && !e.shiftKey) {
        e.preventDefault();
        if (selectedIds.length > 0) duplicateElements(selectedIds);
        return;
      }

      // Ctrl/Cmd + Shift + L -> Lock / unlock selection
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.code === "KeyL") {
        e.preventDefault();
        if (selectedIds.length > 0) toggleLock(selectedIds);
        return;
      }

      // Layering: Ctrl+] / Ctrl+[ (also Ctrl+Shift+] style variants)
      if ((e.ctrlKey || e.metaKey) && (e.key === "]" || e.key === "[")) {
        e.preventDefault();
        if (selectedIds.length > 0) {
          if (e.key === "]") bringForward(selectedIds);
          else sendBackward(selectedIds);
        }
        return;
      }

      // Zoom: Ctrl+0 reset, Ctrl+= in, Ctrl+- out, Shift+1 fit
      if ((e.ctrlKey || e.metaKey) && e.code === "Digit0") {
        e.preventDefault();
        resetCamera();
        return;
      }
      if ((e.ctrlKey || e.metaKey) && (e.code === "Equal" || e.key === "+")) {
        e.preventDefault();
        zoomTo(camera.zoom * 1.2, viewport.width / 2, viewport.height / 2, viewport);
        return;
      }
      if ((e.ctrlKey || e.metaKey) && e.code === "Minus") {
        e.preventDefault();
        zoomTo(camera.zoom / 1.2, viewport.width / 2, viewport.height / 2, viewport);
        return;
      }
      if (e.shiftKey && e.code === "Digit1") {
        e.preventDefault();
        zoomToFit(viewport);
        return;
      }

      // Ctrl/Cmd + Shift + G -> Snap to grid toggle
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && (e.code === "KeyG" || e.key.toLowerCase() === "g")) {
        e.preventDefault();
        toggleSnapToGrid();
      }

      // Ctrl/Cmd + E -> Export Board
      if ((e.ctrlKey || e.metaKey) && e.code === "KeyE") {
        e.preventDefault();
        window.dispatchEvent(new CustomEvent("wb:open-export"));
      }

      // Ctrl/Cmd + / -> Keyboard Shortcuts
      if ((e.ctrlKey || e.metaKey) && (e.code === "Slash" || e.key === "/")) {
        e.preventDefault();
        window.dispatchEvent(new CustomEvent("wb:open-shortcuts"));
      }

      // Ctrl/Cmd + Shift + D -> Theme Toggle
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && (e.code === "KeyD" || e.key.toLowerCase() === "d")) {
        e.preventDefault();
        window.dispatchEvent(new CustomEvent("wb:toggle-theme"));
      }

      if (!e.ctrlKey && !e.metaKey && !e.altKey) {
        if (e.key === "?") {
          e.preventDefault();
          window.dispatchEvent(new CustomEvent("wb:open-shortcuts"));
          return;
        }

        switch (e.code) {
          case "KeyV": setTool("select"); break;
          case "KeyQ": setTool("lasso"); break;
          case "KeyP": setTool(lastStrokeTool ?? "gel"); break;
          case "KeyH": setTool("pan"); break;
          case "KeyK": setTool("laser"); break;
          case "KeyI": setTool("textselect"); break;
          case "KeyY": setTool("highlighter"); break;
          case "KeyE": setTool("eraser"); break;
          case "KeyR": setTool("rectangle"); break;
          case "KeyO": setTool("ellipse"); break;
          case "KeyD": setTool("diamond"); break;
          case "KeyL": setTool("line"); break;
          case "KeyA": setTool("arrow"); break;
          case "KeyT": setTool("text"); break;
          case "KeyN": setTool("sticky"); break;
          case "KeyC": setTool("connect"); break;
          case "KeyM":
            e.preventDefault();
            toggleMinimap();
            break;
          case "KeyS":
            e.preventDefault();
            toggleSnapToGrid();
            break;
          case "Escape":
            // Cancel any active interaction first (draft discarded, overlays
            // cleared), then deselect / exit editor / return to select tool.
            setInteraction({ kind: "idle" });
            setDraftElement(null);
            setRubberBand(null);
            clearSelection();
            setEditingId(null);
            setTool("select");
            break;
        }
      }
    };

    const onKeyUp = (e: KeyboardEvent) => {
      if (e.code === "Space") {
        setSpaceHeld(false);
      }
    };

    // If the window loses focus mid-shortcut (alt-tab while Space held),
    // keyup never fires — clear the held state so the canvas isn't stuck panning.
    const onBlur = () => setSpaceHeld(false);

    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup", onKeyUp);
    window.addEventListener("blur", onBlur);
    return () => {
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
      window.removeEventListener("blur", onBlur);
    };
  }, [
    editingId,
    spaceHeld,
    selectedIds,
    interaction,
    camera.zoom,
    viewport,
    deleteElements,
    undo,
    redo,
    stepPage,
    isNb,
    selectAll,
    duplicateElements,
    toggleLock,
    bringForward,
    sendBackward,
    zoomTo,
    zoomToFit,
    resetCamera,
    setTool,
    clearSelection,
    setEditingId,
    toggleSnapToGrid,
    toggleMinimap,
  ]);

  // Precision Coordinate Calculation (Subtracts Container Left/Top)
  const getContainerPoint = useCallback(
    (clientX: number, clientY: number) => {
      const rect = containerRef.current?.getBoundingClientRect();
      if (!rect) {
        return { x: clientX, y: clientY, width: viewport.width, height: viewport.height };
      }
      return {
        x: clientX - rect.left,
        y: clientY - rect.top,
        width: rect.width,
        height: rect.height,
      };
    },
    [viewport]
  );

  const getWorldPoint = useCallback(
    (clientX: number, clientY: number) => {
      const pt = getContainerPoint(clientX, clientY);
      return screenToWorld(pt.x, pt.y, camera, { width: pt.width, height: pt.height });
    },
    [getContainerPoint, camera]
  );

  // The Select-text tool: hit-tests the page's text from these handlers, so
  // no layer ever sits over the page (see PdfTextSelect.tsx).
  const textSelect = usePdfTextSelect({
    tool,
    board: activeBoard,
    isNb,
    activePage,
    activeIndex,
    pageDim,
    camera,
    viewport,
    getWorldPoint,
    addElements,
    setCamera,
  });

  // ---------------------------------------------------------------------
  // Ink stays on the paper (notebooks only)
  // ---------------------------------------------------------------------
  // A whiteboard is deliberately unbounded. A notebook is a stack of sheets,
  // and writing beside a sheet or in the dead gap between two of them produced
  // ink that was saved but never printed, never exported and impossible to
  // find again once you scrolled. So in a notebook every point that becomes
  // CONTENT is clamped to the active sheet, while `getWorldPoint` stays honest
  // for panning, hit-testing and the marquee — those must still work off-page.

  /** A world point clamped onto the sheet, for anything that creates content. */
  const getInkPoint = useCallback(
    (clientX: number, clientY: number) => {
      const wp = getWorldPoint(clientX, clientY);
      if (!isNb) return wp;
      return clampToSheet(wp.x, wp.y, pageDim.width, pageDim.height);
    },
    [getWorldPoint, isNb, pageDim.width, pageDim.height]
  );

  /**
   * May a content gesture START here?
   *
   * Beginning a stroke off-page and clamping it would draw a phantom line
   * pinned to the margin that the user never asked for, so an off-page press
   * pans instead — the same thing GoodNotes does. The margin is generous
   * because a press a few units outside the border is plainly aimed at the
   * page, and snapping that back is helpful rather than surprising.
   */
  const canStartInkAt = useCallback(
    (wx: number, wy: number) =>
      !isNb || isOnActiveSheet(wx, wy, pageDim.width, pageDim.height, SHEET_GRAB_MARGIN),
    [isNb, pageDim.width, pageDim.height]
  );

  // ---------------------------------------------------------------------
  // Inserting an image — ONE way in, for the toolbar button and paste alike
  // ---------------------------------------------------------------------
  // The toolbar used to drop an image at camera.x/y, up to 500 units wide,
  // with no idea a page existed, and left it UNselected with the pen still
  // active: it landed "in a random place", and touching it drew on it instead
  // of moving it. Now it goes in the middle of what you can see, sized to fit,
  // fully on the paper (lib/whiteboard/placement.ts), comes in SELECTED with
  // the Select tool active so it can be dragged, resized and rotated straight
  // away, and its pixels go to IndexedDB rather than into the saved notes.
  const insertImage = (
    dataUrl: string,
    at: { x: number; y: number } | null,
    opts: {
      /** Several pictures at once fan out instead of landing on each other. */
      stagger?: number;
      /** A picture already in the store: reuse it rather than store it twice. */
      keepSrc?: string;
      /** Open the image editor straight away (a fresh camera photo). */
      edit?: boolean;
      /**
       * The size it should have on the page, in world units - a capture is
       * rendered at 2-3x its size, and placing it by its pixels would paste
       * it back two or three times larger than what was captured.
       */
      size?: { width: number; height: number };
    } = {}
  ) => {
    // A paste aimed at the sheet above or below the live one goes onto that
    // sheet, not squeezed onto the edge of the live page.
    if (at && isNb && allPages.length > 1) {
      const target = sheetIndexAt(at.x, at.y, activeIndex, allPages.length, pageDim.width, pageDim.height);
      if (target !== null && target !== activeIndex) {
        const delta = target - activeIndex;
        anchorLockRef.current = { camY: cameraRef.current.y - delta * pageStride };
        reanchorPage(delta, pageStride);
        at = { x: at.x, y: at.y - delta * pageStride };
      }
    }
    const img = new Image();
    img.onload = () => {
      const rect = placeImage({
        naturalWidth: opts.size?.width || img.naturalWidth || 400,
        naturalHeight: opts.size?.height || img.naturalHeight || 300,
        camera: cameraRef.current,
        viewport: viewportRef.current,
        page: isNb ? pageDim : null,
        at,
      });
      const imageId = nanoid(8);
      const fan = (opts.stagger ?? 0) * (28 / (cameraRef.current.zoom || 1));
      const newImage: ImageElement = {
        id: imageId,
        type: "image",
        x: rect.x + fan,
        y: rect.y + fan,
        width: rect.width,
        height: rect.height,
        naturalWidth: img.naturalWidth || rect.width,
        naturalHeight: img.naturalHeight || rect.height,
        rotation: 0,
        opacity: 1,
        // Replaced by an asset: reference once the pixels are in IndexedDB.
        src: opts.keepSrc ?? dataUrl,
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };
      addElement(newImage, true);
      setTool("select");
      setSelected([imageId]);
      if (opts.edit) setImageStudioId(imageId);
      if (opts.keepSrc) return;
      storeImage(dataUrl).then((src) => {
        if (src !== dataUrl) updateElement(imageId, { src } as never, false);
      });
    };
    img.src = dataUrl;
  };
  const insertImageRef = useRef(insertImage);
  insertImageRef.current = insertImage;

  // The toolbar's "add image" button hands the picked file over here, because
  // only the canvas knows the viewport and the page it has to fit.
  useEffect(() => {
    const onInsert = (e: Event) => {
      const d = (
        e as CustomEvent<{
          dataUrl?: string;
          index?: number;
          edit?: boolean;
          size?: { width: number; height: number };
        }>
      ).detail;
      const dataUrl = d?.dataUrl;
      if (!dataUrl) return;
      const opts = { stagger: d.index ?? 0, edit: !!d.edit, size: d.size };
      if (isAssetRef(dataUrl)) {
        // "Use again" from the image sheet: measure the stored pixels, keep the reference.
        loadImage(assetIdOf(dataUrl)).then((pixels) => {
          if (pixels) insertImageRef.current(pixels, null, { ...opts, keepSrc: dataUrl });
        });
        return;
      }
      insertImageRef.current(dataUrl, null, opts);
    };
    window.addEventListener("pronotes:insertimage", onInsert);
    return () => window.removeEventListener("pronotes:insertimage", onInsert);
  }, []);

  // Clipboard Image Paste Handler
  useEffect(() => {
    const onPaste = (e: ClipboardEvent) => {
      const activeEl = document.activeElement;
      const isInput =
        activeEl?.tagName === "INPUT" ||
        activeEl?.tagName === "TEXTAREA" ||
        activeEl?.getAttribute("contenteditable") === "true";

      if (isInput) return;

      const items = e.clipboardData?.items;
      const hasImage = !!items && Array.from(items).some((it) => it.type.startsWith("image/"));
      // No picture on the system clipboard, but a capture copied here that the
      // system refused (the Android WebView does): paste that. Ours is only
      // used when the system never got it, so it cannot shadow a newer copy.
      if (!hasImage) {
        const clip = appClipForPaste();
        if (clip) {
          e.preventDefault();
          insertImageRef.current(clip.dataUrl, null, { size: clip.worldSize });
        }
        return;
      }
      if (!items) return;

      for (let i = 0; i < items.length; i++) {
        const item = items[i];
        if (item.type.startsWith("image/")) {
          e.preventDefault();
          const file = item.getAsFile();
          if (!file) continue;

          const reader = new FileReader();
          reader.onload = (event) => {
            const dataUrl = event.target?.result as string;
            if (!dataUrl) return;

            // Paste goes where the pointer is, if it is over the canvas.
            let at: { x: number; y: number } | null = null;
            if (lastPointerPosRef.current && containerRef.current) {
              const rect = containerRef.current.getBoundingClientRect();
              const { clientX, clientY } = lastPointerPosRef.current;
              if (
                clientX >= rect.left &&
                clientX <= rect.right &&
                clientY >= rect.top &&
                clientY <= rect.bottom
              ) {
                at = getWorldPoint(clientX, clientY);
              }
            }
            insertImageRef.current(dataUrl, at);
          };
          reader.readAsDataURL(file);
          break;
        }
      }
    };

    window.addEventListener("paste", onPaste);
    return () => {
      window.removeEventListener("paste", onPaste);
    };
  }, [camera, getWorldPoint, addElement, setSelected]);

  // Wheel zoom and pan.
  //
  // Attached as a NON-PASSIVE native listener rather than React's onWheel:
  // React registers wheel handlers passively, so preventDefault() inside
  // onWheel is silently ignored (the console fills with "Unable to
  // preventDefault inside passive event listener invocation"). Without it, a
  // trackpad pinch or Ctrl+wheel zooms the whole BROWSER PAGE on top of the
  // canvas.
  useEffect(() => {
    const node = containerRef.current;
    if (!node) return;

    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      // Decide the DEVICE across a run of events and hold that decision, so a
      // single ambiguous event mid-gesture cannot flip scrolling into zooming.
      wheelDeviceRef.current = observeWheel(wheelDeviceRef.current, {
        deltaX: e.deltaX,
        deltaY: e.deltaY,
        deltaMode: e.deltaMode,
        time: e.timeStamp || Date.now(),
      });
      const source = wheelSourceOf(wheelDeviceRef.current, e);
      const action = resolveWheelAction(e, touchSettings.wheelMode ?? "auto", source);
      if (action.kind === "zoom") {
        const pt = getContainerPoint(e.clientX, e.clientY);
        zoomTo(cameraRef.current.zoom * action.factor, pt.x, pt.y, viewportRef.current);
      } else {
        // Scroll and drag deltas have opposite signs — see cameraPanForScroll.
        // The touch and space-drag callers below pass their deltas unchanged
        // because those really are drag deltas.
        const pan = cameraPanForScroll(action);
        panCamera(pan.dx, pan.dy);
      }
    };

    node.addEventListener("wheel", onWheel, { passive: false });
    return () => node.removeEventListener("wheel", onWheel);
    // Camera and viewport are read through refs so this listener is attached
    // once instead of being torn down and rebuilt on every zoom step.
  }, [touchSettings.wheelMode, getContainerPoint, zoomTo, panCamera]);

  // Find topmost element under world coordinate
  const findElementAt = useCallback(
    (wx: number, wy: number, isTouch = false, customTol?: number): WhiteboardElement | null => {
      const tol = customTol ?? (tool === "eraser" ? Math.max((style.eraserSize || 24) / 2, HIT_THRESHOLD) : (isTouch ? 12 : HIT_THRESHOLD));
      // Locked-items mode: only locked things answer a touch (hitTestElement
      // skips locked elements, so each is tested as if unlocked).
      const lockedPick = lockedMode && (tool === "select" || tool === "lasso");
      for (let i = elements.length - 1; i >= 0; i--) {
        const el = elements[i];
        if (lockedPick) {
          if (el.locked && el.type !== "connection" && hitTestElement({ ...el, locked: false }, wx, wy, tol, elements)) {
            return el;
          }
          continue;
        }
        if (hitTestElement(el, wx, wy, tol, elements)) {
          return el;
        }
      }
      return null;
    },
    [elements, tool, style.eraserSize, lockedMode]
  );


  /**
   * Erase at a world point. In "pixel" mode a stroke is split around the eraser
   * and its surviving pieces replace it; everything else (and "object" mode) is
   * deleted whole, because a shape or a text box has no partial form.
   *
   * `commit` is true only for the FIRST erase of a gesture: the drag then folds
   * into that single history entry, so one swipe is one undo rather than dozens.
   */
  const eraseAt = useCallback(
    (wx: number, wy: number, isTouch: boolean, commit: boolean) => {
      // Where the eraser was at the previous event. Erasing only at the current
      // position leaves gaps whenever the drag outruns the event rate, so the
      // swept segment from there to here is what actually erases.
      const prev = lastErasePosRef.current ?? { x: wx, y: wy };
      lastErasePosRef.current = { x: wx, y: wy };
      const radius = Math.max((style.eraserSize || 24) / 2, 1);

      if (style.eraserMode === "object") {
        const hit = findElementAt(wx, wy, isTouch);
        if (hit) deleteElements([hit.id], commit);
        return;
      }

      // Pixel mode: cut through every stroke under the eraser, not just the
      // topmost one — the eraser is a physical brush, not a picker.
      // The LIVE elements, not this render's: an S Pen reports several moves
      // between renders, and each cut must start from the previous one's
      // result - from a stale copy, a later cut rebuilt the stroke from its
      // uncut original and brought erased ink back (doubled).
      const live = getBoardElements(
        useWhiteboard.getState().boards.find((b) => b.id === activeBoardId) ?? null
      );
      const strokesHit = live.filter((el): el is StrokeElement => {
        if (el.type !== "stroke" || el.locked) return false;
        // A turned stroke's box says little about where its ink is; let the
        // precise test below decide.
        if (el.rotation) return true;
        const b = getElementBounds(el);
        // Cheap reject against the swept segment's bounding box, expanded by
        // the radius — must match what eraseFromStroke actually tests.
        const minX = Math.min(prev.x, wx) - radius;
        const maxX = Math.max(prev.x, wx) + radius;
        const minY = Math.min(prev.y, wy) - radius;
        const maxY = Math.max(prev.y, wy) + radius;
        return !(maxX < b.x || minX > b.x + b.width || maxY < b.y || minY > b.y + b.height);
      });

      let didCommit = false;
      for (const stroke of strokesHit) {
        // Cut the line you SEE: the smoothed points, and for a turned stroke
        // its points turned into place. Cutting the raw points and letting
        // each piece be re-smoothed (and re-turned about its own centre)
        // made the writing beside every cut bend and shift.
        let pts = settledStrokePoints(stroke);
        if (stroke.rotation) {
          const c = getElementCenter(stroke);
          pts = pts.map(([px, py, pr]) => {
            const r = rotatePoint(stroke.x + px, stroke.y + py, c.x, c.y, stroke.rotation);
            return [r.x - stroke.x, r.y - stroke.y, pr] as [number, number, number];
          });
        }
        const runs = eraseFromStroke(
          pts,
          prev.x - stroke.x,
          prev.y - stroke.y,
          wx - stroke.x,
          wy - stroke.y,
          radius
        );
        if (runs === null) continue; // untouched

        if (!didCommit && commit) {
          commitHistory();
          didCommit = true;
        }

        if (runs.length === 0) {
          deleteElements([stroke.id], false);
          continue;
        }

        // Re-origin each piece so its points stay relative to its own element.
        // An end the eraser made is blunt; the stroke's own ends keep theirs.
        const first = pts[0];
        const last = pts[pts.length - 1];
        const same = (a: number[], b: number[]) => Math.abs(a[0] - b[0]) < 1e-6 && Math.abs(a[1] - b[1]) < 1e-6;
        const pieces: StrokeElement[] = runs.map((run, i) => {
          const ox = run[0][0];
          const oy = run[0][1];
          return {
            ...stroke,
            id: i === 0 ? stroke.id : nanoid(8),
            x: stroke.x + ox,
            y: stroke.y + oy,
            rotation: 0,
            points: run.map(([px, py, pr]) => [px - ox, py - oy, pr] as [number, number, number]),
            settled: true,
            cutStart: same(run[0], first) ? stroke.cutStart : true,
            cutEnd: same(run[run.length - 1], last) ? stroke.cutEnd : true,
            path: undefined,
            updatedAt: Date.now(),
          };
        });

        updateElement(pieces[0].id, pieces[0], false);
        if (pieces.length > 1) addElements(pieces.slice(1), false);
      }

      // Drawn shapes and lines erase whole (they have no partial form). Text
      // boxes, notes and pictures are not ink: rubbing out writing near them
      // must never delete them - "Whole" mode is there for that.
      const other = findElementAt(wx, wy, isTouch);
      if (other && other.type !== "stroke" && other.type !== "text" && other.type !== "sticky" && other.type !== "image") {
        deleteElements([other.id], commit && !didCommit);
      }
    },
    [
      activeBoardId,
      style.eraserSize,
      style.eraserMode,
      findElementAt,
      deleteElements,
      updateElement,
      addElements,
      commitHistory,
    ]
  );

  // Capture on the stable SVG root — capturing on e.target (a child node that can
  // unmount mid-gesture when overlays re-render) silently drops the capture and
  // leaves the interaction stuck.
  // ---------------------------------------------------------------------
  // Panning: one camera update per FRAME
  // ---------------------------------------------------------------------
  // Scrolling a notebook by finger was juddery because every single
  // pointermove did TWO React renders — `panCamera` (a store write) and
  // `setInteraction` (component state) — and a tablet digitiser reports
  // 120-240 moves a second. That is up to ~480 renders per second of a tree
  // holding every element, every neighbouring page and any PDF layer, so the
  // camera fell behind the finger and the page appeared to drag.
  //
  // Now a move only writes to refs. A single rAF flush applies the summed
  // delta once per displayed frame, which is the most the screen can show
  // anyway, and the gesture's last position lives in a ref so it never
  // re-renders at all. The total travel is unchanged: the deltas are summed,
  // not sampled, so the page still tracks the finger exactly 1:1.
  //
  // The coast after release lives in startMomentum below. An earlier version
  // overshot (1242px for an 800px drag on a Galaxy Tab S9) because it averaged
  // velocity over the whole drag; the current one uses Android's 100 ms / 40 ms
  // rules, so a drag that has stopped does not throw.

  /** Where the pan gesture last was, in container coords. Ref, not state. */
  const panLastRef = useRef<{ x: number; y: number } | null>(null);
  /** Movement seen since the last frame flush. */
  const panAccumRef = useRef<{ dx: number; dy: number }>({ dx: 0, dy: 0 });
  const panRafRef = useRef<number | null>(null);

  // --- The camera leaves React while a finger is down --------------------
  // Coalescing to one store write per frame was not enough. Each write still
  // re-rendered a 2,500-line component holding every element, every
  // neighbouring sheet and the PDF layer, and `dumpsys gfxinfo` showed the
  // symptom precisely: frames were being produced on time, but "Number High
  // input latency: 230" — the main thread was busy, so touches were handled
  // late. That is what "slow" felt like.
  //
  // During a pan the camera therefore moves by writing the transform straight
  // onto the SVG nodes: zero React renders, two attribute writes a frame. The
  // store is told once, when the finger lifts, so undo, autosave, the minimap
  // and everything else see exactly one camera change per gesture.
  const worldRef = useRef<SVGGElement | null>(null);
  const boardPaperRef = useRef<SVGPatternElement | null>(null);
  /** The camera as the DOM currently shows it, while a pan is in flight. */
  const liveCamRef = useRef<{ x: number; y: number } | null>(null);
  /** Whole-gesture screen delta, committed to the store on release. */
  const panTotalRef = useRef<{ dx: number; dy: number }>({ dx: 0, dy: 0 });

  /** Writes the live camera onto the DOM. Must mirror what the JSX renders. */
  const applyLiveTransform = useCallback(() => {
    const cam = liveCamRef.current;
    const g = worldRef.current;
    if (!cam || !g) return;
    const z = cameraRef.current.zoom;
    g.setAttribute(
      "transform",
      `translate(${viewportRef.current.width / 2}, ${viewportRef.current.height / 2}) scale(${z}) translate(${-cam.x}, ${-cam.y})`
    );
    // The whiteboard's paper pattern is painted in SCREEN space, so it has to
    // be slid by hand too or the dots sit still while the content moves.
    const pat = boardPaperRef.current;
    if (pat) {
      pat.setAttribute("x", String(viewportRef.current.width / 2 - cam.x * z));
      pat.setAttribute("y", String(viewportRef.current.height / 2 - cam.y * z));
    }
  }, []);

  /**
   * Renders the live in-flight stroke directly onto the SVG <path> DOM node.
   * Incorporates transient hardware predictions (R1-DEF-04) and bypasses React reconciliation.
   */
  const applyLiveDraftStroke = useCallback(() => {
    const live = liveDraftStrokeRef.current;
    const pathEl = liveDraftPathRef.current;
    const groupEl = liveDraftGroupRef.current;
    if (!live || !pathEl || !groupEl) return;

    const pred = predictedPointsRef.current;
    const renderPoints = pred.length > 0 ? [...live.points, ...pred] : live.points;

    const tempStroke: StrokeElement = {
      id: live.id,
      type: "stroke",
      x: live.originX,
      y: live.originY,
      rotation: 0,
      opacity: 1,
      points: renderPoints,
      color: live.color,
      strokeWidth: live.strokeWidth,
      strokeStyle: live.strokeStyle,
      smoothing: live.smoothing,
      createdAt: live.createdAt,
      updatedAt: Date.now(),
    };

    const pathD = buildStrokePath(tempStroke, true);
    pathEl.setAttribute("d", pathD);
  }, []);

  const flushDraftStroke = useCallback(() => {
    draftStrokeRafRef.current = null;
    applyLiveDraftStroke();
  }, [applyLiveDraftStroke]);

  const scheduleDraftFlush = useCallback(() => {
    if (draftStrokeRafRef.current === null) {
      draftStrokeRafRef.current = requestAnimationFrame(flushDraftStroke);
    }
  }, [flushDraftStroke]);

  // A render triggered by something else mid-gesture would paint the stale
  // store camera and make the page jump. Re-assert ours after every commit.
  useLayoutEffect(() => {
    if (liveCamRef.current) applyLiveTransform();
    if (liveDraftStrokeRef.current && liveDraftGroupRef.current && liveDraftPathRef.current) {
      liveDraftGroupRef.current.style.display = "";
      liveDraftGroupRef.current.setAttribute(
        "transform",
        `translate(${liveDraftStrokeRef.current.originX}, ${liveDraftStrokeRef.current.originY})`
      );
      applyLiveDraftStroke();
    }
  });
  const flushPan = useCallback(() => {
    panRafRef.current = null;
    const { dx, dy } = panAccumRef.current;
    if (dx === 0 && dy === 0) return;
    panAccumRef.current = { dx: 0, dy: 0 };

    const live = liveCamRef.current;
    if (!live) {
      // No gesture in flight (a stray flush): go through the store as normal.
      panCamera(dx, dy);
      return;
    }
    const z = cameraRef.current.zoom;
    const fromX = live.x;
    const fromY = live.y;
    live.x -= dx / z;
    live.y -= dy / z;
    // Stop the paper at the edge under the finger. The store's own bound only
    // applies on release, so without this a drag could sweep the page off the
    // screen and let it snap back afterwards - the rubber band nobody asked
    // for. Clamping here means the page simply stops, like every other reader.
    const geom = flingGeomRef.current;
    if (geom.isNb) {
      const c = clampCameraToSheet(
        { x: live.x, y: live.y, zoom: z },
        viewportRef.current,
        geom.page,
        geom.doc
      );
      live.x = c.x;
      live.y = c.y;
    }
    // Bank the movement that actually happened, not the movement asked for, so
    // the single store update on release lands where the screen already is.
    panTotalRef.current.dx += (fromX - live.x) * z;
    panTotalRef.current.dy += (fromY - live.y) * z;
    applyLiveTransform();
  }, [panCamera, applyLiveTransform]);

  /** When the pending flush was scheduled, so a stalled one can be detected. */
  const panScheduledAtRef = useRef(0);

  /**
   * Records movement and makes sure a flush happens.
   *
   * The obvious version — "schedule an rAF only if none is pending" — WEDGES.
   * A WebView stops firing requestAnimationFrame whenever it decides the page
   * is not visible (app backgrounded, screen off, system gesture takeover).
   * A flush scheduled just before that never runs, so the pending-flag stays
   * set for ever, every later move refuses to schedule anything, and panning
   * silently stops working until the app is restarted. That is exactly how
   * this froze on the Galaxy Tab S9.
   *
   * So the flag is treated as a hint, not a lock: if the pending flush has not
   * run within a few frames, it is assumed dead and the movement is applied
   * straight away.
   */
  const queuePan = useCallback(
    (dx: number, dy: number) => {
      panAccumRef.current.dx += dx;
      panAccumRef.current.dy += dy;

      const now = performance.now();
      const pending = panRafRef.current !== null;
      const stalled = pending && now - panScheduledAtRef.current > 80; // ~5 frames

      if (stalled) {
        cancelAnimationFrame(panRafRef.current!);
        panRafRef.current = null;
        flushPan();
        return;
      }
      if (!pending) {
        panScheduledAtRef.current = now;
        panRafRef.current = requestAnimationFrame(flushPan);
      }
    },
    [flushPan]
  );

  /** Recent pointer positions for the velocity estimate (last 100 ms only). */
  const panSamplesRef = useRef<Array<{ t: number; x: number; y: number }>>([]);
  /** Latest sheet geometry, read by the fling loop without a stale closure. */
  const flingGeomRef = useRef({
    isNb: false,
    page: { width: 0, height: 0 },
    doc: { pageCount: 1, activeIndex: 0 },
  });
  // Re-assigned every render, so a fling that crosses a page boundary sees the
  // new anchor rather than the one captured when the finger left the glass.
  flingGeomRef.current = {
    isNb,
    page: pageDim,
    doc: { pageCount: allPages.length, activeIndex },
  };

  const recordPanSample = useCallback((x: number, y: number) => {
    const t = performance.now();
    const buf = panSamplesRef.current;
    buf.push({ t, x, y });
    while (buf.length > 2 && t - buf[0].t > VELOCITY_HORIZON_MS) buf.shift();
  }, []);

  const stopMomentum = useCallback(() => {
    if (momentumRafRef.current !== null) {
      cancelAnimationFrame(momentumRafRef.current);
      momentumRafRef.current = null;
    }
  }, []);

  /**
   * Coasts after a throw. Velocity is measured Android's way - only the last
   * 100 ms, and zero if the finger had been still for 40 ms before lifting.
   */
  const startMomentum = useCallback(() => {
    const now = performance.now();
    const buf = panSamplesRef.current.filter((q) => now - q.t <= VELOCITY_HORIZON_MS);
    panSamplesRef.current = [];
    if (buf.length < 2) return;
    const first = buf[0];
    const last = buf[buf.length - 1];
    if (now - last.t > POINTER_STOPPED_MS) return; // finger had stopped: no throw
    const span = last.t - first.t;
    if (span <= 0) return;

    let vx = (last.x - first.x) / span;
    let vy = (last.y - first.y) / span;
    const speed = Math.hypot(vx, vy);
    if (speed < FLING_MIN_V) return;
    if (speed > FLING_MAX_V) {
      vx *= FLING_MAX_V / speed;
      vy *= FLING_MAX_V / speed;
    }

    const lnDecel = Math.log(FLING_DECEL_PER_MS);
    let prev = performance.now();
    const step = () => {
      const t = performance.now();
      const dt = Math.min(50, t - prev); // a stalled frame must not teleport
      prev = t;
      const decay = Math.pow(FLING_DECEL_PER_MS, dt);
      // Exact distance under exponential decay over dt, not v * dt.
      const k = (decay - 1) / lnDecel;
      const dx = vx * k;
      const dy = vy * k;
      vx *= decay;
      vy *= decay;

      const store = useWhiteboard.getState();
      const before = store.camera;
      store.panCamera(dx, dy);
      let after = useWhiteboard.getState().camera;

      // Reached the end of the notebook: stop exactly there instead of pushing.
      const geom = flingGeomRef.current;
      let clamped = false;
      if (geom.isNb) {
        const c = clampCameraToSheet(after, viewportRef.current, geom.page, geom.doc);
        const bitX = Math.abs(c.x - after.x) > 1e-6;
        const bitY = Math.abs(c.y - after.y) > 1e-6;
        if (bitX || bitY) {
          store.setCamera(c);
          after = useWhiteboard.getState().camera;
          // Kill ONLY the axis that hit the wall. Ending the whole fling on any
          // clamp looked right until the sheet became narrower than the screen:
          // x is then pinned to the centre, so it is "at the wall" on every
          // frame, and since no finger swipes perfectly straight, every scroll
          // lost its momentum on the first frame and the notebook felt dead.
          if (bitX) vx = 0;
          if (bitY) vy = 0;
          clamped = true;
        }
      }
      const moved = Math.hypot(after.x - before.x, after.y - before.y) * after.zoom;
      const wanted = Math.hypot(dx, dy);
      if (
        Math.hypot(vx, vy) < FLING_STOP_V ||
        // The store refused to move: something else is holding the camera.
        // Only meaningful on a frame that was not clamped, because a clamped
        // frame is SUPPOSED to move less than asked.
        (!clamped && wanted > 0.5 && moved < wanted * 0.5)
      ) {
        momentumRafRef.current = null;
        return;
      }
      momentumRafRef.current = requestAnimationFrame(step);
    };
    momentumRafRef.current = requestAnimationFrame(step);
  }, []);

  /** Begins a pan. Keeps `interaction` in step for the cursor and other branches. */
  const beginPan = useCallback((x: number, y: number) => {
    stopMomentum();
    panSamplesRef.current = [{ t: performance.now(), x, y }];
    panLastRef.current = { x, y };
    panAccumRef.current = { dx: 0, dy: 0 };
    panTotalRef.current = { dx: 0, dy: 0 };
    liveCamRef.current = { x: cameraRef.current.x, y: cameraRef.current.y };
    setInteraction({ kind: "panning", lastX: x, lastY: y });
  }, [stopMomentum]);

  /** Nothing may outlive the component. */
  useEffect(
    () => () => {
      if (panRafRef.current !== null) cancelAnimationFrame(panRafRef.current);
      if (momentumRafRef.current !== null) cancelAnimationFrame(momentumRafRef.current);
    },
    []
  );

  /** Flushes and clears pan state however the gesture ended. */
  const endPanGesture = useCallback(() => {
    if (panRafRef.current !== null) {
      cancelAnimationFrame(panRafRef.current);
      panRafRef.current = null;
    }
    flushPan();
    panLastRef.current = null;

    // Hand the whole gesture to the store as ONE change, then let React paint
    // it. liveCamRef is cleared first so the layout effect stops re-asserting.
    const total = panTotalRef.current;
    liveCamRef.current = null;
    panTotalRef.current = { dx: 0, dy: 0 };
    if (total.dx !== 0 || total.dy !== 0) panCamera(total.dx, total.dy);
  }, [flushPan, panCamera]);

  // ---------------------------------------------------------------------
  // Eraser cursor: a circle showing exactly what the eraser will take
  // ---------------------------------------------------------------------
  // Like GoodNotes and Samsung Notes: while the eraser is the tool, a ring
  // follows the pen - hovering as well as touching - so you can see what will
  // go before any ink is lost. Its radius is the SAME value eraseAt and
  // findElementAt test against (eraserSize / 2, in page units), scaled by the
  // zoom, so the ring is the eraser rather than an approximation of it. That
  // holds in both modes: whole-stroke picking uses the eraser radius as its
  // hit tolerance too.
  //
  // It is moved by writing its transform straight onto the DOM node. Hover
  // reports arrive at the digitiser's rate; a React render for each would put
  // the ring visibly behind the nib, the same mistake that made scrolling lag.
  const eraserCursorRef = useRef<SVGGElement | null>(null);
  const eraserCursorShownRef = useRef(false);
  const eraserOn = tool === "eraser";
  const eraserScreenR = Math.max(((style.eraserSize || 24) / 2) * camera.zoom, 2);

  const placeEraserCursor = useCallback(
    (clientX: number, clientY: number, show: boolean) => {
      const g = eraserCursorRef.current;
      if (!g) return;
      if (!show) {
        if (eraserCursorShownRef.current) {
          g.setAttribute("visibility", "hidden");
          eraserCursorShownRef.current = false;
        }
        return;
      }
      const pt = getContainerPoint(clientX, clientY);
      g.setAttribute("transform", `translate(${pt.x}, ${pt.y})`);
      if (!eraserCursorShownRef.current) {
        g.setAttribute("visibility", "visible");
        eraserCursorShownRef.current = true;
      }
    },
    [getContainerPoint]
  );

  // ---------------------------------------------------------------------
  // S Pen & Stylus Hover Preview Cursor
  // ---------------------------------------------------------------------
  // When an S Pen (or mouse) hovers above the canvas, show a dual-ring dot
  // previewing the exact ink thickness and color before touching down.
  const penHoverCursorRef = useRef<SVGGElement | null>(null);
  const penHoverCursorShownRef = useRef(false);

  const placePenHoverCursor = useCallback(
    (clientX: number, clientY: number, show: boolean) => {
      const g = penHoverCursorRef.current;
      if (!g) return;
      if (!show) {
        if (penHoverCursorShownRef.current) {
          g.setAttribute("visibility", "hidden");
          penHoverCursorShownRef.current = false;
        }
        return;
      }
      const pt = getContainerPoint(clientX, clientY);
      g.setAttribute("transform", `translate(${pt.x}, ${pt.y})`);
      if (!penHoverCursorShownRef.current) {
        g.setAttribute("visibility", "visible");
        penHoverCursorShownRef.current = true;
      }
    },
    [getContainerPoint]
  );

  // The dot is the width the pen will actually lay down at normal pressure:
  // each pen scales its thickness (a highlighter 3x, a fineliner 0.5x), so the
  // raw thickness setting alone showed the wrong size for most pens.
  const hoverInkRadius =
    ((getToolSize(style, tool) || 4) *
      (isStrokeTool(tool) ? PEN_TYPE_PRESETS[tool as StrokeStyle]?.sizeScale ?? 1 : 1) *
      camera.zoom) /
    2;

  // Switching TO the eraser (including the S Pen button borrowing it) shows
  // the ring where the pen already is, in place of the ink dot; switching away
  // hides the ring at once.
  useLayoutEffect(() => {
    if (!eraserOn) {
      placeEraserCursor(0, 0, false);
      return;
    }
    placePenHoverCursor(0, 0, false);
    const lp = lastPointerPosRef.current;
    if (lp) placeEraserCursor(lp.clientX, lp.clientY, true);
  }, [eraserOn, placeEraserCursor, placePenHoverCursor]);

  // ---------------------------------------------------------------------
  // Draw-and-Hold Auto-Straighten State
  // ---------------------------------------------------------------------
  const autoStraightenTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const isAutoStraightenedRef = useRef(false);

  const clearAutoStraightenTimer = useCallback(() => {
    if (autoStraightenTimerRef.current) {
      clearTimeout(autoStraightenTimerRef.current);
      autoStraightenTimerRef.current = null;
    }
  }, []);

  const capturePointer = useCallback((e: React.PointerEvent<SVGSVGElement>) => {
    const node: Element | null = svgRef.current ?? (e.currentTarget as Element);
    try {
      node?.setPointerCapture?.(e.pointerId);
    } catch {
      // setPointerCapture throws NotFoundError when the pointer is no longer
      // active — a real race on touch devices if the finger lifts between the
      // event firing and this handler running. Unguarded it escaped
      // handlePointerDown and aborted the rest of the gesture setup (tool
      // state, draft element, history), which looks like "drawing randomly
      // stops working". Losing capture only costs us events outside the SVG.
    }
  }, []);

  /**
   * Arm or disarm the context menu. Written through a ref as well so the
   * decision is readable synchronously inside a pointer handler, where the
   * state value would still be the previous render's.
   */
  const armContextMenu = useCallback((next: boolean) => {
    if (contextMenuArmedRef.current === next) return;
    contextMenuArmedRef.current = next;
    setContextMenuArmed(next);
  }, []);

  /** Disarm a pending long press (the finger moved, lifted, or the pen won). */
  const cancelLongPress = useCallback(() => {
    if (longPressRef.current) {
      clearTimeout(longPressRef.current.timer);
      longPressRef.current = null;
    }
  }, []);

  // A timer that outlives the canvas would fire setSelected on an unmounted
  // component — and, worse, keep the board alive in the closure.
  useEffect(() => cancelLongPress, [cancelLongPress]);

  /**
   * Arm Android's standard long press to select. Holding still for 500ms
   * selects the object (and the drag that follows moves it); moving first
   * means the gesture was a pan and nothing is selected at all.
   *
   * This is the half of the fix that works on a tablet with NO stylus, where
   * none of the pen-proximity rules in palm.ts can ever fire: a hand brushing
   * the glass is brief and moves, so it fails the hold, and a hand that comes
   * to rest is filtered by contact size.
   */
  const armLongPressSelect = (
    e: React.PointerEvent<SVGSVGElement>,
    hit: WhiteboardElement
  ) => {
    cancelLongPress();
    // This gesture is a SELECTION, so Radix's own 700ms long press must not
    // race it: two timers on one press produced a menu that pre-empted the
    // selection, and the user was left holding neither. The options menu is
    // still one gesture away — press and hold again once the object is
    // selected (see the already-selected branch below), which is the same
    // press-to-select-then-press-for-options rhythm Android uses.
    armContextMenu(false);
    const pointerId = e.pointerId;
    const startX = e.clientX;
    const startY = e.clientY;
    const priorSelection = selectedIds;
    const timer = setTimeout(() => {
      longPressRef.current = null;
      setSelected([hit.id]);
      touchInteractionRef.current = { pointerId, priorSelection };
      // Locked elements select but never move, so no drag is queued for them.
      if (!hit.locked) pendingMoveRef.current = { pointerId, elementId: hit.id };
      // Confirm the change the way the platform does: at this moment the user
      // is looking at their hand, not at the screen.
      if (touchSettings.touchFeedback) {
        try {
          navigator.vibrate?.(12);
        } catch {
          /* unsupported or blocked; the haptic is a courtesy, never required */
        }
      }
    }, LONG_PRESS_MS);
    longPressRef.current = { timer, pointerId, elementId: hit.id, startX, startY };
  };

  /**
   * Retroactive palm rejection. The hand lands on the glass BEFORE the nib
   * does, so by the time the stylus proves that contact was a palm it has
   * already selected — or started dragging — whatever it came down on. Undo
   * that, rather than merely declining to carry it further.
   */
  const retractTouchInteraction = () => {
    cancelLongPress();
    pendingMoveRef.current = null;
    const started = touchInteractionRef.current;
    if (!started) return;
    touchInteractionRef.current = null;
    if (interaction.kind === "moving") {
      for (const orig of interaction.originalElements) updateElement(orig.id, orig, false);
    }
    setSelected(started.priorSelection);
    setRubberBand(null);
    setInteraction({ kind: "idle" });
  };

  // Touchscreen Double-Tap Detection
  const checkDoubleTap = (clientX: number, clientY: number): boolean => {
    const now = Date.now();
    const last = lastTapRef.current;
    const isDouble =
      now - last.time < 320 &&
      Math.hypot(clientX - last.x, clientY - last.y) < 30;
    lastTapRef.current = { time: now, x: clientX, y: clientY };
    return isDouble;
  };

  // Pointer Down
  const handlePointerDown = (e: React.PointerEvent<SVGSVGElement>) => {
    // Any new contact catches a coasting page, as on every phone.
    stopMomentum();
    if (shapeNote) setShapeNote(null);
    placeEraserCursor(e.clientX, e.clientY, tool === "eraser");
    placePenHoverCursor(0, 0, false);
    clearAutoStraightenTimer();
    isAutoStraightenedRef.current = false;
    // The laser and text select point and read; they must never add a page
    // through the "+" between sheets.
    const pointingTool = tool === "laser" || tool === "textselect";
    if (isNb && !pointingTool) {
      const gw = getWorldPoint(e.clientX, e.clientY);
      const k = gapAt(gw.x, gw.y, isTouchPress(e) ? 10 : 0);
      if (k !== null) showGapPlus(k, 3000);
      else showGapPlus(null); // writing elsewhere: never leave a "+" under the nib
    }
    const isTouch = e.pointerType === "touch";
    const isPen = e.pointerType === "pen";

    if (isPen) {
      penActiveRef.current = true;
      lastPenAtRef.current = Date.now();
      armContextMenu(false);
      retractTouchInteraction();
    }

    syncStylusErase(e);

    // Palm rejection, ahead of anything that could react to this contact.
    // The old test here was `penActiveRef.current` alone — true only WHILE the
    // nib is on the glass — which misses both ways a palm actually arrives: it
    // comes down before you start writing, and it stays down while you lift
    // the pen between words. classifyTouch outlasts the pen and also weighs
    // the size of the contact patch. See lib/whiteboard/palm.ts.
    let touchVerdict: TouchVerdict = "allow";
    // Same rule for the mouse: a right-click with nothing selected used to
    // open the same all-disabled menu.
    if (!isTouch && !isPen) armContextMenu(selectedIds.length > 0);
    if (isTouch) {
      touchVerdict = classifyTouch(
        { width: e.width, height: e.height },
        { penDown: penActiveRef.current, lastPenAt: lastPenAtRef.current, now: Date.now() }
      );
      // A stylus on (or just off) the glass is decisive: the contact is a palm
      // and gets nothing at all.
      // A rejected contact is a palm: it gets no menu. A clean fingertip keeps
      // the deliberate long press, which Radix cancels on movement anyway — so
      // hold-and-drag moves the object and hold-and-wait opens the menu.
      // Mid-edit nothing does: while you are typing, a hand on the glass is a
      // resting hand, and the menu popping up over your text is the very
      // interruption this whole pass is about.
      // ...and only when the menu could actually DO something. Every item in
      // it acts on the current selection, so with nothing selected a long
      // press opened a menu whose five entries were all greyed out — it
      // appeared uninvited, explained nothing and did nothing. Selecting by
      // finger is the long press handled further down; the menu is the
      // SECOND hold, once something is selected.
      armContextMenu(touchVerdict === "allow" && !editingId && selectedIds.length > 0);

      // Context-aware multi-touch fast-bypass (R1-DEF-03):
      // If the pen is lifted (!penActiveRef) and a second fingertip arrives to pinch/scroll,
      // allow multi-touch to proceed if contacts are fingertip-sized (< PALM_CONTACT_PX).
      const isSecondFingertipPinch =
        !penActiveRef.current &&
        touchVerdict === "pen-recent" &&
        activeTouchesRef.current.size >= 1 &&
        !contactLooksLikePalm({ width: e.width, height: e.height });

      if ((touchVerdict === "pen-down" || touchVerdict === "pen-recent") && !isSecondFingertipPinch) {
        // Radix's long press lives on this same <svg>, composed AFTER this
        // handler, and it skips itself when the event is already default-
        // prevented. Using that rather than the `disabled` prop alone makes
        // the palm case synchronous and immune to render timing — and a palm
        // has nothing whose default we want anyway: suppressing the compat
        // mouse events also stops a resting hand from dismissing the text
        // editor you are in the middle of typing into.
        e.preventDefault();
        // Still recorded, so multi-touch maths and the matching release stay
        // consistent — just never allowed to reach content.
        rejectedPalmsRef.current.add(e.pointerId);
        activeTouchesRef.current.set(e.pointerId, {
          x: e.clientX,
          y: e.clientY,
          startX: e.clientX,
          startY: e.clientY,
        });
        return;
      }

      if (isSecondFingertipPinch) {
        // Un-reject existing fingertip contacts since this is a valid multi-touch gesture
        for (const [id] of activeTouchesRef.current.entries()) {
          rejectedPalmsRef.current.delete(id);
        }
      }
      // Contact size alone is weaker evidence, and on a stylus-free tablet it
      // is the ONLY evidence there is — so an oversized patch is demoted to
      // navigation (below) rather than silenced. A resting hand then does
      // nothing because it does not move; a broad fingertip can still pan and
      // can still long-press to select.
    }

    // Only finger pointers count toward multi-touch gestures.
    if (isTouch) {
      activeTouchesRef.current.set(e.pointerId, {
        x: e.clientX,
        y: e.clientY,
        startX: e.clientX,
        startY: e.clientY,
      });

      // Exclude rejected palms from gesture calculations (Defect D5)
      const validTouches = Array.from(activeTouchesRef.current.entries())
        .filter(([id]) => !rejectedPalmsRef.current.has(id))
        .map(([, t]) => t);
      const currentTouchCount = validTouches.length;

      // A new gesture starts when the FIRST finger lands — not on every finger.
      if (currentTouchCount === 1) {
        touchStartTimeRef.current = Date.now();
        touchMovedRef.current = false;
      }
      if (currentTouchCount > maxTouchCountRef.current) {
        maxTouchCountRef.current = currentTouchCount;
      }

      // Multi-touch Pinch to Zoom and 2-Finger Pan Setup on Touchscreen
      // Guard against Defect D5: Inking takes absolute precedence; never hijack into pinch zoom while inking!
      if (
        currentTouchCount >= 2 &&
        !penActiveRef.current &&
        drawingPointerIdRef.current === null &&
        interaction.kind !== "drawing"
      ) {
        // Seal any in-progress gesture so it stays undoable.
        if (
          interaction.kind === "moving" ||
          interaction.kind === "resizing" ||
          interaction.kind === "rotating"
        ) {
          commitHistory();
          gestureSealedRef.current = true;
        }
        // Two fingers mean zoom or scroll, never pointing or selecting.
        laser.clear();
        textSelect.cancel();
        const touches = validTouches;
        const dist = Math.hypot(touches[0].x - touches[1].x, touches[0].y - touches[1].y);
        pinchStartDistanceRef.current = dist;
        pinchEngagedRef.current = false;
        pinchStartZoomRef.current = camera.zoom;
        const midClientX = (touches[0].x + touches[1].x) / 2;
        const midClientY = (touches[0].y + touches[1].y) / 2;
        lastTouchMidRef.current = { x: midClientX, y: midClientY };
        setInteraction({ kind: "idle" });
        setDraftElement(null);
        return;
      }
    }

    const cp = getContainerPoint(e.clientX, e.clientY);
    // While capture is armed the press draws an area, whatever tool is held:
    // the pen's palm rule must not turn a finger's capture drag into a pan.
    const isDrawingTool = isStrokeTool(tool) && !captureArmed;

    // Palm Rejection. In stylus-only mode fingers are navigation-only for
    // EVERY tool (the old isDrawingTool restriction let palms lasso/erase/
    // connect). The palmRejection toggle keeps its drawing-tools-only scope.
    const stylusOnlyFinger = isTouch && touchSettings.mode === "stylus-only";
    const drawingPalmRejection = isTouch && touchSettings.palmRejection && isDrawingTool;
    // A big contact patch only means "palm" if palms are what we are looking
    // for. classifyTouch reports the size honestly, but acting on it while the
    // user has palm rejection OFF made finger drawing impossible on ordinary
    // Windows touchscreens, which commonly report a fingertip at 40-60 CSS px
    // — past the 45px threshold. So the sensor stays sensitive and the policy
    // lives here, with the setting.
    const oversizedContact = touchVerdict === "contact-size" && touchSettings.palmRejection;

    // A finger on one of the selection's HANDLES is a deliberate grab, not a
    // resting hand: it lands on a small target that only exists because you
    // selected something. Without this, stylus-only mode (and palm rejection
    // with a pen tool) made resize and rotate impossible by touch. A contact
    // big enough to be a palm is still never exempt.
    const onSelectionHandle =
      isTouch &&
      touchVerdict === "allow" &&
      selectedIds.length > 0 &&
      Boolean((e.target as Element | null)?.getAttribute?.("data-handle"));

    if ((stylusOnlyFinger || drawingPalmRejection || oversizedContact) && !onSelectionHandle) {
      // Navigation only — which this branch did not honour: it SELECTED
      // whatever the finger landed on, so a resting palm popped the transform
      // box open even with palm rejection switched on. Selection here is the
      // deliberate long press instead, and never mid-edit.
      const wp = getWorldPoint(e.clientX, e.clientY);
      const hit = findElementAt(wp.x, wp.y, true);
      // A patch this size is a palm, and a palm holds perfectly still — so it
      // would pass a long press with room to spare. It gets no way to select;
      // a real fingertip (well under the threshold) still does.
      if (hit && !editingId && !oversizedContact) armLongPressSelect(e, hit);
      beginPan(cp.x, cp.y);
      capturePointer(e);
      return;
    }

    // ------------------------------------------------------------------
    // The live page follows the pen
    // ------------------------------------------------------------------
    // Zoomed out, two or three sheets are on screen but only the anchored
    // one is live - the rest are drawn as pictures. A pen landing on the
    // sheet above or below used to count as "off the page", so the ink gate
    // turned it into a PAN: writing on a visible page scrolled instead. The
    // same root cause made the eraser pan, selection miss, and a double-tap
    // drop its text box on the wrong page.
    //
    // So a press on another visible sheet first makes THAT sheet the live
    // one (re-anchoring shifts the camera by the same stride, so nothing
    // moves on screen), then replays this very press once React has
    // committed the new page - every tool then sees the right page's
    // coordinates and elements, including hit-testing, which a coordinate
    // patch-up alone could not give it.
    if (
      isNb &&
      allPages.length > 1 &&
      tool !== "pan" &&
      // Pointing at another sheet must not make it the active page.
      tool !== "laser" &&
      // Nor may a capture area: it spans sheets in the frame it started in.
      !captureArmed &&
      !spaceHeld &&
      e.button !== 1 &&
      !(e.nativeEvent as PointerEvent & { __reanchored?: boolean }).__reanchored &&
      activeTouchesRef.current.size <= 1
    ) {
      const pw = getWorldPoint(e.clientX, e.clientY);
      const target = sheetIndexAt(
        pw.x,
        pw.y,
        activeIndex,
        allPages.length,
        pageDim.width,
        pageDim.height,
        SHEET_GRAB_MARGIN
      );
      if (target !== null && target !== activeIndex) {
        const delta = target - activeIndex;
        anchorLockRef.current = { camY: cameraRef.current.y - delta * pageStride };
        // Commit the page switch NOW. React otherwise applies it in a
        // microtask of its own - queued after ours - so the replay ran with
        // the old page's coordinates, fell "off the page" and panned.
        flushSync(() => reanchorPage(delta, pageStride));
        const n = e.nativeEvent;
        const replay = new PointerEvent("pointerdown", {
          pointerId: n.pointerId,
          pointerType: n.pointerType,
          isPrimary: n.isPrimary,
          clientX: n.clientX,
          clientY: n.clientY,
          screenX: n.screenX,
          screenY: n.screenY,
          pressure: n.pressure,
          tangentialPressure: n.tangentialPressure,
          tiltX: n.tiltX,
          tiltY: n.tiltY,
          twist: n.twist,
          width: n.width,
          height: n.height,
          button: n.button,
          buttons: n.buttons,
          shiftKey: n.shiftKey,
          ctrlKey: n.ctrlKey,
          altKey: n.altKey,
          metaKey: n.metaKey,
          bubbles: true,
          cancelable: true,
        });
        (replay as PointerEvent & { __reanchored?: boolean }).__reanchored = true;
        const origin = (n.target as Element | null) ?? svgRef.current;
        // After flushSync the new page is committed, so the replay sees it;
        // and a microtask still runs before the next pointermove arrives.
        queueMicrotask(() => origin?.dispatchEvent(replay));
        return;
      }
    }

    // Touch double-tap creates text ONLY in select/text tools — otherwise it
    // would hijack the eraser/lasso/connect/pen tools (tap-tap-erase would
    // spawn a text box instead of erasing).
    const isDouble =
      isTouch &&
      !captureArmed &&
      (tool === "select" || tool === "text") &&
      checkDoubleTap(e.clientX, e.clientY);

    if (isDouble) {
      const wp = getWorldPoint(e.clientX, e.clientY);
      const hit = findElementAt(wp.x, wp.y, true);
      if (hit) {
        if (hit.type === "text" || hit.type === "sticky") {
          setEditingId(hit.id);
          return;
        }
      } else {
        const textId = nanoid(8);
        const newText: TextElement = {
          id: textId,
          type: "text",
          x: wp.x,
          y: wp.y,
          width: 220,
          height: 48,
          rotation: 0,
          opacity: 1,
          text: "",
          color: style.textColor,
          fontSize: style.fontSize,
          fontFamily: style.fontFamily,
          fontWeight: style.fontWeight,
          align: style.textAlign,
          createdAt: Date.now(),
          updatedAt: Date.now(),
        };
        addElement(newText, true);
        setEditingId(textId);
        return;
      }
    }

    if (isTouch && touchSettings.mode === "touch-pan") {
      beginPan(cp.x, cp.y);
      capturePointer(e);
      return;
    }

    const wp = getWorldPoint(e.clientX, e.clientY);

    // Capture: draw the area. It creates nothing and selects nothing, so it
    // needs no page gate - a box may start on the desk and sweep over two
    // sheets. Space / middle button still pan, so you can reframe first.
    // A press on something already SELECTED moves it, even with the mode on:
    // the app selects a picture it has just added (a capture put "on this
    // page", a photo) so you can drag it into place.
    const onSelection =
      captureArmed !== null &&
      selectedIds.length > 0 &&
      (() => {
        const hit = findElementAt(wp.x, wp.y, isTouch);
        return !!hit && selectedIds.includes(hit.id);
      })();
    if (captureArmed && e.button === 0 && !spaceHeld && !onSelection) {
      // One area at a time: a second contact must not restart the one the
      // first is still drawing - except the pen, over an area a resting palm
      // began a moment before it.
      if (interaction.kind === "capturing" && !(isPen && interaction.byTouch)) return;
      setInteraction({
        kind: "capturing",
        shape: captureArmed,
        pointerId: e.pointerId,
        byTouch: isTouch,
        points: [{ x: wp.x, y: wp.y }],
      });
      capturePointer(e);
      return;
    }

    if (e.button === 1 || spaceHeld || tool === "pan") {
      beginPan(cp.x, cp.y);
      capturePointer(e);
      return;
    }

    // The laser points; it never selects, writes or moves anything. Anywhere
    // on screen, the desk beside the pages included.
    if (tool === "laser") {
      laser.down(e.pointerId, wp.x, wp.y);
      capturePointer(e);
      return;
    }

    // Select text: a press lands on the page's text, never on your ink. Off
    // the text (the margin, a scan) it scrolls, as a reader would.
    if (tool === "textselect") {
      if (!textSelect.pointerDown(e)) beginPan(cp.x, cp.y);
      capturePointer(e);
      return;
    }

    // In a notebook, the area beside and between the sheets is a desk, not
    // canvas. A content gesture that starts there pans the view instead of
    // laying down ink that would live outside every page — unreachable once
    // you scroll, and absent from every export and print.
    // `select` is exempt: a marquee that begins on the desk and sweeps onto
    // the page is a normal way to select, and it creates nothing.
    const isContentTool =
      isDrawingTool ||
      tool === "eraser" ||
      tool === "text" ||
      tool === "sticky" ||
      ["rectangle", "ellipse", "diamond", "triangle", "star", "cloud", "line", "arrow"].includes(
        tool
      );
    if (isContentTool && !canStartInkAt(wp.x, wp.y)) {
      beginPan(cp.x, cp.y);
      capturePointer(e);
      return;
    }

    // The press survived the gate, so it is aimed at the page — but it may
    // still be in the grab margin just outside it. Content starts from `ip`,
    // which is on the paper; everything else (hit-testing, panning, marquee)
    // keeps using the honest `wp`.
    const ip = isNb ? clampToSheet(wp.x, wp.y, pageDim.width, pageDim.height) : wp;

    if (e.button !== 0 && e.pointerType === "mouse") return;

    // 1. Check resize/rotate handle
    const target = e.target as HTMLElement | SVGElement;
    const handleName = target.getAttribute?.("data-handle") as ResizeHandle | null;
    if (handleName && selectedIds.length > 0) {
      const el = elements.find((x) => x.id === selectedIds[0]);
      if (el && !el.locked) { // locked elements expose no resize/rotate handles
        commitHistory();
        if (handleName === "rotate") {
          const center = getElementCenter(el);
          const startAngle = Math.atan2(wp.y - center.y, wp.x - center.x);
          setInteraction({
            kind: "rotating",
            originalElement: { ...el },
            startAngle,
            centerX: center.x,
            centerY: center.y,
          });
        } else {
          setInteraction({
            kind: "resizing",
            handle: handleName,
            originalElement: { ...el },
            startWorldX: wp.x,
            startWorldY: wp.y,
          });
        }
        capturePointer(e);
        return;
      }
    }

    // 2. CONNECT Tool
    if (tool === "connect") {
      const hit = findElementAt(wp.x, wp.y, isTouch);
      if (hit && activeBoardId) {
        const ports = getNodeAnchorPorts(hit);
        let bestAnchor: NodeAnchor = "right";
        let minDist = Infinity;
        for (const [k, pt] of Object.entries(ports)) {
          const d = Math.hypot(pt.x - wp.x, pt.y - wp.y);
          if (d < minDist) {
            minDist = d;
            bestAnchor = k as NodeAnchor;
          }
        }

        setInteraction({
          kind: "connecting",
          sourceElementId: hit.id,
          sourceAnchor: bestAnchor,
          currentWorldX: wp.x,
          currentWorldY: wp.y,
        });
        capturePointer(e);
        return;
      }
      // Connect tool with no node under the pointer: swallow the gesture —
      // never fall through to the select tool's rubber-band branch.
      return;
    }

    // 3. Freehand Drawing Tools (Pen, Highlighter, Marker, Brush, Calligraphy, Pencil)
    if (isDrawingTool) {
      const strokeId = nanoid(8);
      // R1-DEF-02: Explicitly bind drawingPointerId to isolate inking stream
      drawingPointerIdRef.current = e.pointerId;

      // A pen reports 0..1 while touching. A 0 is a sample with no pressure
      // reading (it happens on the first sample of some strokes), not the
      // lightest touch: taken literally it drew a hairline start. It falls
      // back to the last real reading; a mouse reports 0.5 anyway.
      const rawPressure = e.pressure > 0 ? e.pressure : 0.5;
      lastPenPressureRef.current = rawPressure;
      // This pen's own feel (see penFeelFor).
      const feel = penFeelFor(touchSettings, tool);
      const pressure = calibratePressure(rawPressure, feel.sensitivity, feel.curve);

      const color = getToolColor(style, tool);
      const strokeWidth = getToolSize(style, tool);
      const strokeStyle = tool as StrokeStyle;
      const smoothing = feel.smoothing;

      deferSavesWhileWriting();
      // Initialize transient stroke buffer in ref (ZERO React state)
      liveDraftStrokeRef.current = {
        id: strokeId,
        originX: ip.x,
        originY: ip.y,
        color,
        strokeWidth,
        strokeStyle,
        smoothing,
        createdAt: Date.now(),
        points: [[0, 0, pressure]],
      };
      predictedPointsRef.current = [];

      // Configure direct DOM nodes immediately for zero-frame touchdown response
      const preset = PEN_TYPE_PRESETS[strokeStyle] || PEN_TYPE_PRESETS.gel;
      const g = liveDraftGroupRef.current;
      const pathEl = liveDraftPathRef.current;
      if (g && pathEl) {
        g.setAttribute("transform", `translate(${ip.x}, ${ip.y})`);
        g.style.display = ""; // Unhide
        pathEl.setAttribute("fill", color);
        pathEl.style.opacity = String(preset.opacity ?? 1);
        pathEl.style.mixBlendMode = preset.mixBlendMode || "normal";
        if (preset.grain) {
          pathEl.setAttribute("filter", "url(#pencil-grain)");
        } else {
          pathEl.removeAttribute("filter");
        }
        // Render initial touchdown dot
        applyLiveDraftStroke();
      }

      // Auto-straighten deadband anchor initialization (R1-DEF-08 / D4)
      autoStraightenAnchorRef.current = { x: ip.x, y: ip.y };

      // Set interaction state (only 1 React state update at touchdown; none during move)
      setInteraction({ kind: "drawing", elementId: strokeId, tool });
      capturePointer(e);
      return;
    }

    // 4. Eraser Tool
    if (tool === "eraser") {
      // A new press starts a new sweep; otherwise it would erase a line all the
      // way from wherever the last stroke ended.
      lastErasePosRef.current = null;
      eraseAt(ip.x, ip.y, isTouch, true);
      setInteraction({ kind: "erasing" });
      capturePointer(e);
      return;
    }

    // 5. Shape Creation Tools
    if (["rectangle", "ellipse", "diamond", "triangle", "star", "cloud", "line", "arrow"].includes(tool)) {
      const shapeId = nanoid(8);
      let newShape: WhiteboardElement;

      const common = {
        id: shapeId,
        x: ip.x,
        y: ip.y,
        rotation: 0,
        opacity: 1,
        strokeColor: style.shapeStrokeColor,
        fillColor: style.shapeFillColor,
        fillStyle: style.fillStyle,
        dashStyle: style.dashStyle,
        strokeWidth: style.strokeWidth,
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };

      if (tool === "line") {
        newShape = { ...common, type: "line", x2: 1, y2: 1 };
      } else if (tool === "arrow") {
        newShape = {
          ...common,
          type: "arrow",
          x2: 1,
          y2: 1,
          startArrowhead: "none",
          endArrowhead: "arrow",
          arrowheadSize: 12,
        };
      } else {
        newShape = { ...common, type: tool as any, width: 2, height: 2 };
      }

      setDraftElement(newShape);
      setInteraction({ kind: "creating-shape", elementId: shapeId, startX: ip.x, startY: ip.y });
      capturePointer(e);
      return;
    }

    // 6. Text Tool Click -> Place text directly at clicked position
    if (tool === "text") {
      const textId = nanoid(8);
      const posX = snapToGridActive ? snapToGrid(ip.x, paperSize) : ip.x;
      const posY = snapToGridActive ? snapToGrid(ip.y, paperSize) : ip.y;
      const newText: TextElement = {
        id: textId,
        type: "text",
        x: posX,
        y: posY,
        width: 220,
        height: 48,
        rotation: 0,
        opacity: 1,
        text: "",
        color: style.textColor,
        fontSize: style.fontSize,
        fontFamily: style.fontFamily,
        fontWeight: style.fontWeight,
        align: style.textAlign,
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };
      addElement(newText, true);
      setEditingId(textId);
      setTool("select");
      return;
    }

    // 7. Sticky Note Tool Click
    if (tool === "sticky") {
      const stickyId = nanoid(8);
      const posX = snapToGridActive ? snapToGrid(ip.x - 100, paperSize) : ip.x - 100;
      const posY = snapToGridActive ? snapToGrid(ip.y - 80, paperSize) : ip.y - 80;
      const newSticky: StickyElement = {
        id: stickyId,
        type: "sticky",
        x: posX,
        y: posY,
        width: 200,
        height: 160,
        rotation: 0,
        opacity: 1,
        text: "",
        color: style.stickyColor,
        fontSize: style.fontSize,
        align: style.textAlign,
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };
      addElement(newSticky, true);
      setEditingId(stickyId);
      setTool("select");
      return;
    }

    // 8. Lasso Tool: Freeform polygon selection. Strictness is captured
    // here, not read live: flipping the setting mid-loop must not change
    // what the loop in progress means.
    if (tool === "lasso") {
      if (!e.shiftKey) clearSelection();
      setInteraction({
        kind: "lasso-selecting",
        points: [{ x: wp.x, y: wp.y }],
        screenPoints: [{ x: cp.x, y: cp.y }],
        strict: useWhiteboard.getState().lassoStrict,
      });
      capturePointer(e);
      return;
    }

    // 9. Select Tool: Hit test elements
    const rawHit = findElementAt(wp.x, wp.y, isTouch);
    const hit = rawHit && (lockedMode || passesSelectFilter(rawHit, selectFilter)) ? rawHit : null;
    if (hit) {
      // A finger landing on an object it has not already selected does NOT
      // grab it. That one behaviour is what threw the transform box — resize
      // and rotate handles and all — onto the screen every time a hand came to
      // rest on a line of text, and dragged the text away when the hand
      // shifted. Selecting by finger is Android's long press now; a finger
      // drag pans, exactly as it does in every tablet note app.
      // Already selected: hold still and the options menu opens; drag and the
      // object moves (Radix cancels its own timer on movement).
      if (isTouch && selectedIds.includes(hit.id)) armContextMenu(true);

      if (isTouch && !e.shiftKey && !selectedIds.includes(hit.id)) {
        // A clean fingertip tap selects at once — the tap-to-select,
        // press-drag-to-move contract every tablet note app uses. The drag
        // that follows still pans (beginPan below), so finger navigation is
        // unchanged; only the mystery second press disappears. Anything else
        // (a palm-sized patch, mid-edit) keeps the deliberate long press, so
        // a resting hand still cannot pop the transform box open.
        if (
          shouldSelectOnTouchTap({
            verdict: touchVerdict,
            hitSelected: false,
            shiftKey: e.shiftKey,
            editing: editingId !== null,
          })
        ) {
          setSelected([hit.id]);
          touchInteractionRef.current = { pointerId: e.pointerId, priorSelection: selectedIds };
        } else if (!editingId) {
          // Mid-edit a touch is overwhelmingly a resting hand rather than a
          // reach for another object, so it does not even arm. Leaving the
          // editor still works — the tap blurs it as it always did.
          armLongPressSelect(e, hit);
        }
        beginPan(cp.x, cp.y);
        capturePointer(e);
        return;
      }

      if (e.shiftKey) {
        if (selectedIds.includes(hit.id)) {
          setSelected(selectedIds.filter((id) => id !== hit.id));
        } else {
          addToSelection(hit.id);
        }
      } else {
        if (!selectedIds.includes(hit.id)) {
          setSelected([hit.id]);
        }
      }

      const targets = (
        selectedIds.includes(hit.id)
          ? elements.filter((el) => selectedSet.has(el.id))
          : [hit]
      ).filter((el) => !el.locked); // locked elements never move

      setInteraction({
        kind: "moving",
        startWorldX: wp.x,
        startWorldY: wp.y,
        originalElements: targets.map((el) => ({ ...el })),
      });
      if (isTouch) {
        touchInteractionRef.current = { pointerId: e.pointerId, priorSelection: selectedIds };
      }
      capturePointer(e);
    } else {
      if (!e.shiftKey) clearSelection();
      setInteraction({
        kind: "selecting",
        startX: cp.x,
        startY: cp.y,
        worldX: wp.x,
        worldY: wp.y,
      });
      capturePointer(e);
    }
  };

  // Pointer Move
  const handlePointerMove = (e: React.PointerEvent<SVGSVGElement>) => {
    lastPointerPosRef.current = { clientX: e.clientX, clientY: e.clientY };
    // A pen or mouse shows the ring while hovering; a finger has no hover, so
    // it shows only while touching.
    placeEraserCursor(
      e.clientX,
      e.clientY,
      tool === "eraser" && (e.pointerType !== "touch" || e.buttons > 0)
    );

    if (tool === "laser") {
      const lp = getWorldPoint(e.clientX, e.clientY);
      if (laser.isActive(e.pointerId)) {
        laser.move(lp.x, lp.y);
        // A finger pointing with the laser is still a finger: keep its
        // position current, or a second finger's pinch starts from where
        // this one first landed and the page jumps.
        const t = activeTouchesRef.current.get(e.pointerId);
        if (t) {
          if (Math.hypot(e.clientX - t.startX, e.clientY - t.startY) > 6) touchMovedRef.current = true;
          activeTouchesRef.current.set(e.pointerId, { ...t, x: e.clientX, y: e.clientY });
        }
        return;
      }
      // A hovering S Pen (or a mouse) carries the dot without pressing: the
      // presenter's way to point.
      if (e.buttons === 0 && e.pointerType !== "touch") laser.hover(lp.x, lp.y, e.pointerType);
    }

    // S Pen & Stylus Hover Preview Cursor
    const isPen = e.pointerType === "pen";
    const isDrawingTool = isStrokeTool(tool);
    const showPenHover =
      touchSettings.penHoverIndicator !== false &&
      isDrawingTool &&
      tool !== "eraser" &&
      (isPen || e.pointerType === "mouse") &&
      e.buttons === 0;
    placePenHoverCursor(e.clientX, e.clientY, showPenHover);
    // A hovering pen (or mouse) over the gap between two sheets shows "+".
    if (isNb && e.buttons === 0 && e.pointerType !== "touch" && !gapPlusTimerRef.current && tool !== "laser" && tool !== "textselect") {
      const hw = getWorldPoint(e.clientX, e.clientY);
      showGapPlus(gapAt(hw.x, hw.y));
    }

    // Keep the suppression window fed while the stylus is drawing OR merely
    // hovering: a hovering pen means the hand is in writing position, which is
    // precisely when the palm is on the glass.
    if (e.pointerType === "pen") lastPenAtRef.current = Date.now();

    // The button is read here too, not only on contact: this is what makes
    // hovering with the button held arm the eraser, and what frees the pen the
    // instant the button goes up rather than when the nib finally lifts.
    syncStylusErase(e);

    const press = longPressRef.current;
    if (press && press.pointerId === e.pointerId) {
      // Moved before the hold completed: this was a pan, not a grab.
      if (exceedsLongPressSlop(e.clientX - press.startX, e.clientY - press.startY)) {
        cancelLongPress();
      }
    }

    // A long press has selected an object; the drag that follows moves it. The
    // origin is THIS event's world point rather than the press point, so the
    // object cannot jump by however far the finger drifted while holding. The
    // event is consumed so the in-progress pan does not also scroll the board.
    const pending = pendingMoveRef.current;
    if (pending && pending.pointerId === e.pointerId) {
      pendingMoveRef.current = null;
      const el = elements.find((x) => x.id === pending.elementId);
      if (el && !el.locked) {
        const origin = getWorldPoint(e.clientX, e.clientY);
        setInteraction({
          kind: "moving",
          startWorldX: origin.x,
          startWorldY: origin.y,
          originalElements: [{ ...el }],
        });
        return;
      }
    }

    // Update touch position
    if (activeTouchesRef.current.has(e.pointerId)) {
      const orig = activeTouchesRef.current.get(e.pointerId)!;
      if (Math.hypot(e.clientX - orig.startX, e.clientY - orig.startY) > 6) {
        touchMovedRef.current = true;
      }
      activeTouchesRef.current.set(e.pointerId, { ...orig, x: e.clientX, y: e.clientY });
    }

    // Multi-touch Pinch to Zoom & 2-Finger Pan Handling
    // Guard against Defect D5: Dual palm contacts during inking must never trigger pan/zoom.
    const nonPalmTouches = Array.from(activeTouchesRef.current.entries())
      .filter(([id]) => !rejectedPalmsRef.current.has(id))
      .map(([, t]) => t);

    if (
      nonPalmTouches.length === 2 &&
      !penActiveRef.current &&
      drawingPointerIdRef.current === null &&
      interaction.kind !== "drawing"
    ) {
      const touches = nonPalmTouches;
      const currDist = Math.hypot(touches[0].x - touches[1].x, touches[0].y - touches[1].y);
      const midClientX = (touches[0].x + touches[1].x) / 2;
      const midClientY = (touches[0].y + touches[1].y) / 2;
      const midContainer = getContainerPoint(midClientX, midClientY);

      // 1. Pan delta tracking (pure 2-finger pan and pan while pinching)
      if (!lastTouchMidRef.current) {
        // A fresh two-finger gesture: its throw is measured from here.
        stopMomentum();
        panSamplesRef.current = [];
      }
      recordPanSample(midClientX, midClientY);
      if (lastTouchMidRef.current) {
        const dx = midClientX - lastTouchMidRef.current.x;
        const dy = midClientY - lastTouchMidRef.current.y;
        if (Math.hypot(dx, dy) > 0.5) {
          // Coalesced to one camera write per frame, exactly like the
          // single-pointer pan — two fingers used to be the WORST case,
          // because both fingers' moves each drove a full re-render.
          queuePan(dx, dy);
        }
      }
      lastTouchMidRef.current = { x: midClientX, y: midClientY };

      // 2. Pinch zoom — only once it is clearly a PINCH.
      //
      // The old gate was `|scale - 1| > 0.005`: half a percent. Two fingers
      // never travel perfectly parallel, so an ordinary two-finger SCROLL
      // drifted past that within a few pixels and the page zoomed slightly the
      // whole way down. That both looks like judder and re-renders the canvas
      // on every move, which is why scrolling felt heavy. Zoom now has to be
      // asked for, and once asked for it stays engaged for the gesture.
      if (pinchStartDistanceRef.current !== null && pinchStartDistanceRef.current > 10) {
        const scale = currDist / pinchStartDistanceRef.current;
        if (!pinchEngagedRef.current) {
          const spread = Math.abs(currDist - pinchStartDistanceRef.current);
          if (Math.abs(scale - 1) > 0.12 && spread > 32) pinchEngagedRef.current = true;
        }
        if (pinchEngagedRef.current) {
          zoomTo(pinchStartZoomRef.current * scale, midContainer.x, midContainer.y, viewport);
        }
      }
      return;
    }

    // After the pinch above, so a second finger always wins over a selection.
    if (textSelect.pointerMove(e)) return;

    const wp = getWorldPoint(e.clientX, e.clientY);
    const cp = getContainerPoint(e.clientX, e.clientY);
    // Content follows the clamped point so a gesture that runs off a notebook
    // page stops at the margin instead of trailing ink across the desk.
    const ip = isNb ? clampToSheet(wp.x, wp.y, pageDim.width, pageDim.height) : wp;

    // Continuous drag-erasing (never while another tool's gesture is active)
    if (interaction.kind === "erasing" || (tool === "eraser" && e.buttons > 0 && interaction.kind === "idle")) {
      // The idle branch means we never saw a pointerdown (pointer entered
      // already held, or capture was lost). Continuing the previous gesture's
      // sweep from there would erase a straight line between two unrelated
      // places, so start a fresh sweep instead.
      if (interaction.kind !== "erasing") lastErasePosRef.current = null;
      eraseAt(ip.x, ip.y, e.pointerType === "touch", false);
      return;
    }

    // Capture area: a box keeps its first point and follows the pointer; a
    // loop records the trail, thinned like the lasso's.
    if (interaction.kind === "capturing") {
      if (e.pointerId !== interaction.pointerId) return;
      const first = interaction.points[0];
      if (interaction.shape === "rectangle") {
        setInteraction({ ...interaction, points: [first, { x: wp.x, y: wp.y }] });
      } else {
        const lastPt = interaction.points[interaction.points.length - 1];
        if (!lastPt || Math.hypot(wp.x - lastPt.x, wp.y - lastPt.y) >= 2 / Math.max(camera.zoom, 0.01)) {
          setInteraction({ ...interaction, points: [...interaction.points, { x: wp.x, y: wp.y }] });
        }
      }
      return;
    }

    // Lasso Freeform Selection
    if (interaction.kind === "lasso-selecting") {
      const lastPt = interaction.points[interaction.points.length - 1];
      if (!lastPt || Math.hypot(wp.x - lastPt.x, wp.y - lastPt.y) >= 2) {
        const updatedPoints = [...interaction.points, { x: wp.x, y: wp.y }];
        const updatedScreenPoints = [...interaction.screenPoints, { x: cp.x, y: cp.y }];
        setInteraction({
          kind: "lasso-selecting",
          points: updatedPoints,
          screenPoints: updatedScreenPoints,
          strict: interaction.strict,
        });
        // No selection while the loop is still open. Judging it live meant
        // judging the half-drawn shape SVG closes for you — a wedge hinged on
        // the start point — so things flicked in and out of the selection as
        // that chord swept across them. The loop is only a loop once the pen
        // lifts, which is when Samsung decides too.
      }
      return;
    }

    // Panning
    if (interaction.kind === "panning") {
      // The gesture's last position is a REF: updating it through
      // setInteraction re-rendered the whole canvas on every pointer event.
      const last = panLastRef.current ?? { x: interaction.lastX, y: interaction.lastY };
      const dx = cp.x - last.x;
      const dy = cp.y - last.y;
      panLastRef.current = { x: cp.x, y: cp.y };
      recordPanSample(cp.x, cp.y);

      queuePan(dx, dy);
      return;
    }

    // Connecting (drawing arrow to target node)
    if (interaction.kind === "connecting") {
      const hit = findElementAt(wp.x, wp.y, e.pointerType === "touch");
      let targetAnchor: NodeAnchor | undefined = undefined;
      if (hit && hit.id !== interaction.sourceElementId) {
        const ports = getNodeAnchorPorts(hit);
        let best: NodeAnchor = "left";
        let minDist = Infinity;
        for (const [k, pt] of Object.entries(ports)) {
          const d = Math.hypot(pt.x - wp.x, pt.y - wp.y);
          if (d < minDist) {
            minDist = d;
            best = k as NodeAnchor;
          }
        }
        targetAnchor = best;
      }

      setInteraction({
        ...interaction,
        currentWorldX: wp.x,
        currentWorldY: wp.y,
        targetElementId: hit && hit.id !== interaction.sourceElementId ? hit.id : undefined,
        targetAnchor,
      });
      return;
    }

    // Freehand Drawing (Direct DOM + RAF Coalescence + Prediction)
    if (liveDraftStrokeRef.current) {
      // R1-DEF-02: Isolate pen stream from palm moves
      if (drawingPointerIdRef.current !== null && e.pointerId !== drawingPointerIdRef.current) {
        return;
      }

      const live = liveDraftStrokeRef.current;
      if (!live) return;

      // 1. High-Frequency Coalesced Events: S Pen hardware digitizer samples at 240-360Hz.
      const native = e.nativeEvent as unknown as {
        getCoalescedEvents?: () => PointerEvent[];
        getPredictedEvents?: () => PointerEvent[];
      };
      const rawEvents: PointerEvent[] =
        typeof native?.getCoalescedEvents === "function"
          ? native.getCoalescedEvents()
          : [];
      const eventsToProcess: Array<PointerEvent | React.PointerEvent<SVGSVGElement>> =
        rawEvents.length > 0 ? rawEvents : [e];

      const { sensitivity, curve } = penFeelFor(touchSettings, live.strokeStyle);

      // Cache container rect once per event batch
      const containerRect = containerRef.current?.getBoundingClientRect();

      const ptsToAdd: Array<[number, number, number]> = [];
      for (const ev of eventsToProcess) {
        const clientX = ev.clientX;
        const clientY = ev.clientY;
        const cX = containerRect ? clientX - containerRect.left : clientX;
        const cY = containerRect ? clientY - containerRect.top : clientY;
        const evWp = screenToWorld(cX, cY, camera, viewport);
        const evIp = isNb ? clampToSheet(evWp.x, evWp.y, pageDim.width, pageDim.height) : evWp;

        // R1-DEF-05: Accurate light pressure; speed fallback only when not pen
        const isPenEvent = ev.pointerType === "pen";
        let rawP: number;
        if (isPenEvent) {
          if (ev.pressure > 0) lastPenPressureRef.current = ev.pressure;
          rawP = lastPenPressureRef.current;
        } else {
          rawP = ev.pressure > 0 ? ev.pressure : computePressureFromSpeed(live.points);
        }
        const p = calibratePressure(rawP, sensitivity, curve);

        // Append relative coordinate to transient buffer
        live.points.push([evIp.x - live.originX, evIp.y - live.originY, p]);
        ptsToAdd.push([evIp.x, evIp.y, p]);
      }

      // R1-DEF-04: Speculative Hardware Prediction via getPredictedEvents()
      const rawPredicted: PointerEvent[] =
        typeof native?.getPredictedEvents === "function"
          ? native.getPredictedEvents() || []
          : [];

      const newPredictedPoints: Array<[number, number, number]> = [];
      if (rawPredicted.length > 0 && ptsToAdd.length > 0) {
        const lastReal = ptsToAdd[ptsToAdd.length - 1];
        const lastCalibratedP = lastReal[2];

        for (const pe of rawPredicted.slice(0, 3)) {
          const peClientX = pe.clientX;
          const peClientY = pe.clientY;
          const peCX = containerRect ? peClientX - containerRect.left : peClientX;
          const peCY = containerRect ? peClientY - containerRect.top : peClientY;
          const peWp = screenToWorld(peCX, peCY, camera, viewport);
          const peIp = isNb ? clampToSheet(peWp.x, peWp.y, pageDim.width, pageDim.height) : peWp;

          // Outlier & deadband guard: between 1px and 40px from latest real hardware point
          const distFromLast = Math.hypot(peIp.x - lastReal[0], peIp.y - lastReal[1]);
          if (distFromLast >= 1.0 && distFromLast <= 40.0) {
            const isPredPen = pe.pointerType === "pen";
            const predP =
              isPredPen && pe.pressure > 0
                ? calibratePressure(pe.pressure, sensitivity, curve)
                : lastCalibratedP;
            newPredictedPoints.push([peIp.x - live.originX, peIp.y - live.originY, predP]);
          }
        }
      }
      // Replace previous predictions with new frame's predictions
      predictedPointsRef.current = newPredictedPoints;

      // 2. Draw-and-hold auto-straighten detection with 5px deadband (R1-DEF-08 & D4)
      if (touchSettings.penAutoStraighten !== false) {
        const lastPt = live.points[live.points.length - 1];
        const lastWorldX = lastPt[0] + live.originX;
        const lastWorldY = lastPt[1] + live.originY;

        const anchor = autoStraightenAnchorRef.current;
        const distFromAnchor = anchor
          ? Math.hypot(lastWorldX - anchor.x, lastWorldY - anchor.y)
          : Infinity;

        // A held pen drifts a few SCREEN pixels; in world units that depends
        // on the zoom, so a fixed world distance was too tight zoomed out.
        if (distFromAnchor > HOLD_SLOP_PX / camera.zoom) {
          // Intentional movement: reset deadband anchor and rearm timer
          autoStraightenAnchorRef.current = { x: lastWorldX, y: lastWorldY };
          clearAutoStraightenTimer();

          if (!isAutoStraightenedRef.current) {
            autoStraightenTimerRef.current = setTimeout(() => {
              if (!liveDraftStrokeRef.current) return;
              const stroke = liveDraftStrokeRef.current;
              // The samples recorded while the pen was held still add length
              // the line never had - a ruler-straight line plus a one-second
              // hold measured as a curve - so they are left out of the test.
              const drawn = trimHoldTail(stroke.points, (HOLD_SLOP_PX * 1.5) / camera.zoom);
              const isStraight = isStrokeStraight(
                drawn,
                tool === "highlighter" ? 0.82 : 0.88
              );
              if (isStraight) {
                isAutoStraightenedRef.current = true;
                stroke.points = straightenStrokePoints(drawn, 8);
                applyLiveDraftStroke();
              }
            }, 550);
          }
        }

        // If already auto-straightened, rubber-band straight line to current nib position
        if (isAutoStraightenedRef.current) {
          const first = live.points[0];
          const relX = ip.x - live.originX;
          const relY = ip.y - live.originY;
          const avgP = live.points[0]?.[2] ?? 0.5;
          live.points = straightenStrokePoints([first, [relX, relY, avgP]], 8);
        }
      }

      // 3. Batch DOM updates to VSYNC via requestAnimationFrame
      // ZERO React renders (setDraftElement completely removed)
      scheduleDraftFlush();
      return;
    }

    // Shape Creation Drag
    if (interaction.kind === "creating-shape" && draftElement) {
      let startX = interaction.startX;
      let startY = interaction.startY;
      let currX = ip.x;
      let currY = ip.y;

      if (snapToGridActive) {
        startX = snapToGrid(startX, paperSize);
        startY = snapToGrid(startY, paperSize);
        currX = snapToGrid(currX, paperSize);
        currY = snapToGrid(currY, paperSize);
      }

      const minX = Math.min(startX, currX);
      const minY = Math.min(startY, currY);
      const width = Math.abs(currX - startX);
      const height = Math.abs(currY - startY);

      if (draftElement.type === "line" || draftElement.type === "arrow") {
        setDraftElement({
          ...draftElement,
          x: startX,
          y: startY,
          x2: currX - startX,
          y2: currY - startY,
        } as any);
      } else {
        setDraftElement({
          ...draftElement,
          x: minX,
          y: minY,
          width: Math.max(width, 2),
          height: Math.max(height, 2),
        } as any);
      }
      return;
    }

    // Moving elements
    if (interaction.kind === "moving") {
      const dx = wp.x - interaction.startWorldX;
      const dy = wp.y - interaction.startWorldY;

      for (const orig of interaction.originalElements) {
        let newX = orig.x + dx;
        let newY = orig.y + dy;
        if (snapToGridActive) {
          newX = snapToGrid(newX, paperSize);
          newY = snapToGrid(newY, paperSize);
        }
        // Dragging something off the sheet would hide it: the desk is not
        // exported, printed, or reachable once you scroll. Translate it back
        // rather than resize it, so the drawing keeps its shape.
        if (isNb) {
          const b = getElementBounds(orig);
          const fixed = clampBoxToSheet(
            newX,
            newY,
            b.width,
            b.height,
            pageDim.width,
            pageDim.height
          );
          newX = fixed.x;
          newY = fixed.y;
        }
        updateElement(orig.id, { x: newX, y: newY }, false);
      }
      return;
    }

    // Resizing element
    if (interaction.kind === "resizing") {
      const { handle, originalElement, startWorldX, startWorldY } = interaction;
      const dx = wp.x - startWorldX;
      const dy = wp.y - startWorldY;

      // 1. Line & Arrow: Update (x2, y2) vector correctly instead of treating as bounding box
      if (originalElement.type === "line" || originalElement.type === "arrow") {
        const b = getElementBounds(originalElement);
        const p1 = { x: originalElement.x, y: originalElement.y };
        const p2 = { x: originalElement.x + (originalElement as any).x2, y: originalElement.y + (originalElement as any).y2 };
        const oldW = Math.max(b.width, 1);
        const oldH = Math.max(b.height, 1);

        let newX = b.x;
        let newY = b.y;
        let newW = b.width;
        let newH = b.height;

        if (handle.includes("e")) newW = Math.max(b.width + dx, 10);
        if (handle.includes("s")) newH = Math.max(b.height + dy, 10);
        if (handle.includes("w")) {
          const potentialW = b.width - dx;
          if (potentialW >= 10) {
            newX = b.x + dx;
            newW = potentialW;
          }
        }
        if (handle.includes("n")) {
          const potentialH = b.height - dy;
          if (potentialH >= 10) {
            newY = b.y + dy;
            newH = potentialH;
          }
        }

        const u1 = (p1.x - b.x) / oldW;
        const v1 = (p1.y - b.y) / oldH;
        const u2 = (p2.x - b.x) / oldW;
        const v2 = (p2.y - b.y) / oldH;

        const newP1x = newX + u1 * newW;
        const newP1y = newY + v1 * newH;
        const newP2x = newX + u2 * newW;
        const newP2y = newY + v2 * newH;

        updateElement(
          originalElement.id,
          {
            x: newP1x,
            y: newP1y,
            x2: newP2x - newP1x,
            y2: newP2y - newP1y,
          } as any,
          false
        );
        return;
      }

      // 2. Rotated element resizing: compute handle displacement in local rotated coordinate space
      const rot = originalElement.rotation || 0;
      if (rot !== 0) {
        const cos = Math.cos(rot);
        const sin = Math.sin(rot);
        const localDx = dx * cos + dy * sin;
        const localDy = -dx * sin + dy * cos;

        const origW = (originalElement as any).width || 100;
        const origH = (originalElement as any).height || 100;
        const origCx = originalElement.x + origW / 2;
        const origCy = originalElement.y + origH / 2;

        let newW = origW;
        let newH = origH;
        let localCenterShiftX = 0;
        let localCenterShiftY = 0;

        if (handle.includes("e")) {
          newW = Math.max(origW + localDx, 20);
          localCenterShiftX += (newW - origW) / 2;
        }
        if (handle.includes("w")) {
          newW = Math.max(origW - localDx, 20);
          localCenterShiftX -= (newW - origW) / 2;
        }
        if (handle.includes("s")) {
          newH = Math.max(origH + localDy, 20);
          localCenterShiftY += (newH - origH) / 2;
        }
        if (handle.includes("n")) {
          newH = Math.max(origH - localDy, 20);
          localCenterShiftY -= (newH - origH) / 2;
        }

        // Photos keep their proportions on a corner drag (see lockAspect).
        if (originalElement.type === "image" && handle.length === 2) {
          const locked = lockAspect(origW, origH, newW, newH);
          newW = locked.width;
          newH = locked.height;
          localCenterShiftX = ((handle.includes("e") ? 1 : -1) * (newW - origW)) / 2;
          localCenterShiftY = ((handle.includes("s") ? 1 : -1) * (newH - origH)) / 2;
        }

        const worldCenterShiftX = localCenterShiftX * cos - localCenterShiftY * sin;
        const worldCenterShiftY = localCenterShiftX * sin + localCenterShiftY * cos;

        const newCx = origCx + worldCenterShiftX;
        const newCy = origCy + worldCenterShiftY;

        const newX = newCx - newW / 2;
        const newY = newCy - newH / 2;

        updateElement(
          originalElement.id,
          { x: newX, y: newY, width: newW, height: newH } as any,
          false
        );
        return;
      }

      // 3. Unrotated box resizing
      const b = getElementBounds(originalElement);
      let newX = b.x;
      let newY = b.y;
      let newW = b.width;
      let newH = b.height;

      if (handle.includes("e")) newW = Math.max(b.width + dx, 20);
      if (handle.includes("s")) newH = Math.max(b.height + dy, 20);
      if (handle.includes("w")) {
        const potentialW = b.width - dx;
        if (potentialW >= 20) {
          newX = b.x + dx;
          newW = potentialW;
        }
      }
      if (handle.includes("n")) {
        const potentialH = b.height - dy;
        if (potentialH >= 20) {
          newY = b.y + dy;
          newH = potentialH;
        }
      }

      // Photos keep their proportions on a corner drag, anchored at the
      // opposite corner so the one you hold follows your finger.
      if (originalElement.type === "image" && handle.length === 2) {
        const locked = lockAspect(b.width, b.height, newW, newH);
        newW = locked.width;
        newH = locked.height;
        newX = handle.includes("w") ? b.x + b.width - newW : b.x;
        newY = handle.includes("n") ? b.y + b.height - newH : b.y;
      }

      if (snapToGridActive) {
        newX = snapToGrid(newX, paperSize);
        newY = snapToGrid(newY, paperSize);
        newW = Math.max(snapToGrid(newW, paperSize), paperSize);
        newH = Math.max(snapToGrid(newH, paperSize), paperSize);
      }

      updateElement(originalElement.id, { x: newX, y: newY, width: newW, height: newH } as any, false);
      return;
    }

    // Rotating element
    if (interaction.kind === "rotating") {
      const { originalElement, startAngle, centerX, centerY } = interaction;
      const currentAngle = Math.atan2(wp.y - centerY, wp.x - centerX);
      const deltaAngle = currentAngle - startAngle;
      // Normalize to [0, 2π) so stored rotations are never negative
      const newRotation =
        (((originalElement.rotation || 0) + deltaAngle) % (Math.PI * 2) + Math.PI * 2) %
        (Math.PI * 2);
      // Snaps to straight within ~4 degrees: a photo you meant to leave level
      // otherwise ends up a hair crooked every time you touch the handle.
      updateElement(originalElement.id, { rotation: snapRotation(newRotation) }, false);
      return;
    }

    // Rubber band selection
    if (interaction.kind === "selecting") {
      const x = Math.min(interaction.startX, cp.x);
      const y = Math.min(interaction.startY, cp.y);
      const w = Math.abs(cp.x - interaction.startX);
      const h = Math.abs(cp.y - interaction.startY);
      setRubberBand({ x, y, w, h });

      const p1 = screenToWorld(x, y, camera, viewport);
      const p2 = screenToWorld(x + w, y + h, camera, viewport);
      const hitIds: string[] = [];

      for (const el of elements) {
        if (el.type === "connection") continue;
        // Locked elements can't be rubber-band selected - except in locked-items mode, where ONLY they can.
        if (!pickableNow(el, lockedMode)) continue;
        if (!lockedMode && !passesSelectFilter(el, selectFilter)) continue;
        const b = getElementBounds(el);
        if (b.x + b.width >= p1.x && b.x <= p2.x && b.y + b.height >= p1.y && b.y <= p2.y) {
          hitIds.push(el.id);
        }
      }
      setSelected(hitIds);
    }
  };

  // Pointer Up
  /**
   * Drop every per-pointer gesture record for a pointer that has gone away.
   * A long-press timer left armed after the finger lifted would select an
   * object half a second later, with nothing on the glass to explain it.
   */
  const releaseGestureRefs = (pointerId: number) => {
    // Re-arm for the NEXT press. Radix reads `disabled` when the press starts,
    // so arming mid-press is too late — disarming mid-press still works, since
    // Radix cancels its pending timer as soon as the prop flips.
    // Still gated on there being a selection for the menu to act on.
    armContextMenu(selectedIds.length > 0);
    if (longPressRef.current?.pointerId === pointerId) cancelLongPress();
    if (pendingMoveRef.current?.pointerId === pointerId) pendingMoveRef.current = null;
    if (touchInteractionRef.current?.pointerId === pointerId) touchInteractionRef.current = null;
  };

  /**
   * Set once the Android bridge has spoken. From then on the NATIVE signal
   * alone decides press and release: the strokes it forwards have their button
   * bits stripped (see MainActivity), so the web-side checks would read every
   * one of them as "button released" and hand the pen back mid-erase - and a
   * nib lifted between two erase strokes would do the same while the button is
   * still held.
   */
  const nativeStylusRef = useRef(
    typeof window !== "undefined" &&
      (window as unknown as { Capacitor?: { getPlatform?: () => string } }).Capacitor?.getPlatform?.() ===
        "android"
  );

  /** Give the pen back after a stylus-button erase. */
  const releaseStylusErase = (fromNative = false) => {
    if (nativeStylusRef.current && !fromNative) return;
    const restore = stylusEraseRestoreRef.current;
    if (!restore) return;
    stylusEraseRestoreRef.current = null;
    setTool(restore);
    // Restoring the tool is not enough on its own. An "erasing" interaction
    // keeps erasing from the move handler REGARDLESS of the current tool, so
    // without this the eraser would run on under the restored pen until the
    // nib lifted — exactly the "stuck erasing" the button release is meant
    // to end.
    lastErasePosRef.current = null;
    setInteraction((prev) => (prev.kind === "erasing" ? { kind: "idle" } : prev));
  };

  /**
   * Borrow the eraser while the stylus barrel button (or the eraser end) is
   * held, and hand the pen back the moment it is released.
   *
   * Called from pointerdown AND pointermove so the button alone drives it:
   * press while hovering and the eraser is already armed before you touch the
   * paper; let go and you are back on your pen mid-stroke.
   */
  const engageStylusErase = () => {
    if (touchSettings.stylusButtonErases === false) return;
    if (stylusEraseRestoreRef.current !== null) return; // already borrowed
    // Already erasing by choice: there is nothing to borrow, and recording a
    // restore target here would strand the user in the eraser on release.
    if (tool === "eraser") return;
    // Pointing and reading tools have nothing to erase with: holding the
    // button while presenting must not wipe real ink.
    if (tool === "laser" || tool === "textselect") return;
    stylusEraseRestoreRef.current = tool;
    setTool("eraser");
  };

  const syncStylusErase = (e: React.PointerEvent<SVGSVGElement>) => {
    if (touchSettings.stylusButtonErases === false) return;
    if (nativeStylusRef.current) return; // Android: the bridge decides
    const action = stylusEraseTransition(stylusEraseRestoreRef.current !== null, e);
    if (action === "engage") engageStylusErase();
    else if (action === "release") releaseStylusErase();
  };

  // The NATIVE route, and on Android the only one that works.
  //
  // Chromium's WebView does not surface the S Pen side button to web content at
  // all — the in-app diagnostic showed no event whatsoever while it was held.
  // MainActivity.java reads Android's own MotionEvent.getButtonState() and
  // dispatches this CustomEvent, so the gesture is driven from outside the web
  // layer entirely. On Windows the pointer-event route above still does the job
  // and this listener simply never fires.
  const stylusBridgeRef = useRef({ engage: () => {}, release: () => {} });
  stylusBridgeRef.current = {
    engage: engageStylusErase,
    release: () => releaseStylusErase(true),
  };

  useEffect(() => {
    const onNativeButton = (e: Event) => {
      nativeStylusRef.current = true;
      const pressed = Boolean((e as CustomEvent).detail?.pressed);
      if (pressed) stylusBridgeRef.current.engage();
      else stylusBridgeRef.current.release();
    };
    window.addEventListener("pronotes:stylusbutton", onNativeButton);
    return () => window.removeEventListener("pronotes:stylusbutton", onNativeButton);
  }, []);

  /**
   * The pen can leave hover range with the button still down — lift it away
   * from the glass and no pointerup or pointercancel ever arrives. Without
   * this the borrowed eraser would still be held when the pen came back.
   */
  const handlePointerLeave = (e: React.PointerEvent<SVGSVGElement>) => {
    laser.hideHover();
    placeEraserCursor(0, 0, false); // pen out of hover range, or mouse gone
    placePenHoverCursor(0, 0, false);
    clearAutoStraightenTimer();
    isAutoStraightenedRef.current = false;
    if (!gapPlusTimerRef.current) showGapPlus(null);
    if (e.pointerType === "pen") releaseStylusErase();
  };

  /**
   * Turns a drawn area into a capture and opens the capture panel. A tap, a
   * flick or a line is not an area: nothing opens and the mode stays armed,
   * so you simply draw again.
   */
  const finishCapture = (drawn: Extract<InteractionMode, { kind: "capturing" }>) => {
    if (!activeBoard) return;
    const pts = drawn.points;
    const zoom = Math.max(camera.zoom, 0.01);
    let drawnRect: ReturnType<typeof boundsOfPoints> = null;
    let polygon: Array<{ x: number; y: number }> | undefined;
    if (drawn.shape === "rectangle") {
      if (pts.length >= 2) drawnRect = rectFromCorners(pts[0], pts[pts.length - 1]);
    } else if (pts.length >= 3 && polygonArea(pts) * zoom * zoom >= 24 * 24) {
      drawnRect = boundsOfPoints(pts);
      polygon = pts;
    }
    // Judged on screen: 12 px is a deliberate drag at any zoom.
    if (!drawnRect || drawnRect.width * zoom < 12 || drawnRect.height * zoom < 12) return;
    const anchorIndex = isNb ? Math.max(0, activeIndex) : 0;
    const region = clampCaptureRegion(activeBoard, anchorIndex, drawnRect);
    if (!region || region.width < CAPTURE_MIN_SIDE || region.height < CAPTURE_MIN_SIDE) return;
    useCapture.getState().open({
      source: { board: activeBoard, region, polygon, anchorIndex },
      origin: "area",
      shape: drawn.shape,
      zoom: camera.zoom,
      dpr: typeof window !== "undefined" ? window.devicePixelRatio || 1 : 1,
    });
  };

  // ---- Shape recognition ---------------------------------------------------
  // With it on, a finished pen stroke that is clearly a shape becomes that
  // exact shape, where you drew it; a note offers the stroke back as drawn.
  const [shapeNote, setShapeNote] = useState<ShapeNote | null>(null);
  const shapeOriginalRef = useRef<{
    id: string;
    points: StrokeElement["points"];
    /** Earlier lines this one was joined to, as they were before. */
    joined: Array<{ id: string; points: StrokeElement["points"]; line: [[number, number], [number, number]] }>;
  } | null>(null);
  const clearShapeNote = useCallback(() => setShapeNote(null), []);
  /**
   * Shapes made recently on this page, in world units, for the next line to
   * join: a line's ends, a polygon's corners.
   */
  const recentShapesRef = useRef<
    Array<{ id: string; place: string; at: number; line?: [[number, number], [number, number]]; corners?: [number, number][] }>
  >([]);
  /** Earlier lines to move once the new line is in (the same Undo step). */
  const pendingJoinRef = useRef<Array<{ id: string; points: StrokeElement["points"] }>>([]);

  const asRecognizedShape = (stroke: StrokeElement): StrokeElement => {
    pendingJoinRef.current = [];
    if (!useWhiteboard.getState().shapeRecognition) return stroke;
    // Too small to be meant as a shape: a letter, a dot. Measured on screen.
    const zoom = Math.max(camera.zoom, 0.01);
    const r = recognizeShape(stroke.points, { minSize: 28 / zoom });
    if (!r) return stroke;
    const place = `${activeBoardId}:${activePage?.id ?? ""}`;
    const now = Date.now();
    const toWorld = (p: [number, number]): [number, number] => [stroke.x + p[0], stroke.y + p[1]];
    const live = new Map(
      getBoardElements(useWhiteboard.getState().boards.find((b) => b.id === activeBoardId) ?? null).map((el) => [el.id, el])
    );
    // Only what is still there, on this page, from the last two minutes.
    recentShapesRef.current = recentShapesRef.current.filter((t) => live.has(t.id) && now - t.at < 120_000).slice(-20);
    let points = r.points;
    let vertices = r.vertices.map(toWorld);
    const joined: Array<{ id: string; points: StrokeElement["points"]; line: [[number, number], [number, number]] }> = [];
    if (r.kind === "line") {
      const len = Math.hypot(vertices[1][0] - vertices[0][0], vertices[1][1] - vertices[0][1]);
      // Within reach: about a fingertip on screen, more for a long line.
      const reach = Math.min(44, Math.max(18, len * zoom * 0.12)) / zoom;
      const targets: JoinTarget[] = recentShapesRef.current.filter((t) => t.place === place);
      const j = joinLine(vertices[0], vertices[1], targets, reach);
      if (j.start !== vertices[0] || j.end !== vertices[1]) {
        const pr = r.points[0]?.[2] ?? 0.5;
        points = lineBetween([j.start[0] - stroke.x, j.start[1] - stroke.y], [j.end[0] - stroke.x, j.end[1] - stroke.y], pr);
        vertices = [j.start, j.end];
      }
      for (const a of j.adjust) {
        const el = live.get(a.id);
        const entry = recentShapesRef.current.find((t) => t.id === a.id);
        if (!el || el.type !== "stroke" || !entry?.line) continue;
        const ends: [[number, number], [number, number]] = [entry.line[0], entry.line[1]];
        ends[a.end] = a.to;
        joined.push({ id: el.id, points: el.points, line: [entry.line[0], entry.line[1]] });
        const pr = el.points[0]?.[2] ?? 0.5;
        pendingJoinRef.current.push({
          id: el.id,
          points: lineBetween([ends[0][0] - el.x, ends[0][1] - el.y], [ends[1][0] - el.x, ends[1][1] - el.y], pr),
        });
        entry.line = ends;
      }
    }
    recentShapesRef.current.push(
      r.kind === "line"
        ? { id: stroke.id, place, at: now, line: [vertices[0], vertices[1]] }
        : { id: stroke.id, place, at: now, corners: vertices }
    );
    shapeOriginalRef.current = { id: stroke.id, points: stroke.points, joined };
    let minX = Infinity;
    let minY = Infinity;
    let maxX = -Infinity;
    for (const [x, y] of r.points) {
      minX = Math.min(minX, x);
      maxX = Math.max(maxX, x);
      minY = Math.min(minY, y);
    }
    const top = worldToScreen(stroke.x + (minX + maxX) / 2, stroke.y + minY, camera, viewport);
    setShapeNote({
      id: stroke.id,
      label: shapeLabel(r.kind),
      x: Math.max(90, Math.min(viewport.width - 90, top.x)),
      y: Math.max(8, top.y - 44),
      key: Date.now(),
    });
    // The exact shape: drawn as it is (no smoothing, no hook trimming) and
    // with blunt ends, so a closed shape has no thin spot where it closes.
    return { ...stroke, points, settled: true, cutStart: true, cutEnd: true };
  };

  /** Moves the ends of earlier lines a new one was joined to. After the new
   *  stroke is added, so its Undo step takes them back too. */
  const applyPendingJoins = () => {
    for (const j of pendingJoinRef.current) updateElement(j.id, { points: j.points } as Partial<StrokeElement>, false);
    pendingJoinRef.current = [];
  };

  const keepShapeAsDrawn = useCallback(() => {
    const orig = shapeOriginalRef.current;
    setShapeNote(null);
    if (!orig) return;
    shapeOriginalRef.current = null;
    updateElement(
      orig.id,
      { points: orig.points, settled: undefined, cutStart: undefined, cutEnd: undefined } as Partial<StrokeElement>,
      false
    );
    // The lines it was joined to go back to how they were, too.
    for (const j of orig.joined) {
      updateElement(j.id, { points: j.points } as Partial<StrokeElement>, false);
      const entry = recentShapesRef.current.find((t) => t.id === j.id);
      if (entry) entry.line = j.line;
    }
    recentShapesRef.current = recentShapesRef.current.filter((t) => t.id !== orig.id);
  }, [updateElement]);

  const handlePointerUp = (e: React.PointerEvent<SVGSVGElement>) => {
    laser.up(e.pointerId);
    clearAutoStraightenTimer();
    isAutoStraightenedRef.current = false;
    // A lifted finger is gone; a lifted pen is still hovering, so it keeps it.
    if (e.pointerType === "touch") {
      placeEraserCursor(0, 0, false);
      placePenHoverCursor(0, 0, false);
    }
    // Apply whatever movement has not been flushed yet, so the camera ends
    // exactly where the finger left it rather than up to one frame behind.
    const wasPanning =
      interaction.kind === "panning" || activeTouchesRef.current.size >= 2;
    // Only when the LAST finger lifts - lifting one of two is not a throw.
    const lastContact = activeTouchesRef.current.size <= 1;
    endPanGesture();
    if (wasPanning && lastContact) startMomentum();

    // End the erase sweep; a later event must not continue from here.
    lastErasePosRef.current = null;
    activeTouchesRef.current.delete(e.pointerId);
    rejectedPalmsRef.current.delete(e.pointerId);
    releaseGestureRefs(e.pointerId);
    if (e.pointerType === "pen") {
      penActiveRef.current = false;
      // The suppression window is measured from here — the lift between words,
      // with the hand still resting, is exactly the gap it exists to cover.
      lastPenAtRef.current = Date.now();
      // Hand the pen back the moment the stylus leaves the glass, whether the
      // button was released first or not — otherwise letting go mid-stroke
      // would strand the user in the eraser.
      releaseStylusErase();
    }

    // Multi-finger tap gestures (2-finger = Undo, 3-finger = Redo) are judged
    // exactly ONCE — when the last finger lifts — and then consumed, so a
    // 2-finger tap can never fire undo twice (once per finger lift).
    // Never while the inline editor is open (mid-edit tap would revert the
    // whole session), and never if this touch sequence already sealed a
    // gesture (pinch takeover commits — undoing it right away feels random).
    if (
      activeTouchesRef.current.size === 0 &&
      touchSettings.twoFingerUndo &&
      maxTouchCountRef.current >= 2 &&
      !editingId &&
      !gestureSealedRef.current
    ) {
      const touchDuration = Date.now() - touchStartTimeRef.current;
      if (touchDuration < 320 && !touchMovedRef.current) {
        if (maxTouchCountRef.current === 2) {
          undo();
        } else if (maxTouchCountRef.current === 3) {
          redo();
        }
      }
      maxTouchCountRef.current = 0;
      touchMovedRef.current = false;
      gestureSealedRef.current = false;
    }

    if (activeTouchesRef.current.size < 2) {
      lastTouchMidRef.current = null;
      pinchStartDistanceRef.current = null;
      pinchEngagedRef.current = false;
    }
    if (activeTouchesRef.current.size === 0) {
      maxTouchCountRef.current = 0;
      pinchStartDistanceRef.current = null;
      pinchEngagedRef.current = false;
      lastTouchMidRef.current = null;
    }

    // Ends a text selection drag; the interaction below is idle for it.
    textSelect.pointerUp(e);

    if (interaction.kind === "erasing") {
      setInteraction({ kind: "idle" });
      return;
    }

    if (interaction.kind === "capturing") {
      // Only the pointer that drew the area ends it; a palm lifting does not.
      if (e.pointerId !== interaction.pointerId) return;
      finishCapture(interaction);
      setInteraction({ kind: "idle" });
      return;
    }

    if (interaction.kind === "lasso-selecting") {
      // The pen has lifted, so the loop closes — joining the last point back
      // to the first, exactly as Samsung does — and only NOW is there a
      // region to judge anything against.
      const loop = interaction.points;
      if (loop.length >= 3) {
        const hitIds: string[] = [];
        for (const el of elements) {
          // Connections live at (0,0) with zero-size bounds — lassoing the
          // origin would otherwise select EVERY connection on the board.
          // Locked elements are never selected by lasso unless in lockedMode.
          if (el.type === "connection" || !pickableNow(el, lockedMode)) continue;
          if (!lockedMode && !passesSelectFilter(el, selectFilter)) continue;
          // `strict` is "include partially selected objects", OFF: only what
          // the loop encloses completely comes along.
          const inside = interaction.strict
            ? isElementFullyInPolygon(el, loop)
            : isElementInPolygon(el, loop);
          if (inside) hitIds.push(el.id);
        }
        setSelected(hitIds);
      } else {
        // A tap or a flick is not a loop.
        setSelected([]);
      }
      setInteraction({ kind: "idle" });
      return;
    }

    // 1. Finish connection
    if (interaction.kind === "connecting") {
      if (interaction.targetElementId && activeBoardId) {
        createConnection(
          {
            boardId: activeBoardId,
            elementId: interaction.sourceElementId,
            anchor: interaction.sourceAnchor,
          },
          {
            boardId: activeBoardId,
            elementId: interaction.targetElementId,
            anchor: interaction.targetAnchor || "auto",
          },
          style.connectionLinkType,
          style.connectionRouting
        );
      }
      setInteraction({ kind: "idle" });
      return;
    }

    // 2. Finish freehand drawing (commits points cleanly from transient ref to Zustand store)
    if (liveDraftStrokeRef.current || interaction.kind === "drawing") {
      // R1-DEF-02: Ignore pointerup from non-drawing pointers (e.g. palm lifting off)
      if (drawingPointerIdRef.current !== null && e.pointerId !== drawingPointerIdRef.current) {
        return;
      }

      // Cancel any pending RAF
      if (draftStrokeRafRef.current !== null) {
        cancelAnimationFrame(draftStrokeRafRef.current);
        draftStrokeRafRef.current = null;
      }

      clearAutoStraightenTimer();
      isAutoStraightenedRef.current = false;
      autoStraightenAnchorRef.current = null;
      drawingPointerIdRef.current = null;
      predictedPointsRef.current = [];

      const live = liveDraftStrokeRef.current;
      if (live && live.points.length >= 1) {
        const cleanPoints =
          touchSettings.penAntiHook !== false
            ? pruneTerminalHooks(live.points)
            : live.points;

        const finalStroke: StrokeElement = {
          id: live.id,
          type: "stroke",
          x: live.originX,
          y: live.originY,
          rotation: 0,
          opacity: 1,
          points: cleanPoints,
          color: live.color,
          strokeWidth: live.strokeWidth,
          strokeStyle: live.strokeStyle,
          smoothing: live.smoothing,
          createdAt: live.createdAt,
          updatedAt: Date.now(),
        };

        // Commit to Zustand store and push undo/redo snapshot. The save
        // this schedules waits until the pen has been quiet a moment.
        deferSavesWhileWriting();
        addElement(asRecognizedShape(finalStroke), true);
        applyPendingJoins();
      } else if (draftElement && draftElement.type === "stroke" && (draftElement as StrokeElement).points.length >= 1) {
        const stroke = draftElement as StrokeElement;
        const cleanPoints =
          touchSettings.penAntiHook !== false
            ? pruneTerminalHooks(stroke.points)
            : stroke.points;
        const finalStroke: StrokeElement = {
          ...stroke,
          points: cleanPoints,
          smoothing: penFeelFor(touchSettings, stroke.strokeStyle).smoothing,
        };
        addElement(asRecognizedShape(finalStroke), true);
        applyPendingJoins();
      }

      // Hide and clear the direct DOM live overlay
      if (liveDraftGroupRef.current) {
        liveDraftGroupRef.current.style.display = "none";
      }
      if (liveDraftPathRef.current) {
        liveDraftPathRef.current.setAttribute("d", "");
      }
      liveDraftStrokeRef.current = null;

      setDraftElement(null);
      setInteraction({ kind: "idle" });
      return;
    }


    // 3. Finish shape creation
    if (interaction.kind === "creating-shape" && draftElement) {
      const b = getElementBounds(draftElement);
      let final: WhiteboardElement | null = null;
      if (b.width > TAP_DRAG_SLOP_PX || b.height > TAP_DRAG_SLOP_PX) {
        final = draftElement;
      } else {
        // A tap, not a drag: plant a default-size shape centred on the press
        // instead of discarding it — or worse, committing the finger's
        // contact wobble as a thin sliver. Centred, snapped like a drag, and
        // never born bigger than the sheet.
        const rect = tapShapeRect(interaction.startX, interaction.startY, {
          snap: snapToGridActive ? (v: number) => snapToGrid(v, paperSize) : undefined,
          page: isNb ? { width: pageDim.width, height: pageDim.height } : null,
        });
        if (draftElement.type === "line" || draftElement.type === "arrow") {
          final = { ...draftElement, x: rect.x, y: rect.y, x2: rect.width, y2: 0 };
        } else if (
          draftElement.type === "rectangle" ||
          draftElement.type === "ellipse" ||
          draftElement.type === "diamond" ||
          draftElement.type === "triangle" ||
          draftElement.type === "star" ||
          draftElement.type === "cloud"
        ) {
          final = { ...draftElement, x: rect.x, y: rect.y, width: rect.width, height: rect.height };
        }
        // Any other type cannot reach this interaction (only the eight shape
        // tools start it) and stays discarded, exactly as before.
      }
      if (final) {
        addElement(final, true);
        setSelected([final.id]);
      }
      setDraftElement(null);
      setInteraction({ kind: "idle" });
      // Back to select: the shape is selected with its handles out, so resize
      // and move work at once — staying in the shape tool meant every press
      // drew a new shape instead of grabbing the one just made.
      setTool("select");
      return;
    }

    // 4. Finish moving / resizing / rotating
    if (interaction.kind === "moving" || interaction.kind === "resizing" || interaction.kind === "rotating") {
      commitHistory();
      setInteraction({ kind: "idle" });
      return;
    }

    if (interaction.kind === "selecting") {
      setRubberBand(null);
      setInteraction({ kind: "idle" });
      return;
    }

    setInteraction({ kind: "idle" });
  };

  // Pointer Cancel: the browser cancelled the gesture (palm takeover, edge
  // swipe, alert dialog). Cancelled gestures ROLL BACK — drafts are discarded
  // and in-flight transforms restored — instead of being committed to history.
  const handlePointerCancel = (e: React.PointerEvent<SVGSVGElement>) => {
    laser.up(e.pointerId);
    // A palm the system cancels must not undo the pen's text drag.
    textSelect.cancel(e.pointerId);
    endPanGesture();
    // End the erase sweep; a later event must not continue from here.
    lastErasePosRef.current = null;
    activeTouchesRef.current.delete(e.pointerId);
    rejectedPalmsRef.current.delete(e.pointerId);
    releaseGestureRefs(e.pointerId);
    if (e.pointerType === "pen") {
      penActiveRef.current = false;
      // The suppression window is measured from here — the lift between words,
      // with the hand still resting, is exactly the gap it exists to cover.
      lastPenAtRef.current = Date.now();
      // Hand the pen back the moment the stylus leaves the glass, whether the
      // button was released first or not — otherwise letting go mid-stroke
      // would strand the user in the eraser.
      releaseStylusErase();
    }

    if (activeTouchesRef.current.size < 2) {
      lastTouchMidRef.current = null;
      pinchStartDistanceRef.current = null;
      pinchEngagedRef.current = false;
    }
    if (activeTouchesRef.current.size === 0) {
      maxTouchCountRef.current = 0;
      touchMovedRef.current = false;
    }

    // A cancelled capture drag is dropped, but the mode stays armed so the
    // area can simply be drawn again. A cancelled palm leaves it alone.
    if (interaction.kind === "capturing") {
      if (e.pointerId !== interaction.pointerId) return;
      setInteraction({ kind: "idle" });
      return;
    }

    // R1-DEF-02: Strict Pointer ID Isolation for Inking Cancellation
    // If Android or the browser cancels a palm contact (pointercancel on touch pointer),
    // the in-flight pen stroke MUST continue unaffected!
    if (interaction.kind === "drawing") {
      if (drawingPointerIdRef.current !== null && e.pointerId !== drawingPointerIdRef.current) {
        // OS cancelled a palm contact — do not cancel active pen inking!
        return;
      }
      drawingPointerIdRef.current = null;
      if (draftStrokeRafRef.current !== null) {
        cancelAnimationFrame(draftStrokeRafRef.current);
        draftStrokeRafRef.current = null;
      }
      clearAutoStraightenTimer();
      isAutoStraightenedRef.current = false;
      autoStraightenAnchorRef.current = null;
      predictedPointsRef.current = [];

      // Keep what was written: a cancelled stream still drew real ink.
      const cancelled = liveDraftStrokeRef.current;
      if (cancelled && cancelled.points.length >= 1) {
        addElement(
          {
            id: cancelled.id,
            type: "stroke",
            x: cancelled.originX,
            y: cancelled.originY,
            rotation: 0,
            opacity: 1,
            points:
              touchSettings.penAntiHook !== false
                ? pruneTerminalHooks(cancelled.points)
                : cancelled.points,
            color: cancelled.color,
            strokeWidth: cancelled.strokeWidth,
            strokeStyle: cancelled.strokeStyle,
            smoothing: cancelled.smoothing,
            createdAt: cancelled.createdAt,
            updatedAt: Date.now(),
          },
          true
        );
      }
      if (liveDraftGroupRef.current) {
        liveDraftGroupRef.current.style.display = "none";
      }
      if (liveDraftPathRef.current) {
        liveDraftPathRef.current.setAttribute("d", "");
      }
      liveDraftStrokeRef.current = null;

      setDraftElement(null);
      setInteraction({ kind: "idle" });
      return;
    }

    if (
      interaction.kind === "moving" ||
      interaction.kind === "resizing" ||
      interaction.kind === "rotating"
    ) {
      const originals =
        interaction.kind === "moving"
          ? interaction.originalElements
          : [interaction.originalElement];
      for (const orig of originals) {
        updateElement(orig.id, orig, false);
      }
    }

    setDraftElement(null);
    setRubberBand(null);
    setInteraction({ kind: "idle" });
  };

  // Safety net for fingers the canvas never heard lift. The touch map is
  // cleared whenever the live document changes or the split opens or closes,
  // and whenever the app is hidden: a press in progress cannot survive any of
  // those, and one stale entry turns every later one-finger touch into half a
  // pinch - scrolling zooms, drawing and typing do nothing - with no way out.
  const splitBoardIdForReset = useWhiteboard((s) => s.splitBoardId);
  const resetGestureState = useCallback(() => {
    activeTouchesRef.current.clear();
    rejectedPalmsRef.current.clear();
    drawingPointerIdRef.current = null;
    penActiveRef.current = false;
    lastTouchMidRef.current = null;
    pinchStartDistanceRef.current = null;
    pinchEngagedRef.current = false;
    maxTouchCountRef.current = 0;
    touchMovedRef.current = false;
    gestureSealedRef.current = false;
    lastErasePosRef.current = null;
    setInteraction((cur) => (cur.kind === "capturing" ? { kind: "idle" } : cur));
    endPanGesture();
  }, [endPanGesture]);
  useEffect(() => {
    resetGestureState();
  }, [activeBoardId, splitBoardIdForReset, resetGestureState]);
  useEffect(() => {
    const onHidden = () => {
      if (document.visibilityState === "hidden") resetGestureState();
    };
    document.addEventListener("visibilitychange", onHidden);
    window.addEventListener("blur", resetGestureState);
    return () => {
      document.removeEventListener("visibilitychange", onHidden);
      window.removeEventListener("blur", resetGestureState);
    };
  }, [resetGestureState]);

  // Safety net: if the browser silently retracts pointer capture mid-gesture
  // (e.g. a captured node unmounts), drop the pointer from the touch map so a
  // stale entry can never poison later gesture math.
  const handleLostPointerCapture = (e: React.PointerEvent<SVGSVGElement>) => {
    laser.up(e.pointerId);
    // A capture drag whose pointer is gone without an "up" must not leave
    // Select dead (every later press would wait for that pointer).
    setInteraction((cur) =>
      cur.kind === "capturing" && cur.pointerId === e.pointerId ? { kind: "idle" } : cur
    );
    endPanGesture();
    activeTouchesRef.current.delete(e.pointerId);
    rejectedPalmsRef.current.delete(e.pointerId);
    if (drawingPointerIdRef.current === e.pointerId) {
      drawingPointerIdRef.current = null;
    }
    releaseGestureRefs(e.pointerId);
    if (e.pointerType === "pen") {
      penActiveRef.current = false;
      lastPenAtRef.current = Date.now();
    }
  };

  // Double click canvas to create text anywhere
  const handleDoubleClick = (e: React.MouseEvent<SVGSVGElement>) => {
    if (tool !== "select" && tool !== "text") return;
    // Screenshot mode: two quick short drags are not "make a text box".
    if (captureArmed) return;
    const wp = getWorldPoint(e.clientX, e.clientY);
    const hit = findElementAt(wp.x, wp.y, false);
    // Double-clicking the desk beside a notebook page must not drop a text box
    // out there; it lands on the paper instead.
    const ip = getInkPoint(e.clientX, e.clientY);

    if (hit) {
      if (lockedMode) return; // locked things are picked here, never edited
      if (hit.type === "text" || hit.type === "sticky") {
        setEditingId(hit.id);
      } else if (hit.type === "image") {
        setImageStudioId(hit.id);
      }
    } else if (!lockedMode) {
      const textId = nanoid(8);
      const posX = snapToGridActive ? snapToGrid(ip.x, paperSize) : ip.x;
      const posY = snapToGridActive ? snapToGrid(ip.y, paperSize) : ip.y;
      const newText: TextElement = {
        id: textId,
        type: "text",
        x: posX,
        y: posY,
        width: 220,
        height: 48,
        rotation: 0,
        opacity: 1,
        text: "",
        color: style.textColor,
        fontSize: style.fontSize,
        fontFamily: style.fontFamily,
        fontWeight: style.fontWeight,
        align: style.textAlign,
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };
      addElement(newText, true);
      setEditingId(textId);
    }
  };

  const cursorStyle = useMemo(() => {
    if (interaction.kind === "panning") return "grabbing";
    if (spaceHeld || tool === "pan") return "grab";
    if (captureArmed) return "crosshair";
    switch (tool) {
      case "laser": return "none";
      case "textselect": return "text";
      case "select": return "default";
      case "lasso": return "crosshair";
      case "pen":
      case "highlighter":
      case "marker":
      case "brush":
      case "calligraphy":
      case "pencil": return "crosshair";
      case "eraser": return "cell";
      case "connect": return "crosshair";
      case "text": return "text";
      default: return "crosshair";
    }
  }, [interaction.kind, spaceHeld, tool, captureArmed]);

  const connectionDraft = useMemo(() => {
    if (interaction.kind !== "connecting" || !activeBoard) return null;
    // Endpoints live on the active page in a notebook; reading the canvas
    // field meant the draft connection silently never rendered.
    const sourceEl = getBoardElements(activeBoard).find((el) => el.id === interaction.sourceElementId);
    if (!sourceEl) return null;

    const sourceAnchor = getResolvedAnchorPoint(
      sourceEl,
      interaction.sourceAnchor,
      { x: interaction.currentWorldX, y: interaction.currentWorldY }
    );

    let targetAnchor = {
      x: interaction.currentWorldX,
      y: interaction.currentWorldY,
      nx: 0,
      ny: 0,
      anchor: "auto" as NodeAnchor,
    };

    if (interaction.targetElementId) {
      const targetEl = getBoardElements(activeBoard).find((el) => el.id === interaction.targetElementId);
      if (targetEl) {
        targetAnchor = getResolvedAnchorPoint(
          targetEl,
          interaction.targetAnchor || "auto",
          sourceAnchor
        );
      }
    }

    const pathD = getConnectionPath(sourceAnchor, targetAnchor, style.connectionRouting);
    const color = getToolColor(style, "connect");

    return { pathD, color, targetAnchor };
  }, [interaction, activeBoard, style]);

  return (
    <div
      ref={containerRef}
      className="w-full h-full relative overflow-hidden bg-background select-none touch-none"
      style={{ cursor: cursorStyle, touchAction: "none" }}
    >
      <CanvasContextMenu elementId={null} disabled={!contextMenuArmed}>
      <svg
        ref={svgRef}
        className="w-full h-full absolute inset-0 touch-none"
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerCancel={handlePointerCancel}
        onPointerLeave={handlePointerLeave}
        // Reflects the live tool so the active tool is observable from the DOM.
        // Nothing in the app reads it; it exists because the tool lives in a
        // zustand store with no other outside signal, which made the
        // borrow-the-eraser behaviour impossible to check from a test.
        data-wb-tool={tool}
        onLostPointerCapture={handleLostPointerCapture}
        onDoubleClick={handleDoubleClick}
        style={{ touchAction: "none" }}
      >
        <StrokeFilterDefs />

        {/* Board paper: colour + pattern, per board.
            The pattern is offset by the camera so it scrolls WITH the canvas
            rather than staying pinned to the screen. */}
        <defs>
          <pattern
            ref={boardPaperRef}
            id="board-paper"
            x={viewport.width / 2 - camera.x * camera.zoom}
            y={viewport.height / 2 - camera.y * camera.zoom}
            width={paperSize * camera.zoom}
            height={paperSize * camera.zoom}
            patternUnits="userSpaceOnUse"
          >
            {paperPattern === "dots" && (
              <circle
                cx={(paperSize * camera.zoom) / 2}
                cy={(paperSize * camera.zoom) / 2}
                r={Math.max(1, (paperSize / 20) * camera.zoom)}
                className="fill-zinc-300 dark:fill-zinc-700"
              />
            )}
            {paperPattern === "grid" && (
              <path
                d={`M ${paperSize * camera.zoom} 0 L 0 0 0 ${paperSize * camera.zoom}`}
                fill="none"
                strokeWidth={Math.max(0.5, camera.zoom * 0.8)}
                className="stroke-zinc-300 dark:stroke-zinc-700"
              />
            )}
            {paperPattern === "lines" && (
              <path
                d={`M 0 ${paperSize * camera.zoom} L ${paperSize * camera.zoom} ${paperSize * camera.zoom}`}
                fill="none"
                strokeWidth={Math.max(0.5, camera.zoom * 0.8)}
                className="stroke-zinc-300 dark:stroke-zinc-700"
              />
            )}
          </pattern>

          {/* The same paper, but in WORLD units, for a notebook page. It is
              painted inside the zoomed group, so unlike #board-paper above it
              must not pre-multiply by the zoom — the group already does. */}
          {isNb && (
            <pattern
              id="page-paper"
              x={0}
              y={0}
              width={paperSize}
              height={paperSize}
              patternUnits="userSpaceOnUse"
            >
              <PaperTiles pattern={paperPattern} size={paperSize} />
            </pattern>
          )}

        </defs>

        {/* Solid colour first, pattern painted on top of it. Two rects rather
            than one keeps the pattern tiles transparent, so the board colour
            shows through instead of being hidden behind opaque tiles. */}
        {!isNb && paperColor && <rect width="100%" height="100%" fill={paperColor} />}
        {!isNb && paperPattern !== "plain" && (
          <rect width="100%" height="100%" fill="url(#board-paper)" />
        )}

        {/* The desk a notebook lies on.
            A whiteboard's background IS the drawing surface, so it carries the
            paper colour and pattern. A notebook's is not: the paper is the
            sheet, and everything around it is furniture. Painting it in the
            board colour made the page edge vanish and the space beside the
            page look like more canvas — which is precisely why it was not
            obvious that writing out there was a mistake. */}
        {isNb && (
          <rect
            width="100%"
            height="100%"
            fill={resolvedTheme === "dark" ? "#0b0b0e" : "#e4e4e9"}
          />
        )}

        {/* World Space Transform Group */}
        <g
          ref={worldRef}
          transform={`translate(${viewport.width / 2}, ${viewport.height / 2}) scale(${camera.zoom}) translate(${-camera.x}, ${-camera.y})`}
        >
          {/* Neighbouring pages, drawn so the notebook scrolls continuously.
              They are display-only: editing happens on the anchored page,
              which the scroll handler keeps in step with what you are
              looking at. */}
          {isNb &&
            neighbourPages.map((n) => {
              // Each sheet wears its OWN paper (the page's, falling back to the
              // notebook's). Painting every sheet with the ACTIVE page's paper is
              // the bug where a grid page showed grid from the page above and
              // turned blank the moment you navigated to it. Each sheet gets its
              // own pattern def because rulings and spacings can differ per page.
              const np = allPages[n.index];
              const npPaper = paperForPage(activeBoard, np ?? null);
              const npColor = paperColorFor(
                np?.background ?? activeBoard?.background,
                resolvedTheme
              );
              const npPatternId = `page-paper-${np?.id ?? n.index}`;
              const npSheetFill =
                npColor || (resolvedTheme === "dark" ? "#18181b" : "#ffffff");
              return (
              <g key={n.id} transform={`translate(0, ${n.offsetY})`} pointerEvents="none">
                <defs>
                  <pattern
                    id={npPatternId}
                    x={0}
                    y={0}
                    width={npPaper.size}
                    height={npPaper.size}
                    patternUnits="userSpaceOnUse"
                  >
                    <PaperTiles pattern={npPaper.pattern} size={npPaper.size} />
                  </pattern>
                </defs>
                {/* Flat offset shadow. This was an SVG feDropShadow, which
                    forces the whole sheet through an off-screen blur on EVERY
                    frame of a scroll — with several sheets on screen that was
                    the single biggest cost of panning a PDF notebook. Two
                    opaque rectangles look near-identical and cost nothing. */}
                <rect
                  x={3}
                  y={4}
                  width={pageDim.width}
                  height={pageDim.height}
                  fill={resolvedTheme === "dark" ? "#000000" : "#a1a1aa"}
                  opacity={resolvedTheme === "dark" ? 0.55 : 0.28}
                  rx={2}
                />
                <rect
                  x={0}
                  y={0}
                  width={pageDim.width}
                  height={pageDim.height}
                  fill={npSheetFill}
                  stroke={resolvedTheme === "dark" ? "#3f3f46" : "#d4d4d8"}
                  strokeWidth={1 / camera.zoom}
                  rx={2}
                />
                {np?.pdf && (
                  <PdfPageLayer
                    pdf={np.pdf}
                    width={pageDim.width}
                    height={pageDim.height}
                  />
                )}
                {/* The sheet's own ruling, over the scan when there is one. */}
                {npPaper.pattern !== "plain" && (
                  <rect
                    x={0}
                    y={0}
                    width={pageDim.width}
                    height={pageDim.height}
                    fill={`url(#${npPatternId})`}
                  />
                )}
                {(np?.elements ?? []).map((el) => (
                  <ElementRenderer key={el.id} element={el} isSelected={false} />
                ))}
              </g>
              );
            })}

          {/* The notebook sheet. Drawn in world space so it pans and zooms
              with the content, and painted before the elements so ink sits on
              top of the paper. */}
          {isNb && (
            <g>
              <rect
                x={3}
                y={4}
                width={pageDim.width}
                height={pageDim.height}
                fill={resolvedTheme === "dark" ? "#000000" : "#a1a1aa"}
                opacity={resolvedTheme === "dark" ? 0.55 : 0.28}
                rx={2}
              />
              <rect
                x={0}
                y={0}
                width={pageDim.width}
                height={pageDim.height}
                fill={paperColor || (resolvedTheme === "dark" ? "#18181b" : "#ffffff")}
                stroke={resolvedTheme === "dark" ? "#52525b" : "#a1a1aa"}
                strokeWidth={1.5 / camera.zoom}
                rx={2}
              />
              {/* The PDF page itself, under your ink and never a pointer
                  target — it is the sheet, not an object you can select or
                  drag. A ruling the page asks for is painted OVER the scan
                  below, so Paper works on PDF pages too (by default PDF
                  notebooks are plain, so scans stay clean). */}
              {activePage?.pdf && (
                <PdfPageLayer
                  pdf={activePage.pdf}
                  width={pageDim.width}
                  height={pageDim.height}
                />
              )}
              {/* A pattern fill is re-tiled on every frame of a scroll. */}
              {paperPattern !== "plain" && (
                <rect
                  x={0}
                  y={0}
                  width={pageDim.width}
                  height={pageDim.height}
                  fill="url(#page-paper)"
                />
              )}
            </g>
          )}

          {/* Committed Elements */}
          {elements.map((el) => (
            <ElementRenderer
              key={el.id}
              element={el}
              isSelected={selectedSet.has(el.id)}
            />
          ))}

          {/* Selected text and find matches, over the ink so they show. */}
          {textSelect.worldLayer}

          {/* ========================================================================= */}
          {/* Live Inking Draft Overlay (Direct DOM - Zero React Render during inking)   */}
          {/* ========================================================================= */}
          <g
            ref={liveDraftGroupRef}
            pointerEvents="none"
            style={{ display: "none" }}
          >
            <path
              ref={liveDraftPathRef}
              stroke="none"
            />
          </g>

          {/* "+" in the gap between sheets. Drawn in world space but scaled
              by 1/zoom so it is the same size on screen at every zoom. It
              stops the press from reaching the canvas, so tapping it never
              pans or draws. */}
          {isNb && gapPlus !== null && (
            <g
              transform={`translate(${pageDim.width / 2}, ${
                (gapPlus - activeIndex) * pageStride - PAGE_GAP / 2
              }) scale(${1 / camera.zoom})`}
              style={{ cursor: "pointer" }}
              data-gap-plus={gapPlus}
              role="button"
              aria-label={
                gapPlus === 0
                  ? "Add a page above the first page"
                  : gapPlus === allPages.length
                    ? "Add a page after the last page"
                    : `Add a page between pages ${gapPlus} and ${gapPlus + 1}`
              }
              onPointerDown={(e) => e.stopPropagation()}
              onPointerUp={(e) => {
                e.stopPropagation();
                const k = gapPlus;
                showGapPlus(null);
                insertPageAt(k);
              }}
            >
              <line x1={-150} y1={0} x2={-30} y2={0} stroke="#6366f1" strokeWidth={2} strokeDasharray="5 5" />
              <line x1={30} y1={0} x2={150} y2={0} stroke="#6366f1" strokeWidth={2} strokeDasharray="5 5" />
              <circle r={19} fill="#6366f1" stroke="#ffffff" strokeWidth={2} />
              <path d="M -8 0 H 8 M 0 -8 V 8" stroke="#ffffff" strokeWidth={3} strokeLinecap="round" />
              {/* Touch target only a little beyond the visible button, so it
                  cannot reach far into the pages either side. */}
              <circle r={22} fill="transparent" />
            </g>
          )}

          {/* Draft Element (Shape Creation: rectangle, ellipse, line, arrow) */}
          {draftElement && draftElement.type !== "stroke" && (
            <ElementRenderer element={draftElement} isSelected={false} isDraft />
          )}

          {/* Draft Connection Arrow */}
          {connectionDraft && (
            <g style={{ pointerEvents: "none" }}>
              <path
                d={connectionDraft.pathD}
                fill="none"
                stroke={connectionDraft.color}
                strokeWidth={2.5}
                strokeDasharray="6,4"
              />
              <circle
                cx={connectionDraft.targetAnchor.x}
                cy={connectionDraft.targetAnchor.y}
                r={6}
                fill={connectionDraft.color}
              />
            </g>
          )}

          {/* Anchor Ports Highlights */}
          {(tool === "connect" || interaction.kind === "connecting") &&
            elements.map((el) => {
              if (el.type === "connection") return null;
              const ports = getNodeAnchorPorts(el);
              const isSource = interaction.kind === "connecting" && interaction.sourceElementId === el.id;
              const isTarget = interaction.kind === "connecting" && interaction.targetElementId === el.id;

              return (
                <g key={`anchors-${el.id}`} style={{ pointerEvents: "none" }}>
                  {Object.entries(ports).map(([anchorKey, pt]) => (
                    <circle
                      key={anchorKey}
                      cx={pt.x}
                      cy={pt.y}
                      r={isSource || isTarget ? 6 : 4.5}
                      fill="white"
                      stroke="#6366f1"
                      strokeWidth={2}
                      className="shadow-md transition-transform"
                      style={{
                        filter: "drop-shadow(0 1px 3px rgba(0,0,0,0.2))",
                      }}
                    />
                  ))}
                </g>
              );
            })}

          {/* Lasso preview: the trail the pen has actually drawn.
              This was a <polygon>, which SVG closes for you — so mid-stroke it
              painted a filled wedge from wherever you started to wherever the
              nib is now, and the enclosed area appeared to fan out from the
              starting point rather than follow the pen. A <polyline> with no
              fill is literally the line you drew, which is all Samsung Notes
              shows until you lift. */}
          {interaction.kind === "lasso-selecting" && interaction.points.length >= 2 && (
            <polyline
              points={interaction.points.map((p) => `${p.x},${p.y}`).join(" ")}
              fill="none"
              stroke="#6366f1"
              strokeWidth={1.5 / camera.zoom}
              strokeDasharray={`${5 / camera.zoom},${4 / camera.zoom}`}
              strokeLinecap="round"
              strokeLinejoin="round"
              style={{ pointerEvents: "none" }}
            />
          )}

          {/* Locked-items mode: every locked thing wears a dashed amber frame
              and a padlock, so what can be picked (and unlocked) is visible. */}
          {lockedMode &&
            elements.map((el) => {
              if (!el.locked || el.type === "connection") return null;
              const b = getElementBounds(el);
              const z = camera.zoom;
              const picked = selectedIds.includes(el.id);
              const r = 11 / z;
              const bx = b.x + b.width;
              const by = b.y;
              return (
                <g key={`lk-${el.id}`} style={{ pointerEvents: "none" }}>
                  <rect
                    x={b.x}
                    y={b.y}
                    width={b.width}
                    height={b.height}
                    fill={picked ? "rgba(245, 158, 11, 0.10)" : "rgba(245, 158, 11, 0.04)"}
                    stroke="#f59e0b"
                    strokeWidth={(picked ? 2.5 : 1.5) / z}
                    strokeDasharray={picked ? undefined : `${6 / z},${4 / z}`}
                    rx={4 / z}
                  />
                  <circle cx={bx} cy={by} r={r} fill="#f59e0b" stroke="#fff" strokeWidth={1.5 / z} />
                  <rect x={bx - 4.5 / z} y={by - 1 / z} width={9 / z} height={6.5 / z} rx={1.2 / z} fill="#fff" />
                  <path
                    d={`M ${bx - 2.8 / z} ${by - 1 / z} v ${-2 / z} a ${2.8 / z} ${2.8 / z} 0 0 1 ${5.6 / z} 0 v ${2 / z}`}
                    fill="none"
                    stroke="#fff"
                    strokeWidth={1.4 / z}
                  />
                </g>
              );
            })}

          {/* Selection Handles & Bounding Box */}
          <SelectionOverlay
            selectedIds={selectedIds}
            elements={elements}
            camera={camera}
            viewport={viewport}
          />
        </g>

        {/* Rubber-band Selection Box (Screen Space) */}
        {rubberBand && (
          <rect
            x={rubberBand.x}
            y={rubberBand.y}
            width={rubberBand.w}
            height={rubberBand.h}
            fill="rgba(99, 102, 241, 0.12)"
            stroke="#6366f1"
            strokeWidth={1}
            strokeDasharray="4,3"
            style={{ pointerEvents: "none" }}
          />
        )}

        {/* Screenshot mode: the viewfinder shows the area while it is drawn. */}
        {interaction.kind === "capturing" && (
          <CaptureMarquee
            shape={interaction.shape}
            points={interaction.points}
            camera={camera}
            viewport={viewport}
          />
        )}

        {/* Eraser cursor. Positioned imperatively by placeEraserCursor - no
            transform prop here, or every render would snap it back. Two
            strokes so it reads on white paper AND on top of dark ink. */}
        <g ref={eraserCursorRef} visibility="hidden" pointerEvents="none">
          <circle r={eraserScreenR} fill="rgba(113, 113, 122, 0.10)" stroke="#ffffff" strokeWidth={3} />
          <circle r={eraserScreenR} fill="none" stroke="#52525b" strokeWidth={1.25} />
        </g>

        {/* S Pen & Stylus Hover Preview Cursor */}
        <g ref={penHoverCursorRef} visibility="hidden" pointerEvents="none">
          <circle
            r={Math.max(2, hoverInkRadius)}
            fill={getToolColor(style, tool)}
            opacity={0.35}
            stroke="#ffffff"
            strokeWidth={1.5}
          />
          <circle
            r={Math.max(1.5, hoverInkRadius)}
            fill="none"
            stroke={getToolColor(style, tool)}
            strokeWidth={1}
          />
        </g>
      </svg>
      </CanvasContextMenu>
      <LaserLayer />
      {shapeNote && <ShapeNoteChip note={shapeNote} onKeepDrawn={keepShapeAsDrawn} onDone={clearShapeNote} />}
      {textSelect.overlay}
    </div>
  );
}
