"use client";

/**
 * Modern Modular Toolbar & Tool Dock (v4 — Native Touchscreen & Obsidian Canvas Grade)
 * ======================================================================================
 * Features:
 * - Grouped modular dock with popover flyouts for Pens, Shapes, Connectors, and Touchscreen Mode
 * - First-Class Touchscreen Mode Switcher (Touch Draw, Stylus + Palm Rejection, Touch Navigation)
 * - Live tool indicators & persistent per-tool color/size configuration
 * - Quick access to Canvas Zoom, Undo/Redo, Search, Graph View, and Theme Toggle
 */

import React, { useEffect, useRef, useState } from "react";
import {
  Hand,
  Pen,
  Highlighter,
  Paintbrush,
  Brush,
  Feather,
  Pencil,
  Eraser,
  Square,
  Circle,
  Diamond,
  Triangle,
  Star,
  Cloud,
  Minus,
  ArrowRight,
  Type,
  StickyNote,
  Link2,
  ZoomIn,
  ZoomOut,
  Maximize,
  Network,
  Search,
  ChevronDown,
  ChevronUp,
  ChevronLeft,
  ChevronRight,
  Tablet,
  Check,
  Sparkles,
  Download,
  Grid,
  Map,
  HelpCircle,
  Keyboard,
  SlidersHorizontal,
} from "lucide-react";
import { ThemeToggle } from "./ThemeToggle";
import { PANEL_W, NotebookPageControls } from "./NotebookPages";
import { ToolPropertiesBar, ToolPropertiesPanel, toolHasProperties } from "./ToolProperties";
import { ImageInsertButton } from "./ImageInsertSheet";
import { DockGrip, dockSizeClasses, dockStackClasses, flyoutSide } from "./DockControls";
import { isVerticalDock, TOOLBAR_ITEMS, type ToolbarItemId } from "@/lib/whiteboard/types";
import { LaserIcon } from "./LaserPointer";
import { ShapeAssistIcon } from "./ShapeAssist";
import { ToolbarCustomizer } from "./ToolbarSettings";
import { TextSelectIcon } from "./PdfTextSelect";
import { useWhiteboard } from "@/store/whiteboard";
import {
  PEN_COLORS,
  STROKE_WIDTHS,
  STICKY_COLORS,
  BUILTIN_LINK_TYPES,
  LINK_TYPE_COLORS,
  LINK_TYPE_LABELS,
  PEN_TYPE_PRESETS,
  PEN_TYPES,
  isStrokeTool,
  getToolColor,
  getToolSize,
  setToolColor,
  setToolSize,
  type StrokeStyle,
  type ToolType,
  type ConnectionRouting,
  type BuiltinLinkType,
  type StickyColor,
  type TouchInputMode,
} from "@/lib/whiteboard/types";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { SelectToolButton } from "./SelectToolButton";
import { useLongPress } from "@/hooks/use-long-press";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Separator } from "@/components/ui/separator";
import { StepperRow } from "./StepperControl";
import { cn } from "@/lib/utils";

interface ToolbarProps {
  onOpenGraph: () => void;
  onOpenSearch: () => void;
}


/**
 * Zoom in/out, percentage and fit. A standalone pill so it can live inside
 * the dock row — or, when the dock itself is on top, detached at the bottom
 * of the page where it never hangs over the canvas under the tools.
 * Hidden entirely via Settings > Canvas when you zoom by gesture alone.
 */
/**
 * Zoom readout, bottom-left of the canvas.
 *
 * It used to ride inside the tool dock, which cost the tool row ~150px of
 * width it could not spare — on a narrow pane the row wrapped and the page
 * controls were pushed onto a line of their own — and it needed a special case
 * that detached it to the bottom of the screen whenever the dock sat on top.
 * Pinned to its own corner it is the same control in every dock position, and
 * the tool row gets its width back.
 *
 * It shows itself while the zoom is CHANGING and fades out about a second
 * later: the percentage matters while you are pinching and never again, so it
 * has no business occupying a corner permanently. It stays up while the
 * pointer is on it, so the buttons are still usable once it has appeared, and
 * while hidden it is `pointer-events-none` — an invisible pill that swallowed
 * clicks in the corner of the canvas would be worse than the space it saved.
 */
export function ZoomDock() {
  const zoom = useWhiteboard((s) => s.camera.zoom);
  const zoomTo = useWhiteboard((s) => s.zoomTo);
  const zoomToFit = useWhiteboard((s) => s.zoomToFit);
  const zoomDockOpen = useWhiteboard((s) => s.zoomDockOpen);
  const pagePanelOpen = useWhiteboard((s) => s.pagePanelOpen);

  const [changing, setChanging] = useState(false);
  const [hovered, setHovered] = useState(false);
  const firstRender = useRef(true);

  useEffect(() => {
    // Mounting is not a zoom change; without this it flashes on every load.
    if (firstRender.current) {
      firstRender.current = false;
      return;
    }
    setChanging(true);
    const t = setTimeout(() => setChanging(false), 1400);
    return () => clearTimeout(t); // each change restarts the countdown
  }, [zoom]);

  if (!zoomDockOpen) return null;
  const show = changing || hovered;

  return (
    <div
      onPointerEnter={() => setHovered(true)}
      onPointerLeave={() => setHovered(false)}
      // Opacity is an inline style, not `opacity-0`/`opacity-100`: this build
      // does not generate an `.opacity-100` rule, so the class flipped without
      // the pill ever becoming visible. Inline wins outright and needs nothing
      // generated.
      // Beside the page panel when it is open, not under it.
      style={{ opacity: show ? 1 : 0, left: pagePanelOpen ? PANEL_W + 12 : undefined }}
      className={cn(
        // Under the tool dock (z-30): where a narrow pane makes them meet, a
        // tap aimed at a tool must reach the tool, not "Zoom out".
        "absolute bottom-3 left-3 z-20 flex select-none items-center gap-0.5 rounded-lg border border-border bg-white/95 p-0.5 shadow-lg backdrop-blur-md transition-opacity duration-200 dark:bg-zinc-900/95",
        !show && "pointer-events-none"
      )}
    >
      <button
        onClick={() => zoomTo(zoom * 0.85)}
        className="rounded-md p-1 text-muted-foreground hover:bg-muted hover:text-foreground"
        title="Zoom out"
        aria-label="Zoom out"
      >
        <ZoomOut size={13} />
      </button>

      <button
        onClick={() => zoomTo(1)}
        className="rounded-md px-1 py-0.5 text-[10px] font-semibold tabular-nums hover:bg-muted"
        title="Reset zoom to 100%"
        aria-label="Reset zoom to 100%"
      >
        {Math.round(zoom * 100)}%
      </button>

      <button
        onClick={() => zoomTo(zoom * 1.15)}
        className="rounded-md p-1 text-muted-foreground hover:bg-muted hover:text-foreground"
        title="Zoom in"
        aria-label="Zoom in"
      >
        <ZoomIn size={13} />
      </button>

      <button
        onClick={() => zoomToFit()}
        className="rounded-md p-1 text-muted-foreground hover:bg-muted hover:text-foreground"
        title="Fit view to content (Shift+1)"
        aria-label="Fit view to content"
      >
        <Maximize size={13} />
      </button>
    </div>
  );
}

/**
 * Lets the tool bar scroll along its length by swipe or drag - finger, S Pen
 * or mouse alike - with a little glide after a flick. Handled here rather than
 * by native scrolling because the pen and the mouse do not scroll a box by
 * dragging it, and mixing native and hand-rolled scrolling fights itself.
 *
 * A press that moves more than a few pixels is a scroll: the button it began
 * on does not also get clicked. The edges fade where tools are hidden.
 */
function useDragScroll(vertical: boolean, contentKey: string) {
  const ref = useRef<HTMLDivElement>(null);
  const [edges, setEdges] = useState({ start: false, end: false });

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const pos = () => (vertical ? el.scrollTop : el.scrollLeft);
    const setPos = (v: number) => {
      if (vertical) el.scrollTop = v;
      else el.scrollLeft = v;
    };
    const update = () => {
      const max = vertical ? el.scrollHeight - el.clientHeight : el.scrollWidth - el.clientWidth;
      const next = { start: pos() > 1, end: pos() < max - 1 };
      setEdges((e) => (e.start === next.start && e.end === next.end ? e : next));
    };
    update();
    el.addEventListener("scroll", update, { passive: true });
    const ro = new ResizeObserver(update);
    ro.observe(el);
    for (const child of Array.from(el.children)) ro.observe(child);

    let drag: { id: number; start: number; from: number; moved: boolean; lastAt: number; last: number; v: number; slop: number } | null = null;
    let blocker: ((ev: Event) => void) | null = null;
    let glide = 0;
    const coord = (e: PointerEvent) => (vertical ? e.clientY : e.clientX);

    const down = (e: PointerEvent) => {
      if (e.pointerType === "mouse" && e.button !== 0) return;
      cancelAnimationFrame(glide);
      // A click blocker left over from the last swipe must not eat this tap
      // (Chrome sends no click at the end of a touch or pen drag at all).
      if (blocker) {
        el.removeEventListener("click", blocker, { capture: true });
        blocker = null;
      }
      // Nothing to scroll: every press is simply a press, however it wobbles.
      const scrollable = vertical ? el.scrollHeight > el.clientHeight + 1 : el.scrollWidth > el.clientWidth + 1;
      if (!scrollable) return;
      const c = coord(e);
      drag = {
        id: e.pointerId,
        start: c,
        from: pos(),
        moved: false,
        lastAt: e.timeStamp,
        last: c,
        v: 0,
        slop: e.pointerType === "touch" ? 12 : 8,
      };
    };
    const move = (e: PointerEvent) => {
      if (!drag || e.pointerId !== drag.id) return;
      const c = coord(e);
      const d = c - drag.start;
      if (!drag.moved) {
        if (Math.abs(d) < drag.slop) return;
        drag.moved = true;
        // From here the bar owns the pointer: the button under the finger
        // loses it (and with it any pending long press or click).
        try {
          el.setPointerCapture(e.pointerId);
        } catch {
          /* pointer already gone */
        }
      }
      const dt = Math.max(1, e.timeStamp - drag.lastAt);
      drag.v = 0.8 * ((c - drag.last) / dt) + 0.2 * drag.v;
      drag.last = c;
      drag.lastAt = e.timeStamp;
      setPos(drag.from - d);
    };
    const up = (e: PointerEvent) => {
      if (!drag || e.pointerId !== drag.id) return;
      const { moved, lastAt } = drag;
      // Held still before letting go: no glide.
      const v = e.type === "pointercancel" || e.timeStamp - lastAt > 80 ? 0 : drag.v;
      drag = null;
      if (!moved) return;
      // The press was a scroll: swallow the click it may end with (a mouse
      // does send one). Removed by the next press, whatever happens.
      const block = (ev: Event) => {
        ev.stopPropagation();
        ev.preventDefault();
        el.removeEventListener("click", block, { capture: true });
        if (blocker === block) blocker = null;
      };
      blocker = block;
      el.addEventListener("click", block, { capture: true });
      // Glide on after a flick, slowing to a stop.
      let vel = v * 16; // px per frame
      const step = () => {
        if (Math.abs(vel) < 0.5) return;
        setPos(pos() - vel);
        vel *= 0.92;
        glide = requestAnimationFrame(step);
      };
      glide = requestAnimationFrame(step);
    };

    el.addEventListener("pointerdown", down);
    el.addEventListener("pointermove", move);
    el.addEventListener("pointerup", up);
    el.addEventListener("pointercancel", up);
    return () => {
      cancelAnimationFrame(glide);
      if (blocker) el.removeEventListener("click", blocker, { capture: true });
      el.removeEventListener("scroll", update);
      ro.disconnect();
      el.removeEventListener("pointerdown", down);
      el.removeEventListener("pointermove", move);
      el.removeEventListener("pointerup", up);
      el.removeEventListener("pointercancel", up);
    };
  }, [vertical, contentKey]);

  // Fade the edge where more tools are waiting.
  const fade = 28;
  const dir = vertical ? "to bottom" : "to right";
  const mask =
    edges.start || edges.end
      ? `linear-gradient(${dir}, ${edges.start ? "transparent" : "black"} 0, black ${edges.start ? fade : 0}px, black calc(100% - ${edges.end ? fade : 0}px), ${edges.end ? "transparent" : "black"} 100%)`
      : undefined;
  const style: React.CSSProperties = {
    // The bar handles its own dragging; the browser must not also pan.
    touchAction: "none",
    maskImage: mask,
    WebkitMaskImage: mask,
  };
  return { ref, style };
}

export function Toolbar({ onOpenGraph, onOpenSearch }: Partial<ToolbarProps>) {
  const tool = useWhiteboard((s) => s.tool);
  const setTool = useWhiteboard((s) => s.setTool);
  const style = useWhiteboard((s) => s.style);
  const setStyle = useWhiteboard((s) => s.setStyle);
  const toolbarPosition = useWhiteboard((s) => s.toolbarPosition);
  const toolPropsCollapsed = useWhiteboard((s) => s.toolPropsBarCollapsed);
  const toggleToolPropsBar = useWhiteboard((s) => s.toggleToolPropsBar);
  const pagePanelOpen = useWhiteboard((s) => s.pagePanelOpen);
  const lastStrokeTool = useWhiteboard((s) => s.lastStrokeTool);
  const [toolPanelOpen, setToolPanelOpen] = useState(false);
  const penLongPress = useLongPress(() => {
    if (!isStrokeTool(tool)) setTool(lastStrokeTool);
    setToolPanelOpen(true);
  });
  const laserLongPress = useLongPress(() => {
    setTool("laser");
    setToolPanelOpen(true);
  });
  const toolbarItems = useWhiteboard((s) => s.toolbarItems);
  const shapeRecognition = useWhiteboard((s) => s.shapeRecognition);
  const toggleShapeRecognition = useWhiteboard((s) => s.toggleShapeRecognition);
  const scroller = useDragScroll(isVerticalDock(toolbarPosition), toolbarItems.join());


  const isPenTool = isStrokeTool(tool);
  const isShapeTool = ["rectangle", "ellipse", "diamond", "triangle", "star", "cloud", "line", "arrow"].includes(tool);

  // Pen type icon lookup
  // The pen flyout edits whichever stroke tool is active. Reading/writing
  // penColor/penSize unconditionally meant picking a colour while the
  // highlighter (or marker/brush/calligraphy/pencil) was selected changed the
  // PEN and left the active tool untouched — the canvas reads each tool's own
  // field via getToolColor/getToolSize.
  // The pen the button represents: the one in hand, or the one you last used.
  const penFlyoutTool: ToolType = isPenTool ? tool : lastStrokeTool;
  const activeInkColor = getToolColor(style, penFlyoutTool);
  const activeInkSize = getToolSize(style, penFlyoutTool);
  const setInkColor = (c: string) => setStyle(setToolColor(style, penFlyoutTool, c));
  const setInkSize = (sz: number) => setStyle(setToolSize(style, penFlyoutTool, sz));

  const getPenIcon = (st: StrokeStyle) => {
    switch (st) {
      case "highlighter": return Highlighter;
      case "marker": return Paintbrush;
      case "brush": return Brush;
      case "calligraphy": return Feather;
      case "pencil": return Pencil;
      case "pen":
      default: return Pen;
    }
  };

  // Shape icon lookup
  const getShapeIcon = (t: ToolType) => {
    switch (t) {
      case "ellipse": return Circle;
      case "diamond": return Diamond;
      case "triangle": return Triangle;
      case "star": return Star;
      case "cloud": return Cloud;
      case "line": return Minus;
      case "arrow": return ArrowRight;
      case "rectangle":
      default: return Square;
    }
  };

  const dockPos = toolbarPosition;
  const vertical = isVerticalDock(dockPos);
  const flyout = flyoutSide(dockPos);

  // Every button the tool bar can hold. Which ones show, and in what order,
  // is the user's choice (the bar's Customize button); a thin divider is drawn
  // wherever two neighbours belong to different groups.
  const toolbarButtons: Record<ToolbarItemId, React.ReactNode> = {
    select: <SelectToolButton vertical={vertical} />,
    pan: (
      <Tooltip>
        <TooltipTrigger asChild>
          <button
            onClick={() => setTool("pan")}
            aria-label="Pan Canvas"
            className={cn(
              "p-2.5 rounded-xl transition-all",
              tool === "pan"
                ? "bg-primary text-primary-foreground shadow-sm"
                : "hover:bg-muted text-muted-foreground hover:text-foreground"
            )}
          >
            <Hand size={18} />
          </button>
        </TooltipTrigger>
        <TooltipContent side={flyout}>Pan Canvas (H / Space+Drag)</TooltipContent>
      </Tooltip>
    ),
    textselect: (
      <Tooltip>
        <TooltipTrigger asChild>
          <button
            onClick={() => setTool("textselect")}
            aria-label="Select text"
            className={cn(
              "p-2.5 rounded-xl transition-all",
              tool === "textselect"
                ? "bg-primary text-primary-foreground shadow-sm"
                : "hover:bg-muted text-muted-foreground hover:text-foreground"
            )}
          >
            <TextSelectIcon size={18} />
          </button>
        </TooltipTrigger>
        <TooltipContent side={flyout}>
          Select text (I)
          <span className="block text-[10px] opacity-70">Copy, highlight or underline the text of PDF, Word and PowerPoint pages</span>
        </TooltipContent>
      </Tooltip>
    ),
    pen: (
<>
      {/* Pen — SELECTION only. Its colour, thickness and pen family live in
          the contextual properties row and its ⚙ panel, so the same controls
          no longer exist in two places. */}
      <Tooltip>
        <TooltipTrigger asChild>
          <button
            {...penLongPress.handlers}
            aria-label="Pen tool"
            onClick={() => {
              // A long press already opened the picker; don't also re-select.
              if (penLongPress.firedRef.current) return;
              setTool(isPenTool ? tool : lastStrokeTool);
            }}
            // Double-click the tool you are already holding to open its
            // settings — the same gesture desktop apps use for tool options.
            // Selecting a pen and choosing WHICH pen are different intents,
            // so a single click must not open a panel over the canvas.
            onDoubleClick={() => {
              if (!isPenTool) setTool(lastStrokeTool);
              setToolPanelOpen(true);
            }}
            className={cn(
              "relative flex items-center p-2.5 rounded-xl transition-all",
              isPenTool
                ? "bg-primary text-primary-foreground shadow-sm"
                : "hover:bg-muted text-muted-foreground hover:text-foreground"
            )}
          >
            {React.createElement(getPenIcon((isPenTool ? tool : lastStrokeTool) as StrokeStyle), { size: 18 })}
            <span
              className="absolute bottom-1 right-1 w-2 h-2 rounded-full border border-background"
              style={{ backgroundColor: activeInkColor }}
            />
          </button>
        </TooltipTrigger>
        <TooltipContent side={flyout}>
          {PEN_TYPE_PRESETS[(isPenTool ? tool : lastStrokeTool) as StrokeStyle]?.label ?? "Pen"} (P)
          <span className="block text-[10px] opacity-70">Double-click for pen types</span>
        </TooltipContent>
      </Tooltip>
      </>
    ),
    eraser: (
<>
      {/* Eraser */}
      <Tooltip>
        <TooltipTrigger asChild>
          <button
            onClick={() => setTool("eraser")}
            aria-label="Eraser tool"
            // Same gesture as the pen: double-click the tool to open its
            // settings, so the rule is "double-click any tool" rather than a
            // one-off for one button.
            onDoubleClick={() => {
              setTool("eraser");
              setToolPanelOpen(true);
            }}
            className={cn(
              "p-2.5 rounded-xl transition-all",
              tool === "eraser"
                ? "bg-primary text-primary-foreground shadow-sm"
                : "hover:bg-muted text-muted-foreground hover:text-foreground"
            )}
          >
            <Eraser size={18} />
          </button>
        </TooltipTrigger>
        <TooltipContent side={flyout}>Eraser (E)</TooltipContent>
      </Tooltip>
      </>
    ),
    laser: (
      <Tooltip>
        <TooltipTrigger asChild>
          <button
            onClick={() => setTool("laser")}
            aria-label="Laser pointer"
            // Double-click (or long-press on the tablet) for its type, size and colour.
            onDoubleClick={() => {
              setTool("laser");
              setToolPanelOpen(true);
            }}
            {...laserLongPress.handlers}
            className={cn(
              "relative p-2.5 rounded-xl transition-all",
              tool === "laser"
                ? "bg-primary text-primary-foreground shadow-sm"
                : "hover:bg-muted text-muted-foreground hover:text-foreground"
            )}
          >
            <LaserIcon size={18} />
            <span
              className="absolute bottom-1 right-1 w-2 h-2 rounded-full border border-background"
              style={{ backgroundColor: getToolColor(style, "laser"), boxShadow: `0 0 4px ${getToolColor(style, "laser")}` }}
            />
          </button>
        </TooltipTrigger>
        <TooltipContent side={flyout}>
          Laser pointer (K)
          <span className="block text-[10px] opacity-70">Points without writing. Double-click for its settings</span>
        </TooltipContent>
      </Tooltip>
    ),
    autoshape: (
      <Tooltip>
        <TooltipTrigger asChild>
          <button
            onClick={() => {
              // Turning it on means you are about to draw a shape: pick up
              // the pen if something else is in hand.
              if (!shapeRecognition && !isStrokeTool(tool)) setTool(lastStrokeTool);
              toggleShapeRecognition();
            }}
            aria-label="Shape recognition"
            aria-pressed={shapeRecognition}
            className={cn(
              "relative p-2.5 rounded-xl transition-all",
              shapeRecognition
                ? "bg-primary/12 text-primary ring-1 ring-primary/40"
                : "hover:bg-muted text-muted-foreground hover:text-foreground"
            )}
          >
            <ShapeAssistIcon size={18} />
            {shapeRecognition && (
              <span className="absolute right-1 top-1 h-1.5 w-1.5 rounded-full bg-primary" />
            )}
          </button>
        </TooltipTrigger>
        <TooltipContent side={flyout}>
          Shape recognition: {shapeRecognition ? "on" : "off"}
          <span className="block text-[10px] opacity-70">
            Draw a circle, line or box with the pen and it becomes the exact shape
          </span>
        </TooltipContent>
      </Tooltip>
    ),
    shapes: (
<>
      {/* Shapes Flyout */}
      <Popover>
        <PopoverTrigger asChild>
          <button
            onClick={() => {
              if (!isShapeTool) setTool("rectangle");
            }}
            aria-label="Shapes tool"
            className={cn(
              "flex items-center gap-1 p-2.5 rounded-xl transition-all",
              isShapeTool
                ? "bg-primary text-primary-foreground shadow-sm"
                : "hover:bg-muted text-muted-foreground hover:text-foreground"
            )}
          >
            {React.createElement(getShapeIcon(isShapeTool ? tool : "rectangle"), { size: 18 })}
            <ChevronDown size={12} className="opacity-60" />
          </button>
        </PopoverTrigger>
        <PopoverContent side={flyout} className="w-56 p-2" align="center">
          <div className="px-2 py-1 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
            Shapes & Primitives
          </div>
          <div className="grid grid-cols-4 gap-1 p-1">
            {[
              { t: "rectangle" as ToolType, icon: Square, label: "Rectangle (R)" },
              { t: "ellipse" as ToolType, icon: Circle, label: "Ellipse (O)" },
              { t: "diamond" as ToolType, icon: Diamond, label: "Diamond (D)" },
              { t: "triangle" as ToolType, icon: Triangle, label: "Triangle" },
              { t: "star" as ToolType, icon: Star, label: "Star" },
              { t: "cloud" as ToolType, icon: Cloud, label: "Cloud" },
              { t: "line" as ToolType, icon: Minus, label: "Line (L)" },
              { t: "arrow" as ToolType, icon: ArrowRight, label: "Arrow (A)" },
            ].map(({ t, icon: Icon, label }) => (
              <button
                key={t}
                onClick={() => setTool(t)}
                title={label}
                className={cn(
                  "p-2.5 rounded-lg flex items-center justify-center transition-colors",
                  tool === t ? "bg-primary text-primary-foreground" : "hover:bg-muted text-foreground"
                )}
              >
                <Icon size={18} />
              </button>
            ))}
          </div>

          {/* Shape Border Width Slider */}
          <div className="space-y-1.5 pt-2 border-t border-border/50">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-medium text-muted-foreground">Border Width</span>
              <span className="text-[11px] font-bold tabular-nums px-1.5 py-0.2 rounded bg-primary/10 text-primary">
                {style.strokeWidth || 2} px
              </span>
            </div>
            <StepperRow
              value={style.strokeWidth || 2}
              min={1}
              max={32}
              onChange={(strokeWidth) => setStyle({ strokeWidth })}
            >
              <input
                type="range"
                min="1"
                max="32"
                step="1"
                value={style.strokeWidth || 2}
                aria-label="Border width"
                onChange={(e) => {
                  const sz = Number(e.target.value);
                  setStyle({ strokeWidth: sz });
                }}
                className="w-full h-1.5 bg-muted rounded-lg appearance-none cursor-pointer accent-primary"
              />
            </StepperRow>
          </div>

          {/* Shape Border Colors */}
          <div className="space-y-1 pt-1">
            <span className="text-[11px] text-muted-foreground">Border Color</span>
            <div className="grid grid-cols-5 gap-1">
              {PEN_COLORS.slice(0, 10).map((c) => (
                <button
                  key={c}
                  onClick={() => setStyle({ shapeStrokeColor: c, shapeFillColor: c, strokeColor: c })}
                  className={cn(
                    "w-5 h-5 rounded-full border transition-transform",
                    style.shapeStrokeColor === c ? "scale-110 border-foreground ring-1 ring-primary" : "border-border"
                  )}
                  style={{ backgroundColor: c }}
                />
              ))}
            </div>
          </div>
        </PopoverContent>
      </Popover>
      </>
    ),
    connect: (
<>
      {/* Smart Connector Tool */}
      <Popover>
        <PopoverTrigger asChild>
          <button
            onClick={() => setTool("connect")}
            aria-label="Smart connector tool"
            className={cn(
              "flex items-center gap-1 p-2.5 rounded-xl transition-all",
              tool === "connect"
                ? "bg-primary text-primary-foreground shadow-sm ring-2 ring-primary/40"
                : "hover:bg-muted text-muted-foreground hover:text-foreground"
            )}
          >
            <Link2 size={18} />
            <ChevronDown size={12} className="opacity-60" />
          </button>
        </PopoverTrigger>
        <PopoverContent side={flyout} className="w-72 p-3 space-y-3" align="center">
          <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
            Smart Connectors & Relationships
          </div>

          {/* Routing style */}
          <div className="space-y-1.5">
            <span className="text-xs text-muted-foreground">Arrow Routing</span>
            <div className="grid grid-cols-3 gap-1">
              {(["curved", "orthogonal", "straight"] as ConnectionRouting[]).map((r) => (
                <button
                  key={r}
                  onClick={() => {
                    setStyle({ connectionRouting: r });
                    setTool("connect");
                  }}
                  className={cn(
                    "py-1.5 px-2 rounded-lg border text-xs capitalize transition-colors font-medium",
                    style.connectionRouting === r
                      ? "border-primary bg-primary/10 text-primary"
                      : "border-border hover:bg-muted text-foreground"
                  )}
                >
                  {r}
                </button>
              ))}
            </div>
          </div>

          {/* Semantic Relationship Types */}
          <div className="space-y-1.5">
            <span className="text-xs text-muted-foreground">Relationship Type</span>
            <div className="space-y-1 max-h-44 overflow-y-auto pr-1">
              {BUILTIN_LINK_TYPES.map((lt) => (
                <button
                  key={lt}
                  onClick={() => {
                    setStyle({ connectionLinkType: lt });
                    setTool("connect");
                  }}
                  className={cn(
                    "w-full text-left px-2.5 py-1.5 rounded-lg text-xs flex items-center justify-between transition-colors",
                    style.connectionLinkType === lt ? "bg-muted font-semibold" : "hover:bg-muted/60"
                  )}
                >
                  <div className="flex items-center gap-2">
                    <span
                      className="w-2.5 h-2.5 rounded-full"
                      style={{ backgroundColor: LINK_TYPE_COLORS[lt] }}
                    />
                    <span>{LINK_TYPE_LABELS[lt]}</span>
                  </div>
                  {style.connectionLinkType === lt && <Check size={12} className="text-primary" />}
                </button>
              ))}
            </div>
          </div>
        </PopoverContent>
      </Popover>
      </>
    ),
    text: (
<>
      {/* Text Tool */}
      <Tooltip>
        <TooltipTrigger asChild>
          <button
            onClick={() => setTool("text")}
            aria-label="Text tool"
            // Same gesture as the pen: double-click the tool to open its
            // settings, so the rule is "double-click any tool" rather than a
            // one-off for one button.
            onDoubleClick={() => {
              setTool("text");
              setToolPanelOpen(true);
            }}
            className={cn(
              "p-2.5 rounded-xl transition-all",
              tool === "text"
                ? "bg-primary text-primary-foreground shadow-sm"
                : "hover:bg-muted text-muted-foreground hover:text-foreground"
            )}
          >
            <Type size={18} />
          </button>
        </TooltipTrigger>
        <TooltipContent side={flyout}>Text & Markdown (T)</TooltipContent>
      </Tooltip>
      </>
    ),
    sticky: (
<>
      {/* Sticky Note Tool */}
      <Tooltip>
        <TooltipTrigger asChild>
          <button
            onClick={() => setTool("sticky")}
            aria-label="Sticky note tool"
            // Same gesture as the pen: double-click the tool to open its
            // settings, so the rule is "double-click any tool" rather than a
            // one-off for one button.
            onDoubleClick={() => {
              setTool("sticky");
              setToolPanelOpen(true);
            }}
            className={cn(
              "p-2.5 rounded-xl transition-all",
              tool === "sticky"
                ? "bg-primary text-primary-foreground shadow-sm"
                : "hover:bg-muted text-muted-foreground hover:text-foreground"
            )}
          >
            <StickyNote size={18} />
          </button>
        </TooltipTrigger>
        <TooltipContent side={flyout}>Sticky Note (N)</TooltipContent>
      </Tooltip>
      </>
    ),
    image: <ImageInsertButton flyout={flyout} />,
  };
  const groupOf = (id: ToolbarItemId) => TOOLBAR_ITEMS.find((t) => t.id === id)?.group;

  return (
    <TooltipProvider delayDuration={300}>

      {/* Main Floating Tool Dock */}
      {/* Both bottom docks live in ONE wrapping row.
          They used to be independently positioned (tools centered, zoom pinned
          right), which is fine on a wide window but overlaps as soon as the
          window narrows — the zoom dock covered the right-hand tools and made
          them unclickable. In a shared flex row they sit side by side when
          there is room and stack when there is not, so they can never collide
          at any window size. */}
      <div
        // Measured by the favourite pens bar, which must never cover the
        // toolbar (see the exclusion in its clamp).
        data-wb-toolbar
        className={cn(
          "absolute z-30 flex w-max gap-2 transition-[left] duration-150",
          dockStackClasses(dockPos),
          dockSizeClasses(dockPos)
        )}
        style={dockPos === "left" && pagePanelOpen ? { left: PANEL_W + 16 } : undefined}
      >
        {/* Row 1: properties of the ACTIVE tool (colour, thickness, settings).
            Selecting a tool and configuring it are separate jobs, so they get
            separate rows — the pattern Samsung Notes / Concepts use. */}
        <ToolPropertiesBar onOpenPanel={() => setToolPanelOpen(true)} />

        <div
          className={cn(
            "flex items-center justify-center gap-1.5",
            // Never wrap: the page controls stay on the LEFT of the tools, on
            // the same line. A wrapping row dropped them onto a line of their
            // own between the colour bar and the tools; now the tools pill
            // (min-w-0 below) shrinks and scrolls instead.
            vertical ? "min-h-0 max-h-full flex-col" : "max-w-full flex-nowrap"
          )}
        >
        {/* Which page you are on, on the left of the tools, compact. */}
        <NotebookPageControls />
        {/* The tools pill and its chevron travel together: `min-w-0` lets the
            pill shrink and scroll while the chevron keeps its place at the
            end. Without this group the chevron is just another flex child of
            a wrapping row, and on a narrow pane it drops onto its own line. */}
        <div className={cn("flex min-w-0 max-w-full items-center gap-1.5", vertical && "min-h-0 max-h-full flex-col")}>
        {/* One line of tools, never two: when they do not fit, swipe or
            drag the bar sideways (up and down on a side dock). The edges fade
            where more tools are waiting. */}
        <div
          ref={scroller.ref}
          className={cn(
            "flex items-center gap-1.5 p-1.5 bg-white/95 dark:bg-zinc-900/95 backdrop-blur-xl shadow-2xl border border-border/80 rounded-2xl select-none",
            "[scrollbar-width:none] [&::-webkit-scrollbar]:hidden [&>*]:shrink-0",
            vertical ? "max-h-full min-h-0 flex-col overflow-y-auto" : "min-w-0 max-w-full flex-nowrap overflow-x-auto"
          )}
          style={scroller.style}
        >
        <DockGrip />
        {toolbarItems.map((id, i) => (
          <React.Fragment key={id}>
            {i > 0 && groupOf(toolbarItems[i - 1]) !== groupOf(id) && (
              <Separator
                orientation={vertical ? "horizontal" : "vertical"}
                className={cn("shrink-0", vertical ? "w-6 h-px my-0.5" : "h-6 w-px mx-0.5")}
              />
            )}
            {toolbarButtons[id]}
          </React.Fragment>
        ))}

        {/* Customise the tool bar: which tools it holds and in what order.
            The LAST item of the bar itself - it belongs to the bar it
            changes, and on a narrow screen you drag the bar to its end to
            reach it, like any other tool. */}
        <Separator
          orientation={vertical ? "horizontal" : "vertical"}
          className={cn("shrink-0", vertical ? "w-6 h-px my-0.5" : "h-6 w-px mx-0.5")}
        />
        <Popover>
          <Tooltip>
            <TooltipTrigger asChild>
              <PopoverTrigger asChild>
                <button
                  aria-label="Customize tool bar"
                  className="p-2.5 rounded-xl text-muted-foreground transition-all hover:bg-muted hover:text-foreground data-[state=open]:bg-primary data-[state=open]:text-primary-foreground"
                >
                  <SlidersHorizontal size={18} />
                </button>
              </PopoverTrigger>
            </TooltipTrigger>
            <TooltipContent side={flyout}>Customize tool bar</TooltipContent>
          </Tooltip>
          <PopoverContent
            side={flyout}
            align="end"
            collisionPadding={12}
            className="w-80 max-w-[calc(100vw-2rem)] p-0"
          >
            <div className="border-b border-border/70 px-3 py-2.5">
              <div className="text-sm font-semibold">Tool bar</div>
              <div className="text-[11px] text-muted-foreground">Choose the tools and their order</div>
            </div>
            <div className="max-h-[min(60vh,28rem)] overflow-y-auto py-2">
              <ToolbarCustomizer />
            </div>
          </PopoverContent>
        </Popover>

      </div>

        {/* Fold the active tool's properties row away.
            It lives OUTSIDE the scrolling pill on purpose: everything in that
            pill slides when the tools overflow, and a control that scrolls off
            the end is a control you cannot reach exactly when the bar is
            crowded enough to need it. Pinned here it is always in the same
            place, and the arrow points at what the press will do. */}
        {toolHasProperties(tool) && (
          <Tooltip>
            <TooltipTrigger asChild>
              <button
                onClick={toggleToolPropsBar}
                aria-label={toolPropsCollapsed ? "Show tool options" : "Hide tool options"}
                aria-expanded={!toolPropsCollapsed}
                className="flex shrink-0 items-center justify-center rounded-2xl border border-border/80 bg-white/95 p-2 text-muted-foreground shadow-2xl backdrop-blur-xl transition-colors hover:bg-muted hover:text-foreground dark:bg-zinc-900/95"
              >
                {vertical
                  ? (toolPropsCollapsed
                      ? <ChevronRight size={16} />
                      : <ChevronLeft size={16} />)
                  : (toolPropsCollapsed
                      ? <ChevronUp size={16} />
                      : <ChevronDown size={16} />)}
              </button>
            </TooltipTrigger>
            <TooltipContent side={flyout}>
              {toolPropsCollapsed ? "Show tool options" : "Hide tool options"}
            </TooltipContent>
          </Tooltip>
        )}


        </div>

        </div>
      </div>

      {/* Its own corner, in every dock position. */}
      <ZoomDock />

      <ToolPropertiesPanel open={toolPanelOpen} onClose={() => setToolPanelOpen(false)} />
    </TooltipProvider>
  );
}
