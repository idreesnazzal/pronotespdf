"use client";

/**
 * Selection Overlay (v3)
 * =======================
 * Renders the selection bounding box and 8 interactive resize/rotation handles.
 */

import React from "react";
import { useWhiteboard } from "@/store/whiteboard";
import type { Camera, WhiteboardElement } from "@/lib/whiteboard/types";
import {
  getElementBounds,
  getResizeHandles,
  getUnionBounds,
  screenSpaceOverlayTransform,
  type Viewport,
} from "@/lib/whiteboard/geometry";

interface SelectionOverlayProps {
  selectedIds: string[];
  elements: WhiteboardElement[];
  camera: Camera;
  viewport: Viewport;
}

export function SelectionOverlay({
  selectedIds,
  elements,
  camera,
  viewport,
}: SelectionOverlayProps) {
  const editingId = useWhiteboard((s) => s.editingId);

  const selected = elements.filter((el) => selectedIds.includes(el.id));
  if (selected.length === 0) return null;

  // Don't render selection overlay while the element is actively being edited inline
  if (editingId && selectedIds.includes(editingId)) return null;

  const unionBounds = getUnionBounds(selected);
  if (!unionBounds) return null;

  const rotation = selected.length === 1 ? selected[0].rotation : 0;
  // Locked things can be selected (to unlock them) but never resized or
  // turned, so they get the box without handles that would do nothing.
  const allLocked = selected.every((el) => el.locked);
  const handles = allLocked ? [] : getResizeHandles(unionBounds, rotation, camera, viewport);

  const cx = unionBounds.x + unionBounds.width / 2;
  const cy = unionBounds.y + unionBounds.height / 2;
  const corners = [
    { x: unionBounds.x, y: unionBounds.y },
    { x: unionBounds.x + unionBounds.width, y: unionBounds.y },
    { x: unionBounds.x + unionBounds.width, y: unionBounds.y + unionBounds.height },
    { x: unionBounds.x, y: unionBounds.y + unionBounds.height },
  ].map((c) => {
    const cos = Math.cos(rotation);
    const sin = Math.sin(rotation);
    const dx = c.x - cx;
    const dy = c.y - cy;
    const rx = cx + dx * cos - dy * sin;
    const ry = cy + dx * sin + dy * cos;
    return {
      x: (rx - camera.x) * camera.zoom + viewport.width / 2,
      y: (ry - camera.y) * camera.zoom + viewport.height / 2,
    };
  });

  // Drawn size, and a separate, invisible TOUCH target around each handle.
  // The handles used to be 9 px and were also the only thing you could hit:
  // about 2 mm on a Galaxy Tab S9, against Android's 48 dp touch-target
  // guideline, so resize and rotate were effectively unreachable by finger or
  // pen. The hit circle below is 44 px across; the visible handle stays small
  // enough not to cover the picture.
  const handleSize = 14;
  const handleStrokeWidth = 2;
  const HIT_R = 22;

  // Handles/corners above are in SCREEN space; undo the world group so they
  // land where the element actually is at every zoom level.
  const inverseTransform = screenSpaceOverlayTransform(camera, viewport);

  return (
    <g transform={inverseTransform} style={{ pointerEvents: "none" }}>
      {/* Selection bounding box */}
      <polygon
        points={corners.map((c) => `${c.x},${c.y}`).join(" ")}
        fill="none"
        stroke="#6366f1"
        strokeWidth={handleStrokeWidth}
        strokeDasharray="5,4"
      />

      {/* Resize & Rotate handles */}
      {handles.map((h) => {
        if (h.handle === "rotate") {
          const topCenter = {
            x: (corners[0].x + corners[1].x) / 2,
            y: (corners[0].y + corners[1].y) / 2,
          };
          return (
            <g key={h.handle}>
              <line
                x1={topCenter.x}
                y1={topCenter.y}
                x2={h.x}
                y2={h.y}
                stroke="#6366f1"
                strokeWidth={handleStrokeWidth}
              />
              <circle
                cx={h.x}
                cy={h.y}
                r={handleSize / 2}
                fill="white"
                stroke="#6366f1"
                strokeWidth={handleStrokeWidth}
              />
              <circle
                cx={h.x}
                cy={h.y}
                r={HIT_R}
                fill="transparent"
                style={{ pointerEvents: "all", cursor: "grab" }}
                data-handle="rotate"
                data-element-id={selected[0].id}
              />
            </g>
          );
        }

        const cursor = getHandleCursor(h.handle, rotation);
        return (
          <g key={h.handle}>
            <rect
              x={h.x - handleSize / 2}
              y={h.y - handleSize / 2}
              width={handleSize}
              height={handleSize}
              fill="white"
              stroke="#6366f1"
              strokeWidth={handleStrokeWidth}
              rx={3}
            />
            <circle
              cx={h.x}
              cy={h.y}
              r={HIT_R}
              fill="transparent"
              style={{ pointerEvents: "all", cursor }}
              data-handle={h.handle}
              data-element-id={selected[0].id}
            />
          </g>
        );
      })}
    </g>
  );
}

function getHandleCursor(handle: string, rotation: number): string {
  const deg = ((rotation * 180) / Math.PI) % 360;
  const normalized = ((deg % 360) + 360) % 360;
  const isDiagonal =
    (normalized > 22.5 && normalized < 67.5) ||
    (normalized > 112.5 && normalized < 157.5) ||
    (normalized > 202.5 && normalized < 247.5) ||
    (normalized > 292.5 && normalized < 337.5);
  const isFlipped =
    (normalized > 67.5 && normalized < 112.5) || (normalized > 247.5 && normalized < 292.5);

  switch (handle) {
    case "n":
    case "s":
      return isFlipped ? "ew-resize" : "ns-resize";
    case "e":
    case "w":
      return isFlipped ? "ns-resize" : "ew-resize";
    case "ne":
    case "sw":
      return isDiagonal ? "nwse-resize" : "nesw-resize";
    case "nw":
    case "se":
      return isDiagonal ? "nesw-resize" : "nwse-resize";
    default:
      return "default";
  }
}
