"use client";

/**
 * Floating Selection Actions Bar (v3 — Obsidian Canvas Grade)
 * ============================================================
 * Contextual floating pill positioned directly above selected text or sticky cards.
 *
 * Every OTHER selection - ink, shapes, pictures, several things at once - gets
 * a single Capture chip instead, beside the selection's top-right corner:
 * clear of the rotate handle (top centre) and of the picture bar (below).
 * Capture takes a picture of the selection's area, background and all; the
 * capture panel can narrow it to the selected things only.
 */

import React, { useState } from "react";
import { useWhiteboard, useActiveBoard } from "@/store/whiteboard";
import { getActivePageIndex, getBoardElements, isNotebook } from "@/lib/whiteboard/notebook";
import { Link2, Hash, Edit3, Plus, Scan } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { getElementBounds, getUnionBounds, type Viewport } from "@/lib/whiteboard/geometry";
import { clampCaptureRegion, selectionCaptureRegion } from "@/lib/whiteboard/capture";
import type { Board } from "@/lib/whiteboard/types";
import { useCapture } from "@/store/capture";

/** Opens the capture panel on the selection's area. */
function captureSelection(board: Board, ids: string[], zoom: number) {
  const region = selectionCaptureRegion(getBoardElements(board), ids, zoom);
  if (!region) return;
  const anchorIndex = isNotebook(board) ? Math.max(0, getActivePageIndex(board)) : 0;
  // A selection hanging off the sheet is captured as far as the paper goes,
  // the same trim a drawn area gets.
  const clamped = clampCaptureRegion(board, anchorIndex, region) ?? region;
  useCapture.getState().open({
    source: { board, region: clamped, anchorIndex },
    origin: "selection",
    shape: "rectangle",
    selectionIds: ids,
    zoom,
    dpr: typeof window !== "undefined" ? window.devicePixelRatio || 1 : 1,
  });
}

export function SelectionActions({ viewport }: { viewport: Viewport }) {
  const selectedIds = useWhiteboard((s) => s.selectedIds);
  const editingId = useWhiteboard((s) => s.editingId);
  const setEditingId = useWhiteboard((s) => s.setEditingId);
  const setTool = useWhiteboard((s) => s.setTool);
  const camera = useWhiteboard((s) => s.camera);
  const activeBoard = useActiveBoard();
  const boards = useWhiteboard((s) => s.boards);
  const updateElement = useWhiteboard((s) => s.updateElement);

  const studioOpen = useWhiteboard((s) => s.imageStudioId !== null);
  const capturing = useCapture((s) => s.request !== null);

  const [tagInput, setTagInput] = useState("");
  const [popoverOpen, setPopoverOpen] = useState(false);

  if (selectedIds.length === 0 || editingId !== null || !activeBoard || studioOpen || capturing) {
    return null;
  }

  const selectedElement =
    selectedIds.length === 1 ? getBoardElements(activeBoard).find((el) => el.id === selectedIds[0]) : undefined;
  if (!selectedElement || (selectedElement.type !== "text" && selectedElement.type !== "sticky")) {
    return <CaptureChip board={activeBoard} ids={selectedIds} viewport={viewport} />;
  }

  const bounds = getElementBounds(selectedElement);
  const screenX = (bounds.x - camera.x) * camera.zoom + viewport.width / 2;
  const screenY = (bounds.y - camera.y) * camera.zoom + viewport.height / 2;
  const screenW = bounds.width * camera.zoom;

  const barX = screenX + screenW / 2;
  const barY = Math.max(screenY - 44, 20);

  const currentText = (selectedElement as { text: string }).text || "";

  const insertLink = (boardName: string) => {
    const linkSyntax = `[[${boardName}]]`;
    const newText =
      currentText +
      (currentText.endsWith(" ") || currentText === "" ? "" : " ") +
      linkSyntax +
      " ";
    updateElement(selectedElement.id, { text: newText }, true);
    setPopoverOpen(false);
  };

  const insertTag = (e: React.FormEvent) => {
    e.preventDefault();
    const tag = tagInput.trim().replace(/^#/, "");
    if (!tag) return;
    const tagSyntax = `#${tag}`;
    const newText =
      currentText +
      (currentText.endsWith(" ") || currentText === "" ? "" : " ") +
      tagSyntax +
      " ";
    updateElement(selectedElement.id, { text: newText }, true);
    setTagInput("");
  };

  return (
    <div
      className="absolute z-30 -translate-x-1/2 flex items-center gap-1 px-2 py-1 bg-white/95 dark:bg-zinc-900/95 backdrop-blur-md rounded-xl shadow-xl border border-border text-foreground text-xs select-none animate-in fade-in zoom-in-95"
      style={{ left: `${barX}px`, top: `${barY}px` }}
      onMouseDown={(e) => e.stopPropagation()}
    >
      {/* Edit text button */}
      <button
        onClick={() => setEditingId(selectedElement.id)}
        className="flex items-center gap-1 px-2 py-1 rounded-lg hover:bg-muted font-medium text-primary"
      >
        <Edit3 size={13} />
        <span>Edit</span>
      </button>

      <span className="w-px h-3.5 bg-border mx-0.5" />

      {/* Link to Board Popover */}
      <Popover open={popoverOpen} onOpenChange={setPopoverOpen}>
        <PopoverTrigger asChild>
          <button className="flex items-center gap-1 px-2 py-1 rounded-lg hover:bg-muted font-medium text-foreground">
            <Link2 size={13} />
            <span>Link to Board</span>
          </button>
        </PopoverTrigger>
        <PopoverContent className="w-60 p-1.5 text-xs" align="center">
          <div className="px-2 py-1 text-[10px] font-semibold text-muted-foreground uppercase tracking-wider">
            Select Board to Link
          </div>
          <div className="max-h-48 overflow-y-auto space-y-0.5">
            {boards
              .filter((b) => b.id !== activeBoard.id)
              .map((b) => (
                <button
                  key={b.id}
                  onClick={() => insertLink(b.name)}
                  className="w-full text-left px-2.5 py-1.5 rounded-md hover:bg-muted flex items-center justify-between text-xs transition-colors"
                >
                  <span className="truncate">{b.name}</span>
                  <span className="text-[10px] text-muted-foreground">[[...]]</span>
                </button>
              ))}
          </div>
        </PopoverContent>
      </Popover>

      <span className="w-px h-3.5 bg-border mx-0.5" />

      {/* Add Tag Form */}
      <form onSubmit={insertTag} className="flex items-center gap-1">
        <div className="flex items-center gap-0.5 px-1.5 py-0.5 rounded-lg bg-muted/60 border border-border/50">
          <Hash size={11} className="text-emerald-500" />
          <input
            type="text"
            value={tagInput}
            onChange={(e) => setTagInput(e.target.value)}
            placeholder="tag"
            className="w-14 bg-transparent outline-none text-[11px]"
          />
        </div>
        {tagInput.trim() && (
          <button type="submit" className="p-1 rounded hover:bg-muted text-emerald-600">
            <Plus size={12} />
          </button>
        )}
      </form>

      <span className="w-px h-3.5 bg-border mx-0.5" />

      <button
        onClick={() => captureSelection(activeBoard, selectedIds, camera.zoom)}
        title="Capture a picture of this to copy or share"
        className="flex items-center gap-1 px-2 py-1 rounded-lg hover:bg-muted font-medium text-indigo-600 dark:text-indigo-300"
      >
        <Scan size={13} />
        <span>Capture</span>
      </button>
    </div>
  );
}

/** The one-button bar for every selection that is not a text box or note. */
function CaptureChip({ board, ids, viewport }: { board: Board; ids: string[]; viewport: Viewport }) {
  const camera = useWhiteboard((s) => s.camera);
  const set = new Set(ids);
  const picked = getBoardElements(board).filter((el) => set.has(el.id) && el.type !== "connection");
  const b = getUnionBounds(picked);
  if (!b) return null;

  const left = (b.x - camera.x) * camera.zoom + viewport.width / 2;
  const right = left + b.width * camera.zoom;
  const top = (b.y - camera.y) * camera.zoom + viewport.height / 2;
  const chipW = 104;
  // Beside the top-right corner handle; flipped to the left edge when the
  // selection runs off the right of the screen, and kept on screen always.
  const x = right + 14 + chipW <= viewport.width - 8 ? right + 14 : Math.max(8, left - 14 - chipW);
  const y = Math.min(Math.max(top - 6, 8), viewport.height - 48);

  return (
    <button
      onClick={() => captureSelection(board, ids, camera.zoom)}
      onPointerDown={(e) => e.stopPropagation()}
      onMouseDown={(e) => e.stopPropagation()}
      title="Capture a picture of the selection to copy, share or add to a notebook"
      className="absolute z-30 flex h-9 items-center gap-1.5 rounded-full border border-white/10 bg-zinc-900/95 pl-2 pr-3.5 text-[12px] font-semibold text-white shadow-xl shadow-black/20 backdrop-blur-md transition hover:bg-zinc-800 active:scale-95 animate-in fade-in zoom-in-95"
      style={{ left: x, top: y, width: chipW }}
    >
      <span className="flex h-6 w-6 items-center justify-center rounded-full bg-gradient-to-br from-indigo-500 to-violet-500">
        <Scan size={13} />
      </span>
      Capture
    </button>
  );
}
