"use client";

/**
 * Link Legend
 * ============
 * A floating panel (bottom-right) showing all link types and their colors —
 * like a map key/legend. Shows:
 * - Built-in types (Reference, Dependency, Related, Flow)
 * - Custom types created by the user
 * - Parent-child (folder→board) relationship
 *
 * Toggle visibility with the "Legend" button in the header.
 */

import React from "react";
import { useWhiteboard } from "@/store/whiteboard";
import {
  BUILTIN_LINK_TYPES,
  LINK_TYPE_COLORS,
  LINK_TYPE_LABELS,
  getLinkTypeColor,
  getLinkTypeLabel,
} from "@/lib/whiteboard/types";
import { Map } from "lucide-react";
import { cn } from "@/lib/utils";

export function LinkLegend({ visible, onToggle }: { visible: boolean; onToggle: () => void }) {
  const customLinkTypes = useWhiteboard((s) => s.customLinkTypes);

  if (!visible) return null;

  return (
    // Clear of the bottom docks. The toolbar and the zoom/undo cluster both sit
    // at `bottom-6` (24px) with z-30 and are ~52px tall, so they occupy roughly
    // 24-76px; the legend used to sit at bottom-16 (64px) with z-20 and was
    // drawn underneath them. bottom-28 clears the docks, right-6 lines it up
    // with the right-hand cluster, and max-h keeps a long custom-type list from
    // growing up into the header.
    <div className="absolute bottom-28 right-6 z-30 bg-white/95 dark:bg-zinc-900/95 backdrop-blur-md shadow-lg border border-border rounded-xl p-3 w-56 max-h-[45vh] overflow-y-auto">
      <div className="flex items-center gap-1.5 mb-2">
        <Map size={13} className="text-muted-foreground" />
        <span className="text-xs font-semibold">Link Legend</span>
      </div>
      <div className="space-y-1.5">
        {/* Built-in types */}
        {BUILTIN_LINK_TYPES.map((lt) => (
          <div key={lt} className="flex items-center gap-2 text-xs">
            <span
              className="w-4 h-1.5 rounded-full shrink-0"
              style={{ backgroundColor: LINK_TYPE_COLORS[lt] }}
            />
            <span>{LINK_TYPE_LABELS[lt]}</span>
          </div>
        ))}
        {/* Custom types */}
        {customLinkTypes.map((ct) => (
          <div key={ct.id} className="flex items-center gap-2 text-xs">
            <span
              className="w-4 h-1.5 rounded-full shrink-0"
              style={{ backgroundColor: ct.color }}
            />
            <span>{ct.name}</span>
          </div>
        ))}
        {/* Parent-child (folder→board) */}
        <div className="flex items-center gap-2 text-xs pt-1 border-t border-border">
          <span className="w-4 h-1.5 shrink-0 border-t-2 border-dashed border-gray-400" />
          <span className="text-muted-foreground">contains (folder→board)</span>
        </div>
      </div>
    </div>
  );
}
