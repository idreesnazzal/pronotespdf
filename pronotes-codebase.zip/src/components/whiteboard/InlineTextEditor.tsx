"use client";

/**
 * Inline Text & Markdown Editor (v5 — Professional Grade)
 * =======================================================
 * The unified, professional inline text editor for ProNotes.
 *
 * Core Features:
 * - Live Voice Dictation ("Record to Text"): Real-time Speech-to-Text streaming
 *   directly into the note with pulsing audio waveform and listening status.
 * - Intelligent List Continuation: Pressing Enter on `- [ ]`, `- `, or `1. `
 *   automatically continues the list, and pressing Enter on an empty prefix
 *   exits list mode cleanly.
 * - Rich Typography & Formatting: Headings (H1/H2/H3), Bold, Italic, Underline,
 *   Strikethrough, Code, Highlighting, Blockquotes, Checklists, and LaTeX Math.
 * - Card / Callout Mode: Toggle between canvas transparent text and styled
 *   cards with background tints, borders, and rounded corners.
 * - Smart Text Utilities: Case transformations (UPPERCASE, lowercase, Title Case)
 *   and real-time word/character count.
 * - Touch & Stylus Ergonomics: Clamped to viewport edges, generous touch targets,
 *   glassmorphic design, and instant tactile feedback.
 */

import React, { useEffect, useLayoutEffect, useRef, useState, useCallback, useMemo } from "react";
import { useWhiteboard } from "@/store/whiteboard";
import { getBoardElements } from "@/lib/whiteboard/notebook";
import { worldToScreen, type Viewport } from "@/lib/whiteboard/geometry";
import {
  FONT_FAMILIES,
  PEN_COLORS,
  STICKY_COLORS,
  CARD_BACKGROUNDS,
  setToolInk,
  type LineDir,
  type StickyColor,
  type StickyElement,
  type StyleState,
  type TextAlign,
  type TextElement,
} from "@/lib/whiteboard/types";
import {
  detectLineDir,
  getNextLinePrefix,
  prefixSelectedLines,
  resolveLineDir,
  selectedLineRange,
  setLineDirs,
  spliceFormatMarkers,
} from "@/lib/whiteboard/textParser";
import {
  VoiceDictationController,
  spliceDictationChunk,
  placeInterim,
  stripInterim,
  SUPPORTED_DICTATION_LANGS,
  resolveDictationLang,
  type DictationRange,
  type SpeechStatus,
} from "@/lib/whiteboard/speechRecognition";
import {
  Bold,
  Italic,
  Underline,
  Strikethrough,
  Code,
  Heading1,
  Heading2,
  Heading3,
  List,
  ListOrdered,
  CheckSquare,
  Quote,
  AlignLeft,
  AlignCenter,
  AlignRight,
  Link2,
  Check,
  ChevronDown,
  MoreHorizontal,
  ArrowUpToLine,
  ArrowDownToLine,
  Copy,
  Lock,
  Trash2,
  Mic,
  MicOff,
  Languages,
  Square,
  Sparkles,
  AlertCircle,
  Loader2,
  X,
} from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { StepButton } from "./StepperControl";
import { cn } from "@/lib/utils";

const MIN_FONT = 10;
const MAX_FONT = 96;
const SIZE_PRESETS = [12, 14, 18, 24, 32, 40, 54, 72];
const EDGE = 8;
const GAP = 8;

export function InlineTextEditor({ viewport }: { viewport: Viewport }) {
  const editingId = useWhiteboard((s) => s.editingId);
  const setEditingId = useWhiteboard((s) => s.setEditingId);
  const camera = useWhiteboard((s) => s.camera);
  const activeBoardId = useWhiteboard((s) => s.activeBoardId);
  const boards = useWhiteboard((s) => s.boards);
  const updateElement = useWhiteboard((s) => s.updateElement);
  const deleteElements = useWhiteboard((s) => s.deleteElements);
  const duplicateElements = useWhiteboard((s) => s.duplicateElements);
  const toggleLock = useWhiteboard((s) => s.toggleLock);
  const bringToFront = useWhiteboard((s) => s.bringToFront);
  const sendToBack = useWhiteboard((s) => s.sendToBack);
  const commitHistory = useWhiteboard((s) => s.commitHistory);
  const setStyle = useWhiteboard((s) => s.setStyle);

  const activeBoard = useMemo(() => boards.find((b) => b.id === activeBoardId), [boards, activeBoardId]);
  const activeElement = useMemo(() => {
    if (!editingId || !activeBoard) return null;
    return getBoardElements(activeBoard).find((el) => el.id === editingId) || null;
  }, [editingId, activeBoard]);

  const [text, setText] = useState("");
  // Live selection, so line tools (direction, and the bar indicator) follow
  // the cursor without waiting for a keystroke.
  const [selRange, setSelRange] = useState({ start: 0, end: 0 });
  const [wikiQuery, setWikiQuery] = useState<string | null>(null);
  const [wikiCursorPos, setWikiCursorPos] = useState<number>(0);
  const [selectedWikiIndex, setSelectedWikiIndex] = useState(0);
  const [barSize, setBarSize] = useState({ width: 0, height: 44 });

  // Voice dictation state
  const [dictating, setDictating] = useState(false);
  const [speechStatus, setSpeechStatus] = useState<SpeechStatus>("idle");
  const [dictationMessage, setDictationMessage] = useState<string | null>(null);
  const [interimText, setInterimText] = useState("");
  const dictationRef = useRef<VoiceDictationController | null>(null);
  const dictationDismissTimer = useRef<NodeJS.Timeout | null>(null);
  const dictationLang = useWhiteboard((s) => s.dictationLang);
  const setDictationLang = useWhiteboard((s) => s.setDictationLang);
  const pickDictationLang = useCallback(
    (id: string) => {
      const resolved = resolveDictationLang(id);
      setDictationLang(resolved);
      // Live-switch when the engine allows it; otherwise the next
      // Dictate press starts in the new language.
      dictationRef.current?.setLang(resolved);
    },
    [setDictationLang]
  );

  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const boxRef = useRef<HTMLDivElement>(null);
  const barRef = useRef<HTMLDivElement>(null);
  const sessionCommittedRef = useRef(false);

  // Sync state when entering edit mode on an element
  useEffect(() => {
    sessionCommittedRef.current = false;
    setDictating(false);
    setInterimText("");
    setDictationMessage(null);
    lastDictationRef.current = null;
    interimRangeRef.current = null;
    if (dictationDismissTimer.current) {
      clearTimeout(dictationDismissTimer.current);
      dictationDismissTimer.current = null;
    }
    // abort, not stop: stop() writes the words still being heard, and by now
    // this callback points at the NEW box. Leaving a box (exitEditing) stops
    // properly first, so nothing said there is lost.
    if (dictationRef.current) {
      dictationRef.current.abort();
    }

    if (activeElement && (activeElement.type === "text" || activeElement.type === "sticky")) {
      const elText = (activeElement as TextElement | StickyElement).text || "";
      setText(elText);
      setWikiQuery(null);

      requestAnimationFrame(() => {
        if (textareaRef.current) {
          textareaRef.current.focus({ preventScroll: true });
          const len = textareaRef.current.value.length;
          textareaRef.current.setSelectionRange(len, len);
          adjustHeight();
        }
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [editingId]);

  // Clean up voice dictation when component unmounts
  useEffect(() => {
    return () => {
      dictationRef.current?.abort();
      if (dictationDismissTimer.current) {
        clearTimeout(dictationDismissTimer.current);
      }
    };
  }, []);

  const exitEditing = useCallback(() => {
    if (dictationDismissTimer.current) {
      clearTimeout(dictationDismissTimer.current);
      dictationDismissTimer.current = null;
    }
    if (dictating) {
      dictationRef.current?.stop();
      setDictating(false);
      setInterimText("");
    }
    lastDictationRef.current = null;
    setDictationMessage(null);
    setEditingId(null);
  }, [dictating, setEditingId]);

  // End edit on pointer-down outside
  useEffect(() => {
    if (!editingId) return;
    const onDown = (e: PointerEvent) => {
      const t = e.target as Element | null;
      if (!t) return;
      if (boxRef.current?.contains(t)) return;
      if (barRef.current?.contains(t)) return;
      if (t.closest?.("[data-radix-popper-content-wrapper]")) return;
      exitEditing();
    };
    document.addEventListener("pointerdown", onDown, true);
    return () => document.removeEventListener("pointerdown", onDown, true);
  }, [editingId, exitEditing]);

  const mutateElement = useCallback(
    (patch: Partial<TextElement> | Partial<StickyElement>) => {
      if (!activeElement) return;
      if (!sessionCommittedRef.current) {
        commitHistory();
        sessionCommittedRef.current = true;
      }
      updateElement(activeElement.id, patch as never, false);
    },
    [activeElement, commitHistory, updateElement]
  );

  const applyStyle = useCallback(
    (patch: { fontFamily?: string; fontSize?: number; color?: string }) => {
      if (!activeElement) return;
      mutateElement(patch as Partial<TextElement>);
      const current = useWhiteboard.getState().style;
      const next: Partial<StyleState> = {};
      if (activeElement.type === "text") {
        if (patch.fontFamily) next.fontFamily = patch.fontFamily;
        Object.assign(next, setToolInk(current, "text", { color: patch.color, size: patch.fontSize }));
      } else if (patch.fontSize !== undefined) {
        Object.assign(next, setToolInk(current, "sticky", { size: patch.fontSize }));
      }
      if (Object.keys(next).length > 0) setStyle(next);
    },
    [activeElement, mutateElement, setStyle]
  );

  const adjustHeight = useCallback(() => {
    const ta = textareaRef.current;
    if (!ta || !activeElement) return;
    ta.style.height = "auto";
    const newHeight = Math.max(ta.scrollHeight / camera.zoom, 40);
    if ("height" in activeElement && typeof activeElement.height === "number" && Math.abs(activeElement.height - newHeight) > 4) {
      mutateElement({ height: newHeight } as Partial<TextElement>);
    }
  }, [activeElement, camera.zoom, mutateElement]);

  useLayoutEffect(() => {
    const bar = barRef.current;
    if (!bar) return;
    const measure = () => setBarSize({ width: bar.offsetWidth, height: bar.offsetHeight });
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(bar);
    return () => ro.disconnect();
  }, [editingId]);

  // Where a dictated phrase goes. The controller is created once and outlives
  // the box it was started in, so its callback must not close over
  // `activeElement`: it did, and dictating into a second box wrote that box's
  // whole text into the FIRST one, replacing what was there. This ref always
  // points at the box being edited right now.
  // Where the last dictated chunk landed. A cumulative re-send from the
  // engine ("how" -> "how to") revises this range in place instead of
  // appending a second copy. Any manual typing clears it (see
  // handleTextChange), and a moved cursor makes the splice fall back to an
  // append — so user edits are never eaten by a late revision.
  const lastDictationRef = useRef<DictationRange | null>(null);
  // The words being heard right now, already written into the text so they
  // appear AS you speak (they used to wait, hidden in a small pill, until the
  // whole phrase was final). Each interim replaces this range; the final
  // replaces it for good.
  const interimRangeRef = useRef<DictationRange | null>(null);

  /** Writes dictated text without grabbing focus. */
  const applyDictatedText = (ta: HTMLTextAreaElement, next: string, cursor: number) => {
    setText(next);
    mutateElement({ text: next });
    // Focusing on every phrase popped the tablet keyboard up again and again
    // while you were talking. The caret moves; focus stays where it is.
    const hadFocus = typeof document !== "undefined" && document.activeElement === ta;
    requestAnimationFrame(() => {
      if (hadFocus) ta.focus({ preventScroll: true });
      ta.setSelectionRange(cursor, cursor);
      adjustHeight();
    });
  };

  const showInterimRef = useRef<(interim: string) => void>(() => {});
  showInterimRef.current = (interim: string) => {
    setInterimText(interim);
    const ta = textareaRef.current;
    if (!ta || !activeElement) return;
    const prev = interimRangeRef.current;
    if (!prev && !interim.trim()) return;
    const out = placeInterim(ta.value, ta.selectionStart, ta.selectionEnd, prev, interim);
    interimRangeRef.current = out.range;
    applyDictatedText(ta, out.text, out.cursor);
  };

  const insertDictationRef = useRef<(chunk: string, opts?: { revisesPrevious: boolean }) => void>(() => {});
  insertDictationRef.current = (finalChunk: string, opts?: { revisesPrevious: boolean }) => {
    setInterimText("");
    const ta = textareaRef.current;
    if (!ta || !activeElement) return;
    const { value, selStart, selEnd } = stripInterim(ta.value, ta.selectionStart, ta.selectionEnd, interimRangeRef.current);
    interimRangeRef.current = null;
    const out = spliceDictationChunk(
      value,
      selStart,
      selEnd,
      finalChunk,
      lastDictationRef.current,
      opts?.revisesPrevious ?? false
    );
    lastDictationRef.current = out.range;
    applyDictatedText(ta, out.text, out.cursor);
  };

  // Voice Dictation Toggle
  const toggleDictation = useCallback(async () => {
    if (dictationDismissTimer.current) {
      clearTimeout(dictationDismissTimer.current);
      dictationDismissTimer.current = null;
    }

    if (dictating) {
      dictationRef.current?.stop();
      setDictating(false);
      setInterimText("");
      setSpeechStatus("idle");
    } else {
      setDictationMessage(null);
      if (!dictationRef.current) {
        dictationRef.current = new VoiceDictationController({
          lang: useWhiteboard.getState().dictationLang,
          onInterim: (interim) => showInterimRef.current(interim),
          onFinal: (finalChunk, opts) => insertDictationRef.current(finalChunk, opts),
          onError: (err) => {
            console.warn("Speech dictation note:", err);
            setDictationMessage(err);
            if (dictationDismissTimer.current) clearTimeout(dictationDismissTimer.current);
            dictationDismissTimer.current = setTimeout(() => {
              setDictationMessage(null);
            }, 8000);
          },
          onStatusChange: (status) => {
            setSpeechStatus(status);
            if (status === "idle" || status === "error" || status === "unsupported") {
              setDictating(false);
              setInterimText("");
              if (status === "unsupported" && dictationRef.current) {
                const errMsg = dictationRef.current.getErrorMessage();
                if (errMsg) {
                  setDictationMessage(errMsg);
                  if (dictationDismissTimer.current) clearTimeout(dictationDismissTimer.current);
                  dictationDismissTimer.current = setTimeout(() => {
                    setDictationMessage(null);
                  }, 8000);
                }
              }
            } else if (status === "listening" || status === "requesting-permission") {
              setDictating(true);
              setDictationMessage(null);
            }
          },
        });
      }

      setDictating(true);
      setSpeechStatus("requesting-permission");
      const started = await dictationRef.current.start();
      if (!started) {
        setDictating(false);
        const errMsg = dictationRef.current.getErrorMessage();
        if (errMsg) {
          setDictationMessage(errMsg);
          if (dictationDismissTimer.current) clearTimeout(dictationDismissTimer.current);
          dictationDismissTimer.current = setTimeout(() => {
            setDictationMessage(null);
          }, 8000);
        }
      }
    }
  }, [dictating]);

  // WikiLink matches
  const matchingBoards = useMemo(() => {
    if (wikiQuery === null) return [];
    const q = wikiQuery.toLowerCase();
    return boards.filter((b) => b.id !== activeBoardId && b.name.toLowerCase().includes(q)).slice(0, 5);
  }, [wikiQuery, boards, activeBoardId]);

  // Typing & WikiLink detection
  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const newText = e.target.value;
    // Manual typing invalidates the dictation revision anchor: a late
    // cumulative final must append now, never rewrite what was just typed.
    lastDictationRef.current = null;
    interimRangeRef.current = null;
    setSelRange({ start: e.target.selectionStart || 0, end: e.target.selectionEnd || 0 });
    setText(newText);
    const pos = e.target.selectionStart || 0;

    const textBeforeCursor = newText.slice(0, pos);
    const lastOpen = textBeforeCursor.lastIndexOf("[[");
    const lastClose = textBeforeCursor.lastIndexOf("]]");

    if (lastOpen !== -1 && lastOpen > lastClose) {
      const query = textBeforeCursor.slice(lastOpen + 2);
      if (!query.includes("\n") && query.length < 30) {
        setWikiQuery(query);
        setWikiCursorPos(lastOpen);
        setSelectedWikiIndex(0);
      } else {
        setWikiQuery(null);
      }
    } else {
      setWikiQuery(null);
    }

    if (activeElement) {
      // Deleted lines must not leave direction overrides pointing past them.
      const dirs = (activeElement as TextElement).lineDirs;
      const lineCount = newText.split("\n").length;
      const patch: Partial<TextElement> = { text: newText };
      if (dirs && dirs.length > lineCount) {
        const trimmed = dirs.slice(0, lineCount);
        while (trimmed.length > 0 && trimmed[trimmed.length - 1] === "auto") trimmed.pop();
        patch.lineDirs = trimmed;
      }
      mutateElement(patch);
      adjustHeight();
    }
  };

  const insertWikiLink = (boardName: string) => {
    // The LIVE textarea value, not React state: state can lag the last
    // keystroke, and slicing a stale string at a live cursor offset mangles
    // the line when typing fast and hitting Enter immediately.
    const ta = textareaRef.current;
    if (!ta || wikiQuery === null) return;
    const live = ta.value;
    const afterPos = ta.selectionStart || live.length;
    const before = live.slice(0, wikiCursorPos);
    const after = live.slice(afterPos);
    const replacement = `[[${boardName}]] `;
    const updated = before + replacement + after;
    setText(updated);
    setWikiQuery(null);
    if (activeElement) mutateElement({ text: updated });

    requestAnimationFrame(() => {
      if (textareaRef.current) {
        textareaRef.current.focus();
        const newPos = before.length + replacement.length;
        textareaRef.current.setSelectionRange(newPos, newPos);
        adjustHeight();
      }
    });
  };

  // Formatting actions
  const applyFormat = (prefix: string, suffix = "") => {
    const ta = textareaRef.current;
    if (!ta || !activeElement) return;
    const start = ta.selectionStart;
    const end = ta.selectionEnd;
    // Empty markers with the cursor parked between them (see
    // spliceFormatMarkers): no placeholder word to delete first.
    const { updated, cursor } = spliceFormatMarkers(text, start, end, prefix, suffix);
    setText(updated);
    mutateElement({ text: updated });

    requestAnimationFrame(() => {
      ta.focus();
      ta.setSelectionRange(cursor, cursor);
      adjustHeight();
    });
  };

  // Line prefix formatting (e.g. #, ##, - [ ], - ): every line the selection
  // touches (see prefixSelectedLines), so multi-line selections format whole.
  const applyLinePrefix = (prefix: string) => {
    const ta = textareaRef.current;
    if (!ta || !activeElement) return;
    const { updated, cursor } = prefixSelectedLines(text, ta.selectionStart, ta.selectionEnd, prefix);
    setText(updated);
    mutateElement({ text: updated });

    requestAnimationFrame(() => {
      ta.focus();
      ta.setSelectionRange(cursor, cursor);
      adjustHeight();
    });
  };

  // Case transforms
  const transformCase = (mode: "upper" | "lower" | "title" | "clean") => {
    const ta = textareaRef.current;
    if (!ta || !activeElement) return;
    const start = ta.selectionStart;
    const end = ta.selectionEnd;
    const isSelection = start !== end;
    const target = isSelection ? text.slice(start, end) : text;

    let transformed = target;
    if (mode === "upper") {
      transformed = target.toUpperCase();
    } else if (mode === "lower") {
      transformed = target.toLowerCase();
    } else if (mode === "title") {
      transformed = target.replace(/\b\w+/g, (txt) => txt.charAt(0).toUpperCase() + txt.slice(1).toLowerCase());
    } else if (mode === "clean") {
      transformed = target.replace(/[ \t]+/g, " ").replace(/\n{3,}/g, "\n\n").trim();
    }

    const updated = isSelection
      ? text.slice(0, start) + transformed + text.slice(end)
      : transformed;

    setText(updated);
    mutateElement({ text: updated });

    requestAnimationFrame(() => {
      ta.focus();
      if (isSelection) {
        ta.setSelectionRange(start, start + transformed.length);
      }
      adjustHeight();
    });
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    // A word still being composed (the underlined word on Samsung / Gboard,
    // or an IME candidate) belongs to the keyboard. Rewriting the text here
    // from React state - which has not seen that word yet - deleted it.
    if (e.nativeEvent.isComposing) return;

    // 1. WikiLink Autocomplete navigation
    if (wikiQuery !== null && matchingBoards.length > 0) {
      if (e.key === "ArrowDown") {
        e.preventDefault();
        setSelectedWikiIndex((i) => (i + 1) % matchingBoards.length);
        return;
      }
      if (e.key === "ArrowUp") {
        e.preventDefault();
        setSelectedWikiIndex((i) => (i - 1 + matchingBoards.length) % matchingBoards.length);
        return;
      }
      if (e.key === "Enter" || e.key === "Tab") {
        e.preventDefault();
        // The list can shrink under a stale highlight; fall back to first.
        const pick = matchingBoards[selectedWikiIndex] ?? matchingBoards[0];
        if (pick) insertWikiLink(pick.name);
        return;
      }
      if (e.key === "Escape") {
        e.preventDefault();
        setWikiQuery(null);
        return;
      }
    }

    // 2. Intelligent List Continuation on Enter
    if (e.key === "Enter" && !e.shiftKey) {
      const ta = textareaRef.current;
      if (ta) {
        // The textarea, not React state: state can lag the last keystroke.
        const text = ta.value;
        const pos = ta.selectionStart;
        const textBefore = text.slice(0, pos);
        const lastNewline = textBefore.lastIndexOf("\n");
        const currentLine = textBefore.slice(lastNewline + 1);

        const { prefix, shouldExit } = getNextLinePrefix(currentLine);

        if (shouldExit) {
          // Erase empty prefix and leave clean empty line
          e.preventDefault();
          const lineStart = lastNewline + 1;
          const updated = text.slice(0, lineStart) + text.slice(pos);
          setText(updated);
          mutateElement({ text: updated });
          requestAnimationFrame(() => {
            ta.focus();
            ta.setSelectionRange(lineStart, lineStart);
            adjustHeight();
          });
          return;
        }

        if (prefix) {
          // Continue checklist, bullet, or numbered item
          e.preventDefault();
          const textAfter = text.slice(pos);
          const insertion = `\n${prefix}`;
          const updated = textBefore + insertion + textAfter;
          setText(updated);
          mutateElement({ text: updated });
          requestAnimationFrame(() => {
            ta.focus();
            const newPos = pos + insertion.length;
            ta.setSelectionRange(newPos, newPos);
            adjustHeight();
          });
          return;
        }
      }
    }

    // 3. Tab Indent / Shift+Tab Outdent
    if (e.key === "Tab") {
      e.preventDefault();
      const ta = textareaRef.current;
      if (ta) {
        const start = ta.selectionStart;
        const end = ta.selectionEnd;
        if (e.shiftKey) {
          const textBefore = text.slice(0, start);
          const lastNewline = textBefore.lastIndexOf("\n");
          const lineStart = lastNewline + 1;
          if (text.slice(lineStart, lineStart + 2) === "  ") {
            const updated = text.slice(0, lineStart) + text.slice(lineStart + 2);
            setText(updated);
            mutateElement({ text: updated });
            requestAnimationFrame(() => {
              ta.setSelectionRange(Math.max(lineStart, start - 2), Math.max(lineStart, end - 2));
            });
          }
        } else {
          const updated = text.slice(0, start) + "  " + text.slice(end);
          setText(updated);
          mutateElement({ text: updated });
          requestAnimationFrame(() => {
            ta.setSelectionRange(start + 2, start + 2);
          });
        }
        return;
      }
    }

    // 4. Keyboard Shortcuts
    if (e.ctrlKey || e.metaKey) {
      if (e.shiftKey && e.code === "KeyR") {
        e.preventDefault();
        e.stopPropagation();
        toggleDictation();
        return;
      }
      if (e.shiftKey && e.code === "KeyL") {
        e.preventDefault();
        e.stopPropagation();
        applyLinePrefix("- [ ] ");
        return;
      }
      if (e.shiftKey && e.code === "KeyM") {
        e.preventDefault();
        e.stopPropagation();
        applyFormat("$", "$");
        return;
      }
      if (e.shiftKey && (e.code === "KeyX" || e.code === "KeyS")) {
        e.preventDefault();
        e.stopPropagation();
        applyFormat("~~", "~~");
        return;
      }
      if (e.code === "KeyB") {
        e.preventDefault();
        e.stopPropagation();
        applyFormat("**", "**");
        return;
      }
      if (e.code === "KeyI") {
        e.preventDefault();
        e.stopPropagation();
        applyFormat("*", "*");
        return;
      }
      if (e.code === "KeyU") {
        e.preventDefault();
        e.stopPropagation();
        applyFormat("<u>", "</u>");
        return;
      }
      if (e.code === "KeyK") {
        e.preventDefault();
        e.stopPropagation();
        applyFormat("[[", "]]");
        return;
      }
    }

    if (e.key === "Escape") {
      exitEditing();
    }
  };

  const returnFocus = (e: Event) => {
    e.preventDefault();
    textareaRef.current?.focus({ preventScroll: true });
  };

  if (!activeElement || (activeElement.type !== "text" && activeElement.type !== "sticky")) {
    return null;
  }

  const isSticky = activeElement.type === "sticky";
  const textEl = activeElement as TextElement;
  const stickyEl = activeElement as StickyElement;
  const fontSize = isSticky ? stickyEl.fontSize : textEl.fontSize;
  const align = (isSticky ? stickyEl.align : textEl.align) || "left";
  // Per-line writing direction: the override on the cursor's line, if any,
  // else what auto-detection reads from that line's own words.
  const lineDirs = (isSticky ? stickyEl.lineDirs : textEl.lineDirs) ?? [];
  const cursorLine = selectedLineRange(text, selRange.start, selRange.end).first;
  const cursorLineDir = resolveLineDir(lineDirs, cursorLine);
  const cursorLineText = text.split("\n")[cursorLine] ?? "";
  const effectiveLineDir = cursorLineDir === "auto" ? detectLineDir(cursorLineText) : cursorLineDir;
  const applyLineDir = (dir: LineDir) => {
    const next = setLineDirs(lineDirs, text, selRange.start, selRange.end, dir);
    mutateElement({ lineDirs: next.length > 0 ? next : undefined });
  };
  const opacity = activeElement.opacity ?? 1;
  const id = activeElement.id;

  // Card mode state
  const isCard = !isSticky && !!(textEl.cardMode || (textEl.backgroundColor && textEl.backgroundColor !== "transparent"));

  // Word & character stats
  const wordCount = text.trim() ? text.trim().split(/\s+/).length : 0;
  const charCount = text.length;

  // Screen coordinates
  const screenPos = worldToScreen(activeElement.x, activeElement.y, camera, viewport);
  const screenWidth = activeElement.width * camera.zoom;
  const screenHeight = Math.max(activeElement.height * camera.zoom, 40);
  const stickyStyle = isSticky ? STICKY_COLORS[stickyEl.color] : null;

  // Bar placement
  const barW = Math.min(barSize.width || 0, viewport.width - EDGE * 2);
  const barLeft = Math.max(EDGE, Math.min(screenPos.x, viewport.width - barW - EDGE));
  const above = screenPos.y - barSize.height - GAP;
  const below = screenPos.y + screenHeight + GAP;
  const barTop =
    above >= EDGE
      ? above
      : below + barSize.height <= viewport.height - EDGE
      ? below
      : EDGE;

  const iconBtn =
    "flex h-8 min-w-8 shrink-0 items-center justify-center rounded-lg px-1.5 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground";
  const divider = <span className="mx-0.5 h-5 w-px shrink-0 bg-border/70" aria-hidden />;

  return (
    <TooltipProvider delayDuration={250}>
      {/* 1. Main Floating Formatting Bar */}
      <div
        ref={barRef}
        data-wb-text-bar
        className="absolute z-50 flex items-center gap-0.5 overflow-x-auto rounded-2xl border border-border/80 bg-white/95 p-1 text-xs text-foreground shadow-2xl backdrop-blur-xl select-none dark:bg-zinc-900/95"
        style={{ left: barLeft, top: barTop, maxWidth: viewport.width - EDGE * 2 }}
        onMouseDown={(e) => e.preventDefault()}
        onPointerDown={(e) => e.stopPropagation()}
      >
        {/* Font family */}
        {!isSticky && (
          <Popover>
            <PopoverTrigger asChild>
              <button className={cn(iconBtn, "gap-1 px-2 font-medium text-foreground")} title="Font family">
                <span className="max-w-[70px] truncate">
                  {FONT_FAMILIES.find((f) => f.value === textEl.fontFamily)?.label.split(" ")[0] || "Font"}
                </span>
                <ChevronDown size={11} className="opacity-60" />
              </button>
            </PopoverTrigger>
            <PopoverContent className="w-48 p-1 text-xs" align="start" onCloseAutoFocus={returnFocus}>
              {FONT_FAMILIES.map((ff) => (
                <button
                  key={ff.id}
                  onClick={() => applyStyle({ fontFamily: ff.value })}
                  className="flex w-full items-center justify-between rounded px-2.5 py-1.5 text-left hover:bg-muted"
                  style={{ fontFamily: ff.value }}
                >
                  <span>{ff.label}</span>
                  {textEl.fontFamily === ff.value && <Check size={12} className="text-primary" />}
                </button>
              ))}
            </PopoverContent>
          </Popover>
        )}

        {/* Font size stepper */}
        <StepButton
          direction={-1}
          value={fontSize}
          min={MIN_FONT}
          max={MAX_FONT}
          onChange={(v) => applyStyle({ fontSize: v })}
          className="h-8 w-7 shrink-0"
        />
        <Popover>
          <PopoverTrigger asChild>
            <button className={cn(iconBtn, "px-1 font-semibold tabular-nums text-foreground")} title="Font size">
              {fontSize}px
            </button>
          </PopoverTrigger>
          <PopoverContent side="top" className="w-56 space-y-2.5 p-3" onCloseAutoFocus={returnFocus}>
            <input
              type="range"
              min={MIN_FONT}
              max={MAX_FONT}
              step={1}
              value={fontSize}
              aria-label="Font size"
              onChange={(e) => applyStyle({ fontSize: Number(e.target.value) })}
              className="h-2 w-full cursor-pointer appearance-none rounded-lg bg-muted accent-primary"
            />
            <div className="grid grid-cols-4 gap-1">
              {SIZE_PRESETS.map((sz) => (
                <button
                  key={sz}
                  onClick={() => applyStyle({ fontSize: sz })}
                  className={cn(
                    "rounded border py-1.5 text-[11px] transition-colors",
                    fontSize === sz
                      ? "border-primary bg-primary font-semibold text-primary-foreground"
                      : "border-border text-muted-foreground hover:bg-muted"
                  )}
                >
                  {sz}
                </button>
              ))}
            </div>
          </PopoverContent>
        </Popover>
        <StepButton
          direction={1}
          value={fontSize}
          min={MIN_FONT}
          max={MAX_FONT}
          onChange={(v) => applyStyle({ fontSize: v })}
          className="h-8 w-7 shrink-0"
        />

        {divider}

        {/* Typography: Bold, Italic, Underline, Strikethrough, Code */}
        <Tooltip>
          <TooltipTrigger asChild>
            <button onClick={() => applyFormat("**", "**")} className={iconBtn} aria-label="Bold (Ctrl+B)">
              <Bold size={14} />
            </button>
          </TooltipTrigger>
          <TooltipContent side="top">Bold (Ctrl+B)</TooltipContent>
        </Tooltip>

        <Tooltip>
          <TooltipTrigger asChild>
            <button onClick={() => applyFormat("*", "*")} className={iconBtn} aria-label="Italic (Ctrl+I)">
              <Italic size={14} />
            </button>
          </TooltipTrigger>
          <TooltipContent side="top">Italic (Ctrl+I)</TooltipContent>
        </Tooltip>

        <Tooltip>
          <TooltipTrigger asChild>
            <button onClick={() => applyFormat("<u>", "</u>")} className={iconBtn} aria-label="Underline (Ctrl+U)">
              <Underline size={14} />
            </button>
          </TooltipTrigger>
          <TooltipContent side="top">Underline (Ctrl+U)</TooltipContent>
        </Tooltip>

        <Tooltip>
          <TooltipTrigger asChild>
            <button onClick={() => applyFormat("~~", "~~")} className={iconBtn} aria-label="Strikethrough">
              <Strikethrough size={14} />
            </button>
          </TooltipTrigger>
          <TooltipContent side="top">Strikethrough</TooltipContent>
        </Tooltip>

        <Tooltip>
          <TooltipTrigger asChild>
            <button onClick={() => applyFormat("`", "`")} className={iconBtn} aria-label="Inline Code">
              <Code size={14} />
            </button>
          </TooltipTrigger>
          <TooltipContent side="top">Inline Code</TooltipContent>
        </Tooltip>

        {divider}

        {/* Headings Popover */}
        <Popover>
          <PopoverTrigger asChild>
            <button className={cn(iconBtn, "gap-0.5 px-1.5")} title="Heading Style">
              <Heading1 size={14} />
              <ChevronDown size={10} className="opacity-60" />
            </button>
          </PopoverTrigger>
          <PopoverContent className="w-40 p-1 text-xs" align="start" onCloseAutoFocus={returnFocus}>
            <button
              onClick={() => applyLinePrefix("# ")}
              className="flex w-full items-center gap-2 rounded px-2 py-1.5 hover:bg-muted font-bold text-base"
            >
              <Heading1 size={16} /> Heading 1
            </button>
            <button
              onClick={() => applyLinePrefix("## ")}
              className="flex w-full items-center gap-2 rounded px-2 py-1.5 hover:bg-muted font-semibold text-sm"
            >
              <Heading2 size={15} /> Heading 2
            </button>
            <button
              onClick={() => applyLinePrefix("### ")}
              className="flex w-full items-center gap-2 rounded px-2 py-1.5 hover:bg-muted font-medium text-xs"
            >
              <Heading3 size={14} /> Heading 3
            </button>
          </PopoverContent>
        </Popover>

        {/* Lists & Tasks Popover */}
        <Popover>
          <PopoverTrigger asChild>
            <button className={cn(iconBtn, "gap-0.5 px-1.5")} title="Lists & Tasks">
              <CheckSquare size={14} />
              <ChevronDown size={10} className="opacity-60" />
            </button>
          </PopoverTrigger>
          <PopoverContent className="w-44 p-1 text-xs" align="start" onCloseAutoFocus={returnFocus}>
            <button
              onClick={() => applyLinePrefix("- [ ] ")}
              className="flex w-full items-center gap-2 rounded px-2 py-1.5 hover:bg-muted"
            >
              <CheckSquare size={14} className="text-primary" /> Task Checklist
            </button>
            <button
              onClick={() => applyLinePrefix("- ")}
              className="flex w-full items-center gap-2 rounded px-2 py-1.5 hover:bg-muted"
            >
              <List size={14} /> Bullet List
            </button>
            <button
              onClick={() => applyLinePrefix("1. ")}
              className="flex w-full items-center gap-2 rounded px-2 py-1.5 hover:bg-muted"
            >
              <ListOrdered size={14} /> Numbered List
            </button>
            <button
              onClick={() => applyLinePrefix("> ")}
              className="flex w-full items-center gap-2 rounded px-2 py-1.5 hover:bg-muted"
            >
              <Quote size={14} /> Blockquote
            </button>
          </PopoverContent>
        </Popover>

        {divider}

        {/* SMART TOOLS: Voice Dictation (Record to Text), WikiLink, LaTeX Math */}
        <Popover>
          <PopoverTrigger asChild>
            <button
              className={cn(iconBtn, "gap-0.5 px-1.5 font-semibold")}
              title="Dictation language"
              aria-label={`Dictation language: ${dictationLang}`}
            >
              <Languages size={14} />
              <span className="text-[10px] leading-none">{dictationLang.split("-")[0]?.toUpperCase() ?? "EN"}</span>
              <ChevronDown size={10} className="opacity-60" />
            </button>
          </PopoverTrigger>
          <PopoverContent className="w-44 p-1 text-xs" align="start" onCloseAutoFocus={returnFocus}>
            <div className="px-2 py-1 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
              Dictation language
            </div>
            {SUPPORTED_DICTATION_LANGS.map((l) => {
              const active = resolveDictationLang(dictationLang) === l.id;
              return (
                <button
                  key={l.id}
                  onClick={() => pickDictationLang(l.id)}
                  className={cn(
                    "flex w-full items-center gap-2 rounded px-2 py-1.5 hover:bg-muted",
                    active && "font-semibold text-primary"
                  )}
                  aria-pressed={active}
                >
                  <span className="flex-1 text-left">{l.label}</span>
                  {active && <Check size={12} />}
                </button>
              );
            })}
          </PopoverContent>
        </Popover>

        <Tooltip>
          <TooltipTrigger asChild>
            <button
              onClick={toggleDictation}
              className={cn(
                "flex h-8 shrink-0 items-center justify-center rounded-lg px-2 transition-all font-medium text-xs gap-1",
                dictating
                  ? "bg-red-500 text-white shadow-md animate-pulse hover:bg-red-600"
                  : "text-muted-foreground hover:bg-muted hover:text-foreground"
              )}
              aria-label={dictating ? "Stop Voice Dictation" : "Record to Text (Voice Dictation)"}
            >
              {dictating ? (
                speechStatus === "requesting-permission" ? (
                  <Loader2 size={14} className="animate-spin" />
                ) : (
                  <MicOff size={14} className="animate-pulse" />
                )
              ) : (
                <Mic size={14} />
              )}
              <span className="hidden sm:inline">
                {dictating
                  ? speechStatus === "requesting-permission"
                    ? "Allow Mic…"
                    : "Listening…"
                  : "Dictate"}
              </span>
            </button>
          </TooltipTrigger>
          <TooltipContent side="top">
            {dictating
              ? speechStatus === "requesting-permission"
                ? "Requesting microphone permission…"
                : "Listening — Click to stop (Ctrl+Shift+R)"
              : "Record to Text — Speak into note (Ctrl+Shift+R)"}
          </TooltipContent>
        </Tooltip>

        <Tooltip>
          <TooltipTrigger asChild>
            <button
              onClick={() => applyFormat("[[", "]]")}
              className={cn(iconBtn, "text-primary hover:text-primary")}
              aria-label="Insert [[WikiLink]] (Ctrl+K)"
            >
              <Link2 size={14} />
            </button>
          </TooltipTrigger>
          <TooltipContent side="top">Insert [[WikiLink]] (Ctrl+K)</TooltipContent>
        </Tooltip>

        <Tooltip>
          <TooltipTrigger asChild>
            <button
              onClick={() => applyFormat("$", "$")}
              className={iconBtn}
              aria-label="LaTeX Math Formula"
            >
              <span className="font-serif italic font-semibold text-xs">fx</span>
            </button>
          </TooltipTrigger>
          <TooltipContent side="top">LaTeX Math ($...$)</TooltipContent>
        </Tooltip>

        {/* Card Mode & Styling */}
        {!isSticky && (
          <Popover>
            <PopoverTrigger asChild>
              <button
                className={cn(
                  iconBtn,
                  "gap-0.5 px-1.5",
                  isCard && "bg-primary/10 text-primary font-medium"
                )}
                title="Card box styling & background"
              >
                <Square size={14} />
                <ChevronDown size={10} className="opacity-60" />
              </button>
            </PopoverTrigger>
            <PopoverContent className="w-56 space-y-3 p-3 text-xs" align="center" onCloseAutoFocus={returnFocus}>
              <div className="flex items-center justify-between">
                <span className="font-medium text-foreground">Card Box Mode</span>
                <button
                  onClick={() => {
                    const nextMode = !isCard;
                    mutateElement({
                      cardMode: nextMode,
                      backgroundColor: nextMode ? textEl.backgroundColor || "#ffffff" : "transparent",
                      borderColor: nextMode ? textEl.borderColor || "#e2e8f0" : "transparent",
                      borderRadius: nextMode ? textEl.borderRadius || 8 : 0,
                      padding: nextMode ? textEl.padding || 12 : 4,
                    });
                  }}
                  className={cn(
                    "h-5 w-9 rounded-full transition-colors relative",
                    isCard ? "bg-primary" : "bg-muted"
                  )}
                >
                  <span
                    className={cn(
                      "absolute top-0.5 h-4 w-4 rounded-full bg-white transition-transform shadow-sm",
                      isCard ? "right-0.5" : "left-0.5"
                    )}
                  />
                </button>
              </div>

              {isCard && (
                <>
                  <div className="space-y-1.5">
                    <span className="text-[10px] font-semibold text-muted-foreground uppercase">Card Theme</span>
                    <div className="grid grid-cols-4 gap-1.5">
                      {CARD_BACKGROUNDS.filter((c) => c.id !== "transparent").map((c) => (
                        <button
                          key={c.id}
                          onClick={() => {
                            mutateElement({
                              backgroundColor: c.bg,
                              borderColor: c.border,
                            });
                          }}
                          className={cn(
                            "h-7 rounded-md border text-[10px] font-medium flex items-center justify-center transition-all",
                            textEl.backgroundColor === c.bg
                              ? "ring-2 ring-primary ring-offset-1 border-primary"
                              : "border-border hover:opacity-90"
                          )}
                          style={{ backgroundColor: c.bg, color: c.id === "dark" ? "#ffffff" : "#1e293b" }}
                          title={c.label}
                        >
                          {c.label.split(" ")[0]}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-1">
                    <span className="text-[10px] font-semibold text-muted-foreground uppercase">Corners</span>
                    <div className="flex gap-1.5">
                      {[
                        { label: "Sharp", radius: 2 },
                        { label: "Smooth", radius: 8 },
                        { label: "Rounded", radius: 14 },
                      ].map((r) => (
                        <button
                          key={r.label}
                          onClick={() => mutateElement({ borderRadius: r.radius })}
                          className={cn(
                            "flex-1 rounded border py-1 text-[10px] transition-colors",
                            (textEl.borderRadius || 8) === r.radius
                              ? "bg-primary text-primary-foreground border-primary"
                              : "border-border hover:bg-muted"
                          )}
                        >
                          {r.label}
                        </button>
                      ))}
                    </div>
                  </div>
                </>
              )}
            </PopoverContent>
          </Popover>
        )}

        {divider}

        {/* Alignment */}
        {(["left", "center", "right"] as TextAlign[]).map((a) => (
          <button
            key={a}
            onClick={() => mutateElement({ align: a })}
            className={cn(iconBtn, align === a && "bg-muted text-primary")}
            title={`Align ${a}`}
            aria-label={`Align ${a}`}
          >
            {a === "left" && <AlignLeft size={14} />}
            {a === "center" && <AlignCenter size={14} />}
            {a === "right" && <AlignRight size={14} />}
          </button>
        ))}

        {/* Line direction: one line RTL Hebrew, the next LTR English */}
        {(["rtl", "auto", "ltr"] as LineDir[]).map((d) => (
          <button
            key={d}
            onClick={() => applyLineDir(d)}
            className={cn(iconBtn, "px-2 text-[11px] font-semibold", cursorLineDir === d && "bg-muted text-primary")}
            title={
              d === "auto"
                ? `Direction: auto (this line reads ${effectiveLineDir.toUpperCase()})`
                : `Force this line ${d.toUpperCase()}`
            }
            aria-label={d === "auto" ? "Line direction auto" : `Force line ${d.toUpperCase()}`}
            aria-pressed={cursorLineDir === d}
          >
            {d === "auto" ? "Auto" : d.toUpperCase()}
          </button>
        ))}

        {divider}

        {/* Text Color & Opacity */}
        <Popover>
          <PopoverTrigger asChild>
            <button className={cn(iconBtn, "gap-1")} title="Text colour and opacity">
              <span
                className="h-4 w-4 rounded-full border border-black/15 shadow-sm dark:border-white/20"
                style={{ backgroundColor: isSticky ? stickyStyle?.bg : textEl.color, opacity }}
              />
              <ChevronDown size={10} className="opacity-60" />
            </button>
          </PopoverTrigger>
          <PopoverContent className="w-60 space-y-3 p-3" onCloseAutoFocus={returnFocus}>
            <div className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider">
              {isSticky ? "Note Colour" : "Ink Colour"}
            </div>
            <div className="grid grid-cols-6 gap-2">
              {isSticky
                ? Object.entries(STICKY_COLORS).map(([key, c]) => (
                    <button
                      key={key}
                      onClick={() => mutateElement({ color: key as StickyColor })}
                      title={c.label}
                      className={cn(
                        "h-7 w-7 rounded-full border",
                        stickyEl.color === key ? "ring-2 ring-primary ring-offset-1" : "border-border"
                      )}
                      style={{ backgroundColor: c.bg }}
                    />
                  ))
                : PEN_COLORS.map((c) => (
                    <button
                      key={c}
                      onClick={() => applyStyle({ color: c })}
                      title={c}
                      className={cn(
                        "h-7 w-7 rounded-full border border-black/10 transition-transform hover:scale-105",
                        textEl.color?.toLowerCase() === c.toLowerCase() && "ring-2 ring-primary ring-offset-1"
                      )}
                      style={{ backgroundColor: c }}
                    />
                  ))}
            </div>

            {!isSticky && (
              <label className="flex items-center justify-between gap-2 text-[11px] text-muted-foreground">
                Custom colour
                <input
                  type="color"
                  value={/^#[0-9a-f]{6}$/i.test(textEl.color || "") ? textEl.color : "#1e293b"}
                  onChange={(e) => applyStyle({ color: e.target.value })}
                  className="h-6 w-9 cursor-pointer rounded border border-border bg-transparent"
                />
              </label>
            )}

            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-[11px] text-muted-foreground">
                <span>Opacity</span>
                <span className="tabular-nums font-semibold text-foreground">{Math.round(opacity * 100)}%</span>
              </div>
              <input
                type="range"
                min={10}
                max={100}
                step={5}
                value={Math.round(opacity * 100)}
                aria-label="Opacity"
                onChange={(e) => mutateElement({ opacity: Number(e.target.value) / 100 })}
                className="h-2 w-full cursor-pointer appearance-none rounded-lg bg-muted accent-primary"
              />
            </div>
          </PopoverContent>
        </Popover>

        {/* More Actions Popover: Transforms, Arrange, Lock, Delete */}
        <Popover>
          <PopoverTrigger asChild>
            <button className={iconBtn} title="More actions">
              <MoreHorizontal size={15} />
            </button>
          </PopoverTrigger>
          <PopoverContent className="w-52 p-1.5 text-xs space-y-1" align="end" onCloseAutoFocus={returnFocus}>
            <div className="px-2 py-1 text-[10px] font-semibold text-muted-foreground uppercase">Case & Clean</div>
            <div className="grid grid-cols-3 gap-1 px-1">
              <button
                onClick={() => transformCase("upper")}
                className="rounded border py-1 text-[10px] hover:bg-muted"
                title="Convert to UPPERCASE"
              >
                UPPER
              </button>
              <button
                onClick={() => transformCase("lower")}
                className="rounded border py-1 text-[10px] hover:bg-muted"
                title="Convert to lowercase"
              >
                lower
              </button>
              <button
                onClick={() => transformCase("title")}
                className="rounded border py-1 text-[10px] hover:bg-muted"
                title="Convert to Title Case"
              >
                Title
              </button>
            </div>
            <button
              onClick={() => transformCase("clean")}
              className="flex w-full items-center gap-2 rounded px-2.5 py-1.5 hover:bg-muted text-[11px]"
            >
              <Sparkles size={13} className="text-primary" /> Clean extra spaces
            </button>

            <div className="my-1 border-t border-border" />
            <div className="px-2 py-0.5 text-[10px] font-semibold text-muted-foreground uppercase">Layering</div>
            <button
              className="flex w-full items-center gap-2 rounded px-2.5 py-1.5 hover:bg-muted text-[11px]"
              onClick={() => bringToFront([id])}
            >
              <ArrowUpToLine size={13} /> Bring to front
            </button>
            <button
              className="flex w-full items-center gap-2 rounded px-2.5 py-1.5 hover:bg-muted text-[11px]"
              onClick={() => sendToBack([id])}
            >
              <ArrowDownToLine size={13} /> Send to back
            </button>
            <button
              className="flex w-full items-center gap-2 rounded px-2.5 py-1.5 hover:bg-muted text-[11px]"
              onClick={() => {
                const [copy] = duplicateElements([id]);
                if (copy) setEditingId(copy);
              }}
            >
              <Copy size={13} /> Duplicate
            </button>
            <button
              className="flex w-full items-center gap-2 rounded px-2.5 py-1.5 hover:bg-muted text-[11px]"
              onClick={() => {
                toggleLock([id]);
                exitEditing();
              }}
            >
              <Lock size={13} /> Lock
            </button>
            <div className="my-1 border-t border-border" />
            <button
              className="flex w-full items-center gap-2 rounded px-2.5 py-1.5 text-red-600 hover:bg-red-500/10 dark:text-red-400 text-[11px]"
              onClick={() => {
                deleteElements([id]);
                exitEditing();
              }}
            >
              <Trash2 size={13} /> Delete
            </button>

            <div className="mt-1 border-t border-border pt-1 px-2 text-[10px] text-muted-foreground flex justify-between">
              <span>{wordCount} words</span>
              <span>{charCount} chars</span>
            </div>
          </PopoverContent>
        </Popover>

        {/* Done Button */}
        <button
          onClick={exitEditing}
          className="ml-1 h-8 shrink-0 rounded-xl bg-primary px-3 text-xs font-semibold text-primary-foreground shadow-sm transition-opacity hover:opacity-90 active:scale-95"
        >
          Done
        </button>
      </div>

      {/* 2. Live Dictation Floating Waveform / Status Banner */}
      {dictating && speechStatus === "requesting-permission" && (
        <div
          className="absolute z-50 flex items-center gap-2 px-3 py-1.5 bg-amber-500/15 border border-amber-500/40 text-amber-700 dark:text-amber-300 rounded-full text-xs font-medium shadow-lg backdrop-blur-md animate-in fade-in slide-in-from-top-1 select-none"
          style={{
            left: barLeft,
            top: Math.max(EDGE, barTop - 36),
          }}
        >
          <Loader2 size={13} className="animate-spin text-amber-600 dark:text-amber-400" />
          <span>Requesting microphone permission…</span>
        </div>
      )}

      {dictating && speechStatus === "listening" && (
        <div
          className="absolute z-50 flex items-center gap-2.5 px-3 py-1.5 bg-red-500/15 border border-red-500/40 text-red-600 rounded-full text-xs font-medium shadow-lg backdrop-blur-md animate-in fade-in slide-in-from-top-1 select-none dark:text-red-400"
          style={{
            left: barLeft,
            top: Math.max(EDGE, barTop - 36),
          }}
        >
          <span className="relative flex h-2.5 w-2.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75" />
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-red-500" />
          </span>
          <span className="max-w-[240px] sm:max-w-md truncate">
            {interimText ? "Hearing you…" : "Listening… speak into note"}
          </span>
          <button
            onClick={() => {
              dictationRef.current?.stop();
              setDictating(false);
              setInterimText("");
              setSpeechStatus("idle");
            }}
            className="ml-1 rounded-full bg-red-500/20 px-2 py-0.5 text-[10px] font-semibold hover:bg-red-500/30 transition-colors"
          >
            Stop
          </button>
        </div>
      )}

      {!dictating && dictationMessage && (
        <div
          className="absolute z-50 flex items-center gap-2 px-3 py-2 bg-amber-500/15 border border-amber-500/40 text-amber-800 dark:text-amber-200 rounded-2xl text-xs shadow-xl backdrop-blur-md animate-in fade-in slide-in-from-top-1 max-w-sm sm:max-w-md"
          style={{
            left: barLeft,
            top: Math.max(EDGE, barTop - 42),
          }}
        >
          <AlertCircle size={14} className="shrink-0 text-amber-600 dark:text-amber-400" />
          <span className="flex-1 text-[11px] leading-snug">{dictationMessage}</span>
          <button
            onClick={() => setDictationMessage(null)}
            className="shrink-0 rounded p-1 hover:bg-amber-500/20 text-muted-foreground hover:text-foreground"
            aria-label="Dismiss notice"
          >
            <X size={12} />
          </button>
        </div>
      )}

      {/* 3. The Text Box Area */}
      <div
        ref={boxRef}
        className="absolute pointer-events-auto z-40"
        style={{
          left: `${screenPos.x}px`,
          top: `${screenPos.y}px`,
          width: `${screenWidth}px`,
          transformOrigin: "top left",
          transform: activeElement.rotation ? `rotate(${(activeElement.rotation * 180) / Math.PI}deg)` : undefined,
        }}
        onMouseDown={(e) => e.stopPropagation()}
        onPointerDown={(e) => e.stopPropagation()}
        onClick={(e) => e.stopPropagation()}
      >
        <textarea
          ref={textareaRef}
          value={text}
          // dir=auto: each line follows its own first strong character, so
          // Hebrew and English lines share one box while editing too.
          dir="auto"
          onChange={handleTextChange}
          onSelect={(e) => {
            const t = e.target as HTMLTextAreaElement;
            setSelRange({ start: t.selectionStart || 0, end: t.selectionEnd || 0 });
          }}
          onKeyDown={handleKeyDown}
          placeholder={
            isSticky
              ? "Write a sticky note…"
              : "Type your thoughts… (use [[WikiLinks]], - [ ] tasks, or tap Dictate to speak)"
          }
          style={{
            width: "100%",
            minHeight: `${screenHeight}px`,
            backgroundColor: isSticky
              ? stickyStyle?.bg
              : isCard
              ? textEl.backgroundColor || "#ffffff"
              : "transparent",
            color: isSticky ? stickyStyle?.text : textEl.color || "#1e293b",
            opacity,
            border: isSticky
              ? `2px solid ${stickyStyle?.border}`
              : isCard
              ? `2px solid ${textEl.borderColor || "#e2e8f0"}`
              : "2px dashed #6366f1",
            borderRadius: isSticky ? "8px" : isCard ? `${textEl.borderRadius || 8}px` : "4px",
            padding: isSticky
              ? `${14 * camera.zoom}px`
              : isCard
              ? `${(textEl.padding || 12) * camera.zoom}px`
              : `${4 * camera.zoom}px ${8 * camera.zoom}px`,
            fontSize: `${fontSize * camera.zoom}px`,
            fontFamily: isSticky
              ? "Inter, system-ui, sans-serif"
              : textEl.fontFamily || "Inter, system-ui, sans-serif",
            fontWeight: isSticky ? 400 : textEl.fontWeight || 400,
            textAlign: align,
            lineHeight: textEl.lineHeight || 1.45,
            outline: "none",
            resize: "none",
            overflow: "hidden",
            boxShadow: isSticky
              ? "0 4px 16px rgba(0,0,0,0.12)"
              : isCard
              ? "0 4px 20px rgba(0,0,0,0.12)"
              : "0 0 0 4px rgba(99,102,241,0.15)",
            touchAction: "manipulation",
            boxSizing: "border-box",
          }}
        />

        {/* Live [[WikiLink]] autocomplete: stays visible while the query has
            no match yet, so typing never looks dead — it narrows with every
            character instead of blinking out. */}
        {wikiQuery !== null && (
          <div className="absolute left-0 top-full z-50 mt-1.5 w-64 rounded-xl border border-border bg-white/98 p-1 shadow-2xl backdrop-blur-md animate-in fade-in zoom-in-95 dark:bg-zinc-900/98">
            <div className="px-2 py-1 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
              Link to Board
            </div>
            {matchingBoards.length > 0 ? (
              matchingBoards.map((b, idx) => (
                <button
                  key={b.id}
                  onClick={() => insertWikiLink(b.name)}
                  className={cn(
                    "flex w-full items-center justify-between rounded-lg px-2.5 py-1.5 text-left text-xs transition-colors",
                    idx === selectedWikiIndex
                      ? "bg-primary font-medium text-primary-foreground"
                      : "text-foreground hover:bg-muted"
                  )}
                >
                  <span className="truncate">{b.name}</span>
                  <span className="text-[10px] opacity-70">[[{b.name}]]</span>
                </button>
              ))
            ) : (
              <div className="px-2.5 py-1.5 text-xs text-muted-foreground">
                No boards match “{wikiQuery}” — keep typing
              </div>
            )}
          </div>
        )}
      </div>
    </TooltipProvider>
  );
}
