"use client";

/**
 * Image editor ("studio").
 *
 * Opens over the page for ONE picture: from its action bar, by double-tapping
 * it, or on its own after a fresh camera photo. Three tabs:
 *   Crop  — drag the frame or its handles; fixed ratios; turn and mirror.
 *   Look  — Original, Document (cleans up photos of pages), Gray, Vivid,
 *           Faded (pale, for writing on top).
 *   Shape — square, rounded or circle, with an optional border.
 *
 * Nothing is applied until Done, and Done is ONE undo step. Every edit is a
 * description on the element (lib/whiteboard/imageEdit.ts): the photo itself
 * is never re-encoded, so Reset can always bring back the whole original.
 */

import React from "react";
import { createPortal } from "react-dom";
import {
  Check,
  Crop,
  FlipHorizontal2,
  FlipVertical2,
  Palette,
  RotateCcw,
  RotateCw,
  Shapes,
  Undo2,
  X,
} from "lucide-react";
import { useWhiteboard, useActiveBoard } from "@/store/whiteboard";
import { getBoardElements } from "@/lib/whiteboard/notebook";
import type { ImageCrop, ImageElement, ImageFilter, ImageFrame } from "@/lib/whiteboard/types";
import {
  FULL_CROP,
  IMAGE_FILTERS,
  IMAGE_FRAMES,
  boxForCrop,
  centeredAspectCrop,
  dragCrop,
  filterCss,
  fitAspect,
  flipCrop,
  isFullCrop,
  naturalSize,
  normalizeCrop,
  quarterTurn,
  type CropHandle,
} from "@/lib/whiteboard/imageEdit";
import { useResolvedImageSrc } from "./ElementRenderer";
import { cn } from "@/lib/utils";

type Tab = "crop" | "look" | "shape";

/** Ratios as the user SEES them (width:height on screen). null = free. */
const RATIOS: Array<{ id: string; label: string; r: number | null | "original" }> = [
  { id: "free", label: "Free", r: null },
  { id: "original", label: "Original", r: "original" },
  { id: "1:1", label: "1:1", r: 1 },
  { id: "4:3", label: "4:3", r: 4 / 3 },
  { id: "3:4", label: "3:4", r: 3 / 4 },
  { id: "16:9", label: "16:9", r: 16 / 9 },
];

const BORDER_COLORS = ["#18181b", "#ffffff", "#6366f1", "#f43f5e", "#f59e0b", "#10b981"];

const HANDLES: Array<{ h: CropHandle; style: React.CSSProperties; cursor: string }> = [
  { h: "nw", style: { left: 0, top: 0 }, cursor: "nwse-resize" },
  { h: "ne", style: { left: "100%", top: 0 }, cursor: "nesw-resize" },
  { h: "sw", style: { left: 0, top: "100%" }, cursor: "nesw-resize" },
  { h: "se", style: { left: "100%", top: "100%" }, cursor: "nwse-resize" },
  { h: "n", style: { left: "50%", top: 0 }, cursor: "ns-resize" },
  { h: "s", style: { left: "50%", top: "100%" }, cursor: "ns-resize" },
  { h: "w", style: { left: 0, top: "50%" }, cursor: "ew-resize" },
  { h: "e", style: { left: "100%", top: "50%" }, cursor: "ew-resize" },
];

export function ImageStudio() {
  const id = useWhiteboard((s) => s.imageStudioId);
  const board = useActiveBoard();
  const el = React.useMemo(() => {
    if (!id || !board) return null;
    const found = getBoardElements(board).find((e) => e.id === id);
    return found && found.type === "image" ? (found as ImageElement) : null;
    // Only the id picks the picture: live edits elsewhere must not reset the draft.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);
  if (!id || !el || typeof document === "undefined") return null;
  // Portalled to <body> so it covers the sidebar and every floating bar.
  return createPortal(<Studio key={id} el={el} />, document.body);
}

function Studio({ el }: { el: ImageElement }) {
  const close = () => useWhiteboard.getState().setImageStudioId(null);
  const href = useResolvedImageSrc(el.src);
  const { nw, nh } = naturalSize(el);

  const [tab, setTab] = React.useState<Tab>("crop");
  const [crop, setCrop] = React.useState<ImageCrop>(normalizeCrop(el.crop));
  const [flipX, setFlipX] = React.useState(!!el.flipX);
  const [flipY, setFlipY] = React.useState(!!el.flipY);
  const [turns, setTurns] = React.useState(0); // extra quarter turns, clockwise
  const [ratio, setRatio] = React.useState<string>("free");
  const [filter, setFilter] = React.useState<ImageFilter>(el.filter ?? "none");
  const [frame, setFrame] = React.useState<ImageFrame>(el.frame ?? "square");
  const [borderWidth, setBorderWidth] = React.useState(el.borderWidth ?? 0);
  const [borderColor, setBorderColor] = React.useState(el.borderColor ?? "#18181b");

  // ---- stage size -------------------------------------------------------
  const stageRef = React.useRef<HTMLDivElement>(null);
  const [stage, setStage] = React.useState({ w: 600, h: 400 });
  React.useLayoutEffect(() => {
    const node = stageRef.current;
    if (!node) return;
    const measure = () => setStage({ w: node.clientWidth, h: node.clientHeight });
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(node);
    return () => ro.disconnect();
  }, []);

  const odd = turns % 2 === 1;
  // The picture fits the stage AS TURNED: a sideways photo swaps its sides.
  const pad = 28;
  const fit = Math.min((stage.w - pad * 2) / (odd ? nh : nw), (stage.h - pad * 2) / (odd ? nw : nh));
  const dispW = Math.max(40, nw * fit);
  const dispH = Math.max(40, nh * fit);

  /** A screen ratio as a crop-fraction ratio (1 = the picture's own shape). */
  const fractionAspect = React.useCallback(
    (id: string): number | null => {
      const r = RATIOS.find((x) => x.id === id)?.r ?? null;
      if (r === null) return null;
      if (r === "original") return 1;
      const px = odd ? 1 / r : r; // on screen w:h is picture h:w when turned sideways
      return (px * nh) / nw;
    },
    [odd, nw, nh]
  );

  const pickRatio = (id: string) => {
    setRatio(id);
    const a = fractionAspect(id);
    if (a) setCrop((c) => (isFullCrop(c) ? centeredAspectCrop(a) : fitAspect(c, a)));
  };

  // ---- dragging the crop -------------------------------------------------
  const drag = React.useRef<{ handle: CropHandle; x: number; y: number; start: ImageCrop; pid: number } | null>(null);
  const onHandleDown = (handle: CropHandle) => (e: React.PointerEvent) => {
    e.preventDefault();
    e.stopPropagation();
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    drag.current = { handle, x: e.clientX, y: e.clientY, start: crop, pid: e.pointerId };
  };
  const onMove = (e: React.PointerEvent) => {
    const d = drag.current;
    if (!d || d.pid !== e.pointerId) return;
    // Screen movement -> picture movement: undo the stage's quarter turns.
    const sx = e.clientX - d.x;
    const sy = e.clientY - d.y;
    const t = (-turns * Math.PI) / 2;
    const cx = sx * Math.cos(t) - sy * Math.sin(t);
    const cy = sx * Math.sin(t) + sy * Math.cos(t);
    setCrop(dragCrop(d.start, d.handle, cx / dispW, cy / dispH, fractionAspect(ratio)));
  };
  const onUp = (e: React.PointerEvent) => {
    if (drag.current?.pid === e.pointerId) drag.current = null;
  };

  const doFlip = (axis: "x" | "y") => {
    if (axis === "x") setFlipX((v) => !v);
    else setFlipY((v) => !v);
    setCrop((c) => flipCrop(c, axis));
  };
  const turn = (dir: 1 | -1) => setTurns((t) => (t + dir + 4) % 4);

  const reset = () => {
    setCrop({ ...FULL_CROP });
    setFlipX(false);
    setFlipY(false);
    setTurns(0);
    setRatio("free");
    setFilter("none");
    setFrame("square");
    setBorderWidth(0);
  };

  const apply = () => {
    const store = useWhiteboard.getState();
    const c = normalizeCrop(crop);
    const box = boxForCrop(el, c);
    let rotation = el.rotation || 0;
    for (let i = 0; i < turns; i++) rotation = quarterTurn(rotation, 1);
    store.commitHistory();
    store.updateElement(
      el.id,
      {
        ...box,
        rotation,
        crop: isFullCrop(c) ? undefined : c,
        flipX: flipX || undefined,
        flipY: flipY || undefined,
        filter: filter === "none" ? undefined : filter,
        frame: frame === "square" ? undefined : frame,
        borderWidth: borderWidth || undefined,
        borderColor: borderWidth ? borderColor : undefined,
      } as Partial<ImageElement>,
      false
    );
    close();
  };

  React.useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.stopPropagation();
        close();
      } else if (e.key === "Enter") {
        e.preventDefault();
        apply();
      }
    };
    window.addEventListener("keydown", onKey, true);
    return () => window.removeEventListener("keydown", onKey, true);
  });

  const css = filterCss(filter);
  const flipCss = `scale(${flipX ? -1 : 1}, ${flipY ? -1 : 1})`;
  const cropStyle: React.CSSProperties = {
    left: crop.x * dispW,
    top: crop.y * dispH,
    width: crop.w * dispW,
    height: crop.h * dispH,
    borderRadius: frame === "circle" ? "50%" : frame === "rounded" ? Math.min(crop.w * dispW, crop.h * dispH) * 0.08 : 0,
    boxShadow: "0 0 0 9999px rgba(9, 9, 11, 0.62)",
    outline: borderWidth && tab === "shape" ? `${Math.max(1, borderWidth * fit)}px solid ${borderColor}` : undefined,
  };

  const TABS: Array<{ id: Tab; label: string; icon: typeof Crop }> = [
    { id: "crop", label: "Crop", icon: Crop },
    { id: "look", label: "Look", icon: Palette },
    { id: "shape", label: "Shape", icon: Shapes },
  ];

  return (
    <div
      className="fixed inset-0 z-[80] flex flex-col bg-zinc-950/95 text-zinc-100 backdrop-blur-md animate-in fade-in"
      onPointerMove={onMove}
      onPointerUp={onUp}
      onPointerCancel={onUp}
      role="dialog"
      aria-label="Edit picture"
    >
      {/* Top bar */}
      <div className="flex items-center justify-between gap-2 px-3 py-2.5 sm:px-5">
        <button onClick={close} className="flex items-center gap-1.5 rounded-full px-3 py-1.5 text-sm text-zinc-300 hover:bg-white/10">
          <X size={16} /> Cancel
        </button>
        <div className="text-sm font-semibold tracking-wide">Edit picture</div>
        <button
          onClick={apply}
          className="flex items-center gap-1.5 rounded-full bg-indigo-500 px-4 py-1.5 text-sm font-semibold text-white shadow-lg shadow-indigo-500/30 hover:bg-indigo-400"
        >
          <Check size={16} /> Done
        </button>
      </div>

      {/* Stage */}
      <div ref={stageRef} className="relative min-h-0 flex-1 overflow-hidden">
        <div
          className="absolute left-1/2 top-1/2 transition-transform duration-200"
          style={{ width: dispW, height: dispH, transform: `translate(-50%, -50%) rotate(${turns * 90}deg)` }}
        >
          <div className="absolute inset-0 overflow-hidden">
            {href ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={href}
                alt=""
                draggable={false}
                className="h-full w-full select-none"
                style={{ transform: flipCss, filter: css || undefined }}
              />
            ) : (
              <div className="h-full w-full animate-pulse bg-zinc-800" />
            )}
          </div>
          {/* The kept area; everything outside is dimmed by its shadow. */}
          <div
            className={cn("absolute touch-none", tab === "crop" ? "cursor-move" : "pointer-events-none")}
            style={cropStyle}
            onPointerDown={tab === "crop" ? onHandleDown("move") : undefined}
          >
            {tab === "crop" && (
              <>
                {/* thirds grid */}
                <div className="pointer-events-none absolute inset-0 border border-white/90">
                  <div className="absolute inset-y-0 left-1/3 w-px bg-white/35" />
                  <div className="absolute inset-y-0 left-2/3 w-px bg-white/35" />
                  <div className="absolute inset-x-0 top-1/3 h-px bg-white/35" />
                  <div className="absolute inset-x-0 top-2/3 h-px bg-white/35" />
                </div>
                {HANDLES.map(({ h, style, cursor }) => (
                  <div
                    key={h}
                    onPointerDown={onHandleDown(h)}
                    className="absolute flex h-9 w-9 -translate-x-1/2 -translate-y-1/2 items-center justify-center touch-none"
                    style={{ ...style, cursor }}
                  >
                    <span
                      className={cn(
                        "block rounded-full bg-white shadow-[0_0_0_1.5px_rgba(99,102,241,0.9)]",
                        h.length === 2 ? "h-3.5 w-3.5" : h === "n" || h === "s" ? "h-1.5 w-6" : "h-6 w-1.5"
                      )}
                    />
                  </div>
                ))}
              </>
            )}
          </div>
        </div>
      </div>

      {/* Tools */}
      <div className="border-t border-white/10 bg-zinc-900/80 px-3 pb-4 pt-3 sm:px-5">
        <div className="mx-auto max-w-xl">
          {tab === "crop" && (
            <div className="flex flex-col gap-3">
              <div className="flex gap-1.5 overflow-x-auto pb-0.5">
                {RATIOS.map((r) => (
                  <Chip key={r.id} active={ratio === r.id} onClick={() => pickRatio(r.id)}>
                    {r.label}
                  </Chip>
                ))}
              </div>
              <div className="flex items-center justify-center gap-1">
                <IconBtn label="Turn left" onClick={() => turn(-1)} icon={RotateCcw} />
                <IconBtn label="Turn right" onClick={() => turn(1)} icon={RotateCw} />
                <span className="mx-2 h-6 w-px bg-white/15" />
                <IconBtn label="Mirror" onClick={() => doFlip("x")} icon={FlipHorizontal2} active={flipX} />
                <IconBtn label="Upside down" onClick={() => doFlip("y")} icon={FlipVertical2} active={flipY} />
                <span className="mx-2 h-6 w-px bg-white/15" />
                <IconBtn label="Reset all" onClick={reset} icon={Undo2} />
              </div>
            </div>
          )}

          {tab === "look" && (
            <div className="flex gap-2.5 overflow-x-auto pb-1">
              {IMAGE_FILTERS.map((f) => (
                <button
                  key={f.id}
                  onClick={() => setFilter(f.id)}
                  title={f.hint}
                  className="flex w-[72px] shrink-0 flex-col items-center gap-1.5"
                >
                  <span
                    className={cn(
                      "block h-16 w-16 overflow-hidden rounded-2xl ring-2 transition",
                      filter === f.id ? "ring-indigo-400" : "ring-transparent hover:ring-white/30"
                    )}
                  >
                    {href && (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={href} alt="" className="h-full w-full object-cover" style={{ filter: f.css || undefined, transform: flipCss }} draggable={false} />
                    )}
                  </span>
                  <span className={cn("text-[11px]", filter === f.id ? "font-semibold text-white" : "text-zinc-400")}>{f.label}</span>
                </button>
              ))}
            </div>
          )}

          {tab === "shape" && (
            <div className="flex flex-col gap-3">
              <div className="flex justify-center gap-2">
                {IMAGE_FRAMES.map((f) => (
                  <button
                    key={f.id}
                    onClick={() => setFrame(f.id)}
                    className={cn(
                      "flex w-20 flex-col items-center gap-1.5 rounded-2xl py-2 transition",
                      frame === f.id ? "bg-indigo-500/20 text-white" : "text-zinc-400 hover:bg-white/5"
                    )}
                  >
                    <span
                      className={cn(
                        "block h-8 w-8 border-2",
                        frame === f.id ? "border-indigo-300" : "border-zinc-500",
                        f.id === "circle" ? "rounded-full" : f.id === "rounded" ? "rounded-lg" : "rounded-none"
                      )}
                    />
                    <span className="text-[11px]">{f.label}</span>
                  </button>
                ))}
              </div>
              <div className="flex flex-wrap items-center justify-center gap-2">
                <span className="text-[11px] text-zinc-400">Border</span>
                {[0, 2, 5].map((w) => (
                  <Chip key={w} active={borderWidth === w} onClick={() => setBorderWidth(w)}>
                    {w === 0 ? "None" : w === 2 ? "Thin" : "Thick"}
                  </Chip>
                ))}
                {borderWidth > 0 &&
                  BORDER_COLORS.map((c) => (
                    <button
                      key={c}
                      onClick={() => setBorderColor(c)}
                      aria-label={`Border colour ${c}`}
                      className={cn("h-6 w-6 rounded-full border border-white/25", borderColor === c && "ring-2 ring-indigo-400 ring-offset-2 ring-offset-zinc-900")}
                      style={{ background: c }}
                    />
                  ))}
              </div>
            </div>
          )}

          <div className="mx-auto mt-3 grid max-w-xs grid-cols-3 gap-1 rounded-2xl bg-white/5 p-1">
            {TABS.map(({ id, label, icon: Icon }) => (
              <button
                key={id}
                onClick={() => setTab(id)}
                className={cn(
                  "flex items-center justify-center gap-1.5 rounded-xl py-2 text-[13px] font-medium transition",
                  tab === id ? "bg-white text-zinc-900 shadow" : "text-zinc-400 hover:text-white"
                )}
              >
                <Icon size={15} /> {label}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function Chip({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "shrink-0 rounded-full px-3.5 py-1.5 text-[12px] font-medium transition",
        active ? "bg-white text-zinc-900" : "bg-white/8 text-zinc-300 hover:bg-white/15"
      )}
    >
      {children}
    </button>
  );
}

function IconBtn({
  label,
  onClick,
  icon: Icon,
  active,
}: {
  label: string;
  onClick: () => void;
  icon: typeof Crop;
  active?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      title={label}
      aria-label={label}
      className={cn(
        "flex h-10 w-10 items-center justify-center rounded-full transition",
        active ? "bg-indigo-500/25 text-indigo-200" : "text-zinc-300 hover:bg-white/10"
      )}
    >
      <Icon size={18} />
    </button>
  );
}
