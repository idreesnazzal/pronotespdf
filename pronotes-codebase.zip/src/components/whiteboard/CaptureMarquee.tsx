"use client";

/**
 * What the canvas shows while you draw a capture area. Screen space: it is
 * drawn outside the zoomed world group so its lines stay one crisp width.
 *
 * The look is a VIEWFINDER, the capture feature's own motif (the panel's
 * preview wears the same corner brackets): everything outside the area dims,
 * the area stays at full brightness with a thin indigo edge, and a small
 * readout gives its size in page units - the size it will have if you drop
 * it into a notebook.
 */

import React from "react";
import { worldToScreen, type Viewport } from "@/lib/whiteboard/geometry";
import { rectFromCorners, type CaptureShape } from "@/lib/whiteboard/capture";

const ACCENT = "#6366f1";

/** A corner bracket's two arms, as one path, for each corner of a box. */
function bracketsPath(x: number, y: number, w: number, h: number, arm: number): string {
  const a = Math.max(4, Math.min(arm, w / 3, h / 3));
  return [
    `M ${x} ${y + a} V ${y} H ${x + a}`,
    `M ${x + w - a} ${y} H ${x + w} V ${y + a}`,
    `M ${x + w} ${y + h - a} V ${y + h} H ${x + w - a}`,
    `M ${x + a} ${y + h} H ${x} V ${y + h - a}`,
  ].join(" ");
}

export function CaptureMarquee({
  shape,
  points,
  camera,
  viewport,
}: {
  shape: CaptureShape;
  /** World points: a box's two corners, or a loop's trail. */
  points: Array<{ x: number; y: number }>;
  camera: { x: number; y: number; zoom: number };
  viewport: Viewport;
}) {
  if (points.length < 2) return null;
  const sp = points.map((p) => worldToScreen(p.x, p.y, camera, viewport));
  const W = viewport.width;
  const H = viewport.height;

  let area: string;
  let box: { x: number; y: number; width: number; height: number };
  if (shape === "rectangle") {
    box = rectFromCorners(sp[0], sp[sp.length - 1]);
    area = `M ${box.x} ${box.y} h ${box.width} v ${box.height} h ${-box.width} Z`;
  } else {
    area = `M ${sp.map((p) => `${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join(" L ")} Z`;
    const xs = sp.map((p) => p.x);
    const ys = sp.map((p) => p.y);
    box = {
      x: Math.min(...xs),
      y: Math.min(...ys),
      width: Math.max(...xs) - Math.min(...xs),
      height: Math.max(...ys) - Math.min(...ys),
    };
  }

  const z = Math.max(camera.zoom, 0.01);
  const label = `${Math.round(box.width / z)} × ${Math.round(box.height / z)}`;
  const labelW = label.length * 6.6 + 18;
  const labelX = Math.min(Math.max(box.x + box.width - labelW, 6), W - labelW - 6);
  const below = box.y + box.height + 8;
  const labelY = below + 22 < H - 6 ? below : Math.max(6, box.y - 30);

  return (
    <g pointerEvents="none">
      {/* Dim everything outside the area: evenodd cuts the area out. */}
      <path d={`M 0 0 H ${W} V ${H} H 0 Z ${area}`} fillRule="evenodd" fill="rgba(9, 9, 11, 0.36)" />
      {/* A white under-stroke keeps the edge visible on dark ink and dark paper. */}
      <path d={area} fill="none" stroke="#ffffff" strokeOpacity={0.9} strokeWidth={3} strokeLinejoin="round" />
      <path
        d={area}
        fill="none"
        stroke={ACCENT}
        strokeWidth={1.5}
        strokeLinejoin="round"
        strokeDasharray={shape === "lasso" ? "6 4" : undefined}
      />
      {shape === "rectangle" && box.width > 8 && box.height > 8 && (
        <>
          <path
            d={bracketsPath(box.x - 2, box.y - 2, box.width + 4, box.height + 4, 18)}
            fill="none"
            stroke="#ffffff"
            strokeWidth={5.5}
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <path
            d={bracketsPath(box.x - 2, box.y - 2, box.width + 4, box.height + 4, 18)}
            fill="none"
            stroke={ACCENT}
            strokeWidth={3}
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </>
      )}
      <g transform={`translate(${labelX}, ${labelY})`}>
        <rect width={labelW} height={22} rx={11} fill="rgba(24, 24, 27, 0.88)" />
        <text
          x={labelW / 2}
          y={15}
          textAnchor="middle"
          fontSize={11.5}
          fontWeight={600}
          fill="#ffffff"
          style={{ fontVariantNumeric: "tabular-nums" }}
        >
          {label}
        </text>
      </g>
    </g>
  );
}
