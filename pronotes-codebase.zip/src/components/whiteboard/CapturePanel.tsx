"use client";

/**
 * The capture panel: what happens to the picture you just drew around.
 * =====================================================================
 * One screen, three questions, in the order people ask them:
 *
 *   1. IS THIS RIGHT?  A large live preview, on a checkerboard wherever the
 *      picture is transparent, framed by the same viewfinder corners the
 *      canvas drew while you dragged - so the picture reads as "the thing I
 *      just caught" rather than a file.
 *   2. HOW SHOULD IT LOOK?  Background (the page as you saw it / clean white /
 *      none) and sharpness (1x-3x, starting at what the screen showed). Every
 *      change re-renders the preview; nothing is applied blind.
 *   3. WHERE DOES IT GO?  Out of the app (Copy, Share, Save) or into your notes
 *      (this page, a new page, another notebook). Two groups because they are
 *      two different intents - sending something away and keeping it.
 *
 * Compared with the apps this was modelled on: Samsung's smart select has
 * Copy / Share / Add to note but no look controls; GoodNotes' lasso screenshot
 * is copy-and-share only; Excalidraw's export has background and scale but
 * nowhere to put the result. This keeps all three and adds nothing else.
 *
 * Honesty rules, as in ExportModal: every outcome is reported as what it was.
 * A copy the Android clipboard refused says so (and is still pasteable inside
 * ProNotes); a dismissed share sheet is not called a failure; a picture or PDF
 * page that could not be loaded is named, not silently left blank.
 */

import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useTheme } from "next-themes";
import {
  ArrowLeft,
  BookOpen,
  Check,
  ChevronRight,
  Copy,
  Download,
  FilePlus2,
  Images as GalleryIcon,
  ImagePlus,
  LayoutGrid,
  Loader2,
  NotebookPen,
  Scan,
  Search,
  Share2,
  X,
} from "lucide-react";
import { useWhiteboard } from "@/store/whiteboard";
import { useCapture, type CaptureRequest } from "@/store/capture";
import {
  CAPTURE_SCALES,
  captureFilename,
  capturePixelSize,
  collectLiveText,
  defaultCaptureScale,
  renderCapture,
  resolveCaptureAssets,
  type CaptureAssets,
  type CaptureBackground,
  type CaptureScale,
  type CaptureSource,
} from "@/lib/whiteboard/capture";
import { blobToDataUrl, isNativeApp, shareBlob, canChooseApp } from "@/lib/whiteboard/share";
import { GALLERY_ALBUM, saveImageToGallery } from "@/lib/whiteboard/gallery";
import type { ExportReport } from "@/lib/whiteboard/export";
import { putAppClipImage, writeImageToSystemClipboard } from "@/lib/whiteboard/appClipboard";
import { storeImage } from "@/lib/whiteboard/imagestore";
import { getActivePageIndex, getPages, isNotebook } from "@/lib/whiteboard/notebook";
import { toast } from "@/hooks/use-toast";
import { ToastAction } from "@/components/ui/toast";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import { cn } from "@/lib/utils";

const BG_KEY = "pronotes:captureBackground";

const BACKGROUNDS: Array<{ id: CaptureBackground; label: string; hint: string }> = [
  { id: "page", label: "Page", hint: "As you see it: paper, ruling and the PDF page." },
  { id: "white", label: "White", hint: "Clean white behind it. Ruling and paper colour left out; PDF pages stay." },
  { id: "transparent", label: "None", hint: "Only your ink and objects, on transparency." },
];

function readBackground(): CaptureBackground {
  try {
    const v = localStorage.getItem(BG_KEY);
    if (v === "page" || v === "white" || v === "transparent") return v;
  } catch {
    /* a remembered preference is a convenience, never a requirement */
  }
  return "page";
}

function formatBytes(n: number): string {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${Math.round(n / 1024)} KB`;
  return `${(n / (1024 * 1024)).toFixed(1)} MB`;
}

/** A sentence naming what the picture had to leave out, or null. */
function describeMissing(r: ExportReport): string | null {
  const parts: string[] = [];
  if (r.missingImages > 0) {
    parts.push(`${r.missingImages} picture${r.missingImages === 1 ? " is" : "s are"} missing from this device and shown as grey`);
  }
  if (r.missingPdfPages > 0) {
    parts.push(`${r.missingPdfPages} PDF page${r.missingPdfPages === 1 ? "" : "s"} could not be loaded`);
  }
  return parts.length ? `${parts.join("; ")}.` : null;
}

interface Rendered {
  url: string;
  blob: Blob;
  width: number;
  height: number;
  report: ExportReport;
}

/** The little background swatch drawn inside each Background option. */
function Swatch({ kind }: { kind: CaptureBackground }) {
  if (kind === "transparent") {
    return <span className="pn-checker h-3.5 w-3.5 rounded-[4px] border border-black/10 dark:border-white/15" />;
  }
  if (kind === "white") {
    return <span className="h-3.5 w-3.5 rounded-[4px] border border-black/15 bg-white" />;
  }
  return (
    <span className="relative h-3.5 w-3.5 overflow-hidden rounded-[4px] border border-black/15 bg-[#fdfaf3]">
      <span className="absolute inset-x-0 top-[4px] h-px bg-sky-300" />
      <span className="absolute inset-x-0 top-[8px] h-px bg-sky-300" />
    </span>
  );
}

/** A labelled row of mutually exclusive choices. */
function Segmented<T extends string | number>({
  label,
  value,
  options,
  onChange,
}: {
  label: string;
  value: T;
  options: Array<{ id: T; label: React.ReactNode; title?: string }>;
  onChange: (v: T) => void;
}) {
  return (
    <div>
      <div className="mb-1 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">{label}</div>
      <div role="radiogroup" aria-label={label} className="flex rounded-xl bg-muted/70 p-0.5 dark:bg-zinc-800/70">
        {options.map((o) => {
          const on = o.id === value;
          return (
            <button
              key={String(o.id)}
              type="button"
              role="radio"
              aria-checked={on}
              title={o.title}
              onClick={() => onChange(o.id)}
              className={cn(
                "flex h-8 flex-1 items-center justify-center gap-1.5 rounded-[10px] text-[12px] font-medium transition-all",
                on
                  ? "bg-white text-foreground shadow-sm ring-1 ring-black/5 dark:bg-zinc-600 dark:ring-white/10"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              {o.label}
            </button>
          );
        })}
      </div>
    </div>
  );
}

/** One "send it out" button: icon over label, a finger-sized target. */
function SendTile({
  icon: Icon,
  label,
  onClick,
  busy,
  done,
  primary,
  disabled,
}: {
  icon: typeof Copy;
  label: string;
  onClick: () => void;
  busy?: boolean;
  done?: boolean;
  primary?: boolean;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      className={cn(
        "flex h-[62px] flex-col items-center justify-center gap-1 rounded-2xl text-[12px] font-semibold transition active:scale-[0.97] disabled:opacity-50 disabled:active:scale-100",
        primary
          ? "bg-gradient-to-br from-indigo-500 to-violet-500 text-white shadow-md shadow-indigo-500/25 hover:from-indigo-400 hover:to-violet-400"
          : "border border-border bg-white text-foreground hover:border-indigo-300 hover:bg-indigo-50/60 dark:bg-zinc-800/60 dark:hover:border-indigo-400/50 dark:hover:bg-zinc-800"
      )}
    >
      {busy ? <Loader2 size={19} className="animate-spin" /> : done ? <Check size={19} /> : <Icon size={19} />}
      {label}
    </button>
  );
}

/** One "keep it in my notes" row. */
function AddRow({
  icon: Icon,
  title,
  hint,
  onClick,
  disabled,
  chevron,
}: {
  icon: typeof Copy;
  title: string;
  hint: string;
  onClick: () => void;
  disabled?: boolean;
  chevron?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      className="group flex w-full items-center gap-3 rounded-xl px-2.5 py-2 text-left transition hover:bg-muted/80 disabled:opacity-50 dark:hover:bg-zinc-800"
    >
      <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-indigo-500/10 text-indigo-600 transition group-hover:bg-indigo-500/15 dark:text-indigo-300">
        <Icon size={16} />
      </span>
      <span className="min-w-0 flex-1">
        <span className="block truncate text-[13px] font-medium leading-tight">{title}</span>
        <span className="block truncate text-[11px] leading-tight text-muted-foreground">{hint}</span>
      </span>
      {chevron && <ChevronRight size={15} className="shrink-0 text-muted-foreground" />}
    </button>
  );
}

/** The viewfinder corners that frame the preview (the canvas marquee's motif). */
function Corners() {
  const c = "pointer-events-none absolute h-4 w-4 border-indigo-500";
  return (
    <>
      <span className={cn(c, "-left-2 -top-2 rounded-tl-md border-l-[3px] border-t-[3px]")} />
      <span className={cn(c, "-right-2 -top-2 rounded-tr-md border-r-[3px] border-t-[3px]")} />
      <span className={cn(c, "-bottom-2 -right-2 rounded-br-md border-b-[3px] border-r-[3px]")} />
      <span className={cn(c, "-bottom-2 -left-2 rounded-bl-md border-b-[3px] border-l-[3px]")} />
    </>
  );
}

export function CapturePanel() {
  const request = useCapture((s) => s.request);
  const close = useCapture((s) => s.close);
  // Keyed by the request so every capture starts from a clean slate.
  return (
    <Dialog open={!!request} onOpenChange={(o) => !o && close()}>
      {request && <CaptureDialogBody key={request.source.region.x + ":" + request.source.region.y} request={request} onClose={close} />}
    </Dialog>
  );
}

function CaptureDialogBody({ request, onClose }: { request: CaptureRequest; onClose: () => void }) {
  const { resolvedTheme } = useTheme();
  const dark = resolvedTheme === "dark";
  const customLinkTypes = useWhiteboard((s) => s.customLinkTypes);
  const boards = useWhiteboard((s) => s.boards);
  const board = request.source.board;
  const notebook = isNotebook(board);

  const [background, setBackground] = useState<CaptureBackground>("page");
  const [scale, setScale] = useState<CaptureScale>(() => defaultCaptureScale(request.zoom, request.dpr));
  const [onlySelection, setOnlySelection] = useState(false);
  const [rendered, setRendered] = useState<Rendered | null>(null);
  const [rendering, setRendering] = useState(true);
  const [renderError, setRenderError] = useState<string | null>(null);
  const [busy, setBusy] = useState<null | "copy" | "share" | "save" | "add">(null);
  const [copied, setCopied] = useState(false);
  const [view, setView] = useState<"main" | "pick">("main");
  const [query, setQuery] = useState("");

  useEffect(() => setBackground(readBackground()), []);
  const chooseBackground = (b: CaptureBackground) => {
    setBackground(b);
    try {
      localStorage.setItem(BG_KEY, b);
    } catch {
      /* a remembered preference is a convenience, never a requirement */
    }
  };

  const source: CaptureSource = useMemo(
    () => ({
      ...request.source,
      onlyIds: onlySelection && request.selectionIds ? request.selectionIds : undefined,
    }),
    [request, onlySelection]
  );

  // The canvas' own text boxes, read once, while the canvas still shows them.
  const liveText = useMemo(() => collectLiveText(request.source), [request.source]);

  // Pictures and PDF pages are fetched once per sharpness; switching the
  // background or the selection filter only re-draws.
  const assetsRef = useRef(new Map<number, Promise<CaptureAssets>>());
  const assetsFor = useCallback(
    (s: number) => {
      let p = assetsRef.current.get(s);
      if (!p) {
        p = resolveCaptureAssets(request.source, s);
        assetsRef.current.set(s, p);
        p.catch(() => assetsRef.current.delete(s));
      }
      return p;
    },
    [request.source]
  );

  // The live preview. A newer setting wins over a render still in flight, and
  // the previous picture stays up (dimmed) until its replacement is ready, so
  // the preview never flashes empty.
  const renderSeq = useRef(0);
  useEffect(() => {
    const seq = ++renderSeq.current;
    setRendering(true);
    setRenderError(null);
    (async () => {
      try {
        const [assets, live] = await Promise.all([assetsFor(scale), liveText]);
        const out = await renderCapture(source, { background, dark }, scale, customLinkTypes, assets, live);
        if (seq !== renderSeq.current) return;
        const url = URL.createObjectURL(out.blob);
        setRendered((prev) => {
          if (prev) URL.revokeObjectURL(prev.url);
          return { url, ...out };
        });
      } catch (err) {
        if (seq !== renderSeq.current) return;
        console.error("[capture] render failed", err);
        setRenderError((err as Error).message || "The picture could not be made.");
      } finally {
        if (seq === renderSeq.current) setRendering(false);
      }
    })();
  }, [source, background, dark, scale, customLinkTypes, assetsFor, liveText]);

  // Free the last preview when the panel goes.
  const lastUrl = useRef<string | null>(null);
  lastUrl.current = rendered?.url ?? null;
  useEffect(() => () => {
    if (lastUrl.current) URL.revokeObjectURL(lastUrl.current);
  }, []);

  // Fit the preview into its stage by measurement: percentage max-heights do
  // not resolve inside a flexible stage, and the corners must hug the image.
  // A callback ref, because the dialog's portal mounts its content a render
  // after this component, so an effect reading a ref would find nothing.
  const [stageEl, stageRef] = useState<HTMLDivElement | null>(null);
  const [stage, setStage] = useState({ width: 0, height: 0 });
  useEffect(() => {
    const el = stageEl;
    if (!el) return;
    const ro = new ResizeObserver(([entry]) => {
      const r = entry.contentRect;
      setStage({ width: r.width, height: r.height });
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, [stageEl]);

  const region = request.source.region;
  const pixel = capturePixelSize(region, scale);
  const fitted = useMemo(() => {
    if (!stage.width || !stage.height) return null;
    const pad = 28;
    const k = Math.min((stage.width - pad * 2) / region.width, (stage.height - pad * 2) / region.height, 4);
    return { width: Math.max(8, region.width * k), height: Math.max(8, region.height * k) };
  }, [stage, region.width, region.height]);

  const filename = useMemo(() => captureFilename(board.name), [board.name]);
  const native = isNativeApp();
  const missing = rendered ? describeMissing(rendered.report) : null;
  const ready = !!rendered && !rendering;
  const pageNo = notebook ? request.source.anchorIndex + 1 : null;

  // ---- Actions --------------------------------------------------------------

  const copy = async () => {
    if (!rendered || busy) return;
    setBusy("copy");
    try {
      // First, while the tap still counts as a user gesture.
      const system = await writeImageToSystemClipboard(rendered.blob);
      const dataUrl = await blobToDataUrl(rendered.blob);
      putAppClipImage({
        dataUrl,
        width: rendered.width,
        height: rendered.height,
        worldSize: { width: region.width, height: region.height },
        systemCopied: system,
      });
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
      toast(
        system
          ? { title: "Copied", description: "Paste it into any app, or back into ProNotes." }
          : {
              title: "Copied inside ProNotes",
              description: native
                ? "Android doesn't let ProNotes put pictures on the system clipboard. Paste it here (Add picture → Paste), or use Share to send it to another app."
                : "This browser blocked the system clipboard. Paste it here with Ctrl+V, or use Save or Share.",
            }
      );
    } finally {
      setBusy(null);
    }
  };

  const share = async () => {
    if (!rendered || busy) return;
    setBusy("share");
    try {
      const outcome = await shareBlob(rendered.blob, filename, board.name);
      if (outcome === "cancelled") {
        toast({ title: "Not sent", description: "The share sheet was closed; the picture went nowhere." });
        return;
      }
      toast(
        outcome === "downloaded"
          ? { title: "Saved instead", description: `No app chooser is available here, so it was saved as ${filename}.` }
          : { title: "Shared", description: filename }
      );
      onClose();
    } catch (err) {
      toast({ title: "That didn't work", description: (err as Error).message, variant: "destructive" });
    } finally {
      setBusy(null);
    }
  };

  const save = async () => {
    if (!rendered || busy) return;
    setBusy("save");
    try {
      const outcome = await saveImageToGallery(rendered.blob, filename);
      if (outcome === "cancelled") {
        toast({ title: "Not saved", description: "The share sheet was closed; the picture was not saved." });
        return;
      }
      toast(
        outcome === "gallery"
          ? { title: "Saved to Gallery", description: `In the ${GALLERY_ALBUM} album.` }
          : outcome === "downloaded"
            ? { title: "Saved", description: `Downloaded as ${filename}.` }
            : {
                title: "Choose where to save it",
                description: "This version of the app can't write to the Gallery directly; pick Save or Gallery in the share sheet.",
              }
      );
      onClose();
    } catch (err) {
      toast({ title: "That didn't work", description: (err as Error).message, variant: "destructive" });
    } finally {
      setBusy(null);
    }
  };

  const size = { width: region.width, height: region.height };

  const addHere = async () => {
    if (!rendered || busy) return;
    setBusy("add");
    try {
      const dataUrl = await blobToDataUrl(rendered.blob);
      onClose();
      // The canvas owns placement (it knows the view and the sheet): centred
      // in view, at the size it was captured, selected, and one Undo away.
      window.dispatchEvent(new CustomEvent("pronotes:insertimage", { detail: { dataUrl, size } }));
      toast({ title: notebook ? "Added to this page" : "Added to this board", description: "It's selected: drag it where you want it." });
    } finally {
      setBusy(null);
    }
  };

  const addTo = async (targetId: string, afterCurrentPage: boolean) => {
    if (!rendered || busy) return;
    setBusy("add");
    try {
      const src = await storeImage(await blobToDataUrl(rendered.blob));
      const st = useWhiteboard.getState();
      const target = st.boards.find((b) => b.id === targetId);
      if (!target) return;
      const res = st.addCaptureToBoard(targetId, {
        src,
        naturalWidth: rendered.width,
        naturalHeight: rendered.height,
        size,
        afterPageId: afterCurrentPage ? target.activePageId : undefined,
      });
      onClose();
      if (!res) return;
      const vpHeight = () => useWhiteboard.getState().canvasViewport.height;
      const open = () => {
        const s = useWhiteboard.getState();
        if (s.activeBoardId !== targetId) s.setActiveBoard(targetId);
        if (res.pageId) {
          const pageId = res.pageId;
          requestAnimationFrame(() => useWhiteboard.getState().goToPage(pageId, vpHeight()));
        }
      };
      if (targetId === st.activeBoardId) {
        open();
        toast({ title: `Added as page ${res.pageNumber}`, description: "Undo takes it back out." });
        return;
      }
      const where = res.pageNumber ? `as page ${res.pageNumber}` : "beside its content";
      const t = toast({
        title: `Added to “${target.name}”`,
        description: `${where[0].toUpperCase()}${where.slice(1)}. To take it out, open it and Undo.`,
        action: (
          <ToastAction
            altText="Open it"
            onClick={() => {
              open();
              t.dismiss();
            }}
          >
            Open
          </ToastAction>
        ),
      });
    } catch (err) {
      toast({ title: "Couldn't add it", description: (err as Error).message, variant: "destructive" });
    } finally {
      setBusy(null);
    }
  };

  // Ctrl/Cmd+C copies, the way it does everywhere else a picture is on screen.
  const copyRef = useRef(copy);
  copyRef.current = copy;
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.code === "KeyC" && !(e.target instanceof HTMLInputElement)) {
        e.preventDefault();
        void copyRef.current();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  // ---- Where it can go --------------------------------------------------------

  const others = useMemo(() => {
    const q = query.trim().toLowerCase();
    return boards
      .filter((b) => b.id !== board.id && (!q || (b.name || "").toLowerCase().includes(q)))
      .sort((a, b) => {
        // Notebooks first: that is what "another notebook" means; then recent.
        const k = Number(isNotebook(b)) - Number(isNotebook(a));
        return k || (b.updatedAt ?? 0) - (a.updatedAt ?? 0);
      })
      .slice(0, 60);
  }, [boards, board.id, query]);

  const liveBoard = boards.find((b) => b.id === board.id);
  const livePage = liveBoard && isNotebook(liveBoard) ? getActivePageIndex(liveBoard) + 1 : null;

  const origin =
    request.origin === "selection" ? "Selection" : request.shape === "lasso" ? "Freeform" : "Area";

  // ---- Layout -----------------------------------------------------------------

  return (
    <DialogContent
      showCloseButton={false}
      onOpenAutoFocus={(e) => e.preventDefault()}
      className="flex max-h-[calc(100dvh-1.5rem)] w-[min(880px,calc(100vw-1.5rem))] max-w-none flex-col gap-0 overflow-hidden rounded-3xl border border-border/80 bg-white p-0 shadow-2xl sm:max-w-none dark:bg-zinc-900"
    >
      <style>{`
        .pn-checker { background-color: #ffffff; background-image: conic-gradient(#e4e4e7 25%, transparent 0 50%, #e4e4e7 0 75%, transparent 0); background-size: 14px 14px; }
        .dark .pn-checker { background-color: #27272a; background-image: conic-gradient(#3f3f46 25%, transparent 0 50%, #3f3f46 0 75%, transparent 0); }
      `}</style>

      {/* Header */}
      <div className="flex items-center gap-3 border-b border-border/60 px-4 py-3">
        <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-500 to-violet-500 text-white shadow-md shadow-indigo-500/30">
          <Scan size={18} />
        </span>
        <div className="min-w-0 flex-1">
          <DialogTitle className="text-[15px] font-semibold leading-tight">Capture</DialogTitle>
          <DialogDescription className="truncate text-[12px] text-muted-foreground">
            {origin} from {board.name || "Untitled"}
            {pageNo ? ` · page ${pageNo}` : ""}
          </DialogDescription>
        </div>
        <button
          type="button"
          onClick={onClose}
          aria-label="Close"
          className="flex h-9 w-9 items-center justify-center rounded-full text-muted-foreground transition hover:bg-muted hover:text-foreground"
        >
          <X size={18} />
        </button>
      </div>

      <div className="@container min-h-0 flex-1 overflow-y-auto">
        <div className="flex flex-col @[40rem]:h-full @[40rem]:flex-row">
          {/* Preview: the light table */}
          <div className="relative min-w-0 flex-1 bg-zinc-100 dark:bg-zinc-950/70">
            <div
              ref={stageRef}
              className="relative h-[36vh] min-h-[190px] @[40rem]:h-full @[40rem]:min-h-[420px]"
            >
              {fitted && (rendered || renderError) && (
                <div className="absolute inset-0 flex items-center justify-center">
                  {rendered ? (
                    <div className="relative" style={{ width: fitted.width, height: fitted.height }}>
                      <Corners />
                      {/* eslint-disable-next-line @next/next/no-img-element -- a local blob, not a page asset */}
                      <img
                        src={rendered.url}
                        alt="Preview of the capture"
                        draggable={false}
                        className={cn(
                          "pn-checker h-full w-full rounded-[3px] object-contain shadow-[0_8px_30px_rgba(0,0,0,0.18)] ring-1 ring-black/10 transition-opacity dark:ring-white/10",
                          rendering && "opacity-60"
                        )}
                      />
                    </div>
                  ) : (
                    <p className="max-w-xs px-6 text-center text-[13px] text-red-600 dark:text-red-400">{renderError}</p>
                  )}
                </div>
              )}
              {!rendered && !renderError && (
                <div className="absolute inset-0 flex items-center justify-center text-muted-foreground">
                  <Loader2 size={22} className="animate-spin" />
                </div>
              )}
              {/* Readouts */}
              <div className="pointer-events-none absolute bottom-2.5 left-2.5 flex flex-wrap gap-1.5">
                <span className="rounded-full bg-zinc-900/80 px-2.5 py-1 text-[11px] font-medium tabular-nums text-white backdrop-blur">
                  {pixel.width} × {pixel.height} px
                </span>
                {rendered && (
                  <span className="rounded-full bg-zinc-900/80 px-2.5 py-1 text-[11px] font-medium tabular-nums text-white/85 backdrop-blur">
                    PNG · {formatBytes(rendered.blob.size)}
                  </span>
                )}
              </div>
              {rendering && rendered && (
                <span className="pointer-events-none absolute right-2.5 top-2.5 flex items-center gap-1.5 rounded-full bg-zinc-900/80 px-2.5 py-1 text-[11px] font-medium text-white backdrop-blur">
                  <Loader2 size={12} className="animate-spin" /> Updating
                </span>
              )}
            </div>
          </div>

          {/* Controls rail */}
          <div className="flex shrink-0 flex-col gap-4 border-t border-border/60 p-4 @[40rem]:w-[18.5rem] @[40rem]:overflow-y-auto @[40rem]:border-l @[40rem]:border-t-0">
            {view === "main" ? (
              <>
                <section className="space-y-3">
                  <Segmented
                    label="Background"
                    value={background}
                    onChange={chooseBackground}
                    options={BACKGROUNDS.map((b) => ({
                      id: b.id,
                      title: b.hint,
                      label: (
                        <>
                          <Swatch kind={b.id} />
                          {b.label}
                        </>
                      ),
                    }))}
                  />
                  <p className="-mt-1.5 px-0.5 text-[11px] leading-snug text-muted-foreground">
                    {BACKGROUNDS.find((b) => b.id === background)!.hint}
                  </p>
                  <Segmented
                    label="Sharpness"
                    value={scale}
                    onChange={(v) => setScale(v)}
                    options={CAPTURE_SCALES.map((s) => ({
                      id: s,
                      label: `${s}×`,
                      title: `${Math.round(region.width * s)} × ${Math.round(region.height * s)} px`,
                    }))}
                  />
                  {request.selectionIds && request.selectionIds.length > 0 && (
                    <Segmented
                      label="Include"
                      value={onlySelection ? "sel" : "all"}
                      onChange={(v) => setOnlySelection(v === "sel")}
                      options={[
                        { id: "all", label: "Whole area" },
                        { id: "sel", label: "Selection only" },
                      ]}
                    />
                  )}
                  {missing && (
                    <p className="rounded-lg bg-amber-500/10 px-2.5 py-1.5 text-[11px] leading-snug text-amber-700 dark:text-amber-300">
                      {missing}
                    </p>
                  )}
                </section>

                <section>
                  <div className="mb-1.5 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
                    Send
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    <SendTile icon={Copy} label={copied ? "Copied" : "Copy"} onClick={copy} busy={busy === "copy"} done={copied} disabled={!ready} />
                    <SendTile
                      icon={Share2}
                      label="Share…"
                      onClick={share}
                      busy={busy === "share"}
                      primary
                      disabled={!ready}
                    />
                    <SendTile
                      icon={native ? GalleryIcon : Download}
                      label={native ? "Gallery" : "Save"}
                      onClick={save}
                      busy={busy === "save"}
                      disabled={!ready}
                    />
                  </div>
                  {!native && !canChooseApp() && (
                    <p className="mt-1.5 px-0.5 text-[10.5px] leading-snug text-muted-foreground">
                      This browser has no app chooser, so Share saves the file instead.
                    </p>
                  )}
                </section>

                <section>
                  <div className="mb-1 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
                    Add to notes
                  </div>
                  <div className="-mx-1 space-y-0.5">
                    <AddRow
                      icon={ImagePlus}
                      title={notebook ? "On this page" : "On this board"}
                      hint="Placed in view, ready to move"
                      onClick={addHere}
                      disabled={!ready || !!busy}
                    />
                    {notebook && (
                      <AddRow
                        icon={FilePlus2}
                        title="On a new page"
                        hint={livePage ? `Inserted after page ${livePage}` : "Inserted after this page"}
                        onClick={() => addTo(board.id, true)}
                        disabled={!ready || !!busy}
                      />
                    )}
                    <AddRow
                      icon={BookOpen}
                      title="In another notebook…"
                      hint="On a new page at its end"
                      onClick={() => setView("pick")}
                      disabled={!ready || !!busy}
                      chevron
                    />
                  </div>
                </section>
              </>
            ) : (
              <section className="flex min-h-0 flex-1 flex-col">
                <div className="mb-2 flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => setView("main")}
                    aria-label="Back"
                    className="flex h-8 w-8 items-center justify-center rounded-full text-muted-foreground transition hover:bg-muted hover:text-foreground"
                  >
                    <ArrowLeft size={17} />
                  </button>
                  <span className="text-[13px] font-semibold">Where should it go?</span>
                </div>
                <label className="mb-2 flex h-9 items-center gap-2 rounded-xl border border-border bg-muted/40 px-2.5 focus-within:border-indigo-400 dark:bg-zinc-800/60">
                  <Search size={14} className="shrink-0 text-muted-foreground" />
                  <input
                    autoFocus
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder="Search notebooks and boards"
                    className="min-w-0 flex-1 bg-transparent text-[13px] outline-none placeholder:text-muted-foreground"
                  />
                </label>
                <div className="-mx-1 max-h-[46vh] min-h-[120px] flex-1 space-y-0.5 overflow-y-auto @[40rem]:max-h-none">
                  {others.length === 0 && (
                    <p className="px-2 py-6 text-center text-[12px] text-muted-foreground">
                      {query ? "Nothing matches." : "There are no other notebooks yet."}
                    </p>
                  )}
                  {others.map((b) => {
                    const nb = isNotebook(b);
                    const count = nb ? getPages(b).length : 0;
                    return (
                      <AddRow
                        key={b.id}
                        icon={nb ? NotebookPen : LayoutGrid}
                        title={b.name || "Untitled"}
                        hint={nb ? `Notebook · ${count} page${count === 1 ? "" : "s"} · new page ${count + 1}` : "Board · placed beside its content"}
                        onClick={() => addTo(b.id, false)}
                        disabled={!!busy}
                      />
                    );
                  })}
                </div>
              </section>
            )}
          </div>
        </div>
      </div>
    </DialogContent>
  );
}
