"use client";

/**
 * The chip that says "screenshot mode is on".
 *
 * A mode that changes what the select tool does must be impossible to miss,
 * or Select appears broken: you drag a box and nothing gets selected. So
 * while screenshot mode is on and Select or Lasso is the tool, this chip sits
 * at the top of the canvas saying what the next drag does, with the box /
 * shape switch and an Off button right there. (The select button wears a
 * camera badge too, and the cursor is a crosshair.)
 *
 * The mode stays on across captures - taking three pictures of three
 * questions should not mean re-arming it three times - until you switch it
 * off here, in the Select menu, or with Esc.
 */

import React, { useEffect } from "react";
import { Camera, Lasso, SquareDashedMousePointer, X } from "lucide-react";
import { useWhiteboard } from "@/store/whiteboard";
import { screenshotShapeFor, useCapture } from "@/store/capture";
import { cn } from "@/lib/utils";

export function CaptureHud() {
  const screenshotMode = useCapture((s) => s.screenshotMode);
  const panelOpen = useCapture((s) => s.request !== null);
  const tool = useWhiteboard((s) => s.tool);
  const setTool = useWhiteboard((s) => s.setTool);
  // With the tool bar along the top, the hint goes to the bottom: at the top
  // it covered the tools and the page controls.
  const dockTop = useWhiteboard((s) => s.toolbarPosition === "top");
  const shape = screenshotShapeFor(screenshotMode, tool);

  // Esc leaves the mode - but not while the panel is up; there Esc closes the
  // panel and you are still in screenshot mode for the next one.
  useEffect(() => {
    if (!screenshotMode) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== "Escape" || useCapture.getState().request) return;
      // An Esc meant for something else - finishing a text box, closing
      // search or another window - is not "leave screenshot mode".
      const t = e.target as HTMLElement | null;
      if (t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName))) return;
      if (document.querySelector('[data-wb-modal], [role="dialog"], [data-wb-searchbar]')) return;
      if (useWhiteboard.getState().editingId) return;
      useCapture.getState().setScreenshotMode(false);
    };
    // Capture phase: the dialog closes itself on Esc from a document listener,
    // and by the time a bubbling listener ran the panel would already look
    // closed - the same Esc would then also switch the mode off.
    window.addEventListener("keydown", onKey, true);
    return () => window.removeEventListener("keydown", onKey, true);
  }, [screenshotMode]);

  if (!shape || panelOpen) return null;

  const shapeBtn = (s: "rectangle" | "lasso", Icon: typeof Camera, label: string) => (
    <button
      type="button"
      onClick={() => setTool(s === "rectangle" ? "select" : "lasso")}
      aria-pressed={shape === s}
      title={label}
      className={cn(
        "flex h-8 items-center gap-1.5 rounded-full px-2.5 text-[12px] font-medium transition",
        shape === s ? "bg-white/15 text-white" : "text-white/60 hover:text-white"
      )}
    >
      <Icon size={15} />
      <span className="hidden @min-[34rem]:inline">{label}</span>
    </button>
  );

  return (
    <div
      className={cn(
        "@container pointer-events-none absolute inset-x-0 z-40 flex justify-center px-3",
        dockTop ? "bottom-6" : "top-[72px]"
      )}
    >
      <div
        role="status"
        className={cn(
          "pointer-events-auto flex max-w-full items-center gap-1 rounded-full border border-white/10 bg-zinc-900/95 py-1 pl-1 pr-1 text-white shadow-2xl shadow-black/30 backdrop-blur-md animate-in fade-in",
          dockTop ? "slide-in-from-bottom-2" : "slide-in-from-top-2"
        )}
        onPointerDown={(e) => e.stopPropagation()}
      >
        <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-indigo-500 to-violet-500">
          <Camera size={15} />
        </span>
        <span className="min-w-0 truncate px-1.5 text-[12.5px] font-medium">
          <span className="hidden @min-[26rem]:inline">Screenshot mode — </span>
          {shape === "lasso" ? "draw around what to capture" : "drag over what to capture"}
        </span>
        <span className="mx-0.5 h-5 w-px shrink-0 bg-white/15" />
        {shapeBtn("rectangle", SquareDashedMousePointer, "Box")}
        {shapeBtn("lasso", Lasso, "Freeform")}
        <span className="mx-0.5 h-5 w-px shrink-0 bg-white/15" />
        <button
          type="button"
          onClick={() => useCapture.getState().setScreenshotMode(false)}
          aria-label="Turn screenshot mode off"
          title="Back to selecting (Esc)"
          className="flex h-8 shrink-0 items-center gap-1 rounded-full px-2.5 text-[12px] font-medium text-white/75 transition hover:bg-white/10 hover:text-white"
        >
          <X size={15} />
          <span className="hidden @min-[30rem]:inline">Off</span>
        </button>
      </div>
    </div>
  );
}
