"use client";

import React, { useRef, useCallback, useState, useMemo } from "react";
import { Map, X, Maximize2, Minimize2, Navigation } from "lucide-react";
import { useWhiteboard, useActiveBoard } from "@/store/whiteboard";
import { getBoardElements } from "@/lib/whiteboard/notebook";
import {
  getElementBounds,
  getUnionBounds,
  screenToWorld,
  type Viewport,
  type BoundingBox,
} from "@/lib/whiteboard/geometry";
import { STICKY_COLORS } from "@/lib/whiteboard/types";
import { cn } from "@/lib/utils";

interface MinimapProps {
  viewport?: Viewport;
}

export function Minimap({ viewport = { width: 1200, height: 800 } }: MinimapProps) {
  const minimapOpen = useWhiteboard((s) => s.minimapOpen);
  const toggleMinimap = useWhiteboard((s) => s.toggleMinimap);
  const camera = useWhiteboard((s) => s.camera);
  const setCamera = useWhiteboard((s) => s.setCamera);
  const activeBoard = useActiveBoard();

  const [isMinimized, setIsMinimized] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const MINIMAP_WIDTH = 200;
  const MINIMAP_HEIGHT = 130;
  const PADDING = 200; // World units margin around content

  const elements = getBoardElements(activeBoard);

  // 1. Calculate the active viewport bounding box in World coordinates
  const vpWorldW = viewport.width / Math.max(camera.zoom, 0.001);
  const vpWorldH = viewport.height / Math.max(camera.zoom, 0.001);
  const vpWorldX = camera.x - vpWorldW / 2;
  const vpWorldY = camera.y - vpWorldH / 2;

  // 2. Compute composite total bounds covering all elements AND the current camera viewport
  const totalBounds: BoundingBox = useMemo(() => {
    const rawBounds = getUnionBounds(elements);
    let minX = vpWorldX;
    let minY = vpWorldY;
    let maxX = vpWorldX + vpWorldW;
    let maxY = vpWorldY + vpWorldH;

    if (rawBounds) {
      minX = Math.min(minX, rawBounds.x);
      minY = Math.min(minY, rawBounds.y);
      maxX = Math.max(maxX, rawBounds.x + rawBounds.width);
      maxY = Math.max(maxY, rawBounds.y + rawBounds.height);
    }

    const paddedW = Math.max(maxX - minX + PADDING * 2, 800);
    const paddedH = Math.max(maxY - minY + PADDING * 2, 600);

    return {
      x: minX - PADDING,
      y: minY - PADDING,
      width: paddedW,
      height: paddedH,
    };
  }, [elements, vpWorldX, vpWorldY, vpWorldW, vpWorldH]);

  // 3. Mapping scale and centering
  const scale = useMemo(() => {
    const sX = MINIMAP_WIDTH / totalBounds.width;
    const sY = MINIMAP_HEIGHT / totalBounds.height;
    return Math.min(sX, sY);
  }, [totalBounds.width, totalBounds.height]);

  const offsetX = (MINIMAP_WIDTH - totalBounds.width * scale) / 2;
  const offsetY = (MINIMAP_HEIGHT - totalBounds.height * scale) / 2;

  // Transform functions: World <-> Minimap
  const worldToMini = useCallback(
    (wx: number, wy: number) => {
      const mx = (wx - totalBounds.x) * scale + offsetX;
      const my = (wy - totalBounds.y) * scale + offsetY;
      return { x: mx, y: my };
    },
    [totalBounds.x, totalBounds.y, scale, offsetX, offsetY]
  );

  const miniToWorld = useCallback(
    (mx: number, my: number) => {
      const wx = (mx - offsetX) / scale + totalBounds.x;
      const wy = (my - offsetY) / scale + totalBounds.y;
      return { x: wx, y: wy };
    },
    [totalBounds.x, totalBounds.y, scale, offsetX, offsetY]
  );

  // Viewport box in minimap coordinates
  const vpMiniPos = worldToMini(vpWorldX, vpWorldY);
  const vpMiniW = Math.max(vpWorldW * scale, 8);
  const vpMiniH = Math.max(vpWorldH * scale, 6);

  // Handle pointer down / drag to pan camera
  const handlePointerAction = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const mx = e.clientX - rect.left;
    const my = e.clientY - rect.top;
    const worldPt = miniToWorld(mx, my);
    setCamera({ x: worldPt.x, y: worldPt.y });
  };

  const onPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    e.stopPropagation();
    setIsDragging(true);
    (e.target as Element).setPointerCapture?.(e.pointerId);
    handlePointerAction(e);
  };

  const onPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!isDragging) return;
    e.stopPropagation();
    handlePointerAction(e);
  };

  const onPointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (isDragging) {
      e.stopPropagation();
      setIsDragging(false);
    }
  };

  if (!minimapOpen) return null;

  return (
    <div className="absolute bottom-6 right-6 z-30 flex flex-col bg-white/95 dark:bg-zinc-900/95 backdrop-blur-xl border border-border/80 shadow-2xl rounded-2xl overflow-hidden select-none animate-in fade-in slide-in-from-bottom-2">
      {/* Header */}
      <div className="flex items-center justify-between px-3 py-1.5 border-b border-border/60 bg-muted/30">
        <div className="flex items-center gap-1.5 text-xs font-semibold text-foreground">
          <Navigation size={12} className="text-primary" />
          <span>Minimap</span>
        </div>
        <div className="flex items-center gap-0.5">
          <button
            onClick={() => setIsMinimized(!isMinimized)}
            className="p-1 rounded-md hover:bg-muted text-muted-foreground hover:text-foreground"
            title={isMinimized ? "Expand minimap" : "Minimize minimap"}
          >
            {isMinimized ? <Maximize2 size={12} /> : <Minimize2 size={12} />}
          </button>
          <button
            onClick={toggleMinimap}
            className="p-1 rounded-md hover:bg-muted text-muted-foreground hover:text-foreground"
            title="Close minimap (M)"
          >
            <X size={12} />
          </button>
        </div>
      </div>

      {/* Minimap Body */}
      {!isMinimized && (
        <div
          ref={containerRef}
          onPointerDown={onPointerDown}
          onPointerMove={onPointerMove}
          onPointerUp={onPointerUp}
          onPointerCancel={onPointerUp}
          className="relative bg-muted/10 cursor-crosshair overflow-hidden touch-none"
          style={{ width: MINIMAP_WIDTH, height: MINIMAP_HEIGHT }}
        >
          {/* Miniature Elements SVG */}
          <svg className="w-full h-full absolute inset-0 pointer-events-none">
            {elements.map((el) => {
              if (el.type === "connection") return null;
              const b = getElementBounds(el);
              const miniPos = worldToMini(b.x, b.y);
              const miniW = Math.max(b.width * scale, 2);
              const miniH = Math.max(b.height * scale, 2);

              let fill = "#94a3b8";
              if (el.type === "sticky") {
                const colors = STICKY_COLORS[(el as { color?: string }).color as keyof typeof STICKY_COLORS];
                fill = colors?.bg || "#fef08a";
              } else if (el.type === "text") {
                fill = "#6366f1";
              } else if ((el as { strokeColor?: string }).strokeColor) {
                fill = (el as { strokeColor: string }).strokeColor;
              } else if ((el as { color?: string }).color) {
                fill = (el as { color: string }).color;
              }

              return (
                <rect
                  key={el.id}
                  x={miniPos.x}
                  y={miniPos.y}
                  width={miniW}
                  height={miniH}
                  rx={1}
                  fill={fill}
                  opacity={0.75}
                />
              );
            })}

            {/* Active Camera Viewport Box */}
            <rect
              x={vpMiniPos.x}
              y={vpMiniPos.y}
              width={vpMiniW}
              height={vpMiniH}
              rx={2}
              className="fill-primary/20 stroke-primary stroke-[1.5]"
              style={{ filter: "drop-shadow(0 1px 3px rgba(0,0,0,0.15))" }}
            />
          </svg>
        </div>
      )}
    </div>
  );
}
