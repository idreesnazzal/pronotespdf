"use client";

/**
 * Link Manager Modal
 * ===================
 * The primary UI for creating links between files (boards) and folders.
 *
 * How it works:
 * 1. User clicks "Link Files" button in the sidebar (next to +Board/+Folder)
 * 2. This modal opens with two columns: "From" (source) and "To" (target)
 * 3. User selects a board or folder from each column
 * 4. User picks a link type (Reference, Dependency, Related, Flow, or custom)
 * 5. User can optionally enter a custom label
 * 6. Click "Create Link" → a ConnectionElement is created on the source's board
 *
 * The connection is stored as a ConnectionElement on the source board, with
 * source.elementId = source board/folder id and target.elementId = target id.
 * For folders (which have no elements), we store a special pseudo-element.
 *
 * Existing links are listed at the bottom with their type colors and a delete button.
 */

import React, { useState, useMemo } from "react";
import { useWhiteboard } from "@/store/whiteboard";
import { allElements } from "@/lib/whiteboard/notebook";
import {
  BUILTIN_LINK_TYPES,
  LINK_TYPE_COLORS,
  LINK_TYPE_LABELS,
  getLinkTypeColor,
  getLinkTypeLabel,
  type Folder,
  type Board,
  type ConnectionElement,
  type WhiteboardElement,
} from "@/lib/whiteboard/types";
import { nanoid } from "nanoid";
import { X, Link2, Folder as FolderIcon, FileText, Trash2, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";

interface LinkManagerProps {
  open: boolean;
  onClose: () => void;
}

type SelectableItem =
  | { kind: "board"; id: string; name: string; color: string; folderId: string | null }
  | { kind: "folder"; id: string; name: string; color: string };

export function LinkManager({ open, onClose }: LinkManagerProps) {
  const folders = useWhiteboard((s) => s.folders);
  const boards = useWhiteboard((s) => s.boards);
  const customLinkTypes = useWhiteboard((s) => s.customLinkTypes);
  const addElementToBoard = useWhiteboard((s) => s.addElementToBoard);
  const deleteElementFromBoard = useWhiteboard((s) => s.deleteElementFromBoard);

  const [sourceId, setSourceId] = useState<string | null>(null);
  const [sourceKind, setSourceKind] = useState<"board" | "folder">("board");
  const [targetId, setTargetId] = useState<string | null>(null);
  const [targetKind, setTargetKind] = useState<"board" | "folder">("board");
  const [linkType, setLinkType] = useState<string>("relates");
  const [customLabel, setCustomLabel] = useState("");
  const [sourceSearch, setSourceSearch] = useState("");
  const [targetSearch, setTargetSearch] = useState("");

  // Build a flat list of all selectable items (boards + folders)
  const allItems: SelectableItem[] = useMemo(() => {
    const boardItems: SelectableItem[] = boards.map((b) => ({
      kind: "board" as const,
      id: b.id,
      name: b.name,
      color: b.color || "#3b82f6",
      folderId: b.folderId,
    }));
    const folderItems: SelectableItem[] = folders.map((f) => ({
      kind: "folder" as const,
      id: f.id,
      name: f.name,
      color: f.color || "#f59e0b",
    }));
    return [...folderItems, ...boardItems];
  }, [boards, folders]);

  // Filtered items for source and target columns based on search
  const sourceItems = useMemo(() => {
    if (!sourceSearch.trim()) return allItems;
    const q = sourceSearch.toLowerCase();
    return allItems.filter((i) => i.name.toLowerCase().includes(q));
  }, [allItems, sourceSearch]);

  const targetItems = useMemo(() => {
    if (!targetSearch.trim()) return allItems.filter((i) => i.id !== sourceId);
    const q = targetSearch.toLowerCase();
    return allItems.filter((i) => i.id !== sourceId && i.name.toLowerCase().includes(q));
  }, [allItems, sourceId, targetSearch]);

  // Collect all existing connection elements across all boards
  const existingLinks = useMemo(() => {
    const links: Array<{
      connectionId: string;
      boardId: string;
      sourceName: string;
      sourceKind: "board" | "folder";
      targetName: string;
      targetKind: "board" | "folder";
      linkType: string;
      label?: string;
    }> = [];
    for (const board of boards) {
      for (const el of allElements(board)) {
        if (el.type === "connection") {
          const conn = el as ConnectionElement;
          const sourceItem = allItems.find((i) => i.id === conn.source.elementId);
          const targetItem = allItems.find((i) => i.id === conn.target.elementId);
          if (sourceItem && targetItem) {
            links.push({
              connectionId: conn.id,
              boardId: board.id,
              sourceName: sourceItem.name,
              sourceKind: sourceItem.kind,
              targetName: targetItem.name,
              targetKind: targetItem.kind,
              linkType: conn.linkType,
              label: conn.label,
            });
          }
        }
      }
    }
    return links;
  }, [boards, allItems]);

  if (!open) return null;

  const handleCreateLink = () => {
    if (!sourceId || !targetId || sourceId === targetId) return;

    // For connections between boards/folders, we need to store the connection
    // on a board. If source is a board, store it there. If source is a folder,
    // store it on the active board (or first board).
    let storageBoardId: string | null = null;
    if (sourceKind === "board") {
      storageBoardId = sourceId;
    } else {
      // Source is a folder — find the first board in that folder, or use active board
      const boardInFolder = boards.find((b) => b.folderId === sourceId);
      storageBoardId = boardInFolder?.id || boards[0]?.id || null;
    }
    if (!storageBoardId) return;

    // Check for duplicate
    const storageBoard = boards.find((b) => b.id === storageBoardId);
    const exists = (storageBoard ? allElements(storageBoard) : []).some(
      (el) =>
        el.type === "connection" &&
        (el as ConnectionElement).source.elementId === sourceId &&
        (el as ConnectionElement).target.elementId === targetId
    );
    if (exists) {
      alert("This link already exists!");
      return;
    }

    // Create the connection element
    const conn: ConnectionElement = {
      id: nanoid(),
      type: "connection",
      x: 0,
      y: 0,
      rotation: 0,
      opacity: 1,
      source: { boardId: storageBoardId, elementId: sourceId, anchor: "auto" },
      target: { boardId: targetKind === "board" ? targetId : storageBoardId, elementId: targetId, anchor: "auto" },
      linkType,
      routing: "curved",
      dashStyle: "solid",
      startArrowhead: "none",
      endArrowhead: "arrow",
      strokeWidth: 2,
      label: customLabel.trim() || undefined,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };

    // Write directly to the storage board — switching boards here would wipe
    // the user's camera/selection/undo-history on the board they are viewing.
    addElementToBoard(storageBoardId, conn as unknown as WhiteboardElement, true);

    // Reset selection
    setSourceId(null);
    setTargetId(null);
    setCustomLabel("");
  };

  const handleDeleteLink = (connectionId: string, boardId: string) => {
    deleteElementFromBoard(boardId, [connectionId], true);
  };

  const sourceItem = allItems.find((i) => i.id === sourceId);
  const targetItem = allItems.find((i) => i.id === targetId);
  const canCreate = sourceId && targetId && sourceId !== targetId;

  return (
    <div
      data-wb-modal
      className="fixed inset-0 z-[90] flex items-center justify-center bg-black/50 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="w-full max-w-3xl bg-white dark:bg-zinc-900 rounded-2xl shadow-2xl border border-border overflow-hidden max-h-[85vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3 border-b border-border">
          <div className="flex items-center gap-2">
            <Link2 size={18} className="text-primary" />
            <h2 className="text-base font-semibold">Link Files & Folders</h2>
          </div>
          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={onClose}>
            <X size={16} />
          </Button>
        </div>

        <ScrollArea className="flex-1">
          <div className="p-5 space-y-4">
            {/* Instructions */}
            <div className="text-xs text-muted-foreground bg-muted/50 rounded-lg p-3">
              Select a source (file or folder) on the left, a target on the right,
              choose a link type, then click "Create Link". The link is saved
              with the source board and shows as an edge in the Knowledge Graph
              (Ctrl+G) and in the list below.
            </div>

            {/* Source & Target selectors */}
            <div className="grid grid-cols-2 gap-4">
              {/* Source */}
              <div className="space-y-2">
                <div className="text-xs font-medium text-muted-foreground flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-primary" />
                  From (source)
                </div>
                <Input
                  value={sourceSearch}
                  onChange={(e) => setSourceSearch(e.target.value)}
                  placeholder="Search name…"
                  className="h-7 text-xs"
                />
                <div className="border border-border rounded-lg max-h-48 overflow-y-auto">
                  {sourceItems.length === 0 ? (
                    <div className="text-xs text-muted-foreground italic py-3 text-center">No matches</div>
                  ) : (
                    sourceItems.map((item) => (
                      <button
                        key={`${item.kind}-${item.id}`}
                        onClick={() => {
                          setSourceId(item.id);
                          setSourceKind(item.kind);
                        }}
                        className={cn(
                          "flex items-center gap-2 w-full px-3 py-2 text-left text-sm hover:bg-muted transition-colors border-b border-border last:border-0",
                          sourceId === item.id && "bg-primary/10 border-l-2 border-l-primary"
                        )}
                      >
                        {item.kind === "folder" ? (
                          <FolderIcon size={13} style={{ color: item.color }} />
                        ) : (
                          <FileText size={13} style={{ color: item.color }} />
                        )}
                        <span className="flex-1 truncate">{item.name}</span>
                        <span className="text-[10px] text-muted-foreground capitalize">{item.kind}</span>
                      </button>
                    ))
                  )}
                </div>
              </div>

              {/* Target */}
              <div className="space-y-2">
                <div className="text-xs font-medium text-muted-foreground flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-emerald-500" />
                  To (target)
                </div>
                <Input
                  value={targetSearch}
                  onChange={(e) => setTargetSearch(e.target.value)}
                  placeholder="Search name…"
                  className="h-7 text-xs"
                />
                <div className="border border-border rounded-lg max-h-48 overflow-y-auto">
                  {targetItems.length === 0 ? (
                    <div className="text-xs text-muted-foreground italic py-3 text-center">No matches</div>
                  ) : (
                    targetItems.map((item) => (
                      <button
                        key={`${item.kind}-${item.id}`}
                        onClick={() => {
                          setTargetId(item.id);
                          setTargetKind(item.kind);
                        }}
                        className={cn(
                          "flex items-center gap-2 w-full px-3 py-2 text-left text-sm hover:bg-muted transition-colors border-b border-border last:border-0",
                          targetId === item.id && "bg-emerald-500/10 border-l-2 border-l-emerald-500"
                        )}
                      >
                        {item.kind === "folder" ? (
                          <FolderIcon size={13} style={{ color: item.color }} />
                        ) : (
                          <FileText size={13} style={{ color: item.color }} />
                        )}
                        <span className="flex-1 truncate">{item.name}</span>
                        <span className="text-[10px] text-muted-foreground capitalize">{item.kind}</span>
                      </button>
                    ))
                  )}
                </div>
              </div>
            </div>

            {/* Link type selector */}
            <div className="space-y-2">
              <div className="text-xs font-medium text-muted-foreground">Link type</div>
              <div className="flex flex-wrap gap-1.5">
                {BUILTIN_LINK_TYPES.map((lt) => (
                  <button
                    key={lt}
                    className={cn(
                      "flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs border transition-colors",
                      linkType === lt
                        ? "bg-primary/10 border-primary"
                        : "border-border hover:bg-muted"
                    )}
                    onClick={() => setLinkType(lt)}
                  >
                    <span
                      className="w-2.5 h-2.5 rounded-full"
                      style={{ backgroundColor: LINK_TYPE_COLORS[lt] }}
                    />
                    <span>{LINK_TYPE_LABELS[lt]}</span>
                  </button>
                ))}
                {customLinkTypes.map((ct) => (
                  <button
                    key={ct.id}
                    className={cn(
                      "flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs border transition-colors",
                      linkType === ct.id
                        ? "bg-primary/10 border-primary"
                        : "border-border hover:bg-muted"
                    )}
                    onClick={() => setLinkType(ct.id)}
                  >
                    <span
                      className="w-2.5 h-2.5 rounded-full"
                      style={{ backgroundColor: ct.color }}
                    />
                    <span>{ct.name}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Custom label */}
            <div className="space-y-2">
              <div className="text-xs font-medium text-muted-foreground">
                Custom label (optional — overrides the type name on the arrow)
              </div>
              <Input
                value={customLabel}
                onChange={(e) => setCustomLabel(e.target.value)}
                placeholder="e.g., depends on, blocks, references..."
                className="h-8 text-sm"
              />
            </div>

            {/* Preview + Create */}
            <div className="flex items-center justify-between bg-muted/30 rounded-lg p-3">
              <div className="text-xs">
                {sourceItem && targetItem ? (
                  <span>
                    <strong>{sourceItem.name}</strong>
                    <span className="text-muted-foreground mx-2">→</span>
                    <strong>{targetItem.name}</strong>
                  </span>
                ) : (
                  <span className="text-muted-foreground">Select source and target</span>
                )}
              </div>
              <Button
                size="sm"
                disabled={!canCreate}
                onClick={handleCreateLink}
              >
                <Plus size={14} className="mr-1" />
                Create Link
              </Button>
            </div>

            {/* Existing links */}
            <div className="space-y-2">
              <div className="text-xs font-medium text-muted-foreground">
                Existing links ({existingLinks.length})
              </div>
              {existingLinks.length === 0 ? (
                <div className="text-xs text-muted-foreground italic py-4 text-center">
                  No links yet. Create one above.
                </div>
              ) : (
                <div className="space-y-1 max-h-40 overflow-y-auto">
                  {existingLinks.map((link) => (
                    <div
                      key={link.connectionId}
                      className="flex items-center gap-2 px-3 py-2 rounded-lg border border-border bg-background text-xs"
                    >
                      <span
                        className="w-3 h-1.5 rounded-full shrink-0"
                        style={{ backgroundColor: getLinkTypeColor(link.linkType, customLinkTypes) }}
                      />
                      <span className="flex-1 truncate">
                        <span className="font-medium">{link.sourceName}</span>
                        <span className="text-muted-foreground mx-1.5">→</span>
                        <span className="font-medium">{link.targetName}</span>
                      </span>
                      <span className="text-muted-foreground text-[10px]">
                        {link.label || getLinkTypeLabel(link.linkType, customLinkTypes)}
                      </span>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-6 w-6 text-destructive hover:text-destructive"
                        onClick={() => handleDeleteLink(link.connectionId, link.boardId)}
                      >
                        <Trash2 size={12} />
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </ScrollArea>
      </div>
    </div>
  );
}
