"use client";

/**
 * "Add a picture" — the toolbar's image button.
 *
 * One tap used to open the system file picker directly, with no say in where
 * the picture came from and no word on what happens to it. It now opens this
 * sheet: pick the SOURCE (take a photo, pick from photos, browse files, paste),
 * choose whether the picture goes ON the page or becomes a page of its own,
 * or reuse a picture already in your notes.
 *
 * Privacy: before ProNotes opens the camera or your photos for the first time
 * it says, in plain words, what it will and won't do, and asks. The answer is
 * remembered on this device and can be withdrawn from the same sheet. (The
 * camera itself is the system camera app, which needs no extra Android
 * permission — so the only "ask" is this honest one.)
 */

import React from "react";
import {
  Camera,
  ClipboardPaste,
  FileImage,
  FilePlus2,
  Images,
  Image as ImageIcon,
  Loader2,
  ShieldCheck,
  StickyNote,
  X,
} from "lucide-react";
import { useWhiteboard } from "@/store/whiteboard";
import { isNotebook } from "@/lib/whiteboard/notebook";
import { listRecentImages, storeImage, ASSET_PREFIX } from "@/lib/whiteboard/imagestore";
import { isImageFile, prepareImage } from "@/lib/whiteboard/imageImport";
import { appClipForPaste, getAppClipImage } from "@/lib/whiteboard/appClipboard";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";

type Source = "camera" | "photos" | "files";
type Access = "camera" | "media";
type PlaceAs = "picture" | "page";

const CONSENT_KEY = (a: Access) => `pronotes:consent:${a}`;
const PLACE_KEY = "pronotes:imagePlaceAs";

function readConsent(a: Access): boolean {
  try {
    return localStorage.getItem(CONSENT_KEY(a)) === "yes";
  } catch {
    return false;
  }
}
function writeConsent(a: Access, yes: boolean) {
  try {
    if (yes) localStorage.setItem(CONSENT_KEY(a), "yes");
    else localStorage.removeItem(CONSENT_KEY(a));
  } catch {
    /* a remembered answer is a convenience: without storage we simply ask again */
  }
}

const accessOf = (s: Source): Access => (s === "camera" ? "camera" : "media");

const CONSENT_COPY: Record<Access, { title: string; points: string[]; allow: string }> = {
  camera: {
    title: "Use your camera?",
    points: [
      "Your camera opens only when you tap Camera.",
      "The photo is kept in this notebook, on this device.",
      "Nothing is uploaded or shared unless you export or share it.",
    ],
    allow: "Allow camera",
  },
  media: {
    title: "Open your photos and files?",
    points: [
      "You choose each picture; ProNotes sees only what you pick.",
      "Your other photos and files stay private.",
      "Pictures are kept on this device, never uploaded.",
    ],
    allow: "Allow access",
  },
};

const SOURCES: Array<{ id: Source; label: string; hint: string; icon: typeof Camera; tint: string }> = [
  { id: "camera", label: "Camera", hint: "Take a photo", icon: Camera, tint: "from-rose-500 to-orange-400" },
  { id: "photos", label: "Photos", hint: "From your gallery", icon: Images, tint: "from-indigo-500 to-violet-500" },
  { id: "files", label: "Files", hint: "Browse storage", icon: FileImage, tint: "from-sky-500 to-cyan-400" },
];

interface Recent {
  id: string;
  url: string;
}

export function ImageInsertButton({ flyout }: { flyout: "top" | "bottom" | "left" | "right" }) {
  const [open, setOpen] = React.useState(false);
  const [asking, setAsking] = React.useState<Source | null>(null);
  const [consent, setConsent] = React.useState<Record<Access, boolean>>({ camera: false, media: false });
  const [placeAs, setPlaceAs] = React.useState<PlaceAs>("picture");
  const [busy, setBusy] = React.useState<string | null>(null);
  const [error, setError] = React.useState<string | null>(null);
  const [recent, setRecent] = React.useState<Recent[]>([]);
  const inputs = {
    camera: React.useRef<HTMLInputElement>(null),
    photos: React.useRef<HTMLInputElement>(null),
    files: React.useRef<HTMLInputElement>(null),
  };
  const inNotebook = useWhiteboard((s) => {
    const b = s.boards.find((x) => x.id === s.activeBoardId);
    return !!b && isNotebook(b);
  });

  // Read on open: localStorage is absent during the static export, and the
  // answers may have changed since the sheet was last shown.
  React.useEffect(() => {
    if (!open) return;
    setConsent({ camera: readConsent("camera"), media: readConsent("media") });
    try {
      setPlaceAs(localStorage.getItem(PLACE_KEY) === "page" ? "page" : "picture");
    } catch {
      /* default placement */
    }
    setAsking(null);
    setError(null);
    let alive = true;
    listRecentImages(10).then((recs) => {
      if (!alive) return;
      // Only pictures still used somewhere are worth offering again.
      const used = new Set<string>();
      for (const b of useWhiteboard.getState().boards) {
        const pages = (b as { pages?: Array<{ elements?: Array<{ type: string; src?: string }> }> }).pages;
        const lists = [(b as { elements?: Array<{ type: string; src?: string }> }).elements ?? []];
        if (pages) for (const p of pages) lists.push(p.elements ?? []);
        for (const els of lists) for (const el of els) if (el.type === "image" && el.src) used.add(el.src);
      }
      setRecent(
        recs
          .filter((r) => used.has(`${ASSET_PREFIX}${r.id}`))
          .map((r) => ({ id: r.id, url: r.dataUrl }))
      );
    });
    return () => {
      alive = false;
    };
  }, [open]);

  const choosePlace = (p: PlaceAs) => {
    setPlaceAs(p);
    try {
      localStorage.setItem(PLACE_KEY, p);
    } catch {
      /* remembered placement is a convenience */
    }
  };

  /** Launch a source. Must run inside the tap, or Android blocks the picker. */
  const launch = (src: Source) => {
    if (!consent[accessOf(src)]) {
      setAsking(src);
      return;
    }
    setError(null);
    inputs[src].current?.click();
  };

  const allow = () => {
    if (!asking) return;
    const a = accessOf(asking);
    writeConsent(a, true);
    setConsent((c) => ({ ...c, [a]: true }));
    const src = asking;
    setAsking(null);
    inputs[src].current?.click(); // still inside the Allow tap
  };

  const revoke = (a: Access) => {
    writeConsent(a, false);
    setConsent((c) => ({ ...c, [a]: false }));
  };

  const handleFiles = async (files: File[], source: Source | "paste") => {
    const pictures = files.filter(isImageFile);
    if (pictures.length === 0) {
      setError(files.length ? "That file is not a picture." : null);
      return;
    }
    setBusy(pictures.length === 1 ? "Adding picture…" : `Adding ${pictures.length} pictures…`);
    setError(null);
    try {
      const prepared = await Promise.all(pictures.map((f) => prepareImage(f)));
      if (placeAs === "page" && inNotebook) {
        const measured = await Promise.all(
          prepared.map(
            (dataUrl) =>
              new Promise<{ src: string; width: number; height: number }>((resolve, reject) => {
                const img = new Image();
                img.onload = () =>
                  storeImage(dataUrl).then((src) =>
                    resolve({ src, width: img.naturalWidth, height: img.naturalHeight })
                  );
                img.onerror = () => reject(new Error("A picture could not be read."));
                img.src = dataUrl;
              })
          )
        );
        useWhiteboard.getState().addImagePages(measured);
      } else {
        prepared.forEach((dataUrl, index) =>
          window.dispatchEvent(
            new CustomEvent("pronotes:insertimage", {
              // A fresh photo nearly always wants cropping: open the editor.
              detail: { dataUrl, index, edit: source === "camera" && prepared.length === 1 },
            })
          )
        );
      }
      setOpen(false);
    } catch (err) {
      setError((err as Error).message || "The picture could not be added.");
    } finally {
      setBusy(null);
    }
  };

  const onPicked = (source: Source) => (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files ?? []);
    e.target.value = "";
    if (files.length) void handleFiles(files, source);
  };

  const paste = async () => {
    setError(null);
    // A capture copied inside ProNotes that the system clipboard refused (the
    // Android WebView will not take pictures): it lives on the app's own
    // clipboard, and pasting it here must work all the same.
    const own = appClipForPaste();
    if (own) {
      if (placeAs === "page" && inNotebook) {
        const src = await storeImage(own.dataUrl);
        useWhiteboard.getState().addImagePages([{ src, width: own.width, height: own.height }]);
      } else {
        window.dispatchEvent(
          new CustomEvent("pronotes:insertimage", { detail: { dataUrl: own.dataUrl, size: own.worldSize } })
        );
      }
      setOpen(false);
      return;
    }
    try {
      const items = await navigator.clipboard.read();
      const blobs: File[] = [];
      for (const item of items) {
        const type = item.types.find((t) => t.startsWith("image/"));
        if (type) {
          const blob = await item.getType(type);
          blobs.push(new File([blob], "pasted", { type }));
        }
      }
      if (blobs.length === 0) {
        setError("There is no picture on the clipboard. Copy one first.");
        return;
      }
      await handleFiles(blobs, "paste");
    } catch {
      // Copying may have worked while reading back is refused (Android): a
      // capture copied here is still on ProNotes' own clipboard.
      const mine = getAppClipImage();
      if (mine) {
        window.dispatchEvent(
          new CustomEvent("pronotes:insertimage", { detail: { dataUrl: mine.dataUrl, size: mine.worldSize } })
        );
        setOpen(false);
        return;
      }
      setError("ProNotes can't read the clipboard here. Close this and press Ctrl+V on the page.");
    }
  };

  const reuse = (r: Recent) => {
    if (placeAs === "page" && inNotebook) {
      const img = new Image();
      img.onload = () => {
        useWhiteboard
          .getState()
          .addImagePages([{ src: `${ASSET_PREFIX}${r.id}`, width: img.naturalWidth, height: img.naturalHeight }]);
        setOpen(false);
      };
      img.src = r.url;
      return;
    }
    window.dispatchEvent(
      new CustomEvent("pronotes:insertimage", { detail: { dataUrl: `${ASSET_PREFIX}${r.id}` } })
    );
    setOpen(false);
  };

  const ask = asking ? CONSENT_COPY[accessOf(asking)] : null;

  return (
    <>
      <input ref={inputs.camera} type="file" accept="image/*" capture="environment" className="hidden" onChange={onPicked("camera")} />
      <input ref={inputs.photos} type="file" accept="image/*" multiple className="hidden" onChange={onPicked("photos")} />
      {/* Several types make Android open its file browser instead of the photo picker. */}
      <input
        ref={inputs.files}
        type="file"
        accept="image/png,image/jpeg,image/webp,image/gif,image/bmp,image/svg+xml,image/heic"
        multiple
        className="hidden"
        onChange={onPicked("files")}
      />
      <Popover open={open} onOpenChange={setOpen}>
        <Tooltip>
          <TooltipTrigger asChild>
            <PopoverTrigger asChild>
              <button
                aria-label="Add a picture"
                className={cn(
                  "p-2.5 rounded-xl transition-all",
                  open ? "bg-indigo-500/15 text-indigo-600 dark:text-indigo-300" : "hover:bg-muted text-muted-foreground hover:text-foreground"
                )}
              >
                <ImageIcon size={18} />
              </button>
            </PopoverTrigger>
          </TooltipTrigger>
          <TooltipContent side={flyout}>Add a picture (or paste)</TooltipContent>
        </Tooltip>
        <PopoverContent
          side={flyout}
          align="center"
          className="w-[320px] max-w-[calc(100vw-24px)] overflow-hidden rounded-3xl border-border/70 p-0 shadow-2xl"
        >
          {ask && asking ? (
            <div className="p-5">
              <div className="mb-3 flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-500/12 text-emerald-600 dark:text-emerald-400">
                <ShieldCheck size={22} />
              </div>
              <h3 className="text-base font-semibold">{ask.title}</h3>
              <ul className="mt-2 space-y-1.5">
                {ask.points.map((p) => (
                  <li key={p} className="flex gap-2 text-[13px] leading-snug text-muted-foreground">
                    <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-emerald-500" />
                    {p}
                  </li>
                ))}
              </ul>
              <p className="mt-3 text-[11px] text-muted-foreground">You can turn this off any time at the bottom of this panel.</p>
              <div className="mt-4 flex gap-2">
                <button
                  onClick={() => setAsking(null)}
                  className="flex-1 rounded-xl border border-border py-2.5 text-sm font-medium hover:bg-muted"
                >
                  Not now
                </button>
                <button
                  onClick={allow}
                  className="flex-1 rounded-xl bg-indigo-600 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500"
                >
                  {ask.allow}
                </button>
              </div>
            </div>
          ) : (
            <div className="relative">
              <div className="flex items-center justify-between px-4 pb-1 pt-3.5">
                <div>
                  <h3 className="text-sm font-semibold">Add a picture</h3>
                  <p className="text-[11px] text-muted-foreground">Crop, flip and restyle it after it lands.</p>
                </div>
                <button onClick={() => setOpen(false)} aria-label="Close" className="rounded-full p-1.5 text-muted-foreground hover:bg-muted">
                  <X size={15} />
                </button>
              </div>

              <div className="grid grid-cols-3 gap-2 px-3 pt-2">
                {SOURCES.map(({ id, label, hint, icon: Icon, tint }) => (
                  <button
                    key={id}
                    onClick={() => launch(id)}
                    disabled={!!busy}
                    className="group flex flex-col items-center gap-1.5 rounded-2xl border border-border/60 bg-muted/30 px-1 pb-2.5 pt-3 transition hover:border-indigo-400/60 hover:bg-indigo-500/5 active:scale-[0.97] disabled:opacity-50"
                  >
                    <span className={cn("flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br text-white shadow-md transition group-hover:scale-105", tint)}>
                      <Icon size={21} />
                    </span>
                    <span className="text-[13px] font-semibold leading-none">{label}</span>
                    <span className="text-[10px] leading-none text-muted-foreground">{hint}</span>
                  </button>
                ))}
              </div>

              <button
                onClick={paste}
                disabled={!!busy}
                className="mx-3 mt-2 flex w-[calc(100%-24px)] items-center gap-2 rounded-xl px-3 py-2 text-[13px] text-muted-foreground transition hover:bg-muted hover:text-foreground disabled:opacity-50"
              >
                <ClipboardPaste size={15} /> Paste from clipboard
              </button>

              {inNotebook && (
                <div className="mx-3 mt-1 grid grid-cols-2 gap-1 rounded-xl bg-muted/60 p-1" role="radiogroup" aria-label="Place as">
                  {(
                    [
                      { id: "picture" as const, label: "On this page", icon: StickyNote },
                      { id: "page" as const, label: "As a new page", icon: FilePlus2 },
                    ]
                  ).map(({ id, label, icon: Icon }) => (
                    <button
                      key={id}
                      role="radio"
                      aria-checked={placeAs === id}
                      onClick={() => choosePlace(id)}
                      className={cn(
                        "flex items-center justify-center gap-1.5 rounded-lg py-1.5 text-[12px] font-medium transition",
                        placeAs === id ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"
                      )}
                    >
                      <Icon size={13} /> {label}
                    </button>
                  ))}
                </div>
              )}

              {recent.length > 0 && (
                <div className="mt-3">
                  <div className="px-4 text-[11px] font-medium uppercase tracking-wide text-muted-foreground">Use again</div>
                  <div className="flex gap-2 overflow-x-auto px-3 pb-1 pt-1.5 [scrollbar-width:thin]">
                    {recent.map((r) => (
                      <button
                        key={r.id}
                        onClick={() => reuse(r)}
                        className="h-16 w-16 shrink-0 overflow-hidden rounded-xl border border-border/60 bg-muted transition hover:ring-2 hover:ring-indigo-400"
                        aria-label="Add this picture again"
                      >
                        {/* eslint-disable-next-line @next/next/no-img-element */}
                        <img src={r.url} alt="" className="h-full w-full object-cover" draggable={false} />
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {error && <p className="mx-4 mt-2 text-[12px] text-rose-600 dark:text-rose-400">{error}</p>}

              <div className="mt-3 flex items-center gap-2 border-t border-border/60 bg-muted/30 px-4 py-2.5 text-[11px] text-muted-foreground">
                <ShieldCheck size={13} className="shrink-0 text-emerald-600 dark:text-emerald-400" />
                <span className="flex-1">Pictures stay on this device.</span>
                {(["camera", "media"] as Access[]).map((a) =>
                  consent[a] ? (
                    <button key={a} onClick={() => revoke(a)} className="rounded-md px-1.5 py-0.5 underline-offset-2 hover:bg-muted hover:underline">
                      {a === "camera" ? "Camera: on" : "Photos: on"}
                    </button>
                  ) : null
                )}
              </div>

              {busy && (
                <div className="absolute inset-0 flex items-center justify-center gap-2 bg-background/80 text-sm font-medium backdrop-blur-sm">
                  <Loader2 size={16} className="animate-spin" /> {busy}
                </div>
              )}
            </div>
          )}
        </PopoverContent>
      </Popover>
    </>
  );
}
