/**
 * Notebook paper, shared by every renderer.
 *
 * A sheet's ruling comes from `paperForPage` (the page's own paper, falling
 * back to the notebook's) — never from the ACTIVE page's paper. Each visible
 * sheet gets its own `<pattern>` (unique id per sheet) because different pages
 * in one document can carry different rulings and spacings.
 */

import { BOARD_BACKGROUNDS, type BoardBackground, type BoardPattern } from "@/lib/whiteboard/types";

/** Resolve a stored paper colour for the current theme ("" = follow theme). */
export function paperColorFor(
  bg: BoardBackground | undefined,
  resolvedTheme: string | undefined
): string {
  const preset = BOARD_BACKGROUNDS.find((b) => b.id === bg?.color);
  if (preset) return resolvedTheme === "dark" ? preset.dark : preset.light;
  // A custom colour is stored literally; presets are stored by id so that
  // they can flip between their light and dark variants with the theme.
  return bg?.color || "";
}

/** Ruling tiles in WORLD units (no zoom pre-multiplied — the zoomed group does it). */
export function PaperTiles({ pattern, size }: { pattern: BoardPattern; size: number }) {
  if (pattern === "dots") {
    return (
      <circle
        cx={size / 2}
        cy={size / 2}
        r={Math.max(0.5, size / 20)}
        className="fill-zinc-300 dark:fill-zinc-700"
      />
    );
  }
  if (pattern === "grid") {
    return (
      <path
        d={`M ${size} 0 L 0 0 0 ${size}`}
        fill="none"
        strokeWidth={0.8}
        className="stroke-zinc-300 dark:stroke-zinc-700"
      />
    );
  }
  if (pattern === "lines") {
    return (
      <path
        d={`M 0 ${size} L ${size} ${size}`}
        fill="none"
        strokeWidth={0.8}
        className="stroke-zinc-300 dark:stroke-zinc-700"
      />
    );
  }
  return null;
}
