"use client";

/**
 * Split view
 * ==========
 * Two documents side by side: the lecture PDF on one side, your notes on the
 * other. Either side can be written on.
 *
 * The store keeps ONE live document (`activeBoardId`) with its camera,
 * selection and editing target. The other half is drawn here. Touching it,
 * scrolling it or turning its page makes it the live one - the note you last
 * acted on is the note every tool, colour, paper and setting applies to.
 *
 * The invariant this file exists to keep
 * --------------------------------------
 * Switching which side is live must not move either document. Not a page, not
 * a pixel. Three things used to break that, all fixed here:
 *
 *  1. Different pictures from the same camera. The live canvas draws a notebook
 *     as a continuous strip anchored on its active page; this pane drew a
 *     single sheet at y = 0. Both now use `visibleSheets` / `reanchorDirection`
 *     from notebook.ts, so one camera means one picture.
 *  2. Different rules for a legal camera. The live canvas clamps to the paper
 *     (`clampNotebookCamera`) and floors the zoom (`minNotebookZoom`); this
 *     pane did neither, so on every switch the canvas "corrected" the view.
 *     This pane now DISPLAYS the stored camera through the same rules, for its
 *     own size, and writes the result back - so the canvas has nothing left to
 *     correct when it takes over.
 *  3. Different drawing areas. A header strip and a footer strip took height
 *     from this pane that the live canvas, in the same slot, did not lose. With
 *     the camera being the world point at the CENTRE of the pane, that alone
 *     shifted the page on every switch. The chrome is now floating, so both
 *     draw into the full slot.
 *
 * And the page you are reading here is the notebook's OWN active page, not a
 * private counter - otherwise tapping to write on page 5 put you on page 1.
 */

import React from "react";
import { ArrowLeftRight, ArrowUpDown, ChevronLeft, ChevronRight, Columns2, PenLine, Rows2, X } from "lucide-react";
import { useWhiteboard, useActiveBoard } from "@/store/whiteboard";
import {
  clampNotebookCamera,
  getActivePageIndex,
  getPages,
  isNotebook,
  minNotebookZoom,
  PAGE_GAP,
  pageSizeOf,
  paperForPage,
  reanchorDirection,
  visibleSheets,
} from "@/lib/whiteboard/notebook";
import { getUnionBounds } from "@/lib/whiteboard/geometry";
import {
  BOARD_BACKGROUNDS,
  BOARD_PATTERN_MAX_SIZE,
  BOARD_PATTERN_MIN_SIZE,
  type Board,
  type Camera,
} from "@/lib/whiteboard/types";
import { GRID_SIZE } from "@/lib/whiteboard/grid";
import { handOff, handOffPress } from "@/lib/whiteboard/pointerHandoff";
import { useTheme } from "next-themes";
import { ElementRenderer, StrokeFilterDefs } from "./ElementRenderer";
import { PdfPageLayer } from "./PdfPageLayer";
import { PaperTiles, paperColorFor } from "./PaperPattern";
import { cn } from "@/lib/utils";
import { dividerRatio } from "@/lib/whiteboard/split";

const DEFAULT_CAMERA: Camera = { x: 0, y: 0, zoom: 1 };

/**
 * The camera a notebook is SHOWN with in a pane of this size: the stored one,
 * put through exactly the rules the live canvas enforces when it settles.
 * Pure, so the same function answers for both panes.
 */
export function displayCameraFor(
  board: Board | null,
  stored: Camera,
  size: { width: number; height: number }
): Camera {
  if (!board || !isNotebook(board) || !size.width || !size.height) return stored;
  const dim = pageSizeOf(board);
  const floor = minNotebookZoom(size, dim);
  const zoom = floor > 0 && stored.zoom < floor - 1e-3 ? floor : stored.zoom;
  const { x, y } = clampNotebookCamera({ ...stored, zoom }, size, dim, {
    pageCount: getPages(board).length,
    activeIndex: getActivePageIndex(board),
  });
  return { x, y, zoom };
}

// ---------------------------------------------------------------------------
// The chip each pane wears
// ---------------------------------------------------------------------------

/**
 * Which document this is, which page, and - above all - whether it is the one
 * your tools act on. Floating, so it costs the drawing area nothing.
 */
export function SplitPaneChip({
  board,
  live,
  onPrevPage,
  onNextPage,
  children,
}: {
  board: Board;
  live: boolean;
  onPrevPage?: () => void;
  onNextPage?: () => void;
  children?: React.ReactNode;
}) {
  const notebook = isNotebook(board);
  const pages = getPages(board);
  const index = getActivePageIndex(board);
  return (
    <div
      data-split-chip={live ? "live" : "other"}
      className={cn(
        "pointer-events-auto flex h-8 max-w-[calc(100%-1.5rem)] items-center gap-1 rounded-full border pl-2.5 pr-1 text-xs shadow-md backdrop-blur-md transition-colors",
        // Blue, not the theme's "primary": in this theme primary is near
        // black, and "live" has to read at a glance from across the table.
        live
          ? "border-blue-500 bg-blue-600 text-white"
          : "border-border bg-white/90 text-foreground dark:bg-zinc-900/90"
      )}
    >
      <span
        className={cn(
          "h-2 w-2 shrink-0 rounded-full",
          live ? "bg-white animate-pulse" : "bg-muted-foreground/50"
        )}
        aria-hidden
      />
      <span className="min-w-0 truncate font-semibold" title={board.name}>
        {board.name}
      </span>
      <span className={cn("shrink-0 text-[10px] font-medium", live ? "opacity-80" : "text-muted-foreground")}>
        {live ? "Editing" : "Tap to edit"}
      </span>

      {notebook && pages.length > 1 && (
        <span className="ml-0.5 flex shrink-0 items-center">
          {onPrevPage && (
            <button
              type="button"
              onClick={onPrevPage}
              disabled={index <= 0}
              aria-label={`${board.name}: previous page`}
              className={cn(
                "flex h-6 w-6 items-center justify-center rounded-full disabled:pointer-events-none disabled:opacity-35",
                live ? "hover:bg-white/20" : "hover:bg-muted"
              )}
            >
              <ChevronLeft size={14} />
            </button>
          )}
          <span className="min-w-[3.25rem] text-center text-[11px] tabular-nums">
            {index + 1} / {pages.length}
          </span>
          {onNextPage && (
            <button
              type="button"
              onClick={onNextPage}
              disabled={index >= pages.length - 1}
              aria-label={`${board.name}: next page`}
              className={cn(
                "flex h-6 w-6 items-center justify-center rounded-full disabled:pointer-events-none disabled:opacity-35",
                live ? "hover:bg-white/20" : "hover:bg-muted"
              )}
            >
              <ChevronRight size={14} />
            </button>
          )}
        </span>
      )}
      {children}
    </div>
  );
}

/**
 * The live pane's chip and frame, mounted over the real canvas. The frame is
 * what tells you, at a glance, which half your pen, colour, paper and settings
 * are about to change.
 */
export function SplitLiveOverlay() {
  const splitBoardId = useWhiteboard((s) => s.splitBoardId);
  const board = useActiveBoard();
  if (!splitBoardId || !board) return null;
  return (
    <>
      <div
        aria-hidden
        data-split-live-frame
        className="pointer-events-none absolute inset-0 z-[35]"
        // Inline on purpose. The frame IS the answer to "which side am I
        // editing", and a Tailwind arbitrary ring (ring-[3px]) was silently
        // dropped from the build - verified at box-shadow: none. A plain style
        // cannot be.
        style={{ boxShadow: "inset 0 0 0 3px rgb(59 130 246)" }}
      />
      <div className="pointer-events-none absolute left-3 top-3 z-40 flex w-1/2">
        <SplitPaneChip board={board} live />
      </div>
    </>
  );
}

// ---------------------------------------------------------------------------
// The other pane
// ---------------------------------------------------------------------------

export function SplitPane() {
  const splitBoardId = useWhiteboard((s) => s.splitBoardId);
  const setSplitBoard = useWhiteboard((s) => s.setSplitBoard);
  const swapSplit = useWhiteboard((s) => s.swapSplit);
  const boards = useWhiteboard((s) => s.boards);
  const splitSide = useWhiteboard((s) => s.splitSide);
  const stacked = useWhiteboard((s) => s.splitOrientation === "stacked");
  const setSplitOrientation = useWhiteboard((s) => s.setSplitOrientation);
  const focusSplitSide = useWhiteboard((s) => s.focusSplitSide);
  const setBoardCamera = useWhiteboard((s) => s.setBoardCamera);
  const reanchorBoardPage = useWhiteboard((s) => s.reanchorBoardPage);
  const goToBoardPage = useWhiteboard((s) => s.goToBoardPage);
  const { resolvedTheme } = useTheme();

  // This pane shows the document that is NOT live, so it sits on the side the
  // live one is not.
  const mySide = splitSide === "left" ? "right" : "left";
  const board = boards.find((b) => b.id === splitBoardId) ?? null;

  const containerRef = React.useRef<HTMLDivElement>(null);
  const [size, setSize] = React.useState({ width: 0, height: 0 });
  React.useEffect(() => {
    const node = containerRef.current;
    if (!node) return;
    const ro = new ResizeObserver(() => setSize({ width: node.clientWidth, height: node.clientHeight }));
    ro.observe(node);
    setSize({ width: node.clientWidth, height: node.clientHeight });
    return () => ro.disconnect();
  }, []);

  const notebook = isNotebook(board);
  const pages = getPages(board);
  const activeIndex = getActivePageIndex(board);
  const dim = pageSizeOf(board);
  const stride = dim.height + PAGE_GAP;

  const stored = board?.camera ?? DEFAULT_CAMERA;
  const camera = displayCameraFor(board, stored, size);

  // Write the settled camera back, so the store holds exactly what is on
  // screen and the canvas finds nothing to correct when this side goes live.
  // Half a world unit of drift is invisible; skipping it avoids a render loop.
  React.useEffect(() => {
    if (!board || !notebook || !size.width) return;
    if (
      Math.abs(camera.x - stored.x) > 0.5 ||
      Math.abs(camera.y - stored.y) > 0.5 ||
      Math.abs(camera.zoom - stored.zoom) > 1e-3
    ) {
      setBoardCamera(board.id, camera);
    }
  }, [board, notebook, size.width, camera.x, camera.y, camera.zoom, stored.x, stored.y, stored.zoom, setBoardCamera]);

  // Continuous scrolling, the canvas's own rule: past the middle of the gap,
  // the next page takes the anchor and the camera slides one stride to match.
  React.useEffect(() => {
    if (!board || !notebook) return;
    const dir = reanchorDirection(camera.y, dim.height, activeIndex, pages.length);
    if (dir !== 0) reanchorBoardPage(board.id, dir, stride);
  }, [board, notebook, camera.y, dim.height, activeIndex, pages.length, stride, reanchorBoardPage]);

  /**
   * Frame a canvas that has never been looked at. A canvas's drawing sits
   * wherever it was drawn, so an untouched camera can show an empty pane.
   * Notebooks never need this: the clamp above already keeps the paper in
   * view. Runs only when NONE of the content is visible - refitting whenever
   * it opened is what used to throw away the position you had left it at.
   */
  const fittedFor = React.useRef<string | null>(null);
  React.useEffect(() => {
    if (!board || notebook || !size.width || !size.height) return;
    if (fittedFor.current === board.id) return;
    fittedFor.current = board.id;
    const bounds = getUnionBounds(board.elements ?? []);
    if (!bounds || bounds.width <= 0 || bounds.height <= 0) return;
    const halfW = size.width / 2 / Math.max(stored.zoom, 0.01);
    const halfH = size.height / 2 / Math.max(stored.zoom, 0.01);
    const visible =
      bounds.x < stored.x + halfW &&
      bounds.x + bounds.width > stored.x - halfW &&
      bounds.y < stored.y + halfH &&
      bounds.y + bounds.height > stored.y - halfH;
    if (visible) return;
    const pad = 40;
    const zoom = Math.max(
      0.05,
      Math.min(2, Math.min((size.width - pad) / bounds.width, (size.height - pad) / bounds.height))
    );
    setBoardCamera(board.id, { x: bounds.x + bounds.width / 2, y: bounds.y + bounds.height / 2, zoom });
  }, [board, notebook, size.width, size.height, stored.x, stored.y, stored.zoom, setBoardCamera]);

  // Scrolling this side makes it the live one - the note you last acted on is
  // the note your settings apply to. The wheel is handed to the canvas that
  // takes over, so the scroll obeys the canvas's own rules rather than a copy.
  React.useEffect(() => {
    const node = containerRef.current;
    if (!node) return;
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      const { clientX, clientY, deltaX, deltaY, deltaZ, deltaMode, ctrlKey, metaKey, shiftKey, altKey } = e;
      focusSplitSide(mySide);
      handOff(
        () =>
          new WheelEvent("wheel", {
            bubbles: true,
            cancelable: true,
            clientX,
            clientY,
            deltaX,
            deltaY,
            deltaZ,
            deltaMode,
            ctrlKey,
            metaKey,
            shiftKey,
            altKey,
          }),
        clientX,
        clientY
      );
    };
    node.addEventListener("wheel", onWheel, { passive: false });
    return () => node.removeEventListener("wheel", onWheel);
  }, [focusSplitSide, mySide]);

  if (!board) return null;

  const goPage = (delta: number) => {
    const target = pages[activeIndex + delta];
    if (!target) return;
    // Turning a page here is acting on this note, so it becomes the live one -
    // and it opens on the page you just turned to.
    goToBoardPage(board.id, target.id, size.height);
    focusSplitSide(mySide);
  };

  const canvasPaper = board.background;
  const canvasPattern = canvasPaper?.pattern ?? "dots";
  const canvasPaperSize = Math.min(
    BOARD_PATTERN_MAX_SIZE,
    Math.max(BOARD_PATTERN_MIN_SIZE, canvasPaper?.size ?? GRID_SIZE)
  );
  const canvasColor = (() => {
    const preset = BOARD_BACKGROUNDS.find((b) => b.id === canvasPaper?.color);
    if (preset) return resolvedTheme === "dark" ? preset.dark : preset.light;
    return canvasPaper?.color || "";
  })();

  const halfWorldH = size.height / 2 / Math.max(camera.zoom, 0.01);
  const sheets = notebook ? visibleSheets(pages.length, activeIndex, dim.height, camera.y, halfWorldH) : [];
  const onlySheetEmpty =
    notebook && pages.length === 1 && (pages[0]?.elements?.length ?? 0) === 0 && !pages[0]?.pdf;

  return (
    <div className="relative h-full min-w-0 overflow-hidden bg-muted/30">
      <div
        ref={containerRef}
        data-split-other
        className="absolute inset-0 cursor-pointer overflow-hidden"
        style={{ touchAction: "none" }}
        // Touching this side hands it the edit focus AND delivers the touch to
        // the canvas that takes over, so a pen stroke begins under the nib and
        // a finger drag pans - whatever that input does on the live side.
        onPointerDown={(e) => {
          const { clientX, clientY, pointerId, pointerType, button, buttons, pressure, isPrimary } = e;
          focusSplitSide(mySide);
          handOffPress(
            { clientX, clientY, pointerId, pointerType, button, buttons, pressure, isPrimary },
            clientX,
            clientY
          );
        }}
      >
        <svg width="100%" height="100%" className="block">
          <StrokeFilterDefs />

          {/* A canvas has no sheet: its paper fills the pane in screen space,
              offset by the camera so the ruling moves with the drawing. */}
          {!notebook && (
            <>
              <defs>
                <pattern
                  id={`split-canvas-paper-${board.id}`}
                  x={size.width / 2 - camera.x * camera.zoom}
                  y={size.height / 2 - camera.y * camera.zoom}
                  width={canvasPaperSize * camera.zoom}
                  height={canvasPaperSize * camera.zoom}
                  patternUnits="userSpaceOnUse"
                >
                  <g transform={`scale(${camera.zoom})`}>
                    <PaperTiles pattern={canvasPattern} size={canvasPaperSize} />
                  </g>
                </pattern>
              </defs>
              {canvasColor && <rect width="100%" height="100%" fill={canvasColor} />}
              {canvasPattern !== "plain" && (
                <rect width="100%" height="100%" fill={`url(#split-canvas-paper-${board.id})`} />
              )}
            </>
          )}

          <g
            transform={`translate(${size.width / 2}, ${size.height / 2}) scale(${camera.zoom}) translate(${-camera.x}, ${-camera.y})`}
          >
            {/* Every visible sheet, each in its OWN paper - the same strip the
                live canvas draws, so switching sides changes nothing. */}
            {sheets.map(({ index, offsetY }) => {
              const pg = pages[index];
              if (!pg) return null;
              const paper = paperForPage(board, pg);
              const color = paperColorFor(pg.background ?? board.background, resolvedTheme);
              const patternId = `split-paper-${board.id}-${pg.id}`;
              return (
                <g key={pg.id} transform={`translate(0, ${offsetY})`} pointerEvents="none">
                  <defs>
                    <pattern
                      id={patternId}
                      x={0}
                      y={0}
                      width={paper.size}
                      height={paper.size}
                      patternUnits="userSpaceOnUse"
                    >
                      <PaperTiles pattern={paper.pattern} size={paper.size} />
                    </pattern>
                  </defs>
                  <rect
                    x={3}
                    y={4}
                    width={dim.width}
                    height={dim.height}
                    fill={resolvedTheme === "dark" ? "#000000" : "#a1a1aa"}
                    opacity={resolvedTheme === "dark" ? 0.55 : 0.28}
                    rx={2}
                  />
                  <rect
                    x={0}
                    y={0}
                    width={dim.width}
                    height={dim.height}
                    fill={color || (resolvedTheme === "dark" ? "#18181b" : "#ffffff")}
                    stroke={resolvedTheme === "dark" ? "#3f3f46" : "#d4d4d8"}
                    strokeWidth={1 / camera.zoom}
                    rx={2}
                  />
                  {pg.pdf && <PdfPageLayer pdf={pg.pdf} width={dim.width} height={dim.height} />}
                  {paper.pattern !== "plain" && (
                    <rect x={0} y={0} width={dim.width} height={dim.height} fill={`url(#${patternId})`} />
                  )}
                  {(pg.elements ?? []).map((el) => (
                    <ElementRenderer key={el.id} element={el} isSelected={false} />
                  ))}
                </g>
              );
            })}

            {!notebook &&
              (board.elements ?? []).map((el) => (
                <ElementRenderer key={el.id} element={el} isSelected={false} />
              ))}
          </g>
        </svg>

        {onlySheetEmpty && (
          <p className="pointer-events-none absolute inset-x-0 bottom-16 text-center text-[11px] text-muted-foreground">
            Empty page — tap to start writing
          </p>
        )}
      </div>

      {/* Chrome floats: it must not take height the live canvas would not lose. */}
      <div className="pointer-events-none absolute left-3 right-3 top-3 z-10 flex items-start justify-between gap-2">
        <SplitPaneChip
          board={board}
          live={false}
          onPrevPage={() => goPage(-1)}
          onNextPage={() => goPage(1)}
        />
        <div className="pointer-events-auto flex shrink-0 items-center gap-1 rounded-full border border-border bg-white/90 p-0.5 shadow-md backdrop-blur-md dark:bg-zinc-900/90">
          <button
            type="button"
            onClick={() => focusSplitSide(mySide)}
            title="Write on this side"
            aria-label="Edit this pane"
            className="flex h-7 w-7 items-center justify-center rounded-full text-muted-foreground hover:bg-muted hover:text-foreground"
          >
            <PenLine size={14} />
          </button>
          <button
            type="button"
            onClick={swapSplit}
            title={stacked ? "Swap top and bottom" : "Swap left and right"}
            aria-label="Swap panes"
            className="flex h-7 w-7 items-center justify-center rounded-full text-muted-foreground hover:bg-muted hover:text-foreground"
          >
            {stacked ? <ArrowUpDown size={14} /> : <ArrowLeftRight size={14} />}
          </button>
          <button
            type="button"
            onClick={() => setSplitOrientation(stacked ? "side" : "stacked")}
            title={stacked ? "Show side by side" : "Show one above the other"}
            aria-label={stacked ? "Side by side" : "Top and bottom"}
            className="flex h-7 w-7 items-center justify-center rounded-full text-muted-foreground hover:bg-muted hover:text-foreground"
          >
            {stacked ? <Columns2 size={14} /> : <Rows2 size={14} />}
          </button>
          <button
            type="button"
            onClick={() => setSplitBoard(null)}
            title="Close split view"
            aria-label="Close split view"
            className="flex h-7 w-7 items-center justify-center rounded-full text-muted-foreground hover:bg-muted hover:text-foreground"
          >
            <X size={14} />
          </button>
        </div>
      </div>
    </div>
  );
}

/**
 * The divider between the two panes: a vertical bar side by side, a
 * horizontal one when stacked. A 6px line with a wide grab area and a grip,
 * because a hairline cannot be hit with a finger. Double-tap evens it out.
 */
export function SplitDivider({
  containerRef,
  stacked = false,
  style,
}: {
  containerRef: React.RefObject<HTMLDivElement | null>;
  stacked?: boolean;
  style?: React.CSSProperties;
}) {
  const setSplitRatio = useWhiteboard((s) => s.setSplitRatio);
  const [dragging, setDragging] = React.useState(false);
  const lastTap = React.useRef(0);

  React.useEffect(() => {
    if (!dragging) return;
    // One resize per frame. The pointer reports far more often than that, and
    // every resize re-lays-out both panes and the canvas - dragging used to
    // stutter because each report did all of that (and a save) on its own.
    let frame = 0;
    let pending: number | null = null;
    const flush = () => {
      frame = 0;
      if (pending !== null) setSplitRatio(pending);
      pending = null;
    };
    const onMove = (e: PointerEvent) => {
      const node = containerRef.current;
      if (!node) return;
      const box = node.getBoundingClientRect();
      pending = stacked
        ? dividerRatio(e.clientY - box.top, box.height)
        : dividerRatio(e.clientX - box.left, box.width);
      if (!frame) frame = requestAnimationFrame(flush);
    };
    const onUp = () => {
      if (frame) cancelAnimationFrame(frame);
      flush();
      setDragging(false);
    };
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
    window.addEventListener("pointercancel", onUp);
    return () => {
      if (frame) cancelAnimationFrame(frame);
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
      window.removeEventListener("pointercancel", onUp);
    };
  }, [dragging, containerRef, setSplitRatio, stacked]);

  return (
    <div
      role="separator"
      aria-orientation={stacked ? "horizontal" : "vertical"}
      aria-label="Resize split view (double-tap to even it out)"
      onPointerDown={(e) => {
        e.preventDefault();
        const now = Date.now();
        if (now - lastTap.current < 350) {
          lastTap.current = 0;
          setSplitRatio(0.5);
          return;
        }
        lastTap.current = now;
        setDragging(true);
      }}
      style={{ ...style, touchAction: "none" }}
      className={cn(
        "group relative z-[60] shrink-0 bg-border",
        stacked ? "h-1.5 w-full cursor-row-resize" : "w-1.5 cursor-col-resize"
      )}
    >
      {/* A wider invisible hit area than the line itself. */}
      <span className={cn("absolute", stacked ? "inset-x-0 -top-2.5 -bottom-2.5" : "inset-y-0 -left-2.5 -right-2.5")} aria-hidden />
      <span
        aria-hidden
        className={cn(
          "absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full transition-colors",
          stacked ? "h-1.5 w-12" : "h-12 w-1.5",
          dragging ? "bg-blue-500" : "bg-muted-foreground/40 group-hover:bg-blue-500"
        )}
      />
    </div>
  );
}
