"use client";

/**
 * Account section of the Sync panel: self-service sign-up, sign-in, password
 * reset, and two-way sync of the workspace for the signed-in account.
 */

import React, { useEffect, useState } from "react";
import { useWhiteboard } from "@/store/whiteboard";
import {
  getCurrentUser,
  isConfigured,
  onAuthChange,
  pullWorkspace,
  pushWorkspace,
  sendPasswordReset,
  signIn,
  signOut,
  signUp,
  type AccountUser,
} from "@/lib/whiteboard/account";
import { Loader2, LogOut, RefreshCw, UserPlus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

type Mode = "signin" | "signup" | "reset";

interface Props {
  deviceLabel: string;
  onStatus: (s: { kind: "busy" | "ok" | "error"; message: string }) => void;
  busy: boolean;
}

export function AccountSection({ deviceLabel, onStatus, busy }: Props) {
  const getWorkspaceSnapshot = useWhiteboard((s) => s.getWorkspaceSnapshot);
  const mergeWorkspace = useWhiteboard((s) => s.mergeWorkspace);

  const [user, setUser] = useState<AccountUser | null>(null);
  const [mode, setMode] = useState<Mode>("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");

  useEffect(() => {
    let alive = true;
    getCurrentUser()
      .then((u) => alive && setUser(u))
      .catch(() => {});
    const off = onAuthChange((u) => alive && setUser(u));
    return () => {
      alive = false;
      off();
    };
  }, []);

  if (!isConfigured()) {
    return (
      <div className="rounded-lg border border-amber-500/40 bg-amber-500/10 p-3 text-xs leading-relaxed">
        <p className="font-medium text-amber-700 dark:text-amber-400">
          Accounts are not set up in this build.
        </p>
        <p className="mt-1 text-muted-foreground">
          Add <code className="font-semibold">NEXT_PUBLIC_SUPABASE_URL</code> and{" "}
          <code className="font-semibold">NEXT_PUBLIC_SUPABASE_ANON_KEY</code>, then rebuild.
          See <code>ACCOUNTS_SETUP.md</code> — free, about five minutes.
        </p>
      </div>
    );
  }

  const submit = async () => {
    const mail = email.trim();
    if (!mail) return onStatus({ kind: "error", message: "Enter your email." });

    try {
      if (mode === "reset") {
        onStatus({ kind: "busy", message: "Sending reset email…" });
        await sendPasswordReset(mail);
        onStatus({ kind: "ok", message: `Reset link sent to ${mail}.` });
        setMode("signin");
        return;
      }

      if (password.length < 6) {
        return onStatus({ kind: "error", message: "Password must be at least 6 characters." });
      }

      if (mode === "signup") {
        // Catching the mismatch here, rather than after the account exists,
        // saves the user from an account with a password they mistyped.
        if (password !== confirm) {
          return onStatus({ kind: "error", message: "The two passwords do not match." });
        }
        onStatus({ kind: "busy", message: "Creating your account…" });
        const res = await signUp(mail, password);
        if (res.needsEmailConfirmation) {
          onStatus({
            kind: "ok",
            message: `Account created. Click the link sent to ${mail}, then sign in.`,
          });
          setMode("signin");
        } else {
          onStatus({ kind: "ok", message: "Account created and signed in." });
        }
        setPassword("");
        setConfirm("");
        return;
      }

      onStatus({ kind: "busy", message: "Signing in…" });
      await signIn(mail, password);
      setPassword("");
      onStatus({ kind: "ok", message: "Signed in." });
    } catch (e) {
      onStatus({ kind: "error", message: (e as Error).message });
    }
  };

  const doSync = async () => {
    onStatus({ kind: "busy", message: "Syncing…" });
    try {
      const remote = await pullWorkspace();
      let summary: string;
      if (!remote) {
        summary = "First sync — uploaded this device's boards.";
      } else {
        const r = mergeWorkspace(remote.snapshot);
        summary =
          `Merged: ${r.added} new, ${r.updatedFromRemote} updated from your account, ` +
          `${r.keptLocal} kept from this device.`;
      }
      await pushWorkspace(getWorkspaceSnapshot(), deviceLabel);
      onStatus({ kind: "ok", message: summary });
    } catch (e) {
      onStatus({ kind: "error", message: (e as Error).message });
    }
  };

  const doSignOut = async () => {
    await signOut();
    onStatus({ kind: "ok", message: "Signed out. Your boards stay on this device." });
  };

  if (user) {
    return (
      <>
        <div className="rounded-lg border border-border p-3 text-xs">
          <div className="font-medium">{user.email}</div>
          <div className="text-muted-foreground">
            {user.confirmed ? "Signed in" : "Email not confirmed yet"}
          </div>
        </div>
        <div className="flex gap-2">
          <Button size="sm" className="flex-1" onClick={doSync} disabled={busy}>
            {busy ? (
              <Loader2 size={14} className="mr-1.5 animate-spin" />
            ) : (
              <RefreshCw size={14} className="mr-1.5" />
            )}
            Sync now
          </Button>
          <Button size="sm" variant="outline" onClick={doSignOut} disabled={busy}>
            <LogOut size={14} className="mr-1.5" />
            Sign out
          </Button>
        </div>
        <p className="text-[11px] leading-snug text-muted-foreground">
          Sign in with the same email on your tablet to get the same boards.
          Boards merge one by one — newest edit wins.
        </p>
      </>
    );
  }

  return (
    <>
      <div className="flex gap-1 rounded-lg bg-muted p-0.5 text-xs">
        {(["signin", "signup"] as const).map((m) => (
          <button
            key={m}
            onClick={() => setMode(m)}
            className={cn(
              "flex-1 rounded-md px-2 py-1.5 font-medium transition-colors",
              mode === m ? "bg-background shadow-sm" : "text-muted-foreground hover:text-foreground"
            )}
          >
            {m === "signin" ? "Sign in" : "Create account"}
          </button>
        ))}
      </div>

      <div className="space-y-2">
        <Input
          type="email"
          autoComplete="email"
          placeholder="you@example.com"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="h-9 text-xs"
        />
        {mode !== "reset" && (
          <Input
            type="password"
            autoComplete={mode === "signup" ? "new-password" : "current-password"}
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && void submit()}
            className="h-9 text-xs"
          />
        )}
        {mode === "signup" && (
          <Input
            type="password"
            autoComplete="new-password"
            placeholder="Confirm password"
            value={confirm}
            onChange={(e) => setConfirm(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && void submit()}
            className="h-9 text-xs"
          />
        )}

        <Button size="sm" className="w-full" onClick={submit} disabled={busy}>
          {busy ? (
            <Loader2 size={14} className="mr-1.5 animate-spin" />
          ) : (
            <UserPlus size={14} className="mr-1.5" />
          )}
          {mode === "signup" ? "Create account" : mode === "reset" ? "Send reset link" : "Sign in"}
        </Button>

        <button
          onClick={() => setMode(mode === "reset" ? "signin" : "reset")}
          className="w-full text-center text-[11px] text-muted-foreground underline-offset-2 hover:underline"
        >
          {mode === "reset" ? "Back to sign in" : "Forgot your password?"}
        </button>
      </div>
    </>
  );
}
