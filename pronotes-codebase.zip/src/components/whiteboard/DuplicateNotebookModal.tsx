"use client";

/**
 * Duplicate a notebook with page range + destination.
 *
 * Replaces the one-click duplicate for notebooks.
 *
 * 1. WHICH PAGES - tick checkboxes on lazy-rendered thumbnails or type a range
 *    like "2-5, 8", kept bidirectionally in sync.
 * 2. WHERE IT GOES - drill down through folders and stop somewhere:
 *    - Stop on a folder (or root): creates a NEW notebook with chosen pages.
 *      Asks for its name (defaulting to "X (Copy)").
 *    - Stop on a notebook: MERGES the chosen pages into that notebook.
 * 3. PUT THEM - only revealed when a notebook was chosen in step 2:
 *    pick where the pages land (at start / after page N / at end).
 */

import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  AlertTriangle,
  Check,
  Copy,
  NotebookText,
} from "lucide-react";
import { useWhiteboard } from "@/store/whiteboard";
import {
  formatPageSelection,
  getPages,
  pageSizeOf,
  parsePageSelection,
} from "@/lib/whiteboard/notebook";
import { buildExportSvg } from "@/lib/whiteboard/export";
import type { Board, NotebookPage } from "@/lib/whiteboard/types";
import {
  DestinationBrowser,
  type DestinationTarget,
} from "./MoveToDialog";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

interface DuplicateNotebookModalProps {
  open: boolean;
  onClose: () => void;
  sourceBoard: Board;
}

type Placement = "start" | "after" | "end";

const PLACEMENTS: Array<{ id: Placement; label: string }> = [
  { id: "start", label: "At the beginning" },
  { id: "after", label: "After page…" },
  { id: "end", label: "At the end" },
];

/**
 * Lazy page thumbnail renderer, reused from ExportModal.
 */
function DuplicatePageThumb({
  page,
  index,
  board,
  checked,
  onToggle,
}: {
  page: NotebookPage;
  index: number;
  board: Board;
  checked: boolean;
  onToggle: () => void;
}) {
  const ref = useRef<HTMLButtonElement | null>(null);
  const [svg, setSvg] = useState<string | null>(null);

  useEffect(() => {
    const node = ref.current;
    if (!node || svg) return;
    const draw = () => {
      try {
        const single = { ...board, pages: [page], activePageId: page.id };
        setSvg(buildExportSvg(single, { pages: "current", background: "white" }).svg);
      } catch {
        setSvg("");
      }
    };
    if (typeof IntersectionObserver === "undefined") {
      draw();
      return;
    }
    const io = new IntersectionObserver(
      (entries) => {
        if (entries.some((e) => e.isIntersecting)) {
          draw();
          io.disconnect();
        }
      },
      { rootMargin: "200px" }
    );
    io.observe(node);
    return () => io.disconnect();
  }, [board, page, svg]);

  const { width, height } = pageSizeOf(board);

  return (
    <button
      ref={ref}
      type="button"
      onClick={onToggle}
      aria-pressed={checked}
      aria-label={`Page ${index + 1}${checked ? ", selected" : ""}`}
      className="group relative shrink-0 focus:outline-none"
    >
      <div
        className={cn(
          "relative w-[64px] rounded-md border-2 overflow-hidden bg-white transition-all",
          checked ? "border-primary shadow-sm" : "border-border/70 opacity-70 group-hover:opacity-100"
        )}
        style={{ aspectRatio: `${width} / ${height}` }}
      >
        {svg ? (
          <div
            className="absolute inset-0 [&>svg]:w-full [&>svg]:h-full"
            dangerouslySetInnerHTML={{ __html: svg }}
          />
        ) : (
          <div className="absolute inset-0 bg-muted/40" />
        )}
        {page.pdf && (
          <span className="absolute left-0.5 top-0.5 rounded bg-black/60 px-1 text-[8px] font-semibold text-white">
            PDF
          </span>
        )}
        <span
          className={cn(
            "absolute bottom-0.5 right-0.5 flex h-4 w-4 items-center justify-center rounded-full border text-[9px]",
            checked ? "border-primary bg-primary text-primary-foreground" : "border-border bg-white/90 text-transparent"
          )}
        >
          <Check size={10} strokeWidth={3} />
        </span>
      </div>
      <div className="mt-0.5 text-center text-[10px] tabular-nums text-muted-foreground">{index + 1}</div>
    </button>
  );
}

export function DuplicateNotebookModal({
  open,
  onClose,
  sourceBoard,
}: DuplicateNotebookModalProps) {
  const folders = useWhiteboard((s) => s.folders);
  const boards = useWhiteboard((s) => s.boards);
  const duplicateNotebook = useWhiteboard((s) => s.duplicateNotebook);
  const insertPagesFromBoard = useWhiteboard((s) => s.insertPagesFromBoard);

  const pages = useMemo(() => getPages(sourceBoard), [sourceBoard]);
  const pageCount = pages.length;

  // Step 1: Pages
  const [selected, setSelected] = useState<number[]>([]);
  const [rangeText, setRangeText] = useState<string>("");

  // Step 2: Destination
  const [target, setTarget] = useState<DestinationTarget>({
    kind: "folder",
    folderId: sourceBoard.folderId ?? null,
    name: "Top level",
  });
  const [newNotebookName, setNewNotebookName] = useState("");

  // Step 3: Placement (only when target is a notebook)
  const [placement, setPlacement] = useState<Placement>("end");
  const [afterPageNum, setAfterPageNum] = useState("1");

  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Initialize or reset when opened
  useEffect(() => {
    if (!open) return;
    const all = Array.from({ length: pageCount }, (_, i) => i + 1);
    setSelected(all);
    setRangeText(all.length ? `1-${all.length}` : "");
    const parentFolder = sourceBoard.folderId
      ? folders.find((f) => f.id === sourceBoard.folderId)
      : null;
    setTarget({
      kind: "folder",
      folderId: sourceBoard.folderId ?? null,
      name: parentFolder ? parentFolder.name : "Top level",
    });
    setNewNotebookName(`${sourceBoard.name} (Copy)`);
    setPlacement("end");
    setAfterPageNum("1");
    setError(null);
    setBusy(false);
  }, [open, sourceBoard, pageCount, folders]);

  const allSelected = selected.length === pageCount && pageCount > 0;

  const applySelection = useCallback((next: number[]) => {
    setSelected(next);
    setRangeText(formatPageSelection(next));
  }, []);

  const togglePage = (pageNumber: number) => {
    const next = selected.includes(pageNumber)
      ? selected.filter((n) => n !== pageNumber)
      : [...selected, pageNumber].sort((a, b) => a - b);
    applySelection(next);
  };

  const onRangeTextChange = (text: string) => {
    setRangeText(text);
    setSelected(parsePageSelection(text, pageCount));
  };

  // Find target notebook board if target is a notebook
  const targetNotebookBoard = useMemo(() => {
    if (target.kind !== "notebook") return null;
    return boards.find((b) => b.id === target.boardId) ?? null;
  }, [target, boards]);

  const targetPageCount = targetNotebookBoard ? getPages(targetNotebookBoard).length : 0;

  // Compute 0-based insert index for notebook merge
  const insertIndex = useMemo(() => {
    if (placement === "start") return 0;
    if (placement === "end") return targetPageCount;
    const parsed = parseInt(afterPageNum, 10);
    const clampedPage = isNaN(parsed) ? 1 : Math.min(Math.max(1, parsed), targetPageCount);
    return clampedPage; // after page N means index N
  }, [placement, afterPageNum, targetPageCount]);

  // Size mismatch warning when merging
  const sizeWarning = useMemo(() => {
    if (target.kind !== "notebook" || !targetNotebookBoard) return null;
    const a = pageSizeOf(targetNotebookBoard);
    const b = pageSizeOf(sourceBoard);
    const ratio = (s: { width: number; height: number }) => s.width / s.height;
    if (Math.abs(ratio(a) - ratio(b)) < 0.02) return null;
    return `"${target.name}" uses a differently shaped page (${Math.round(a.width)}×${Math.round(
      a.height
    )} against this notebook's ${Math.round(b.width)}×${Math.round(b.height)}). Inserted pages keep their contents but sit on the target's sheet.`;
  }, [target, targetNotebookBoard, sourceBoard]);

  // Live plain-words summary
  const summary = useMemo(() => {
    const count = selected.length;
    if (count === 0) return "No pages selected.";
    const formattedRange = formatPageSelection(selected);
    const pageDesc = `${count} page${count === 1 ? "" : "s"} (${formattedRange})`;

    if (target.kind === "folder") {
      const name = newNotebookName.trim() || `${sourceBoard.name} (Copy)`;
      const folderDesc = target.folderId ? `in '${target.name}'` : "at top level";
      return `${pageDesc} → new notebook '${name}' ${folderDesc}.`;
    }

    // Merge into notebook
    let posDesc = "at the end";
    if (placement === "start") posDesc = "at the start";
    else if (placement === "after") {
      const p = Math.min(Math.max(1, parseInt(afterPageNum, 10) || 1), targetPageCount);
      posDesc = `after page ${p} of ${targetPageCount}`;
    }
    return `${pageDesc} → merge into '${target.name}', ${posDesc}.`;
  }, [selected, target, newNotebookName, sourceBoard.name, placement, afterPageNum, targetPageCount]);

  const disabledReason = useMemo(() => {
    if (selected.length === 0) return "Select at least one page";
    if (target.kind === "folder" && !newNotebookName.trim()) return "Enter a notebook name";
    return null;
  }, [selected.length, target.kind, newNotebookName]);

  const handleConfirm = () => {
    if (disabledReason || busy) return;
    setBusy(true);
    setError(null);
    try {
      const pageIndices = selected.map((n) => n - 1); // 0-based
      if (target.kind === "folder") {
        const id = duplicateNotebook(sourceBoard.id, {
          name: newNotebookName.trim(),
          folderId: target.folderId,
          pageIndices,
        });
        if (!id) {
          setError("Failed to create the duplicated notebook.");
          return;
        }
      } else {
        const count = insertPagesFromBoard(
          sourceBoard.id,
          { indices: pageIndices },
          insertIndex,
          target.boardId
        );
        if (count === 0) {
          setError("Nothing was merged. Check that the pages exist.");
          return;
        }
      }
      onClose();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && !busy && onClose()}>
      <DialogContent className="max-w-xl p-0 gap-0 overflow-hidden rounded-2xl border border-border/80 bg-white/98 shadow-2xl backdrop-blur-xl dark:bg-zinc-900/98">
        <DialogHeader className="space-y-0.5 border-b border-border/60 bg-muted/20 px-5 py-3.5">
          <div className="flex items-center gap-2.5">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10 text-primary">
              <Copy size={17} />
            </div>
            <div className="min-w-0">
              <DialogTitle className="text-base font-semibold">Duplicate notebook</DialogTitle>
              <DialogDescription className="truncate text-xs text-muted-foreground">
                Copy pages from &ldquo;{sourceBoard.name}&rdquo; ({pageCount} pages)
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>

        <div className="max-h-[70vh] space-y-4 overflow-y-auto px-5 py-4">
          {/* ---------------- 1. Which pages ---------------- */}
          <section className="space-y-2">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                1. Which pages
              </h3>
              <button
                type="button"
                onClick={() =>
                  applySelection(allSelected ? [] : Array.from({ length: pageCount }, (_, i) => i + 1))
                }
                className="text-xs font-medium text-primary hover:underline"
              >
                {allSelected ? "Deselect all" : "Select all"}
              </button>
            </div>

            <div className="flex gap-2 overflow-x-auto pb-1">
              {pages.map((p, i) => (
                <DuplicatePageThumb
                  key={p.id}
                  page={p}
                  index={i}
                  board={sourceBoard}
                  checked={selected.includes(i + 1)}
                  onToggle={() => togglePage(i + 1)}
                />
              ))}
            </div>

            <div className="space-y-1">
              <input
                value={rangeText}
                onChange={(e) => onRangeTextChange(e.target.value)}
                placeholder="e.g. 2-5, 8"
                aria-label="Page range to duplicate"
                className="w-full h-8 rounded-lg border border-border bg-background px-3 text-xs focus:border-primary focus:outline-none"
              />
              <p className="text-[11px] text-muted-foreground">
                {selected.length > 0
                  ? `${selected.length} of ${pageCount} pages selected (${formatPageSelection(selected)})`
                  : "No pages selected."}
              </p>
            </div>
          </section>

          {/* ---------------- 2. Where it goes ---------------- */}
          <section className="space-y-2">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              2. Where it goes
            </h3>
            <p className="text-[11px] text-muted-foreground">
              Navigate into a folder to create a new notebook, or tap an existing notebook to merge into it.
            </p>

            <DestinationBrowser
              selectedTarget={target}
              onSelectTarget={setTarget}
              allowNotebookTarget={true}
              excludeBoardId={sourceBoard.id}
            />

            {target.kind === "folder" ? (
              <div className="pt-1 space-y-1">
                <label className="text-xs font-medium text-foreground block">
                  New notebook name
                </label>
                <Input
                  value={newNotebookName}
                  onChange={(e) => setNewNotebookName(e.target.value)}
                  placeholder="Notebook name…"
                  className="h-8 text-xs"
                />
              </div>
            ) : (
              <div className="flex items-center gap-2 rounded-lg border border-primary/40 bg-primary/5 px-3 py-2">
                <NotebookText size={16} className="text-primary shrink-0" />
                <div className="min-w-0 flex-1">
                  <div className="truncate text-xs font-medium text-primary">
                    Merge into &ldquo;{target.name}&rdquo;
                  </div>
                  <div className="text-[10px] text-muted-foreground">
                    {target.pageCount} existing page{target.pageCount === 1 ? "" : "s"}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() =>
                    setTarget({
                      kind: "folder",
                      folderId: sourceBoard.folderId ?? null,
                      name: "Top level",
                    })
                  }
                  className="text-[11px] text-muted-foreground hover:text-foreground font-medium underline"
                >
                  Change
                </button>
              </div>
            )}
          </section>

          {/* ---------------- 3. Put them (only for notebook target) ---------------- */}
          {target.kind === "notebook" && (
            <section className="space-y-2 pt-1 border-t border-border/60">
              <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                3. After which page
              </h3>
              <div className="grid grid-cols-3 gap-1.5">
                {PLACEMENTS.map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => setPlacement(p.id)}
                    className={cn(
                      "py-1.5 px-2 rounded-lg border text-xs font-medium transition-all",
                      placement === p.id
                        ? "border-primary bg-primary/10 text-primary font-semibold"
                        : "border-border hover:bg-muted text-foreground"
                    )}
                  >
                    {p.label}
                  </button>
                ))}
              </div>

              {placement === "after" && (
                <div className="flex items-center gap-2 pt-1 text-xs">
                  <span className="text-muted-foreground">Insert after page:</span>
                  <input
                    type="number"
                    inputMode="numeric"
                    min={1}
                    max={Math.max(1, targetPageCount)}
                    value={afterPageNum}
                    onChange={(e) => setAfterPageNum(e.target.value)}
                    className="w-16 h-8 rounded-lg border border-border bg-background px-2 text-center text-xs tabular-nums focus:border-primary focus:outline-none"
                  />
                  <span className="text-muted-foreground">of {targetPageCount}</span>
                </div>
              )}

              <p className="text-[11px] text-muted-foreground">
                Target has {targetPageCount} page{targetPageCount === 1 ? "" : "s"}. The copied pages will become pages{" "}
                {insertIndex + 1}
                {selected.length > 1 ? `–${insertIndex + selected.length}` : ""} of{" "}
                {targetPageCount + selected.length}.
              </p>

              {sizeWarning && (
                <div className="flex gap-2 rounded-lg border border-amber-500/40 bg-amber-500/10 px-3 py-2 text-[11px] leading-snug text-amber-700 dark:text-amber-400">
                  <AlertTriangle size={14} className="shrink-0 mt-0.5" />
                  <span>{sizeWarning}</span>
                </div>
              )}
            </section>
          )}

          {error && (
            <div
              role="alert"
              className="rounded-lg border border-red-500/40 bg-red-500/10 px-3 py-2 text-[11px] text-red-600 dark:text-red-400"
            >
              {error}
            </div>
          )}

          {/* Live Summary Bar */}
          <div className="rounded-lg bg-muted/40 p-2.5 text-xs text-foreground font-medium border border-border/60">
            {summary}
          </div>

          <div className="flex gap-2 pt-1">
            <Button variant="outline" className="flex-1" onClick={onClose} disabled={busy}>
              Cancel
            </Button>
            <Button
              className="flex-1 font-semibold"
              disabled={Boolean(disabledReason) || busy}
              onClick={handleConfirm}
            >
              {disabledReason ??
                (busy
                  ? "Working…"
                  : target.kind === "folder"
                  ? `Duplicate ${selected.length} page${selected.length === 1 ? "" : "s"}`
                  : `Merge ${selected.length} page${selected.length === 1 ? "" : "s"}`)}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
