"use client";

/**
 * Movable tool dock
 * =================
 * The dock can attach to any edge. Pinning it to the bottom forever wastes the
 * long side of a landscape tablet and parks the tools right under your writing
 * hand — moving it is the fix, and it is a setting every serious note app has.
 *
 * The grip is a deliberate 4-way picker rather than a free drag: on a touch
 * screen a drag that starts on the toolbar is indistinguishable from a
 * mis-aimed tap on a tool, and a dock only has four useful places to be.
 */

import React from "react";
import { GripVertical, PanelBottom, PanelLeft, PanelRight, PanelTop } from "lucide-react";
import { useWhiteboard } from "@/store/whiteboard";
import { DOCK_POSITIONS, isVerticalDock, type DockPosition } from "@/lib/whiteboard/types";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";

const DOCK_ICONS: Record<DockPosition, React.ComponentType<{ size?: number }>> = {
  top: PanelTop,
  bottom: PanelBottom,
  left: PanelLeft,
  right: PanelRight,
};

/**
 * Where the whole dock stack sits, and which way it runs.
 *
 * The properties bar is always placed on the CANVAS side of the tools — above
 * a bottom dock, below a top one, and to the inside of a side dock — so the
 * thing you are configuring never sits between you and the edge.
 */
export function dockStackClasses(pos: DockPosition): string {
  switch (pos) {
    case "top":
      // BELOW the top bars, not level with them: at top-4 the dock sat on the
      // sidebar button (top-left) and the settings bar (top-right) and was
      // cut by them. Those bars end at ~60px.
      return "top-[72px] left-1/2 -translate-x-1/2 flex-col-reverse items-center";
    case "left":
      return "left-4 top-1/2 -translate-y-1/2 flex-row-reverse items-center";
    case "right":
      return "right-4 top-1/2 -translate-y-1/2 flex-row items-center";
    case "bottom":
    default:
      return "bottom-6 left-1/2 -translate-x-1/2 flex-col items-center";
  }
}

/** Caps the dock so it can never grow past the window on its long axis. */
export function dockSizeClasses(pos: DockPosition): string {
  return isVerticalDock(pos) ? "max-h-[calc(100%-2rem)]" : "max-w-[calc(100%-2rem)]";
}

/** Which side a flyout should open towards so it lands over the canvas. */
export function flyoutSide(pos: DockPosition): "top" | "bottom" | "left" | "right" {
  switch (pos) {
    case "top":
      return "bottom";
    case "left":
      return "right";
    case "right":
      return "left";
    case "bottom":
    default:
      return "top";
  }
}

export function DockGrip({ className }: { className?: string }) {
  const position = useWhiteboard((s) => s.toolbarPosition);
  const setPosition = useWhiteboard((s) => s.setToolbarPosition);
  const [open, setOpen] = React.useState(false);
  const vertical = isVerticalDock(position);

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <button
          title="Move the toolbar to another edge"
          aria-label="Move toolbar"
          className={cn(
            "flex shrink-0 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-muted hover:text-foreground",
            vertical ? "h-6 w-8" : "h-8 w-6",
            className
          )}
        >
          <GripVertical size={14} className={vertical ? "rotate-90" : undefined} />
        </button>
      </PopoverTrigger>
      <PopoverContent side={flyoutSide(position)} className="w-auto p-1.5" align="center">
        <div className="mb-1 px-1 text-[11px] font-medium text-muted-foreground">Toolbar edge</div>
        <div className="grid grid-cols-2 gap-1">
          {DOCK_POSITIONS.map((d) => {
            const Icon = DOCK_ICONS[d.id];
            return (
              <button
                key={d.id}
                onClick={() => {
                  setPosition(d.id);
                  setOpen(false);
                }}
                className={cn(
                  "flex items-center gap-1.5 rounded-lg border px-2 py-1.5 text-[11px] transition-colors",
                  position === d.id
                    ? "border-primary bg-primary/10 text-primary"
                    : "border-border text-foreground hover:bg-muted"
                )}
              >
                <Icon size={13} />
                {d.label}
              </button>
            );
          })}
        </div>
      </PopoverContent>
    </Popover>
  );
}
