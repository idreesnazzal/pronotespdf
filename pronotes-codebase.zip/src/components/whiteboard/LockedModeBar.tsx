"use client";

/**
 * Locked-items mode.
 *
 * A locked thing ignores every touch — that is the point of locking it — and
 * that used to leave no way back: you could not select it, so you could not
 * unlock it. This mode flips the rule for the Select tool: ONLY locked things
 * can be picked (tap, lasso or box), each wears an amber padlock so you can
 * see what is locked, and this bar unlocks the picked ones or all of them.
 * Unlocked things can't be picked meanwhile, so nothing else gets moved by
 * accident. Any other tool, Done, or Esc ends the mode.
 */

import React from "react";
import { Lock, LockOpen, MousePointerSquareDashed } from "lucide-react";
import { useWhiteboard, useActiveBoard } from "@/store/whiteboard";
import { getBoardElements } from "@/lib/whiteboard/notebook";
import { cn } from "@/lib/utils";

export function LockedModeBar() {
  const lockedMode = useWhiteboard((s) => s.lockedMode);
  const selectedIds = useWhiteboard((s) => s.selectedIds);
  const board = useActiveBoard();
  const [confirmAll, setConfirmAll] = React.useState(false);
  const [flash, setFlash] = React.useState<string | null>(null);

  React.useEffect(() => {
    if (!lockedMode) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") useWhiteboard.getState().setLockedMode(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [lockedMode]);

  React.useEffect(() => {
    if (!confirmAll) return;
    const t = setTimeout(() => setConfirmAll(false), 3000);
    return () => clearTimeout(t);
  }, [confirmAll]);

  React.useEffect(() => {
    if (!flash) return;
    const t = setTimeout(() => setFlash(null), 2200);
    return () => clearTimeout(t);
  }, [flash]);

  if (!lockedMode || !board) return null;
  const locked = getBoardElements(board).filter((el) => el.locked && el.type !== "connection");
  const picked = selectedIds.filter((id) => locked.some((el) => el.id === id));

  const unlock = (ids: string[]) => {
    const n = useWhiteboard.getState().unlockElements(ids);
    useWhiteboard.getState().clearSelection();
    setConfirmAll(false);
    if (n) setFlash(n === 1 ? "Unlocked — it moves again with the Select tool" : `${n} items unlocked`);
  };

  const pill = "flex h-9 items-center gap-1.5 rounded-full px-3 text-[12px] font-medium transition active:scale-95";

  return (
    <div
      className="absolute left-1/2 top-3 z-40 flex max-w-[calc(100%-24px)] -translate-x-1/2 flex-col items-center gap-1.5 animate-in fade-in slide-in-from-top-2"
      onPointerDown={(e) => e.stopPropagation()}
    >
      <div className="flex flex-wrap items-center justify-center gap-1 rounded-[22px] border border-amber-400/40 bg-white/95 p-1 pl-3 shadow-xl backdrop-blur-md dark:bg-zinc-900/95">
        <span className="flex items-center gap-1.5 pr-1 text-[12px] font-semibold text-amber-700 dark:text-amber-300">
          <span className="flex h-6 w-6 items-center justify-center rounded-full bg-amber-500 text-white">
            <Lock size={13} />
          </span>
          Locked items
          <span className="font-normal text-muted-foreground">
            · {locked.length === 0 ? "none here" : `${locked.length} on this page`}
          </span>
        </span>

        {picked.length > 0 ? (
          <button onClick={() => unlock(picked)} className={cn(pill, "bg-amber-500 text-white hover:bg-amber-400")}>
            <LockOpen size={14} /> Unlock {picked.length > 1 ? picked.length : ""}
          </button>
        ) : (
          locked.length > 0 && (
            <button onClick={() => useWhiteboard.getState().selectAll()} className={cn(pill, "text-foreground hover:bg-muted")}>
              <MousePointerSquareDashed size={14} /> Select all
            </button>
          )
        )}
        {locked.length > 1 && (
          <button
            onClick={() => (confirmAll ? unlock(locked.map((el) => el.id)) : setConfirmAll(true))}
            className={cn(pill, confirmAll ? "bg-rose-500 text-white hover:bg-rose-400" : "text-foreground hover:bg-muted")}
          >
            <LockOpen size={14} /> {confirmAll ? `Unlock all ${locked.length}?` : "Unlock all"}
          </button>
        )}
        <button
          onClick={() => useWhiteboard.getState().setLockedMode(false)}
          className={cn(pill, "bg-foreground text-background hover:opacity-90")}
        >
          Done
        </button>
      </div>
      <div className="rounded-full bg-black/60 px-3 py-1 text-[11px] text-white backdrop-blur">
        {flash ?? "Tap, lasso or drag a box over a locked item"}
      </div>
    </div>
  );
}

/** The Select tool menu's switch into (and out of) locked-items mode. */
export function LockedModeMenuItem({ onDone }: { onDone: () => void }) {
  const lockedMode = useWhiteboard((s) => s.lockedMode);
  const count = useWhiteboard((s) => {
    const b = s.boards.find((x) => x.id === s.activeBoardId);
    return b ? getBoardElements(b).filter((el) => el.locked && el.type !== "connection").length : 0;
  });
  return (
    <button
      onClick={() => {
        useWhiteboard.getState().setLockedMode(!lockedMode);
        onDone();
      }}
      className={cn(
        "mt-0.5 flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-[12px]",
        lockedMode ? "bg-amber-500/15 text-amber-700 dark:text-amber-300" : "hover:bg-muted"
      )}
    >
      {lockedMode ? <LockOpen size={15} /> : <Lock size={15} />}
      <span className="flex-1 text-left">{lockedMode ? "Leave locked items" : "Locked items…"}</span>
      <span className="text-[10px] text-muted-foreground">{count}</span>
    </button>
  );
}
