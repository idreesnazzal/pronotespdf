"use client";

/**
 * Canvas Context Menu
 * ===================
 * Right-click menu for canvas elements.
 * Provides quick access to: bring forward/back, duplicate, delete, edit style.
 *
 * `disabled` exists because Radix opens this menu on a 700ms LONG PRESS for
 * any pointer that is not a mouse — which on a tablet means a hand resting on
 * the glass opens it uninvited, and a stylus paused mid-thought does too
 * (Radix's own test is `pointerType !== "mouse"`, so it lumps pens in with
 * fingers). The trigger sits directly on the canvas <svg>, so the canvas'
 * palm rejection cannot reach it; the canvas disarms it through this prop
 * instead. Radix clears any pending timer the moment `disabled` flips true.
 */

import React from "react";
import {
  ContextMenu,
  ContextMenuContent,
  ContextMenuItem,
  ContextMenuSeparator,
  ContextMenuTrigger,
  ContextMenuSub,
  ContextMenuSubContent,
  ContextMenuSubTrigger,
} from "@/components/ui/context-menu";
import { useWhiteboard } from "@/store/whiteboard";
import {
  BringToFront,
  SendToBack,
  ArrowUp,
  ArrowDown,
  Copy,
  Trash2,
  Pencil,
} from "lucide-react";

export function CanvasContextMenu({
  children,
  elementId,
  disabled = false,
}: {
  children: React.ReactNode;
  elementId: string | null;
  /** Suppress the menu entirely — see the note above on long-press opening. */
  disabled?: boolean;
}) {
  const bringToFront = useWhiteboard((s) => s.bringToFront);
  const sendToBack = useWhiteboard((s) => s.sendToBack);
  const bringForward = useWhiteboard((s) => s.bringForward);
  const sendBackward = useWhiteboard((s) => s.sendBackward);
  const deleteElements = useWhiteboard((s) => s.deleteElements);
  const duplicateBoard = useWhiteboard((s) => s.duplicateBoard);
  const selectedIds = useWhiteboard((s) => s.selectedIds);

  // Use either the right-clicked element or the current selection
  const targetIds = elementId ? [elementId] : selectedIds;

  return (
    <ContextMenu>
      <ContextMenuTrigger asChild disabled={disabled}>
        {children}
      </ContextMenuTrigger>
      <ContextMenuContent className="w-48">
        <ContextMenuItem
          disabled={targetIds.length === 0}
          onClick={() => bringForward(targetIds)}
        >
          <ArrowUp size={14} className="mr-2" /> Bring Forward
        </ContextMenuItem>
        <ContextMenuItem
          disabled={targetIds.length === 0}
          onClick={() => sendBackward(targetIds)}
        >
          <ArrowDown size={14} className="mr-2" /> Send Backward
        </ContextMenuItem>
        <ContextMenuItem
          disabled={targetIds.length === 0}
          onClick={() => bringToFront(targetIds)}
        >
          <BringToFront size={14} className="mr-2" /> Bring to Front
        </ContextMenuItem>
        <ContextMenuItem
          disabled={targetIds.length === 0}
          onClick={() => sendToBack(targetIds)}
        >
          <SendToBack size={14} className="mr-2" /> Send to Back
        </ContextMenuItem>
        <ContextMenuSeparator />
        <ContextMenuItem
          disabled={targetIds.length === 0}
          onClick={() => deleteElements(targetIds, true)}
          className="text-destructive focus:text-destructive"
        >
          <Trash2 size={14} className="mr-2" /> Delete
        </ContextMenuItem>
      </ContextMenuContent>
    </ContextMenu>
  );
}
