"use client";

/**
 * One Select button, three shapes.
 *
 * Rectangle, freeform lasso, and Samsung-style strict encircle (a closed
 * hand-drawn loop that only takes fully enclosed content) do the same job —
 * pick things up — and differ only in the shape you draw, so they share one
 * button with that choice inside it, the way the Shapes button works.
 *
 * A tap selects IMMEDIATELY with whichever shape you used last; only the
 * small chevron opens the menu, and a long-press cycles the three shapes
 * (the chevron is a tiny target for a fingertip or S Pen, and double-tap
 * never reaches a button on Android). The same three live in
 * Settings > Touch & stylus. The menu also holds what the shape picks up
 * (handwriting / text / shapes / images) and Select All, which obeys the
 * same filter.
 *
 * And the Screenshot switch: while it is on, the same box or loop takes a
 * PICTURE of the area - ink, pictures, the paper, the PDF page - instead of
 * picking up objects, for copying, sharing or saving to the gallery. It is a
 * switch on this tool, not a tool of its own, because it is the same gesture
 * aimed at what you SEE rather than at objects. The button wears a camera
 * badge while it is on, so Select can never silently stop selecting.
 */

import React from "react";
import {
  Camera,
  Check,
  ChevronDown,
  CircleDashed,
  Image as ImageIcon,
  LassoSelect,
  ListChecks,
  PenLine,
  Shapes,
  SquareDashedMousePointer,
  Type,
} from "lucide-react";
import { useWhiteboard } from "@/store/whiteboard";
import { useCapture } from "@/store/capture";
import {
  effectiveSelectFilter,
  SELECT_CATEGORIES,
  type SelectCategory,
} from "@/lib/whiteboard/types";
import { useLongPress } from "@/hooks/use-long-press";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";
import { flyoutSide } from "./DockControls";
import { LockedModeMenuItem } from "./LockedModeBar";

/**
 * The two select shapes, in long-press cycle order.
 *
 * There were briefly three, with "Encircle" as its own shape — but drawing a
 * loop that takes only what it fully contains is the SAME gesture as drawing a
 * loop that takes whatever it touches. The difference is a rule, not a shape,
 * and Samsung Notes has it exactly here: one Lasso, one Rectangle, and a
 * switch called "Include partially selected objects".
 */
export type SelectShape = "rectangle" | "lasso";

const SHAPES: Array<{ shape: SelectShape; label: string; hint: string; icon: typeof LassoSelect }> = [
  { shape: "rectangle", label: "Rectangle", hint: "Drag a box (V)", icon: SquareDashedMousePointer },
  { shape: "lasso", label: "Lasso", hint: "Draw around it (Q)", icon: LassoSelect },
];

const CATEGORY_UI: Record<SelectCategory, { label: string; icon: typeof PenLine }> = {
  ink: { label: "Handwriting", icon: PenLine },
  text: { label: "Text & notes", icon: Type },
  shapes: { label: "Shapes", icon: Shapes },
  images: { label: "Images", icon: ImageIcon },
};

const LAST_SHAPE_KEY = "pronotes:lastSelectMode";

function readLastShape(): SelectShape {
  try {
    const v = localStorage.getItem(LAST_SHAPE_KEY);
    if (v === "lasso" || v === "rectangle") return v;
    // Saves from when Encircle was its own shape, and older ones that stored
    // the tool id, both mean a loop / a box.
    if (v === "encircle") return "lasso";
    if (v === "select") return "rectangle";
  } catch {
    /* a remembered preference is a convenience, never a requirement */
  }
  return "rectangle";
}

export function SelectToolButton({ vertical }: { vertical: boolean }) {
  const tool = useWhiteboard((s) => s.tool);
  const setTool = useWhiteboard((s) => s.setTool);
  const lassoStrict = useWhiteboard((s) => s.lassoStrict);
  const setLassoStrict = useWhiteboard((s) => s.setLassoStrict);
  const selectAll = useWhiteboard((s) => s.selectAll);
  const savedFilter = useWhiteboard((s) => s.touchSettings.selectFilter);
  const setTouchSettings = useWhiteboard((s) => s.setTouchSettings);
  const toolbarPosition = useWhiteboard((s) => s.toolbarPosition);
  const clearSelection = useWhiteboard((s) => s.clearSelection);
  const flyout = flyoutSide(toolbarPosition);
  const screenshotMode = useCapture((s) => s.screenshotMode);

  const [lastShape, setLastShape] = React.useState<SelectShape>("rectangle");
  const [open, setOpen] = React.useState(false);

  // Read after mount: localStorage is not there during the static export.
  React.useEffect(() => setLastShape(readLastShape()), []);

  /** Each shape is simply its own tool; strictness is separate. */
  const applyShape = React.useCallback(
    (shape: SelectShape) => setTool(shape === "rectangle" ? "select" : "lasso"),
    [setTool]
  );

  // The keyboard (V / Q) and Settings change the shape too; follow them so the
  // button shows what you will actually get.
  const liveShape: SelectShape | null =
    tool === "select" ? "rectangle" : tool === "lasso" ? "lasso" : null;
  React.useEffect(() => {
    if (!liveShape) return;
    setLastShape(liveShape);
    try {
      localStorage.setItem(LAST_SHAPE_KEY, liveShape);
    } catch {
      /* a remembered preference is a convenience, never a requirement */
    }
  }, [liveShape]);

  const active = tool === "select" || tool === "lasso";
  const shown: SelectShape = liveShape ?? lastShape;
  const ShownIcon = SHAPES.find((m) => m.shape === shown)!.icon;
  const nextShape: SelectShape = shown === "rectangle" ? "lasso" : "rectangle";
  const nextLabel = SHAPES.find((m) => m.shape === nextShape)!.label;
  // The shape cycles on long-press: the chevron is a tiny target for a
  // fingertip or S Pen, and double-tap never reaches a button on Android —
  // the same reason the pen picker opens on long-press.
  const modeLongPress = useLongPress(() => applyShape(nextShape));
  const filter = effectiveSelectFilter(savedFilter);
  const filtered = filter.size < SELECT_CATEGORIES.length;

  const toggleCategory = (c: SelectCategory) => {
    const next = new Set(filter);
    if (next.has(c)) {
      // Never let the last one go: a filter that matches nothing makes the
      // tool look broken, which is worse than refusing the click.
      if (next.size === 1) return;
      next.delete(c);
    } else {
      next.add(c);
    }
    setTouchSettings({ selectFilter: SELECT_CATEGORIES.filter((k) => next.has(k)) });
  };

  const activeClass = "bg-primary text-primary-foreground shadow-sm";
  const idleClass = "hover:bg-muted text-muted-foreground hover:text-foreground";

  return (
    <div
      className={cn(
        "flex rounded-xl transition-all",
        vertical ? "flex-col items-center" : "items-center",
        active ? activeClass : idleClass
      )}
    >
      <Tooltip>
        <TooltipTrigger asChild>
          <button
            {...modeLongPress.handlers}
            onClick={() => {
              // A long press already switched the shape; don't also re-select.
              if (modeLongPress.firedRef.current) return;
              applyShape(shown);
            }}
            aria-label={`Select — ${SHAPES.find((m) => m.shape === shown)!.label}`}
            className={cn(
              "relative p-2.5",
              vertical ? "rounded-t-xl" : "rounded-l-xl",
              !active && "hover:bg-muted"
            )}
          >
            <ShownIcon size={18} />
            {/* A dot says "you are only picking up some things", so a filter
                left on from yesterday cannot quietly confuse you. */}
            {filtered && !screenshotMode && (
              <span className="absolute right-1.5 top-1.5 h-1.5 w-1.5 rounded-full bg-amber-500" />
            )}
            {/* Screenshot mode is on: this tool takes pictures, not objects. */}
            {screenshotMode && (
              <span
                data-screenshot-badge
                className="absolute -bottom-0.5 -right-0.5 flex h-[15px] w-[15px] items-center justify-center rounded-full bg-gradient-to-br from-indigo-500 to-violet-500 text-white shadow ring-2 ring-white dark:ring-zinc-900"
              >
                <Camera size={9} strokeWidth={2.5} />
              </span>
            )}
          </button>
        </TooltipTrigger>
        <TooltipContent side={flyout}>
          {screenshotMode ? "Screenshot" : "Select"} — {SHAPES.find((m) => m.shape === shown)!.label}
          <span className="block text-[10px] opacity-70">Long-press for {nextLabel}</span>
        </TooltipContent>
      </Tooltip>

      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <button
            aria-label="Selection options"
            className={cn(
              "flex items-center justify-center",
              vertical ? "w-full rounded-b-xl pb-1.5" : "self-stretch rounded-r-xl pr-1.5 pl-0.5",
              !active && "hover:bg-muted"
            )}
          >
            <ChevronDown size={12} className="opacity-60" />
          </button>
        </PopoverTrigger>

        <PopoverContent side={flyout} align="start" className="w-64 p-2">
          <p className="px-1.5 pb-1 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
            Shape — tip: long-press the button to switch
          </p>
          <div className="grid grid-cols-2 gap-1">
            {SHAPES.map(({ shape, label, hint, icon: Icon }) => {
              const isCurrent = shown === shape && active;
              return (
                <button
                  key={shape}
                  onClick={() => {
                    applyShape(shape);
                    setOpen(false);
                  }}
                  aria-pressed={isCurrent}
                  className={cn(
                    "flex flex-col items-center gap-1 rounded-lg px-2 py-2 text-center transition-colors",
                    isCurrent ? "bg-primary text-primary-foreground" : "hover:bg-muted"
                  )}
                >
                  <Icon size={20} />
                  <span className="text-[11px] font-medium leading-none">{label}</span>
                  <span
                    className={cn(
                      "text-[9px] leading-none",
                      isCurrent ? "text-primary-foreground/80" : "text-muted-foreground"
                    )}
                  >
                    {hint}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Screenshot: the same box or loop takes a picture instead of
              objects. First among the switches because it changes what the
              tool DOES; the ones below only tune what it picks up. */}
          <button
            onClick={() => {
              const on = !screenshotMode;
              useCapture.getState().setScreenshotMode(on);
              if (on) {
                // Handles left on screen would suggest the selection still
                // works; and the mode acts through Select, so make it the tool.
                clearSelection();
                if (!active) applyShape(shown);
              }
              setOpen(false);
            }}
            role="switch"
            aria-checked={screenshotMode}
            className={cn(
              "mt-1.5 flex w-full items-start gap-2 rounded-lg border px-1.5 py-2 text-left transition-colors",
              screenshotMode
                ? "border-indigo-500/50 bg-indigo-500/10"
                : "border-transparent hover:bg-muted"
            )}
          >
            <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-md bg-gradient-to-br from-indigo-500 to-violet-500 text-white shadow-sm shadow-indigo-500/30">
              <Camera size={13} />
            </span>
            <span className="min-w-0 flex-1">
              <span className="block text-[11px] font-medium leading-tight">Screenshot</span>
              <span className="block text-[9px] leading-tight text-muted-foreground">
                {screenshotMode
                  ? "On: the box or loop takes a picture to copy, share or save"
                  : "Take a picture of an area - PDF, pictures and ink"}
              </span>
            </span>
            <span
              className={cn(
                "mt-0.5 h-4 w-7 shrink-0 rounded-full p-0.5 transition-colors",
                screenshotMode ? "bg-indigo-500" : "bg-muted-foreground/30"
              )}
            >
              <span
                className={cn(
                  "block h-3 w-3 rounded-full bg-white transition-transform",
                  screenshotMode ? "translate-x-3" : "translate-x-0"
                )}
              />
            </span>
          </button>

          {/* Samsung's own switch, under its own name: with it on the loop
              takes anything it touches, with it off only what it encloses
              completely. A rule about the loop, not a second kind of loop. */}
          <button
            onClick={() => setLassoStrict(!lassoStrict)}
            role="switch"
            aria-checked={!lassoStrict}
            className="mt-1 flex w-full items-start gap-2 rounded-lg px-1.5 py-2 text-left hover:bg-muted"
          >
            <CircleDashed size={14} className="mt-0.5 shrink-0 opacity-70" />
            <span className="min-w-0 flex-1">
              <span className="block text-[11px] font-medium leading-tight">
                Include partially selected
              </span>
              <span className="block text-[9px] leading-tight text-muted-foreground">
                {lassoStrict
                  ? "Only what the loop fully encloses"
                  : "Anything the loop touches comes along"}
              </span>
            </span>
            <span
              className={cn(
                "mt-0.5 h-4 w-7 shrink-0 rounded-full p-0.5 transition-colors",
                lassoStrict ? "bg-muted-foreground/30" : "bg-primary"
              )}
            >
              <span
                className={cn(
                  "block h-3 w-3 rounded-full bg-white transition-transform",
                  lassoStrict ? "translate-x-0" : "translate-x-3"
                )}
              />
            </span>
          </button>

          <p className="mt-2 px-1.5 pb-1 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
            Pick up
          </p>
          <div className="grid grid-cols-2 gap-1">
            {SELECT_CATEGORIES.map((c) => {
              const on = filter.has(c);
              const { label, icon: Icon } = CATEGORY_UI[c];
              const lastOne = on && filter.size === 1;
              return (
                <button
                  key={c}
                  onClick={() => toggleCategory(c)}
                  title={lastOne ? "At least one kind must stay on" : undefined}
                  aria-pressed={on}
                  className={cn(
                    "flex items-center gap-1.5 rounded-lg border px-2 py-1.5 text-[11px] transition-colors",
                    on
                      ? "border-primary/40 bg-primary/10 text-foreground"
                      : "border-border text-muted-foreground hover:bg-muted",
                    lastOne && "cursor-not-allowed"
                  )}
                >
                  <Icon size={13} />
                  <span className="flex-1 text-left">{label}</span>
                  {on && <Check size={12} className="text-primary" />}
                </button>
              );
            })}
          </div>
          {filtered && (
            <button
              onClick={() => setTouchSettings({ selectFilter: [...SELECT_CATEGORIES] })}
              className="mt-1 w-full rounded-md px-1.5 py-1 text-left text-[10px] text-primary hover:bg-primary/10"
            >
              Pick up everything again
            </button>
          )}

          <div className="mt-2 border-t border-border/60 pt-2">
            <button
              onClick={() => {
                if (!active) applyShape(shown);
                selectAll();
                setOpen(false);
              }}
              className="flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-[12px] hover:bg-muted"
            >
              <ListChecks size={15} />
              <span className="flex-1 text-left">
                Select all {filtered ? "matching" : ""} on this page
              </span>
              <span className="text-[10px] text-muted-foreground">Ctrl+A</span>
            </button>
            <LockedModeMenuItem onDone={() => setOpen(false)} />
          </div>
        </PopoverContent>
      </Popover>
    </div>
  );
}
