"use client";

/**
 * Sidebar (Folder & Board Tree)
 * ==============================
 * Microsoft Whiteboard-style left sidebar showing:
 * - A tree of folders and boards
 * - Create / rename / delete / duplicate boards
 * - Create / rename / delete folders
 * - Drag-and-drop to move boards and folders: hold a row, then drop it on a
 *   folder (or on empty tree space for the top level)
 * - Active board highlighting
 *
 * Tree rendering:
 * - Folders can be nested (parentId chains)
 * - Each folder can be expanded/collapsed
 * - Boards are leaf nodes inside folders (or at root)
 *
 * Touch rules (pointer events, never HTML5 drag-and-drop):
 * - A tap still opens/toggles; only a 300ms hold picks a row up, and moving
 *   first cancels the pickup so the tree keeps scrolling from the row.
 * - Dropping a folder into itself or its own subtree is rejected (the store
 *   guards it too — a parentId cycle would hang every tree walk).
 * - Holding over a collapsed folder springs it open so its children accept drops.
 *
 * Future debugging notes:
 * - All mutations go through the Zustand store; sidebar is purely a view
 * - Empty folders are allowed and shown with a muted hint
 */

import React, { useRef, useState } from "react";
import {
  Folder as FolderIcon,
  FolderInput,
  FolderOpen,
  FileText,
  Plus,
  BookOpen,
  NotebookText,
  Presentation,
  Files,
  FileUp,
  ImagePlus,
  Columns2,
  FolderPlus,
  MoreHorizontal,
  Trash2,
  Pencil,
  Copy,
  ChevronRight,
  ChevronDown,
  PanelLeftClose,
  Search,
  Star,
  Link2,
  Download,
  ArrowUpDown,
  CheckSquare,
  Square,
  X,
} from "lucide-react";
import { useWhiteboard } from "@/store/whiteboard";
import { getPages, isNotebook } from "@/lib/whiteboard/notebook";
import { FOLDER_COLORS, type Board, type Folder } from "@/lib/whiteboard/types";
import { sortItems } from "@/lib/whiteboard/sort";
import {
  buildExportBlob,
  zipExportFiles,
  type ExportFormat,
} from "@/lib/whiteboard/export";
import { saveBlob } from "@/lib/whiteboard/share";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  ContextMenu,
  ContextMenuContent,
  ContextMenuItem,
  ContextMenuSeparator,
  ContextMenuTrigger,
} from "@/components/ui/context-menu";
import { cn } from "@/lib/utils";
import { MoveToDialog, BatchMoveDialog } from "./MoveToDialog";
import { DuplicateNotebookModal } from "./DuplicateNotebookModal";
import { importPicturesAsNotebook } from "./FileDropZone";
import { DOCUMENT_ACCEPT } from "@/lib/whiteboard/officeImport";
import { trashWithUndo } from "./trashToast";

// ---------------------------------------------------------------------------
// Tree drag & drop: hold a row, drop it on a folder (or empty space = root)
// ---------------------------------------------------------------------------

/** What a drag carries: a board/notebook, or a whole folder. */
type SidebarDragPayload = { kind: "board" | "folder"; id: string };

/** Drop-target ids: a folder id, or "root" for the top level. */
const ROOT_DROP_ID = "root";

/** Hold still this long to pick a row up (a tap still opens/toggles). */
const TREE_HOLD_MS = 300;
/** Two taps within this open the full row menu (pen and finger alike). */
const DOUBLE_TAP_MS = 350;
/** Moving further first means a scroll, which cancels the pickup. */
const TREE_HOLD_PX = 24;
/** Dragging within this far of the tree's top/bottom edge scrolls it. */
const TREE_SCROLL_EDGE_PX = 64;
const TREE_SCROLL_STEP_PX = 24;
/** Hovering a collapsed folder this long springs it open. */
const SPRING_OPEN_MS = 600;

interface SidebarDrag {
  drag: SidebarDragPayload | null;
  dropTarget: string | null;
  pickUp: (p: SidebarDragPayload) => void;
}

const SidebarDragContext = React.createContext<SidebarDrag>({
  drag: null,
  dropTarget: null,
  pickUp: () => undefined,
});

/** Selection ids for folders live next to board ids with a prefix. */
export const FOLDER_SEL_PREFIX = "folder:";

export function splitSelection(ids: string[]): { boardIds: string[]; folderIds: string[] } {
  const boardIds: string[] = [];
  const folderIds: string[] = [];
  for (const id of ids) {
    if (id.startsWith(FOLDER_SEL_PREFIX)) folderIds.push(id.slice(FOLDER_SEL_PREFIX.length));
    else boardIds.push(id);
  }
  return { boardIds, folderIds };
}

/** True for notebooks imported from a PDF (drawn over document pages). */
export function isPdfNotebook(board: Board): boolean {
  if (!isNotebook(board)) return false;
  if ((board.pdfDocIds?.length ?? 0) > 0) return true;
  return getPages(board).some((p) => !!p.pdf);
}

/**
 * One icon per document kind, everywhere: canvas boards, notebooks, PDFs and
 * folders each keep their own glyph in rows, menus and dialogs. (Rows used to
 * show FileText for everything and "New Board" a bare "+".)
 */
export function BoardKindIcon({ board, size = 14 }: { board: Board; size?: number }) {
  if (isPdfNotebook(board)) {
    return <FileText size={size} className="shrink-0 text-red-400" />;
  }
  if (isNotebook(board)) {
    return <NotebookText size={size} className="shrink-0" style={{ color: board.color || "#3b82f6" }} />;
  }
  // A canvas board is a whiteboard, so it wears one — not a pencil, which
  // read as "edit" (and the old "New Board" row showed a bare "+").
  return <Presentation size={size} className="shrink-0" style={{ color: board.color || "#3b82f6" }} />;
}

/** True when `id` sits inside `ancestorId`'s subtree (invalid drop styling). */
export function isDescendantFolder(folders: Folder[], ancestorId: string, id: string): boolean {
  let cursor = folders.find((f) => f.id === id)?.parentId ?? null;
  const seen = new Set<string>();
  while (cursor) {
    if (cursor === ancestorId) return true;
    if (seen.has(cursor)) break;
    seen.add(cursor);
    cursor = folders.find((f) => f.id === cursor)?.parentId ?? null;
  }
  return false;
}

export { sortItems } from "@/lib/whiteboard/sort";

/**
 * Press-and-hold a tree row: holding still selects (entering multi-select
 * with the row chosen when coming from outside); moving after the hold
 * picks the row up for drag-and-drop instead. Moving FIRST cancels (the
 * tree still scrolls from the row). Returns props for the row root plus a
 * click suppressor for the tap that follows either gesture.
 */
function useHoldRow({ onHold, onDragStart }: { onHold: () => void; onDragStart: () => void }) {
  const timer = React.useRef<ReturnType<typeof setTimeout> | null>(null);
  const start = React.useRef<{ x: number; y: number } | null>(null);
  const suppressClick = React.useRef(false);
  const held = React.useRef(false);
  const dragged = React.useRef(false);
  const cancel = React.useCallback(() => {
    if (timer.current) clearTimeout(timer.current);
    timer.current = null;
    start.current = null;
  }, []);
  React.useEffect(() => cancel, [cancel]);
  return {
    suppressClick,
    holdHandlers: {
      onPointerDown: (e: React.PointerEvent) => {
        if (!e.isPrimary) return;
        if ((e.target as Element).closest?.("[data-hold-ignore]")) return;
        suppressClick.current = false;
        held.current = false;
        dragged.current = false;
        start.current = { x: e.clientX, y: e.clientY };
        timer.current = setTimeout(() => {
          timer.current = null;
          held.current = true;
          suppressClick.current = true;
          try {
            navigator.vibrate?.(15);
          } catch {
            /* haptic is a courtesy, never required */
          }
          onHold();
        }, TREE_HOLD_MS);
      },
      onPointerMove: (e: React.PointerEvent) => {
        const s = start.current;
        if (!s) return;
        if (Math.hypot(e.clientX - s.x, e.clientY - s.y) <= TREE_HOLD_PX) return;
        if (timer.current) {
          // Moved first: a scroll, never a pickup.
          cancel();
          return;
        }
        if (held.current && !dragged.current) {
          dragged.current = true;
          onDragStart();
        }
      },
      onPointerUp: cancel,
      onPointerCancel: cancel,
    },
  };
}

/**
 * What the sidebar shows about each board, as one string. Strokes do not
 * change it, so writing never re-renders the sidebar; renaming, moving,
 * starring or adding a board does.
 *
 * For "Recently updated" sorting, we add the sorted order of notebook IDs to
 * this key, NOT their raw updatedAt times. Otherwise the sidebar redraws after
 * every pen stroke and the ~240ms freeze after each pen lift comes back.
 */
export function boardListKey(boards: Board[]): string {
  const sortedIds = [...boards]
    .sort((a, b) => (b.updatedAt || b.createdAt || 0) - (a.updatedAt || a.createdAt || 0))
    .map((b) => b.id)
    .join(",");

  const entries = boards
    .map((b) =>
      [b.id, b.name, b.folderId ?? "", b.starred ? 1 : 0, b.color ?? "", b.kind ?? "", (b.tags ?? []).join(",")].join(
        "\u0001"
      )
    )
    .join("\u0002");

  return `${sortedIds}\u0003${entries}`;
}

/**
 * A notebook's page count, with a pages glyph so it reads as pages. It used
 * to be the number of strokes and shapes inside ("1929"), which told the
 * reader nothing. Its own subscription, and a page count only changes when a
 * page is added or removed, so writing never re-renders it.
 */
function PageCount({ id }: { id: string }) {
  const n = useWhiteboard((s) => {
    const b = s.boards.find((x) => x.id === id);
    return b && isNotebook(b) ? getPages(b).length : 0;
  });
  if (!n) return null;
  return (
    <span
      className="flex shrink-0 items-center gap-0.5 text-[10px] tabular-nums text-muted-foreground"
      title={`${n} page${n === 1 ? "" : "s"}`}
    >
      <Files size={10} className="opacity-70" />
      {n}
    </span>
  );
}

/** One row of the New menu: a coloured icon, a name and what it is for. */
function NewMenuItem({
  icon,
  title,
  hint,
  onClick,
  disabled,
}: {
  icon: React.ReactNode;
  title: string;
  hint: string;
  onClick: () => void;
  disabled?: boolean;
}) {
  return (
    <DropdownMenuItem onClick={onClick} disabled={disabled} className="gap-3 rounded-lg px-2 py-2">
      <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-muted">{icon}</span>
      <span className="flex min-w-0 flex-col">
        <span className="text-[13px] font-medium leading-tight">{title}</span>
        <span className="truncate text-[11px] leading-tight text-muted-foreground">{hint}</span>
      </span>
    </DropdownMenuItem>
  );
}

/** A small section heading in the tree: Starred / Folders / Notes. */
function SectionLabel({ icon, children }: { icon?: React.ReactNode; children: React.ReactNode }) {
  return (
    <div className="flex items-center gap-1.5 px-2 pb-1 pt-3 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground first:pt-1">
      {icon}
      {children}
    </div>
  );
}

/**
 * Name-before-create dialog for the New menu. Mounts only while open, autofocuses,
 * Enter confirms and Escape cancels. `contextLabel` says where the item lands
 * ("Top level" or a folder name).
 */
export function NameDialog({
  open,
  title,
  defaultName,
  confirmLabel,
  contextLabel,
  onConfirm,
  onClose,
}: {
  open: boolean;
  title: string;
  defaultName: string;
  confirmLabel: string;
  contextLabel?: string;
  onConfirm: (name: string) => void;
  onClose: () => void;
}) {
  const [value, setValue] = React.useState(defaultName);
  React.useEffect(() => {
    if (open) setValue(defaultName);
  }, [open, defaultName]);
  if (!open) return null;
  const confirm = () => {
    const trimmed = value.trim();
    if (!trimmed) return;
    onConfirm(trimmed);
    onClose();
  };
  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-xs p-0 gap-0 overflow-hidden">
        <DialogHeader className="px-4 pb-2 pt-4 text-left">
          <DialogTitle className="text-base">{title}</DialogTitle>
          {contextLabel && <p className="text-xs text-muted-foreground">in {contextLabel}</p>}
        </DialogHeader>
        <div className="px-4 pb-2">
          <Input
            value={value}
            onChange={(e) => setValue(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") confirm();
              if (e.key === "Escape") onClose();
            }}
            autoFocus
            onFocus={(e) => e.target.select()}
            aria-label={title}
          />
        </div>
        <DialogFooter className="flex-row items-center justify-end gap-2 border-t border-border px-4 py-3">
          <Button variant="ghost" size="sm" onClick={onClose}>
            Cancel
          </Button>
          <Button size="sm" onClick={confirm} disabled={!value.trim()}>
            {confirmLabel}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/**
 * The selection actions, docked at the bottom of the sidebar while selecting.
 * Four equal buttons - icon over label, so all four fit the narrow sidebar
 * with finger-sized targets - and everything less common behind "More". The
 * count lives ONCE, in the header above; this bar used to repeat it.
 * Disabled (not hidden) while nothing is picked, so it never jumps about.
 */
function SelectionBar({
  boardIds,
  folderIds,
  boards,
  folders,
  busy,
  onDelete,
  onMove,
  onExport,
  onDuplicate,
  onStar,
  onRename,
  onCopyLink,
}: {
  boardIds: string[];
  folderIds: string[];
  boards: Board[];
  folders: Folder[];
  busy: string | null;
  onDelete: () => void;
  onMove: () => void;
  onExport: (format: ExportFormat) => void;
  onDuplicate: () => void;
  onStar: () => void;
  onRename: (kind: "board" | "folder", id: string) => void;
  onCopyLink: (id: string) => void;
}) {
  const total = boardIds.length + folderIds.length;
  const none = total === 0;
  const singleBoardId = boardIds.length === 1 && folderIds.length === 0 ? boardIds[0] : null;
  const singleFolderId = folderIds.length === 1 && boardIds.length === 0 ? folderIds[0] : null;
  const singleName =
    singleBoardId != null
      ? boards.find((b) => b.id === singleBoardId)?.name
      : singleFolderId != null
        ? folders.find((f) => f.id === singleFolderId)?.name
        : null;
  const allStarred = boardIds.length > 0 && boardIds.every((id) => boards.find((b) => b.id === id)?.starred);
  const cell =
    "flex h-12 min-w-0 flex-1 flex-col items-center justify-center gap-0.5 rounded-lg text-[10px] font-medium transition-colors disabled:pointer-events-none disabled:opacity-35";
  return (
    <div className="border-t border-sidebar-border bg-sidebar px-1.5 py-1.5 animate-in slide-in-from-bottom-2">
      <div className="flex items-stretch gap-1">
        <button
          type="button"
          className={cn(cell, "text-destructive hover:bg-destructive/10")}
          onClick={onDelete}
          disabled={none}
          title="Delete — you can Undo right after"
        >
          <Trash2 size={17} />
          Delete
        </button>
        <button
          type="button"
          className={cn(cell, "text-sidebar-foreground hover:bg-sidebar-accent")}
          onClick={onMove}
          disabled={none}
          title="Move to a folder"
        >
          <FolderInput size={17} />
          Move
        </button>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button
              type="button"
              className={cn(cell, "text-sidebar-foreground hover:bg-sidebar-accent")}
              disabled={boardIds.length === 0 || busy !== null}
              title={boardIds.length === 0 ? "Pick a notebook or board to export" : "Export as…"}
            >
              <Download size={17} />
              <span className="max-w-full truncate">{busy ?? "Export"}</span>
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent side="top" align="center" className="w-44">
            <div className="px-2 py-1 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
              {boardIds.length > 1 ? `${boardIds.length} files, as one .zip` : "Export as"}
            </div>
            {(["pdf", "png", "svg"] as ExportFormat[]).map((f) => (
              <DropdownMenuItem key={f} onClick={() => onExport(f)}>
                {f.toUpperCase()}
              </DropdownMenuItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button
              type="button"
              className={cn(cell, "text-sidebar-foreground hover:bg-sidebar-accent")}
              disabled={none}
              aria-label="More actions"
            >
              <MoreHorizontal size={17} />
              More
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent side="top" align="end" className="w-48">
            <DropdownMenuItem onClick={onDuplicate} disabled={boardIds.length === 0}>
              <Copy size={13} className="mr-2" /> Duplicate
            </DropdownMenuItem>
            <DropdownMenuItem onClick={onStar} disabled={boardIds.length === 0}>
              <Star size={13} className="mr-2" /> {allStarred ? "Unstar" : "Star"}
            </DropdownMenuItem>
            <DropdownMenuItem
              onClick={() => {
                if (singleBoardId) onRename("board", singleBoardId);
                else if (singleFolderId) onRename("folder", singleFolderId);
              }}
              disabled={singleName == null}
            >
              <Pencil size={13} className="mr-2" /> Rename
              {singleName == null && <span className="ml-auto text-[10px] text-muted-foreground">one item</span>}
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => singleBoardId && onCopyLink(singleBoardId)} disabled={singleBoardId === null}>
              <Link2 size={13} className="mr-2" /> Copy [[link]]
              {singleBoardId === null && <span className="ml-auto text-[10px] text-muted-foreground">one item</span>}
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  );
}

export function Sidebar() {
  const folders = useWhiteboard((s) => s.folders);
  // Every pen stroke replaces `boards`; the sidebar only needs the list. It
  // re-rendered - every row and folder, with their menus - after each stroke
  // (~240 ms on a real 20-notebook workspace, the freeze after each pen lift).
  const boardsKey = useWhiteboard((s) => boardListKey(s.boards));
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const boards = React.useMemo(() => useWhiteboard.getState().boards, [boardsKey]);
  const activeBoardId = useWhiteboard((s) => s.activeBoardId);
  const setActiveBoard = useWhiteboard((s) => s.setActiveBoard);
  const pdfInputRef = useRef<HTMLInputElement>(null);
  const [pdfBusy, setPdfBusy] = useState<string | null>(null);
  const [pdfError, setPdfError] = useState<string | null>(null);
  const toggleSidebar = useWhiteboard((s) => s.toggleSidebar);
  const [searchQuery, setSearchQuery] = React.useState("");

  const sidebarSortBy = useWhiteboard((s) => s.sidebarSortBy);
  const sidebarSortOrder = useWhiteboard((s) => s.sidebarSortOrder);
  const setSidebarSort = useWhiteboard((s) => s.setSidebarSort);
  const [multiSelectMode, setMultiSelectMode] = React.useState(false);
  // Board ids plus `folder:<id>` entries — one list, split at action time.
  const [selectedBatchIds, setSelectedBatchIds] = React.useState<string[]>([]);
  const [batchMoveOpen, setBatchMoveOpen] = React.useState(false);
  /** Folder the selection is scoped to (from its "..." menu), or null for all. */
  const [scopeFolderId, setScopeFolderId] = React.useState<string | null>(null);
  /** Single row awaiting inline rename ({ kind: "board" | "folder", id }). */
  const [renameRequest, setRenameRequest] = React.useState<{ kind: "board" | "folder"; id: string } | null>(null);
  const [batchBusy, setBatchBusy] = useState<string | null>(null);
  const [batchError, setBatchError] = useState<string | null>(null);
  const [nameDialog, setNameDialog] = React.useState<
    null | { kind: "board" | "notebook" | "folder"; folderId: string | null }
  >(null);
  /** Shared file inputs: folder menus set the target, then open the picker. */
  const imageInputRef = useRef<HTMLInputElement>(null);
  const importTargetFolder = React.useRef<string | null>(null);
  const [importBusy, setImportBusy] = useState<string | null>(null);

  // Fresh reads for the hold gesture, which fires 300 ms after the press.
  const multiSelectModeRef = React.useRef(multiSelectMode);
  multiSelectModeRef.current = multiSelectMode;

  const toggleBatchSelect = React.useCallback((boardId: string) => {
    setSelectedBatchIds((prev) =>
      prev.includes(boardId) ? prev.filter((id) => id !== boardId) : [...prev, boardId]
    );
  }, []);

  const toggleFolderSelect = React.useCallback((folderId: string) => {
    const key = FOLDER_SEL_PREFIX + folderId;
    setSelectedBatchIds((prev) =>
      prev.includes(key) ? prev.filter((id) => id !== key) : [...prev, key]
    );
  }, []);

  /**
   * Long-press entry: from outside, enters selection mode scoped nowhere with
   * just this row; inside, it ensures the row is selected (drag arms on move).
   */
  const holdRowSelect = React.useCallback((kind: "board" | "folder", id: string) => {
    const key = kind === "folder" ? FOLDER_SEL_PREFIX + id : id;
    if (!multiSelectModeRef.current) {
      multiSelectModeRef.current = true;
      setScopeFolderId(null);
      setMultiSelectMode(true);
      setSelectedBatchIds([key]);
    } else {
      setSelectedBatchIds((prev) => (prev.includes(key) ? prev : [...prev, key]));
    }
  }, []);

  const exitSelectMode = React.useCallback(() => {
    setMultiSelectMode(false);
    multiSelectModeRef.current = false;
    setSelectedBatchIds([]);
    setScopeFolderId(null);
  }, []);

  /** Batch export: one file straight out, several packed into one .zip. */
  const runBatchExport = React.useCallback(
    async (format: ExportFormat) => {
      const st = useWhiteboard.getState();
      const { boardIds } = splitSelection(selectedBatchIds);
      const targets = boardIds
        .map((id) => st.boards.find((b) => b.id === id))
        .filter((b) => b !== undefined);
      if (targets.length === 0) return;
      setBatchBusy("Exporting…");
      setBatchError(null);
      try {
        if (targets.length === 1) {
          const { blob, filename } = await buildExportBlob(targets[0], format, {}, st.customLinkTypes);
          await saveBlob(blob, filename);
        } else {
          const files: Array<{ filename: string; data: Uint8Array }> = [];
          for (const b of targets) {
            const { blob, filename } = await buildExportBlob(b, format, {}, st.customLinkTypes);
            files.push({ filename, data: new Uint8Array(await blob.arrayBuffer()) });
          }
          // Same-named boards would collide inside the zip; suffix extras.
          const seen = new Map<string, number>();
          for (const f of files) {
            const n = seen.get(f.filename) ?? 0;
            seen.set(f.filename, n + 1);
            if (n > 0) {
              const dot = f.filename.lastIndexOf(".");
              f.filename = `${f.filename.slice(0, dot)} (${n + 1})${f.filename.slice(dot)}`;
            }
          }
          // Copy into ArrayBuffer-backed bytes: fflate's view type is wider
          // than what Blob accepts.
          const zipped = new Uint8Array(zipExportFiles(files));
          const d = new Date();
          const stamp = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, "0")}${String(d.getDate()).padStart(2, "0")}`;
          await saveBlob(new Blob([zipped], { type: "application/zip" }), `pronotes-export-${stamp}.zip`);
        }
        setSelectedBatchIds([]);
      } catch (err) {
        setBatchError((err as Error).message || "Export failed.");
      } finally {
        setBatchBusy(null);
      }
    },
    [selectedBatchIds]
  );

  // --- tree drag & drop ------------------------------------------------------
  // State lives here; rows only pick up (via the context) while the window
  // listeners below track the pointer anywhere, even off the tree.
  const [drag, setDrag] = React.useState<SidebarDragPayload | null>(null);
  const [dropTarget, setDropTarget] = React.useState<string | null>(null);
  const dragRef = React.useRef(drag);
  dragRef.current = drag;
  const dropRef = React.useRef(dropTarget);
  dropRef.current = dropTarget;
  // Synchronous drag flag for the contextmenu killer below. State (`drag`)
  // arrives a render late; Radix's own long-press menu must die the moment a
  // pickup happens, not after React catches up.
  const dragActiveRef = React.useRef(false);
  const springTimer = React.useRef<ReturnType<typeof setTimeout> | null>(null);
  const scrollerRef = React.useRef<HTMLElement | null>(null);

  const clearSpring = React.useCallback(() => {
    if (springTimer.current) clearTimeout(springTimer.current);
    springTimer.current = null;
  }, []);
  React.useEffect(() => clearSpring, [clearSpring]);

  const pickUp = React.useCallback((p: SidebarDragPayload) => {
    dragActiveRef.current = true;
    scrollerRef.current = null; // re-measured on first move of each drag
    setDrag(p);
    setDropTarget(null);
  }, []);

  const moveDrag = React.useCallback((clientX: number, clientY: number) => {
    if (!dragRef.current) return;
    // Auto-scroll near the edges so a row can be dragged past the viewport.
    if (!scrollerRef.current) {
      scrollerRef.current = document.querySelector(
        "[data-radix-scroll-area-viewport]"
      ) as HTMLElement | null;
    }
    const scroller = scrollerRef.current;
    if (scroller) {
      const r = scroller.getBoundingClientRect();
      if (clientY < r.top + TREE_SCROLL_EDGE_PX) scroller.scrollTop -= TREE_SCROLL_STEP_PX;
      else if (clientY > r.bottom - TREE_SCROLL_EDGE_PX)
        scroller.scrollTop += TREE_SCROLL_STEP_PX;
    }
    const el = document.elementFromPoint(clientX, clientY);
    const zone = el?.closest?.("[data-drop-id]") as HTMLElement | null;
    const id = zone?.dataset.dropId ?? null;
    if (id === dropRef.current) return;
    setDropTarget(id);
    clearSpring();
    // Spring-open a collapsed folder held over, so its children take drops.
    if (id && id !== ROOT_DROP_ID) {
      const st = useWhiteboard.getState();
      const f = st.folders.find((x) => x.id === id);
      if (f && !f.expanded) {
        springTimer.current = setTimeout(() => st.toggleFolderExpanded(id), SPRING_OPEN_MS);
      }
    }
  }, [clearSpring]);

  const endDrag = React.useCallback(() => {
    clearSpring();
    const d = dragRef.current;
    const t = dropRef.current;
    scrollerRef.current = null;
    dragActiveRef.current = false;
    setDrag(null);
    setDropTarget(null);
    if (!d || !t) return;
    const st = useWhiteboard.getState();
    const folder = t === ROOT_DROP_ID ? null : t;
    if (d.kind === "board") {
      const b = st.boards.find((x) => x.id === d.id);
      if (b && (b.folderId ?? null) !== folder) st.moveBoard(d.id, folder);
    } else {
      const f = st.folders.find((x) => x.id === d.id);
      // The store rejects cycles, self-drops and ghosts; the equality check
      // here just skips a pointless save for an already-correct parent.
      if (f && (f.parentId ?? null) !== folder) st.moveFolder(d.id, folder);
    }
  }, [clearSpring]);

  const cancelDrag = React.useCallback(() => {
    clearSpring();
    scrollerRef.current = null;
    dragActiveRef.current = false;
    setDrag(null);
    setDropTarget(null);
  }, [clearSpring]);

  React.useEffect(() => {
    if (!drag) return;
    const move = (e: PointerEvent) => moveDrag(e.clientX, e.clientY);
    const up = () => endDrag();
    const cancel = () => cancelDrag();
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
    window.addEventListener("pointercancel", cancel);
    return () => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
      window.removeEventListener("pointercancel", cancel);
    };
  }, [drag, moveDrag, endDrag, cancelDrag]);

  // A drag that outlives the app's attention (home button, power key, alert)
  // would otherwise stick forever: no pointerup ever arrives, the contextmenu
  // killer stays armed, and every menu in the tree stops opening. Losing focus
  // cancels the drag — re-holding is cheap, a dead tree is not.
  React.useEffect(() => {
    const onBlur = () => cancelDrag();
    window.addEventListener("blur", onBlur);
    return () => window.removeEventListener("blur", onBlur);
  }, [cancelDrag]);

  // Radix opens its context menu on a ~700ms long-press — AFTER our 300ms
  // pickup. Without this, holding a row opens star/rename/duplicate/export on
  // top of the drag and swallows it. A window-level CAPTURE listener fires
  // before Radix ever sees the event; the ref (not state) is read so there is
  // no render delay to race. Row-level `disabled` props stay as backup.
  React.useEffect(() => {
    const kill = (e: Event) => {
      if (dragActiveRef.current) {
        e.preventDefault();
        e.stopPropagation();
      }
    };
    window.addEventListener("contextmenu", kill, true);
    return () => window.removeEventListener("contextmenu", kill, true);
  }, []);

  const dragCtx = React.useMemo(
    () => ({ drag, dropTarget, pickUp }),
    [drag, dropTarget, pickUp]
  );

  const rootFolders = React.useMemo(() => {
    const list = folders.filter((f) => !f.parentId || f.parentId === null);
    return sortItems(list, sidebarSortBy, sidebarSortOrder);
  }, [folders, sidebarSortBy, sidebarSortOrder]);

  // Filtered boards based on search, sorted by user preference
  const filteredBoards = React.useMemo(() => {
    let list = boards;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      list = boards.filter(
        (b) =>
          b.name.toLowerCase().includes(q) ||
          (Array.isArray(b.tags) && b.tags.some((t) => t.toLowerCase().includes(q)))
      );
    }
    return sortItems(list, sidebarSortBy, sidebarSortOrder);
  }, [boards, searchQuery, sidebarSortBy, sidebarSortOrder]);

  // Selection scope: a folder's direct contents, or the whole sidebar.
  const scopeFolder = scopeFolderId ? folders.find((f) => f.id === scopeFolderId) ?? null : null;
  const scopeAllIds = React.useMemo(() => {
    if (!scopeFolder) return filteredBoards.map((b) => b.id);
    const ids = boards.filter((b) => b.folderId === scopeFolder.id).map((b) => b.id);
    for (const f of folders) {
      if (f.parentId === scopeFolder.id) ids.push(FOLDER_SEL_PREFIX + f.id);
    }
    return ids;
  }, [scopeFolder, boards, folders, filteredBoards]);
  const allInScopeSelected =
    scopeAllIds.length > 0 && scopeAllIds.every((id) => selectedBatchIds.includes(id));
  const toggleSelectAllInScope = React.useCallback(() => {
    setSelectedBatchIds((prev) => {
      const all = scopeAllIdsRef.current;
      const hasAll = all.length > 0 && all.every((id) => prev.includes(id));
      if (hasAll) return prev.filter((id) => !all.includes(id));
      return [...prev, ...all.filter((id) => !prev.includes(id))];
    });
  }, []);
  const scopeAllIdsRef = React.useRef(scopeAllIds);
  scopeAllIdsRef.current = scopeAllIds;

  /**
   * Select inside one folder: the folder opens and selection mode starts,
   * scoped to it, with NOTHING picked - you choose, or tap "Select all" (which
   * then means all of this folder). It used to pre-select everything.
   */
  const selectFolderContents = React.useCallback((folderId: string) => {
    const st = useWhiteboard.getState();
    const f = st.folders.find((x) => x.id === folderId);
    if (f && !f.expanded) st.toggleFolderExpanded(folderId);
    multiSelectModeRef.current = true;
    setMultiSelectMode(true);
    setScopeFolderId(folderId);
    setSelectedBatchIds([]);
  }, []);

  /** Shared pickers: folder menus set the target, then open the same inputs. */
  const pickPdfFile = React.useCallback((folderId: string | null) => {
    importTargetFolder.current = folderId;
    pdfInputRef.current?.click();
  }, []);
  const pickImageFiles = React.useCallback((folderId: string | null) => {
    importTargetFolder.current = folderId;
    imageInputRef.current?.click();
  }, []);
  const handlePdfFile = React.useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    setPdfBusy("Opening…");
    setPdfError(null);
    try {
      // importPdfAsNotebook opens the new notebook itself, wherever it lands.
      // PDF, Word or PowerPoint: one store action converts what needs it.
      await useWhiteboard.getState().importDocumentAsNotebook(file, importTargetFolder.current, (p) =>
        setPdfBusy(p.total > 1 ? `${p.label}…` : p.label)
      );
    } catch (err) {
      // Import can fail for real reasons — an encrypted PDF, a corrupt file,
      // no storage left — and silence would look exactly like a slow import.
      setPdfError((err as Error).message || "Could not open that PDF.");
    } finally {
      setPdfBusy(null);
      importTargetFolder.current = null;
    }
  }, []);
  const [importError, setImportError] = useState<string | null>(null);
  const handleImageFiles = React.useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files ?? []);
    e.target.value = "";
    if (files.length === 0) return;
    const target = importTargetFolder.current;
    importTargetFolder.current = null;
    setImportBusy("Adding…");
    setImportError(null);
    try {
      await importPicturesAsNotebook(files, target);
    } catch (err) {
      setImportError((err as Error).message || "Could not import those pictures.");
    } finally {
      setImportBusy(null);
    }
  }, []);

  return (
    <div className="h-full w-64 flex flex-col bg-sidebar border-r border-sidebar-border">
      {/* Header */}
      <div className="flex items-center justify-between px-3 py-3 border-b border-sidebar-border">
        <div className="flex items-center gap-2">
          <img
            src="/favicon.png"
            alt="ProNotes Logo"
            className="w-5 h-5 rounded-md shadow-sm"
          />
          <h2 className="text-sm font-semibold tracking-tight text-sidebar-foreground">ProNotes</h2>
        </div>
        <Button variant="ghost" size="icon" className="h-7 w-7" onClick={toggleSidebar} title="Hide sidebar">
          <PanelLeftClose size={16} />
        </Button>
      </div>

      {/* Search + Sort + Multi-select + Action buttons */}
      <div className="p-2 border-b border-sidebar-border space-y-2">
        <div className="flex items-center gap-1">
          <div className="relative flex-1">
            <Search size={12} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search…"
              className="h-7 pl-7 text-xs"
            />
          </div>

          {/* Sort dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="h-7 w-7 text-muted-foreground hover:text-foreground shrink-0"
                title={`Sort: ${sidebarSortBy} (${sidebarSortOrder})`}
              >
                <ArrowUpDown size={13} />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48 text-xs">
              <div className="px-2 py-1 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
                Sort By
              </div>
              <DropdownMenuItem
                onClick={() =>
                  setSidebarSort(
                    "updated",
                    sidebarSortBy === "updated"
                      ? sidebarSortOrder === "asc"
                        ? "desc"
                        : "asc"
                      : "desc"
                  )
                }
              >
                <span className="flex-1">Last Updated</span>
                {sidebarSortBy === "updated" && (
                  <span className="text-[10px] font-medium text-primary ml-1">
                    {sidebarSortOrder === "desc" ? "↓ Recent" : "↑ Oldest"}
                  </span>
                )}
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={() =>
                  setSidebarSort(
                    "created",
                    sidebarSortBy === "created"
                      ? sidebarSortOrder === "asc"
                        ? "desc"
                        : "asc"
                      : "desc"
                  )
                }
              >
                <span className="flex-1">Date Created</span>
                {sidebarSortBy === "created" && (
                  <span className="text-[10px] font-medium text-primary ml-1">
                    {sidebarSortOrder === "desc" ? "↓ Newest" : "↑ Oldest"}
                  </span>
                )}
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={() =>
                  setSidebarSort(
                    "name",
                    sidebarSortBy === "name"
                      ? sidebarSortOrder === "asc"
                        ? "desc"
                        : "asc"
                      : "asc"
                  )
                }
              >
                <span className="flex-1">Name</span>
                {sidebarSortBy === "name" && (
                  <span className="text-[10px] font-medium text-primary ml-1">
                    {sidebarSortOrder === "asc" ? "A → Z" : "Z → A"}
                  </span>
                )}
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Multi-select toggle. Entering never pre-selects: you choose. */}
          <Button
            variant={multiSelectMode ? "secondary" : "ghost"}
            size="icon"
            className={cn(
              "h-7 w-7 shrink-0",
              multiSelectMode ? "text-primary bg-primary/15" : "text-muted-foreground hover:text-foreground"
            )}
            onClick={() => {
              if (multiSelectMode) exitSelectMode();
              else {
                setMultiSelectMode(true);
                multiSelectModeRef.current = true;
                setSelectedBatchIds([]);
                setScopeFolderId(null);
              }
            }}
            title={multiSelectMode ? "Exit multi-select mode" : "Select boards and folders"}
          >
            <CheckSquare size={13} />
          </Button>
        </div>

        {multiSelectMode ? (
          /* Selecting: ONE bar says how many, where, and offers Select all.
             New and Link step aside so nothing competes with the selection. */
          <div className="flex h-9 items-center gap-1 rounded-lg bg-primary/10 pl-1 pr-1 ring-1 ring-inset ring-primary/20">
            <button
              type="button"
              onClick={exitSelectMode}
              className="flex h-7 w-7 shrink-0 items-center justify-center rounded-md text-primary hover:bg-primary/15"
              aria-label="Stop selecting"
              title="Done"
            >
              <X size={15} />
            </button>
            <span className="min-w-0 flex-1 truncate text-[12px] font-semibold text-primary">
              {selectedBatchIds.length === 0 ? "Tap to select" : `${selectedBatchIds.length} selected`}
              {scopeFolder && <span className="font-normal opacity-80"> · {scopeFolder.name}</span>}
            </span>
            <button
              type="button"
              onClick={toggleSelectAllInScope}
              disabled={scopeAllIds.length === 0}
              className="h-7 shrink-0 rounded-md px-2 text-[11px] font-semibold text-primary hover:bg-primary/15 disabled:opacity-40"
            >
              {allInScopeSelected ? "Select none" : "Select all"}
            </button>
          </div>
        ) : (
          <div className="flex items-center gap-1.5">
            {/* ONE New button: every creatable/importable lives in its menu. */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button size="sm" className="h-9 flex-1 gap-1.5 text-xs" title="Create or import">
                  <Plus size={15} className="shrink-0" />
                  <span className="font-semibold">New</span>
                  <ChevronDown size={13} className="opacity-70" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" className="w-60 p-1.5">
                <NewMenuItem
                  icon={<NotebookText size={16} className="text-blue-500" />}
                  title="Notebook"
                  hint="Pages to write on"
                  onClick={() => setNameDialog({ kind: "notebook", folderId: null })}
                />
                <NewMenuItem
                  icon={<Presentation size={16} className="text-violet-500" />}
                  title="Board"
                  hint="An endless whiteboard"
                  onClick={() => setNameDialog({ kind: "board", folderId: null })}
                />
                <NewMenuItem
                  icon={<FolderPlus size={16} className="text-amber-500" />}
                  title="Folder"
                  hint="To group your notes"
                  onClick={() => setNameDialog({ kind: "folder", folderId: null })}
                />
                <DropdownMenuSeparator />
                <NewMenuItem
                  icon={<FileText size={16} className="text-red-500" />}
                  title={pdfBusy ?? "Open a document"}
                  hint="PDF, Word or PowerPoint - write on it"
                  onClick={() => pickPdfFile(null)}
                  disabled={pdfBusy !== null}
                />
                <NewMenuItem
                  icon={<ImagePlus size={16} className="text-emerald-500" />}
                  title={importBusy ?? "Import pictures"}
                  hint="Each picture becomes a page"
                  onClick={() => pickImageFiles(null)}
                  disabled={importBusy !== null}
                />
              </DropdownMenuContent>
            </DropdownMenu>
            {/* Linking files is a tool, not the main action: an icon button,
                where it used to be a full-width black bar louder than New. */}
            <Button
              variant="outline"
              size="icon"
              className="h-9 w-9 shrink-0"
              onClick={() => window.dispatchEvent(new CustomEvent("wb:open-link-manager"))}
              title="Link files"
              aria-label="Link files"
            >
              <Link2 size={15} />
            </Button>
          </div>
        )}
        <input
          ref={pdfInputRef}
          type="file"
          accept={DOCUMENT_ACCEPT}
          className="hidden"
          onChange={handlePdfFile}
        />
        <input
          ref={imageInputRef}
          type="file"
          accept="image/*"
          multiple
          className="hidden"
          onChange={handleImageFiles}
        />

        {(pdfError || importError) && (
          <p className="rounded-md border border-destructive/40 bg-destructive/10 px-2 py-1 text-[11px] leading-snug text-destructive">
            {pdfError ?? importError}
          </p>
        )}
      </div>

      {/* Tree */}
      <ScrollArea className="flex-1">
        <SidebarDragContext.Provider value={dragCtx}>
        <div
          data-drop-id={ROOT_DROP_ID}
          className={cn(
            "p-2 space-y-0.5 no-pan-x",
            dropTarget === ROOT_DROP_ID && "rounded-lg ring-2 ring-inset ring-emerald-500/60"
          )}
        >
          {/* Starred section */}
          {!searchQuery && boards.some((b) => b.starred) && (
            <>
              <SectionLabel icon={<Star size={10} className="fill-amber-400 text-amber-400" />}>Starred</SectionLabel>
              {sortItems(
                boards.filter((b) => b.starred),
                sidebarSortBy,
                sidebarSortOrder
              ).map((board) => (
                <BoardItem
                  key={board.id}
                  board={board}
                  isActive={board.id === activeBoardId}
                  onClick={() => setActiveBoard(board.id)}
                  depth={0}
                  multiSelectMode={multiSelectMode}
                  isSelected={selectedBatchIds.includes(board.id)}
                  onToggleSelect={toggleBatchSelect}
                  onHoldSelect={() => holdRowSelect("board", board.id)}
                  renameRequested={renameRequest?.kind === "board" && renameRequest.id === board.id}
                  onRenameHandled={() => setRenameRequest(null)}
                />
              ))}
            </>
          )}

          {/* Folders first, then the notes that live outside any folder. Each
              gets a heading: without one, loose notes sat straight under
              "Starred" and read as starred. */}
          {rootFolders.length > 0 && <SectionLabel>Folders</SectionLabel>}
          {rootFolders.map((folder) => (
            <FolderItem
              key={folder.id}
              folder={folder}
              folders={folders}
              boards={searchQuery ? filteredBoards : boards}
              activeBoardId={activeBoardId}
              depth={0}
              onSelectBoard={setActiveBoard}
              multiSelectMode={multiSelectMode}
              selectedBatchIds={selectedBatchIds}
              onToggleSelectBoard={toggleBatchSelect}
              onToggleSelectFolder={toggleFolderSelect}
              onHoldSelect={holdRowSelect}
              onSelectFolderContents={selectFolderContents}
              onImportHere={(kind, folderId) =>
                kind === "pdf" ? pickPdfFile(folderId) : pickImageFiles(folderId)
              }
              onNewHere={(kind, folderId) => setNameDialog({ kind, folderId })}
              renameRequest={renameRequest}
              onRenameHandled={() => setRenameRequest(null)}
            />
          ))}

          {/* Notes outside any folder. While searching, starred ones must
              appear here too - the Starred section is hidden during search. */}
          {(() => {
            const loose = filteredBoards.filter(
              (b) => b.folderId === null && (!b.starred || !!searchQuery.trim())
            );
            if (loose.length === 0) return null;
            return (
              <>
                <SectionLabel>{searchQuery.trim() ? "Results" : "Notes"}</SectionLabel>
                {loose.map((board) => (
                  <BoardItem
                    key={board.id}
                    board={board}
                    isActive={board.id === activeBoardId}
                    onClick={() => setActiveBoard(board.id)}
                    depth={0}
                    multiSelectMode={multiSelectMode}
                    isSelected={selectedBatchIds.includes(board.id)}
                    onToggleSelect={toggleBatchSelect}
                    onHoldSelect={() => holdRowSelect("board", board.id)}
                    renameRequested={renameRequest?.kind === "board" && renameRequest.id === board.id}
                    onRenameHandled={() => setRenameRequest(null)}
                  />
                ))}
              </>
            );
          })()}

          {folders.length === 0 && boards.length === 0 && (
            <div className="text-xs text-muted-foreground text-center py-8">
              No whiteboards yet.
              <br />
              Create one above.
            </div>
          )}
          {searchQuery.trim() !== "" &&
            filteredBoards.length === 0 &&
            !folders.some((f) => f.name.toLowerCase().includes(searchQuery.trim().toLowerCase())) && (
              <div className="text-xs text-muted-foreground text-center py-8">
                No matches for “{searchQuery.trim()}”.
              </div>
            )}
        </div>
        </SidebarDragContext.Provider>
      </ScrollArea>

      {/* Selection action bar: count, the three common actions, the rest in ⋯. */}
      {multiSelectMode && (
        <SelectionBar
          boardIds={splitSelection(selectedBatchIds).boardIds}
          folderIds={splitSelection(selectedBatchIds).folderIds}
          boards={boards}
          folders={folders}
          busy={batchBusy}
          onDelete={() => {
            const { boardIds, folderIds } = splitSelection(selectedBatchIds);
            trashWithUndo(boardIds, folderIds);
            setSelectedBatchIds([]);
          }}
          onMove={() => setBatchMoveOpen(true)}
          onExport={runBatchExport}
          onDuplicate={() => {
            const { boardIds } = splitSelection(selectedBatchIds);
            const st = useWhiteboard.getState();
            const made = st.batchDuplicateBoards(boardIds);
            if (made.length > 0) setSelectedBatchIds([]);
          }}
          onStar={() => {
            const { boardIds } = splitSelection(selectedBatchIds);
            useWhiteboard.getState().batchStarBoards(boardIds);
          }}
          onRename={(kind, id) => setRenameRequest({ kind, id })}
          onCopyLink={(id) => {
            const b = boards.find((x) => x.id === id);
            if (b) navigator.clipboard?.writeText(`[[${b.name}]]`).catch(() => {});
          }}
        />
      )}
      {batchError && (
        <p className="mx-2 mb-1 rounded-md border border-destructive/40 bg-destructive/10 px-2 py-1 text-[11px] leading-snug text-destructive">
          {batchError}
        </p>
      )}

      {/* Footer */}
      <div className="border-t border-sidebar-border p-2 text-xs text-muted-foreground">
        Auto-saved locally
      </div>

      {/* Batch Move Dialog */}
      <BatchMoveDialog
        open={batchMoveOpen}
        onClose={() => setBatchMoveOpen(false)}
        boardIds={splitSelection(selectedBatchIds).boardIds}
        folderIds={splitSelection(selectedBatchIds).folderIds}
        onMoved={exitSelectMode}
      />

      {/* Name-before-create for the New menu */}
      <NameDialog
        open={nameDialog !== null}
        title={
          nameDialog?.kind === "notebook"
            ? "New notebook"
            : nameDialog?.kind === "board"
              ? "New board"
              : "New folder"
        }
        defaultName={
          nameDialog?.kind === "notebook"
            ? "Untitled Notebook"
            : nameDialog?.kind === "board"
              ? "Untitled Board"
              : "New Folder"
        }
        confirmLabel="Create"
        contextLabel={
          nameDialog?.folderId ? folders.find((f) => f.id === nameDialog.folderId)?.name ?? "Top level" : "Top level"
        }
        onConfirm={(name) => {
          if (!nameDialog) return;
          const st = useWhiteboard.getState();
          if (nameDialog.kind === "board") setActiveBoard(st.createBoard(name, nameDialog.folderId));
          else if (nameDialog.kind === "notebook")
            setActiveBoard(st.createNotebook(name, nameDialog.folderId));
          else st.createFolder(name, nameDialog.folderId);
        }}
        onClose={() => setNameDialog(null)}
      />
    </div>
  );
}

// ============================================================================
// Folder item (recursive)
// ============================================================================

function FolderItem({
  folder,
  folders,
  boards,
  activeBoardId,
  depth,
  onSelectBoard,
  multiSelectMode,
  selectedBatchIds,
  onToggleSelectBoard,
  onToggleSelectFolder,
  onHoldSelect,
  onSelectFolderContents,
  onImportHere,
  onNewHere,
  renameRequest,
  onRenameHandled,
}: {
  folder: Folder;
  folders: Folder[];
  boards: Board[];
  activeBoardId: string | null;
  depth: number;
  onSelectBoard: (id: string) => void;
  multiSelectMode?: boolean;
  selectedBatchIds?: string[];
  onToggleSelectBoard?: (id: string) => void;
  onToggleSelectFolder?: (id: string) => void;
  /** Long-press entry + threaded pass-through (same callback at every level). */
  onHoldSelect?: (kind: "board" | "folder", id: string) => void;
  onSelectFolderContents?: (id: string) => void;
  onImportHere?: (kind: "pdf" | "pictures", folderId: string) => void;
  /** New notebook/board/folder in this folder - through the name dialog. */
  onNewHere?: (kind: "board" | "notebook" | "folder", folderId: string) => void;
  renameRequest?: { kind: "board" | "folder"; id: string } | null;
  onRenameHandled?: () => void;
}) {
  const toggleFolderExpanded = useWhiteboard((s) => s.toggleFolderExpanded);
  const renameFolder = useWhiteboard((s) => s.renameFolder);
  const setFolderColor = useWhiteboard((s) => s.setFolderColor);
  const sidebarSortBy = useWhiteboard((s) => s.sidebarSortBy);
  const sidebarSortOrder = useWhiteboard((s) => s.sidebarSortOrder);
  const wantRename = renameRequest?.kind === "folder" && renameRequest.id === folder.id;

  const [isRenaming, setIsRenaming] = React.useState(false);
  const [renameValue, setRenameValue] = React.useState(folder.name);
  // Double-tap (pen or finger, timed) opens the full row menu, same as BoardItem.
  const [menuOpen, setMenuOpen] = React.useState(false);
  const [moveOpen, setMoveOpen] = React.useState(false);
  const lastTap = React.useRef(0);

  // The batch bar's Rename lands here from anywhere in the tree.
  React.useEffect(() => {
    if (wantRename && !isRenaming) {
      setRenameValue(folder.name);
      setIsRenaming(true);
      onRenameHandled?.();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [wantRename]);

  const isFolderSelected = selectedBatchIds?.includes(FOLDER_SEL_PREFIX + folder.id) ?? false;

  const { drag, dropTarget, pickUp } = React.useContext(SidebarDragContext);
  const { suppressClick, holdHandlers } = useHoldRow({
    onHold: () => onHoldSelect?.("folder", folder.id),
    onDragStart: () => pickUp({ kind: "folder", id: folder.id }),
  });
  const isDragged = drag?.id === folder.id;
  // Dropping onto itself or its own subtree is rejected by the store; do not
  // promise it with a highlight either.
  const invalidTarget =
    !!drag &&
    drag.kind === "folder" &&
    (drag.id === folder.id || isDescendantFolder(folders, drag.id, folder.id));
  const isDropTarget = dropTarget === folder.id && !invalidTarget;

  const childFolders = React.useMemo(() => {
    const list = folders.filter((f) => f.parentId === folder.id);
    return sortItems(list, sidebarSortBy, sidebarSortOrder);
  }, [folders, folder.id, sidebarSortBy, sidebarSortOrder]);

  const childBoards = React.useMemo(() => {
    const list = boards.filter((b) => b.folderId === folder.id);
    return sortItems(list, sidebarSortBy, sidebarSortOrder);
  }, [boards, folder.id, sidebarSortBy, sidebarSortOrder]);

  const commitRename = () => {
    const trimmed = renameValue.trim();
    if (trimmed && trimmed !== folder.name) {
      renameFolder(folder.id, trimmed);
    } else {
      setRenameValue(folder.name);
    }
    setIsRenaming(false);
  };

  return (
    <>
    <ContextMenu>
      <ContextMenuTrigger asChild disabled={!!drag}>
        <div data-drop-id={folder.id}>
          {/* Folder row (select-none: a hold must pick the row up, not select its name) */}
          <div
            {...holdHandlers}
            className={cn(
              "flex items-center gap-1 px-2 py-1.5 rounded-md hover:bg-sidebar-accent cursor-pointer select-none text-sm group",
              isDragged && "opacity-40",
              isDropTarget && "ring-2 ring-inset ring-emerald-500/70 bg-emerald-500/10",
              isFolderSelected &&
                multiSelectMode &&
                "bg-primary/10 text-primary font-medium ring-1 ring-inset ring-primary/30"
            )}
            style={{ paddingLeft: `${depth * 12 + 8}px` }}
            onClick={() => {
              if (suppressClick.current) {
                suppressClick.current = false;
                return;
              }
              if (multiSelectMode) {
                onToggleSelectFolder?.(folder.id);
                return;
              }
              const now = Date.now();
              if (now - lastTap.current < DOUBLE_TAP_MS) {
                lastTap.current = 0;
                setMenuOpen(true);
                return;
              }
              lastTap.current = now;
              toggleFolderExpanded(folder.id);
            }}
            onContextMenu={(e) => {
              if (drag) e.preventDefault();
            }}
          >
            {multiSelectMode && (
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onToggleSelectFolder?.(folder.id);
                }}
                data-hold-ignore
                className="shrink-0 p-0.5 text-primary hover:text-primary/80 focus:outline-none"
                aria-label={isFolderSelected ? `Deselect folder ${folder.name}` : `Select folder ${folder.name}`}
              >
                {isFolderSelected ? (
                  <CheckSquare size={14} className="text-primary fill-primary/15" />
                ) : (
                  <Square size={14} className="text-muted-foreground/60 hover:text-foreground" />
                )}
              </button>
            )}
            {folder.expanded ? (
              <ChevronDown size={14} className="text-muted-foreground shrink-0" />
            ) : (
              <ChevronRight size={14} className="text-muted-foreground shrink-0" />
            )}
            {folder.expanded ? (
              <FolderOpen size={14} className="shrink-0" style={{ color: folder.color || "#f59e0b" }} />
            ) : (
              <FolderIcon size={14} className="shrink-0" style={{ color: folder.color || "#f59e0b" }} />
            )}
            {isRenaming ? (
              <Input
                value={renameValue}
                onChange={(e) => setRenameValue(e.target.value)}
                onBlur={commitRename}
                onKeyDown={(e) => {
                  if (e.key === "Enter") commitRename();
                  if (e.key === "Escape") {
                    setRenameValue(folder.name);
                    setIsRenaming(false);
                  }
                }}
                onClick={(e) => e.stopPropagation()}
                data-hold-ignore
                className="h-5 text-xs px-1 py-0"
                autoFocus
              />
            ) : (
              <span className="min-w-0 flex-1 truncate text-sidebar-foreground">{folder.name}</span>
            )}
            <DropdownMenu open={menuOpen} onOpenChange={setMenuOpen}>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  data-hold-ignore
                  className={cn("h-5 w-5 opacity-0 group-hover:opacity-100 show-on-touch shrink-0", multiSelectMode && "hidden")}
                  onClick={(e) => e.stopPropagation()}
                >
                  <MoreHorizontal size={12} />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56" onClick={(e) => e.stopPropagation()}>
                <DropdownMenuItem onClick={() => onSelectFolderContents?.(folder.id)}>
                  <CheckSquare size={12} className="mr-2" /> Select in this folder
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => onImportHere?.("pdf", folder.id)}>
                  <FileUp size={12} className="mr-2" /> Import document here
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => onImportHere?.("pictures", folder.id)}>
                  <ImagePlus size={12} className="mr-2" /> Import pictures here
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => onNewHere?.("notebook", folder.id)}>
                  <NotebookText size={12} className="mr-2" /> New notebook here
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => onNewHere?.("board", folder.id)}>
                  <Presentation size={12} className="mr-2" /> New board here
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => onNewHere?.("folder", folder.id)}>
                  <FolderPlus size={12} className="mr-2" /> New subfolder
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setMoveOpen(true)}>
                  <FolderInput size={12} className="mr-2" /> Move to…
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setIsRenaming(true)}>
                  <Pencil size={12} className="mr-2" /> Rename
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <div className="px-2 py-1.5">
                  <div className="text-xs text-muted-foreground mb-1.5">Folder color</div>
                  <div className="flex gap-1.5">
                    {FOLDER_COLORS.map((c) => (
                      <button
                        key={c}
                        className={cn(
                          "w-5 h-5 rounded-full border-2 transition-transform hover:scale-110",
                          (folder.color || "#f59e0b") === c ? "border-ring ring-1 ring-ring/30" : "border-white"
                        )}
                        style={{ backgroundColor: c }}
                        onClick={() => setFolderColor(folder.id, c)}
                      />
                    ))}
                  </div>
                </div>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  className="text-destructive focus:text-destructive"
                  onClick={() => trashWithUndo([], [folder.id])}
                  title="Deletes the folder; its boards move to the top level. Undo restores everything."
                >
                  <Trash2 size={12} className="mr-2" /> Delete
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>

          {/* Children (if expanded) */}
          {folder.expanded && (
            <div>
              {childBoards.map((board) => (
                <BoardItem
                  key={board.id}
                  board={board}
                  isActive={board.id === activeBoardId}
                  onClick={() => onSelectBoard(board.id)}
                  depth={depth + 1}
                  multiSelectMode={multiSelectMode}
                  isSelected={selectedBatchIds?.includes(board.id)}
                  onToggleSelect={onToggleSelectBoard}
                  onHoldSelect={onHoldSelect ? () => onHoldSelect("board", board.id) : undefined}
                  renameRequested={renameRequest?.kind === "board" && renameRequest.id === board.id}
                  onRenameHandled={onRenameHandled}
                />
              ))}
              {childFolders.map((childFolder) => (
                <FolderItem
                  key={childFolder.id}
                  folder={childFolder}
                  folders={folders}
                  boards={boards}
                  activeBoardId={activeBoardId}
                  depth={depth + 1}
                  onSelectBoard={onSelectBoard}
                  multiSelectMode={multiSelectMode}
                  selectedBatchIds={selectedBatchIds}
                  onToggleSelectBoard={onToggleSelectBoard}
                  onToggleSelectFolder={onToggleSelectFolder}
                  onHoldSelect={onHoldSelect}
                  onSelectFolderContents={onSelectFolderContents}
                  onImportHere={onImportHere}
                  onNewHere={onNewHere}
                  renameRequest={renameRequest}
                  onRenameHandled={onRenameHandled}
                />
              ))}
              {childBoards.length === 0 && childFolders.length === 0 && (
                <div
                  className="text-xs text-muted-foreground italic py-1"
                  style={{ paddingLeft: `${(depth + 1) * 12 + 24}px` }}
                >
                  Empty folder
                </div>
              )}
            </div>
          )}
        </div>
      </ContextMenuTrigger>
      <ContextMenuContent onClick={(e) => e.stopPropagation()}>
        <ContextMenuItem onClick={() => onSelectFolderContents?.(folder.id)}>
          <CheckSquare size={12} className="mr-2" /> Select in this folder
        </ContextMenuItem>
        <ContextMenuItem onClick={() => onImportHere?.("pdf", folder.id)}>
          <FileUp size={12} className="mr-2" /> Import document here
        </ContextMenuItem>
        <ContextMenuItem onClick={() => onImportHere?.("pictures", folder.id)}>
          <ImagePlus size={12} className="mr-2" /> Import pictures here
        </ContextMenuItem>
        <ContextMenuSeparator />
        <ContextMenuItem onClick={() => onNewHere?.("notebook", folder.id)}>
          <NotebookText size={12} className="mr-2" /> New notebook here
        </ContextMenuItem>
        <ContextMenuItem onClick={() => onNewHere?.("board", folder.id)}>
          <Presentation size={12} className="mr-2" /> New board here
        </ContextMenuItem>
        <ContextMenuItem onClick={() => onNewHere?.("folder", folder.id)}>
          <FolderPlus size={12} className="mr-2" /> New subfolder
        </ContextMenuItem>
        <ContextMenuItem onClick={() => setMoveOpen(true)}>
          <FolderInput size={12} className="mr-2" /> Move to…
        </ContextMenuItem>
        <ContextMenuItem onClick={() => setIsRenaming(true)}>
          <Pencil size={12} className="mr-2" /> Rename
        </ContextMenuItem>
        <ContextMenuSeparator />
        <ContextMenuItem
          className="text-destructive focus:text-destructive"
          onClick={() => trashWithUndo([], [folder.id])}
        >
          <Trash2 size={12} className="mr-2" /> Delete
        </ContextMenuItem>
      </ContextMenuContent>
    </ContextMenu>
    {/* Dialogs exist only while open. Each listens to the whole workspace,
        and one per row meant ~40 closed dialogs re-rendering after every
        pen stroke. */}
    {moveOpen && (
    <MoveToDialog
      open={moveOpen}
      onClose={() => setMoveOpen(false)}
      item={{ kind: "folder", id: folder.id, name: folder.name }}
      currentParentId={folder.parentId ?? null}
    />
    )}
    </>
  );
}

// ============================================================================
// Board item
// ============================================================================

export type BoardItemProps = {
  board: Board;
  isActive: boolean;
  onClick: () => void;
  depth: number;
  multiSelectMode?: boolean;
  isSelected?: boolean;
  onToggleSelect?: (id: string) => void;
  onHoldSelect?: () => void;
  renameRequested?: boolean;
  onRenameHandled?: () => void;
};

/**
 * A row re-draws only when what it SHOWS changes. The sidebar listens to the
 * whole workspace, so every pen stroke used to re-draw every notebook row -
 * each with its own menus - which measured ~240 ms after EVERY stroke on a
 * real 20-notebook workspace: the freeze after each pen lift that made fast
 * writing lag and drop the start of the next letter.
 * `onClick` is left out: it always opens this same board. So are the
 * callbacks (`onToggleSelect`, `onHoldSelect`, `onRenameHandled`): they are
 * stable per row purpose, never compared.
 */
export function boardItemPropsEqual(a: BoardItemProps, b: BoardItemProps): boolean {
  if (a.isActive !== b.isActive || a.depth !== b.depth) return false;
  if (a.multiSelectMode !== b.multiSelectMode || a.isSelected !== b.isSelected) return false;
  if ((a.renameRequested ?? false) !== (b.renameRequested ?? false)) return false;
  const x = a.board;
  const y = b.board;
  if (x === y) return true;
  return (
    x.id === y.id &&
    x.name === y.name &&
    x.folderId === y.folderId &&
    x.starred === y.starred &&
    x.color === y.color &&
    x.kind === y.kind &&
    (x.tags ?? []).join("\u0000") === (y.tags ?? []).join("\u0000")
  );
}

const BoardItem = React.memo(BoardItemImpl, boardItemPropsEqual);

function BoardItemImpl({
  board,
  isActive,
  onClick,
  depth,
  multiSelectMode,
  isSelected,
  onToggleSelect,
  onHoldSelect,
  renameRequested,
  onRenameHandled,
}: BoardItemProps) {
  const renameBoard = useWhiteboard((s) => s.renameBoard);
  const duplicateBoard = useWhiteboard((s) => s.duplicateBoard);
  const convertToNotebook = useWhiteboard((s) => s.convertToNotebook);
  const setSplitBoard = useWhiteboard((s) => s.setSplitBoard);
  const splitBoardId = useWhiteboard((s) => s.splitBoardId);
  const activeBoardId = useWhiteboard((s) => s.activeBoardId);
  const toggleStarred = useWhiteboard((s) => s.toggleStarred);
  const setBoardColor = useWhiteboard((s) => s.setBoardColor);
  const setActiveBoard = useWhiteboard((s) => s.setActiveBoard);

  const [isRenaming, setIsRenaming] = React.useState(false);
  const [renameValue, setRenameValue] = React.useState(board.name);
  // Double-tap (pen or finger, timed — mobile WebViews never fire dblclick)
  // opens the full row menu: move, delete, rename, duplicate and the rest.
  const [menuOpen, setMenuOpen] = React.useState(false);
  const [moveOpen, setMoveOpen] = React.useState(false);
  const [duplicateModalOpen, setDuplicateModalOpen] = React.useState(false);
  const lastTap = React.useRef(0);

  // The batch bar's Rename lands here from anywhere in the tree.
  React.useEffect(() => {
    if (renameRequested && !isRenaming) {
      setRenameValue(board.name);
      setIsRenaming(true);
      onRenameHandled?.();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [renameRequested]);

  const { drag, pickUp } = React.useContext(SidebarDragContext);
  const { suppressClick, holdHandlers } = useHoldRow({
    onHold: () => onHoldSelect?.(),
    onDragStart: () => pickUp({ kind: "board", id: board.id }),
  });
  const isDragged = drag?.id === board.id;

  // Copy a [[wikilink]] to this board to the clipboard, so it can be pasted
  // into any text/sticky element to create a link.
  const copyBoardLink = (b: Board) => {
    const linkText = `[[${b.name}]]`;
    navigator.clipboard?.writeText(linkText).catch(() => {
      // Fallback: do nothing if clipboard is unavailable
    });
  };

  const commitRename = () => {
    const trimmed = renameValue.trim();
    if (trimmed && trimmed !== board.name) {
      renameBoard(board.id, trimmed);
    } else {
      setRenameValue(board.name);
    }
    setIsRenaming(false);
  };

  return (
    <>
    <ContextMenu>
      <ContextMenuTrigger asChild disabled={!!drag}>
        <div
          {...holdHandlers}
          // Pass-through target: dropping onto a board files it into that
          // board's folder (boards cannot contain anything).
          data-drop-id={board.folderId ?? ROOT_DROP_ID}
          className={cn(
            "flex items-center gap-1 px-2 py-1.5 rounded-md cursor-pointer select-none text-sm group",
            isActive && !multiSelectMode
              ? "bg-sidebar-accent text-sidebar-accent-foreground font-medium"
              : isSelected && multiSelectMode
                ? "bg-primary/10 text-primary font-medium ring-1 ring-inset ring-primary/30"
                : "hover:bg-sidebar-accent/50 text-sidebar-foreground",
            isDragged && "opacity-40"
          )}
          // While selecting, every checkbox sits in one column: a board row
          // drops the indent that lines its icon up with a folder's name.
          style={{ paddingLeft: `${depth * 12 + (multiSelectMode ? 8 : 24)}px` }}
          onClick={() => {
            if (multiSelectMode) {
              onToggleSelect?.(board.id);
              return;
            }
            if (suppressClick.current) {
              suppressClick.current = false;
              return;
            }
            const now = Date.now();
            if (now - lastTap.current < DOUBLE_TAP_MS) {
              lastTap.current = 0;
              setMenuOpen(true);
              return;
            }
            lastTap.current = now;
            onClick();
          }}
          onContextMenu={(e) => {
            if (drag) e.preventDefault();
          }}
        >
          {multiSelectMode && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onToggleSelect?.(board.id);
              }}
              data-hold-ignore
              className="shrink-0 p-0.5 text-primary hover:text-primary/80 focus:outline-none"
              aria-label={isSelected ? `Deselect ${board.name}` : `Select ${board.name}`}
            >
              {isSelected ? (
                <CheckSquare size={14} className="text-primary fill-primary/15" />
              ) : (
                <Square size={14} className="text-muted-foreground/60 hover:text-foreground" />
              )}
            </button>
          )}
          <BoardKindIcon board={board} />
          {isRenaming ? (
            <Input
              value={renameValue}
              onChange={(e) => setRenameValue(e.target.value)}
              onBlur={commitRename}
              onKeyDown={(e) => {
                if (e.key === "Enter") commitRename();
                if (e.key === "Escape") {
                  setRenameValue(board.name);
                  setIsRenaming(false);
                }
              }}
              onClick={(e) => e.stopPropagation()}
              data-hold-ignore
              className="h-5 text-xs px-1 py-0"
              autoFocus
            />
          ) : (
            <span className="min-w-0 flex-1 truncate">{board.name}</span>
          )}
          {board.starred && (
            <Star size={10} className="fill-amber-400 text-amber-400 shrink-0" />
          )}
          {Array.isArray(board.tags) && board.tags.length > 0 && (
            <span className="text-[9px] text-emerald-600 shrink-0">#{board.tags.length}</span>
          )}
          <PageCount id={board.id} />
          <DropdownMenu open={menuOpen} onOpenChange={setMenuOpen}>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                data-hold-ignore
                className={cn("h-5 w-5 opacity-0 group-hover:opacity-100 show-on-touch shrink-0", multiSelectMode && "hidden")}
                onClick={(e) => e.stopPropagation()}
              >
                <MoreHorizontal size={12} />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48" onClick={(e) => e.stopPropagation()}>
              <DropdownMenuItem onClick={() => toggleStarred(board.id)}>
                <Star size={12} className="mr-2" /> {board.starred ? "Unstar" : "Star"}
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setIsRenaming(true)}>
                <Pencil size={12} className="mr-2" /> Rename
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={() => {
                  if (isNotebook(board)) {
                    setDuplicateModalOpen(true);
                  } else {
                    duplicateBoard(board.id);
                  }
                }}
              >
                <Copy size={12} className="mr-2" /> Duplicate
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setMoveOpen(true)}>
                <FolderInput size={12} className="mr-2" /> Move to…
              </DropdownMenuItem>
              {board.id !== activeBoardId && (
                <DropdownMenuItem
                  onClick={() => setSplitBoard(splitBoardId === board.id ? null : board.id)}
                >
                  <Columns2 size={12} className="mr-2" />
                  {splitBoardId === board.id ? "Close split view" : "Open beside this one"}
                </DropdownMenuItem>
              )}
              {board.kind !== "notebook" && (
                <DropdownMenuItem onClick={() => convertToNotebook(board.id)}>
                  <BookOpen size={12} className="mr-2" /> Convert to Notebook
                </DropdownMenuItem>
              )}
              <DropdownMenuItem onClick={() => copyBoardLink(board)}>
                <Link2 size={12} className="mr-2" /> Copy link
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => {
                setActiveBoard(board.id);
                window.dispatchEvent(new CustomEvent("wb:open-export"));
              }}>
                <Download size={12} className="mr-2" /> Export Board
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <div className="px-2 py-1.5">
                <div className="text-xs text-muted-foreground mb-1.5">Board color</div>
                <div className="flex gap-1.5">
                  {FOLDER_COLORS.map((c) => (
                    <button
                      key={c}
                      className={cn(
                        "w-5 h-5 rounded-full border-2 transition-transform hover:scale-110",
                        (board.color || "#3b82f6") === c ? "border-ring ring-1 ring-ring/30" : "border-white"
                      )}
                      style={{ backgroundColor: c }}
                      onClick={() => setBoardColor(board.id, c)}
                    />
                  ))}
                </div>
              </div>
              <DropdownMenuSeparator />
              <DropdownMenuItem
                className="text-destructive focus:text-destructive"
                onClick={() => trashWithUndo([board.id], [])}
              >
                <Trash2 size={12} className="mr-2" /> Delete
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </ContextMenuTrigger>
      <ContextMenuContent onClick={(e) => e.stopPropagation()}>
        <ContextMenuItem onClick={() => toggleStarred(board.id)}>
          <Star size={12} className="mr-2" /> {board.starred ? "Unstar" : "Star"}
        </ContextMenuItem>
        <ContextMenuItem onClick={() => setIsRenaming(true)}>
          <Pencil size={12} className="mr-2" /> Rename
        </ContextMenuItem>
        <ContextMenuItem
          onClick={() => {
            if (isNotebook(board)) {
              setDuplicateModalOpen(true);
            } else {
              duplicateBoard(board.id);
            }
          }}
        >
          <Copy size={12} className="mr-2" /> Duplicate
        </ContextMenuItem>
        <ContextMenuItem onClick={() => setMoveOpen(true)}>
          <FolderInput size={12} className="mr-2" /> Move to…
        </ContextMenuItem>
        {board.id !== activeBoardId && (
          <ContextMenuItem
            onClick={() => setSplitBoard(splitBoardId === board.id ? null : board.id)}
          >
            <Columns2 size={12} className="mr-2" />
            {splitBoardId === board.id ? "Close split view" : "Open beside this one"}
          </ContextMenuItem>
        )}
        {board.kind !== "notebook" && (
          <ContextMenuItem onClick={() => convertToNotebook(board.id)}>
            <BookOpen size={12} className="mr-2" /> Convert to Notebook
          </ContextMenuItem>
        )}
        <ContextMenuItem onClick={() => {
          setActiveBoard(board.id);
          window.dispatchEvent(new CustomEvent("wb:open-export"));
        }}>
          <Download size={12} className="mr-2" /> Export Board
        </ContextMenuItem>
        <ContextMenuSeparator />
        <ContextMenuItem
          className="text-destructive focus:text-destructive"
          onClick={() => trashWithUndo([board.id], [])}
        >
          <Trash2 size={12} className="mr-2" /> Delete
        </ContextMenuItem>
      </ContextMenuContent>
    </ContextMenu>
    {/* Dialogs exist only while open. Each listens to the whole workspace,
        and one per row meant ~40 closed dialogs re-rendering after every
        pen stroke. */}
    {moveOpen && (
    <MoveToDialog
      open={moveOpen}
      onClose={() => setMoveOpen(false)}
      item={{ kind: "board", id: board.id, name: board.name }}
      currentParentId={board.folderId ?? null}
    />
    )}
    {isNotebook(board) && duplicateModalOpen && (
      <DuplicateNotebookModal
        open={duplicateModalOpen}
        onClose={() => setDuplicateModalOpen(false)}
        // The row's `board` is a list snapshot; the dialog previews pages,
        // so it gets the notebook as it is now.
        sourceBoard={useWhiteboard.getState().boards.find((b) => b.id === board.id) ?? board}
      />
    )}
    </>
  );
}
