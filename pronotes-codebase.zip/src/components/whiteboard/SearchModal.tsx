"use client";

/**
 * Search
 * ======
 * One search with three scopes, picked at the top of the panel:
 *
 *  - This note    find-in-page. Results run top to bottom, page by page, and
 *                 can be stepped through ("3 of 12") from a small find bar that
 *                 leaves the page visible.
 *  - This folder  the open note's folder and its sub-folders.
 *  - Everywhere   every note, NEAREST FIRST: this note, its folder, the
 *                 folders around it, then the rest - under headers that say so.
 *
 * What is searched is spelled out in the empty panel, because "what does this
 * actually search?" was the complaint: names of notes and folders, tags, text
 * boxes, sticky notes, connection labels and PDF / document text. Handwriting,
 * shapes and pictures carry no text, so they are not searchable - and the
 * panel says that rather than implying otherwise.
 *
 * Ctrl+F opens it on "This note"; Ctrl+K and the header button on "Everywhere".
 * The ranking and scoping rules live in lib/whiteboard/search.ts.
 */

import React, { useCallback, useDeferredValue, useEffect, useMemo, useRef, useState } from "react";
import { useWhiteboard, useActiveBoard } from "@/store/whiteboard";
import {
  ChevronDown,
  ChevronUp,
  FileText,
  Folder as FolderIcon,
  Globe,
  Hash,
  ListFilter,
  Search,
  Spline,
  StickyNote,
  Type,
  X,
} from "lucide-react";
import { cn } from "@/lib/utils";
import type { Board } from "@/lib/whiteboard/types";
import { getActivePageIndex, getBoardElements, getPages, isNotebook } from "@/lib/whiteboard/notebook";
import { worldToScreen } from "@/lib/whiteboard/geometry";
import {
  boardInScope,
  buildSearchIndex,
  focusBounds,
  folderPath,
  groupHits,
  highlightParts,
  isLocatable,
  makeSnippet,
  pdfHit,
  scopeInfo,
  searchEntries,
  sortHits,
  type Nearness,
  type SearchContext,
  type SearchHit,
  type SearchKind,
  type SearchScope,
} from "@/lib/whiteboard/search";
import { searchNotebookPdfText } from "@/lib/whiteboard/pdfTextIndex";
import { BoardKindIcon } from "./Sidebar";

interface SearchModalProps {
  initialScope: SearchScope;
  /**
   * "bar": open straight into the compact find bar and go to the first match
   * from this page on - no panel over the page, no keyboard. For "Find in
   * note" on a text selection, whose matches you want to SEE.
   */
  initialMode?: "panel" | "bar";
  /** Start with this text (e.g. "Find in note" on a text selection). */
  initialQuery?: string;
  onClose: () => void;
}

// The last query, for this session. Reopening search shows where you were,
// with the text selected so typing simply replaces it.
let lastQuery = "";

/** How many rows each group shows before "Show more". */
const GROUP_CAP: Record<SearchScope, number> = { note: 50, folder: 8, everywhere: 6 };
const MORE_STEP = 20;

const KIND_META: Record<SearchKind, { label: string; icon: React.ElementType; tint: string }> = {
  board: { label: "Note", icon: FileText, tint: "bg-blue-500/10 text-blue-600 dark:text-blue-400" },
  folder: { label: "Folder", icon: FolderIcon, tint: "bg-amber-500/10 text-amber-600 dark:text-amber-400" },
  tag: { label: "Tag", icon: Hash, tint: "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400" },
  text: { label: "Text box", icon: Type, tint: "bg-sky-500/10 text-sky-600 dark:text-sky-400" },
  sticky: { label: "Sticky note", icon: StickyNote, tint: "bg-yellow-400/20 text-yellow-700 dark:text-yellow-300" },
  connection: { label: "Connection label", icon: Spline, tint: "bg-violet-500/10 text-violet-600 dark:text-violet-400" },
  pdf: { label: "Document text", icon: FileText, tint: "bg-red-500/10 text-red-600 dark:text-red-400" },
};

/** What each scope looks through, for the empty panel. */
const SEARCHED: Record<SearchScope, SearchKind[]> = {
  note: ["text", "sticky", "connection", "pdf"],
  folder: ["board", "folder", "tag", "text", "sticky", "connection", "pdf"],
  everywhere: ["board", "folder", "tag", "text", "sticky", "connection", "pdf"],
};
const SEARCHED_LABEL: Partial<Record<SearchKind, string>> = {
  board: "Note names",
  folder: "Folder names",
  tag: "Tags",
  text: "Text boxes",
  sticky: "Sticky notes",
  connection: "Connection labels",
  pdf: "PDF & document text",
};

export function SearchModal({ initialScope, initialMode = "panel", initialQuery, onClose }: SearchModalProps) {
  const boards = useWhiteboard((s) => s.boards);
  const folders = useWhiteboard((s) => s.folders);
  const activeBoardId = useWhiteboard((s) => s.activeBoardId);
  const sidebarFolderId = useWhiteboard((s) => s.activeFolderId);
  const activeBoard = useActiveBoard();

  const [scopeChoice, setScope] = useState<SearchScope>(initialScope);
  // "This note" needs a note; with none open it quietly means everywhere.
  const scope: SearchScope = scopeChoice === "note" && !activeBoard ? "everywhere" : scopeChoice;
  const [mode, setMode] = useState<"panel" | "bar">(initialMode);
  const [query, setQueryState] = useState(() => {
    if (initialQuery) lastQuery = initialQuery;
    return lastQuery;
  });
  const setQuery = (q: string) => {
    lastQuery = q;
    setQueryState(q);
  };
  // Typing stays instant; the search itself runs at React's convenience.
  const deferredQuery = useDeferredValue(query);
  const [currentId, setCurrentId] = useState<string | null>(null);
  const [flash, setFlash] = useState<{ boardId: string; elementId: string; key: number } | null>(null);

  // Where the search started: the open note, and its folder (else the one
  // picked in the sidebar). The wide scopes rank relative to THIS, not to
  // wherever the last opened result took you - otherwise opening a result in
  // another note re-sorted the list around it, "next" led back to the start,
  // and results further away could never be reached.
  const [anchor] = useState(() => {
    const s = useWhiteboard.getState();
    const b = s.boards.find((x) => x.id === s.activeBoardId);
    return { boardId: b ? b.id : null, folderId: b ? b.folderId ?? null : s.activeFolderId ?? null };
  });
  const liveFolderId = activeBoard ? activeBoard.folderId ?? null : sidebarFolderId ?? null;
  // Primitives only: the board OBJECT changes with every stroke, and the
  // document-text search below must not re-run for each one.
  const liveBoardId = activeBoard ? activeBoardId : null;
  // "This note" always means the note on screen now.
  const ctx = useMemo<SearchContext>(
    () =>
      scope === "note"
        ? { activeBoardId: liveBoardId, folderId: liveFolderId, folders }
        : { activeBoardId: anchor.boardId, folderId: anchor.folderId, folders },
    [scope, liveBoardId, liveFolderId, anchor, folders]
  );
  const currentFolderId = anchor.folderId;
  const folderName = currentFolderId
    ? folders.find((f) => f.id === currentFolderId)?.name || "Folder"
    : "Top level";

  // ----- Results -------------------------------------------------------------

  const index = useMemo(() => buildSearchIndex(boards, folders), [boards, folders]);
  const localHits = useMemo(
    () => searchEntries(index, deferredQuery, scope, ctx),
    [index, deferredQuery, scope, ctx]
  );

  // Document text comes from the text layer, asynchronously and a little
  // later (it may have to read a PDF), so it never holds up typing.
  const trimmed = deferredQuery.trim();
  const pdfKey = `${scope}|${ctx.activeBoardId}|${ctx.folderId}|${trimmed}`;
  const [pdf, setPdf] = useState<{ key: string; hits: SearchHit[]; pending: boolean }>({
    key: "",
    hits: [],
    pending: false,
  });
  useEffect(() => {
    if (!trimmed) return;
    const abort = new AbortController();
    const timer = setTimeout(() => {
      const s = useWhiteboard.getState();
      const info = scopeInfo(ctx);
      const targets = s.boards.filter(
        (b) => isNotebook(b) && getPages(b).some((p) => p.pdf) && boardInScope(b, scope, info)
      );
      if (targets.length === 0) return;
      const collected: SearchHit[] = [];
      setPdf({ key: pdfKey, hits: [], pending: true });
      const limit = scope === "note" ? 300 : 30;
      // One notebook at a time, nearest first, and stopped for good once the
      // query changes or search closes: reading every PDF in the workspace at
      // once could exhaust the tablet's memory.
      const ordered = [...targets].sort(
        (a, b) => (a.id === ctx.activeBoardId ? -1 : 0) - (b.id === ctx.activeBoardId ? -1 : 0)
      );
      void (async () => {
        for (const b of ordered) {
          if (abort.signal.aborted) return;
          try {
            const raw = await searchNotebookPdfText(b, trimmed, limit, { signal: abort.signal });
            if (abort.signal.aborted) return;
            raw.forEach((r, i) => collected.push(pdfHit(b, r, trimmed, i, info)));
            // Show each notebook's hits as they arrive.
            setPdf({ key: pdfKey, hits: [...collected], pending: true });
          } catch {
            // A document that cannot be read just contributes no text hits.
          }
        }
        if (!abort.signal.aborted) setPdf({ key: pdfKey, hits: [...collected], pending: false });
      })();
    }, 250);
    return () => {
      abort.abort();
      clearTimeout(timer);
    };
  }, [pdfKey, trimmed, scope, ctx]);

  const pdfPending = pdf.key === pdfKey && pdf.pending;
  const hits = useMemo(() => {
    const pdfHits = pdf.key === pdfKey ? pdf.hits : [];
    return pdfHits.length ? sortHits([...localHits, ...pdfHits], scope) : localHits;
  }, [localHits, pdf, pdfKey, scope]);
  const groups = useMemo(
    () =>
      scope === "note"
        ? hits.length
          ? [{ id: "note" as Nearness, label: "In this note", hits }]
          : []
        : groupHits(hits, scope, ctx).map((g) =>
            // Once a result has taken you to another note, "this note" would
            // be ambiguous: name the note the search started from.
            g.id === "note" && ctx.activeBoardId !== activeBoardId
              ? { ...g, label: `In ${boards.find((b) => b.id === ctx.activeBoardId)?.name || "the first note"}` }
              : g
          ),
    [hits, scope, ctx, activeBoardId, boards]
  );
  // What the find bar steps through: places in a note, in the order shown.
  const locatable = useMemo(() => hits.filter(isLocatable), [hits]);
  const currentIndex = currentId ? locatable.findIndex((h) => h.entry.id === currentId) : -1;

  // "Show more", per group, for this query only.
  const resultsKey = `${scope}|${trimmed}`;
  const [more, setMore] = useState<{ key: string; extra: Partial<Record<Nearness, number>> }>({ key: "", extra: {} });
  const extra = more.key === resultsKey ? more.extra : {};
  const visibleGroups = groups.map((g) => {
    const cap = GROUP_CAP[scope] + (extra[g.id] ?? 0);
    return { ...g, shown: g.hits.slice(0, cap), hidden: Math.max(0, g.hits.length - cap) };
  });
  const rows = visibleGroups.flatMap((g) => g.shown);

  // Keyboard cursor over the visible rows; back to the top on a new query.
  const [cursorState, setCursor] = useState({ key: "", i: 0 });
  const cursor = cursorState.key === resultsKey ? Math.min(cursorState.i, Math.max(0, rows.length - 1)) : 0;
  const rowRefs = useRef(new Map<string, HTMLButtonElement>());
  // Scrolled from the key handler, not an effect: an effect would also fire on
  // unrelated re-renders and yank the list back while you scroll it by finger.
  const moveCursor = (i: number) => {
    setCursor({ key: resultsKey, i });
    const id = rows[i]?.entry.id;
    if (id) rowRefs.current.get(id)?.scrollIntoView({ block: "nearest" });
  };

  // ----- Navigation ----------------------------------------------------------

  /**
   * Opens a document in the pane you are working in. In split view a result
   * in the OTHER pane's document makes that pane the live one rather than
   * showing one document twice.
   */
  const openBoard = useCallback((boardId: string) => {
    const s = useWhiteboard.getState();
    if (s.activeBoardId === boardId) return;
    if (s.splitBoardId === boardId) {
      // Switching panes refuses to run under an open text editor (the edit
      // would be lost); finish the edit first, as tapping away would.
      if (s.editingId) s.setEditingId(null);
      s.focusSplitSide(s.splitSide === "left" ? "right" : "left");
      return;
    }
    s.setActiveBoard(boardId);
  }, []);

  /** Lands on a hit: its note, its page, the element centred, and a flash. */
  const reveal = useCallback(
    (hit: SearchHit) => {
      const e = hit.entry;
      if (!e.boardId) return;
      openBoard(e.boardId);
      const s = useWhiteboard.getState();
      if (e.kind === "pdf") {
        const board = s.boards.find((b) => b.id === e.boardId);
        const pages = getPages(board);
        const pageId = e.pageId ?? pages[e.pageIndex ?? 0]?.id;
        // Already on that page (stepping through its matches): stay, and let
        // the text layer bring the match itself into view - going to the page
        // again snapped back to its top every step.
        const onPage = pages[getActivePageIndex(board)]?.id === pageId;
        if (pageId && !onPage) s.goToPage(pageId, s.canvasViewport.height);
        // After the page has rendered, so its text layer is there to listen.
        const detail = { boardId: e.boardId, pageId, pageIndex: e.pageIndex ?? 0, query: trimmed, ordinal: e.ordinal ?? 0 };
        requestAnimationFrame(() =>
          requestAnimationFrame(() => window.dispatchEvent(new CustomEvent("wb:pdf-find", { detail })))
        );
        return;
      }
      if (e.elementId) {
        s.focusElement(e.boardId, e.elementId, { select: false });
        setFlash({ boardId: e.boardId, elementId: e.elementId, key: Date.now() });
      }
    },
    [openBoard, trimmed]
  );

  const open = (hit: SearchHit) => {
    const e = hit.entry;
    // Put the soft keyboard away: the page is what you want to see now.
    (document.activeElement as HTMLElement | null)?.blur?.();
    if (e.kind === "folder") {
      if (e.folderId) useWhiteboard.getState().revealFolder(e.folderId);
      onClose();
      return;
    }
    if (!e.boardId) return;
    if (!isLocatable(hit)) {
      openBoard(e.boardId);
      onClose();
      return;
    }
    reveal(hit);
    setCurrentId(e.id);
    setMode("bar");
  };

  const step = (delta: 1 | -1) => {
    const n = locatable.length;
    if (n === 0) return;
    const i = currentIndex === -1 ? (delta > 0 ? 0 : n - 1) : (currentIndex + delta + n) % n;
    const hit = locatable[i];
    reveal(hit);
    setCurrentId(hit.entry.id);
  };

  // "Find in note": once the matches are in, go to the first one from this
  // page on - usually the very text you selected - and show it, bar only.
  const autoOpenedRef = useRef(initialMode !== "bar");
  const pdfDone = pdf.key === pdfKey && !pdf.pending;
  useEffect(() => {
    if (autoOpenedRef.current || locatable.length === 0) return;
    const here = activeBoard ? getActivePageIndex(activeBoard) : 0;
    const inThisNote = (h: SearchHit) => h.entry.boardId === activeBoardId && (h.entry.pageIndex ?? 0) >= here;
    const hit =
      locatable.find((h) => h.entry.kind === "pdf" && inThisNote(h)) ??
      (pdfDone ? locatable.find(inThisNote) ?? locatable[0] : undefined);
    if (!hit) return;
    autoOpenedRef.current = true;
    reveal(hit);
    setCurrentId(hit.entry.id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [locatable, pdfDone]);

  // Esc closes search wherever the focus is. Once a result has been opened,
  // focus is back on the page, and Esc used to reach the canvas instead: the
  // bar stayed, and your selection and tool were reset.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== "Escape") return;
      e.preventDefault();
      e.stopImmediatePropagation();
      onClose();
    };
    window.addEventListener("keydown", onKey, true);
    return () => window.removeEventListener("keydown", onKey, true);
  }, [onClose]);

  // ----- Keyboard ------------------------------------------------------------

  const inputRef = useRef<HTMLInputElement>(null);
  // Focus (and so the tablet's keyboard) only when search is first opened -
  // not when coming back to the list from the find bar with the pen.
  const [focusOnShow, setFocusOnShow] = useState(initialMode === "panel");
  useEffect(() => {
    if (mode !== "panel" || !focusOnShow) return;
    const raf = requestAnimationFrame(() => {
      inputRef.current?.focus();
      inputRef.current?.select();
    });
    return () => cancelAnimationFrame(raf);
  }, [mode, focusOnShow]);

  /** Ctrl+F / Ctrl+K while search already has the keyboard switch scope. */
  const scopeShortcut = (e: React.KeyboardEvent) => {
    if (!(e.ctrlKey || e.metaKey) || e.shiftKey) return false;
    if (e.code === "KeyF" && activeBoard) {
      e.preventDefault();
      setScope("note");
      if (mode === "bar") inputRef.current?.select();
      return true;
    }
    if (e.code === "KeyK") {
      e.preventDefault();
      setScope("everywhere");
      setFocusOnShow(true);
      setMode("panel");
      return true;
    }
    return false;
  };

  // Arrows and Enter drive the results only from the text field; on a focused
  // button Enter must still press that button.
  const fromInput = (e: React.KeyboardEvent) => e.target === inputRef.current;

  const onPanelKeyDown = (e: React.KeyboardEvent) => {
    if (scopeShortcut(e)) return;
    if (e.key === "Escape") {
      e.preventDefault();
      onClose();
      return;
    }
    if (!fromInput(e)) return;
    if (e.key === "ArrowDown") {
      e.preventDefault();
      moveCursor(Math.min(rows.length - 1, cursor + 1));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      moveCursor(Math.max(0, cursor - 1));
    } else if (e.key === "Enter") {
      e.preventDefault();
      if (rows[cursor]) open(rows[cursor]);
    }
  };

  const onBarKeyDown = (e: React.KeyboardEvent) => {
    if (scopeShortcut(e)) return;
    if (e.key === "Escape") {
      e.preventDefault();
      onClose();
      return;
    }
    if (!fromInput(e)) return;
    if (e.key === "Enter" || e.key === "ArrowDown" || e.key === "ArrowUp") {
      e.preventDefault();
      step(e.key === "ArrowUp" || (e.key === "Enter" && e.shiftKey) ? -1 : 1);
    } else if (e.key === "Escape") {
      e.preventDefault();
      onClose();
    }
  };

  // ----- Where a result is ---------------------------------------------------

  const boardById = useMemo(() => new Map(boards.map((b) => [b.id, b])), [boards]);
  const pathOf = useMemo(() => {
    const cache = new Map<string | null, string>();
    return (folderId: string | null) => {
      if (!cache.has(folderId)) cache.set(folderId, folderPath(folderId, folders).join(" › "));
      return cache.get(folderId) as string;
    };
  }, [folders]);

  const whereOf = (hit: SearchHit): string => {
    const e = hit.entry;
    if (e.kind === "folder") {
      const parent = folders.find((f) => f.id === e.folderId)?.parentId ?? null;
      return parent ? `Folder in ${pathOf(parent)}` : "Folder · top level";
    }
    const board = e.boardId ? boardById.get(e.boardId) : undefined;
    const path = pathOf(e.folderId) || "Top level";
    if (e.kind === "board") {
      const pages = getPages(board).length;
      const what = board && isNotebook(board) ? `Notebook · ${pages} page${pages === 1 ? "" : "s"}` : "Whiteboard";
      return `${what} · ${path}`;
    }
    const kind = KIND_META[e.kind].label;
    // Under "In this note" the note is already named by the header.
    if (scope === "note" || hit.nearness === "note") return kind;
    return `${kind} · ${board?.name || "Untitled"} · ${path}`;
  };

  // ----- Render --------------------------------------------------------------

  const scopes: Array<{ id: SearchScope; label: string; detail: string; icon: React.ReactNode; disabled?: boolean }> = [
    {
      id: "note",
      label: "This note",
      detail: activeBoard ? activeBoard.name || "Untitled" : "No note open",
      icon: activeBoard ? <BoardKindIcon board={activeBoard} size={13} /> : <FileText size={13} />,
      disabled: !activeBoard,
    },
    {
      id: "folder",
      label: "This folder",
      detail: folderName,
      icon: <FolderIcon size={13} className="shrink-0 text-amber-500" />,
    },
    {
      id: "everywhere",
      label: "Everywhere",
      detail: `All ${boards.length} note${boards.length === 1 ? "" : "s"}`,
      icon: <Globe size={13} className="shrink-0 text-emerald-500" />,
    },
  ];

  const counter =
    locatable.length === 0
      ? trimmed
        ? "No matches"
        : ""
      : currentIndex >= 0
        ? `${currentIndex + 1} of ${locatable.length}`
        : `${locatable.length} match${locatable.length === 1 ? "" : "es"}`;

  const flashRing = flash && (
    <FlashRing key={flash.key} boardId={flash.boardId} elementId={flash.elementId} onDone={() => setFlash(null)} />
  );

  if (mode === "bar") {
    const current = scopes.find((s) => s.id === scope);
    return (
      <>
        {flashRing}
        <div
          data-wb-search-bar
          role="search"
          onKeyDown={onBarKeyDown}
          data-wb-searchbar
          className="absolute left-1/2 top-[4.25rem] z-40 flex w-[min(30rem,calc(100%-1.5rem))] -translate-x-1/2 items-center gap-0.5 rounded-xl border border-border/80 bg-white/95 p-1 shadow-lg backdrop-blur-md dark:bg-zinc-900/95"
        >
          <button
            type="button"
            onClick={() => {
              setFocusOnShow(false);
              setMode("panel");
            }}
            className="flex h-9 shrink-0 items-center gap-1.5 rounded-lg px-2 text-[11px] font-medium text-muted-foreground hover:bg-muted hover:text-foreground"
            title={`Searching ${current?.label.toLowerCase()} - show all results`}
            aria-label="Show all results"
          >
            {current?.icon}
            <span className="hidden max-w-[7rem] truncate @min-[34rem]:inline">{current?.label}</span>
          </button>
          <input
            ref={inputRef}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Find…"
            dir="auto"
            aria-label="Search text"
            className="h-9 min-w-0 flex-1 bg-transparent px-1.5 text-[13px] outline-none placeholder:text-muted-foreground"
          />
          <span className="shrink-0 whitespace-nowrap px-1.5 text-[12px] tabular-nums text-muted-foreground" aria-live="polite">
            {counter}
          </span>
          <BarButton label="Previous match (Shift+Enter)" onClick={() => step(-1)} disabled={!locatable.length}>
            <ChevronUp size={17} />
          </BarButton>
          <BarButton label="Next match (Enter)" onClick={() => step(1)} disabled={!locatable.length}>
            <ChevronDown size={17} />
          </BarButton>
          <BarButton
            label="All results"
            onClick={() => {
              setFocusOnShow(false);
              setMode("panel");
            }}
          >
            <ListFilter size={16} />
          </BarButton>
          <BarButton label="Close (Esc)" onClick={onClose}>
            <X size={16} />
          </BarButton>
        </div>
      </>
    );
  }

  return (
    <>
      {flashRing}
      <div
        data-wb-modal
        // Above the split divider (z-60), which otherwise cuts through the
        // panel and steals taps on it in split view.
        className="fixed inset-0 z-[70] flex items-start justify-center bg-black/30 px-3 pt-3 backdrop-blur-sm sm:pt-[10vh]"
        onClick={onClose}
      >
        <div
          role="dialog"
          aria-label="Search"
          className="flex max-h-[min(80dvh,42rem)] w-full max-w-2xl flex-col overflow-hidden rounded-2xl border border-border bg-white shadow-2xl dark:bg-zinc-900"
          onClick={(e) => e.stopPropagation()}
          onKeyDown={onPanelKeyDown}
        >
          {/* Query */}
          <div className="flex items-center gap-2 border-b border-border px-3 py-2">
            <Search size={17} className="shrink-0 text-muted-foreground" />
            <input
              ref={inputRef}
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={
                scope === "note" ? "Find in this note…" : scope === "folder" ? `Search in ${folderName}…` : "Search everything…"
              }
              dir="auto"
              aria-label="Search text"
              className="h-10 min-w-0 flex-1 bg-transparent text-[15px] outline-none placeholder:text-muted-foreground"
            />
            {query && (
              <button
                type="button"
                onClick={() => {
                  setQuery("");
                  inputRef.current?.focus();
                }}
                className="shrink-0 rounded-md px-1.5 py-1 text-[11px] font-medium text-muted-foreground hover:bg-muted hover:text-foreground"
              >
                Clear
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              className="grid h-9 w-9 shrink-0 place-items-center rounded-lg text-muted-foreground hover:bg-muted hover:text-foreground"
              aria-label="Close search"
              title="Close (Esc)"
            >
              <X size={17} />
            </button>
          </div>

          {/* Scope: where to look. Each segment names the note / folder it means. */}
          <div className="border-b border-border px-3 py-2">
            <div role="radiogroup" aria-label="Search scope" className="grid grid-cols-3 gap-1 rounded-xl bg-muted/60 p-1">
              {scopes.map((s) => (
                <button
                  key={s.id}
                  type="button"
                  role="radio"
                  aria-checked={scope === s.id}
                  disabled={s.disabled}
                  onClick={() => {
                    setScope(s.id);
                    inputRef.current?.focus({ preventScroll: true });
                  }}
                  className={cn(
                    "flex min-h-11 min-w-0 flex-col items-start justify-center rounded-lg px-2.5 py-1 text-left transition",
                    scope === s.id
                      ? "bg-background text-foreground shadow-sm ring-1 ring-border/60"
                      : "text-muted-foreground hover:text-foreground",
                    s.disabled && "cursor-not-allowed opacity-45 hover:text-muted-foreground"
                  )}
                >
                  <span className="flex items-center gap-1.5 text-[12px] font-semibold leading-tight">
                    {s.icon}
                    {s.label}
                  </span>
                  <span dir="auto" className="w-full truncate text-[10.5px] leading-tight opacity-75">
                    {s.detail}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Results */}
          <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain px-1.5 pb-1.5">
            {!trimmed ? (
              <SearchedLegend scope={scope} folderName={folderName} noteName={activeBoard?.name || "this note"} />
            ) : hits.length === 0 ? (
              <div className="px-4 py-10 text-center text-[13px] text-muted-foreground">
                {pdfPending ? "Searching document text…" : <>No results for &ldquo;{trimmed}&rdquo;</>}
                {!pdfPending && scope !== "everywhere" && (
                  <div className="mt-3">
                    <button
                      type="button"
                      onClick={() => setScope("everywhere")}
                      className="rounded-lg border border-border px-3 py-1.5 text-[12px] font-medium text-foreground hover:bg-muted"
                    >
                      Search everywhere instead
                    </button>
                  </div>
                )}
              </div>
            ) : (
              visibleGroups.map((g) => (
                <section key={g.id} aria-label={g.label}>
                  <div className="sticky top-0 z-10 flex items-center gap-2 bg-white/95 px-2 pb-1 pt-2.5 backdrop-blur dark:bg-zinc-900/95">
                    <NearnessGlyph level={g.id} />
                    <span dir="auto" className="truncate text-[10.5px] font-semibold uppercase tracking-wider text-muted-foreground">
                      {g.label}
                    </span>
                    <span className="ml-auto text-[10.5px] tabular-nums text-muted-foreground">{g.hits.length}</span>
                  </div>
                  {g.shown.map((hit) => {
                    const i = rows.indexOf(hit);
                    return (
                      <ResultRow
                        key={hit.entry.id}
                        hit={hit}
                        board={hit.entry.boardId ? boardById.get(hit.entry.boardId) : undefined}
                        where={whereOf(hit)}
                        active={i === cursor}
                        current={hit.entry.id === currentId}
                        onOpen={() => open(hit)}
                        onHover={() => setCursor({ key: resultsKey, i })}
                        refCallback={(node) => {
                          if (node) rowRefs.current.set(hit.entry.id, node);
                          else rowRefs.current.delete(hit.entry.id);
                        }}
                      />
                    );
                  })}
                  {g.hidden > 0 && (
                    <button
                      type="button"
                      onClick={() =>
                        setMore({ key: resultsKey, extra: { ...extra, [g.id]: (extra[g.id] ?? 0) + MORE_STEP } })
                      }
                      className="ml-10 mt-0.5 rounded-md px-2 py-1.5 text-[12px] font-medium text-blue-600 hover:bg-muted dark:text-blue-400"
                    >
                      Show {Math.min(MORE_STEP, g.hidden)} more
                      <span className="text-muted-foreground"> of {g.hidden}</span>
                    </button>
                  )}
                </section>
              ))
            )}
          </div>

          {/* Footer */}
          <div className="flex items-center justify-between gap-3 border-t border-border px-3 py-1.5 text-[11px] text-muted-foreground">
            <span className="truncate">
              {trimmed ? `${hits.length} result${hits.length === 1 ? "" : "s"}` : ""}
              {pdfPending && hits.length > 0 && " · reading documents…"}
            </span>
            <span className="hidden shrink-0 items-center gap-1.5 pointer-fine:flex">
              <kbd className="rounded border bg-muted px-1">↑↓</kbd> move
              <kbd className="rounded border bg-muted px-1">↵</kbd> open
              <kbd className="rounded border bg-muted px-1">Ctrl F</kbd> this note
              <kbd className="rounded border bg-muted px-1">Ctrl K</kbd> everywhere
            </span>
          </div>
        </div>
      </div>
    </>
  );
}

// ---------------------------------------------------------------------------
// Pieces
// ---------------------------------------------------------------------------

function BarButton({
  label,
  onClick,
  disabled,
  children,
}: {
  label: string;
  onClick: () => void;
  disabled?: boolean;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      title={label}
      aria-label={label}
      // 36 px: a comfortable target for a fingertip and the S Pen alike.
      className="grid h-9 w-9 shrink-0 place-items-center rounded-lg text-muted-foreground hover:bg-muted hover:text-foreground disabled:opacity-35"
    >
      {children}
    </button>
  );
}

/**
 * Signal-strength bars for a group: full for this note, fading with distance.
 * Makes "nearest first" readable at a glance without reading the headers.
 */
function NearnessGlyph({ level }: { level: Nearness }) {
  const strength = { note: 3, folder: 2, near: 1, elsewhere: 0 }[level];
  return (
    <span aria-hidden className="flex h-2.5 shrink-0 items-end gap-[2px]">
      {[1, 2, 3].map((n) => (
        <span
          key={n}
          className={cn("w-[3px] rounded-[1px]", n <= strength ? "bg-blue-500" : "bg-muted-foreground/25")}
          style={{ height: `${n * 3 + 1}px` }}
        />
      ))}
    </span>
  );
}

function ResultRow({
  hit,
  board,
  where,
  active,
  current,
  onOpen,
  onHover,
  refCallback,
}: {
  hit: SearchHit;
  board: Board | undefined;
  where: string;
  active: boolean;
  current: boolean;
  onOpen: () => void;
  onHover: () => void;
  refCallback: (node: HTMLButtonElement | null) => void;
}) {
  const e = hit.entry;
  const meta = KIND_META[e.kind];
  const Icon = meta.icon;
  const parts = highlightParts(makeSnippet(hit));
  const title = e.kind === "board" || e.kind === "folder" || e.kind === "tag";
  const page = e.pageIndex !== undefined ? e.pageIndex + 1 : null;
  return (
    <button
      ref={refCallback}
      type="button"
      onClick={onOpen}
      onPointerMove={(ev) => {
        // Only a real mouse moves the cursor; a pen hovering over the list
        // would otherwise drag the highlight around as it approaches.
        if (ev.pointerType === "mouse") onHover();
      }}
      className={cn(
        "relative flex min-h-12 w-full items-center gap-2.5 rounded-xl px-2 py-1.5 text-left transition-colors",
        active ? "bg-muted" : "hover:bg-muted/60"
      )}
    >
      {current && <span aria-hidden className="absolute inset-y-2 left-0 w-[3px] rounded-full bg-blue-500" />}
      <span className={cn("grid h-8 w-8 shrink-0 place-items-center rounded-lg", meta.tint)}>
        {e.kind === "board" && board ? <BoardKindIcon board={board} size={15} /> : <Icon size={15} />}
      </span>
      <span className="min-w-0 flex-1">
        <span dir="auto" className={cn("block truncate text-[13px] text-foreground", title && "font-medium")}>
          {parts.map((p, i) =>
            p.hit ? (
              <mark key={i} className="rounded-[3px] bg-amber-200/90 px-[1px] text-inherit dark:bg-amber-400/35">
                {p.text}
              </mark>
            ) : (
              <React.Fragment key={i}>{p.text}</React.Fragment>
            )
          )}
        </span>
        <span dir="auto" className="block truncate text-[11px] text-muted-foreground">
          {where}
        </span>
      </span>
      {page !== null && (
        <span className="shrink-0 rounded-md bg-muted px-1.5 py-0.5 text-[10.5px] font-medium tabular-nums text-muted-foreground">
          p. {page}
        </span>
      )}
    </button>
  );
}

/** The empty panel: exactly what this scope looks through, and what it cannot. */
function SearchedLegend({ scope, folderName, noteName }: { scope: SearchScope; folderName: string; noteName: string }) {
  const where =
    scope === "note" ? `in “${noteName}”` : scope === "folder" ? `in ${folderName} and its sub-folders` : "in every note and folder";
  return (
    <div className="px-3 py-5">
      <p dir="auto" className="text-[12px] text-muted-foreground">
        Searches {where}:
      </p>
      <div className="mt-2.5 flex flex-wrap gap-1.5">
        {SEARCHED[scope].map((k) => {
          const Icon = KIND_META[k].icon;
          return (
            <span
              key={k}
              className="flex items-center gap-1.5 rounded-lg border border-border/70 px-2 py-1 text-[11.5px] text-foreground"
            >
              <span className={cn("grid h-5 w-5 place-items-center rounded-md", KIND_META[k].tint)}>
                <Icon size={12} />
              </span>
              {SEARCHED_LABEL[k]}
            </span>
          );
        })}
      </div>
      <p className="mt-3 text-[11.5px] leading-snug text-muted-foreground">
        Handwriting, shapes and pictures can&apos;t be found - they hold no text. Type into a text box
        or sticky note to make something findable.
        {scope !== "note" && " Results nearest to you come first: this note, its folder, then the folders around it."}
      </p>
    </div>
  );
}

/**
 * A brief ring around the element a search landed on, so the eye finds it
 * after the camera jumps. Positioned in the live pane's screen space and
 * follows the camera while it lasts.
 */
function FlashRing({ boardId, elementId, onDone }: { boardId: string; elementId: string; onDone: () => void }) {
  const board = useActiveBoard();
  const camera = useWhiteboard((s) => s.camera);
  const viewport = useWhiteboard((s) => s.canvasViewport);
  const ref = useRef<HTMLDivElement>(null);
  const doneRef = useRef(onDone);
  useEffect(() => {
    doneRef.current = onDone;
  }, [onDone]);

  useEffect(() => {
    const node = ref.current;
    if (!node || typeof node.animate !== "function") {
      const t = setTimeout(() => doneRef.current(), 1400);
      return () => clearTimeout(t);
    }
    const anim = node.animate(
      [
        { opacity: 0, transform: "scale(1.12)" },
        { opacity: 1, transform: "scale(1)", offset: 0.15 },
        { opacity: 1, transform: "scale(1)", offset: 0.35 },
        { opacity: 0.35, transform: "scale(1)", offset: 0.5 },
        { opacity: 1, transform: "scale(1)", offset: 0.65 },
        { opacity: 0, transform: "scale(1)" },
      ],
      { duration: 1500, easing: "ease-out", fill: "forwards" }
    );
    anim.onfinish = () => doneRef.current();
    return () => anim.cancel();
  }, []);

  if (!board || board.id !== boardId) return null;
  const elements = getBoardElements(board);
  const el = elements.find((x) => x.id === elementId);
  if (!el) return null;
  const b = focusBounds(el, elements);
  const p = worldToScreen(b.x, b.y, camera, viewport);
  const pad = 6;
  return (
    <div
      ref={ref}
      aria-hidden
      className="pointer-events-none absolute z-[26] rounded-xl"
      style={{
        left: p.x - pad,
        top: p.y - pad,
        width: b.width * camera.zoom + pad * 2,
        height: b.height * camera.zoom + pad * 2,
        opacity: 0,
        boxShadow: "0 0 0 3px rgb(59 130 246 / 0.95), 0 0 0 10px rgb(59 130 246 / 0.2)",
      }}
    />
  );
}
