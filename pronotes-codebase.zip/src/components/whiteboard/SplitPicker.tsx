"use client";

/**
 * "Split view" button and its picker.
 *
 * Both sides are chosen here. The earlier version only let you pick the RIGHT
 * document — the left was silently whatever you already had open — so pairing
 * two particular documents meant opening one first and then finding the other
 * in the sidebar, and nothing on screen said so.
 *
 * Each row also says whether the document has anything in it. Without that,
 * picking a blank board looks identical to the split being broken.
 */

import React from "react";
import { Columns2, Rows2, X } from "lucide-react";
import { useWhiteboard, useActiveBoard } from "@/store/whiteboard";
import { allElements, getPages, isNotebook } from "@/lib/whiteboard/notebook";
import type { Board, SplitOrientation } from "@/lib/whiteboard/types";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";

/** "12 items" / "4 pages, 2 drawn on" / "empty" — enough to pick by. */
function describe(b: Board): { text: string; empty: boolean } {
  if (isNotebook(b)) {
    const pages = getPages(b);
    const withContent = pages.filter(
      (p) => (p.elements?.length ?? 0) > 0 || p.pdf
    ).length;
    if (withContent === 0) {
      return { text: `${pages.length} blank page${pages.length === 1 ? "" : "s"}`, empty: true };
    }
    return { text: `${pages.length}p · ${withContent} with content`, empty: false };
  }
  const n = allElements(b).length;
  return { text: n === 0 ? "empty canvas" : `canvas · ${n} item${n === 1 ? "" : "s"}`, empty: n === 0 };
}

function BoardList({
  boards,
  selectedId,
  disabledId,
  onPick,
}: {
  boards: Board[];
  selectedId: string | null;
  disabledId: string | null;
  onPick: (id: string) => void;
}) {
  return (
    <div className="max-h-[168px] space-y-0.5 overflow-y-auto">
      {boards.map((b) => {
        const d = describe(b);
        const blocked = b.id === disabledId;
        return (
          <button
            key={b.id}
            onClick={() => !blocked && onPick(b.id)}
            disabled={blocked}
            title={blocked ? "Already on the other side" : b.name}
            className={cn(
              "flex w-full items-baseline gap-2 rounded-lg px-2 py-1 text-left transition-colors",
              b.id === selectedId
                ? "bg-primary/10 text-primary"
                : "text-foreground hover:bg-muted",
              blocked && "cursor-not-allowed opacity-35 hover:bg-transparent"
            )}
          >
            <span className="min-w-0 flex-1 truncate text-[11px]">{b.name}</span>
            <span
              className={cn(
                "shrink-0 text-[9px]",
                d.empty ? "text-muted-foreground/60 italic" : "text-muted-foreground"
              )}
            >
              {d.text}
            </span>
          </button>
        );
      })}
    </div>
  );
}

export function SplitPicker() {
  const boards = useWhiteboard((s) => s.boards);
  const activeBoard = useActiveBoard();
  const splitBoardId = useWhiteboard((s) => s.splitBoardId);
  const splitSide = useWhiteboard((s) => s.splitSide);
  const setSplitBoard = useWhiteboard((s) => s.setSplitBoard);
  const setSplitPair = useWhiteboard((s) => s.setSplitPair);
  const orientation = useWhiteboard((s) => s.splitOrientation);
  const setSplitOrientation = useWhiteboard((s) => s.setSplitOrientation);
  const [open, setOpen] = React.useState(false);
  // The layout is chosen FIRST, together with the documents, and can be
  // changed later from the pane's own buttons.
  const [pendingLayout, setPendingLayout] = React.useState<SplitOrientation>("side");

  const splitOpen = Boolean(splitBoardId);

  // Which document is physically on each side right now.
  const leftId = splitSide === "left" ? activeBoard?.id ?? null : splitBoardId;
  const rightId = splitSide === "left" ? splitBoardId : activeBoard?.id ?? null;

  // Staged choices, so picking a left that is already on the right does not
  // half-apply and leave the split in a state you did not ask for.
  const [pendingLeft, setPendingLeft] = React.useState<string | null>(null);
  const [pendingRight, setPendingRight] = React.useState<string | null>(null);

  React.useEffect(() => {
    if (open) {
      setPendingLeft(leftId ?? activeBoard?.id ?? null);
      setPendingRight(rightId);
      // An open split keeps its layout; a new one starts in the layout that
      // suits the screen - stacked on a tablet held upright.
      const portrait = typeof window !== "undefined" && window.innerHeight > window.innerWidth;
      setPendingLayout(splitOpen ? orientation : portrait ? "stacked" : orientation);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const canApply =
    pendingLeft && pendingRight && pendingLeft !== pendingRight;

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="ghost"
          size="icon"
          className={cn(
            "h-8 w-8 text-muted-foreground hover:text-foreground",
            splitOpen && "bg-primary/10 text-primary"
          )}
          title="Split view — two documents at once"
          aria-label="Split view"
        >
          {splitOpen && orientation === "stacked" ? <Rows2 size={15} /> : <Columns2 size={15} />}
        </Button>
      </PopoverTrigger>

      <PopoverContent align="end" className="w-80 p-2">
        <p className="mb-2 px-1 text-[12px] font-semibold">Split view</p>

        {/* Layout first: it decides what the two lists below are called. */}
        <div className="mb-2 grid grid-cols-2 gap-1 rounded-xl bg-muted/60 p-1" role="radiogroup" aria-label="Layout">
          {(
            [
              { id: "side" as const, label: "Side by side", icon: Columns2 },
              { id: "stacked" as const, label: "Top & bottom", icon: Rows2 },
            ]
          ).map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              type="button"
              role="radio"
              aria-checked={pendingLayout === id}
              onClick={() => {
                setPendingLayout(id);
                // With a split already open the layout applies at once: it
                // changes nothing about WHICH documents are shown.
                if (splitOpen) setSplitOrientation(id);
              }}
              className={cn(
                "flex flex-col items-center gap-1 rounded-lg py-2 text-[11px] font-medium transition",
                pendingLayout === id
                  ? "bg-background text-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              <Icon size={18} className={pendingLayout === id ? "text-blue-600" : undefined} />
              {label}
            </button>
          ))}
        </div>

        {boards.length < 2 ? (
          <p className="px-1 py-3 text-center text-[11px] leading-snug text-muted-foreground">
            You need two documents. Make another board or notebook, or open a
            PDF, and you can pair them here.
          </p>
        ) : (
          <>
            <p className="mb-1 px-1 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
              {pendingLayout === "stacked" ? "Top" : "Left"}
            </p>
            <BoardList
              boards={boards}
              selectedId={pendingLeft}
              disabledId={pendingRight}
              onPick={setPendingLeft}
            />

            <p className="mb-1 mt-2 px-1 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
              {pendingLayout === "stacked" ? "Bottom" : "Right"}
            </p>
            <BoardList
              boards={boards}
              selectedId={pendingRight}
              disabledId={pendingLeft}
              onPick={setPendingRight}
            />

            <p className="mt-2 px-1 text-[10px] leading-snug text-muted-foreground">
              Both can be written on: tap a pane (or start writing in it) to make
              it the one your tools act on. The blue frame shows which one that is.
            </p>

            <div className="mt-2 flex gap-1">
              <Button
                size="sm"
                className="h-7 flex-1 text-[11px]"
                disabled={!canApply}
                onClick={() => {
                  if (!canApply) return;
                  setSplitPair(pendingLeft!, pendingRight!, pendingLayout);
                  setOpen(false);
                }}
              >
                {splitOpen ? "Apply" : pendingLayout === "stacked" ? "Show top & bottom" : "Show side by side"}
              </Button>
              {splitOpen && (
                <Button
                  variant="outline"
                  size="sm"
                  className="h-7 text-[11px]"
                  onClick={() => {
                    setSplitBoard(null);
                    setOpen(false);
                  }}
                >
                  <X size={12} className="mr-1" /> Close
                </Button>
              )}
            </div>
          </>
        )}
      </PopoverContent>
    </Popover>
  );
}
