"use client";

/**
 * Contextual Properties HUD & Inspector (v3 — Obsidian Canvas Grade)
 * ==================================================================
 * Floating contextual inspector that appears when an element is selected.
 */

import React, { useState } from "react";
import {
  Bold,
  Italic,
  Type,
  Palette,
  Minus,
  X,
  BringToFront,
  SendToBack,
  Copy,
  Trash2,
  Lock,
  Unlock,
  ChevronDown,
  ChevronUp,
  ArrowRight,
  GitBranch,
  CheckSquare,
} from "lucide-react";
import { useWhiteboard, useActiveBoard } from "@/store/whiteboard";
import { getBoardElements } from "@/lib/whiteboard/notebook";
import {
  PEN_COLORS,
  STROKE_WIDTHS,
  STICKY_COLORS,
  BUILTIN_LINK_TYPES,
  LINK_TYPE_COLORS,
  LINK_TYPE_LABELS,
  FONT_FAMILIES,
  setToolInk,
  type StickyColor,
  type WhiteboardElement,
  type ConnectionElement,
  type ConnectionRouting,
  type ArrowheadType,
  type DashStyle,
  type FillStyle,
  type TextAlign,
} from "@/lib/whiteboard/types";
import { Button } from "@/components/ui/button";
import { StepperRow, StepButton } from "./StepperControl";
import { Separator } from "@/components/ui/separator";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";

export function PropertiesPanel() {
  const selectedIds = useWhiteboard((s) => s.selectedIds);
  const activeBoard = useActiveBoard();
  const updateElement = useWhiteboard((s) => s.updateElement);
  const updateElements = useWhiteboard((s) => s.updateElements);
  const deleteSelected = useWhiteboard((s) => s.deleteSelected);
  const duplicateElements = useWhiteboard((s) => s.duplicateElements);
  const toggleLock = useWhiteboard((s) => s.toggleLock);
  const bringToFront = useWhiteboard((s) => s.bringToFront);
  const sendToBack = useWhiteboard((s) => s.sendToBack);
  const commitHistory = useWhiteboard((s) => s.commitHistory);
  const clearSelection = useWhiteboard((s) => s.clearSelection);
  const invertSelection = useWhiteboard((s) => s.invertSelection);
  const selectByType = useWhiteboard((s) => s.selectByType);
  const customLinkTypes = useWhiteboard((s) => s.customLinkTypes);
  const editingId = useWhiteboard((s) => s.editingId);
  const setStyle = useWhiteboard((s) => s.setStyle);
  const propsPanelCollapsed = useWhiteboard((s) => s.propsPanelCollapsed);
  const setPropsPanelCollapsed = useWhiteboard((s) => s.setPropsPanelCollapsed);

  if (selectedIds.length === 0 || !activeBoard) return null;
  // While a text box or sticky note is being typed in, the formatting bar
  // attached to it is the ONE place to style it. Showing this panel as well
  // meant two sets of controls that disagreed - and on a tablet the panel
  // covered the right half of that bar, including its Done button.
  if (editingId) return null;

  const isSingle = selectedIds.length === 1;
  // Selections in a notebook live on the active page; the canvas field is
  // empty there, so this panel rendered nothing for them.
  const boardElements = getBoardElements(activeBoard);
  const el = isSingle ? boardElements.find((item) => item.id === selectedIds[0]) : null;
  const firstSelected = boardElements.find((item) => selectedIds.includes(item.id));
  const currentOpacity = (isSingle ? el?.opacity : firstSelected?.opacity) ?? 1;

  const handleChange = (patch: Partial<WhiteboardElement>, commit = false) => {
    if (!el) return;
    if (commit) commitHistory();
    updateElement(el.id, patch, false);
  };

  /**
   * Text styling from this panel behaves exactly like the text box's own bar:
   * it styles the box AND becomes the default for the next one, so the panel,
   * the bar and the bottom tool bar can never show different values.
   */
  const applyTextStyle = (patch: { fontFamily?: string; fontSize?: number; color?: string }) => {
    if (!el) return;
    handleChange(patch as Partial<WhiteboardElement>, true);
    const st = useWhiteboard.getState().style;
    if (el.type === "text") {
      setStyle({
        ...(patch.fontFamily ? { fontFamily: patch.fontFamily } : {}),
        ...setToolInk(st, "text", { color: patch.color, size: patch.fontSize }),
      });
    } else if (el.type === "sticky" && patch.fontSize !== undefined) {
      setStyle(setToolInk(st, "sticky", { size: patch.fontSize }));
    }
  };

  return (
    // z-50 puts this ABOVE the floating favourites pen bar (z-40). They share
    // the right-hand edge, and the bar was covering the third option of every
    // row here — Solid / Dotted / 8px were unreachable, which read as "the
    // panel does not work". The panel is transient and task-focused, so it wins.
    <div className="absolute top-16 right-5 z-50 flex max-h-[calc(100%-6rem)] w-64 max-w-[calc(100%-2.5rem)] flex-col overflow-hidden rounded-2xl border border-border/80 bg-white/95 shadow-2xl backdrop-blur-xl animate-in fade-in slide-in-from-top-2 dark:bg-zinc-900/95">
      {/* Header */}
      <div className="flex items-center justify-between px-3.5 py-2.5 border-b border-border/70 bg-muted/30">
        <span className="text-xs font-semibold capitalize flex items-center gap-1.5 text-foreground">
          <Palette size={13} className="text-primary" />
          {isSingle ? `${el?.type} Properties` : `${selectedIds.length} Elements Selected`}
        </span>
        <div className="flex items-center gap-0.5">
          <button
            onClick={() => setPropsPanelCollapsed(!propsPanelCollapsed)}
            title={propsPanelCollapsed ? "Expand panel" : "Fold panel to its header"}
            className="p-1 rounded-md hover:bg-muted text-muted-foreground hover:text-foreground"
          >
            {propsPanelCollapsed ? <ChevronDown size={14} /> : <ChevronUp size={14} />}
          </button>
          <button
            onClick={clearSelection}
            className="p-1 rounded-md hover:bg-muted text-muted-foreground hover:text-foreground"
          >
            <X size={14} />
          </button>
        </div>
      </div>

      {!propsPanelCollapsed && (
      <div className="p-3.5 space-y-3.5 max-h-[70vh] overflow-y-auto">
        {/* === Single Element Specific Controls === */}
        {el && (
          <>
            {/* 1. TEXT / STICKY CONTROLS */}
            {(el.type === "text" || el.type === "sticky") && (
              <div className="space-y-2.5">
                <span className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider">
                  Typography
                </span>

                {/* Font size: the ACTUAL value with -/+, presets below. Presets
                    alone could not show a size like 17, so none looked chosen. */}
                <div className="space-y-1.5 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-muted-foreground">Size</span>
                    <div className="flex items-center gap-1">
                      <StepButton
                        direction={-1}
                        value={(el as { fontSize: number }).fontSize}
                        min={10}
                        max={96}
                        onChange={(v) => applyTextStyle({ fontSize: v })}
                        className="h-7 w-7"
                      />
                      <span className="min-w-[44px] text-center text-[12px] font-semibold tabular-nums">
                        {(el as { fontSize: number }).fontSize}px
                      </span>
                      <StepButton
                        direction={1}
                        value={(el as { fontSize: number }).fontSize}
                        min={10}
                        max={96}
                        onChange={(v) => applyTextStyle({ fontSize: v })}
                        className="h-7 w-7"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-5 gap-1">
                    {[14, 18, 24, 32, 48].map((sz) => (
                      <button
                        key={sz}
                        onClick={() => applyTextStyle({ fontSize: sz })}
                        className={cn(
                          "py-0.5 rounded text-[11px] font-semibold border",
                          (el as { fontSize: number }).fontSize === sz
                            ? "bg-primary text-primary-foreground border-primary"
                            : "border-border hover:bg-muted text-foreground"
                        )}
                      >
                        {sz}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Font family for text */}
                {el.type === "text" && (
                  <div className="space-y-1">
                    <span className="text-xs text-muted-foreground">Font Family</span>
                    <div className="grid grid-cols-2 gap-1">
                      {FONT_FAMILIES.map((ff) => (
                        <button
                          key={ff.id}
                          onClick={() => applyTextStyle({ fontFamily: ff.value })}
                          className={cn(
                            "px-2 py-1 rounded text-left text-[11px] border truncate",
                            (el as { fontFamily: string }).fontFamily === ff.value
                              ? "bg-primary text-primary-foreground border-primary"
                              : "border-border hover:bg-muted text-foreground"
                          )}
                          style={{ fontFamily: ff.value }}
                        >
                          {ff.label.split(" ")[0]}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Text Color / Sticky Color */}
                <div className="space-y-1">
                  <span className="text-xs text-muted-foreground">Color</span>
                  {el.type === "sticky" ? (
                    <div className="flex items-center gap-1.5">
                      {Object.entries(STICKY_COLORS).map(([cKey, cVal]) => (
                        <button
                          key={cKey}
                          onClick={() => handleChange({ color: cKey as StickyColor }, true)}
                          className={cn(
                            "w-6 h-6 rounded-full border transition-transform",
                            (el as { color: StickyColor }).color === cKey
                              ? "scale-110 ring-2 ring-primary border-foreground"
                              : "border-border"
                          )}
                          style={{ backgroundColor: cVal.bg }}
                          title={cVal.label}
                        />
                      ))}
                    </div>
                  ) : (
                    <div className="grid grid-cols-5 gap-1.5">
                      {PEN_COLORS.map((c) => (
                        <button
                          key={c}
                          onClick={() => applyTextStyle({ color: c })}
                          className={cn(
                            "w-6 h-6 rounded-full border transition-transform",
                            (el as { color: string }).color === c
                              ? "scale-110 ring-2 ring-primary border-foreground"
                              : "border-border"
                          )}
                          style={{ backgroundColor: c }}
                        />
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* 2. SHAPE CONTROLS (Rectangle, Ellipse, Diamond, Triangle, Star, Cloud) */}
            {["rectangle", "ellipse", "diamond", "triangle", "star", "cloud"].includes(el.type) && (
              <div className="space-y-3">
                <span className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider">
                  Shape Styling
                </span>

                {/* Stroke Color */}
                <div className="space-y-1">
                  <span className="text-xs text-muted-foreground">Border Color</span>
                  <div className="grid grid-cols-5 gap-1.5">
                    {PEN_COLORS.map((c) => (
                      <button
                        key={c}
                        onClick={() => handleChange({ strokeColor: c }, true)}
                        className={cn(
                          "w-6 h-6 rounded-full border",
                          (el as { strokeColor: string }).strokeColor === c ? "scale-110 ring-2 ring-primary" : ""
                        )}
                        style={{ backgroundColor: c }}
                      />
                    ))}
                  </div>
                </div>

                {/* Fill Color */}
                <div className="space-y-1">
                  <span className="text-xs text-muted-foreground">Fill Color</span>
                  <div className="grid grid-cols-5 gap-1.5">
                    {PEN_COLORS.map((c) => (
                      <button
                        key={c}
                        onClick={() => handleChange({ fillColor: c }, true)}
                        className={cn(
                          "w-6 h-6 rounded-full border",
                          (el as { fillColor?: string }).fillColor === c ? "scale-110 ring-2 ring-primary" : ""
                        )}
                        style={{ backgroundColor: c }}
                      />
                    ))}
                  </div>
                </div>

                {/* Fill Style */}
                <div className="space-y-1">
                  <span className="text-xs text-muted-foreground">Fill Mode</span>
                  <div className="grid grid-cols-3 gap-1">
                    {(["transparent", "semi", "solid"] as FillStyle[]).map((fs) => (
                      <button
                        key={fs}
                        onClick={() => handleChange({ fillStyle: fs }, true)}
                        className={cn(
                          "py-1 rounded text-xs capitalize border font-medium",
                          (el as { fillStyle?: FillStyle }).fillStyle === fs
                            ? "bg-primary text-primary-foreground border-primary"
                            : "border-border hover:bg-muted text-foreground"
                        )}
                      >
                        {fs}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Stroke Style */}
                <div className="space-y-1">
                  <span className="text-xs text-muted-foreground">Border Line</span>
                  <div className="grid grid-cols-3 gap-1">
                    {(["solid", "dashed", "dotted"] as DashStyle[]).map((ds) => (
                      <button
                        key={ds}
                        onClick={() => handleChange({ dashStyle: ds }, true)}
                        className={cn(
                          "py-1 rounded text-xs capitalize border font-medium",
                          (el as { dashStyle?: DashStyle }).dashStyle === ds
                            ? "bg-primary text-primary-foreground border-primary"
                            : "border-border hover:bg-muted text-foreground"
                        )}
                      >
                        {ds}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Stroke Width */}
                <div className="space-y-1">
                  <span className="text-xs text-muted-foreground">Border Width</span>
                  <div className="flex items-center justify-between gap-1">
                    {[1, 2, 4, 8].map((w) => (
                      <button
                        key={w}
                        onClick={() => handleChange({ strokeWidth: w }, true)}
                        className={cn(
                          "flex-1 py-1 rounded text-xs border font-medium",
                          (el as { strokeWidth: number }).strokeWidth === w
                            ? "bg-primary text-primary-foreground border-primary"
                            : "border-border hover:bg-muted text-foreground"
                        )}
                      >
                        {w}px
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* 3. CONNECTION / ARROW CONTROLS */}
            {el.type === "connection" && (
              <div className="space-y-3">
                <span className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider">
                  Arrow & Relationship
                </span>

                {/* Routing Mode */}
                <div className="space-y-1">
                  <span className="text-xs text-muted-foreground">Arrow Routing</span>
                  <div className="grid grid-cols-3 gap-1">
                    {(["curved", "orthogonal", "straight"] as ConnectionRouting[]).map((r) => (
                      <button
                        key={r}
                        onClick={() => handleChange({ routing: r }, true)}
                        className={cn(
                          "py-1 rounded text-xs capitalize border font-medium",
                          (el as ConnectionElement).routing === r
                            ? "bg-primary text-primary-foreground border-primary"
                            : "border-border hover:bg-muted text-foreground"
                        )}
                      >
                        {r}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Relationship Type */}
                <div className="space-y-1">
                  <span className="text-xs text-muted-foreground">Relationship Type</span>
                  <div className="space-y-1 max-h-36 overflow-y-auto pr-1">
                    {BUILTIN_LINK_TYPES.map((lt) => (
                      <button
                        key={lt}
                        onClick={() => handleChange({ linkType: lt }, true)}
                        className={cn(
                          "w-full text-left px-2 py-1 rounded text-xs flex items-center justify-between",
                          (el as ConnectionElement).linkType === lt
                            ? "bg-muted font-semibold text-primary"
                            : "hover:bg-muted/50 text-foreground"
                        )}
                      >
                        <div className="flex items-center gap-2">
                          <span
                            className="w-2 h-2 rounded-full"
                            style={{ backgroundColor: LINK_TYPE_COLORS[lt] }}
                          />
                          <span>{LINK_TYPE_LABELS[lt]}</span>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Label edit */}
                <div className="space-y-1">
                  <span className="text-xs text-muted-foreground">Custom Label</span>
                  <input
                    type="text"
                    value={(el as ConnectionElement).label || ""}
                    onChange={(e) => handleChange({ label: e.target.value }, false)}
                    placeholder="e.g. Depends on, Causes..."
                    className="w-full px-2.5 py-1.5 rounded-lg border border-border bg-background text-xs"
                  />
                </div>

                {/* Arrowheads */}
                <div className="space-y-1">
                  <span className="text-xs text-muted-foreground">Arrow Head</span>
                  <div className="grid grid-cols-4 gap-1">
                    {(["arrow", "triangle", "diamond", "circle"] as ArrowheadType[]).map((ah) => (
                      <button
                        key={ah}
                        onClick={() => handleChange({ endArrowhead: ah }, true)}
                        className={cn(
                          "py-1 rounded text-[11px] capitalize border",
                          (el as ConnectionElement).endArrowhead === ah
                            ? "bg-primary text-primary-foreground border-primary"
                            : "border-border hover:bg-muted text-foreground"
                        )}
                      >
                        {ah}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </>
        )}

        {/* === Opacity Control (Universal for Single & Multi Selection) === */}
        <div className="space-y-2 pt-1 border-t border-border/50">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider">
              Opacity
            </span>
            <span className="text-xs font-bold tabular-nums px-2 py-0.5 rounded-md bg-primary/10 text-primary border border-primary/20">
              {Math.round(currentOpacity * 100)}%
            </span>
          </div>

          <StepperRow
            value={Math.round(currentOpacity * 100)}
            min={10}
            max={100}
            step={5}
            onChange={(pct) => {
              const opacity = pct / 100;
              if (selectedIds.length > 1) {
                updateElements(selectedIds, { opacity }, false);
              } else if (el) {
                updateElement(el.id, { opacity }, false);
              }
            }}
            onCommit={() => commitHistory()}
          >
            <input
              type="range"
              min="10"
              max="100"
              step="5"
              value={Math.round(currentOpacity * 100)}
              aria-label="Opacity"
              onChange={(e) => {
                const opacity = Number(e.target.value) / 100;
                if (selectedIds.length > 1) {
                  updateElements(selectedIds, { opacity }, false);
                } else if (el) {
                  updateElement(el.id, { opacity }, false);
                }
              }}
              onMouseUp={() => commitHistory()}
              onTouchEnd={() => commitHistory()}
              className="w-full h-2 bg-muted rounded-lg appearance-none cursor-pointer accent-primary"
            />
          </StepperRow>

          {/* Quick jump presets */}
          <div className="flex items-center justify-between gap-1 pt-0.5">
            {[25, 50, 75, 100].map((pct) => (
              <button
                key={pct}
                type="button"
                onClick={() => {
                  commitHistory();
                  const opacity = pct / 100;
                  if (selectedIds.length > 1) {
                    updateElements(selectedIds, { opacity }, false);
                  } else if (el) {
                    updateElement(el.id, { opacity }, false);
                  }
                }}
                className={cn(
                  "flex-1 py-1 rounded text-[10px] border font-medium transition-colors",
                  Math.round(currentOpacity * 100) === pct
                    ? "border-primary bg-primary text-primary-foreground font-semibold"
                    : "border-border text-muted-foreground hover:bg-muted"
                )}
              >
                {pct}%
              </button>
            ))}
          </div>
        </div>

        <Separator />

        {/* === Universal Actions (Duplicate, Layering, Lock, Delete) === */}
        <div className="space-y-2">
          <span className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider">
            Arrange & Actions
          </span>
          <div className="grid grid-cols-2 gap-1.5">
            <button
              onClick={() => bringToFront(selectedIds)}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-border hover:bg-muted text-xs text-foreground font-medium"
            >
              <BringToFront size={13} />
              <span>Bring to Front</span>
            </button>
            <button
              onClick={() => sendToBack(selectedIds)}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-border hover:bg-muted text-xs text-foreground font-medium"
            >
              <SendToBack size={13} />
              <span>Send to Back</span>
            </button>
            <button
              onClick={() => duplicateElements(selectedIds)}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-border hover:bg-muted text-xs text-foreground font-medium"
            >
              <Copy size={13} />
              <span>Duplicate</span>
            </button>
            <button
              onClick={() => toggleLock(selectedIds)}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-border hover:bg-muted text-xs text-foreground font-medium"
            >
              <Lock size={13} />
              <span>Lock / Unlock</span>
            </button>
            <button
              onClick={() => invertSelection()}
              className="col-span-2 flex items-center justify-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-border hover:bg-muted text-xs text-foreground font-medium"
              title="Invert selection (Ctrl+Shift+V)"
            >
              <CheckSquare size={13} />
              <span>Invert Selection</span>
            </button>
            {el && (
              <button
                onClick={() => {
                  const t =
                    el.type === "stroke"
                      ? "stroke"
                      : el.type === "text"
                      ? "text"
                      : el.type === "sticky"
                      ? "sticky"
                      : el.type === "image"
                      ? "image"
                      : el.type === "connection"
                      ? "connection"
                      : "shape";
                  selectByType(t);
                }}
                className="col-span-2 flex items-center justify-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-border hover:bg-muted text-xs text-foreground font-medium"
              >
                <CheckSquare size={13} />
                <span>
                  Select all{" "}
                  {el.type === "stroke"
                    ? "Ink Strokes"
                    : el.type === "text"
                    ? "Text Notes"
                    : el.type === "sticky"
                    ? "Sticky Notes"
                    : el.type === "image"
                    ? "Images"
                    : el.type === "connection"
                    ? "Connectors"
                    : "Shapes"}
                </span>
              </button>
            )}
          </div>

          <button
            onClick={deleteSelected}
            className="w-full flex items-center justify-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-destructive/10 text-destructive hover:bg-destructive hover:text-destructive-foreground transition-colors text-xs font-semibold"
          >
            <Trash2 size={13} />
            <span>Delete Selected</span>
          </button>
        </div>
      </div>
      )}
    </div>
  );
}
