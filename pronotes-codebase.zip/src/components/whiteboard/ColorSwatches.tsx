"use client";

/**
 * Colour controls shared by the contextual property bar and the tool panel.
 *
 * Includes a real custom-colour control (the rainbow disc), because a fixed
 * palette is the single most common complaint about note apps' pen tools —
 * users want *their* colour, not the nearest preset.
 */

import React from "react";
import { useWhiteboard } from "@/store/whiteboard";
import { cn } from "@/lib/utils";

/** One round colour chip. */
export function Swatch({
  color,
  active,
  onSelect,
  size = 22,
  title,
}: {
  color: string;
  active: boolean;
  onSelect: () => void;
  size?: number;
  title?: string;
}) {
  return (
    <button
      onClick={onSelect}
      title={title ?? color}
      aria-label={title ?? color}
      className={cn(
        "shrink-0 rounded-full border transition-transform",
        active
          ? "scale-110 border-foreground ring-2 ring-primary ring-offset-1 ring-offset-background"
          : "border-black/15 hover:scale-105 dark:border-white/20"
      )}
      style={{ backgroundColor: color, width: size, height: size }}
    />
  );
}

/**
 * The rainbow disc: opens the OS colour picker. Rendered as a label wrapping a
 * visually-hidden <input type="color"> — the native control is the only way to
 * get a full picker (including eyedropper on desktop) without shipping one.
 */
export function CustomColorButton({
  value,
  onChange,
  size = 22,
}: {
  value: string;
  onChange: (color: string) => void;
  size?: number;
}) {
  return (
    <label
      title="Custom colour…"
      className="relative shrink-0 cursor-pointer rounded-full border border-black/15 transition-transform hover:scale-105 dark:border-white/20"
      style={{
        width: size,
        height: size,
        background:
          "conic-gradient(#ef4444,#f97316,#eab308,#22c55e,#06b6d4,#3b82f6,#8b5cf6,#ec4899,#ef4444)",
      }}
    >
      <input
        type="color"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="absolute inset-0 h-full w-full cursor-pointer opacity-0"
      />
      {/* Hole in the middle so the disc reads as a picker, not a colour. */}
      <span
        className="pointer-events-none absolute rounded-full bg-background"
        style={{ inset: size * 0.3 }}
      />
    </label>
  );
}

/**
 * Palette + recents + custom, as used inside the tool panel.
 * `compact` renders the single row used by the contextual bar.
 */
export function ColorRow({
  colors,
  value,
  onChange,
  compact = false,
  swatchSize = 22,
}: {
  colors: string[];
  value: string;
  onChange: (c: string) => void;
  compact?: boolean;
  swatchSize?: number;
}) {
  const recentColors = useWhiteboard((s) => s.recentColors);
  const addRecentColor = useWhiteboard((s) => s.addRecentColor);

  const pick = (c: string) => {
    onChange(c);
    addRecentColor(c);
  };

  // In the compact row, recents come first: the colour you just mixed is the
  // one you are most likely to want again, and it would otherwise be lost.
  const shown = compact
    ? [...recentColors.filter((c) => !colors.includes(c)).slice(0, 2), ...colors].slice(0, 7)
    : colors;

  return (
    <div className={cn("flex items-center gap-1.5", !compact && "flex-wrap")}>
      {shown.map((c) => (
        <Swatch
          key={c}
          color={c}
          size={swatchSize}
          active={value.toLowerCase() === c.toLowerCase()}
          onSelect={() => pick(c)}
        />
      ))}
      <CustomColorButton value={value} onChange={pick} size={swatchSize} />

      {!compact && recentColors.length > 0 && (
        <div className="mt-2 w-full">
          <div className="mb-1 text-[11px] text-muted-foreground">Recent</div>
          <div className="flex flex-wrap items-center gap-1.5">
            {recentColors.map((c) => (
              <Swatch
                key={`recent-${c}`}
                color={c}
                size={swatchSize}
                active={value.toLowerCase() === c.toLowerCase()}
                onSelect={() => pick(c)}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
