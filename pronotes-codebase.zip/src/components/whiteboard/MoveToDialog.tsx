"use client";

/**
 * Move-to dialog: file a board/notebook or folder anywhere by browsing.
 *
 * Why a dialog and not only drag-and-drop: drag needs a visible target, but a
 * destination five levels deep (or a 200-board sidebar) is faster reached by
 * drilling down a path — or by typing a name. The dialog shows top-level
 * folders, tapping one walks into it (breadcrumb across the top walks back
 * out), and "Move here" files the item where you stand. Search jumps straight
 * to any folder. The store still rejects cycles, self-drops and ghosts, so the
 * dialog only ever disables what would be a no-op.
 */

import React from "react";
import {
  Check,
  ChevronRight,
  Folder as FolderIcon,
  FolderInput,
  House,
  NotebookText,
  Search,
  X,
} from "lucide-react";
import { useWhiteboard } from "@/store/whiteboard";
import { getPages, isNotebook } from "@/lib/whiteboard/notebook";
import type { Board, Folder } from "@/lib/whiteboard/types";
import { isDescendantFolder } from "./Sidebar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { cn } from "@/lib/utils";

export interface MoveToItem {
  kind: "board" | "folder";
  id: string;
  name: string;
}

export type DestinationTarget =
  | { kind: "folder"; folderId: string | null; name: string }
  | { kind: "notebook"; boardId: string; name: string; pageCount: number };

/** Folder ids from the top level down to `id` (inclusive). Empty = top level. */
export function chainTo(folders: Folder[], id: string | null): string[] {
  if (id === null) return [];
  const chain: string[] = [];
  const seen = new Set<string>();
  let cursor: string | null = id;
  while (cursor && !seen.has(cursor)) {
    seen.add(cursor);
    chain.unshift(cursor);
    cursor = folders.find((f) => f.id === cursor)?.parentId ?? null;
  }
  return chain;
}

export function folderName(folders: Folder[], id: string): string {
  return folders.find((f) => f.id === id)?.name ?? "…";
}

export interface DestinationBrowserProps {
  selectedTarget: DestinationTarget;
  onSelectTarget: (target: DestinationTarget) => void;
  allowNotebookTarget?: boolean;
  excludeBoardId?: string;
  moveItem?: MoveToItem | null;
  className?: string;
}

export function DestinationBrowser({
  selectedTarget,
  onSelectTarget,
  allowNotebookTarget = false,
  excludeBoardId,
  moveItem,
  className,
}: DestinationBrowserProps) {
  const folders = useWhiteboard((s) => s.folders);
  const boards = useWhiteboard((s) => s.boards);

  const [path, setPath] = React.useState<string[]>([]);
  const [query, setQuery] = React.useState("");

  const destId = path.length > 0 ? path[path.length - 1] : null;
  const destLabel = destId === null ? "Top level" : folderName(folders, destId);

  const childrenFolders = folders.filter((f) => (f.parentId ?? null) === destId);
  const notebooksHere = allowNotebookTarget
    ? boards.filter(
        (b) =>
          isNotebook(b) &&
          (b.folderId ?? null) === destId &&
          (!excludeBoardId || b.id !== excludeBoardId)
      )
    : [];

  const containedCount = (folderId: string) =>
    folders.filter((f) => f.parentId === folderId).length +
    boards.filter((b) => b.folderId === folderId).length;

  const q = query.trim().toLowerCase();
  const searchFolderHits = q
    ? folders.filter((f) => f.name.toLowerCase().includes(q))
    : [];
  const searchNotebookHits =
    q && allowNotebookTarget
      ? boards.filter(
          (b) =>
            isNotebook(b) &&
            b.name.toLowerCase().includes(q) &&
            (!excludeBoardId || b.id !== excludeBoardId)
        )
      : [];

  const selectFolder = (folderId: string | null) => {
    onSelectTarget({
      kind: "folder",
      folderId,
      name: folderId === null ? "Top level" : folderName(folders, folderId),
    });
  };

  const selectNotebook = (b: Board) => {
    onSelectTarget({
      kind: "notebook",
      boardId: b.id,
      name: b.name,
      pageCount: getPages(b).length,
    });
  };

  return (
    <div className={cn("space-y-2", className)}>
      {/* Search box */}
      <div className="relative">
        <Search
          size={13}
          className="absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground"
        />
        <Input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder={allowNotebookTarget ? "Search folders & notebooks…" : "Search folders…"}
          aria-label={allowNotebookTarget ? "Search folders and notebooks" : "Search folders"}
          className="h-8 pl-8 pr-7 text-xs"
        />
        {query && (
          <button
            type="button"
            onClick={() => setQuery("")}
            aria-label="Clear search"
            className="absolute right-1.5 top-1/2 -translate-y-1/2 rounded p-0.5 text-muted-foreground hover:text-foreground"
          >
            <X size={13} />
          </button>
        )}
      </div>

      {q ? (
        /* Flat hits across folders and notebooks */
        <div className="max-h-56 overflow-y-auto space-y-1 pr-1">
          {searchFolderHits.length === 0 && searchNotebookHits.length === 0 ? (
            <p className="px-2 py-6 text-center text-xs text-muted-foreground">
              Nothing matches “{query}”.
            </p>
          ) : (
            <>
              {searchFolderHits.map((f) => (
                <button
                  key={f.id}
                  type="button"
                  onClick={() => {
                    setPath(chainTo(folders, f.id));
                    setQuery("");
                    selectFolder(f.id);
                  }}
                  className="flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-left transition-colors hover:bg-muted"
                >
                  <FolderIcon
                    size={15}
                    className="shrink-0"
                    style={{ color: f.color || "#f59e0b" }}
                  />
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-xs font-medium">{f.name}</span>
                    <span className="block truncate text-[10px] text-muted-foreground">
                      {chainTo(folders, f.parentId ?? null)
                        .map((id) => folderName(folders, id))
                        .join(" / ") || "Top level"}
                    </span>
                  </span>
                  <ChevronRight size={14} className="shrink-0 text-muted-foreground" />
                </button>
              ))}
              {searchNotebookHits.map((nb) => {
                const isSelected =
                  selectedTarget.kind === "notebook" && selectedTarget.boardId === nb.id;
                return (
                  <button
                    key={nb.id}
                    type="button"
                    onClick={() => {
                      selectNotebook(nb);
                      setQuery("");
                    }}
                    className={cn(
                      "flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-left transition-colors",
                      isSelected
                        ? "bg-primary/10 text-primary border border-primary/40 font-medium"
                        : "hover:bg-muted"
                    )}
                  >
                    <NotebookText size={15} className="shrink-0 text-primary" />
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-xs font-medium">{nb.name}</span>
                      <span className="block truncate text-[10px] text-muted-foreground">
                        {chainTo(folders, nb.folderId ?? null)
                          .map((id) => folderName(folders, id))
                          .join(" / ") || "Top level"}
                      </span>
                    </span>
                    <span className="shrink-0 text-[10px] text-muted-foreground tabular-nums">
                      {getPages(nb).length} pages
                    </span>
                  </button>
                );
              })}
            </>
          )}
        </div>
      ) : (
        <>
          {/* Breadcrumb back out */}
          <div className="flex items-center gap-1 overflow-x-auto py-1">
            <button
              type="button"
              onClick={() => {
                setPath([]);
                selectFolder(null);
              }}
              title="Top level"
              aria-label="Go to top level"
              className={cn(
                "flex shrink-0 items-center gap-1 rounded-md px-1.5 py-1 text-[11px] transition-colors",
                path.length === 0 && selectedTarget.kind === "folder"
                  ? "bg-primary/10 font-semibold text-primary"
                  : "text-muted-foreground hover:bg-muted"
              )}
            >
              <House size={12} />
            </button>
            {path.map((id, i) => (
              <React.Fragment key={id}>
                <ChevronRight size={12} className="shrink-0 text-muted-foreground/60" />
                <button
                  type="button"
                  onClick={() => {
                    setPath(path.slice(0, i + 1));
                    selectFolder(id);
                  }}
                  className={cn(
                    "shrink-0 truncate rounded-md px-1.5 py-1 text-[11px] transition-colors max-w-[120px]",
                    i === path.length - 1 && selectedTarget.kind === "folder"
                      ? "bg-primary/10 font-semibold text-primary"
                      : "text-muted-foreground hover:bg-muted"
                  )}
                >
                  {folderName(folders, id)}
                </button>
              </React.Fragment>
            ))}
          </div>

          {/* Folder & notebook items list */}
          <div className="max-h-56 overflow-y-auto space-y-1 pr-1 border border-border/60 rounded-lg p-1">
            {/* When notebook target is allowed and user is in a folder, give option to stay on folder */}
            {allowNotebookTarget && (
              <button
                type="button"
                onClick={() => selectFolder(destId)}
                className={cn(
                  "flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-left transition-colors",
                  selectedTarget.kind === "folder" && selectedTarget.folderId === destId
                    ? "bg-primary/10 text-primary border border-primary/30 font-medium"
                    : "hover:bg-muted/70 text-muted-foreground"
                )}
              >
                <FolderIcon size={14} className="shrink-0" />
                <span className="flex-1 text-xs truncate">
                  {destId === null ? "Top level (no folder)" : `This folder (${destLabel})`}
                </span>
                {selectedTarget.kind === "folder" && selectedTarget.folderId === destId && (
                  <Check size={13} className="text-primary shrink-0" />
                )}
              </button>
            )}

            {childrenFolders.length === 0 && notebooksHere.length === 0 ? (
              <p className="px-2 py-4 text-center text-xs text-muted-foreground">
                {destId === null && folders.length === 0
                  ? "No folders yet."
                  : "No subfolders or notebooks here."}
              </p>
            ) : null}

            {childrenFolders.map((f) => {
              const invalid =
                moveItem?.kind === "folder" &&
                (f.id === moveItem.id || isDescendantFolder(folders, moveItem.id, f.id));
              return (
                <button
                  key={f.id}
                  type="button"
                  disabled={invalid}
                  onClick={() => {
                    setPath([...path, f.id]);
                    selectFolder(f.id);
                  }}
                  title={invalid ? "Cannot move a folder into itself" : `Open ${f.name}`}
                  className={cn(
                    "flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-left transition-colors",
                    invalid ? "opacity-40" : "hover:bg-muted"
                  )}
                >
                  <FolderIcon
                    size={15}
                    className="shrink-0"
                    style={{ color: f.color || "#f59e0b" }}
                  />
                  <span className="min-w-0 flex-1 truncate text-xs font-medium">
                    {f.name}
                  </span>
                  <span className="shrink-0 text-[10px] tabular-nums text-muted-foreground">
                    {containedCount(f.id) > 0 ? containedCount(f.id) : ""}
                  </span>
                  <ChevronRight size={14} className="shrink-0 text-muted-foreground" />
                </button>
              );
            })}

            {notebooksHere.map((nb) => {
              const isSelected =
                selectedTarget.kind === "notebook" && selectedTarget.boardId === nb.id;
              return (
                <button
                  key={nb.id}
                  type="button"
                  onClick={() => selectNotebook(nb)}
                  className={cn(
                    "flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-left transition-colors",
                    isSelected
                      ? "bg-primary/10 text-primary border border-primary/40 font-medium"
                      : "hover:bg-muted"
                  )}
                >
                  <NotebookText size={15} className="shrink-0 text-primary" />
                  <span className="min-w-0 flex-1 truncate text-xs font-medium">
                    {nb.name}
                  </span>
                  <span className="shrink-0 text-[10px] tabular-nums text-muted-foreground">
                    {getPages(nb).length} pages
                  </span>
                  {isSelected && <Check size={13} className="text-primary shrink-0 ml-1" />}
                </button>
              );
            })}
          </div>
        </>
      )}
    </div>
  );
}

export function MoveToDialog({
  open,
  onClose,
  item,
  currentParentId,
}: {
  open: boolean;
  onClose: () => void;
  item: MoveToItem | null;
  currentParentId: string | null;
}) {
  const folders = useWhiteboard((s) => s.folders);
  const moveBoard = useWhiteboard((s) => s.moveBoard);
  const moveFolder = useWhiteboard((s) => s.moveFolder);

  const [target, setTarget] = React.useState<DestinationTarget>({
    kind: "folder",
    folderId: null,
    name: "Top level",
  });

  React.useEffect(() => {
    if (open) {
      setTarget({ kind: "folder", folderId: null, name: "Top level" });
    }
  }, [open, item?.id]);

  if (!item) return null;

  const destId = target.kind === "folder" ? target.folderId : null;

  // A destination is useless (button disabled, never applied) when it is where
  // the item already is, the item itself, or — for folders — its own subtree.
  const destInvalid =
    destId === currentParentId ||
    (item.kind === "folder" &&
      destId !== null &&
      (destId === item.id || isDescendantFolder(folders, item.id, destId)));

  const applyMove = () => {
    if (destInvalid) return;
    if (item.kind === "board") moveBoard(item.id, destId);
    else moveFolder(item.id, destId);
    onClose();
  };

  const destLabel = destId === null ? "Top level" : folderName(folders, destId);

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-sm p-0 gap-0 overflow-hidden">
        <DialogHeader className="px-4 pb-2 pt-4 text-left">
          <DialogTitle className="flex items-center gap-2 text-base">
            <FolderInput size={17} className="shrink-0 text-primary" />
            Move “{item.name}”
          </DialogTitle>
          <DialogDescription className="text-xs">
            {item.kind === "board"
              ? "Pick the folder it should live in."
              : "Pick the folder it should move into."}
          </DialogDescription>
        </DialogHeader>

        <div className="px-4 pb-2">
          <DestinationBrowser
            selectedTarget={target}
            onSelectTarget={setTarget}
            allowNotebookTarget={false}
            moveItem={item}
          />
        </div>

        <DialogFooter className="flex-row items-center justify-between gap-2 border-t border-border px-4 py-3">
          <Button variant="ghost" size="sm" onClick={onClose}>
            Cancel
          </Button>
          <Button size="sm" disabled={destInvalid} onClick={applyMove} className="gap-1.5">
            <Check size={14} />
            {destId === currentParentId
              ? "Already here"
              : destId === null
                ? "Move to top level"
                : `Move to ${destLabel}`}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export function BatchMoveDialog({
  open,
  onClose,
  boardIds,
  folderIds = [],
  onMoved,
}: {
  open: boolean;
  onClose: () => void;
  boardIds: string[];
  /** Folders move one by one; the store rejects cycles, so no bad move applies. */
  folderIds?: string[];
  onMoved?: () => void;
}) {
  const folders = useWhiteboard((s) => s.folders);
  const batchMoveBoards = useWhiteboard((s) => s.batchMoveBoards);
  const moveFolder = useWhiteboard((s) => s.moveFolder);

  const [target, setTarget] = React.useState<DestinationTarget>({
    kind: "folder",
    folderId: null,
    name: "Top level",
  });

  React.useEffect(() => {
    if (open) {
      setTarget({ kind: "folder", folderId: null, name: "Top level" });
    }
  }, [open]);

  const total = boardIds.length + folderIds.length;
  if (!open || total === 0) return null;

  const destId = target.kind === "folder" ? target.folderId : null;
  const destLabel = destId === null ? "Top level" : folderName(folders, destId);

  const applyMove = () => {
    batchMoveBoards(boardIds, destId);
    for (const id of folderIds) moveFolder(id, destId);
    onMoved?.();
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-sm p-0 gap-0 overflow-hidden">
        <DialogHeader className="px-4 pb-2 pt-4 text-left">
          <DialogTitle className="flex items-center gap-2 text-base">
            <FolderInput size={17} className="shrink-0 text-primary" />
            Move {total} {total === 1 ? "Item" : "Items"}
          </DialogTitle>
          <DialogDescription className="text-xs">
            Pick the destination folder for selected items.
          </DialogDescription>
        </DialogHeader>

        <div className="px-4 pb-2">
          <DestinationBrowser
            selectedTarget={target}
            onSelectTarget={setTarget}
            allowNotebookTarget={false}
          />
        </div>

        <DialogFooter className="flex-row items-center justify-between gap-2 border-t border-border px-4 py-3">
          <Button variant="ghost" size="sm" onClick={onClose}>
            Cancel
          </Button>
          <Button size="sm" onClick={applyMove} className="gap-1.5">
            <Check size={14} />
            {destId === null ? "Move to top level" : `Move to ${destLabel}`}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
