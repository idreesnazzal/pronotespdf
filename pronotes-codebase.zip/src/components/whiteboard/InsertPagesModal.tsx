"use client";

/**
 * Insert pages into the notebook you are in.
 *
 * Two sources, one flow, because the question is the same either way: WHICH
 * pages, from WHERE, and WHERE DO THEY GO.
 *
 *   - another notebook or whiteboard already in the app, found by name;
 *   - a PDF file from the device.
 *
 * The three steps stay on one screen rather than becoming a wizard: picking
 * "pages 2-5 of last year's notes, after page 12" is one thought, and a wizard
 * would make you commit to the source before it tells you how many pages it
 * even has.
 *
 * Everything COPIES. The source notebook is never modified, so a mistake here
 * costs a delete rather than work you cannot get back.
 */

import React from "react";
import { FileText, NotebookText, Search, X, Layers, AlertTriangle } from "lucide-react";
import { useWhiteboard, useActiveBoard } from "@/store/whiteboard";
import { getPages, isNotebook, pageSizeOf, resolvePageRange } from "@/lib/whiteboard/notebook";
import type { Board } from "@/lib/whiteboard/types";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface InsertPagesModalProps {
  open: boolean;
  onClose: () => void;
}

/** A chosen source: a board in the app, or a PDF picked from the device. */
type Source =
  | { kind: "board"; board: Board; pageCount: number }
  | { kind: "pdf"; file: File; pageCount: number };

/** Where the pages go, expressed the way people say it out loud. */
type Placement = "start" | "before" | "after" | "end";

const PLACEMENTS: Array<{ id: Placement; label: string }> = [
  { id: "start", label: "At the beginning" },
  { id: "before", label: "Before this page" },
  { id: "after", label: "After this page" },
  { id: "end", label: "At the end" },
];

/** A number input that tolerates being empty while you type. */
function PageNumberInput({
  value,
  onChange,
  max,
  label,
}: {
  value: string;
  onChange: (v: string) => void;
  max: number;
  label: string;
}) {
  return (
    <input
      type="number"
      inputMode="numeric"
      min={1}
      max={max}
      value={value}
      aria-label={label}
      onChange={(e) => onChange(e.target.value)}
      className="w-16 h-8 rounded-lg border border-border bg-background px-2 text-center text-sm tabular-nums focus:border-primary focus:outline-none"
    />
  );
}

export function InsertPagesModal({ open, onClose }: InsertPagesModalProps) {
  const activeBoard = useActiveBoard();
  const boards = useWhiteboard((s) => s.boards);
  const insertPagesFromBoard = useWhiteboard((s) => s.insertPagesFromBoard);
  const insertPdfPages = useWhiteboard((s) => s.insertPdfPages);

  const [query, setQuery] = React.useState("");
  const [source, setSource] = React.useState<Source | null>(null);
  const [from, setFrom] = React.useState("1");
  const [to, setTo] = React.useState("1");
  const [placement, setPlacement] = React.useState<Placement>("after");
  const [busy, setBusy] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const [done, setDone] = React.useState<string | null>(null);
  const fileInputRef = React.useRef<HTMLInputElement | null>(null);

  const targetPages = getPages(activeBoard);
  const activeIndex = Math.max(
    0,
    targetPages.findIndex((p) => p.id === activeBoard?.activePageId)
  );

  // A fresh dialog every time: a stale source from last week's insert is far
  // more confusing than re-picking it.
  React.useEffect(() => {
    if (!open) return;
    setQuery("");
    setSource(null);
    setFrom("1");
    setTo("1");
    setPlacement("after");
    setError(null);
    setDone(null);
    setBusy(false);
  }, [open]);

  /** Choosing a source pre-fills the range to "all of it" - the common case. */
  const chooseSource = (s: Source) => {
    setSource(s);
    setFrom("1");
    setTo(String(s.pageCount));
    setError(null);
    setDone(null);
  };

  const candidates = React.useMemo(() => {
    const q = query.trim().toLowerCase();
    return boards
      .filter((b) => b.id !== activeBoard?.id)
      .filter((b) => (q ? b.name.toLowerCase().includes(q) : true))
      .sort((a, b) => (b.accessedAt ?? b.updatedAt ?? 0) - (a.accessedAt ?? a.updatedAt ?? 0))
      .slice(0, 40);
  }, [boards, query, activeBoard?.id]);

  const pickPdf = async (file: File) => {
    setError(null);
    setBusy(true);
    try {
      // The page count has to come from the document itself; a range box that
      // does not know the maximum cannot clamp or validate anything.
      const { readPdfFile, openPdf } = await import("@/lib/whiteboard/pdf");
      const bytes = await readPdfFile(file);
      const doc = await openPdf(bytes);
      chooseSource({ kind: "pdf", file, pageCount: doc.numPages });
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const range = source
    ? resolvePageRange(source.pageCount, Number(from), Number(to))
    : { from: 0, to: 0, indices: [] as number[] };

  const insertIndex =
    placement === "start"
      ? 0
      : placement === "end"
      ? targetPages.length
      : placement === "before"
      ? activeIndex
      : activeIndex + 1;

  /**
   * Pages keep their own contents but land on THIS notebook's sheet, so a
   * different shape means the imported page is letterboxed. Worth saying
   * before the insert, not discovering afterwards on 60 pages.
   */
  const sizeWarning = React.useMemo(() => {
    if (!source || source.kind !== "board" || !activeBoard) return null;
    const a = pageSizeOf(activeBoard);
    const b = pageSizeOf(source.board);
    const ratio = (s: { width: number; height: number }) => s.width / s.height;
    if (Math.abs(ratio(a) - ratio(b)) < 0.02) return null;
    return `"${source.board.name}" uses a differently shaped page (${Math.round(b.width)}x${Math.round(
      b.height
    )} against this notebook's ${Math.round(a.width)}x${Math.round(a.height)}). Inserted pages keep their contents but sit on this notebook's sheet.`;
  }, [source, activeBoard]);

  const handleInsert = async () => {
    if (!source || range.indices.length === 0) return;
    setBusy(true);
    setError(null);
    try {
      const n =
        source.kind === "board"
          ? insertPagesFromBoard(source.board.id, { from: range.from, to: range.to }, insertIndex)
          : await insertPdfPages(source.file, { from: range.from, to: range.to }, insertIndex);

      if (n === 0) {
        setError("Nothing was inserted. Check that those pages exist.");
        return;
      }
      setDone(`Inserted ${n} page${n === 1 ? "" : "s"}.`);
      onClose();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  };

  if (!activeBoard) return null;

  const notANotebook = !isNotebook(activeBoard);

  return (
    <Dialog open={open} onOpenChange={(isOpen) => !isOpen && onClose()}>
      <DialogContent className="max-w-2xl p-0 gap-0 overflow-hidden bg-white/98 dark:bg-zinc-900/98 backdrop-blur-xl border border-border/80 shadow-2xl rounded-2xl">
        <DialogHeader className="px-6 py-4 border-b border-border/60 bg-muted/20 space-y-0.5">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-primary/10 text-primary flex items-center justify-center">
              <Layers size={18} />
            </div>
            <div>
              <DialogTitle className="text-base font-semibold">Insert pages</DialogTitle>
              <DialogDescription className="text-xs text-muted-foreground">
                Copy pages from another notebook or a PDF into &ldquo;{activeBoard.name}&rdquo;.
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>

        {notANotebook ? (
          <div className="p-6 text-sm text-muted-foreground">
            Pages can only be inserted into a notebook. This board is a whiteboard, which is a
            single infinite canvas rather than a stack of sheets.
          </div>
        ) : (
          <div className="p-6 space-y-5 max-h-[70vh] overflow-y-auto">
            {/* ---------------- Step 1: where from ---------------- */}
            <section className="space-y-2">
              <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                1. Take pages from
              </h3>

              {source ? (
                <div className="flex items-center gap-2 rounded-xl border border-primary/50 bg-primary/5 px-3 py-2">
                  {source.kind === "pdf" ? (
                    <FileText size={16} className="text-primary shrink-0" />
                  ) : (
                    <NotebookText size={16} className="text-primary shrink-0" />
                  )}
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-sm font-medium">
                      {source.kind === "pdf" ? source.file.name : source.board.name}
                    </div>
                    <div className="text-[11px] text-muted-foreground">
                      {source.pageCount} page{source.pageCount === 1 ? "" : "s"}
                      {source.kind === "pdf" ? " · PDF file" : ""}
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setSource(null)}
                    aria-label="Choose a different source"
                    className="p-1 rounded-md hover:bg-muted text-muted-foreground"
                  >
                    <X size={14} />
                  </button>
                </div>
              ) : (
                <>
                  <div className="relative">
                    <Search
                      size={14}
                      className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground"
                    />
                    <input
                      autoFocus
                      value={query}
                      onChange={(e) => setQuery(e.target.value)}
                      placeholder="Search your notebooks by name..."
                      className="w-full h-9 rounded-lg border border-border bg-background pl-9 pr-3 text-sm focus:border-primary focus:outline-none"
                    />
                  </div>

                  <div className="max-h-48 overflow-y-auto rounded-lg border border-border/60 divide-y divide-border/40">
                    {candidates.length === 0 && (
                      <div className="px-3 py-6 text-center text-xs text-muted-foreground">
                        {query ? `No notebook matches "${query}".` : "There is nothing else to copy from yet."}
                      </div>
                    )}
                    {candidates.map((b) => {
                      const count = isNotebook(b) ? getPages(b).length : 1;
                      return (
                        <button
                          key={b.id}
                          type="button"
                          onClick={() => chooseSource({ kind: "board", board: b, pageCount: count })}
                          className="w-full flex items-center gap-2.5 px-3 py-2 text-left hover:bg-muted/60 transition-colors"
                        >
                          <NotebookText size={15} className="text-muted-foreground shrink-0" />
                          <span className="flex-1 truncate text-sm">{b.name}</span>
                          <span className="text-[11px] text-muted-foreground tabular-nums shrink-0">
                            {count} {isNotebook(b) ? "pages" : "canvas"}
                          </span>
                        </button>
                      );
                    })}
                  </div>

                  <div className="flex items-center gap-2">
                    <div className="h-px flex-1 bg-border/60" />
                    <span className="text-[11px] text-muted-foreground">or</span>
                    <div className="h-px flex-1 bg-border/60" />
                  </div>

                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="application/pdf,.pdf"
                    className="hidden"
                    onChange={(e) => {
                      const f = e.target.files?.[0];
                      // Cleared so picking the SAME file twice still fires.
                      e.target.value = "";
                      if (f) void pickPdf(f);
                    }}
                  />
                  <Button
                    variant="outline"
                    className="w-full gap-2"
                    disabled={busy}
                    onClick={() => fileInputRef.current?.click()}
                  >
                    <FileText size={15} />
                    {busy ? "Reading PDF..." : "Choose a PDF file"}
                  </Button>
                </>
              )}
            </section>

            {/* ---------------- Step 2: which pages ---------------- */}
            {source && (
              <section className="space-y-2">
                <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                  2. Which pages
                </h3>
                <div className="flex flex-wrap items-center gap-2 text-sm">
                  <span className="text-muted-foreground">From page</span>
                  <PageNumberInput value={from} onChange={setFrom} max={source.pageCount} label="First page" />
                  <span className="text-muted-foreground">to</span>
                  <PageNumberInput value={to} onChange={setTo} max={source.pageCount} label="Last page" />
                  <button
                    type="button"
                    onClick={() => {
                      setFrom("1");
                      setTo(String(source.pageCount));
                    }}
                    className="ml-1 rounded-md border border-border px-2 py-1 text-[11px] font-medium hover:bg-muted"
                  >
                    All {source.pageCount}
                  </button>
                </div>
                <p className="text-[11px] text-muted-foreground">
                  {range.indices.length > 0
                    ? `${range.indices.length} page${range.indices.length === 1 ? "" : "s"} (${range.from}-${range.to}) will be copied.`
                    : "That range is empty."}
                </p>
              </section>
            )}

            {/* ---------------- Step 3: where to ---------------- */}
            {source && (
              <section className="space-y-2">
                <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                  3. Put them
                </h3>
                <div className="grid grid-cols-2 gap-1.5">
                  {PLACEMENTS.map((p) => (
                    <button
                      key={p.id}
                      type="button"
                      onClick={() => setPlacement(p.id)}
                      className={cn(
                        "py-1.5 px-2 rounded-lg border text-xs font-medium transition-all",
                        placement === p.id
                          ? "border-primary bg-primary/10 text-primary font-semibold"
                          : "border-border hover:bg-muted text-foreground"
                      )}
                    >
                      {p.label}
                    </button>
                  ))}
                </div>
                <p className="text-[11px] text-muted-foreground">
                  You are on page {activeIndex + 1} of {targetPages.length}. The pages will become
                  page{range.indices.length === 1 ? "" : "s"}{" "}
                  {insertIndex + 1}
                  {range.indices.length > 1 ? `-${insertIndex + range.indices.length}` : ""} of{" "}
                  {targetPages.length + range.indices.length}.
                </p>
              </section>
            )}

            {sizeWarning && (
              <div className="flex gap-2 rounded-lg border border-amber-500/40 bg-amber-500/10 px-3 py-2 text-[11px] leading-snug text-amber-700 dark:text-amber-400">
                <AlertTriangle size={14} className="shrink-0 mt-0.5" />
                <span>{sizeWarning}</span>
              </div>
            )}
            {error && (
              <div
                role="alert"
                className="rounded-lg border border-red-500/40 bg-red-500/10 px-3 py-2 text-[11px] text-red-600 dark:text-red-400"
              >
                {error}
              </div>
            )}
            {done && (
              <div role="status" className="text-[11px] text-emerald-600 dark:text-emerald-400">
                {done}
              </div>
            )}

            <div className="flex gap-2 pt-1">
              <Button variant="outline" className="flex-1" onClick={onClose} disabled={busy}>
                Cancel
              </Button>
              <Button
                className="flex-1 font-semibold"
                disabled={!source || busy || range.indices.length === 0}
                onClick={handleInsert}
              >
                {busy
                  ? "Inserting..."
                  : `Insert ${range.indices.length || ""} page${range.indices.length === 1 ? "" : "s"}`}
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
