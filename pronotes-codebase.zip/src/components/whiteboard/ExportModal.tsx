"use client";

/**
 * Export / share.
 *
 * Rebuilt around the question people actually arrive with: "send THESE pages,
 * as THIS kind of file, to THAT app." The three answers are on one screen,
 * in that order, the way GoodNotes, Notability and Notewise all arrange it:
 *
 *   1. WHICH PAGES - tick them on thumbnails, or type "2-5, 8". The two stay
 *      in sync, because picking 30 of 69 pages by tapping is miserable and
 *      typing a range you cannot see is guesswork.
 *   2. WHAT FILE   - PDF, PNG, JPEG, WEBP or SVG, each with the one line that
 *      says when to choose it.
 *   3. WHERE       - "Share" opens the system app chooser; "Save" writes the
 *      file. On Android saving IS the share sheet, which offers Save to Files.
 *
 * Two things this must never do again, both reported from the tablet:
 *   - go quiet. Rasterising 40 sheets takes real time, and a button that just
 *     sits there reads as a crash. Every sheet reports into a progress bar.
 *   - claim success it did not have. A cancelled share, a partial export and a
 *     failure are three different messages, and none of them close the dialog
 *     pretending the file went out.
 *
 * Thumbnails render lazily. A 69-page notebook must not build 69 previews to
 * show the first four.
 */

import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Check,
  Copy,
  Download,
  FileCode,
  FileText,
  Image as ImageIcon,
  Loader2,
  Share2,
  X,
} from "lucide-react";
import { useWhiteboard, useActiveBoard } from "@/store/whiteboard";
import {
  allElements,
  formatPageSelection,
  getActivePageIndex,
  getPages,
  isNotebook,
  pageSizeOf,
  parsePageSelection,
} from "@/lib/whiteboard/notebook";
import {
  buildExportSvg,
  canChooseApp,
  copyPngToClipboard,
  exportBoard,
  isNativeApp,
  resolveExportImages,
  resolvePageBackdrops,
  type ExportFormat,
  type ExportOptions,
  type ExportProgress,
  type ExportReport,
} from "@/lib/whiteboard/export";
import type { NotebookPage } from "@/lib/whiteboard/types";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface ExportModalProps {
  open: boolean;
  onClose: () => void;
}

/**
 * Every format, with the line that tells you when to pick it. "All the
 * formats" only helps if you can tell them apart: PNG and JPEG both make an
 * image, and the difference - one keeps transparency, one makes a file a mail
 * client will accept - is the whole basis for choosing.
 */
const FORMATS: Array<{ id: ExportFormat; label: string; hint: string; icon: typeof FileText }> = [
  { id: "pdf", label: "PDF", hint: "One page per sheet", icon: FileText },
  { id: "png", label: "PNG", hint: "Sharp, transparency", icon: ImageIcon },
  { id: "jpeg", label: "JPEG", hint: "Small file", icon: ImageIcon },
  { id: "webp", label: "WEBP", hint: "Smallest", icon: ImageIcon },
  { id: "svg", label: "SVG", hint: "Vector", icon: FileCode },
];

/** A sentence describing what an export had to leave out, or null. */
function describeReport(r: ExportReport): string | null {
  const parts: string[] = [];
  if (r.missingImages > 0) {
    parts.push(
      `${r.missingImages} picture${r.missingImages === 1 ? " was" : "s were"} missing from this device's storage and ${
        r.missingImages === 1 ? "is" : "are"
      } shown as a grey box`
    );
  }
  if (r.missingPdfPages > 0) {
    parts.push(
      `${r.missingPdfPages} PDF page${r.missingPdfPages === 1 ? "" : "s"} could not be loaded and ${
        r.missingPdfPages === 1 ? "was" : "were"
      } exported as plain paper`
    );
  }
  return parts.length ? `Exported, but ${parts.join("; ")}.` : null;
}

/**
 * One page thumbnail, drawn only once it scrolls into view.
 *
 * PDF backdrops are deliberately skipped here: rasterising a PDF page per
 * thumbnail would make opening this dialog on a 69-page import cost more than
 * the export itself. A badge says the page has one.
 */
function PageThumb({
  page,
  index,
  board,
  checked,
  onToggle,
}: {
  page: NotebookPage;
  index: number;
  board: NonNullable<ReturnType<typeof useActiveBoard>>;
  checked: boolean;
  onToggle: () => void;
}) {
  const ref = useRef<HTMLButtonElement | null>(null);
  const [svg, setSvg] = useState<string | null>(null);

  useEffect(() => {
    const node = ref.current;
    if (!node || svg) return;
    const draw = () => {
      try {
        const single = { ...board, pages: [page], activePageId: page.id };
        setSvg(buildExportSvg(single, { pages: "current", background: "white" }).svg);
      } catch {
        setSvg(""); // a thumbnail is never worth breaking the dialog over
      }
    };
    if (typeof IntersectionObserver === "undefined") {
      draw();
      return;
    }
    const io = new IntersectionObserver(
      (entries) => {
        if (entries.some((e) => e.isIntersecting)) {
          draw();
          io.disconnect();
        }
      },
      { rootMargin: "200px" }
    );
    io.observe(node);
    return () => io.disconnect();
  }, [board, page, svg]);

  const { width, height } = pageSizeOf(board);

  return (
    <button
      ref={ref}
      type="button"
      onClick={onToggle}
      aria-pressed={checked}
      aria-label={`Page ${index + 1}${checked ? ", selected" : ""}`}
      className="group relative shrink-0 focus:outline-none"
    >
      <div
        className={cn(
          "relative w-[68px] rounded-md border-2 overflow-hidden bg-white transition-all",
          checked ? "border-primary shadow-sm" : "border-border/70 opacity-70 group-hover:opacity-100"
        )}
        style={{ aspectRatio: `${width} / ${height}` }}
      >
        {svg ? (
          <div
            className="absolute inset-0 [&>svg]:w-full [&>svg]:h-full"
            dangerouslySetInnerHTML={{ __html: svg }}
          />
        ) : (
          <div className="absolute inset-0 bg-muted/40" />
        )}
        {page.pdf && (
          <span className="absolute left-0.5 top-0.5 rounded bg-black/60 px-1 text-[8px] font-semibold text-white">
            PDF
          </span>
        )}
        <span
          className={cn(
            "absolute bottom-0.5 right-0.5 flex h-4 w-4 items-center justify-center rounded-full border text-[9px]",
            checked ? "border-primary bg-primary text-primary-foreground" : "border-border bg-white/90 text-transparent"
          )}
        >
          <Check size={10} strokeWidth={3} />
        </span>
      </div>
      <div className="mt-0.5 text-center text-[10px] tabular-nums text-muted-foreground">{index + 1}</div>
    </button>
  );
}

export function ExportModal({ open, onClose }: ExportModalProps) {
  const activeBoard = useActiveBoard();
  const customLinkTypes = useWhiteboard((s) => s.customLinkTypes);

  const notebook = isNotebook(activeBoard);
  const pages = useMemo(() => (activeBoard ? getPages(activeBoard) : []), [activeBoard]);
  const pageCount = pages.length;

  const [format, setFormat] = useState<ExportFormat>("pdf");
  const [background, setBackground] = useState<"white" | "dark" | "transparent">("white");
  const [scale, setScale] = useState<number>(2);
  const [includeLocked, setIncludeLocked] = useState<boolean>(true);
  const [selected, setSelected] = useState<number[]>([]);
  const [rangeText, setRangeText] = useState<string>("");
  const [busy, setBusy] = useState<false | "save" | "share">(false);
  const [progress, setProgress] = useState<ExportProgress | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [native, setNative] = useState(false);
  const [canShare, setCanShare] = useState(false);
  const copiedTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [preview, setPreview] = useState<string>("");

  useEffect(() => () => { if (copiedTimer.current) clearTimeout(copiedTimer.current); }, []);

  // Opening resets to sensible defaults for what is on screen: a notebook is
  // almost always wanted whole, as a PDF; a whiteboard as an image. Probed on
  // open rather than at mount, because this dialog is mounted with the app.
  useEffect(() => {
    if (!open || !activeBoard) return;
    const all = Array.from({ length: pageCount }, (_, i) => i + 1);
    setFormat(notebook ? "pdf" : "png");
    setSelected(all);
    setRangeText(all.length ? `1-${all.length}` : "");
    setError(null);
    setNotice(null);
    setProgress(null);
    setBusy(false);
    setNative(isNativeApp());
    setCanShare(canChooseApp());
  }, [open, activeBoard?.id, pageCount, notebook]); // eslint-disable-line react-hooks/exhaustive-deps

  /** Ticking a thumbnail rewrites the range box, and vice versa. */
  const applySelection = useCallback((next: number[]) => {
    setSelected(next);
    setRangeText(formatPageSelection(next));
  }, []);

  const toggle = (pageNumber: number) => {
    const next = selected.includes(pageNumber)
      ? selected.filter((n) => n !== pageNumber)
      : [...selected, pageNumber].sort((a, b) => a - b);
    applySelection(next);
  };

  const onRangeChange = (text: string) => {
    setRangeText(text);
    setSelected(parsePageSelection(text, pageCount));
  };

  const allSelected = notebook && selected.length === pageCount && pageCount > 0;

  const exportOptions: ExportOptions = useMemo(
    () => ({
      background,
      scale,
      includeLocked,
      padding: 40,
      pages: notebook ? selected : "all",
    }),
    [background, scale, includeLocked, notebook, selected]
  );

  const chosenPages = useMemo(
    () => (notebook ? selected.map((n) => pages[n - 1]).filter(Boolean) : []),
    [notebook, selected, pages]
  );
  const elementCount = !activeBoard
    ? 0
    : notebook
    ? chosenPages.reduce((n, p) => n + (p.elements?.length ?? 0), 0)
    : allElements(activeBoard).length;

  // Live preview of exactly what will be written, capped so a big selection
  // does not cost more to preview than to export.
  useEffect(() => {
    if (!open || !activeBoard) return;
    let cancelled = false;
    (async () => {
      try {
        const images = await resolveExportImages(activeBoard);
        if (cancelled) return;
        let board = activeBoard;
        let backdrops: Map<string, string> | undefined;
        if (notebook) {
          const shown = chosenPages.slice(0, 4);
          if (shown.length === 0) { setPreview(""); return; }
          board = { ...activeBoard, pages: shown, activePageId: shown[0].id };
          backdrops = await resolvePageBackdrops(shown, pageSizeOf(activeBoard).width);
          if (cancelled) return;
        }
        setPreview(buildExportSvg(board, { ...exportOptions, pages: "all" }, customLinkTypes, images, backdrops).svg);
      } catch {
        if (!cancelled) setPreview("");
      }
    })();
    return () => { cancelled = true; };
  }, [open, activeBoard, notebook, chosenPages, exportOptions, customLinkTypes]);

  if (!activeBoard) return null;

  const nothingChosen = notebook && selected.length === 0;

  const run = async (destination: "save" | "share") => {
    if (busy || nothingChosen) return;
    setBusy(destination);
    setError(null);
    setNotice(null);
    setProgress({ done: 0, total: notebook ? Math.max(1, selected.length) : 1, label: "Preparing" });
    try {
      const { report, outcome } = await exportBoard(
        activeBoard,
        format,
        { ...exportOptions, onProgress: (p) => setProgress(p) },
        customLinkTypes,
        destination
      );
      const warning = describeReport(report);
      if (warning) { setNotice(warning); return; }
      if (outcome === "cancelled") {
        setNotice("Sharing was cancelled — the file was not sent anywhere.");
        return;
      }
      if (destination === "share" && outcome === "downloaded") {
        setNotice("No app chooser was available, so the file was saved instead.");
        return;
      }
      onClose();
    } catch (err) {
      console.error("Export failed:", err);
      // Stay open on failure. Closing looks exactly like success, which is how
      // a broken export went unnoticed for so long.
      setError(`Export failed: ${(err as Error).message}`);
    } finally {
      setBusy(false);
      setProgress(null);
    }
  };

  const copy = async () => {
    if (busy) return;
    setBusy("save");
    setError(null);
    try {
      const ok = await copyPngToClipboard(activeBoard, exportOptions, customLinkTypes);
      if (ok) {
        setCopied(true);
        if (copiedTimer.current) clearTimeout(copiedTimer.current);
        copiedTimer.current = setTimeout(() => setCopied(false), 2000);
      } else {
        setError(
          native
            ? "This device can't copy images to the clipboard. Use Share instead."
            : "Your browser blocked clipboard access. Use Save instead."
        );
      }
    } catch (err) {
      setError(`Copy failed: ${(err as Error).message}`);
    } finally {
      setBusy(false);
    }
  };

  const pct = progress && progress.total > 0 ? Math.round((progress.done / progress.total) * 100) : 0;

  return (
    <Dialog open={open} onOpenChange={(o) => !o && !busy && onClose()}>
      <DialogContent className="max-w-lg p-0 gap-0 overflow-hidden rounded-2xl border border-border/80 bg-white/98 shadow-2xl backdrop-blur-xl dark:bg-zinc-900/98">
        <DialogHeader className="space-y-0.5 border-b border-border/60 bg-muted/20 px-5 py-3.5">
          <div className="flex items-center gap-2.5">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10 text-primary">
              <Share2 size={17} />
            </div>
            <div className="min-w-0">
              <DialogTitle className="text-base font-semibold">Export &amp; share</DialogTitle>
              <DialogDescription className="truncate text-xs text-muted-foreground">
                {activeBoard.name}
                {notebook ? ` · ${selected.length} of ${pageCount} pages` : ""} · {elementCount} items
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>

        <div className="max-h-[60vh] space-y-4 overflow-y-auto px-5 py-4">
          {/* ---------------- 1. Which pages ---------------- */}
          {notebook && (
            <section className="space-y-2">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                  Select pages
                </h3>
                <button
                  type="button"
                  onClick={() =>
                    applySelection(allSelected ? [] : Array.from({ length: pageCount }, (_, i) => i + 1))
                  }
                  className="text-xs font-medium text-primary hover:underline"
                >
                  {allSelected ? "Deselect all" : "Select all"}
                </button>
              </div>

              <div className="flex gap-2 overflow-x-auto pb-1">
                {pages.map((p, i) => (
                  <PageThumb
                    key={p.id}
                    page={p}
                    index={i}
                    board={activeBoard}
                    checked={selected.includes(i + 1)}
                    onToggle={() => toggle(i + 1)}
                  />
                ))}
              </div>

              <input
                value={rangeText}
                onChange={(e) => onRangeChange(e.target.value)}
                placeholder="Enter page range to export, e.g. 2-5, 8"
                aria-label="Page range to export"
                className="h-9 w-full rounded-lg border border-border bg-background px-3 text-sm focus:border-primary focus:outline-none"
              />
              {nothingChosen && (
                <p className="text-[11px] text-amber-600 dark:text-amber-400">
                  No pages selected — tick a page or type a range.
                </p>
              )}
            </section>
          )}

          {/* ---------------- 2. What file ---------------- */}
          <section className="space-y-2">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Export as</h3>
            <div className="grid grid-cols-5 gap-1.5">
              {FORMATS.map((f) => {
                const Icon = f.icon;
                const on = format === f.id;
                return (
                  <button
                    key={f.id}
                    type="button"
                    onClick={() => setFormat(f.id)}
                    title={f.hint}
                    className={cn(
                      "flex flex-col items-center gap-1 rounded-xl border px-1 py-2 transition-all",
                      on
                        ? "border-primary bg-primary/10 text-primary"
                        : "border-border text-muted-foreground hover:bg-muted hover:text-foreground"
                    )}
                  >
                    <Icon size={17} />
                    <span className="text-[11px] font-semibold">{f.label}</span>
                    <span className="text-[8px] leading-tight opacity-70">{f.hint}</span>
                  </button>
                );
              })}
            </div>
            {notebook && format !== "pdf" && selected.length > 1 && (
              <p className="text-[11px] leading-snug text-muted-foreground">
                {format.toUpperCase()} is one image, so the pages come out stacked top to bottom.
                Choose PDF for one page per sheet.
              </p>
            )}
            {format === "jpeg" && background === "transparent" && (
              <p className="text-[11px] leading-snug text-muted-foreground">
                JPEG has no transparency, so this export will use a white background.
              </p>
            )}
          </section>

          {/* ---------------- Options ---------------- */}
          <section className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Background</h3>
              <div className="grid grid-cols-3 gap-1">
                {([
                  { id: "white", label: "White", bg: "#ffffff" },
                  { id: "dark", label: "Dark", bg: "#18181b" },
                  { id: "transparent", label: "None", bg: "transparent" },
                ] as const).map((b) => (
                  <button
                    key={b.id}
                    type="button"
                    onClick={() => setBackground(b.id)}
                    className={cn(
                      "flex items-center justify-center gap-1 rounded-lg border py-1 text-[11px] font-medium transition-all",
                      background === b.id ? "border-primary bg-primary/10 text-primary" : "border-border hover:bg-muted"
                    )}
                  >
                    <span className="h-2.5 w-2.5 shrink-0 rounded-full border border-border" style={{ background: b.bg }} />
                    {b.label}
                  </button>
                ))}
              </div>
            </div>

            {format !== "svg" && (
              <div className="space-y-1.5">
                <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Quality</h3>
                <div className="grid grid-cols-3 gap-1">
                  {[1, 2, 3].map((s) => (
                    <button
                      key={s}
                      type="button"
                      onClick={() => setScale(s)}
                      className={cn(
                        "rounded-lg border py-1 text-[11px] font-medium transition-all",
                        scale === s ? "border-primary bg-primary text-primary-foreground" : "border-border hover:bg-muted"
                      )}
                    >
                      {s}x
                    </button>
                  ))}
                </div>
              </div>
            )}
          </section>

          <label className="flex cursor-pointer select-none items-center gap-2 text-xs text-foreground">
            <input
              type="checkbox"
              checked={includeLocked}
              onChange={(e) => setIncludeLocked(e.target.checked)}
              className="h-4 w-4 rounded border-border text-primary focus:ring-primary"
            />
            Include locked items
          </label>

          {/* ---------------- Preview ---------------- */}
          <section className="space-y-1.5">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Preview</h3>
            <div
              className={cn(
                "flex h-36 items-center justify-center overflow-hidden rounded-xl border border-border/80 p-2",
                background === "dark" ? "bg-zinc-950" : "bg-white"
              )}
            >
              {preview ? (
                <div
                  className="flex h-full w-full items-center justify-center [&>svg]:max-h-full [&>svg]:max-w-full [&>svg]:w-auto [&>svg]:h-auto"
                  dangerouslySetInnerHTML={{ __html: preview }}
                />
              ) : (
                <span className="text-xs text-muted-foreground">
                  {nothingChosen ? "Nothing selected" : "Nothing to preview"}
                </span>
              )}
            </div>
          </section>
        </div>

        {/* ---------------- 3. Where ---------------- */}
        <div className="space-y-2 border-t border-border/60 bg-muted/10 px-5 py-3.5">
          {progress && (
            <div className="space-y-1" role="status" aria-live="polite">
              <div className="flex items-center justify-between text-[11px] text-muted-foreground">
                <span className="flex items-center gap-1.5">
                  <Loader2 size={12} className="animate-spin" />
                  {progress.label}
                </span>
                <span className="tabular-nums">{pct}%</span>
              </div>
              <div className="h-1.5 w-full overflow-hidden rounded-full bg-border/60">
                <div className="h-full rounded-full bg-primary transition-[width] duration-200" style={{ width: `${pct}%` }} />
              </div>
            </div>
          )}

          {notice && (
            <div role="status" className="rounded-lg border border-amber-500/40 bg-amber-500/10 px-3 py-2 text-[11px] leading-snug text-amber-700 dark:text-amber-400">
              {notice}
            </div>
          )}
          {error && (
            <div role="alert" className="rounded-lg border border-red-500/40 bg-red-500/10 px-3 py-2 text-[11px] leading-snug text-red-600 dark:text-red-400">
              {error}
            </div>
          )}

          <div className="flex gap-2">
            <Button variant="ghost" className="px-3" onClick={onClose} disabled={!!busy}>
              <X size={15} />
            </Button>
            {format === "png" && !native && (
              <Button variant="outline" className="gap-1.5 px-3" onClick={copy} disabled={!!busy || nothingChosen}>
                {copied ? <Check size={14} className="text-emerald-500" /> : <Copy size={14} />}
                <span className="text-xs">{copied ? "Copied" : "Copy"}</span>
              </Button>
            )}
            <Button
              variant={canShare ? "outline" : "default"}
              className="flex-1 gap-1.5"
              onClick={() => run("save")}
              disabled={!!busy || nothingChosen}
            >
              <Download size={15} />
              <span>{busy === "save" ? "Working…" : native ? "Save" : "Download"}</span>
            </Button>
            {canShare && (
              <Button className="flex-1 gap-1.5 font-semibold" onClick={() => run("share")} disabled={!!busy || nothingChosen}>
                <Share2 size={15} />
                <span>{busy === "share" ? "Working…" : "Share"}</span>
              </Button>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
