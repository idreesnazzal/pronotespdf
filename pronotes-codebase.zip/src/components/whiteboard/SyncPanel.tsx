"use client";

/**
 * Sync & Backup panel
 * ====================
 * - Microsoft sign-in, then two-way sync of the whole workspace through the
 *   user's own OneDrive (see lib/whiteboard/onedrive.ts).
 * - Local backup: download / restore a workspace JSON. This works with no
 *   account at all, and is the safety net for moving between browsers, since
 *   localStorage is per-browser.
 */

import React, { useCallback, useEffect, useRef, useState } from "react";
import { useWhiteboard } from "@/store/whiteboard";
import {
  beginSignIn,
  completeSignInIfRedirected,
  downloadWorkspace,
  getSignedInAccount,
  isConfigured,
  isSignedIn,
  signOut,
  uploadWorkspace,
} from "@/lib/whiteboard/onedrive";
import {
  parseWorkspace,
  serializeWorkspace,
  WorkspaceParseError,
} from "@/lib/whiteboard/workspace";
import { isNativeApp, saveBlob } from "@/lib/whiteboard/export";
import { Cloud, CloudOff, Download, Loader2, LogOut, RefreshCw, Upload, X } from "lucide-react";
import { AccountSection } from "./AccountSection";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

type Status =
  | { kind: "idle" }
  | { kind: "busy"; message: string }
  | { kind: "ok"; message: string }
  | { kind: "error"; message: string };

function deviceLabel(): string {
  if (typeof navigator === "undefined") return "unknown device";
  const ua = navigator.userAgent;
  if (/Android/i.test(ua)) return "Android tablet/phone";
  if (/iPad|iPhone/i.test(ua)) return "iPad/iPhone";
  if (/Windows/i.test(ua)) return "Windows PC";
  if (/Mac/i.test(ua)) return "Mac";
  return "browser";
}

export function SyncPanel({ open, onClose }: { open: boolean; onClose: () => void }) {
  const getWorkspaceSnapshot = useWhiteboard((s) => s.getWorkspaceSnapshot);
  const replaceWorkspace = useWhiteboard((s) => s.replaceWorkspace);
  const mergeWorkspace = useWhiteboard((s) => s.mergeWorkspace);

  const [status, setStatus] = useState<Status>({ kind: "idle" });
  const [signedIn, setSignedIn] = useState(false);
  const [account, setAccount] = useState<{ name?: string; email?: string } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const refreshAuthState = useCallback(() => {
    setSignedIn(isSignedIn());
    setAccount(getSignedInAccount() ?? null);
  }, []);

  // Finish the OAuth redirect on load — the app comes back to its own URL with
  // ?code=..., which must be exchanged before anything else works.
  useEffect(() => {
    let cancelled = false;
    completeSignInIfRedirected()
      .then((completed) => {
        if (cancelled) return;
        refreshAuthState();
        if (completed) setStatus({ kind: "ok", message: "Signed in to Microsoft." });
      })
      .catch((e: Error) => {
        if (!cancelled) setStatus({ kind: "error", message: e.message });
      });
    refreshAuthState();
    return () => {
      cancelled = true;
    };
  }, [refreshAuthState]);

  if (!open) return null;

  const configured = isConfigured();

  const doSync = async () => {
    setStatus({ kind: "busy", message: "Syncing with OneDrive…" });
    try {
      const remote = await downloadWorkspace();
      let summary: string;
      if (!remote) {
        summary = "First sync — uploaded this device's boards.";
      } else {
        const report = mergeWorkspace(remote.snapshot);
        summary =
          `Merged: ${report.added} new, ${report.updatedFromRemote} updated from OneDrive, ` +
          `${report.keptLocal} kept from this device.`;
      }
      // Upload the merged result so both devices converge on the same document.
      await uploadWorkspace(getWorkspaceSnapshot(), deviceLabel());
      setStatus({ kind: "ok", message: summary });
    } catch (e) {
      setStatus({ kind: "error", message: (e as Error).message });
    }
  };

  const doSignIn = async () => {
    setStatus({ kind: "busy", message: "Opening Microsoft sign-in…" });
    try {
      await beginSignIn();
    } catch (e) {
      setStatus({ kind: "error", message: (e as Error).message });
    }
  };

  const doSignOut = () => {
    signOut();
    refreshAuthState();
    setStatus({ kind: "ok", message: "Signed out. Your boards stay on this device." });
  };

  const doBackup = async () => {
    const json = serializeWorkspace(getWorkspaceSnapshot(), deviceLabel());
    const blob = new Blob([json], { type: "application/json" });
    const stamp = new Date().toISOString().slice(0, 10);
    setStatus({ kind: "busy", message: "Preparing backup…" });
    try {
      // saveBlob, not a hand-rolled <a download>: inside the APK that click is
      // swallowed and the backup silently never happens.
      await saveBlob(blob, `pronotes-backup-${stamp}.json`);
      setStatus({
        kind: "ok",
        message: isNativeApp() ? "Backup ready — pick where to save it." : "Backup file downloaded.",
      });
    } catch (e) {
      setStatus({ kind: "error", message: `Could not save the backup: ${(e as Error).message}` });
    }
  };

  const doRestore = async (file: File) => {
    setStatus({ kind: "busy", message: "Reading backup…" });
    try {
      const snapshot = parseWorkspace(await file.text());
      const boards = snapshot.boards.length;
      // Restoring REPLACES everything, so make the user confirm with the real
      // number in front of them — this is not undoable.
      const ok = window.confirm(
        `Replace everything on this device with the backup?\n\n` +
          `The backup has ${boards} board${boards === 1 ? "" : "s"}.\n` +
          `Your current boards on this device will be lost.`
      );
      if (!ok) {
        setStatus({ kind: "idle" });
        return;
      }
      replaceWorkspace(snapshot);
      setStatus({ kind: "ok", message: `Restored ${boards} board${boards === 1 ? "" : "s"}.` });
    } catch (e) {
      setStatus({
        kind: "error",
        message:
          e instanceof WorkspaceParseError ? e.message : `Could not restore: ${(e as Error).message}`,
      });
    }
  };

  const busy = status.kind === "busy";

  return (
    <div
      data-wb-modal
      className="fixed inset-0 z-[90] flex items-center justify-center bg-black/50 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md rounded-2xl border border-border bg-white shadow-2xl dark:bg-zinc-900"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between border-b border-border px-5 py-3">
          <div className="flex items-center gap-2">
            <Cloud size={18} className="text-primary" />
            <h2 className="text-base font-semibold">Sync & Backup</h2>
          </div>
          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={onClose}>
            <X size={16} />
          </Button>
        </div>

        <div className="space-y-4 p-5">
          {/* ---- Account (email + password, self-service sign-up) ---- */}
          <section className="space-y-2">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              Your account
            </h3>
            <AccountSection
              deviceLabel={deviceLabel()}
              onStatus={setStatus}
              busy={status.kind === "busy"}
            />
          </section>

          <div className="h-px bg-border" />

          {/* ---- OneDrive ---- */}
          <section className="space-y-2">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              Or use your Microsoft account
            </h3>

            {!configured ? (
              <div className="rounded-lg border border-amber-500/40 bg-amber-500/10 p-3 text-xs leading-relaxed">
                <p className="font-medium text-amber-700 dark:text-amber-400">
                  Sign-in is not set up yet.
                </p>
                <p className="mt-1 text-muted-foreground">
                  Add your free Microsoft app ID as{" "}
                  <code className="font-semibold">NEXT_PUBLIC_MS_CLIENT_ID</code> and rebuild. See{" "}
                  <code>ONEDRIVE_SETUP.md</code> — it takes about two minutes and costs nothing.
                </p>
              </div>
            ) : signedIn ? (
              <>
                <div className="rounded-lg border border-border p-3 text-xs">
                  <div className="font-medium">{account?.name || "Signed in"}</div>
                  {account?.email && (
                    <div className="text-muted-foreground">{account.email}</div>
                  )}
                </div>
                <div className="flex gap-2">
                  <Button size="sm" className="flex-1" onClick={doSync} disabled={busy}>
                    {busy ? (
                      <Loader2 size={14} className="mr-1.5 animate-spin" />
                    ) : (
                      <RefreshCw size={14} className="mr-1.5" />
                    )}
                    Sync now
                  </Button>
                  <Button size="sm" variant="outline" onClick={doSignOut} disabled={busy}>
                    <LogOut size={14} className="mr-1.5" />
                    Sign out
                  </Button>
                </div>
                <p className="text-[11px] leading-snug text-muted-foreground">
                  Boards are merged one by one, newest edit wins. Only a board you
                  changed on two devices since the last sync has to pick a winner.
                </p>
              </>
            ) : (
              <>
                <Button size="sm" className="w-full" onClick={doSignIn} disabled={busy}>
                  <Cloud size={14} className="mr-1.5" />
                  Sign in with Microsoft
                </Button>
                <p className="text-[11px] leading-snug text-muted-foreground">
                  Your boards are stored in one file in your own OneDrive. ProNotes
                  can only see its own folder, never the rest of your files.
                </p>
              </>
            )}
          </section>

          <div className="h-px bg-border" />

          {/* ---- Local file backup ---- */}
          <section className="space-y-2">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              Backup file
            </h3>
            <div className="flex gap-2">
              <Button size="sm" variant="outline" className="flex-1" onClick={() => void doBackup()} disabled={busy}>
                <Download size={14} className="mr-1.5" />
                Save backup
              </Button>
              <Button
                size="sm"
                variant="outline"
                className="flex-1"
                onClick={() => fileInputRef.current?.click()}
                disabled={busy}
              >
                <Upload size={14} className="mr-1.5" />
                Restore
              </Button>
            </div>
            <input
              ref={fileInputRef}
              type="file"
              accept="application/json,.json"
              className="hidden"
              onChange={(e) => {
                const file = e.target.files?.[0];
                // Reset so picking the SAME file twice still fires onChange.
                e.target.value = "";
                if (file) void doRestore(file);
              }}
            />
            <p className="text-[11px] leading-snug text-muted-foreground">
              Boards live in this browser only. A backup file moves them to another
              browser, another PC, or your tablet — no account needed.
            </p>
          </section>

          {status.kind !== "idle" && (
            <div
              className={cn(
                "rounded-lg border p-2.5 text-xs",
                status.kind === "error" && "border-destructive/40 bg-destructive/10 text-destructive",
                status.kind === "ok" && "border-emerald-500/40 bg-emerald-500/10 text-emerald-700 dark:text-emerald-400",
                status.kind === "busy" && "border-border bg-muted text-muted-foreground"
              )}
            >
              <span className="flex items-center gap-1.5">
                {status.kind === "busy" && <Loader2 size={12} className="animate-spin" />}
                {status.kind === "error" && <CloudOff size={12} />}
                {status.message}
              </span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
