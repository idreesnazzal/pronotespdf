"use client";

/**
 * Backlinks & Relationship Panel (v3 — Obsidian Canvas Grade)
 * =============================================================
 * Aggregates both [[WikiLinks]] and typed directed arrow connections.
 */

import React, { useMemo } from "react";
import { useWhiteboard, useActiveBoard } from "@/store/whiteboard";
import { getBacklinks, getBoardLinks, getBoardTags } from "@/lib/whiteboard/links";
import { Link2, Tag, ArrowRight, Hash, Plus, Sparkles, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";

interface BacklinksPanelProps {
  /** Close the panel. Without this the panel could cover the only button that
   *  toggles it, leaving no way out except the Ctrl+B shortcut. */
  onClose?: () => void;
}

export function BacklinksPanel({ onClose }: BacklinksPanelProps) {
  const boards = useWhiteboard((s) => s.boards);
  const customLinkTypes = useWhiteboard((s) => s.customLinkTypes);
  const activeBoard = useActiveBoard();
  const setActiveBoard = useWhiteboard((s) => s.setActiveBoard);
  const findOrCreateBoardByName = useWhiteboard((s) => s.findOrCreateBoardByName);

  const backlinks = useMemo(() => {
    if (!activeBoard) return [];
    return getBacklinks(boards, activeBoard.name, activeBoard.id, customLinkTypes);
  }, [boards, activeBoard, customLinkTypes]);

  const outgoingLinks = useMemo(() => {
    if (!activeBoard) return [];
    return getBoardLinks(activeBoard);
  }, [activeBoard]);

  const tags = useMemo(() => {
    if (!activeBoard) return [];
    return getBoardTags(activeBoard);
  }, [activeBoard]);

  if (!activeBoard) return null;

  const navigateToBoard = (name: string) => {
    const id = findOrCreateBoardByName(name);
    setActiveBoard(id);
  };

  return (
    <div className="w-72 h-full bg-sidebar border-r border-sidebar-border flex flex-col select-none">
      {/* Header */}
      <div className="px-4 py-3 border-b border-sidebar-border">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Link2 size={16} className="text-primary" />
            <h3 className="text-xs font-bold uppercase tracking-wider text-foreground">
              Links & Connections
            </h3>
          </div>
          <div className="flex items-center gap-1">
            <span className="text-[11px] px-2 py-0.5 rounded-full bg-primary/10 text-primary font-semibold">
              {backlinks.length + outgoingLinks.length}
            </span>
            {onClose && (
              <Button
                variant="ghost"
                size="icon"
                className="h-6 w-6 text-muted-foreground hover:text-foreground"
                onClick={onClose}
                title="Close links panel (Ctrl+B)"
                aria-label="Close links panel"
              >
                <X size={14} />
              </Button>
            )}
          </div>
        </div>
        {/* Say what this panel is for — it opens from a button labelled only
            "Links", which does not explain itself. */}
        <p className="mt-1.5 text-[11px] leading-snug text-muted-foreground">
          Every board that <strong>this</strong> board points to, and every board
          pointing back at it.
        </p>
      </div>

      <ScrollArea className="flex-1">
        <div className="p-3.5 space-y-4">
          {/* Outgoing links */}
          <div>
            <div className="text-xs font-semibold text-muted-foreground mb-2 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <ArrowRight size={13} className="text-blue-500" />
                Outgoing References
              </span>
              <span className="tabular-nums font-bold text-[11px]">{outgoingLinks.length}</span>
            </div>

            {outgoingLinks.length === 0 ? (
              <div className="text-[11px] text-muted-foreground italic px-1 py-1">
                No outgoing links. Type <code className="text-primary font-semibold">[[Board Name]]</code> to link ideas.
              </div>
            ) : (
              <div className="space-y-1">
                {outgoingLinks.map((target) => {
                  const exists = boards.some(
                    (b) => b.name.toLowerCase() === target.toLowerCase()
                  );
                  return (
                    <button
                      key={target}
                      onClick={() => navigateToBoard(target)}
                      className="w-full text-left text-xs px-2.5 py-1.5 rounded-lg hover:bg-sidebar-accent text-foreground flex items-center justify-between transition-colors"
                    >
                      <span className="font-medium truncate text-blue-600 dark:text-blue-400">
                        {target}
                      </span>
                      {!exists && (
                        <span className="text-[10px] text-amber-500 font-semibold">(new)</span>
                      )}
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* Backlinks */}
          <div>
            <div className="text-xs font-semibold text-muted-foreground mb-2 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <Link2 size={13} className="text-primary" />
                Incoming Backlinks
              </span>
              <span className="tabular-nums font-bold text-[11px]">{backlinks.length}</span>
            </div>

            {backlinks.length === 0 ? (
              <div className="text-[11px] text-muted-foreground italic px-1 py-1">
                No boards link to this one yet.
              </div>
            ) : (
              <div className="space-y-1.5">
                {backlinks.map((bl, i) => (
                  <button
                    key={`${bl.sourceBoardId}-${bl.elementId}-${i}`}
                    onClick={() => setActiveBoard(bl.sourceBoardId)}
                    className="w-full text-left p-2 rounded-lg border border-sidebar-border hover:border-primary/50 hover:bg-sidebar-accent transition-all group"
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-semibold text-xs text-foreground group-hover:text-primary transition-colors truncate">
                        {bl.sourceBoardName}
                      </span>
                      {bl.relationship && (
                        <span
                          className="text-[10px] px-1.5 py-0.5 rounded font-medium text-white"
                          style={{ backgroundColor: bl.color || "#6366f1" }}
                        >
                          {bl.relationship}
                        </span>
                      )}
                    </div>
                    {bl.snippet && (
                      <p className="text-[11px] text-muted-foreground line-clamp-2 italic">
                        "{bl.snippet}"
                      </p>
                    )}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Tags */}
          <div>
            <div className="text-xs font-semibold text-muted-foreground mb-2 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <Hash size={13} className="text-emerald-500" />
                Tags
              </span>
              <span className="tabular-nums font-bold text-[11px]">{tags.length}</span>
            </div>

            {tags.length === 0 ? (
              <div className="text-[11px] text-muted-foreground italic px-1 py-1">
                No tags yet. Use <code className="text-emerald-500 font-semibold">#tag</code> in text.
              </div>
            ) : (
              <div className="flex flex-wrap gap-1">
                {tags.map((tag) => (
                  <span
                    key={tag}
                    className="text-[11px] px-2 py-0.5 rounded-md bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-medium"
                  >
                    #{tag}
                  </span>
                ))}
              </div>
            )}
          </div>
        </div>
      </ScrollArea>
    </div>
  );
}
