"use client";

/**
 * Element Renderer (v3 — Obsidian Canvas & Vector Grade)
 * =======================================================
 * High-performance SVG renderer for all whiteboard elements:
 * - Freehand strokes (via perfect-freehand with realistic pen styles)
 * - Shapes: Rectangles, Rounded Rects, Ellipses, Diamonds, Triangles, Stars, Clouds
 * - Lines & Directional Arrows
 * - Rich Markdown Text & Sticky Notes with clickable [[WikiLinks]] and #tags
 * - Smart Directed Connections with 3 routing modes (Curved, Orthogonal, Straight),
 *   arrowheads, and interactive relationship badges.
 */

import React, { useMemo, useState, useRef } from "react";
import { useWhiteboard } from "@/store/whiteboard";
import { assetIdOf, isAssetRef, loadImage } from "@/lib/whiteboard/imagestore";
import { imageLayout, isUnedited } from "@/lib/whiteboard/imageEdit";
import { allElements } from "@/lib/whiteboard/notebook";
import {
  STICKY_COLORS,
  PEN_TYPE_PRESETS,
  getLinkTypeColor,
  getLinkTypeLabel,
  type ArrowElement,
  type ConnectionElement,
  type DiamondElement,
  type EllipseElement,
  type ImageElement,
  type LineElement,
  type RectangleElement,
  type StarElement,
  type CloudElement,
  type StickyElement,
  type StrokeElement,
  type TextElement,
  type TriangleElement,
  type WhiteboardElement,
} from "@/lib/whiteboard/types";
import { buildStrokePath } from "@/lib/whiteboard/stroke";
import {
  getElementBounds,
  getElementCenter,
  getOptimalConnectionAnchors,
  getConnectionPath,
  getArrowheadPath,
  getResolvedAnchorPoint,
} from "@/lib/whiteboard/geometry";
import {
  parseMarkdownBlocks,
  resolveLineDir,
  toggleChecklistAtLine,
  type InlineToken,
  type BlockToken,
} from "@/lib/whiteboard/textParser";

interface ElementRendererProps {
  element: WhiteboardElement;
  isSelected: boolean;
  isDraft?: boolean;
}

export const ElementRenderer = React.memo(function ElementRenderer({
  element,
  isSelected,
  isDraft,
}: ElementRendererProps) {
  // Subscribe to a BOOLEAN (is THIS element being edited), not the raw id —
  // otherwise every element re-renders whenever any element starts/stops editing.
  const isBeingEdited = useWhiteboard((s) => s.editingId === element.id);

  // If being edited inline, hide SVG representation (InlineTextEditor overlays it)
  if (isBeingEdited) {
    return null;
  }

  const opacity = element.opacity ?? 1;
  const center = getElementCenter(element);

  const transform =
    element.rotation && element.rotation !== 0
      ? `translate(${element.x}, ${element.y}) rotate(${(element.rotation * 180) / Math.PI}, ${center.x - element.x}, ${center.y - element.y})`
      : `translate(${element.x}, ${element.y})`;

  return (
    <g
      transform={element.type === "connection" ? undefined : transform}
      opacity={opacity}
      data-element-id={element.id}
      style={{ cursor: element.locked ? "not-allowed" : undefined }}
    >
      {renderElementContent(element, isDraft ?? false)}
    </g>
  );
});

function renderElementContent(el: WhiteboardElement, isDraft: boolean): React.ReactNode {
  switch (el.type) {
    case "stroke":
      return <StrokeShape element={el} isDraft={isDraft} />;
    case "rectangle":
      return <RectangleShape element={el} />;
    case "ellipse":
      return <EllipseShape element={el} />;
    case "diamond":
      return <DiamondShape element={el} />;
    case "triangle":
      return <TriangleShape element={el} />;
    case "star":
      return <StarShape element={el} />;
    case "cloud":
      return <CloudShape element={el} />;
    case "line":
      return <LineShape element={el} />;
    case "arrow":
      return <ArrowShape element={el} />;
    case "text":
      return <TextShape element={el} />;
    case "sticky":
      return <StickyShape element={el} />;
    case "image":
      return <ImageShape element={el} />;
    case "connection":
      return <ConnectionShape element={el} />;
    default:
      return null;
  }
}

// ============================================================================
// Freehand Stroke
// ============================================================================

function StrokeShape({ element, isDraft }: { element: StrokeElement; isDraft: boolean }) {
  // Always derive the path from the points — never reuse a cached string.
  // Caching froze each stroke's geometry at the moment it was drawn, so any
  // later improvement to stroke rendering (taper, corner handling) could never
  // apply to strokes that already existed. It also cost ~143% of the points'
  // own size per stroke, duplicated into every deep-cloned history snapshot.
  // useMemo keyed on the element keeps this to one build per change.
  const path = useMemo(() => buildStrokePath(element, isDraft), [element, isDraft]);

  if (!path) return null;
  const preset = PEN_TYPE_PRESETS[element.strokeStyle] || PEN_TYPE_PRESETS.gel;

  return (
    <path
      d={path}
      fill={element.color}
      stroke="none"
      // Graphite tooth. A pencil that is merely a thinner pen is the main
      // reason the old presets felt interchangeable; the grain is what makes
      // it read as pencil at any size.
      filter={preset.grain ? "url(#pencil-grain)" : undefined}
      style={{
        opacity: preset.opacity,
        mixBlendMode: preset.mixBlendMode,
        pointerEvents: "auto",
      }}
    />
  );
}

/**
 * Filters used by stroke rendering. Defined once per canvas rather than per
 * stroke — an SVG filter is referenced by id, so duplicating it per element
 * would cost a node each without changing the result.
 */
export function StrokeFilterDefs() {
  return (
    <defs>
      <filter id="pencil-grain" x="-20%" y="-20%" width="140%" height="140%">
        <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="3" seed="7" result="noise" />
        {/* Push the noise through the alpha channel so the grain eats into the
            stroke's edges instead of tinting its colour. */}
        <feDisplacementMap in="SourceGraphic" in2="noise" scale="1.6" xChannelSelector="R" yChannelSelector="G" result="rough" />
        <feComponentTransfer in="rough">
          <feFuncA type="discrete" tableValues="0 .55 .75 .9 1" />
        </feComponentTransfer>
      </filter>
    </defs>
  );
}

// ============================================================================
// Geometric Shapes (Rectangle, Ellipse, Diamond, Triangle, Star, Cloud)
// ============================================================================

function getFillAndDash(fillStyle: string, dashStyle: string, strokeColor: string, fillColor: string) {
  let fill = "transparent";
  if (fillStyle === "solid") fill = fillColor === "transparent" ? strokeColor : fillColor;
  else if (fillStyle === "semi") fill = fillColor === "transparent" ? `${strokeColor}33` : `${fillColor}40`;

  let strokeDasharray: string | undefined = undefined;
  if (dashStyle === "dashed") strokeDasharray = "8,6";
  else if (dashStyle === "dotted") strokeDasharray = "3,4";

  return { fill, strokeDasharray };
}

function RectangleShape({ element }: { element: RectangleElement }) {
  const { fill, strokeDasharray } = getFillAndDash(
    element.fillStyle || "transparent",
    element.dashStyle || "solid",
    element.strokeColor,
    element.fillColor
  );

  return (
    <rect
      x={0}
      y={0}
      width={Math.max(element.width, 2)}
      height={Math.max(element.height, 2)}
      rx={element.cornerRadius || 6}
      ry={element.cornerRadius || 6}
      fill={fill}
      stroke={element.strokeColor}
      strokeWidth={element.strokeWidth}
      strokeDasharray={strokeDasharray}
      style={{ pointerEvents: "auto" }}
    />
  );
}

function EllipseShape({ element }: { element: EllipseElement }) {
  const { fill, strokeDasharray } = getFillAndDash(
    element.fillStyle || "transparent",
    element.dashStyle || "solid",
    element.strokeColor,
    element.fillColor
  );

  const rx = Math.max(element.width / 2, 1);
  const ry = Math.max(element.height / 2, 1);

  return (
    <ellipse
      cx={rx}
      cy={ry}
      rx={rx}
      ry={ry}
      fill={fill}
      stroke={element.strokeColor}
      strokeWidth={element.strokeWidth}
      strokeDasharray={strokeDasharray}
      style={{ pointerEvents: "auto" }}
    />
  );
}

function DiamondShape({ element }: { element: DiamondElement }) {
  const { fill, strokeDasharray } = getFillAndDash(
    element.fillStyle || "transparent",
    element.dashStyle || "solid",
    element.strokeColor,
    element.fillColor
  );

  const w = element.width;
  const h = element.height;
  const points = `${w / 2},0 ${w},${h / 2} ${w / 2},${h} 0,${h / 2}`;

  return (
    <polygon
      points={points}
      fill={fill}
      stroke={element.strokeColor}
      strokeWidth={element.strokeWidth}
      strokeDasharray={strokeDasharray}
      style={{ pointerEvents: "auto" }}
    />
  );
}

function TriangleShape({ element }: { element: TriangleElement }) {
  const { fill, strokeDasharray } = getFillAndDash(
    element.fillStyle || "transparent",
    element.dashStyle || "solid",
    element.strokeColor,
    element.fillColor
  );

  const w = element.width;
  const h = element.height;
  const points = `${w / 2},0 ${w},${h} 0,${h}`;

  return (
    <polygon
      points={points}
      fill={fill}
      stroke={element.strokeColor}
      strokeWidth={element.strokeWidth}
      strokeDasharray={strokeDasharray}
      style={{ pointerEvents: "auto" }}
    />
  );
}

function StarShape({ element }: { element: StarElement }) {
  const { fill, strokeDasharray } = getFillAndDash(
    element.fillStyle || "transparent",
    element.dashStyle || "solid",
    element.strokeColor,
    element.fillColor
  );

  const w = element.width;
  const h = element.height;
  const cx = w / 2;
  const cy = h / 2;
  const spikes = 5;
  const outerR = Math.min(w, h) / 2;
  const innerR = outerR * 0.45;

  let pts = "";
  for (let i = 0; i < spikes * 2; i++) {
    const r = i % 2 === 0 ? outerR : innerR;
    const angle = (i * Math.PI) / spikes - Math.PI / 2;
    const x = cx + Math.cos(angle) * r;
    const y = cy + Math.sin(angle) * r;
    pts += `${x.toFixed(1)},${y.toFixed(1)} `;
  }

  return (
    <polygon
      points={pts.trim()}
      fill={fill}
      stroke={element.strokeColor}
      strokeWidth={element.strokeWidth}
      strokeDasharray={strokeDasharray}
      style={{ pointerEvents: "auto" }}
    />
  );
}

function CloudShape({ element }: { element: CloudElement }) {
  const { fill, strokeDasharray } = getFillAndDash(
    element.fillStyle || "transparent",
    element.dashStyle || "solid",
    element.strokeColor,
    element.fillColor
  );

  const w = element.width;
  const h = element.height;
  const r = Math.min(w, h) * 0.2;

  const d = `
    M ${r * 1.5},${h - r}
    A ${r},${r} 0 0,1 ${r},${h * 0.5}
    A ${r * 1.2},${r * 1.2} 0 0,1 ${w * 0.35},${r}
    A ${r * 1.5},${r * 1.5} 0 0,1 ${w * 0.7},${r * 1.2}
    A ${r},${r} 0 0,1 ${w - r * 0.5},${h * 0.55}
    A ${r * 0.9},${r * 0.9} 0 0,1 ${w - r},${h - r}
    Z
  `;

  return (
    <path
      d={d}
      fill={fill}
      stroke={element.strokeColor}
      strokeWidth={element.strokeWidth}
      strokeDasharray={strokeDasharray}
      style={{ pointerEvents: "auto" }}
    />
  );
}

// ============================================================================
// Lines & Arrows
// ============================================================================

function LineShape({ element }: { element: LineElement }) {
  let strokeDasharray: string | undefined = undefined;
  if (element.dashStyle === "dashed") strokeDasharray = "8,6";
  else if (element.dashStyle === "dotted") strokeDasharray = "3,4";

  return (
    <line
      x1={0}
      y1={0}
      x2={element.x2}
      y2={element.y2}
      stroke={element.strokeColor}
      strokeWidth={element.strokeWidth}
      strokeDasharray={strokeDasharray}
      strokeLinecap="round"
      style={{ pointerEvents: "auto" }}
    />
  );
}

function ArrowShape({ element }: { element: ArrowElement }) {
  let strokeDasharray: string | undefined = undefined;
  if (element.dashStyle === "dashed") strokeDasharray = "8,6";
  else if (element.dashStyle === "dotted") strokeDasharray = "3,4";

  const head = getArrowheadPath(
    element.x2,
    element.y2,
    0,
    0,
    element.endArrowhead || "arrow",
    element.arrowheadSize || 12
  );

  return (
    <g style={{ pointerEvents: "auto", color: element.strokeColor }}>
      <line
        x1={0}
        y1={0}
        x2={element.x2}
        y2={element.y2}
        stroke={element.strokeColor}
        strokeWidth={element.strokeWidth}
        strokeDasharray={strokeDasharray}
        strokeLinecap="round"
      />
      {head && (
        <path
          d={head.path}
          fill={element.strokeColor}
          stroke={head.stroke}
        />
      )}
    </g>
  );
}

// ============================================================================
// Text & Markdown Cards (Obsidian [[WikiLink]] & #tag support)
// ============================================================================

function renderInlineTokens(
  tokens: InlineToken[],
  handleLinkClick: (e: React.MouseEvent, target: string) => void
): React.ReactNode {
  return tokens.map((tok, idx) => {
    switch (tok.type) {
      case "bold":
        return <strong key={idx} style={{ fontWeight: 700 }}>{tok.text}</strong>;
      case "italic":
        return <em key={idx} style={{ fontStyle: "italic" }}>{tok.text}</em>;
      case "underline":
        return <u key={idx}>{tok.text}</u>;
      case "strike":
        return <s key={idx} style={{ textDecoration: "line-through", opacity: 0.75 }}>{tok.text}</s>;
      case "code":
        return (
          <code
            key={idx}
            style={{
              backgroundColor: "rgba(128,128,128,0.15)",
              padding: "1px 4px",
              borderRadius: "4px",
              fontFamily: "monospace",
              fontSize: "0.9em",
            }}
          >
            {tok.text}
          </code>
        );
      case "highlight":
        return (
          <mark
            key={idx}
            style={{
              backgroundColor: "#fef08a",
              color: "inherit",
              padding: "0 3px",
              borderRadius: "3px",
            }}
          >
            {tok.text}
          </mark>
        );
      case "math":
        return (
          <span
            key={idx}
            style={{
              fontFamily: "'KaTeX_Main', 'Times New Roman', serif",
              fontStyle: "italic",
              padding: "0 2px",
              letterSpacing: "0.02em",
            }}
          >
            {tok.text}
          </span>
        );
      case "link":
        return (
          <span
            key={idx}
            onClick={(e) => handleLinkClick(e, tok.value!)}
            style={{
              color: "#6366f1",
              textDecoration: "underline",
              cursor: "pointer",
              fontWeight: 600,
            }}
            title={`Jump to [[${tok.value}]]`}
          >
            {tok.text}
          </span>
        );
      case "tag":
        return (
          <span
            key={idx}
            style={{
              color: "#059669",
              backgroundColor: "rgba(5,150,105,0.12)",
              padding: "1px 5px",
              borderRadius: "4px",
              fontWeight: 600,
              fontSize: "0.9em",
            }}
          >
            {tok.text}
          </span>
        );
      case "url":
        return (
          <a
            key={idx}
            href={tok.value}
            target="_blank"
            rel="noopener noreferrer"
            onClick={(e) => e.stopPropagation()}
            style={{ color: "#3b82f6", textDecoration: "underline", cursor: "pointer" }}
          >
            {tok.text}
          </a>
        );
      case "text":
      default:
        return <span key={idx}>{tok.text}</span>;
    }
  });
}

function renderMarkdownBlocks(
  blocks: BlockToken[],
  handleLinkClick: (e: React.MouseEvent, target: string) => void,
  onChecklistToggle?: (lineIndex: number) => void,
  lineDirs?: Array<"ltr" | "rtl" | "auto">
): React.ReactNode {
  return blocks.map((b, i) => {
    // Per-line writing direction: an explicit override wins, otherwise
    // dir="auto" lets Hebrew and English lines share one box correctly.
    const blockDir = resolveLineDir(lineDirs, b.lineIndex);
    switch (b.type) {
      case "h1":
        return (
          <div key={i} dir={blockDir} style={{ fontSize: "1.45em", fontWeight: 700, margin: "4px 0 2px 0", lineHeight: 1.25 }}>
            {renderInlineTokens(b.tokens, handleLinkClick)}
          </div>
        );
      case "h2":
        return (
          <div key={i} dir={blockDir} style={{ fontSize: "1.25em", fontWeight: 600, margin: "3px 0 1px 0", lineHeight: 1.3 }}>
            {renderInlineTokens(b.tokens, handleLinkClick)}
          </div>
        );
      case "h3":
        return (
          <div key={i} dir={blockDir} style={{ fontSize: "1.12em", fontWeight: 600, margin: "2px 0 1px 0", lineHeight: 1.35 }}>
            {renderInlineTokens(b.tokens, handleLinkClick)}
          </div>
        );
      case "checklist":
        return (
          <div
            key={i}
            dir={blockDir}
            style={{
              display: "flex",
              alignItems: "flex-start",
              gap: 6,
              margin: "2px 0",
              cursor: onChecklistToggle ? "pointer" : "default",
            }}
            onClick={
              onChecklistToggle
                ? (e) => {
                    e.stopPropagation();
                    onChecklistToggle(b.lineIndex);
                  }
                : undefined
            }
          >
            <span
              style={{
                display: "inline-flex",
                alignItems: "center",
                justifyContent: "center",
                width: 16,
                height: 16,
                marginTop: 2,
                flexShrink: 0,
                borderRadius: 3,
                border: b.checked ? "1.5px solid #6366f1" : "1.5px solid currentColor",
                backgroundColor: b.checked ? "#6366f1" : "transparent",
                color: "#ffffff",
                transition: "all 0.15s ease",
              }}
            >
              {b.checked && (
                <svg
                  width="10"
                  height="10"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="3"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <polyline points="20 6 9 17 4 12" />
                </svg>
              )}
            </span>
            <div
              style={{
                textDecoration: b.checked ? "line-through" : "none",
                opacity: b.checked ? 0.6 : 1,
                flex: 1,
              }}
            >
              {renderInlineTokens(b.tokens, handleLinkClick)}
            </div>
          </div>
        );
      case "bullet":
        return (
          <div key={i} dir={blockDir} style={{ display: "flex", alignItems: "flex-start", gap: 6, margin: "1px 0" }}>
            <span style={{ opacity: 0.6, userSelect: "none" }}>•</span>
            <div style={{ flex: 1 }}>{renderInlineTokens(b.tokens, handleLinkClick)}</div>
          </div>
        );
      case "numbered":
        return (
          <div key={i} dir={blockDir} style={{ display: "flex", alignItems: "flex-start", gap: 6, margin: "1px 0" }}>
            <span style={{ opacity: 0.7, fontWeight: 500, minWidth: "1.2em", userSelect: "none" }}>
              {b.number}.
            </span>
            <div style={{ flex: 1 }}>{renderInlineTokens(b.tokens, handleLinkClick)}</div>
          </div>
        );
      case "quote":
        return (
          <div
            key={i}
            dir={blockDir}
            style={{
              borderLeft: "3px solid #6366f1",
              backgroundColor: "rgba(99,102,241,0.06)",
              padding: "3px 8px",
              margin: "2px 0",
              borderRadius: "0 4px 4px 0",
              fontStyle: "italic",
            }}
          >
            {renderInlineTokens(b.tokens, handleLinkClick)}
          </div>
        );
      case "codeblock":
        return (
          <pre
            key={i}
            dir={blockDir}
            style={{
              backgroundColor: "rgba(128,128,128,0.12)",
              padding: "6px 8px",
              borderRadius: 4,
              fontFamily: "monospace",
              fontSize: "0.88em",
              margin: "3px 0",
              overflowX: "auto",
              whiteSpace: "pre-wrap",
            }}
          >
            {b.rawText}
          </pre>
        );
      case "paragraph":
      default:
        return (
          <div key={i} dir={blockDir} style={{ minHeight: "1.2em" }}>
            {b.tokens.length > 0 ? renderInlineTokens(b.tokens, handleLinkClick) : "\u00A0"}
          </div>
        );
    }
  });
}

function TextShape({ element }: { element: TextElement }) {
  const setActiveBoard = useWhiteboard((s) => s.setActiveBoard);
  const findOrCreateBoardByName = useWhiteboard((s) => s.findOrCreateBoardByName);
  const setEditingId = useWhiteboard((s) => s.setEditingId);
  const updateElement = useWhiteboard((s) => s.updateElement);
  const commitHistory = useWhiteboard((s) => s.commitHistory);

  const handleLinkClick = (e: React.MouseEvent, target: string) => {
    e.stopPropagation();
    const boardId = findOrCreateBoardByName(target);
    setActiveBoard(boardId);
  };

  const handleChecklistToggle = (lineIndex: number) => {
    commitHistory();
    const newText = toggleChecklistAtLine(element.text || "", lineIndex);
    updateElement(element.id, { text: newText }, false);
  };

  const blocks = useMemo(() => parseMarkdownBlocks(element.text || ""), [element.text]);

  const isCard = !!(
    element.cardMode ||
    (element.backgroundColor && element.backgroundColor !== "transparent")
  );
  const bgColor = isCard ? element.backgroundColor || "#ffffff" : "transparent";
  const borderColor = isCard ? element.borderColor || "rgba(0,0,0,0.12)" : "transparent";
  const borderRadius = isCard ? `${element.borderRadius || 8}px` : "0px";
  const padding = isCard ? `${element.padding || 12}px` : "4px 8px";
  const boxShadow = isCard ? "0 2px 10px rgba(0,0,0,0.06)" : undefined;

  return (
    <foreignObject
      x={0}
      y={0}
      width={Math.max(element.width, 20)}
      height={Math.max(element.height, 20)}
      onDoubleClick={() => setEditingId(element.id)}
    >
      <div
        style={{
          width: "100%",
          height: "100%",
          backgroundColor: bgColor,
          border: isCard ? `1.5px solid ${borderColor}` : undefined,
          borderRadius,
          boxShadow,
          color: element.color || "#1e293b",
          fontSize: `${element.fontSize || 18}px`,
          fontFamily: element.fontFamily || "Inter, system-ui, sans-serif",
          fontWeight: element.fontWeight || 400,
          textAlign: element.align || "left",
          lineHeight: element.lineHeight || 1.45,
          wordBreak: "break-word",
          padding,
          userSelect: "none",
          cursor: "default",
          boxSizing: "border-box",
        }}
      >
        {element.text ? (
          renderMarkdownBlocks(blocks, handleLinkClick, handleChecklistToggle, element.lineDirs)
        ) : (
          <span style={{ opacity: 0.4, fontStyle: "italic" }}>Type thoughts…</span>
        )}
      </div>
    </foreignObject>
  );
}

// ============================================================================
// Sticky Notes
// ============================================================================

function StickyShape({ element }: { element: StickyElement }) {
  const colors = STICKY_COLORS[element.color] || STICKY_COLORS.yellow;
  const setActiveBoard = useWhiteboard((s) => s.setActiveBoard);
  const findOrCreateBoardByName = useWhiteboard((s) => s.findOrCreateBoardByName);
  const setEditingId = useWhiteboard((s) => s.setEditingId);
  const updateElement = useWhiteboard((s) => s.updateElement);
  const commitHistory = useWhiteboard((s) => s.commitHistory);

  const handleLinkClick = (e: React.MouseEvent, target: string) => {
    e.stopPropagation();
    const boardId = findOrCreateBoardByName(target);
    setActiveBoard(boardId);
  };

  const handleChecklistToggle = (lineIndex: number) => {
    commitHistory();
    const newText = toggleChecklistAtLine(element.text || "", lineIndex);
    updateElement(element.id, { text: newText }, false);
  };

  const blocks = useMemo(() => parseMarkdownBlocks(element.text || ""), [element.text]);

  return (
    <foreignObject
      x={0}
      y={0}
      width={Math.max(element.width, 40)}
      height={Math.max(element.height, 40)}
      onDoubleClick={() => setEditingId(element.id)}
    >
      <div
        style={{
          width: "100%",
          height: "100%",
          backgroundColor: colors.bg,
          border: `1.5px solid ${colors.border}`,
          borderRadius: "8px",
          color: colors.text,
          fontSize: `${element.fontSize || 16}px`,
          fontFamily: "Inter, system-ui, sans-serif",
          textAlign: element.align || "left",
          padding: "14px",
          overflow: "hidden",
          wordBreak: "break-word",
          boxShadow: "0 4px 14px rgba(0,0,0,0.08)",
          lineHeight: 1.45,
          userSelect: "none",
          boxSizing: "border-box",
        }}
      >
        {element.text ? (
          renderMarkdownBlocks(blocks, handleLinkClick, handleChecklistToggle, element.lineDirs)
        ) : (
          <span style={{ opacity: 0.45, fontStyle: "italic" }}>Write note…</span>
        )}
      </div>
    </foreignObject>
  );
}

// ============================================================================
// Image
// ============================================================================

/**
 * Resolves an image src for rendering.
 *
 * `asset:<id>` means the pixels live in IndexedDB (see lib/whiteboard/
 * imagestore.ts) rather than in the workspace, because a single image was
 * measured at 908 KB against a ~5 MB localStorage budget. An ordinary data or
 * http URL is returned unchanged, so every image saved before that change
 * still renders.
 *
 * Resolved URLs are cached across components: the same photo used on ten pages
 * must not mean ten IndexedDB reads per frame.
 */
const assetUrlCache = new Map<string, string>();

export function useResolvedImageSrc(src: string): string {
  const isRef = isAssetRef(src);
  const [resolved, setResolved] = React.useState<string>(() =>
    isRef ? assetUrlCache.get(src) ?? "" : src
  );

  React.useEffect(() => {
    if (!isRef) {
      setResolved(src);
      return;
    }
    const cached = assetUrlCache.get(src);
    if (cached) {
      setResolved(cached);
      return;
    }
    let alive = true;
    loadImage(assetIdOf(src)).then((url) => {
      if (!alive || !url) return;
      assetUrlCache.set(src, url);
      setResolved(url);
    });
    return () => {
      alive = false;
    };
  }, [src, isRef]);

  return resolved;
}

function ImageShape({ element }: { element: ImageElement }) {
  const href = useResolvedImageSrc(element.src);

  // An image whose pixels are still loading, or whose payload was dropped by a
  // full-storage save, gets a placeholder rather than an invisible gap — the
  // element is still there and still selectable.
  if (!href) {
    return (
      <rect
        x={0}
        y={0}
        width={element.width}
        height={element.height}
        rx={6}
        className="fill-zinc-200 stroke-zinc-300 dark:fill-zinc-800 dark:stroke-zinc-700"
        strokeWidth={1}
        style={{ pointerEvents: "auto" }}
      />
    );
  }

  // An untouched picture is drawn exactly as before edits existed.
  if (isUnedited(element)) {
    return (
      <image
        href={href}
        x={0}
        y={0}
        width={element.width}
        height={element.height}
        preserveAspectRatio="xMidYMid meet"
        style={{
          borderRadius: "6px",
          pointerEvents: "auto",
        }}
      />
    );
  }

  // Crop = the inner svg's viewBox; flip = a transform on the picture;
  // frame = a clip. The pixels themselves are never touched (imageEdit.ts).
  const L = imageLayout(element);
  const w = element.width;
  const h = element.height;
  const clipId = `imgclip-${element.id}`;
  const bw = element.borderWidth && element.borderWidth > 0 ? element.borderWidth : 0;
  const shape = (extra: React.SVGProps<SVGElement>) =>
    L.frame === "circle" ? (
      <ellipse cx={w / 2} cy={h / 2} rx={w / 2} ry={h / 2} {...(extra as React.SVGProps<SVGEllipseElement>)} />
    ) : (
      <rect x={0} y={0} width={w} height={h} rx={L.radius} {...(extra as React.SVGProps<SVGRectElement>)} />
    );
  return (
    <g style={{ pointerEvents: "auto" }}>
      <clipPath id={clipId}>{shape({})}</clipPath>
      <g clipPath={`url(#${clipId})`}>
        <svg
          x={0}
          y={0}
          width={w}
          height={h}
          viewBox={`${L.viewBox.x} ${L.viewBox.y} ${L.viewBox.w} ${L.viewBox.h}`}
          preserveAspectRatio="xMidYMid meet"
        >
          <image
            href={href}
            x={0}
            y={0}
            width={L.nw}
            height={L.nh}
            preserveAspectRatio="none"
            transform={L.flip || undefined}
            style={L.filter ? { filter: L.filter } : undefined}
          />
        </svg>
      </g>
      {bw > 0 && shape({ fill: "none", stroke: element.borderColor || "#18181b", strokeWidth: bw })}
    </g>
  );
}

// ============================================================================
// Smart Directed Connections (Obsidian Canvas Grade)
// ============================================================================

function ConnectionShape({ element }: { element: ConnectionElement }) {
  const boards = useWhiteboard((s) => s.boards);
  const customLinkTypes = useWhiteboard((s) => s.customLinkTypes);
  const updateElement = useWhiteboard((s) => s.updateElement);
  const commitHistory = useWhiteboard((s) => s.commitHistory);

  const [isEditingLabel, setIsEditingLabel] = useState(false);
  const [draftLabel, setDraftLabel] = useState(element.label || "");

  // Find source & target elements.
  //
  // A connection can point at an element on any board, and that board may be a
  // notebook — whose elements live on its pages, not on `elements`. Searching
  // the canvas field alone made every connection into a notebook resolve to
  // nothing, so the whole connection silently vanished.
  const findAcrossBoard = (boardId: string, elementId: string) => {
    const b = boards.find((x) => x.id === boardId);
    return b ? allElements(b).find((e) => e.id === elementId) : undefined;
  };
  const sourceEl = findAcrossBoard(element.source.boardId, element.source.elementId);
  const targetEl = findAcrossBoard(element.target.boardId, element.target.elementId);

  if (!sourceEl || !targetEl) return null;

  // Resolve anchor points
  const { source, target } = getOptimalConnectionAnchors(
    sourceEl,
    targetEl,
    element.source.anchor,
    element.target.anchor
  );

  const pathD = getConnectionPath(source, target, element.routing || "curved");
  const color = getLinkTypeColor(element.linkType, customLinkTypes);
  const defaultLabel = getLinkTypeLabel(element.linkType, customLinkTypes);
  const displayLabel = element.label !== undefined ? element.label : defaultLabel;

  // Arrowheads
  const endHead = getArrowheadPath(
    target.x,
    target.y,
    target.x + target.nx * 20,
    target.y + target.ny * 20,
    element.endArrowhead || "arrow",
    12
  );

  const startHead = element.startArrowhead && element.startArrowhead !== "none"
    ? getArrowheadPath(
        source.x,
        source.y,
        source.x + source.nx * 20,
        source.y + source.ny * 20,
        element.startArrowhead,
        12
      )
    : null;

  // Calculate midpoint for the badge
  const midX = (source.x + target.x) / 2;
  const midY = (source.y + target.y) / 2;

  let strokeDasharray: string | undefined = undefined;
  if (element.dashStyle === "dashed") strokeDasharray = "6,4";
  else if (element.dashStyle === "dotted") strokeDasharray = "2,4";

  return (
    <g style={{ pointerEvents: "auto", color }}>
      {/* Invisible thicker hit-path */}
      <path
        d={pathD}
        fill="none"
        stroke="transparent"
        strokeWidth={16}
        style={{ cursor: "pointer" }}
      />

      {/* Main Connection Line */}
      <path
        d={pathD}
        fill="none"
        stroke={color}
        strokeWidth={element.strokeWidth || 2.5}
        strokeDasharray={strokeDasharray}
        strokeLinecap="round"
      />

      {/* Start Arrowhead */}
      {startHead && (
        <path d={startHead.path} fill={color} stroke="none" />
      )}

      {/* End Arrowhead */}
      {endHead && (
        <path d={endHead.path} fill={color} stroke="none" />
      )}

      {/* Interactive Semantic Relationship Badge */}
      {displayLabel && (
        <g
          transform={`translate(${midX}, ${midY})`}
          style={{ cursor: "pointer" }}
          onClick={(e) => {
            e.stopPropagation();
            setIsEditingLabel(true);
            setDraftLabel(displayLabel);
          }}
        >
          {isEditingLabel ? (
            <foreignObject x={-60} y={-14} width={120} height={28}>
              <input
                type="text"
                autoFocus
                value={draftLabel}
                onChange={(e) => setDraftLabel(e.target.value)}
                onBlur={() => {
                  commitHistory();
                  updateElement(element.id, { label: draftLabel.trim() }, false);
                  setIsEditingLabel(false);
                }}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    commitHistory();
                    updateElement(element.id, { label: draftLabel.trim() }, false);
                    setIsEditingLabel(false);
                  }
                  if (e.key === "Escape") {
                    setIsEditingLabel(false);
                  }
                }}
                className="w-full h-full px-2 text-[11px] font-semibold text-center rounded-full border border-primary bg-background shadow-lg outline-none"
              />
            </foreignObject>
          ) : (
            <>
              {/* Badge Background */}
              <rect
                x={-(displayLabel.length * 3.8 + 12)}
                y={-11}
                width={displayLabel.length * 7.6 + 24}
                height={22}
                rx={11}
                fill="white"
                className="dark:fill-zinc-900"
                stroke={color}
                strokeWidth={1.5}
                style={{ filter: "drop-shadow(0 2px 4px rgba(0,0,0,0.1))" }}
              />
              {/* Badge Text */}
              <text
                x={0}
                y={3.5}
                fill={color}
                textAnchor="middle"
                fontSize={11}
                fontWeight={600}
                fontFamily="Inter, system-ui, sans-serif"
              >
                {displayLabel}
              </text>
            </>
          )}
        </g>
      )}
    </g>
  );
}
