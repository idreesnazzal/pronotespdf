"use client";

/**
 * The bar that floats over ONE selected picture.
 *
 * The quick things happen right here, one tap each: turn a quarter, mirror,
 * swap the photo for another, lock it in place. Anything that needs a closer
 * look — cropping, a look, a frame — opens the editor (ImageStudio).
 * Resizing is the selection box's own corner handles, as for everything else.
 */

import React from "react";
import { Crop, FlipHorizontal2, Lock, Replace, RotateCw, Undo2 } from "lucide-react";
import { useWhiteboard, useActiveBoard } from "@/store/whiteboard";
import { getBoardElements } from "@/lib/whiteboard/notebook";
import { getElementBounds, type Viewport } from "@/lib/whiteboard/geometry";
import type { ImageElement } from "@/lib/whiteboard/types";
import { FULL_CROP, boxForCrop, flipCrop, isUnedited, normalizeCrop, quarterTurn } from "@/lib/whiteboard/imageEdit";
import { prepareImage } from "@/lib/whiteboard/imageImport";
import { storeImage } from "@/lib/whiteboard/imagestore";
import { cn } from "@/lib/utils";

export function ImageActions({ viewport }: { viewport: Viewport }) {
  const selectedIds = useWhiteboard((s) => s.selectedIds);
  const camera = useWhiteboard((s) => s.camera);
  const lockedMode = useWhiteboard((s) => s.lockedMode);
  const studioOpen = useWhiteboard((s) => s.imageStudioId !== null);
  const board = useActiveBoard();
  const replaceRef = React.useRef<HTMLInputElement>(null);

  if (selectedIds.length !== 1 || !board || lockedMode || studioOpen) return null;
  const found = getBoardElements(board).find((e) => e.id === selectedIds[0]);
  if (!found || found.type !== "image" || found.locked) return null;
  const el = found as ImageElement;

  const store = () => useWhiteboard.getState();
  const patch = (p: Partial<ImageElement>) => {
    store().commitHistory();
    store().updateElement(el.id, p, false);
  };

  const onReplace = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    const dataUrl = await prepareImage(file);
    const img = new Image();
    img.onload = async () => {
      const src = await storeImage(dataUrl);
      const nw = img.naturalWidth || el.naturalWidth;
      const nh = img.naturalHeight || el.naturalHeight;
      // Same width and place; the height follows the new photo's shape. The
      // old edits described the OLD photo, so they go with it.
      const height = (el.width * nh) / nw;
      patch({
        src,
        naturalWidth: nw,
        naturalHeight: nh,
        height,
        y: el.y + (el.height - height) / 2,
        crop: undefined,
        flipX: undefined,
        flipY: undefined,
      });
    };
    img.src = dataUrl;
  };

  const b = getElementBounds(el);
  const sx = (b.x - camera.x) * camera.zoom + viewport.width / 2;
  const sy = (b.y - camera.y) * camera.zoom + viewport.height / 2;
  const sw = b.width * camera.zoom;
  const sh = b.height * camera.zoom;
  const left = Math.min(Math.max(sx + sw / 2, 150), viewport.width - 150);
  // BELOW the picture: the rotate handle sits above it, and a bar there
  // covered it. With no room below (a tall picture), above the handle; failing
  // both, inside the bottom edge.
  const below = sy + sh + 16;
  const above = sy - 96;
  const top = below + 48 < viewport.height - 80 ? below : above > 8 ? above : Math.min(sy + sh - 56, viewport.height - 140);

  const btn =
    "flex h-9 items-center gap-1.5 rounded-full px-2.5 text-[12px] font-medium text-zinc-200 transition hover:bg-white/10 active:scale-95";

  return (
    <div
      className="absolute z-40 flex -translate-x-1/2 items-center gap-0.5 rounded-full border border-white/10 bg-zinc-900/95 p-1 shadow-2xl backdrop-blur-md animate-in fade-in zoom-in-95"
      style={{ left, top }}
      onPointerDown={(e) => e.stopPropagation()}
      onMouseDown={(e) => e.stopPropagation()}
    >
      <input ref={replaceRef} type="file" accept="image/*" className="hidden" onChange={onReplace} />
      <button
        onClick={() => store().setImageStudioId(el.id)}
        className="flex h-9 items-center gap-1.5 rounded-full bg-indigo-500 px-3.5 text-[12px] font-semibold text-white shadow-md shadow-indigo-500/30 transition hover:bg-indigo-400 active:scale-95"
      >
        <Crop size={15} /> Edit
      </button>
      <button className={btn} title="Turn a quarter" aria-label="Turn a quarter" onClick={() => patch({ rotation: quarterTurn(el.rotation, 1) })}>
        <RotateCw size={16} />
      </button>
      <button
        className={cn(btn, el.flipX && "text-indigo-300")}
        title="Mirror"
        aria-label="Mirror"
        onClick={() => patch({ flipX: !el.flipX || undefined, crop: el.crop ? flipCrop(normalizeCrop(el.crop), "x") : undefined })}
      >
        <FlipHorizontal2 size={16} />
      </button>
      <button className={btn} title="Replace with another picture" aria-label="Replace" onClick={() => replaceRef.current?.click()}>
        <Replace size={16} />
      </button>
      {!isUnedited(el) && (
        <button
          className={btn}
          title="Back to the original photo"
          onClick={() =>
            patch({
              crop: undefined,
              flipX: undefined,
              flipY: undefined,
              filter: undefined,
              frame: undefined,
              borderWidth: undefined,
              // Uncropped again, at the same scale: the whole photo comes back.
              ...boxForCrop(el, FULL_CROP),
            })
          }
        >
          <Undo2 size={16} />
        </button>
      )}
      <span className="mx-0.5 h-5 w-px bg-white/15" />
      <button
        className={btn}
        title="Lock in place (unlock from Select → Locked items)"
        onClick={() => {
          store().toggleLock([el.id]);
          store().clearSelection();
        }}
      >
        <Lock size={15} /> Lock
      </button>
    </div>
  );
}
