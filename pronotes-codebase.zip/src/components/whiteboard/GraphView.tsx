"use client";

/**
 * Interactive Knowledge Graph View (Obsidian Canvas & Network Grade v4)
 * =====================================================================
 * Comprehensive interactive knowledge network connecting boards, folders,
 * notes/cards, and #tags with:
 * - Full tablet multi-touch pinch-to-zoom & dual-pointer pan
 * - S Pen stylus hover peek cards & pen gesture isolation
 * - Drag vs tap disambiguation with Euclidean deadband
 * - Global Universe vs Local Neighborhood subgraphs
 * - Node Inspector Drawer with backlink & outbound connection analysis
 * - Tag clustering (#tags) with semantic relationship edges
 * - Interactive Minimap Radar with camera viewport tracking
 * - True bounding-box Auto-Fit (Zoom to Extents)
 * - Vector SVG & 2x Retina PNG export
 * - Organic force-directed physics with settle/reheat
 */

import React, { useEffect, useMemo, useRef, useState, useCallback } from "react";
import { useWhiteboard } from "@/store/whiteboard";
import {
  buildGraph,
  parseElementNodeId,
  filterGraphNeighborhood,
  type GraphData,
  type GraphNode,
} from "@/lib/whiteboard/links";
import {
  X,
  Star,
  Search,
  Network,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  Maximize2,
  Download,
  Filter,
  Compass,
  Layers,
  Hash,
  FileText,
  Folder as FolderIcon,
  Tag as TagIcon,
  Sparkles,
  Pin,
  ExternalLink,
  Play,
  Pause,
  ArrowUpRight,
  ArrowDownLeft,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

interface GraphViewProps {
  open: boolean;
  onClose: () => void;
}

interface SimNode extends GraphNode {
  x: number;
  y: number;
  vx: number;
  vy: number;
  degree: number;
  isPinned?: boolean;
}

interface SimEdge {
  id: string;
  source: string;
  target: string;
  kind?: "link" | "parent" | "tag";
  label?: string;
  color?: string;
  linkType?: string;
}

/**
 * SVG node silhouettes corresponding to whiteboard element types.
 */
function elementNodeShape(elementType: string | undefined, r: number): React.ReactNode {
  switch (elementType) {
    case "text":
      return <rect x={-r * 1.35} y={-r * 0.72} width={r * 2.7} height={r * 1.44} rx={3} />;
    case "sticky":
      return (
        <path d={`M ${-r} ${-r} H ${r} V ${r * 0.35} L ${r * 0.35} ${r} H ${-r} Z`} />
      );
    case "image":
      return <rect x={-r * 1.2} y={-r * 0.9} width={r * 2.4} height={r * 1.8} rx={2} />;
    case "diamond":
      return <path d={`M 0 ${-r} L ${r} 0 L 0 ${r} L ${-r} 0 Z`} />;
    case "triangle":
      return <path d={`M 0 ${-r} L ${r} ${r * 0.8} L ${-r} ${r * 0.8} Z`} />;
    case "star":
      return (
        <path
          d={Array.from({ length: 10 }, (_, i) => {
            const rad = i % 2 === 0 ? r : r * 0.45;
            const a = (Math.PI / 5) * i - Math.PI / 2;
            return `${i === 0 ? "M" : "L"} ${(Math.cos(a) * rad).toFixed(2)} ${(Math.sin(a) * rad).toFixed(2)}`;
          }).join(" ") + " Z"}
        />
      );
    case "ellipse":
      return <ellipse rx={r * 1.15} ry={r * 0.85} />;
    case "line":
    case "arrow":
      return <rect x={-r * 1.3} y={-r * 0.3} width={r * 2.6} height={r * 0.6} rx={r * 0.3} />;
    case "stroke":
      return <path d={`M ${-r} ${r * 0.5} Q 0 ${-r * 1.3} ${r} ${r * 0.5}`} fill="none" strokeLinecap="round" />;
    case "tag":
      return (
        <path
          d={`M ${-r * 1.2} ${-r * 0.6} L ${r * 0.5} ${-r * 0.6} L ${r * 1.2} 0 L ${r * 0.5} ${r * 0.6} L ${-r * 1.2} ${r * 0.6} Z`}
        />
      );
    default:
      return <rect x={-r} y={-r} width={r * 2} height={r * 2} rx={4} />;
  }
}

export function GraphView({ open, onClose }: GraphViewProps) {
  const boards = useWhiteboard((s) => s.boards);
  const folders = useWhiteboard((s) => s.folders);
  const activeBoardId = useWhiteboard((s) => s.activeBoardId);
  const setActiveBoard = useWhiteboard((s) => s.setActiveBoard);
  const revealFolder = useWhiteboard((s) => s.revealFolder);
  const focusElement = useWhiteboard((s) => s.focusElement);
  const customLinkTypes = useWhiteboard((s) => s.customLinkTypes);

  const containerRef = useRef<HTMLDivElement>(null);
  const svgRef = useRef<SVGSVGElement>(null);

  // Layout Viewport
  const [dims, setDims] = useState({ width: 1000, height: 700 });
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });

  // Mode & Filtering
  const [graphMode, setGraphMode] = useState<"global" | "local">("global");
  const [localFocusId, setLocalFocusId] = useState<string | null>(null);
  const [localDepth, setLocalDepth] = useState<number>(1);

  const [showFolders, setShowFolders] = useState(true);
  const [showElements, setShowElements] = useState(true);
  const [showTags, setShowTags] = useState(true);
  const [showOrphans, setShowOrphans] = useState(true);
  const [physicsEnabled, setPhysicsEnabled] = useState(true);
  const [filterMenuOpen, setFilterMenuOpen] = useState(false);

  // Search & Inspection
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);
  const [hoveredNode, setHoveredNode] = useState<string | null>(null);
  const [hoverAnchor, setHoverAnchor] = useState<{ x: number; y: number } | null>(null);

  // Multi-Touch & Gesture Refs
  const activePointersRef = useRef<Map<number, { x: number; y: number; pointerType: string }>>(new Map());
  const pinchStartRef = useRef<{ dist: number; zoom: number; mid: { x: number; y: number }; pan: { x: number; y: number } } | null>(null);
  const canvasPanStartRef = useRef<{ x: number; y: number } | null>(null);
  const isPanningRef = useRef(false);

  // Node Drag & Tap Disambiguation Refs
  const [dragNodeId, setDragNodeId] = useState<string | null>(null);
  const [nodePositions, setNodePositions] = useState<Record<string, { x: number; y: number }>>({});
  const [pinnedNodeIds, setPinnedNodeIds] = useState<Set<string>>(new Set());
  const nodeDragStartRef = useRef<{ x: number; y: number } | null>(null);
  const nodeHasDraggedRef = useRef<boolean>(false);
  const lastTapRef = useRef<{ id: string; time: number } | null>(null);

  // Cached positions across renders to avoid layout scrambling
  const cachedPositionsRef = useRef<Map<string, { x: number; y: number }>>(new Map());

  // Set local focus to active board on open
  useEffect(() => {
    if (open && activeBoardId) {
      setLocalFocusId(activeBoardId);
    }
  }, [open, activeBoardId]);

  // Track container size
  useEffect(() => {
    if (!open) return;
    const update = () => {
      if (containerRef.current) {
        const rect = containerRef.current.getBoundingClientRect();
        if (rect.width > 100 && rect.height > 100) {
          setDims({ width: rect.width, height: rect.height });
        }
      }
    };
    update();
    const timer = setTimeout(update, 50);
    window.addEventListener("resize", update);
    return () => {
      clearTimeout(timer);
      window.removeEventListener("resize", update);
    };
  }, [open]);

  // Keyboard shortcut: Escape to close
  useEffect(() => {
    if (!open) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        if (selectedNodeId) {
          setSelectedNodeId(null);
        } else {
          onClose();
        }
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [open, selectedNodeId, onClose]);

  // 1. Build Global Graph Data
  const rawGlobalGraphData = useMemo<GraphData>(() => {
    return buildGraph(boards, customLinkTypes, folders, {
      includeTags: true,
      includeElements: true,
    });
  }, [boards, customLinkTypes, folders]);

  // 2. Select between Global and Local Subgraph
  const baseGraphData = useMemo<GraphData>(() => {
    if (graphMode === "local") {
      const focusTarget = localFocusId || activeBoardId || boards[0]?.id;
      if (focusTarget) {
        return filterGraphNeighborhood(rawGlobalGraphData, focusTarget, localDepth);
      }
    }
    return rawGlobalGraphData;
  }, [graphMode, localFocusId, activeBoardId, boards, localDepth, rawGlobalGraphData]);

  // 3. Assemble and Filter Edges
  const allEdges = useMemo<SimEdge[]>(() => {
    const wikilinkEdges: SimEdge[] = baseGraphData.edges.map((e) => ({
      id: e.id,
      source: e.source,
      target: e.target,
      kind: (e.linkType === "tag" ? "tag" : "link") as "link" | "tag",
      label: e.label,
      color: e.color || "#6366f1",
      linkType: e.linkType,
    }));

    // Folder parent-child edges (only in global mode or when folder is included)
    const folderParentEdges: SimEdge[] = [];
    if (graphMode === "global") {
      for (const b of boards) {
        if (b.folderId) {
          folderParentEdges.push({
            id: `parent-${b.folderId}-${b.id}`,
            source: b.folderId,
            target: b.id,
            kind: "parent",
            color: "#9ca3af",
          });
        }
      }
    }

    return [...wikilinkEdges, ...folderParentEdges];
  }, [baseGraphData, boards, graphMode]);

  // 4. Force-Directed Layout Simulation (Cohesive & Organic)
  const simulatedNodes = useMemo<SimNode[]>(() => {
    if (!open || dims.width === 0) return [];
    if (baseGraphData.nodes.length === 0 && folders.length === 0) return [];

    const cx = dims.width / 2;
    const cy = dims.height / 2;
    const initialRadius = Math.min(dims.width, dims.height) / 2.8;

    // Combine base nodes with folder vertices
    const allItems: GraphNode[] = [
      ...baseGraphData.nodes,
      ...(graphMode === "global"
        ? folders.map((f) => ({
            id: f.id,
            name: f.name,
            inDegree: 0,
            outDegree: 0,
            orphan: true,
            starred: false,
            tagCount: 0,
            folderId: null,
            kind: "folder" as const,
            color: f.color || "#f59e0b",
          }))
        : []),
    ];

    // Deduplicate by ID
    const uniqueItemsMap = new Map<string, GraphNode>();
    for (const item of allItems) {
      if (!uniqueItemsMap.has(item.id)) {
        uniqueItemsMap.set(item.id, item);
      }
    }
    const items = Array.from(uniqueItemsMap.values());

    const simNodes: SimNode[] = items.map((n, i) => {
      const cached = cachedPositionsRef.current.get(n.id);
      const angle = (i / Math.max(1, items.length)) * Math.PI * 2;
      const board = boards.find((b) => b.id === n.id);
      const folder = folders.find((f) => f.id === n.id);
      const degree = allEdges.filter((e) => e.source === n.id || e.target === n.id).length;

      const initX = cached ? cached.x : cx + Math.cos(angle) * (initialRadius * 0.85);
      const initY = cached ? cached.y : cy + Math.sin(angle) * (initialRadius * 0.85);

      return {
        ...n,
        x: initX,
        y: initY,
        vx: 0,
        vy: 0,
        degree,
        starred: !!board?.starred,
        orphan: degree === 0,
        color: n.color || board?.color || folder?.color || (n.kind === "tag" ? "#10b981" : "#3b82f6"),
        isPinned: pinnedNodeIds.has(n.id),
      };
    });

    // Run force layout simulation if physics enabled
    if (physicsEnabled) {
      const nodeMap = new Map(simNodes.map((n) => [n.id, n]));
      const iterations = 85;
      const k = 120; // Ideal spring rest length
      const repulsion = 12000;
      const attraction = 0.045;
      const damping = 0.86;

      for (let iter = 0; iter < iterations; iter++) {
        const cooling = Math.pow(0.96, iter);

        // Repulsion between all node pairs
        for (let i = 0; i < simNodes.length; i++) {
          const a = simNodes[i];
          for (let j = i + 1; j < simNodes.length; j++) {
            const b = simNodes[j];
            const dx = b.x - a.x;
            const dy = b.y - a.y;
            const dist = Math.max(16, Math.hypot(dx, dy));
            const force = (repulsion / (dist * dist)) * cooling;
            const fx = (dx / dist) * force;
            const fy = (dy / dist) * force;
            if (!a.isPinned) {
              a.vx -= fx;
              a.vy -= fy;
            }
            if (!b.isPinned) {
              b.vx += fx;
              b.vy += fy;
            }
          }
        }

        // Attraction along edges
        for (const edge of allEdges) {
          const a = nodeMap.get(edge.source);
          const b = nodeMap.get(edge.target);
          if (!a || !b) continue;
          const dx = b.x - a.x;
          const dy = b.y - a.y;
          const dist = Math.max(1, Math.hypot(dx, dy));
          const force = (dist - k) * attraction * cooling;
          const fx = (dx / dist) * force;
          const fy = (dy / dist) * force;
          if (!a.isPinned) {
            a.vx += fx;
            a.vy += fy;
          }
          if (!b.isPinned) {
            b.vx -= fx;
            b.vy -= fy;
          }
        }

        // Integration with radial soft gravity (organic cohesion in open space)
        for (const n of simNodes) {
          if (n.isPinned) continue;
          n.vx += (cx - n.x) * 0.0035;
          n.vy += (cy - n.y) * 0.0035;
          n.vx *= damping;
          n.vy *= damping;
          n.x += n.vx;
          n.y += n.vy;
        }
      }
    }

    // Cache updated simulated coordinates
    for (const n of simNodes) {
      cachedPositionsRef.current.set(n.id, { x: n.x, y: n.y });
    }

    return simNodes;
  }, [open, dims, baseGraphData, folders, graphMode, boards, allEdges, physicsEnabled, pinnedNodeIds]);

  // Combine simulated positions with user drag overrides
  const nodes = useMemo<SimNode[]>(() => {
    return simulatedNodes.map((n) => {
      const override = nodePositions[n.id];
      if (override) {
        return { ...n, x: override.x, y: override.y };
      }
      return n;
    });
  }, [simulatedNodes, nodePositions]);

  // 5. Apply User Filtering (Folders, Elements, Tags, Orphans)
  const filteredNodes = useMemo<SimNode[]>(() => {
    return nodes.filter((n) => {
      if (!showFolders && n.kind === "folder") return false;
      if (!showElements && n.kind === "element") return false;
      if (!showTags && n.kind === "tag") return false;
      if (!showOrphans && n.orphan) return false;
      return true;
    });
  }, [nodes, showFolders, showElements, showTags, showOrphans]);

  const visibleNodeIds = useMemo(() => new Set(filteredNodes.map((n) => n.id)), [filteredNodes]);

  const visibleEdges = useMemo<SimEdge[]>(() => {
    return allEdges.filter((e) => visibleNodeIds.has(e.source) && visibleNodeIds.has(e.target));
  }, [allEdges, visibleNodeIds]);

  // 6. Search Highlighting & Neighborhood Illumination
  const searchQueryNormalized = searchQuery.trim().toLowerCase();

  const matchingNodeIds = useMemo<Set<string> | null>(() => {
    if (!searchQueryNormalized) return null;
    const matches = new Set<string>();
    for (const n of filteredNodes) {
      if (
        n.name.toLowerCase().includes(searchQueryNormalized) ||
        n.tags?.some((t) => t.toLowerCase().includes(searchQueryNormalized)) ||
        (n.snippet && n.snippet.toLowerCase().includes(searchQueryNormalized))
      ) {
        matches.add(n.id);
      }
    }
    return matches;
  }, [filteredNodes, searchQueryNormalized]);

  const highlightedNodeIds = useMemo<Set<string> | null>(() => {
    if (!matchingNodeIds) return null;
    const connected = new Set<string>(matchingNodeIds);
    for (const edge of visibleEdges) {
      if (matchingNodeIds.has(edge.source)) connected.add(edge.target);
      if (matchingNodeIds.has(edge.target)) connected.add(edge.source);
    }
    return connected;
  }, [matchingNodeIds, visibleEdges]);

  // 7. Auto-Fit Viewport Algorithm (Zoom to Extents)
  const fitToView = useCallback(() => {
    if (filteredNodes.length === 0 || !containerRef.current) return;
    const padding = 70;
    let minX = Infinity;
    let maxX = -Infinity;
    let minY = Infinity;
    let maxY = -Infinity;

    for (const n of filteredNodes) {
      if (n.x < minX) minX = n.x;
      if (n.x > maxX) maxX = n.x;
      if (n.y < minY) minY = n.y;
      if (n.y > maxY) maxY = n.y;
    }

    const graphWidth = Math.max(120, maxX - minX);
    const graphHeight = Math.max(120, maxY - minY);
    const availableWidth = Math.max(200, dims.width - padding * 2);
    const availableHeight = Math.max(200, dims.height - padding * 2);

    const targetZoom = Math.min(
      Math.max(Math.min(availableWidth / graphWidth, availableHeight / graphHeight), 0.35),
      2.2
    );

    const centerX = (minX + maxX) / 2;
    const centerY = (minY + maxY) / 2;
    const targetPanX = dims.width / 2 - centerX * targetZoom;
    const targetPanY = dims.height / 2 - centerY * targetZoom;

    setZoom(targetZoom);
    setPan({ x: targetPanX, y: targetPanY });
  }, [filteredNodes, dims]);

  // Auto-fit on initial modal open when nodes become available
  const hasAutoFittedRef = useRef(false);
  useEffect(() => {
    if (open && filteredNodes.length > 0 && !hasAutoFittedRef.current) {
      hasAutoFittedRef.current = true;
      const t = setTimeout(fitToView, 60);
      return () => clearTimeout(t);
    }
  }, [open, filteredNodes.length, fitToView]);

  // Native non-passive Wheel zoom centered around cursor
  useEffect(() => {
    const el = containerRef.current;
    if (!el || !open) return;
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      const factor = e.deltaY < 0 ? 1.15 : 0.85;
      const rect = el.getBoundingClientRect();
      const mouseX = e.clientX - rect.left;
      const mouseY = e.clientY - rect.top;

      setZoom((prevZoom) => {
        const nextZoom = Math.min(Math.max(prevZoom * factor, 0.25), 3.5);
        setPan((prevPan) => ({
          x: mouseX - ((mouseX - prevPan.x) / prevZoom) * nextZoom,
          y: mouseY - ((mouseY - prevPan.y) / prevZoom) * nextZoom,
        }));
        return nextZoom;
      });
    };
    el.addEventListener("wheel", onWheel, { passive: false });
    return () => el.removeEventListener("wheel", onWheel);
  }, [open]);

  // 8. Multi-Touch Gesture Handling (Pinch-to-Zoom & Dual-Pointer Pan)
  const handleCanvasPointerDown = (e: React.PointerEvent) => {
    const target = e.target as HTMLElement;
    if (target.tagName === "svg" || target.id === "graph-canvas" || target.id === "graph-background") {
      activePointersRef.current.set(e.pointerId, {
        x: e.clientX,
        y: e.clientY,
        pointerType: e.pointerType,
      });

      if (activePointersRef.current.size === 1) {
        isPanningRef.current = true;
        canvasPanStartRef.current = { x: e.clientX - pan.x, y: e.clientY - pan.y };
        target.setPointerCapture?.(e.pointerId);
      } else if (activePointersRef.current.size === 2) {
        // Multi-touch pinch started!
        const pts = Array.from(activePointersRef.current.values());
        const dist = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
        const mid = { x: (pts[0].x + pts[1].x) / 2, y: (pts[0].y + pts[1].y) / 2 };
        pinchStartRef.current = { dist, zoom, mid, pan: { ...pan } };
      }
    }
  };

  const handleCanvasPointerMove = (e: React.PointerEvent) => {
    if (activePointersRef.current.has(e.pointerId)) {
      activePointersRef.current.set(e.pointerId, {
        x: e.clientX,
        y: e.clientY,
        pointerType: e.pointerType,
      });
    }

    // 2-Finger Pinch to Zoom & Pan
    if (activePointersRef.current.size === 2 && pinchStartRef.current) {
      const pts = Array.from(activePointersRef.current.values());
      const currentDist = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
      const currentMid = { x: (pts[0].x + pts[1].x) / 2, y: (pts[0].y + pts[1].y) / 2 };

      const scale = currentDist / Math.max(1, pinchStartRef.current.dist);
      const newZoom = Math.min(Math.max(pinchStartRef.current.zoom * scale, 0.25), 3.5);

      const containerRect = containerRef.current?.getBoundingClientRect();
      const midRelX = currentMid.x - (containerRect?.left || 0);
      const midRelY = currentMid.y - (containerRect?.top || 0);

      const newPanX = midRelX - ((midRelX - pinchStartRef.current.pan.x) / pinchStartRef.current.zoom) * newZoom;
      const newPanY = midRelY - ((midRelY - pinchStartRef.current.pan.y) / pinchStartRef.current.zoom) * newZoom;

      setZoom(newZoom);
      setPan({ x: newPanX, y: newPanY });
      return;
    }

    // 1-Finger / Pen Canvas Pan
    if (isPanningRef.current && canvasPanStartRef.current && activePointersRef.current.size === 1) {
      setPan({
        x: e.clientX - canvasPanStartRef.current.x,
        y: e.clientY - canvasPanStartRef.current.y,
      });
      return;
    }

    // Node Drag
    if (dragNodeId && nodeDragStartRef.current && containerRef.current) {
      const travel = Math.hypot(
        e.clientX - nodeDragStartRef.current.x,
        e.clientY - nodeDragStartRef.current.y
      );
      if (travel > 6) {
        nodeHasDraggedRef.current = true;
      }
      const rect = containerRef.current.getBoundingClientRect();
      const svgX = (e.clientX - rect.left - pan.x) / zoom;
      const svgY = (e.clientY - rect.top - pan.y) / zoom;

      setNodePositions((prev) => ({
        ...prev,
        [dragNodeId]: { x: svgX, y: svgY },
      }));
    }
  };

  const handleCanvasPointerUp = (e: React.PointerEvent) => {
    activePointersRef.current.delete(e.pointerId);
    if (activePointersRef.current.size < 2) {
      pinchStartRef.current = null;
    }
    if (activePointersRef.current.size === 0) {
      isPanningRef.current = false;
      canvasPanStartRef.current = null;
    }
  };

  // 9. Node Interaction & Tap/Drag Disambiguation
  const handleNodePointerDown = (nodeId: string, e: React.PointerEvent) => {
    e.stopPropagation();
    nodeHasDraggedRef.current = false;
    nodeDragStartRef.current = { x: e.clientX, y: e.clientY };
    setDragNodeId(nodeId);
    e.currentTarget.setPointerCapture?.(e.pointerId);
  };

  const handleNodePointerUp = (nodeId: string) => {
    if (nodeHasDraggedRef.current) {
      // It was a drag: stop here, do not trigger tap or open
      setDragNodeId(null);
      nodeDragStartRef.current = null;
      return;
    }

    setDragNodeId(null);
    nodeDragStartRef.current = null;

    // It was a clean tap!
    const now = Date.now();
    if (lastTapRef.current && lastTapRef.current.id === nodeId && now - lastTapRef.current.time < 350) {
      // Double tap: immediately open board/note
      handleNodeOpen(nodeId);
    } else {
      // Single tap: select node to open Inspector Drawer
      setSelectedNodeId(nodeId);
      lastTapRef.current = { id: nodeId, time: now };
    }
  };

  const handleNodeOpen = (nodeId: string) => {
    const el = parseElementNodeId(nodeId);
    if (el) {
      focusElement(el.boardId, el.elementId);
      onClose();
      return;
    }
    if (boards.some((b) => b.id === nodeId)) {
      setActiveBoard(nodeId);
      onClose();
      return;
    }
    if (folders.some((f) => f.id === nodeId)) {
      revealFolder(nodeId);
      const firstBoard = boards.find((b) => b.folderId === nodeId);
      if (firstBoard) setActiveBoard(firstBoard.id);
      onClose();
      return;
    }
  };

  // Reheat / Jiggle layout to untangle clusters
  const reheatLayout = () => {
    setNodePositions({});
    cachedPositionsRef.current.clear();
    setPhysicsEnabled(true);
  };

  // High-Resolution Export as SVG
  const handleExportSVG = () => {
    if (!svgRef.current) return;
    const svgClone = svgRef.current.cloneNode(true) as SVGSVGElement;
    svgClone.setAttribute("xmlns", "http://www.w3.org/2000/svg");
    const svgData = new XMLSerializer().serializeToString(svgClone);
    const blob = new Blob([svgData], { type: "image/svg+xml;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `pronotes-knowledge-graph-${Date.now()}.svg`;
    link.click();
    URL.revokeObjectURL(url);
  };

  // High-Resolution Export as 2x PNG
  const handleExportPNG = () => {
    if (!svgRef.current || !containerRef.current) return;
    const svgClone = svgRef.current.cloneNode(true) as SVGSVGElement;
    const rect = containerRef.current.getBoundingClientRect();
    const scale = 2;
    const width = rect.width * scale;
    const height = rect.height * scale;

    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    ctx.fillStyle = document.documentElement.classList.contains("dark") ? "#09090b" : "#f8fafc";
    ctx.fillRect(0, 0, width, height);

    const svgData = new XMLSerializer().serializeToString(svgClone);
    const img = new Image();
    const blob = new Blob([svgData], { type: "image/svg+xml;charset=utf-8" });
    const url = URL.createObjectURL(blob);

    img.onload = () => {
      ctx.drawImage(img, 0, 0, width, height);
      URL.revokeObjectURL(url);
      const pngUrl = canvas.toDataURL("image/png");
      const link = document.createElement("a");
      link.href = pngUrl;
      link.download = `pronotes-knowledge-graph-${Date.now()}.png`;
      link.click();
    };
    img.src = url;
  };

  // Node Inspector Data
  const inspectedNode = useMemo(() => {
    if (!selectedNodeId) return null;
    return nodes.find((n) => n.id === selectedNodeId) || null;
  }, [selectedNodeId, nodes]);

  const inspectedInboundEdges = useMemo(() => {
    if (!selectedNodeId) return [];
    return visibleEdges.filter((e) => e.target === selectedNodeId);
  }, [selectedNodeId, visibleEdges]);

  const inspectedOutboundEdges = useMemo(() => {
    if (!selectedNodeId) return [];
    return visibleEdges.filter((e) => e.source === selectedNodeId);
  }, [selectedNodeId, visibleEdges]);

  if (!open) return null;

  return (
    <div
      data-wb-modal
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-md p-3 sm:p-5 select-none animate-in fade-in"
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          onClose();
        }
      }}
    >
      <div
        ref={containerRef}
        style={{ touchAction: "none" }}
        className="relative w-full max-w-7xl h-[92vh] bg-white dark:bg-zinc-900 rounded-2xl shadow-2xl border border-border overflow-hidden flex flex-col"
      >
        {/* Top Header & Toolbar */}
        <div className="flex flex-wrap items-center justify-between gap-3 px-5 py-3.5 border-b border-border bg-white/95 dark:bg-zinc-900/95 backdrop-blur-md z-30">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-primary/10 text-primary">
              <Network size={22} />
            </div>
            <div>
              <div className="flex items-center gap-2.5">
                <h2 className="text-base sm:text-lg font-bold text-foreground">
                  Interactive Knowledge Graph
                </h2>
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-primary/10 text-primary font-semibold tabular-nums">
                  {filteredNodes.length} nodes · {visibleEdges.length} connections
                </span>
              </div>
              <p className="text-[11px] text-muted-foreground hidden sm:block">
                Tap node to inspect • Double-tap to open • Pinch to zoom • Drag to organize
              </p>
            </div>
          </div>

          {/* Center Mode Controls: Global vs Local Neighborhood */}
          <div className="flex items-center gap-1.5 p-1 rounded-xl bg-muted/60 border border-border/60">
            <button
              onClick={() => setGraphMode("global")}
              className={`px-3 py-1 text-xs font-medium rounded-lg transition-all ${
                graphMode === "global"
                  ? "bg-white dark:bg-zinc-800 text-foreground shadow-xs font-semibold"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              Universe
            </button>
            <button
              onClick={() => {
                setGraphMode("local");
                if (!localFocusId && activeBoardId) setLocalFocusId(activeBoardId);
              }}
              className={`px-3 py-1 text-xs font-medium rounded-lg transition-all ${
                graphMode === "local"
                  ? "bg-white dark:bg-zinc-800 text-foreground shadow-xs font-semibold"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              Local Focus
            </button>
            {graphMode === "local" && (
              <div className="flex items-center gap-1 pl-1 border-l border-border">
                {[1, 2, 3].map((d) => (
                  <button
                    key={d}
                    onClick={() => setLocalDepth(d)}
                    className={`px-1.5 py-0.5 text-[11px] rounded ${
                      localDepth === d ? "bg-primary text-primary-foreground font-bold" : "text-muted-foreground"
                    }`}
                  >
                    {d}H
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Right Action Tools: Search, Filter Popover, Export, Close */}
          <div className="flex items-center gap-2">
            {/* Search Input */}
            <div className="relative">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search graph..."
                className="h-8 w-44 sm:w-56 pl-8 text-xs rounded-xl"
              />
              {matchingNodeIds && (
                <span className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[10px] font-bold px-1.5 py-0.2 rounded bg-primary/20 text-primary">
                  {matchingNodeIds.size}
                </span>
              )}
            </div>

            {/* Filter Toggle Menu Button */}
            <div className="relative">
              <Button
                variant={filterMenuOpen ? "secondary" : "outline"}
                size="sm"
                onClick={() => setFilterMenuOpen((v) => !v)}
                className="h-8 gap-1.5 rounded-xl text-xs px-2.5"
                title="Filter elements and nodes"
              >
                <Filter size={14} />
                <span className="hidden md:inline">Filters</span>
              </Button>

              {filterMenuOpen && (
                <div className="absolute right-0 top-10 w-52 p-2.5 bg-white dark:bg-zinc-900 border border-border shadow-2xl rounded-xl z-50 text-xs space-y-2 animate-in fade-in zoom-in-95">
                  <div className="font-semibold text-foreground px-1 pb-1 border-b border-border text-[11px] uppercase tracking-wider">
                    Node Filters
                  </div>
                  <label className="flex items-center justify-between px-1.5 py-1 rounded-md hover:bg-muted cursor-pointer">
                    <span className="flex items-center gap-2">
                      <FolderIcon size={14} className="text-amber-500" /> Folders
                    </span>
                    <input
                      type="checkbox"
                      checked={showFolders}
                      onChange={(e) => setShowFolders(e.target.checked)}
                      className="rounded accent-primary"
                    />
                  </label>
                  <label className="flex items-center justify-between px-1.5 py-1 rounded-md hover:bg-muted cursor-pointer">
                    <span className="flex items-center gap-2">
                      <FileText size={14} className="text-teal-500" /> Note Cards
                    </span>
                    <input
                      type="checkbox"
                      checked={showElements}
                      onChange={(e) => setShowElements(e.target.checked)}
                      className="rounded accent-primary"
                    />
                  </label>
                  <label className="flex items-center justify-between px-1.5 py-1 rounded-md hover:bg-muted cursor-pointer">
                    <span className="flex items-center gap-2">
                      <TagIcon size={14} className="text-emerald-500" /> Tags (#tag)
                    </span>
                    <input
                      type="checkbox"
                      checked={showTags}
                      onChange={(e) => setShowTags(e.target.checked)}
                      className="rounded accent-primary"
                    />
                  </label>
                  <label className="flex items-center justify-between px-1.5 py-1 rounded-md hover:bg-muted cursor-pointer">
                    <span className="flex items-center gap-2">
                      <Layers size={14} className="text-zinc-400" /> Orphan Notes
                    </span>
                    <input
                      type="checkbox"
                      checked={showOrphans}
                      onChange={(e) => setShowOrphans(e.target.checked)}
                      className="rounded accent-primary"
                    />
                  </label>
                </div>
              )}
            </div>

            {/* Export Dropdown */}
            <Button
              variant="outline"
              size="sm"
              onClick={handleExportPNG}
              className="h-8 gap-1 rounded-xl text-xs px-2.5"
              title="Export high-resolution graph image"
            >
              <Download size={14} />
              <span className="hidden sm:inline">PNG</span>
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={handleExportSVG}
              className="h-8 gap-1 rounded-xl text-xs px-2.5 hidden md:flex"
              title="Export scalable vector graphics"
            >
              <Download size={14} />
              <span>SVG</span>
            </Button>

            {/* Close Button */}
            <Button variant="ghost" size="icon" onClick={onClose} className="h-8 w-8 rounded-xl">
              <X size={18} />
            </Button>
          </div>
        </div>

        {/* SVG Canvas Area */}
        <div
          id="graph-canvas"
          style={{ touchAction: "none" }}
          onPointerDown={handleCanvasPointerDown}
          onPointerMove={handleCanvasPointerMove}
          onPointerUp={handleCanvasPointerUp}
          onPointerCancel={handleCanvasPointerUp}
          className="flex-1 w-full h-full relative overflow-hidden bg-slate-50/70 dark:bg-zinc-950/70 cursor-grab active:cursor-grabbing"
        >
          <svg
            ref={svgRef}
            style={{ touchAction: "none" }}
            className="w-full h-full"
          >
            <rect id="graph-background" width="100%" height="100%" fill="transparent" />

            <g transform={`translate(${pan.x}, ${pan.y}) scale(${zoom})`}>
              {/* Edges */}
              {visibleEdges.map((edge) => {
                const a = filteredNodes.find((n) => n.id === edge.source);
                const b = filteredNodes.find((n) => n.id === edge.target);
                if (!a || !b) return null;

                const isParent = edge.kind === "parent";
                const isTagEdge = edge.kind === "tag";
                const isHighlighted =
                  hoveredNode === a.id ||
                  hoveredNode === b.id ||
                  selectedNodeId === a.id ||
                  selectedNodeId === b.id;

                const isSearchDimmed =
                  matchingNodeIds !== null &&
                  !matchingNodeIds.has(a.id) &&
                  !matchingNodeIds.has(b.id);

                const edgeColor = edge.color || (isTagEdge ? "#10b981" : isParent ? "#9ca3af" : "#6366f1");

                const radiusA = (a.kind === "element" ? 7 : a.kind === "tag" ? 9 : 9) + Math.min(16, a.degree * 2.5);
                const radiusB = (b.kind === "element" ? 7 : b.kind === "tag" ? 9 : 9) + Math.min(16, b.degree * 2.5);
                const angle = Math.atan2(b.y - a.y, b.x - a.x);

                const startX = a.x + Math.cos(angle) * radiusA;
                const startY = a.y + Math.sin(angle) * radiusA;
                const endX = b.x - Math.cos(angle) * radiusB;
                const endY = b.y - Math.sin(angle) * radiusB;

                const midX = (startX + endX) / 2;
                const midY = (startY + endY) / 2;

                const arrowSize = isParent ? 6 : isTagEdge ? 7 : 9;
                const back1X = endX - Math.cos(angle - 0.38) * arrowSize;
                const back1Y = endY - Math.sin(angle - 0.38) * arrowSize;
                const back2X = endX - Math.cos(angle + 0.38) * arrowSize;
                const back2Y = endY - Math.sin(angle + 0.38) * arrowSize;

                return (
                  <g key={edge.id} opacity={isSearchDimmed ? 0.12 : 1}>
                    <line
                      x1={startX}
                      y1={startY}
                      x2={endX}
                      y2={endY}
                      stroke={isHighlighted ? "#6366f1" : edgeColor}
                      strokeWidth={isHighlighted ? 3 : isParent ? 1.4 : isTagEdge ? 1.6 : 2}
                      strokeDasharray={isParent ? "5,4" : isTagEdge ? "3,3" : undefined}
                      opacity={isHighlighted ? 1 : 0.75}
                    />
                    <polygon
                      points={`${endX},${endY} ${back1X},${back1Y} ${back2X},${back2Y}`}
                      fill={isHighlighted ? "#6366f1" : edgeColor}
                      opacity={isHighlighted ? 1 : 0.85}
                    />
                    {edge.label && !isParent && zoom > 0.65 && (
                      <g transform={`translate(${midX}, ${midY})`}>
                        <rect
                          x={-(edge.label.length * 3.4 + 7)}
                          y={-8.5}
                          width={edge.label.length * 6.8 + 14}
                          height={17}
                          rx={8.5}
                          fill="white"
                          className="dark:fill-zinc-900 shadow-xs"
                          stroke={edgeColor}
                          strokeWidth={1}
                        />
                        <text
                          textAnchor="middle"
                          y={3.5}
                          fontSize={9}
                          fontWeight={600}
                          fill={edgeColor}
                          style={{ pointerEvents: "none", userSelect: "none" }}
                        >
                          {edge.label}
                        </text>
                      </g>
                    )}
                  </g>
                );
              })}

              {/* Nodes */}
              {filteredNodes.map((node) => {
                const isActive = node.id === activeBoardId;
                const isSelected = selectedNodeId === node.id;
                const isHovered = hoveredNode === node.id;
                const isFolder = node.kind === "folder";
                const isTag = node.kind === "tag";
                const isElement = node.kind === "element";

                const isDirectMatch = matchingNodeIds?.has(node.id);
                const isDimmed = matchingNodeIds !== null && !highlightedNodeIds?.has(node.id);

                const radius = (isElement ? 7 : isTag ? 8 : 10) + Math.min(isElement ? 8 : 18, node.degree * 2.5);

                const fill = isTag
                  ? "#10b981"
                  : isElement
                  ? "#14b8a6"
                  : isFolder
                  ? node.color || "#f59e0b"
                  : isActive
                  ? "#6366f1"
                  : node.starred
                  ? "#f59e0b"
                  : node.orphan
                  ? "#94a3b8"
                  : node.color || "#3b82f6";

                return (
                  <g
                    key={node.id}
                    transform={`translate(${node.x}, ${node.y})`}
                    opacity={isDimmed ? 0.2 : 1}
                    style={{ cursor: "pointer", touchAction: "none" }}
                    onPointerDown={(e) => handleNodePointerDown(node.id, e)}
                    onPointerUp={() => handleNodePointerUp(node.id)}
                    onPointerEnter={(e) => {
                      if (e.pointerType === "pen" || e.pointerType === "mouse") {
                        setHoveredNode(node.id);
                        setHoverAnchor({ x: node.x, y: node.y });
                      }
                    }}
                    onPointerLeave={(e) => {
                      if (e.pointerType === "pen" || e.pointerType === "mouse") {
                        if (hoveredNode === node.id) setHoveredNode(null);
                      }
                    }}
                  >
                    {/* Search match illuminated halo */}
                    {isDirectMatch && (
                      <circle
                        r={radius + 8}
                        fill="none"
                        stroke="#ec4899"
                        strokeWidth={3}
                        className="animate-pulse"
                      />
                    )}

                    {/* Node Geometry */}
                    {isTag ? (
                      <g
                        fill={fill}
                        stroke={isSelected ? "#ec4899" : isActive ? "#4338ca" : "white"}
                        strokeWidth={isSelected ? 3.5 : 2}
                        style={{
                          filter: isHovered || isSelected
                            ? "drop-shadow(0 0 12px rgba(16,185,129,0.75))"
                            : "drop-shadow(0 2px 4px rgba(0,0,0,0.15))",
                          transition: "filter 0.15s",
                        }}
                      >
                        {elementNodeShape("tag", radius * 0.9)}
                      </g>
                    ) : isElement ? (
                      <g
                        fill={fill}
                        stroke={isSelected ? "#ec4899" : isActive ? "#4338ca" : "white"}
                        strokeWidth={node.elementType === "stroke" ? 2.5 : isSelected ? 3.5 : 2}
                        style={{
                          filter: isHovered || isSelected
                            ? "drop-shadow(0 0 12px rgba(99,102,241,0.7))"
                            : "drop-shadow(0 2px 4px rgba(0,0,0,0.15))",
                          transition: "filter 0.15s",
                        }}
                      >
                        {elementNodeShape(node.elementType, radius * 0.82)}
                      </g>
                    ) : isFolder ? (
                      <rect
                        x={-radius}
                        y={-radius}
                        width={radius * 2}
                        height={radius * 2}
                        rx={6}
                        fill={fill}
                        stroke={isSelected ? "#ec4899" : isActive ? "#4338ca" : "white"}
                        strokeWidth={isSelected || isActive ? 3.5 : 2}
                        style={{
                          filter: isHovered || isSelected
                            ? "drop-shadow(0 0 12px rgba(245,158,11,0.7))"
                            : "drop-shadow(0 2px 4px rgba(0,0,0,0.15))",
                          transition: "filter 0.15s",
                        }}
                      />
                    ) : (
                      <circle
                        r={radius}
                        fill={fill}
                        stroke={isSelected ? "#ec4899" : isActive ? "#4338ca" : "white"}
                        strokeWidth={isSelected || isActive ? 3.5 : 2}
                        style={{
                          filter: isHovered || isSelected
                            ? "drop-shadow(0 0 12px rgba(99,102,241,0.7))"
                            : "drop-shadow(0 2px 4px rgba(0,0,0,0.15))",
                          transition: "filter 0.15s",
                        }}
                      />
                    )}

                    {/* Starred badge */}
                    {node.starred && (
                      <Star
                        size={11}
                        className="text-white fill-white absolute"
                        style={{ transform: "translate(-50%, -50%)" }}
                      />
                    )}

                    {/* Pinned badge */}
                    {node.isPinned && (
                      <Pin
                        size={10}
                        className="text-white fill-white absolute"
                        style={{ transform: "translate(-50%, -50%)" }}
                      />
                    )}

                    {/* Node Text Label */}
                    <text
                      y={radius + 14}
                      textAnchor="middle"
                      fontSize={11.5}
                      className="fill-zinc-900 dark:fill-zinc-100"
                      fontWeight={isActive || isHovered || isSelected ? 700 : 500}
                      style={{ pointerEvents: "none", userSelect: "none" }}
                    >
                      {node.name.length > 24 ? node.name.slice(0, 22) + "…" : node.name}
                    </text>
                  </g>
                );
              })}
            </g>
          </svg>

          {/* S Pen Stylus Hover Peek Card */}
          {hoveredNode && hoverAnchor && (
            <div
              className="absolute pointer-events-none z-40 bg-white/95 dark:bg-zinc-900/95 backdrop-blur-md rounded-xl border border-border p-3 shadow-2xl text-xs max-w-xs animate-in fade-in"
              style={{
                left: Math.min(dims.width - 240, Math.max(20, hoverAnchor.x * zoom + pan.x + 20)),
                top: Math.min(dims.height - 140, Math.max(20, hoverAnchor.y * zoom + pan.y - 40)),
              }}
            >
              {(() => {
                const n = filteredNodes.find((x) => x.id === hoveredNode);
                if (!n) return null;
                return (
                  <div className="space-y-1.5">
                    <div className="flex items-center gap-1.5">
                      <span className="text-[10px] uppercase font-bold px-1.5 py-0.5 rounded bg-primary/10 text-primary">
                        {n.kind}
                      </span>
                      <span className="font-bold text-foreground truncate">{n.name}</span>
                    </div>
                    {n.snippet && (
                      <div className="text-[11px] text-muted-foreground line-clamp-2">
                        {n.snippet}
                      </div>
                    )}
                    <div className="text-[10px] text-muted-foreground pt-1 border-t border-border flex items-center justify-between">
                      <span>{n.degree} connections</span>
                      {n.folderName && <span>📁 {n.folderName}</span>}
                    </div>
                  </div>
                );
              })()}
            </div>
          )}

          {/* Floating Radar Minimap (Bottom-Left) */}
          <div className="absolute bottom-5 left-5 hidden sm:block p-1.5 bg-white/90 dark:bg-zinc-900/90 backdrop-blur-md shadow-xl border border-border rounded-xl z-20">
            <div className="text-[10px] font-bold text-muted-foreground px-1 pb-1 flex items-center justify-between">
              <span>Radar</span>
              <span className="text-[9px] font-mono">{Math.round(zoom * 100)}%</span>
            </div>
            <svg
              width={120}
              height={80}
              className="rounded-lg bg-slate-100 dark:bg-zinc-950 border border-border/50 cursor-pointer"
              onClick={(e) => {
                const rect = e.currentTarget.getBoundingClientRect();
                const clickNormX = (e.clientX - rect.left) / rect.width;
                const clickNormY = (e.clientY - rect.top) / rect.height;
                setPan({
                  x: dims.width / 2 - clickNormX * dims.width * zoom,
                  y: dims.height / 2 - clickNormY * dims.height * zoom,
                });
              }}
            >
              {filteredNodes.map((n) => {
                const mx = (n.x / Math.max(1, dims.width)) * 120;
                const my = (n.y / Math.max(1, dims.height)) * 80;
                return (
                  <circle
                    key={n.id}
                    cx={Math.max(3, Math.min(117, mx))}
                    cy={Math.max(3, Math.min(77, my))}
                    r={2}
                    fill={n.id === selectedNodeId ? "#ec4899" : n.color || "#6366f1"}
                  />
                );
              })}
              {/* Viewport indicator box */}
              {(() => {
                const vx = (-pan.x / (dims.width * zoom)) * 120;
                const vy = (-pan.y / (dims.height * zoom)) * 80;
                const vw = (1 / zoom) * 120;
                const vh = (1 / zoom) * 80;
                return (
                  <rect
                    x={Math.max(0, vx)}
                    y={Math.max(0, vy)}
                    width={Math.min(120, vw)}
                    height={Math.min(80, vh)}
                    fill="rgba(99, 102, 241, 0.15)"
                    stroke="#6366f1"
                    strokeWidth={1}
                    rx={2}
                  />
                );
              })()}
            </svg>
          </div>

          {/* Floating Navigation & Physics Controls (Bottom-Right) */}
          <div className="absolute bottom-5 right-5 flex items-center gap-1.5 p-1.5 bg-white/95 dark:bg-zinc-900/95 backdrop-blur-md shadow-xl border border-border rounded-xl z-20">
            <button
              onClick={() => setPhysicsEnabled((v) => !v)}
              className={`p-1.5 rounded-lg transition-colors ${
                physicsEnabled
                  ? "bg-primary/10 text-primary font-bold"
                  : "text-muted-foreground hover:bg-muted"
              }`}
              title={physicsEnabled ? "Pause physics" : "Enable physics"}
            >
              {physicsEnabled ? <Pause size={15} /> : <Play size={15} />}
            </button>
            <button
              onClick={reheatLayout}
              className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground hover:text-foreground"
              title="Reheat and jiggle layout"
            >
              <Sparkles size={15} />
            </button>
            <div className="w-px h-4 bg-border mx-0.5" />
            <button
              onClick={() => setZoom((z) => Math.max(0.25, z * 0.85))}
              className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground hover:text-foreground"
              title="Zoom out"
            >
              <ZoomOut size={15} />
            </button>
            <span className="text-xs font-semibold px-1.5 tabular-nums min-w-[42px] text-center">
              {Math.round(zoom * 100)}%
            </span>
            <button
              onClick={() => setZoom((z) => Math.min(3.5, z * 1.15))}
              className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground hover:text-foreground"
              title="Zoom in"
            >
              <ZoomIn size={15} />
            </button>
            <div className="w-px h-4 bg-border mx-0.5" />
            <button
              onClick={fitToView}
              className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground hover:text-foreground"
              title="Fit to view (Zoom to extents)"
            >
              <Maximize2 size={15} />
            </button>
            <button
              onClick={() => {
                setZoom(1);
                setPan({ x: 0, y: 0 });
                setNodePositions({});
              }}
              className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground hover:text-foreground"
              title="Reset camera"
            >
              <RotateCcw size={15} />
            </button>
          </div>
        </div>

        {/* Node Inspector Drawer (Slide-out Right Panel) */}
        {inspectedNode && (
          <div className="absolute top-14 right-4 bottom-4 w-80 bg-white/95 dark:bg-zinc-900/95 backdrop-blur-md rounded-2xl shadow-2xl border border-border p-4 flex flex-col z-40 animate-in slide-in-from-right-4 duration-200">
            <div className="flex items-center justify-between pb-3 border-b border-border">
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded-full bg-primary/10 text-primary">
                  {inspectedNode.kind}
                </span>
                {inspectedNode.folderName && (
                  <span className="text-xs text-muted-foreground truncate max-w-[140px]">
                    📁 {inspectedNode.folderName}
                  </span>
                )}
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setSelectedNodeId(null)}
                className="h-7 w-7 rounded-lg"
              >
                <X size={15} />
              </Button>
            </div>

            <div className="flex-1 overflow-y-auto py-3 space-y-3.5 pr-1 text-xs">
              <div>
                <h3 className="text-base font-bold text-foreground leading-snug">
                  {inspectedNode.name}
                </h3>
                <div className="text-[11px] text-muted-foreground mt-0.5">
                  {inspectedNode.degree} active connections
                </div>
              </div>

              {/* Snippet Preview */}
              {inspectedNode.snippet && (
                <div className="p-3 rounded-xl bg-muted/50 border border-border/80 font-mono text-[11px] text-foreground/90 leading-relaxed max-h-28 overflow-y-auto">
                  {inspectedNode.snippet}
                </div>
              )}

              {/* Tags Badges */}
              {inspectedNode.tags && inspectedNode.tags.length > 0 && (
                <div>
                  <div className="text-[11px] font-semibold text-muted-foreground mb-1.5 flex items-center gap-1">
                    <Hash size={12} /> Tags
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {inspectedNode.tags.map((tag) => (
                      <span
                        key={tag}
                        onClick={() => setSearchQuery(tag)}
                        className="px-2 py-0.5 rounded-md bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-semibold text-[10px] cursor-pointer hover:bg-emerald-500/20"
                      >
                        #{tag}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Inbound Backlinks */}
              <div>
                <div className="text-[11px] font-semibold text-muted-foreground mb-1 flex items-center gap-1">
                  <ArrowDownLeft size={13} className="text-indigo-500" /> Incoming Backlinks ({inspectedInboundEdges.length})
                </div>
                {inspectedInboundEdges.length === 0 ? (
                  <div className="text-[11px] text-muted-foreground italic pl-1">No incoming links</div>
                ) : (
                  <div className="space-y-1">
                    {inspectedInboundEdges.map((e) => {
                      const src = nodes.find((n) => n.id === e.source);
                      if (!src) return null;
                      return (
                        <button
                          key={e.id}
                          onClick={() => setSelectedNodeId(src.id)}
                          className="w-full text-left p-1.5 rounded-lg hover:bg-muted flex items-center justify-between text-[11px] transition-colors"
                        >
                          <span className="font-medium text-foreground truncate">{src.name}</span>
                          <span className="text-[10px] text-muted-foreground">{e.label || "link"}</span>
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Outbound Connections */}
              <div>
                <div className="text-[11px] font-semibold text-muted-foreground mb-1 flex items-center gap-1">
                  <ArrowUpRight size={13} className="text-teal-500" /> Outgoing Links ({inspectedOutboundEdges.length})
                </div>
                {inspectedOutboundEdges.length === 0 ? (
                  <div className="text-[11px] text-muted-foreground italic pl-1">No outgoing links</div>
                ) : (
                  <div className="space-y-1">
                    {inspectedOutboundEdges.map((e) => {
                      const tgt = nodes.find((n) => n.id === e.target);
                      if (!tgt) return null;
                      return (
                        <button
                          key={e.id}
                          onClick={() => setSelectedNodeId(tgt.id)}
                          className="w-full text-left p-1.5 rounded-lg hover:bg-muted flex items-center justify-between text-[11px] transition-colors"
                        >
                          <span className="font-medium text-foreground truncate">{tgt.name}</span>
                          <span className="text-[10px] px-1.5 py-0.2 rounded bg-primary/10 text-primary font-semibold">
                            {e.label || e.linkType || "leads to"}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>

            {/* Bottom Actions */}
            <div className="pt-3 border-t border-border space-y-2">
              <Button
                size="sm"
                className="w-full gap-2 rounded-xl text-xs font-semibold"
                onClick={() => handleNodeOpen(inspectedNode.id)}
              >
                <ExternalLink size={14} /> Open Note / Board
              </Button>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  className="flex-1 gap-1.5 rounded-xl text-xs"
                  onClick={() => {
                    setLocalFocusId(inspectedNode.id);
                    setGraphMode("local");
                  }}
                >
                  <Compass size={13} /> Focus Here
                </Button>
                <Button
                  variant={inspectedNode.isPinned ? "secondary" : "outline"}
                  size="sm"
                  className="gap-1.5 rounded-xl text-xs px-3"
                  onClick={() => {
                    setPinnedNodeIds((prev) => {
                      const next = new Set(prev);
                      if (next.has(inspectedNode.id)) {
                        next.delete(inspectedNode.id);
                      } else {
                        next.add(inspectedNode.id);
                      }
                      return next;
                    });
                  }}
                  title={inspectedNode.isPinned ? "Unpin position" : "Pin position"}
                >
                  <Pin size={13} className={inspectedNode.isPinned ? "fill-primary text-primary" : ""} />
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
