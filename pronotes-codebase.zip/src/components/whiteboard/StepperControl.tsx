"use client";

/**
 * −/+ steppers for numeric sliders
 * ================================
 * Dragging a slider is good for getting roughly where you want and bad for
 * landing on an exact value — especially with a finger on a tablet, where the
 * thumb is under the fingertip you are trying to aim with. Every numeric
 * slider in the app therefore gets a −/+ pair around it.
 *
 * Holding a button repeats. Tapping + seventeen times to walk 7px → 24px is
 * the problem the buttons were added to solve, so they must not recreate it.
 */

import React from "react";
import { Minus, Plus } from "lucide-react";
import { cn } from "@/lib/utils";

const HOLD_DELAY_MS = 400;
const HOLD_REPEAT_MS = 60;

export interface StepperProps {
  value: number;
  min: number;
  max: number;
  /** How much one press moves the value. Match the slider's own step. */
  step?: number;
  onChange: (next: number) => void;
  /**
   * Called once when a press (or a hold) ends, for controls that batch into
   * one undo entry rather than one per tick.
   */
  onCommit?: () => void;
}

function clamp(v: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, v));
}

export function StepButton({
  direction,
  value,
  min,
  max,
  step = 1,
  onChange,
  onCommit,
  className,
}: StepperProps & { direction: -1 | 1; className?: string }) {
  const disabled = direction < 0 ? value <= min : value >= max;

  // The repeat timer closes over the render that started the hold, so without
  // this it would keep re-applying the step to the value as it was on press —
  // holding + would move you exactly one step and then stall.
  const latest = React.useRef({ value, onChange, onCommit });
  React.useEffect(() => {
    latest.current = { value, onChange, onCommit };
  });

  const delayRef = React.useRef<ReturnType<typeof setTimeout> | null>(null);
  const repeatRef = React.useRef<ReturnType<typeof setInterval> | null>(null);
  const activeRef = React.useRef(false);

  const stop = React.useCallback(() => {
    if (delayRef.current) clearTimeout(delayRef.current);
    if (repeatRef.current) clearInterval(repeatRef.current);
    delayRef.current = null;
    repeatRef.current = null;
    if (activeRef.current) {
      activeRef.current = false;
      latest.current.onCommit?.();
    }
  }, []);

  React.useEffect(() => stop, [stop]);

  // Reaching min/max mid-hold disables the button, and a disabled button gets
  // no pointerup — the timer would otherwise run forever against the clamp.
  React.useEffect(() => {
    if (disabled) stop();
  }, [disabled, stop]);

  const apply = React.useCallback(() => {
    const { value: v, onChange: set } = latest.current;
    const next = clamp(v + direction * step, min, max);
    if (next !== v) set(next);
  }, [direction, step, min, max]);

  const begin = React.useCallback(() => {
    activeRef.current = true;
    apply();
    delayRef.current = setTimeout(() => {
      repeatRef.current = setInterval(apply, HOLD_REPEAT_MS);
    }, HOLD_DELAY_MS);
  }, [apply]);

  return (
    <button
      type="button"
      disabled={disabled}
      onPointerDown={(e) => {
        if (e.button !== 0) return;
        // Keeps the press from stealing focus or starting a text selection,
        // which on touch would turn a hold into a text-selection gesture.
        e.preventDefault();
        begin();
      }}
      onPointerUp={stop}
      onPointerLeave={stop}
      onPointerCancel={stop}
      // preventDefault above suppresses the synthetic click, and pointer events
      // never fire for keyboard activation, so the keyboard is handled here.
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          apply();
          latest.current.onCommit?.();
        }
      }}
      aria-label={direction < 0 ? "Decrease" : "Increase"}
      title={direction < 0 ? "Decrease (hold to repeat)" : "Increase (hold to repeat)"}
      className={cn(
        "flex h-7 w-7 shrink-0 touch-none select-none items-center justify-center rounded-lg",
        "border border-border text-muted-foreground transition-colors",
        "hover:bg-muted hover:text-foreground active:bg-muted active:scale-95",
        "disabled:pointer-events-none disabled:opacity-40",
        className
      )}
    >
      {direction < 0 ? <Minus size={13} /> : <Plus size={13} />}
    </button>
  );
}

/**
 * Wraps a slider as `[−] slider [+]`. The slider keeps its own markup and
 * styling; this only adds the buttons and the row that holds them.
 */
export function StepperRow({
  children,
  className,
  ...stepper
}: StepperProps & { children: React.ReactNode; className?: string }) {
  return (
    <div className={cn("flex items-center gap-2", className)}>
      <StepButton direction={-1} {...stepper} />
      {children}
      <StepButton direction={1} {...stepper} />
    </div>
  );
}
