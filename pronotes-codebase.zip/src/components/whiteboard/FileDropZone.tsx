"use client";

/**
 * Drop files onto the app
 * =======================
 * Drop a PDF and it opens as a notebook you can write on, pages running down
 * the canvas. Drop images and they become pages in the notebook you have open.
 *
 * The listeners are on `window`, not on a drop target, for a reason that bites
 * hard in a desktop build: Chromium's DEFAULT action for a dropped file is to
 * navigate to it. Inside Electron that replaces the whole app with a file
 * viewer and there is no back button — the user's session is simply gone. So
 * dragover and drop are cancelled globally, and only then routed.
 */

import React from "react";
import { FileText, ImagePlus, Loader2 } from "lucide-react";
import { useWhiteboard, useActiveBoard } from "@/store/whiteboard";
import { isNotebook } from "@/lib/whiteboard/notebook";
import { storeImage } from "@/lib/whiteboard/imagestore";
import { officeKindOf } from "@/lib/whiteboard/officeImport";
import { cn } from "@/lib/utils";

function isPdf(file: File): boolean {
  return file.type === "application/pdf" || /\.pdf$/i.test(file.name);
}

/** Word / PowerPoint (and the old .doc/.ppt, which get a clear message). */
function isOffice(file: File): boolean {
  return officeKindOf(file) !== null;
}

function isImage(file: File): boolean {
  return file.type.startsWith("image/") || /\.(png|jpe?g|gif|webp|bmp|svg)$/i.test(file.name);
}

/**
 * Reads an image, measures it, and puts the pixels in IndexedDB.
 *
 * Measuring keeps pages fitted rather than stretched. Storing keeps the bytes
 * out of the workspace: a single image was measured at 908 KB against a ~5 MB
 * localStorage budget, so dropping a handful of photos would fill it, and the
 * over-quota fallback discards image data permanently.
 */
/**
 * Imports picture files into a notebook living in `folderId`, reusing the
 * drop path: pictures become pages of a fresh notebook that opens at once.
 * Shared by the drop zone and the sidebar's "Import here" menu — one path,
 * not two.
 */
export async function importPicturesAsNotebook(files: File[], folderId: string | null): Promise<void> {
  const images = files.filter(isImage);
  if (images.length === 0) {
    throw new Error(
      files.length === 1 ? `"${files[0].name}" is not a picture.` : "Those files are not pictures."
    );
  }
  const api = useWhiteboard.getState();
  const measured = await Promise.all(images.map(readImage));
  const id = api.createNotebook("Imported pictures", folderId);
  api.setActiveBoard(id);
  useWhiteboard.getState().addImagePages(measured);
}

function readImage(file: File): Promise<{ src: string; width: number; height: number }> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = String(reader.result);
      const img = new Image();
      img.onload = () => {
        storeImage(dataUrl).then((src) =>
          resolve({ src, width: img.naturalWidth, height: img.naturalHeight })
        );
      };
      img.onerror = () => reject(new Error(`Could not read the image "${file.name}".`));
      img.src = dataUrl;
    };
    reader.onerror = () => reject(new Error(`Could not read "${file.name}".`));
    reader.readAsDataURL(file);
  });
}

export function FileDropZone() {
  const importPdfAsNotebook = useWhiteboard((s) => s.importPdfAsNotebook);
  const addImagePages = useWhiteboard((s) => s.addImagePages);
  const createNotebook = useWhiteboard((s) => s.createNotebook);
  const activeBoard = useActiveBoard();

  const [dragging, setDragging] = React.useState(false);
  const [busy, setBusy] = React.useState<string | null>(null);
  const [error, setError] = React.useState<string | null>(null);

  // dragenter/dragleave fire for every element the cursor crosses, so a naive
  // boolean flickers the overlay while you move across the page. Counting
  // enters against leaves is the standard fix.
  const depth = React.useRef(0);

  // Kept in a ref so the window listeners, registered once, never act on a
  // stale board.
  const latest = React.useRef({ activeBoard, importPdfAsNotebook, addImagePages, createNotebook });
  React.useEffect(() => {
    latest.current = { activeBoard, importPdfAsNotebook, addImagePages, createNotebook };
  });

  /**
   * Opens files the way a drop does: each PDF becomes a notebook, pictures
   * become pages. Used by drag-and-drop AND by files other apps send us
   * ("Open with" / "Share" on Android - see MainActivity.handleIncoming).
   */
  const openFilesRef = React.useRef<(files: File[]) => Promise<void>>(async () => {});
  openFilesRef.current = async (files: File[]) => {
    if (files.length === 0) return;
    setError(null);
    // PDFs, Word and PowerPoint files each become their own notebook -
    // merging two documents into one would be impossible to undo without
    // deleting pages by hand.
    const pdfs = files.filter((f) => isPdf(f) || isOffice(f));
    const images = files.filter((f) => !isPdf(f) && !isOffice(f) && isImage(f));
    const ignored = files.filter((f) => !isPdf(f) && !isOffice(f) && !isImage(f));
    const problems: string[] = [];
    try {
      for (const file of pdfs) {
        setBusy(`Opening ${file.name}…`);
        try {
          await useWhiteboard.getState().importDocumentAsNotebook(file, null, (p) =>
            setBusy(`${file.name}: ${p.label}`)
          );
        } catch (err) {
          // One bad file must not stop the others that came with it.
          problems.push((err as Error).message || `Could not open "${file.name}".`);
        }
      }
      if (images.length > 0) {
        setBusy(images.length === 1 ? "Adding image…" : `Adding ${images.length} images…`);
        const measured = await Promise.all(images.map(readImage));
        // Images need somewhere paged to go. If the open document is a
        // canvas (or a PDF notebook was just made), start a notebook for
        // them rather than silently doing nothing.
        const board = useWhiteboard.getState().boards.find(
          (b) => b.id === useWhiteboard.getState().activeBoardId
        );
        if (!board || !isNotebook(board)) {
          useWhiteboard.getState().createNotebook("Dropped images", null);
        }
        useWhiteboard.getState().addImagePages(measured);
      }
      if (ignored.length > 0 && pdfs.length === 0 && images.length === 0) {
        setError(
          ignored.length === 1
            ? `"${ignored[0].name}" can't be opened: ProNotes opens PDF, Word, PowerPoint and pictures.`
            : "Those files can't be opened: ProNotes opens PDF, Word, PowerPoint and pictures."
        );
      } else if (problems.length) {
        setError(problems[0]);
      }
    } catch (err) {
      // Import fails for real reasons — an encrypted PDF, a corrupt file, no
      // storage left. Silence would be indistinguishable from a slow import.
      setError((err as Error).message || "Could not open that file.");
    } finally {
      setBusy(null);
    }
  };

  // Files from other apps. The Android side copies each into the app's cache
  // and calls this with its path (retrying until it exists); the bytes come
  // back through Capacitor's local file server. Registered only once the
  // workspace has loaded, so an import can't be overwritten by the load.
  const isReady = useWhiteboard((s) => s.isReady);
  React.useEffect(() => {
    if (!isReady || typeof window === "undefined") return;
    type Incoming = { path?: string; name?: string; type?: string; error?: string };
    const w = window as unknown as { __pronotesReceiveFiles?: (items: Incoming[]) => void };
    w.__pronotesReceiveFiles = (items: Incoming[]) => {
      void (async () => {
        const files: File[] = [];
        const problems: string[] = [];
        for (const it of items) {
          if (it.error || !it.path) {
            problems.push(it.error || "A file could not be read.");
            continue;
          }
          try {
            setBusy(`Opening ${it.name ?? "file"}…`);
            const { Capacitor } = await import("@capacitor/core");
            const res = await fetch(Capacitor.convertFileSrc(it.path));
            if (!res.ok) throw new Error(`HTTP ${res.status}`);
            const blob = await res.blob();
            const name = it.name || "Shared file";
            const type = it.type || blob.type || (/\.pdf$/i.test(name) ? "application/pdf" : "");
            files.push(new File([blob], name, { type }));
          } catch (err) {
            problems.push(`Could not open "${it.name ?? "the file"}": ${(err as Error).message}`);
          }
        }
        setBusy(null);
        await openFilesRef.current(files);
        if (problems.length) setError(problems[0]);
      })();
    };
    return () => {
      delete w.__pronotesReceiveFiles;
    };
  }, [isReady]);

  React.useEffect(() => {
    const hasFiles = (e: DragEvent) =>
      Array.from(e.dataTransfer?.types ?? []).includes("Files");

    const onDragEnter = (e: DragEvent) => {
      if (!hasFiles(e)) return;
      e.preventDefault();
      depth.current += 1;
      setDragging(true);
    };

    const onDragOver = (e: DragEvent) => {
      if (!hasFiles(e)) return;
      // Without this the drop never fires and Chromium navigates to the file,
      // which in the desktop build throws the whole app away.
      e.preventDefault();
      if (e.dataTransfer) e.dataTransfer.dropEffect = "copy";
    };

    const onDragLeave = (e: DragEvent) => {
      if (!hasFiles(e)) return;
      depth.current = Math.max(0, depth.current - 1);
      if (depth.current === 0) setDragging(false);
    };

    const onDrop = async (e: DragEvent) => {
      if (!hasFiles(e)) return;
      e.preventDefault();
      depth.current = 0;
      setDragging(false);
      setError(null);

      const files = Array.from(e.dataTransfer?.files ?? []);
      await openFilesRef.current(files);
    };

    window.addEventListener("dragenter", onDragEnter);
    window.addEventListener("dragover", onDragOver);
    window.addEventListener("dragleave", onDragLeave);
    window.addEventListener("drop", onDrop);
    return () => {
      window.removeEventListener("dragenter", onDragEnter);
      window.removeEventListener("dragover", onDragOver);
      window.removeEventListener("dragleave", onDragLeave);
      window.removeEventListener("drop", onDrop);
    };
  }, []);

  // Dismiss an error on the next interaction rather than making the user aim
  // at a close button.
  React.useEffect(() => {
    if (!error) return;
    const clear = () => setError(null);
    const t = setTimeout(clear, 8000);
    window.addEventListener("pointerdown", clear, { once: true });
    return () => {
      clearTimeout(t);
      window.removeEventListener("pointerdown", clear);
    };
  }, [error]);

  const notebookOpen = isNotebook(activeBoard);

  return (
    <>
      {dragging && (
        <div className="pointer-events-none fixed inset-0 z-[95] flex items-center justify-center bg-primary/10 backdrop-blur-[2px]">
          <div className="flex flex-col items-center gap-3 rounded-2xl border-2 border-dashed border-primary bg-white/95 px-8 py-6 shadow-2xl dark:bg-zinc-900/95">
            <div className="flex gap-3 text-primary">
              <FileText size={28} />
              <ImagePlus size={28} />
            </div>
            <p className="text-sm font-semibold">Drop to open</p>
            <p className="max-w-[260px] text-center text-[11px] leading-snug text-muted-foreground">
              A <strong>PDF</strong> becomes a notebook you can write on.{" "}
              <strong>Images</strong> become pages
              {notebookOpen ? " in this notebook" : " in a new notebook"}.
            </p>
          </div>
        </div>
      )}

      {(busy || error) && (
        <div
          className={cn(
            "fixed bottom-6 left-1/2 z-[96] flex -translate-x-1/2 items-center gap-2 rounded-xl border px-3 py-2 text-[12px] shadow-lg",
            error
              ? "border-destructive/40 bg-destructive/10 text-destructive"
              : "border-border bg-white/95 text-foreground dark:bg-zinc-900/95"
          )}
          role="status"
        >
          {busy && <Loader2 size={14} className="animate-spin" />}
          <span>{busy ?? error}</span>
        </div>
      )}
    </>
  );
}
