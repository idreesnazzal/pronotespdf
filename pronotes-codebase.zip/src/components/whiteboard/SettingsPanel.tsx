"use client";

/**
 * Settings
 * ========
 * One home for everything that used to be scattered across the toolbar as
 * always-visible toggles. The bottom dock is for TOOLS you reach constantly;
 * anything you set once and forget lives here.
 *
 * This is also the single owner of the theme control — it used to exist twice
 * (header and toolbar), which is why two sun/moon icons were on screen.
 */

import React from "react";
import { useTheme } from "next-themes";
import { useWhiteboard, useActiveBoard } from "@/store/whiteboard";
import {
  BOARD_BACKGROUNDS,
  BOARD_PATTERNS,
  BOARD_PATTERN_DEFAULT_SIZE,
  BOARD_PATTERN_MAX_SIZE,
  BOARD_PATTERN_MIN_SIZE,
  BOARD_PATTERN_SIZE_PRESETS,
  PAGE_SIZES,
} from "@/lib/whiteboard/types";
import type { PageSizeId, TouchInputMode, PressureCurve } from "@/lib/whiteboard/types";
import { isNotebook, pageSizeOf } from "@/lib/whiteboard/notebook";
import {
  Grid,
  HelpCircle,
  Keyboard,
  Layers,
  Map as MapIcon,
  Monitor,
  Moon,
  Pointer,
  Sparkles,
  Star,
  Sun,
  Tag,
  Wand2,
  X,
  ZoomIn,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { StepperRow } from "./StepperControl";
import { cn } from "@/lib/utils";

interface Props {
  open: boolean;
  onClose: () => void;
  legendVisible: boolean;
  onToggleLegend: () => void;
}

/** A labelled on/off row — the repeated shape of most settings here. */
function ToggleRow({
  icon,
  label,
  hint,
  checked,
  onChange,
}: {
  icon: React.ReactNode;
  label: string;
  hint?: string;
  checked: boolean;
  onChange: () => void;
}) {
  return (
    <button
      onClick={onChange}
      role="switch"
      aria-checked={checked}
      className="flex w-full items-center gap-3 rounded-lg px-2 py-2 text-left transition-colors hover:bg-muted"
    >
      <span className="text-muted-foreground">{icon}</span>
      <span className="min-w-0 flex-1">
        <span className="block text-xs font-medium">{label}</span>
        {hint && <span className="block text-[11px] leading-snug text-muted-foreground">{hint}</span>}
      </span>
      <span
        className={cn(
          "relative h-5 w-9 shrink-0 rounded-full transition-colors",
          checked ? "bg-primary" : "bg-muted-foreground/30"
        )}
      >
        <span
          className={cn(
            "absolute top-0.5 h-4 w-4 rounded-full bg-white shadow transition-all",
            checked ? "left-[1.125rem]" : "left-0.5"
          )}
        />
      </span>
    </button>
  );
}

function SectionTitle({ children }: { children: React.ReactNode }) {
  return (
    <h3 className="px-2 pb-1 pt-1 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
      {children}
    </h3>
  );
}

export function SettingsPanel({ open, onClose, legendVisible, onToggleLegend }: Props) {
  const { theme, setTheme, resolvedTheme } = useTheme();
  const activeBoard = useActiveBoard();
  const setBoardBackground = useWhiteboard((s) => s.setBoardBackground);
  const setPageSize = useWhiteboard((s) => s.setPageSize);
  const pageDims = pageSizeOf(activeBoard);
  const paperSize = activeBoard?.background?.size ?? BOARD_PATTERN_DEFAULT_SIZE;

  const minimapOpen = useWhiteboard((s) => s.minimapOpen);
  const toggleMinimap = useWhiteboard((s) => s.toggleMinimap);
  const defaultPaper = useWhiteboard((s) => s.defaultPaper);
  const setDefaultPaper = useWhiteboard((s) => s.setDefaultPaper);
  // Scope for the paper controls below. Off = the notebook default only (new
  // pages start with it); on = every existing page is rewritten too. Always
  // starts off — rewriting history is opt-in per session.
  const [applyAllPages, setApplyAllPages] = React.useState(false);
  const pageScope = { allPages: applyAllPages };
  const snapToGrid = useWhiteboard((s) => s.snapToGrid);
  const toggleSnapToGrid = useWhiteboard((s) => s.toggleSnapToGrid);
  const zoomDockOpen = useWhiteboard((s) => s.zoomDockOpen);
  const toggleZoomDock = useWhiteboard((s) => s.toggleZoomDock);  const pinnedBarOpen = useWhiteboard((s) => s.pinnedBarOpen);
  const togglePinnedBar = useWhiteboard((s) => s.togglePinnedBar);
  const touchSettings = useWhiteboard((s) => s.touchSettings);
  const setTouchSettings = useWhiteboard((s) => s.setTouchSettings);
  const tool = useWhiteboard((s) => s.tool);
  const setTool = useWhiteboard((s) => s.setTool);
  const lassoStrict = useWhiteboard((s) => s.lassoStrict);
  const setLassoStrict = useWhiteboard((s) => s.setLassoStrict);

  if (!open) return null;

  const themes: Array<{ id: string; label: string; icon: React.ReactNode }> = [
    { id: "light", label: "Light", icon: <Sun size={13} /> },
    { id: "dark", label: "Dark", icon: <Moon size={13} /> },
    { id: "system", label: "System", icon: <Monitor size={13} /> },
  ];

  const touchModes: Array<{ id: TouchInputMode; label: string; hint: string }> = [
    { id: "touch-draw", label: "Touch & pen draw", hint: "Fingers and stylus both draw" },
    { id: "stylus-only", label: "Stylus only", hint: "Fingers pan and zoom — palm rejection" },
    { id: "touch-pan", label: "Touch navigation", hint: "Fingers only pan; draw with the pen" },
  ];

  return (
    <div
      data-wb-modal
      className="fixed inset-0 z-[90] flex items-center justify-center bg-black/50 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="flex max-h-[80vh] w-full max-w-sm flex-col overflow-hidden rounded-2xl border border-border bg-white shadow-2xl dark:bg-zinc-900"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between border-b border-border px-5 py-3">
          <h2 className="text-base font-semibold">Settings</h2>
          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={onClose}>
            <X size={16} />
          </Button>
        </div>

        {/* A plain scrolling div, deliberately not Radix's ScrollArea.
            Radix's viewport is sized with height:100%, which needs a parent
            with a definite height; inside a flex column it resolved to the
            content height instead, so the panel grew past the card and the
            bottom of Settings was unreachable. `min-h-0 flex-1 overflow-y-auto`
            needs no percentage resolution and cannot be overridden by the
            inline styles Radix sets on its own root. */}
        <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain">
          <div className="space-y-3 p-3">
            {/* ---- Appearance ---- */}
            <section>
              <SectionTitle>Appearance</SectionTitle>
              <div className="flex gap-1 rounded-lg bg-muted p-0.5">
                {themes.map((t) => (
                  <button
                    key={t.id}
                    onClick={() => setTheme(t.id)}
                    className={cn(
                      "flex flex-1 items-center justify-center gap-1.5 rounded-md px-2 py-1.5 text-xs font-medium transition-colors",
                      theme === t.id
                        ? "bg-background shadow-sm"
                        : "text-muted-foreground hover:text-foreground"
                    )}
                  >
                    {t.icon}
                    {t.label}
                  </button>
                ))}
              </div>
            </section>

            {/* ---- This board's paper ---- */}
            <section>
              <SectionTitle>Board background</SectionTitle>
              <div className="px-2 pb-1">
                <div className="mb-1.5 flex flex-wrap items-center gap-1.5">
                  {BOARD_BACKGROUNDS.map((bg) => {
                    const swatch =
                      bg.id === "default"
                        ? "linear-gradient(135deg,#ffffff 50%,#18181b 50%)"
                        : resolvedTheme === "dark"
                        ? bg.dark
                        : bg.light;
                    const active = (activeBoard?.background?.color ?? "default") === bg.id;
                    return (
                      <button
                        key={bg.id}
                        title={bg.label}
                        onClick={() =>
                          activeBoard &&
                          setBoardBackground(
                            activeBoard.id,
                            {
                              color: bg.id === "default" ? undefined : bg.id,
                            },
                            pageScope
                          )
                        }
                        className={cn(
                          "h-7 w-7 rounded-full border transition-transform",
                          active
                            ? "scale-110 border-foreground ring-2 ring-primary"
                            : "border-black/15 hover:scale-105 dark:border-white/20"
                        )}
                        style={{ background: swatch }}
                      />
                    );
                  })}
                  {/* Any colour at all, stored literally rather than by preset id. */}
                  <label
                    title="Custom background colour…"
                    className="relative h-7 w-7 cursor-pointer rounded-full border border-dashed border-border"
                    style={{
                      background:
                        "conic-gradient(#ef4444,#f97316,#eab308,#22c55e,#06b6d4,#3b82f6,#8b5cf6,#ec4899,#ef4444)",
                    }}
                  >
                    <input
                      type="color"
                      className="absolute inset-0 h-full w-full cursor-pointer opacity-0"
                      onChange={(e) =>
                        activeBoard &&
                        setBoardBackground(activeBoard.id, { color: e.target.value }, pageScope)
                      }
                    />
                    <span className="pointer-events-none absolute inset-[7px] rounded-full bg-background" />
                  </label>
                </div>

                <div className="mb-1 text-[11px] text-muted-foreground">Paper</div>
                <div className="flex gap-1">
                  {BOARD_PATTERNS.map((pt) => (
                    <button
                      key={pt.id}
                      onClick={() =>
                        activeBoard && setBoardBackground(activeBoard.id, { pattern: pt.id }, pageScope)
                      }
                      className={cn(
                        "flex-1 rounded-lg border px-2 py-1.5 text-[11px] font-medium transition-colors",
                        (activeBoard?.background?.pattern ?? "dots") === pt.id
                          ? "border-primary bg-primary/10 text-primary"
                          : "border-border hover:bg-muted"
                      )}
                    >
                      {pt.label}
                    </button>
                  ))}
                </div>

                {/* Paper size. Hidden for "Plain" — there is no spacing to set
                    when nothing is drawn. */}
                {(activeBoard?.background?.pattern ?? "dots") !== "plain" && (
                  <div className="mt-2.5">
                    <div className="mb-1 flex items-center justify-between">
                      <span className="text-[11px] text-muted-foreground">Paper size</span>
                      <span className="rounded-md bg-muted px-1.5 py-0.5 text-[11px] font-semibold tabular-nums">
                        {paperSize}px
                      </span>
                    </div>
                    <StepperRow
                      value={paperSize}
                      min={BOARD_PATTERN_MIN_SIZE}
                      max={BOARD_PATTERN_MAX_SIZE}
                      onChange={(size) =>
                        activeBoard && setBoardBackground(activeBoard.id, { size }, pageScope)
                      }
                    >
                      <input
                        type="range"
                        min={BOARD_PATTERN_MIN_SIZE}
                        max={BOARD_PATTERN_MAX_SIZE}
                        value={paperSize}
                        aria-label="Paper size"
                        onChange={(e) =>
                          activeBoard &&
                          setBoardBackground(activeBoard.id, { size: Number(e.target.value) }, pageScope)
                        }
                        className="h-1.5 w-full cursor-pointer appearance-none rounded-lg bg-muted accent-primary"
                      />
                    </StepperRow>
                    <div className="mt-1.5 flex gap-1">
                      {BOARD_PATTERN_SIZE_PRESETS.map((sz) => (
                        <button
                          key={sz}
                          onClick={() =>
                            activeBoard && setBoardBackground(activeBoard.id, { size: sz }, pageScope)
                          }
                          className={cn(
                            "flex-1 rounded-md border px-1.5 py-1 text-[10px] font-medium transition-colors",
                            paperSize === sz
                              ? "border-primary bg-primary/10 text-primary"
                              : "border-border text-muted-foreground hover:bg-muted"
                          )}
                        >
                          {sz}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                <p className="mt-1.5 text-[11px] leading-snug text-muted-foreground">
                  The default for <strong>{activeBoard?.name ?? "this board"}</strong> — new
                  pages start with it, and pages without their own paper follow it.
                  Pages you styled individually keep theirs. Snap-to-grid follows
                  this spacing.
                </p>
                {/* Scope: future pages only, or every existing page too. The
                    panel always edits the board you last touched (in split view
                    that is the last-used pane) — never the whole app. */}
                {isNotebook(activeBoard) && (
                  <div className="mt-1">
                    <ToggleRow
                      icon={<Layers size={15} />}
                      label="Apply to all pages"
                      hint="Writes the current paper onto every existing page now, and keeps later changes in step"
                      checked={applyAllPages}
                      onChange={() => {
                        const next = !applyAllPages;
                        setApplyAllPages(next);
                        // Flipping the toggle must DO something, not just arm
                        // future taps: turning it on stamps the board's current
                        // paper onto every page immediately.
                        if (next && activeBoard?.background) {
                          setBoardBackground(
                            activeBoard.id,
                            { ...activeBoard.background },
                            { allPages: true }
                          );
                        }
                      }}
                    />
                  </div>
                )}
                <div className="mt-1.5 flex items-center justify-between gap-2">
                  <span className="text-[11px] text-muted-foreground">
                    App default:{" "}
                    <strong>
                      {BOARD_PATTERNS.find((p) => p.id === defaultPaper.pattern)?.label ??
                        "Plain"}
                      {defaultPaper.pattern !== "plain" &&
                        ` · ${defaultPaper.size ?? BOARD_PATTERN_DEFAULT_SIZE}px`}
                    </strong>
                  </span>
                  <button
                    onClick={() =>
                      activeBoard?.background && setDefaultPaper({ ...activeBoard.background })
                    }
                    title="Use this board's paper for all future boards and pages"
                    className="shrink-0 rounded-lg border border-border px-2 py-1 text-[11px] font-medium transition-colors hover:bg-muted"
                  >
                    Set as app default
                  </button>
                </div>
              </div>
            </section>

            {/* ---- Notebook ---- */}
            {isNotebook(activeBoard) && (
              <section>
                <SectionTitle>Notebook</SectionTitle>
                <div className="px-2 pb-1">
                  <div className="mb-1 flex items-center justify-between">
                    <span className="text-[11px] text-muted-foreground">Page size</span>
                    <span className="rounded-md bg-muted px-1.5 py-0.5 text-[11px] font-semibold tabular-nums">
                      {pageDims.width} × {pageDims.height}
                    </span>
                  </div>
                  {/* A PDF notebook uses its document's page size — the buttons
                      below change `pageSize`, which pageSizeOf ignores while a
                      valid custom size exists, so they would silently do
                      nothing here. */}
                  {activeBoard?.customPageSize &&
                  activeBoard.customPageSize.width > 0 &&
                  activeBoard.customPageSize.height > 0 ? (
                    <p className="mt-1.5 text-[11px] leading-snug text-muted-foreground">
                      This notebook uses its PDF&apos;s page size.
                    </p>
                  ) : (
                    <div className="grid grid-cols-2 gap-1">
                      {(Object.keys(PAGE_SIZES) as PageSizeId[]).map((id) => (
                        <button
                          key={id}
                          onClick={() => setPageSize(id)}
                          className={cn(
                            "rounded-lg border px-2 py-1.5 text-left text-[11px] transition-colors",
                            (activeBoard?.pageSize ?? "a4") === id
                              ? "border-primary bg-primary/10 text-primary"
                              : "border-border hover:bg-muted"
                          )}
                        >
                          {PAGE_SIZES[id].label}
                        </button>
                      ))}
                    </div>
                  )}
                  <p className="mt-1.5 text-[11px] leading-snug text-muted-foreground">
                    Applies to every page of{" "}
                    <strong>{activeBoard?.name ?? "this notebook"}</strong>. Existing ink is not
                    moved or scaled, so shrinking the page can push content past its edge.
                  </p>
                </div>
              </section>
            )}

            {/* ---- Canvas ---- */}
            <section>
              <SectionTitle>Canvas</SectionTitle>
              <ToggleRow
                icon={<Grid size={15} />}
                label="Snap to grid"
                hint="Aligns to the paper spacing (freehand strokes stay free)"
                checked={snapToGrid}
                onChange={toggleSnapToGrid}
              />
              <ToggleRow
                icon={<ZoomIn size={15} />}
                label="Zoom controls"
                hint="Bottom-left readout that appears while you zoom, then fades"
                checked={zoomDockOpen}
                onChange={toggleZoomDock}
              />
              <ToggleRow
                icon={<MapIcon size={15} />}
                label="Minimap"
                hint="Corner navigator showing the whole board"
                checked={minimapOpen}
                onChange={toggleMinimap}
              />
              <ToggleRow
                icon={<Tag size={15} />}
                label="Link legend"
                hint="Colour key for connection types"
                checked={legendVisible}
                onChange={onToggleLegend}
              />
            </section>

            {/* ---- Pens ---- */}
            <section>
              <SectionTitle>Pens</SectionTitle>
              <ToggleRow
                icon={<Star size={15} />}
                label="Favorite pens bar"
                hint="Pin pens by type, colour and size; drag to move it"
                checked={pinnedBarOpen}
                onChange={togglePinnedBar}
              />
            </section>

            {/* ---- Touch & stylus ---- */}
            <section>
              <SectionTitle>Touch & stylus</SectionTitle>
              <div className="space-y-1 px-2 pb-1">
                {touchModes.map((m) => (
                  <button
                    key={m.id}
                    onClick={() => setTouchSettings({ mode: m.id })}
                    className={cn(
                      "flex w-full flex-col items-start rounded-lg border px-2.5 py-1.5 text-left transition-colors",
                      touchSettings.mode === m.id
                        ? "border-primary bg-primary/10"
                        : "border-border hover:bg-muted"
                    )}
                  >
                    <span className="text-xs font-medium">{m.label}</span>
                    <span className="text-[11px] leading-snug text-muted-foreground">{m.hint}</span>
                  </button>
                ))}
              </div>
              <div className="px-2 pb-1 pt-1">
                <div className="mb-1 text-[11px] text-muted-foreground">Select shape</div>
                <div className="flex gap-1">
                  {(
                    [
                      { id: "rectangle", label: "Box", hint: "Drag a box" },
                      { id: "lasso", label: "Lasso", hint: "Draw around it with the pen" },
                    ] as const
                  ).map((m) => {
                    const current =
                      tool === "select" ? "rectangle" : tool === "lasso" ? "lasso" : null;
                    return (
                      <button
                        key={m.id}
                        onClick={() => setTool(m.id === "rectangle" ? "select" : "lasso")}
                        title={m.hint}
                        aria-pressed={current === m.id}
                        className={cn(
                          "flex-1 rounded-lg border px-2 py-1.5 text-[11px] font-medium transition-colors",
                          current === m.id
                            ? "border-primary bg-primary/10 text-primary"
                            : "border-border hover:bg-muted"
                        )}
                      >
                        {m.label}
                      </button>
                    );
                  })}
                </div>
                <button
                  onClick={() => setLassoStrict(!lassoStrict)}
                  role="switch"
                  aria-checked={!lassoStrict}
                  className="mt-2 flex w-full items-start gap-2 rounded-lg px-1 py-1.5 text-left hover:bg-muted"
                >
                  <span className="min-w-0 flex-1">
                    <span className="block text-[11px] font-medium leading-tight">
                      Include partially selected
                    </span>
                    <span className="block text-[11px] leading-snug text-muted-foreground">
                      {lassoStrict
                        ? "The lasso takes only what it fully encloses."
                        : "The lasso takes anything it touches."}
                    </span>
                  </span>
                  <span
                    className={cn(
                      "mt-0.5 h-4 w-7 shrink-0 rounded-full p-0.5 transition-colors",
                      lassoStrict ? "bg-muted-foreground/30" : "bg-primary"
                    )}
                  >
                    <span
                      className={cn(
                        "block h-3 w-3 rounded-full bg-white transition-transform",
                        lassoStrict ? "translate-x-0" : "translate-x-3"
                      )}
                    />
                  </span>
                </button>
              </div>
              <div className="px-2 pb-1 pt-1">
                <div className="mb-1 text-[11px] text-muted-foreground">Mouse &amp; trackpad</div>
                <div className="flex gap-1">
                  {([
                    { id: "auto", label: "Auto", hint: "Detect per event" },
                    { id: "trackpad", label: "Trackpad", hint: "Scroll pans, pinch zooms" },
                    { id: "mouse", label: "Mouse", hint: "Wheel zooms" },
                  ] as const).map((w) => (
                    <button
                      key={w.id}
                      onClick={() => setTouchSettings({ wheelMode: w.id })}
                      title={w.hint}
                      className={cn(
                        "flex-1 rounded-lg border px-2 py-1.5 text-[11px] font-medium transition-colors",
                        (touchSettings.wheelMode ?? "auto") === w.id
                          ? "border-primary bg-primary/10 text-primary"
                          : "border-border hover:bg-muted"
                      )}
                    >
                      {w.label}
                    </button>
                  ))}
                </div>
                <p className="mt-1.5 text-[11px] leading-snug text-muted-foreground">
                  Ctrl/⌘ + wheel always zooms. Shift + wheel scrolls sideways.
                </p>
              </div>

              <ToggleRow
                icon={<Pointer size={15} />}
                label="Two-finger tap to undo"
                hint="Three-finger tap redoes"
                checked={touchSettings.twoFingerUndo}
                onChange={() => setTouchSettings({ twoFingerUndo: !touchSettings.twoFingerUndo })}
              />
              <ToggleRow
                icon={<Pointer size={15} />}
                label="Stylus button erases"
                hint="Hold the pen's side button (or flip to its eraser end) to erase, release for your pen back"
                checked={touchSettings.stylusButtonErases !== false}
                onChange={() =>
                  setTouchSettings({ stylusButtonErases: !(touchSettings.stylusButtonErases !== false) })
                }
              />
              <ToggleRow
                icon={<Pointer size={15} />}
                label="Show pen diagnostics"
                hint="Prints what your stylus actually sends (buttons, pressure, tilt). Turn on if the side button does not erase, then screenshot the panel."
                checked={touchSettings.penDiagnostics === true}
                onChange={() => setTouchSettings({ penDiagnostics: !(touchSettings.penDiagnostics === true) })}
              />
              <ToggleRow
                icon={<Pointer size={15} />}
                label="Fingers never draw"
                hint="With a pen tool selected, fingers only navigate. Contact while the stylus is in use is always ignored, and holding a finger on an object selects it."
                checked={touchSettings.palmRejection}
                onChange={() => setTouchSettings({ palmRejection: !touchSettings.palmRejection })}
              />

              {/* S Pen Inking Engine & Stabilization */}
              <div className="mt-3 px-2">
                <div className="mb-1 flex items-center justify-between">
                  <span className="text-xs font-medium">Stroke stabilization &amp; smoothing</span>
                  <span className="rounded-md bg-muted px-1.5 py-0.5 text-[11px] font-semibold tabular-nums">
                    {touchSettings.penSmoothing ?? 50}%
                  </span>
                </div>
                <div className="mb-2 flex gap-1">
                  {[
                    { label: "Off", val: 0 },
                    { label: "Light", val: 25 },
                    { label: "Balanced", val: 50 },
                    { label: "High", val: 75 },
                    { label: "Ultra", val: 100 },
                  ].map((preset) => (
                    <button
                      key={preset.val}
                      type="button"
                      onClick={() => setTouchSettings({ penSmoothing: preset.val })}
                      className={cn(
                        "flex-1 rounded-md border py-1 text-[10px] font-medium transition-colors",
                        (touchSettings.penSmoothing ?? 50) === preset.val
                          ? "border-primary bg-primary/10 text-primary"
                          : "border-border text-muted-foreground hover:bg-muted"
                      )}
                    >
                      {preset.label}
                    </button>
                  ))}
                </div>
                <StepperRow
                  value={touchSettings.penSmoothing ?? 50}
                  min={0}
                  max={100}
                  onChange={(v) => setTouchSettings({ penSmoothing: v })}
                >
                  <input
                    type="range"
                    min={0}
                    max={100}
                    value={touchSettings.penSmoothing ?? 50}
                    aria-label="Stroke stabilization"
                    onChange={(e) => setTouchSettings({ penSmoothing: Number(e.target.value) })}
                    className="h-1.5 w-full cursor-pointer appearance-none rounded-lg bg-muted accent-primary"
                  />
                </StepperRow>
                <p className="mt-1 text-[11px] leading-snug text-muted-foreground">
                  Filters electromagnetic digitizer jitter. 50% gives natural responsive handwriting; High/Ultra stabilizes tremors.
                </p>
              </div>

              {/* S Pen Pressure Calibration */}
              <div className="mt-3 px-2">
                <div className="mb-1 flex items-center justify-between">
                  <span className="text-xs font-medium">S Pen pressure response curve</span>
                  <span className="rounded-md bg-muted px-1.5 py-0.5 text-[10px] font-semibold capitalize text-muted-foreground">
                    {touchSettings.penPressureCurve ?? "standard"}
                  </span>
                </div>
                <div className="mb-2 flex gap-1">
                  {[
                    { id: "off", label: "Off", hint: "Uniform" },
                    { id: "soft", label: "Soft", hint: "Light touch" },
                    { id: "standard", label: "Standard", hint: "Natural" },
                    { id: "firm", label: "Firm", hint: "Deliberate" },
                  ].map((c) => (
                    <button
                      key={c.id}
                      type="button"
                      onClick={() => setTouchSettings({ penPressureCurve: c.id as PressureCurve })}
                      className={cn(
                        "flex-1 rounded-md border py-1 text-center transition-colors",
                        (touchSettings.penPressureCurve ?? "standard") === c.id
                          ? "border-primary bg-primary/10 text-primary"
                          : "border-border text-muted-foreground hover:bg-muted"
                      )}
                    >
                      <span className="block text-[11px] font-medium leading-tight">{c.label}</span>
                      <span className="block text-[9px] text-muted-foreground leading-tight">{c.hint}</span>
                    </button>
                  ))}
                </div>

                {(touchSettings.penPressureCurve ?? "standard") !== "off" && (
                  <div>
                    <div className="mb-1 flex items-center justify-between">
                      <span className="text-[11px] text-muted-foreground">Pressure dynamic range</span>
                      <span className="rounded-md bg-muted px-1.5 py-0.5 text-[10px] font-semibold tabular-nums">
                        {touchSettings.penPressureSensitivity ?? 50}%
                      </span>
                    </div>
                    <StepperRow
                      value={touchSettings.penPressureSensitivity ?? 50}
                      min={0}
                      max={100}
                      onChange={(v) => setTouchSettings({ penPressureSensitivity: v })}
                    >
                      <input
                        type="range"
                        min={0}
                        max={100}
                        value={touchSettings.penPressureSensitivity ?? 50}
                        aria-label="Pressure sensitivity"
                        onChange={(e) => setTouchSettings({ penPressureSensitivity: Number(e.target.value) })}
                        className="h-1.5 w-full cursor-pointer appearance-none rounded-lg bg-muted accent-primary"
                      />
                    </StepperRow>
                  </div>
                )}
              </div>

              {/* Hardware Toggles */}
              <div className="mt-2">
                <ToggleRow
                  icon={<Sparkles size={15} />}
                  label="Lift-off anti-hook filter"
                  hint="Filters out the trailing hook flick caused when lifting the S Pen nib off the glass"
                  checked={touchSettings.penAntiHook !== false}
                  onChange={() => setTouchSettings({ penAntiHook: !(touchSettings.penAntiHook !== false) })}
                />
                <ToggleRow
                  icon={<Wand2 size={15} />}
                  label="Draw-and-hold auto-straighten"
                  hint="Pausing for 550ms at the end of a stroke snaps a freehand line perfectly straight"
                  checked={touchSettings.penAutoStraighten !== false}
                  onChange={() =>
                    setTouchSettings({ penAutoStraighten: !(touchSettings.penAutoStraighten !== false) })
                  }
                />
                <ToggleRow
                  icon={<Pointer size={15} />}
                  label="S Pen hover indicator"
                  hint="Shows live cursor dot and nib size preview when hovering S Pen above the screen"
                  checked={touchSettings.penHoverIndicator !== false}
                  onChange={() =>
                    setTouchSettings({ penHoverIndicator: !(touchSettings.penHoverIndicator !== false) })
                  }
                />
              </div>
            </section>

            {/* ---- Help ---- */}
            <section>
              <SectionTitle>Help</SectionTitle>
              <button
                onClick={() => {
                  onClose();
                  window.dispatchEvent(new CustomEvent("wb:open-shortcuts"));
                }}
                className="flex w-full items-center gap-3 rounded-lg px-2 py-2 text-left text-xs font-medium transition-colors hover:bg-muted"
              >
                <Keyboard size={15} className="text-muted-foreground" />
                Keyboard shortcuts & gestures
              </button>
              <button
                onClick={() => {
                  onClose();
                  window.dispatchEvent(new CustomEvent("wb:open-tutorial"));
                }}
                className="flex w-full items-center gap-3 rounded-lg px-2 py-2 text-left text-xs font-medium transition-colors hover:bg-muted"
              >
                <HelpCircle size={15} className="text-muted-foreground" />
                Show the tutorial again
              </button>
            </section>

            {/* ---- Which build is this ----
                Installing an APK and seeing no change is indistinguishable
                from a fix that did not work, unless the app can say which
                build it is. The build number is Android's versionCode and
                rises with every APK; a browser or desktop build has none. */}
            <p className="pt-1 text-center text-[11px] text-muted-foreground">
              ProNotes {process.env.NEXT_PUBLIC_APP_VERSION || "?"}
              {process.env.NEXT_PUBLIC_BUILD_CODE ? ` · build ${process.env.NEXT_PUBLIC_BUILD_CODE}` : ""}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
