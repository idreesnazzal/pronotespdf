"use client";

/**
 * Whiteboard App (v4 — Professional Grade Canvas & Knowledge Architecture)
 * ==========================================================================
 * Top-level whiteboard application shell. Composes:
 * - Sidebar (folder + board tree) — collapsible
 * - BacklinksPanel (Obsidian-style links & backlinks)
 * - Canvas (infinite drawing surface with snap-to-grid)
 * - Toolbar (modern bottom dock with tools, quick export, and zoom controls)
 * - Minimap Navigator (real-time canvas radar with interactive pan)
 * - ExportModal (vector SVG and 2x Retina PNG exporter)
 * - KeyboardShortcutsModal (searchable shortcuts categorized overlay)
 * - ThemeToggle (dark / light / system theme switching)
 * - PropertiesPanel (contextual HUD with opacity slider and styling)
 * - Inline text editor (overlay)
 * - Graph View modal (network visualization)
 * - Search modal (global search)
 */

import React, { useCallback, useEffect, useState, useRef } from "react";
import { useWhiteboard } from "@/store/whiteboard";
import { useTheme } from "next-themes";
import { WhiteboardCanvas } from "./WhiteboardCanvas";
import { Toolbar } from "./Toolbar";
import { Sidebar } from "./Sidebar";
import { PenDiagnostics } from "./PenDiagnostics";
import { BacklinksPanel } from "./BacklinksPanel";
import { SelectionActions } from "./SelectionActions";
import { ImageActions } from "./ImageActions";
import { CaptureHud } from "./CaptureHud";
import { CapturePanel } from "./CapturePanel";
import { ImageStudio } from "./ImageStudio";
import { LockedModeBar } from "./LockedModeBar";
import { PropertiesPanel } from "./PropertiesPanel";
import { InlineTextEditor } from "./InlineTextEditor";
import { GraphView } from "./GraphView";
import { SearchModal } from "./SearchModal";
import { LinkLegend } from "./LinkLegend";
import { TutorialModal } from "./TutorialModal";
import { LinkManager } from "./LinkManager";
import { Minimap } from "./Minimap";
import { FavoritePensBar } from "./FavoritePensBar";
import { NotebookPagePanelHost } from "./NotebookPages";
import { FileDropZone } from "./FileDropZone";
import { getBoardElements, isNotebook } from "@/lib/whiteboard/notebook";
import { SplitPane, SplitDivider, SplitLiveOverlay } from "./SplitPane";
import { SplitPicker } from "./SplitPicker";
import { SyncPanel } from "./SyncPanel";
import { SettingsPanel } from "./SettingsPanel";
import { ExportModal } from "./ExportModal";
import { InsertPagesModal } from "./InsertPagesModal";
import { KeyboardShortcutsModal } from "./KeyboardShortcutsModal";
import { ThemeToggle } from "./ThemeToggle";
import {
  PanelLeftOpen,
  Map as MapIcon,
  HelpCircle,
  Share2,
  FilePlus2,
  Keyboard,
  Grid,
  Cloud,
  Search,
  Network,
  Settings as SettingsIcon,
  CheckSquare,
  PenLine,
  Type,
  StickyNote,
  Shapes,
  Image as ImageIcon,
  Link2,
  Undo2,
  Redo2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";
import type { Viewport } from "@/lib/whiteboard/geometry";
import type { SearchScope } from "@/lib/whiteboard/search";

/** Undo and redo, in the top bar beside Select / Links / Search. */
function HeaderUndoRedo() {
  const undo = useWhiteboard((s) => s.undo);
  const redo = useWhiteboard((s) => s.redo);
  const canUndo = useWhiteboard((s) => s.canUndo());
  const canRedo = useWhiteboard((s) => s.canRedo());
  const btn = "h-8 w-8 text-muted-foreground hover:text-foreground disabled:opacity-30";
  return (
    <>
      <Button variant="ghost" size="icon" className={btn} onClick={undo} disabled={!canUndo} title="Undo (Ctrl+Z / 2-finger tap)" aria-label="Undo">
        <Undo2 size={15} />
      </Button>
      <Button variant="ghost" size="icon" className={btn} onClick={redo} disabled={!canRedo} title="Redo (Ctrl+Y / 3-finger tap)" aria-label="Redo">
        <Redo2 size={15} />
      </Button>
    </>
  );
}

export function WhiteboardApp() {
  const init = useWhiteboard((s) => s.init);
  const isReady = useWhiteboard((s) => s.isReady);
  const sidebarOpen = useWhiteboard((s) => s.sidebarOpen);
  const splitBoardId = useWhiteboard((s) => s.splitBoardId);
  const splitRatio = useWhiteboard((s) => s.splitRatio);
  const splitSide = useWhiteboard((s) => s.splitSide);
  const stacked = useWhiteboard((s) => s.splitOrientation === "stacked");
  const splitRowRef = useRef<HTMLDivElement>(null);
  const setSidebarOpen = useWhiteboard((s) => s.setSidebarOpen);
  const findOrCreateBoardByName = useWhiteboard((s) => s.findOrCreateBoardByName);
  const setActiveBoard = useWhiteboard((s) => s.setActiveBoard);
  const selectedIds = useWhiteboard((s) => s.selectedIds);
  const selectAll = useWhiteboard((s) => s.selectAll);
  const clearSelection = useWhiteboard((s) => s.clearSelection);
  const selectByType = useWhiteboard((s) => s.selectByType);
  const invertSelection = useWhiteboard((s) => s.invertSelection);

  const { theme, setTheme, resolvedTheme } = useTheme();

  const [viewport, setViewport] = useState<Viewport>({ width: 1200, height: 800 });
  const [graphOpen, setGraphOpen] = useState(false);
  // Search opens in a scope: Ctrl+F finds in the open note, while Ctrl+K and
  // the header button search everywhere (see SearchModal). Each request gets
  // a fresh key, so asking again while the find bar is up reopens the panel
  // in the requested scope.
  const [search, setSearch] = useState<{ scope: SearchScope; key: number; query?: string; mode?: "panel" | "bar" } | null>(null);
  const searchKeyRef = useRef(0);
  const openSearch = useCallback((scope: SearchScope, query?: string, mode?: "panel" | "bar") => {
    searchKeyRef.current += 1;
    setSearch({ scope, key: searchKeyRef.current, query, mode });
  }, []);
  // "Find in note" on a PDF text selection: search this note for that text.
  useEffect(() => {
    const onOpen = (e: Event) => {
      const q = (e as CustomEvent<{ query?: string }>).detail?.query;
      // Straight to the find bar on the matches, not a panel over them.
      openSearch("note", typeof q === "string" ? q : undefined, typeof q === "string" && q ? "bar" : "panel");
    };
    window.addEventListener("wb:open-search", onOpen);
    return () => window.removeEventListener("wb:open-search", onOpen);
  }, [openSearch]);
  const [showBacklinks, setShowBacklinks] = useState(false);
  const [syncOpen, setSyncOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);

  // Home-screen shortcuts from manifest.json ("New Whiteboard", "Knowledge
  // Graph"). The manifest has always pointed at `/?action=new` and
  // `/?view=graph`, but nothing read those parameters, so both shortcuts just
  // opened the app. Handled once, after the workspace has loaded (a new board
  // made before that would be overwritten by the load), and then stripped from
  // the address so a reload does not create a second board.
  const createBoardAction = useWhiteboard((s) => s.createBoard);
  const shortcutHandledRef = useRef(false);
  useEffect(() => {
    if (!isReady || shortcutHandledRef.current || typeof window === "undefined") return;
    shortcutHandledRef.current = true;
    const params = new URLSearchParams(window.location.search);
    const action = params.get("action");
    const view = params.get("view");
    if (!action && !view) return;
    if (action === "new") createBoardAction("Untitled Board", null);
    if (view === "graph") setGraphOpen(true);
    params.delete("action");
    params.delete("view");
    const rest = params.toString();
    window.history.replaceState(null, "", window.location.pathname + (rest ? `?${rest}` : "") + window.location.hash);
  }, [isReady, createBoardAction]);
  // Off by default: it is a colour key, not a tool, and it occupied a large
  // block of the canvas permanently. Turn it on in Settings > Canvas.
  // Persisted in the store (like the minimap) so it survives reloads.
  const showLegend = useWhiteboard((s) => s.legendOpen);
  const toggleLegend = useWhiteboard((s) => s.toggleLegend);
  const [linkManagerOpen, setLinkManagerOpen] = useState(false);
  const [exportOpen, setExportOpen] = useState(false);
  const [insertPagesOpen, setInsertPagesOpen] = useState(false);
  // Inserting pages only means anything in a paged document, so the button
  // stays out of a whiteboard's toolbar rather than opening to explain itself.
  const isNotebookBoard = useWhiteboard((s) => isNotebook(s.boards.find((b) => b.id === s.activeBoardId)));
  const [shortcutsOpen, setShortcutsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // Initialize store from localStorage on mount
  useEffect(() => {
    init();
  }, [init]);

  // Track viewport size for the inline text editor and tools.
  //
  // `isReady` is a dependency for a reason: until the workspace loads, this
  // component renders a "Loading" placeholder, so containerRef is null on the
  // first run and the effect returned early. With only the sidebar/backlinks
  // flags as deps it never ran again, and the size stayed at the 1200x800
  // default until the sidebar was toggled - so the text editor, the selection
  // action bar and the minimap were all positioned for a canvas that was not
  // there (on a tablet the text editor's bar ran off the screen).
  useEffect(() => {
    if (!containerRef.current) return;
    const updateSize = () => {
      if (containerRef.current) {
        const rect = containerRef.current.getBoundingClientRect();
        if (rect.width > 0 && rect.height > 0) {
          setViewport({ width: rect.width, height: rect.height });
        }
      }
    };
    updateSize();

    const observer = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const { width, height } = entry.contentRect;
        if (width > 0 && height > 0) {
          setViewport({ width, height });
        }
      }
    });

    observer.observe(containerRef.current);
    window.addEventListener("resize", updateSize);
    return () => {
      observer.disconnect();
      window.removeEventListener("resize", updateSize);
    };
  }, [sidebarOpen, showBacklinks, isReady]);

  // Listen for wikilink navigation events
  useEffect(() => {
    const handler = (e: Event) => {
      const detail = (e as CustomEvent).detail as { target: string };
      const id = findOrCreateBoardByName(detail.target);
      setActiveBoard(id);
    };
    window.addEventListener("wb:navigate-link", handler);
    return () => window.removeEventListener("wb:navigate-link", handler);
  }, [findOrCreateBoardByName, setActiveBoard]);

  // Listen for auto-fit height events from text elements
  useEffect(() => {
    const handler = (e: Event) => {
      const detail = (e as CustomEvent).detail as { id: string; height: number };
      const state = useWhiteboard.getState();
      const board = state.boards.find((b) => b.id === state.activeBoardId);
      if (!board) return;
      // On a notebook the element is on the active page, not on the canvas
      // field — so a growing text box never found itself and stopped
      // expanding as you typed.
      const el = getBoardElements(board).find((x) => x.id === detail.id);
      if (!el || (el.type !== "text" && el.type !== "sticky")) return;
      state.updateElement(detail.id, { height: detail.height } as never, false);
    };
    window.addEventListener("wb:auto-fit-height", handler);
    return () => window.removeEventListener("wb:auto-fit-height", handler);
  }, []);

  // Listen for custom modal events
  useEffect(() => {
    const onOpenExport = () => setExportOpen(true);
    const onOpenInsertPages = () => setInsertPagesOpen(true);
    const onOpenShortcuts = () => setShortcutsOpen(true);
    const onOpenSettings = () => setSettingsOpen(true);
    const onToggleTheme = () => {
      const nextTheme = resolvedTheme === "dark" ? "light" : "dark";
      setTheme(nextTheme);
    };

    window.addEventListener("wb:open-export", onOpenExport);
    window.addEventListener("wb:open-insert-pages", onOpenInsertPages);
    window.addEventListener("wb:open-shortcuts", onOpenShortcuts);
    window.addEventListener("wb:open-settings", onOpenSettings);
    window.addEventListener("wb:toggle-theme", onToggleTheme);
    return () => {
      window.removeEventListener("wb:open-export", onOpenExport);
      window.removeEventListener("wb:open-shortcuts", onOpenShortcuts);
      window.removeEventListener("wb:open-settings", onOpenSettings);
      window.removeEventListener("wb:toggle-theme", onToggleTheme);
    };
  }, [resolvedTheme, setTheme]);

  // Global keyboard shortcuts for search and graph
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      // Never hijack typing: skip while an element is being edited inline or
      // while focus is in any input / textarea / contentEditable host.
      const editing = useWhiteboard.getState().editingId;
      if (editing) return;
      const target = e.target as HTMLElement | null;
      if (
        target &&
        (target.tagName === "INPUT" ||
          target.tagName === "TEXTAREA" ||
          target.isContentEditable)
      ) {
        return;
      }

      // Shortcuts must not fire under open modal overlays (Radix dialogs
      // focus a plain DIV, so the input guard above is not enough).
      if (document.querySelector('[role="dialog"][data-state="open"], [data-wb-modal]')) {
        return;
      }

      // Ctrl+K / Cmd+K: search everywhere
      if ((e.ctrlKey || e.metaKey) && !e.shiftKey && e.code === "KeyK") {
        e.preventDefault();
        openSearch("everywhere");
      }
      // Ctrl+F / Cmd+F: find in the open note - what Ctrl+F means in every
      // editor. With nothing open there is no note to find in.
      if ((e.ctrlKey || e.metaKey) && !e.shiftKey && e.code === "KeyF") {
        e.preventDefault();
        openSearch(useWhiteboard.getState().activeBoardId ? "note" : "everywhere");
      }
      // Ctrl+G / Cmd+G: graph view (plain only — Ctrl+Shift+G is Snap-to-Grid)
      if ((e.ctrlKey || e.metaKey) && !e.shiftKey && e.code === "KeyG") {
        e.preventDefault();
        setGraphOpen(true);
      }
      // Ctrl+B / Cmd+B: toggle backlinks panel
      if ((e.ctrlKey || e.metaKey) && !e.shiftKey && e.code === "KeyB") {
        e.preventDefault();
        setShowBacklinks((v) => !v);
      }
      // Ctrl+L / Cmd+L: link manager (plain only — Ctrl+Shift+L is Lock)
      if ((e.ctrlKey || e.metaKey) && !e.shiftKey && e.code === "KeyL") {
        e.preventDefault();
        setLinkManagerOpen(true);
      }
      // Ctrl+Shift+I / Cmd+Shift+I: select all ink strokes
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.code === "KeyI") {
        e.preventDefault();
        selectByType("stroke");
      }
      // Ctrl+Shift+T / Cmd+Shift+T: select all text cards
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.code === "KeyT") {
        e.preventDefault();
        selectByType("text");
      }
      // Ctrl+Shift+V / Cmd+Shift+V: invert selection
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.code === "KeyV") {
        e.preventDefault();
        invertSelection();
      }
      // Escape: deselect all if elements are selected
      if (e.key === "Escape" && selectedIds.length > 0) {
        e.preventDefault();
        clearSelection();
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [selectByType, invertSelection, clearSelection, selectedIds.length, openSearch]);

  // Listen for "open link manager" events from the sidebar button
  useEffect(() => {
    const handler = () => setLinkManagerOpen(true);
    window.addEventListener("wb:open-link-manager", handler);
    return () => window.removeEventListener("wb:open-link-manager", handler);
  }, []);

  // Storage health banner: quota-degraded saves, total save failure, recovery,
  // and multi-tab clobbering — all previously silent.
  const [storageWarning, setStorageWarning] = useState<string | null>(null);
  useEffect(() => {
    const onDegraded = () => setStorageWarning("Storage full — images were NOT saved (boards, strokes and text were). Delete unused boards or large images.");
    const onFailed = () => setStorageWarning("Saving failed — your latest changes may be lost on reload.");
    const onRecovered = () => setStorageWarning(null);
    const onPressure = () =>
      setStorageWarning(
        "Storage is almost full — export a backup (Settings → Sync → Save backup), then delete unused boards."
      );
    const onImageInline = () =>
      setStorageWarning(
        "A picture couldn't go into this device's image storage, so it was saved inside the board instead. A few more like that can fill up storage - export a backup if you add many images."
      );
    const onExternal = () =>
      setStorageWarning("This whiteboard was just saved from another tab. Keep working in ONE tab to avoid losing changes.");
    window.addEventListener("wb:save-degraded", onDegraded);
    window.addEventListener("wb:save-failed", onFailed);
    window.addEventListener("wb:save-recovered", onRecovered);
    window.addEventListener("wb:storage-pressure", onPressure);
    window.addEventListener("wb:external-change", onExternal);
    window.addEventListener("wb:image-inline", onImageInline);
    return () => {
      window.removeEventListener("wb:image-inline", onImageInline);
      window.removeEventListener("wb:save-degraded", onDegraded);
      window.removeEventListener("wb:save-failed", onFailed);
      window.removeEventListener("wb:save-recovered", onRecovered);
      window.removeEventListener("wb:storage-pressure", onPressure);
      window.removeEventListener("wb:external-change", onExternal);
    };
  }, []);

  if (!isReady) {
    return (
      <div className="w-screen h-screen flex items-center justify-center bg-background">
        <div className="text-muted-foreground text-sm">Loading whiteboard…</div>
      </div>
    );
  }

  return (
    <div className="w-screen h-screen flex overflow-hidden bg-background text-foreground">
      {/* Sidebar */}
      {sidebarOpen && <Sidebar />}

      {/* Raw pointer readout, off unless switched on in Settings. */}
      <PenDiagnostics />

      {/* Backlinks panel */}
      {showBacklinks && <BacklinksPanel onClose={() => setShowBacklinks(false)} />}

      {/* Storage health banner */}
      {storageWarning && (
        <div
          data-wb-modal
          className="absolute top-2 left-1/2 -translate-x-1/2 z-[120] flex items-center gap-3 max-w-[90vw] px-4 py-2 rounded-lg bg-amber-500/95 text-amber-950 text-xs font-medium shadow-lg"
          role="alert"
        >
          <span>{storageWarning}</span>
          <button
            className="px-2 py-0.5 rounded bg-amber-900/15 hover:bg-amber-900/25 font-semibold"
            onClick={() => setStorageWarning(null)}
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Editable pane + optional reference pane. The row is what the
          divider measures against when you drag it. */}
      <div ref={splitRowRef} className={cn("flex min-h-0 min-w-0 flex-1", splitBoardId && stacked && "flex-col")}>
      {/* The editable canvas and the reference pane are REORDERED rather than
          swapped in the tree: moving them would remount the canvas and lose
          its measured viewport mid-gesture. `order` keeps both mounted and
          just changes which side each occupies. */}
      <div
        ref={containerRef}
        // The floating pen bar measures this box to keep itself out of the
        // sidebar and the backlinks panel. Measuring the pane rather than
        // assuming a sidebar width means a split view narrows it too.
        data-wb-canvas-area
        // @container: the dock's page controls go compact in a narrow pane
        // (upright tablet with the sidebar open) - see NotebookPageControls.
        className="@container relative min-h-0 min-w-0 overflow-hidden"
        style={
          splitBoardId
            ? {
                order: splitSide === "left" ? 0 : 2,
                // Minus half the 6px divider each, or the two panes plus the
                // divider overflow the row and the far pane loses its edge.
                flex: `0 0 calc(${(splitSide === "left" ? splitRatio : 1 - splitRatio) * 100}% - 3px)`,
              }
            : { flex: "1 1 0%" }
        }
      >
        {/* Which half your tools act on: framed, and named. Only in split view. */}
        <SplitLiveOverlay />

        {/* Top-left controls (when sidebar is hidden) */}
        {!sidebarOpen && (
          <div className="absolute top-4 left-4 z-30 flex items-center gap-2">
            <Button
              variant="outline"
              size="icon"
              className="h-9 w-9 bg-white/95 dark:bg-zinc-900/95 backdrop-blur-md shadow-md"
              onClick={() => setSidebarOpen(true)}
              title="Show sidebar"
            >
              <PanelLeftOpen size={18} />
            </Button>
          </div>
        )}

        {/* Top-right header — DOCUMENT actions (things you do to this board).
            View controls live in the bottom-right dock and one-time settings
            live in Settings, so no control appears in two places.
            In a narrow pane (split view, or the sidebar open on an upright
            tablet) the labels become icons and the gaps tighten, so the whole
            bar fits and undo at its left end is never cut off. */}
        <div className="absolute top-4 right-4 z-30 flex max-w-[calc(100%-2rem)] items-center gap-1.5 @max-[46rem]:gap-0.5 overflow-x-auto [scrollbar-width:none] [&::-webkit-scrollbar]:hidden p-1 bg-white/95 dark:bg-zinc-900/95 backdrop-blur-md shadow-md border border-border/80 rounded-xl select-none">
          {/* Undo / redo live here, with the other board actions: inside the
              tool pill they wrapped onto a second row of their own. */}
          <HeaderUndoRedo />
          <div className="h-4 w-px bg-border/80 mx-0.5" />
          {/* Pro Selection Tools */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant={selectedIds.length > 0 ? "secondary" : "ghost"}
                size="sm"
                className={cn(
                  "h-8 px-2 text-xs font-medium gap-1.5 transition-colors",
                  selectedIds.length > 0
                    ? "text-primary bg-primary/10 border border-primary/25"
                    : "text-muted-foreground hover:text-foreground"
                )}
                title="Canvas selection tools (Select all, by type, invert)"
              >
                <CheckSquare size={14} className={selectedIds.length > 0 ? "text-primary" : ""} />
                <span className="hidden sm:inline @max-[46rem]:hidden">
                  {selectedIds.length > 0 ? `Selected (${selectedIds.length})` : "Select"}
                </span>
                {selectedIds.length > 0 && (
                  <span className="sm:hidden @max-[46rem]:inline text-[10px] font-bold">
                    {selectedIds.length}
                  </span>
                )}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56 text-xs">
              <div className="px-2 py-1 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
                Canvas Selection
              </div>
              <DropdownMenuItem onClick={() => selectAll()}>
                <span className="flex-1">Select All</span>
                <span className="text-[10px] text-muted-foreground">Ctrl+A</span>
              </DropdownMenuItem>
              {selectedIds.length > 0 && (
                <DropdownMenuItem onClick={() => clearSelection()}>
                  <span className="flex-1">Deselect All</span>
                  <span className="text-[10px] text-muted-foreground">Esc</span>
                </DropdownMenuItem>
              )}
              <DropdownMenuItem onClick={() => invertSelection()}>
                <span className="flex-1">Invert Selection</span>
                <span className="text-[10px] text-muted-foreground">Ctrl+Shift+V</span>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <div className="px-2 py-1 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
                Select by Type
              </div>
              <DropdownMenuItem onClick={() => selectByType("stroke")}>
                <PenLine size={13} className="mr-2 text-primary" />
                <span className="flex-1">All Ink Strokes</span>
                <span className="text-[10px] text-muted-foreground">Ctrl+Shift+I</span>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => selectByType("text")}>
                <Type size={13} className="mr-2 text-blue-500" />
                <span className="flex-1">All Text Notes</span>
                <span className="text-[10px] text-muted-foreground">Ctrl+Shift+T</span>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => selectByType("sticky")}>
                <StickyNote size={13} className="mr-2 text-amber-500" />
                <span className="flex-1">All Sticky Notes</span>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => selectByType("shape")}>
                <Shapes size={13} className="mr-2 text-indigo-500" />
                <span className="flex-1">All Shapes</span>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => selectByType("image")}>
                <ImageIcon size={13} className="mr-2 text-emerald-500" />
                <span className="flex-1">All Images</span>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => selectByType("connection")}>
                <Link2 size={13} className="mr-2 text-purple-500" />
                <span className="flex-1">All Connectors</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <Button
            variant="ghost"
            size="sm"
            className={cn(
              "h-8 px-2.5 text-xs font-medium",
              showBacklinks ? "text-primary" : "text-muted-foreground hover:text-foreground"
            )}
            onClick={() => setShowBacklinks(!showBacklinks)}
            title="Links & backlinks for this board (Ctrl+B)"
            aria-label="Links"
          >
            <Link2 size={15} className="hidden @max-[46rem]:block" />
            <span className="@max-[46rem]:hidden">Links</span>
          </Button>

          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 text-muted-foreground hover:text-foreground"
            // Everywhere, like Ctrl+K: it sits beside the graph, the other
            // whole-workspace tool, and is how you reach a note that is not
            // open. "This note" is one tap away in the panel, and Ctrl+F.
            onClick={() => openSearch("everywhere")}
            title="Search (Ctrl+K) · find in this note (Ctrl+F)"
            aria-label="Search"
          >
            <Search size={15} />
          </Button>

          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 text-muted-foreground hover:text-foreground"
            onClick={() => setGraphOpen(true)}
            title="Knowledge graph (Ctrl+G)"
          >
            <Network size={15} />
          </Button>

          <SplitPicker />

          <div className="h-4 w-px bg-border/80 mx-0.5" />

          {isNotebookBoard && (
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 text-muted-foreground hover:text-foreground"
              onClick={() => setInsertPagesOpen(true)}
              title="Insert pages from another notebook or a PDF"
            >
              <FilePlus2 size={15} />
            </Button>
          )}

          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 text-muted-foreground hover:text-foreground"
            onClick={() => setExportOpen(true)}
            title="Export or share (Ctrl+E)"
          >
            <Share2 size={15} />
          </Button>

          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 text-muted-foreground hover:text-foreground"
            onClick={() => setSyncOpen(true)}
            title="Sync & Backup"
          >
            <Cloud size={16} />
          </Button>

          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 text-muted-foreground hover:text-foreground"
            onClick={() => setSettingsOpen(true)}
            title="Settings"
          >
            <SettingsIcon size={16} />
          </Button>
        </div>

        {/* Canvas */}
        <WhiteboardCanvas />

        {/* Toolbar bottom dock */}
        <Toolbar
          onOpenGraph={() => setGraphOpen(true)}
          onOpenSearch={() => openSearch("everywhere")}
        />

        {/* Minimap Radar */}
        <Minimap viewport={viewport} />

        {/* Favourite pens (movable, reorderable pin bar) */}
        <FavoritePensBar />

        {/* Notebook page navigation — renders nothing on an infinite canvas */}
        <NotebookPagePanelHost />

        {/* Drop a PDF or images anywhere on the window */}
        <FileDropZone />

        {/* Floating actions and HUD */}
        <SelectionActions viewport={viewport} />
        <ImageActions viewport={viewport} />
        <CaptureHud />
        <LockedModeBar />
        <PropertiesPanel />
        <LinkLegend visible={showLegend} onToggle={toggleLegend} />
        <InlineTextEditor viewport={viewport} />

        {/* Modals */}
        <ImageStudio />
        <CapturePanel />
        <ExportModal open={exportOpen} onClose={() => setExportOpen(false)} />
        <InsertPagesModal open={insertPagesOpen} onClose={() => setInsertPagesOpen(false)} />
        <KeyboardShortcutsModal open={shortcutsOpen} onClose={() => setShortcutsOpen(false)} />
        <GraphView open={graphOpen} onClose={() => setGraphOpen(false)} />
        {search && (
          <SearchModal key={search.key} initialScope={search.scope} initialQuery={search.query} initialMode={search.mode} onClose={() => setSearch(null)} />
        )}
        <LinkManager open={linkManagerOpen} onClose={() => setLinkManagerOpen(false)} />
        <SyncPanel open={syncOpen} onClose={() => setSyncOpen(false)} />
        <SettingsPanel
          open={settingsOpen}
          onClose={() => setSettingsOpen(false)}
          legendVisible={showLegend}
          onToggleLegend={toggleLegend}
        />
        <TutorialModal />
      </div>

      {/* Reference pane. Modals stay inside the editable pane above so they
          are never squeezed by the split. */}
      {splitBoardId && (
        <>
          <SplitDivider containerRef={splitRowRef} stacked={stacked} style={{ order: 1 }} />
          <div
            className="min-h-0 min-w-0"
            style={{
              order: splitSide === "left" ? 2 : 0,
              flex: `0 0 calc(${(splitSide === "left" ? 1 - splitRatio : splitRatio) * 100}% - 3px)`,
            }}
          >
            <SplitPane />
          </div>
        </>
      )}
      </div>
    </div>
  );
}
