"use client";

/**
 * Shape recognition: its tool-bar icon and the note that appears after a
 * stroke was turned into a shape. The recognising itself is pure and lives in
 * lib/whiteboard/shapeRecognition.ts.
 */

import React, { useEffect } from "react";
import { Check, Undo2 } from "lucide-react";

/**
 * A pen beside a triangle, a circle and a square. Drawn on the 24px grid the
 * other tool icons use, same 1.8 stroke, nothing overlapping: the pen runs
 * corner to corner on the left, the three shapes sit clear of it on the right.
 */
export function ShapeAssistIcon({ size = 18, className }: { size?: number; className?: string }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.8}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden
    >
      {/* pen: nib at bottom left, rounded end at top right */}
      <path d="M3.5 17.5 4.17 13.99 11.93 3.83A1.6 1.6 0 0 1 14.47 5.77L6.71 15.93Z" />
      <path d="M4.17 13.99 6.71 15.93" />
      {/* triangle */}
      <path d="M17.6 9.4 20.3 13.8H14.9Z" />
      {/* circle */}
      <circle cx="11.3" cy="18.7" r="2.3" />
      {/* square */}
      <rect x="15.3" y="16.4" width="4.6" height="4.6" rx="0.7" />
    </svg>
  );
}

export interface ShapeNote {
  id: string;
  label: string;
  /** Screen position (px, within the canvas) to show it at. */
  x: number;
  y: number;
  key: number;
}

/**
 * "Circle ✓  Keep as drawn" - shows what the stroke became, with a one-tap
 * way back to the stroke as you drew it. Goes by itself after a few seconds.
 */
export function ShapeNoteChip({
  note,
  onKeepDrawn,
  onDone,
}: {
  note: ShapeNote;
  onKeepDrawn: () => void;
  onDone: () => void;
}) {
  useEffect(() => {
    const t = setTimeout(onDone, 3200);
    return () => clearTimeout(t);
  }, [note.key, onDone]);

  return (
    <div
      className="pointer-events-auto absolute z-30 flex -translate-x-1/2 items-center gap-0.5 rounded-full border border-white/10 bg-zinc-900/92 py-0.5 pl-2.5 pr-0.5 text-[12px] font-medium text-white shadow-xl backdrop-blur-md animate-in fade-in zoom-in-95 duration-150"
      style={{ left: note.x, top: note.y }}
      onPointerDown={(e) => e.stopPropagation()}
    >
      <Check size={13} className="text-emerald-400" />
      <span className="px-1">{note.label}</span>
      <button
        type="button"
        onClick={onKeepDrawn}
        className="flex h-7 items-center gap-1 rounded-full px-2.5 text-white/80 transition-colors hover:bg-white/10 hover:text-white"
        title="Put back the stroke exactly as you drew it"
      >
        <Undo2 size={13} />
        Keep as drawn
      </button>
    </div>
  );
}
