"use client";

/**
 * Favorite Pens Bar
 * ==================
 * A floating, movable bar of pinned pens. Each pin is a full (pen type, color,
 * size) triple, so the SAME pen type can be pinned several times in different
 * colors — that is the point of the bar.
 *
 * Interactions:
 * - Click a pin            → that pen becomes the active tool, with its color & size.
 * - Double-click / double-tap a pin → open its editor (size, color, type, move, delete).
 * - Drag a pin             → reorder within the bar.
 * - Drag the grip handle   → move the whole bar anywhere on screen (position persists).
 * - "+"                    → add a pin (starts from the pen you are currently using).
 * - Right-click (or long-press on touch) a pin → edit its type / color / size, or delete it.
 *
 * Everything here is pointer-event based (not HTML5 drag-and-drop) so it works
 * with a finger and a stylus, not just a mouse.
 */

import React, { useCallback, useEffect, useLayoutEffect, useRef, useState } from "react";
import { useWhiteboard } from "@/store/whiteboard";
import {
  PEN_COLORS,
  PEN_TYPE_PRESETS,
  getToolColor,
  getToolSize,
  type PinnedPen,
  type ToolType,
  type StrokeStyle,
} from "@/lib/whiteboard/types";
import {
  Brush,
  ChevronDown,
  ChevronUp,
  Feather,
  GripVertical,
  Highlighter,
  Paintbrush,
  Pen,
  PenLine,
  Pencil,
  Plus,
  RotateCw,
  Star,
  Trash2,
  X,
} from "lucide-react";
import {
  defaultPensBarPosition,
  PENS_BAR_HEIGHT_ESTIMATE,
} from "@/lib/whiteboard/placement";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { StepButton } from "./StepperControl";
import { cn } from "@/lib/utils";

const PEN_ICONS: Record<StrokeStyle, React.ComponentType<{ size?: number; className?: string }>> = {
  ballpoint: Pen,
  gel: Pen,
  fineliner: PenLine,
  fountain: Feather,
  brush: Brush,
  marker: Paintbrush,
  highlighter: Highlighter,
  pencil: Pencil,
  // legacy ids
  pen: Pen,
  calligraphy: Feather,
};

/** Thickness across the bar: its width when vertical, its height when horizontal. */
const BAR_THICKNESS = 56;
const PIN_SIZE = 40;
/** How far a pointer must travel before a press turns into a drag, not a click. */
const DRAG_THRESHOLD_PX = 5;

/**
 * Capture the pointer so a gesture that leaves the element still delivers
 * pointermove/up. Never let a refused capture abort the gesture — the drag
 * state is already set up by the time we get here.
 */
function capturePointer(e: React.PointerEvent) {
  try {
    (e.currentTarget as HTMLElement).setPointerCapture?.(e.pointerId);
  } catch {
    /* no active pointer (synthetic event, or pointer already released) */
  }
}

/**
 * The region the bar is allowed to live in: the canvas pane, NOT the window.
 *
 * The bar is `fixed`, so nothing kept it off the sidebar — and a default x of
 * 16 put it exactly there, covering the board list and the Link Files button.
 * The pane is MEASURED rather than derived from the sidebar's width, so the
 * backlinks panel (a second left panel) and a split view, which both move this
 * edge, are handled by the same code and cannot drift out of sync with it.
 */
function canvasArea(): { left: number; top: number; right: number; bottom: number } {
  const whole = {
    left: 0,
    top: 0,
    right: typeof window === "undefined" ? 0 : window.innerWidth,
    bottom: typeof window === "undefined" ? 0 : window.innerHeight,
  };
  if (typeof document === "undefined") return whole;
  const pane = document.querySelector("[data-wb-canvas-area]");
  if (!pane) return whole;
  const r = pane.getBoundingClientRect();
  // Before first layout the box is 0x0; clamping into that would pin the bar
  // to the top-left corner and it would never come back.
  if (r.width < 120 || r.height < 120) return whole;
  return { left: r.left, top: r.top, right: r.right, bottom: r.bottom };
}

function defaultPosition(): { x: number; y: number } {
  // Left edge of the canvas, vertically centred — one home shared by every
  // board. A saved drag always wins over this (the adopt-position effect
  // below); it only applies while there is nothing persisted yet, so existing
  // placements are left untouched. The height is a guess before first layout;
  // the mount effect re-centres exactly once the bar can be measured.
  const a = canvasArea();
  return defaultPensBarPosition(a, PENS_BAR_HEIGHT_ESTIMATE);
}

/**
 * Keep the bar inside the canvas pane. Measured in both axes, because the bar
 * can be a tall narrow rail or a wide short strip and a fixed width would
 * strand the horizontal one off the right edge.
 *
 * This also rescues a position persisted from a session with no sidebar, or
 * from a bigger window, or a tablet in the other orientation.
 *
 * Toolbar rects (tools row and, when detached, the zoom pill) are exclusion
 * zones, not just boundaries: the bar floats ABOVE them, so parking on top
 * would swallow their taps with no visible reason. Overlapping positions are
 * pushed out along the smallest penetration.
 */
function clampToCanvasArea(
  pos: { x: number; y: number },
  width: number,
  height: number
) {
  if (typeof window === "undefined") return pos;
  const a = canvasArea();
  const minX = a.left + 8;
  const minY = a.top + 8;
  const clamped = {
    x: Math.min(Math.max(minX, pos.x), Math.max(minX, a.right - width - 8)),
    y: Math.min(Math.max(minY, pos.y), Math.max(minY, a.bottom - height - 8)),
  };
  let out = clamped;
  for (const r of toolbarRects()) {
    out = pushOutOfRect(out, width, height, r);
  }
  // A push may have left the pane (toolbar hugging an edge); the pane wins,
  // because a bar half off screen is worse than a near miss.
  return {
    x: Math.min(Math.max(minX, out.x), Math.max(minX, a.right - width - 8)),
    y: Math.min(Math.max(minY, out.y), Math.max(minY, a.bottom - height - 8)),
  };
}

interface Rect {
  left: number;
  top: number;
  right: number;
  bottom: number;
}

/** Every toolbar rect: the tools row plus the detached zoom pill, if shown. */
function toolbarRects(): Rect[] {
  if (typeof document === "undefined") return [];
  const out: Rect[] = [];
  for (const el of document.querySelectorAll("[data-wb-toolbar]")) {
    const r = (el as HTMLElement).getBoundingClientRect();
    if (r.width < 8 || r.height < 8) continue;
    out.push({ left: r.left, top: r.top, right: r.right, bottom: r.bottom });
  }
  return out;
}

export function pushOutOfRect(
  pos: { x: number; y: number },
  width: number,
  height: number,
  r: Rect,
  area: Rect = canvasArea()
): { x: number; y: number } {
  const overlapX = Math.min(pos.x + width, r.right) - Math.max(pos.x, r.left);
  const overlapY = Math.min(pos.y + height, r.bottom) - Math.max(pos.y, r.top);
  if (overlapX <= 0 || overlapY <= 0) return pos;
  const M = 8;
  // How far each way the bar must travel to CLEAR the rect. (It used to move
  // by the overlap's width - enough only when the bar straddles an edge; a
  // bar narrower than the toolbar and inside it moved its own width and was
  // still on top, covering the page controls.)
  const moves = [
    { x: r.left - M - width, y: pos.y },
    { x: r.right + M, y: pos.y },
    { x: pos.x, y: r.top - M - height },
    { x: pos.x, y: r.bottom + M },
  ].filter(
    (m) => m.x >= area.left + 8 && m.x + width <= area.right - 8 && m.y >= area.top + 8 && m.y + height <= area.bottom - 8
  );
  if (!moves.length) return pos;
  moves.sort((p, q) => Math.hypot(p.x - pos.x, p.y - pos.y) - Math.hypot(q.x - pos.x, q.y - pos.y));
  return moves[0];
}

export function FavoritePensBar() {
  const pinnedPens = useWhiteboard((s) => s.pinnedPens);
  const pinnedBarOpen = useWhiteboard((s) => s.pinnedBarOpen);
  const storedPos = useWhiteboard((s) => s.pinnedBarPos);
  const tool = useWhiteboard((s) => s.tool);
  const style = useWhiteboard((s) => s.style);
  const applyPinnedPen = useWhiteboard((s) => s.applyPinnedPen);
  const pinCurrentPen = useWhiteboard((s) => s.pinCurrentPen);
  const updatePinnedPen = useWhiteboard((s) => s.updatePinnedPen);
  const removePinnedPen = useWhiteboard((s) => s.removePinnedPen);
  const reorderPinnedPens = useWhiteboard((s) => s.reorderPinnedPens);
  const setPinnedBarPos = useWhiteboard((s) => s.setPinnedBarPos);
  const togglePinnedBar = useWhiteboard((s) => s.togglePinnedBar);
  const vertical = useWhiteboard((s) => s.pinnedBarVertical);
  const toggleOrientation = useWhiteboard((s) => s.togglePinnedBarOrientation);
  // Subscribe so a dock-edge change re-renders: moving the toolbar does not
  // resize the canvas pane (so the observer below never fires), but it moves
  // the exclusion zone, and the render clamp must push the bar out of it.
  // The value itself is unused — the subscription is the point.
  useWhiteboard((s) => s.toolbarPosition);

  const barRef = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState<{ x: number; y: number }>(() => storedPos ?? defaultPosition());
  // Mirror of `pos` so drag-end can persist the final position without reading
  // it from inside a state updater (that would be a setState during render).
  const posRef = useRef(pos);
  posRef.current = pos;
  // Snapshot of whether a position was already persisted when we mounted, so
  // the mount-once effect below can tell "fresh workspace" from "late storage
  // load" without taking dependencies (a saved drag must always win).
  const hadStoredPosRef = useRef(storedPos != null);
  const [editingPin, setEditingPin] = useState<string | null>(null);

  // Bar drag (move the whole bar)
  const barDragRef = useRef<{ dx: number; dy: number; moved: boolean } | null>(null);
  const [movingBar, setMovingBar] = useState(false);

  // Pin drag (reorder)
  const pinDragRef = useRef<{
    id: string;
    fromIndex: number;
    startX: number;
    startY: number;
    dragging: boolean;
  } | null>(null);
  const [dragPinId, setDragPinId] = useState<string | null>(null);
  const [dropIndex, setDropIndex] = useState<number | null>(null);
  // Last tap per pin, for double-click / double-tap to open the editor.
  // Timed on pointer-up (not the dblclick event) because a mobile WebView
  // with zoom disabled never fires dblclick.
  const lastTapRef = useRef<Record<string, number>>({});
  /** Double-tap window. Long enough for a finger, short enough to feel instant. */
  const DOUBLE_TAP_MS = 350;

  // Adopt a position saved by an earlier session once it arrives from storage.
  useEffect(() => {
    if (storedPos) setPos(storedPos);
  }, [storedPos]);

  const splitSide = useWhiteboard((s) => s.splitSide);
  const splitRatio = useWhiteboard((s) => s.splitRatio);
  const splitBoardId = useWhiteboard((s) => s.splitBoardId);
  /** Where the canvas pane was last seen, so a move can carry the bar along. */
  const paneOriginRef = useRef<{ left: number; top: number } | null>(null);
  const followPane = () => {
    const area = canvasArea();
    const prev = paneOriginRef.current;
    paneOriginRef.current = { left: area.left, top: area.top };
    setPos((p) => {
      const carried = prev ? { x: p.x + (area.left - prev.left), y: p.y + (area.top - prev.top) } : p;
      return clampToCanvasArea(
        carried,
        barRef.current?.offsetWidth ?? BAR_THICKNESS,
        barRef.current?.offsetHeight ?? 200
      );
    });
  };

  // Re-clamp whenever the canvas pane changes size so the bar can never be
  // stranded. A plain resize listener is not enough: the window can be resized
  // while the app is backgrounded, Electron/Android restore a size after mount,
  // and — the case this bar kept getting wrong — opening the sidebar or the
  // backlinks panel narrows the pane without any window resize at all. So we
  // observe the PANE, which changes in every one of those cases.
  useEffect(() => {
    // Fresh workspace (nothing dragged + persisted yet): centre exactly with
    // the measured height — the useState initialiser had to guess it before
    // first layout. Runs once; any drag after this owns `pos` from then on,
    // and a position arriving late from storage still wins via the effect above.
    if (!hadStoredPosRef.current && barRef.current && barRef.current.offsetHeight > 0) {
      setPos(defaultPensBarPosition(canvasArea(), barRef.current.offsetHeight));
    }
    const reclamp = () => followPane();
    reclamp();
    window.addEventListener("resize", reclamp);
    const ro = new ResizeObserver(reclamp);
    ro.observe(document.querySelector("[data-wb-canvas-area]") ?? document.documentElement);
    // The toolbar too: it grows (tools wrapping onto another row, the colour
    // row unfolding) without the pane changing size, and the bar was left
    // sitting on top of the page controls.
    for (const el of document.querySelectorAll("[data-wb-toolbar]")) ro.observe(el);
    return () => {
      window.removeEventListener("resize", reclamp);
      ro.disconnect();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // In split view the live pane can MOVE without changing size - swapping
  // sides slides it from one half to the other at the same width - and a
  // ResizeObserver never fires for a move. The bar was left behind, floating
  // over the other document. So the pane's position is watched too: when the
  // live half moves, the bar moves with it and keeps its spot inside it.
  //
  // A layout effect, not requestAnimationFrame. The DOM is already committed
  // here, so the pane's new position can be read at once; waiting a frame
  // added nothing but a dependency on rAF, which NEVER fires while the page is
  // hidden - measured: the bar was left behind every time.
  useLayoutEffect(() => {
    followPane();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [splitSide, splitRatio, splitBoardId]);

  // ---- moving the bar -------------------------------------------------------
  const onGripPointerDown = (e: React.PointerEvent) => {
    e.preventDefault();
    e.stopPropagation();
    barDragRef.current = { dx: e.clientX - pos.x, dy: e.clientY - pos.y, moved: false };
    setMovingBar(true);
    capturePointer(e);
  };

  const onGripPointerMove = (e: React.PointerEvent) => {
    const drag = barDragRef.current;
    if (!drag) return;
    drag.moved = true;
    setPos(
      clampToCanvasArea(
        { x: e.clientX - drag.dx, y: e.clientY - drag.dy },
        barRef.current?.offsetWidth ?? BAR_THICKNESS,
        barRef.current?.offsetHeight ?? 200
      )
    );
  };

  const endBarDrag = useCallback(() => {
    const drag = barDragRef.current;
    barDragRef.current = null;
    if (!drag) return;
    setMovingBar(false);
    // A tap on the grip never moved: persisting would pointlessly rewrite
    // storage (and re-trigger the adopt-position effect) on every tap.
    if (drag.moved) setPinnedBarPos(posRef.current);
  }, [setPinnedBarPos]);

  // ---- reordering pins ------------------------------------------------------
  const onPinPointerDown = (e: React.PointerEvent, pin: PinnedPen, index: number) => {
    // Only the primary button starts a drag; right-click opens the browser menu.
    if (e.button !== 0) return;
    pinDragRef.current = {
      id: pin.id,
      fromIndex: index,
      startX: e.clientX,
      startY: e.clientY,
      dragging: false,
    };
    capturePointer(e);
  };

  /**
   * Which slot a drag is over. Measured along the bar's own axis — using Y
   * while the bar is horizontal would make every drop land on the same slot.
   */
  const indexFromPointer = (clientX: number, clientY: number): number => {
    const bar = barRef.current;
    if (!bar) return 0;
    const buttons = [...bar.querySelectorAll("[data-pin-index]")] as HTMLElement[];
    for (let i = 0; i < buttons.length; i++) {
      const r = buttons[i].getBoundingClientRect();
      const midpoint = vertical ? r.top + r.height / 2 : r.left + r.width / 2;
      const along = vertical ? clientY : clientX;
      if (along < midpoint) return i;
    }
    return buttons.length - 1;
  };

  const onPinPointerMove = (e: React.PointerEvent) => {
    const drag = pinDragRef.current;
    if (!drag) return;
    if (!drag.dragging) {
      const moved = Math.hypot(e.clientX - drag.startX, e.clientY - drag.startY);
      if (moved < DRAG_THRESHOLD_PX) return; // still a click, not a drag
      drag.dragging = true;
      // A drag is not a tap: forget tap history so a tap, drag, tap sequence
      // cannot combine into a phantom double-tap that opens the editor.
      lastTapRef.current = {};
      setDragPinId(drag.id);
    }
    setDropIndex(indexFromPointer(e.clientX, e.clientY));
  };

  const onPinPointerUp = (e: React.PointerEvent, pin: PinnedPen, index: number) => {
    const drag = pinDragRef.current;
    pinDragRef.current = null;

    if (drag?.dragging) {
      const target = indexFromPointer(e.clientX, e.clientY);
      if (target !== index) reorderPinnedPens(index, target);
    } else {
      // A press that never became a drag is a plain click: use this pen —
      // unless it is the second tap of a double-tap, which opens the editor.
      const now = Date.now();
      const last = lastTapRef.current[pin.id] ?? 0;
      if (now - last < DOUBLE_TAP_MS) {
        delete lastTapRef.current[pin.id];
        setEditingPin(pin.id);
      } else {
        lastTapRef.current[pin.id] = now;
        applyPinnedPen(pin.id);
      }
    }
    setDragPinId(null);
    setDropIndex(null);
  };

  const cancelPinDrag = () => {
    // A cancelled press is not a tap: forget it, or a tap, cancel, tap
    // sequence would combine into a phantom double-tap that opens the editor.
    if (pinDragRef.current) delete lastTapRef.current[pinDragRef.current.id];
    pinDragRef.current = null;
    setDragPinId(null);
    setDropIndex(null);
  };

  if (!pinnedBarOpen) return null;

  // Clamp at RENDER time, not only in a resize handler. `pos` is the position
  // the user chose; this is where it is actually allowed to sit right now. A
  // listener alone is not enough — a window can be resized while the app is
  // backgrounded, and Electron/Android restore a size without a resize event —
  // and a stale position leaves the bar stranded off screen where it cannot be
  // dragged back.
  const renderPos = clampToCanvasArea(
    pos,
    barRef.current?.offsetWidth ?? BAR_THICKNESS,
    barRef.current?.offsetHeight ?? 200
  );

  // Read through the accessors. This used to index `style["gelColor"]` by
  // string, which stopped existing when per-tool ink moved into a map — so the
  // pin you were actually drawing with never showed as selected.
  const isPinActive = (pin: PinnedPen) =>
    tool === pin.tool &&
    getToolColor(style, pin.tool as ToolType).toLowerCase() === pin.color.toLowerCase() &&
    getToolSize(style, pin.tool as ToolType) === pin.size;

  return (
    <div
      ref={barRef}
      className={cn(
        // touch-none + select-none: without them a finger drag on the grip or
        // a pin is hijacked by the browser for scroll/pan, the gesture dies
        // with a pointercancel, and the bar looks stuck where it is. Every
        // other touch-drag surface (canvas, minimap, page grip, steppers)
        // already has it; this one was missed. Taps still click, and the pin
        // editor lives in a portal outside this tree so its slider is unaffected.
        "fixed z-40 flex touch-none select-none items-center gap-1.5 rounded-2xl border border-border bg-background/95 p-1.5 shadow-lg backdrop-blur",
        vertical ? "flex-col" : "flex-row",
        movingBar && "cursor-grabbing select-none"
      )}
      style={
        vertical
          ? { left: renderPos.x, top: renderPos.y, width: BAR_THICKNESS }
          : { left: renderPos.x, top: renderPos.y, height: BAR_THICKNESS }
      }
      // The canvas binds window-level shortcuts; keep bar interaction local.
      onPointerDown={(e) => e.stopPropagation()}
    >
      {/* Grip — drag to move the whole bar */}
      <div
        className={cn(
          "flex cursor-grab items-center justify-center rounded-lg text-muted-foreground hover:bg-muted active:cursor-grabbing",
          vertical ? "w-full py-0.5" : "h-full px-0.5"
        )}
        onPointerDown={onGripPointerDown}
        onPointerMove={onGripPointerMove}
        onPointerUp={endBarDrag}
        onPointerCancel={endBarDrag}
        onLostPointerCapture={endBarDrag}
        title="Drag to move the favorites bar"
      >
        <GripVertical size={14} className={vertical ? "" : "rotate-90"} />
      </div>

      {pinnedPens.length === 0 && (
        <div className="px-1 pb-1 text-center text-[9px] leading-tight text-muted-foreground">
          Pin your pens
        </div>
      )}

      {pinnedPens.map((pin, index) => {
        const Icon = PEN_ICONS[pin.tool] ?? Pen;
        const active = isPinActive(pin);
        const isDragging = dragPinId === pin.id;
        const showDropLine = dropIndex === index && dragPinId !== null && !isDragging;

        return (
          <div key={pin.id} className={cn("relative", vertical ? "w-full" : "h-full")}>
            {showDropLine && (
              <div
                className={cn(
                  "absolute rounded bg-primary",
                  vertical ? "-top-1 left-1 right-1 h-0.5" : "-left-1 top-1 bottom-1 w-0.5"
                )}
              />
            )}
            <Popover
              open={editingPin === pin.id}
              onOpenChange={(o) => setEditingPin(o ? pin.id : null)}
            >
              <PopoverTrigger asChild>
                <button
                  data-pin-index={index}
                  onPointerDown={(e) => onPinPointerDown(e, pin, index)}
                  onPointerMove={onPinPointerMove}
                  onPointerUp={(e) => onPinPointerUp(e, pin, index)}
                  onPointerCancel={cancelPinDrag}
                  onLostPointerCapture={cancelPinDrag}
                  onContextMenu={(e) => {
                    e.preventDefault();
                    setEditingPin(pin.id);
                  }}
                  // The popover must open from the edit affordance, never from
                  // a plain click — a plain click selects the pen.
                  onClick={(e) => e.preventDefault()}
                  title={`${PEN_TYPE_PRESETS[pin.tool].label} · ${pin.size}px — click to use, double-click for options, drag to reorder, right-click or long-press to edit`}
                  className={cn(
                    "relative flex w-full items-center justify-center rounded-xl border transition-all",
                    active
                      ? "border-primary bg-primary/10 ring-2 ring-primary"
                      : "border-transparent hover:bg-muted",
                    isDragging && "opacity-40"
                  )}
                  style={{ height: PIN_SIZE }}
                >
                  <Icon size={18} className="drop-shadow-sm" />
                  {/* Colour + thickness read-out: the swatch height tracks the
                      pen's actual size so two pins of one type are tellable. */}
                  <span
                    className="absolute bottom-1 left-1/2 -translate-x-1/2 rounded-full border border-background"
                    style={{
                      backgroundColor: pin.color,
                      width: 18,
                      height: Math.max(2, Math.min(7, pin.size / 4)),
                    }}
                  />
                </button>
              </PopoverTrigger>
              <PopoverContent side={pos.x < 260 ? "right" : "left"} align="start" className="w-60 space-y-3 p-3">
                <PinEditor
                  pin={pin}
                  onChange={(patch) => updatePinnedPen(pin.id, patch)}
                  onMoveEarlier={
                    index > 0 ? () => reorderPinnedPens(index, index - 1) : undefined
                  }
                  onMoveLater={
                    index < pinnedPens.length - 1
                      ? () => reorderPinnedPens(index, index + 1)
                      : undefined
                  }
                  onDelete={() => {
                    removePinnedPen(pin.id);
                    setEditingPin(null);
                  }}
                />
              </PopoverContent>
            </Popover>
          </div>
        );
      })}

      {/* Add — pins whatever pen is currently selected, then opens its editor */}
      <button
        onClick={() => {
          const id = pinCurrentPen();
          if (id) setEditingPin(id);
        }}
        title="Pin the current pen to favorites"
        className={cn(
          "flex items-center justify-center rounded-xl border border-dashed border-border text-muted-foreground transition-colors hover:border-primary hover:text-primary",
          vertical ? "w-full py-2" : "h-full px-2"
        )}
      >
        <Plus size={16} />
      </button>

      <button
        onClick={toggleOrientation}
        title={vertical ? "Rotate: lay the bar flat" : "Rotate: stand the bar upright"}
        aria-label="Rotate the favorites bar"
        className={cn(
          "flex items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-muted hover:text-foreground",
          vertical ? "w-full py-1" : "h-full px-1"
        )}
      >
        <RotateCw size={13} />
      </button>

      <button
        onClick={togglePinnedBar}
        title="Hide favorites bar"
        className={cn(
          "flex items-center justify-center rounded-lg text-muted-foreground hover:text-foreground",
          vertical ? "w-full py-0.5" : "h-full px-0.5"
        )}
      >
        <X size={12} />
      </button>
    </div>
  );
}

/** Type / colour / size editor for one pinned pen. */
function PinEditor({
  pin,
  onChange,
  onMoveEarlier,
  onMoveLater,
  onDelete,
}: {
  pin: PinnedPen;
  onChange: (patch: Partial<Omit<PinnedPen, "id">>) => void;
  /** Absent at the ends of the list, where there is nowhere to move. */
  onMoveEarlier?: () => void;
  onMoveLater?: () => void;
  onDelete: () => void;
}) {
  const [customColor, setCustomColor] = useState(pin.color);

  return (
    <>
      <div className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
        <Star size={12} /> Favorite pen
      </div>

      <div>
        <div className="mb-1 text-[11px] text-muted-foreground">Pen type</div>
        <div className="grid grid-cols-3 gap-1">
          {(Object.keys(PEN_TYPE_PRESETS) as StrokeStyle[]).map((st) => {
            const Icon = PEN_ICONS[st];
            return (
              <button
                key={st}
                onClick={() => onChange({ tool: st })}
                className={cn(
                  "flex flex-col items-center gap-0.5 rounded-lg border p-1.5 text-[10px] font-medium transition-colors",
                  pin.tool === st
                    ? "border-primary bg-primary/10 text-primary"
                    : "border-border hover:bg-muted"
                )}
              >
                <Icon size={14} />
                {PEN_TYPE_PRESETS[st].label}
              </button>
            );
          })}
        </div>
      </div>

      <div>
        <div className="mb-1 text-[11px] text-muted-foreground">Color</div>
        <div className="flex flex-wrap gap-1">
          {PEN_COLORS.map((c) => (
            <button
              key={c}
              onClick={() => onChange({ color: c })}
              className={cn(
                "h-5 w-5 rounded-full border transition-transform",
                pin.color === c ? "scale-110 border-foreground ring-2 ring-primary" : "border-border"
              )}
              style={{ backgroundColor: c }}
              title={c}
            />
          ))}
          {/* Any colour, not just the presets */}
          <label
            className="flex h-5 w-5 cursor-pointer items-center justify-center rounded-full border border-dashed border-border text-[9px]"
            title="Custom color"
          >
            <input
              type="color"
              value={customColor}
              onChange={(e) => {
                setCustomColor(e.target.value);
                onChange({ color: e.target.value });
              }}
              className="h-0 w-0 opacity-0"
            />
            +
          </label>
        </div>
      </div>

      <div>
        <div className="mb-1 flex items-center justify-between text-[11px] text-muted-foreground">
          <span>Size</span>
          <span className="tabular-nums">{pin.size}px</span>
        </div>
        <div className="flex items-center gap-2">
          <StepButton
            direction={-1}
            value={pin.size}
            min={1}
            max={64}
            onChange={(size) => onChange({ size })}
          />
          <Slider
            value={[pin.size]}
            min={1}
            max={64}
            step={1}
            onValueChange={([v]) => onChange({ size: v })}
          />
          <StepButton
            direction={1}
            value={pin.size}
            min={1}
            max={64}
            onChange={(size) => onChange({ size })}
          />
        </div>
      </div>

      <div>
        <div className="mb-1 text-[11px] text-muted-foreground">Position in the bar</div>
        <div className="flex gap-1">
          <button
            onClick={onMoveEarlier}
            disabled={!onMoveEarlier}
            className="flex flex-1 items-center justify-center gap-1 rounded-lg border border-border px-2 py-1.5 text-[11px] font-medium transition-colors hover:bg-muted disabled:pointer-events-none disabled:opacity-40"
          >
            <ChevronUp size={13} /> Earlier
          </button>
          <button
            onClick={onMoveLater}
            disabled={!onMoveLater}
            className="flex flex-1 items-center justify-center gap-1 rounded-lg border border-border px-2 py-1.5 text-[11px] font-medium transition-colors hover:bg-muted disabled:pointer-events-none disabled:opacity-40"
          >
            Later <ChevronDown size={13} />
          </button>
        </div>
      </div>

      <Button variant="ghost" size="sm" className="w-full text-destructive" onClick={onDelete}>
        <Trash2 size={14} className="mr-1" /> Remove pin
      </Button>
    </>
  );
}
