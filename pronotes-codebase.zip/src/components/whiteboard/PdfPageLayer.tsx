"use client";

/**
 * Draws the PDF page that sits underneath a notebook page's ink.
 *
 * Pages are rasterised on demand and cached in memory, keyed by document,
 * page and render width. A 90-page lecture PDF must never be rendered all at
 * once — only the sheets the viewport can reach are asked for, and the cache
 * stops a page being re-rendered every time you scroll past it.
 *
 * The cache is memory-only on purpose. Persisting the rasters is exactly the
 * mistake this whole design avoids: it is the thing that would blow the
 * storage budget. Re-rendering after a restart costs a few milliseconds.
 */

import React from "react";
import type { PDFDocumentProxy } from "pdfjs-dist";
import type { PdfPageRef } from "@/lib/whiteboard/types";

/** Rendered page images, keyed `docId:pageNumber:width`. */
const rasterCache = new Map<string, string>();
/** In-flight renders, so scrolling quickly cannot start the same one twice. */
const inFlight = new Map<string, Promise<string>>();

/** Open documents are shared with the text layer (see `openStoredPdf`). */
async function docFor(docId: string): Promise<PDFDocumentProxy> {
  const { openStoredPdf } = await import("@/lib/whiteboard/pdf");
  return openStoredPdf(docId);
}

async function rasterFor(ref: PdfPageRef, width: number): Promise<string> {
  const key = `${ref.docId}:${ref.pageNumber}:${Math.round(width)}`;
  const cached = rasterCache.get(key);
  if (cached) return cached;

  let pending = inFlight.get(key);
  if (!pending) {
    pending = (async () => {
      const { renderPdfPage } = await import("@/lib/whiteboard/pdf");
      const doc = await docFor(ref.docId);
      const url = await renderPdfPage(doc, ref.pageNumber, width);
      rasterCache.set(key, url);
      return url;
    })();
    inFlight.set(key, pending);
    pending.finally(() => inFlight.delete(key));
  }
  return pending;
}

export function PdfPageLayer({
  pdf,
  width,
  height,
}: {
  pdf: PdfPageRef;
  width: number;
  height: number;
}) {
  const [href, setHref] = React.useState<string | null>(null);
  const [failed, setFailed] = React.useState<string | null>(null);

  React.useEffect(() => {
    let alive = true;
    setFailed(null);
    rasterFor(pdf, width).then(
      (url) => {
        if (alive) setHref(url);
      },
      (err: Error) => {
        if (alive) setFailed(err.message);
      }
    );
    return () => {
      alive = false;
    };
  }, [pdf.docId, pdf.pageNumber, width]);

  if (failed) {
    return (
      <g pointerEvents="none">
        <rect x={0} y={0} width={width} height={height} fill="#fff" />
        <text
          x={width / 2}
          y={height / 2}
          textAnchor="middle"
          fontSize={Math.max(12, width / 40)}
          fill="#b91c1c"
        >
          {failed}
        </text>
      </g>
    );
  }

  if (!href) {
    // A plain sheet while the raster arrives — never a spinner that would
    // redraw on every scroll frame.
    return <rect x={0} y={0} width={width} height={height} fill="#fff" pointerEvents="none" />;
  }

  // "meet", not "none". A notebook made FROM a PDF has sheets the exact shape
  // of its pages, so either setting looks identical there - but pages can now
  // be inserted into a notebook of a different shape, and stretching someone's
  // lecture slide to fit A4 is a silent corruption of what they imported.
  // Letterboxing keeps the page's own proportions and centres it on the sheet.
  return (
    <image
      href={href}
      x={0}
      y={0}
      width={width}
      height={height}
      preserveAspectRatio="xMidYMid meet"
      pointerEvents="none"
    />
  );
}
