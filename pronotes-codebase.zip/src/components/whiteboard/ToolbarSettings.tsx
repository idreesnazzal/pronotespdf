"use client";

/**
 * The tool bar's own "Customize" panel: choose which buttons it holds and in
 * what order. Removing one only hides the button - the tool, its settings and its
 * shortcut key all stay - and "Reset" brings back the full default bar.
 */

import React from "react";
import {
  ArrowDown,
  ArrowUp,
  Eraser,
  Hand,
  Image as ImageIcon,
  Link2,
  MinusCircle,
  MousePointer2,
  Pen,
  PlusCircle,
  RotateCcw,
  Shapes,
  StickyNote,
  Type,
} from "lucide-react";
import { useWhiteboard } from "@/store/whiteboard";
import { ALL_TOOLBAR_ITEMS, DEFAULT_TOOLBAR_ITEMS, TOOLBAR_ITEMS, type ToolbarItemId } from "@/lib/whiteboard/types";
import { LaserIcon } from "./LaserPointer";
import { ShapeAssistIcon } from "./ShapeAssist";
import { TextSelectIcon } from "./PdfTextSelect";
import { cn } from "@/lib/utils";

const ICONS: Record<ToolbarItemId, React.ReactNode> = {
  select: <MousePointer2 size={15} />,
  pan: <Hand size={15} />,
  textselect: <TextSelectIcon size={15} />,
  pen: <Pen size={15} />,
  eraser: <Eraser size={15} />,
  laser: <LaserIcon size={15} />,
  autoshape: <ShapeAssistIcon size={15} />,
  shapes: <Shapes size={15} />,
  connect: <Link2 size={15} />,
  text: <Type size={15} />,
  sticky: <StickyNote size={15} />,
  image: <ImageIcon size={15} />,
};

const labelOf = (id: ToolbarItemId) => TOOLBAR_ITEMS.find((t) => t.id === id)?.label ?? id;

function IconButton({
  onClick,
  disabled,
  label,
  children,
  tone = "plain",
}: {
  onClick: () => void;
  disabled?: boolean;
  label: string;
  children: React.ReactNode;
  tone?: "plain" | "remove" | "add";
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      title={label}
      aria-label={label}
      className={cn(
        "flex h-8 w-8 shrink-0 items-center justify-center rounded-lg transition-colors disabled:pointer-events-none disabled:opacity-25",
        tone === "remove" && "text-red-500 hover:bg-red-500/10",
        tone === "add" && "text-emerald-600 hover:bg-emerald-500/10 dark:text-emerald-400",
        tone === "plain" && "text-muted-foreground hover:bg-muted hover:text-foreground"
      )}
    >
      {children}
    </button>
  );
}

export function ToolbarCustomizer() {
  const items = useWhiteboard((s) => s.toolbarItems);
  const setItems = useWhiteboard((s) => s.setToolbarItems);
  const hidden = ALL_TOOLBAR_ITEMS.filter((id) => !items.includes(id));
  const isDefault = items.join() === DEFAULT_TOOLBAR_ITEMS.join();

  const move = (i: number, by: -1 | 1) => {
    const j = i + by;
    if (j < 0 || j >= items.length) return;
    const next = [...items];
    [next[i], next[j]] = [next[j], next[i]];
    setItems(next);
  };
  const remove = (id: ToolbarItemId) => setItems(items.filter((x) => x !== id));
  // An added button goes back to its place in the default order, as near as
  // the current order allows, rather than always to the end.
  const add = (id: ToolbarItemId) => {
    const order = ALL_TOOLBAR_ITEMS;
    const next = [...items];
    const after = order.slice(0, order.indexOf(id)).reverse().find((x) => next.includes(x));
    next.splice(after ? next.indexOf(after) + 1 : 0, 0, id);
    setItems(next);
  };

  return (
    <div className="space-y-2 px-2">
      <div className="overflow-hidden rounded-xl border border-border">
        {items.map((id, i) => (
          <div
            key={id}
            className={cn("flex items-center gap-2 bg-background px-2 py-1", i > 0 && "border-t border-border/70")}
          >
            <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-muted text-foreground">
              {ICONS[id]}
            </span>
            <span className="min-w-0 flex-1 truncate text-[13px]">{labelOf(id)}</span>
            <IconButton onClick={() => move(i, -1)} disabled={i === 0} label={`Move ${labelOf(id)} earlier`}>
              <ArrowUp size={15} />
            </IconButton>
            <IconButton onClick={() => move(i, 1)} disabled={i === items.length - 1} label={`Move ${labelOf(id)} later`}>
              <ArrowDown size={15} />
            </IconButton>
            <IconButton
              onClick={() => remove(id)}
              // The last button stays: an empty tool bar could not be put back
              // from itself.
              disabled={items.length === 1}
              label={`Remove ${labelOf(id)} from the tool bar`}
              tone="remove"
            >
              <MinusCircle size={16} />
            </IconButton>
          </div>
        ))}
      </div>

      {hidden.length > 0 && (
        <div>
          <div className="px-1 pb-1 text-[11px] text-muted-foreground">Not in the tool bar</div>
          <div className="overflow-hidden rounded-xl border border-dashed border-border">
            {hidden.map((id, i) => (
              <div
                key={id}
                className={cn("flex items-center gap-2 px-2 py-1", i > 0 && "border-t border-dashed border-border/70")}
              >
                <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg text-muted-foreground">
                  {ICONS[id]}
                </span>
                <span className="min-w-0 flex-1 truncate text-[13px] text-muted-foreground">{labelOf(id)}</span>
                <IconButton onClick={() => add(id)} label={`Add ${labelOf(id)} to the tool bar`} tone="add">
                  <PlusCircle size={16} />
                </IconButton>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="flex items-center justify-between gap-2 px-1">
        <p className="text-[11px] leading-snug text-muted-foreground">
          Removing a button only hides it; its keyboard shortcut still works.
        </p>
        <button
          type="button"
          onClick={() => setItems([...DEFAULT_TOOLBAR_ITEMS])}
          disabled={isDefault}
          className="flex shrink-0 items-center gap-1 rounded-lg px-2 py-1 text-[11px] font-medium text-primary transition-colors hover:bg-primary/10 disabled:pointer-events-none disabled:opacity-40"
        >
          <RotateCcw size={12} />
          Reset
        </button>
      </div>
    </div>
  );
}
