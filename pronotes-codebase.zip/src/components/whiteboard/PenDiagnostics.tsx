"use client";

/**
 * Pen diagnostics overlay.
 *
 * Why this exists
 * ---------------
 * Hold-to-erase was written against the Pointer Events spec, where a stylus
 * side button is `buttons & 2` and the eraser end is `buttons & 32`. That is
 * correct on paper, and it is what Windows delivers — but it did NOT work on a
 * real Samsung tablet, and no amount of reading settles what one particular
 * device and WebView version actually send.
 *
 * Chromium on Android has several ways it MIGHT report the S Pen button:
 *   - `buttons & 2` on pointerdown/pointermove (what the spec implies)
 *   - `buttons & 32` (the eraser end)
 *   - a `contextmenu` event, with nothing in `buttons` at all
 *   - only while the nib is in contact, never on hover
 *   - nothing whatsoever (the BLE remote button never reaches web content)
 *
 * So this panel prints what actually arrives. Hold the button, read the
 * numbers, and it stops being a guess.
 */

import React from "react";
import { X, Copy, Check } from "lucide-react";
import { useWhiteboard } from "@/store/whiteboard";

interface Row {
  n: number;
  type: string;
  pointerType: string;
  button: number;
  buttons: number;
  pressure: number;
  w: number;
  h: number;
  tiltX: number;
  tiltY: number;
}

/** Names the bits, so the readout needs no decoding by hand. */
function describeButtons(b: number): string {
  if (b === 0) return "none";
  const names: string[] = [];
  if (b & 1) names.push("1 nib");
  if (b & 2) names.push("2 BARREL");
  if (b & 4) names.push("4 middle");
  if (b & 8) names.push("8 X1");
  if (b & 16) names.push("16 X2");
  if (b & 32) names.push("32 ERASER");
  const known = 1 | 2 | 4 | 8 | 16 | 32;
  if (b & ~known) names.push((b & ~known) + " other");
  return names.join(" + ");
}

export function PenDiagnostics() {
  const on = useWhiteboard((s) => s.touchSettings.penDiagnostics === true);
  const setTouchSettings = useWhiteboard((s) => s.setTouchSettings);

  const [rows, setRows] = React.useState<Row[]>([]);
  const [live, setLive] = React.useState<{ buttons: number; pointerType: string } | null>(null);
  const [copied, setCopied] = React.useState(false);
  const seqRef = React.useRef(0);
  // pointermove fires hundreds of times a second. Only a CHANGE in the button
  // state is interesting; logging every move would bury it instantly.
  const lastMoveKeyRef = React.useRef("");

  React.useEffect(() => {
    if (!on) return;

    const push = (e: PointerEvent, type: string) => {
      seqRef.current += 1;
      const row: Row = {
        n: seqRef.current,
        type,
        pointerType: e.pointerType,
        button: e.button,
        buttons: e.buttons,
        pressure: Math.round((e.pressure ?? 0) * 100) / 100,
        w: Math.round(e.width ?? 0),
        h: Math.round(e.height ?? 0),
        tiltX: e.tiltX ?? 0,
        tiltY: e.tiltY ?? 0,
      };
      setRows((r) => [row, ...r].slice(0, 14));
    };

    const onDown = (e: PointerEvent) => push(e, "down");
    const onUp = (e: PointerEvent) => push(e, "up");
    const onMove = (e: PointerEvent) => {
      setLive({ buttons: e.buttons, pointerType: e.pointerType });
      const key = e.pointerType + ":" + e.buttons + ":" + e.button;
      if (key === lastMoveKeyRef.current) return;
      lastMoveKeyRef.current = key;
      push(e, "move*");
    };
    const onCtx = (e: Event) => {
      seqRef.current += 1;
      const pe = e as PointerEvent;
      setRows((r) =>
        [
          {
            n: seqRef.current,
            type: "CONTEXTMENU",
            pointerType: pe.pointerType ?? "?",
            button: pe.button ?? -1,
            buttons: pe.buttons ?? -1,
            pressure: 0,
            w: 0,
            h: 0,
            tiltX: 0,
            tiltY: 0,
          },
          ...r,
        ].slice(0, 14)
      );
    };

    // The native bridge (MainActivity.java). On Android this is the ONLY route
    // that sees the S Pen side button, so it gets its own clearly marked row.
    const onNative = (e: Event) => {
      const d = (e as CustomEvent).detail ?? {};
      seqRef.current += 1;
      setRows((r) =>
        [
          {
            n: seqRef.current,
            // `because` names the MotionEvent that decided it, so a wrong
            // decision says which rule got it wrong instead of just "up".
            type: (d.pressed ? "NATIVE down" : "NATIVE up") + (d.because ? " · " + d.because : ""),
            pointerType: "native",
            button: d.toolType ?? -1,
            buttons: d.buttonState ?? -1,
            pressure: 0,
            w: 0,
            h: 0,
            tiltX: 0,
            tiltY: 0,
          },
          ...r,
        ].slice(0, 14)
      );
    };

    // Capture phase, on window: the canvas calls preventDefault and stops
    // propagation in places, and a diagnostic the app can silence would report
    // "nothing arrived" when something did.
    const opt = { capture: true, passive: true } as AddEventListenerOptions;
    window.addEventListener("pointerdown", onDown, opt);
    window.addEventListener("pointerup", onUp, opt);
    window.addEventListener("pointermove", onMove, opt);
    window.addEventListener("contextmenu", onCtx, { capture: true });
    window.addEventListener("pronotes:stylusbutton", onNative);
    return () => {
      window.removeEventListener("pronotes:stylusbutton", onNative);
      window.removeEventListener("pointerdown", onDown, opt);
      window.removeEventListener("pointerup", onUp, opt);
      window.removeEventListener("pointermove", onMove, opt);
      window.removeEventListener("contextmenu", onCtx, { capture: true });
    };
  }, [on]);

  if (!on) return null;

  const asText = () =>
    [
      "ua: " + (typeof navigator !== "undefined" ? navigator.userAgent : "?"),
      "maxTouchPoints: " + (typeof navigator !== "undefined" ? navigator.maxTouchPoints : "?"),
      "n type ptrType button buttons pressure w h tiltX tiltY",
      ...rows.map((r) =>
        [r.n, r.type, r.pointerType, r.button, r.buttons, r.pressure, r.w, r.h, r.tiltX, r.tiltY].join(" ")
      ),
    ].join("\n");

  return (
    <div
      data-wb-modal
      className="fixed bottom-2 left-1/2 z-[200] w-[min(680px,96vw)] -translate-x-1/2 rounded-xl border border-border bg-background/95 p-2 shadow-2xl backdrop-blur"
    >
      <div className="mb-1 flex items-center gap-2">
        <span className="text-[11px] font-semibold">Pen diagnostics</span>
        <span className="text-[10px] text-muted-foreground">
          hover the pen, then hold its side button
        </span>
        <div className="ml-auto flex items-center gap-1">
          <button
            onClick={async () => {
              try {
                await navigator.clipboard.writeText(asText());
                setCopied(true);
                setTimeout(() => setCopied(false), 1500);
              } catch {
                // Clipboard is often refused inside an Android WebView. The
                // panel stays readable on screen precisely so a screenshot
                // works when this fails.
                setCopied(false);
              }
            }}
            className="rounded-md px-1.5 py-1 text-muted-foreground hover:bg-muted"
            title="Copy the log"
          >
            {copied ? <Check size={13} /> : <Copy size={13} />}
          </button>
          <button
            onClick={() => setTouchSettings({ penDiagnostics: false })}
            className="rounded-md px-1.5 py-1 text-muted-foreground hover:bg-muted"
            title="Close diagnostics"
          >
            <X size={13} />
          </button>
        </div>
      </div>

      {/* The one number that answers the question, large enough to read at
          arm's length while the other hand holds the pen. */}
      <div className="mb-1 rounded-lg bg-muted/60 px-2 py-1.5">
        <div className="text-[10px] uppercase tracking-wider text-muted-foreground">
          live buttons {live ? "(" + live.pointerType + ")" : ""}
        </div>
        <div className="font-mono text-[15px] font-bold">
          {live ? live.buttons + " — " + describeButtons(live.buttons) : "move the pen over the screen"}
        </div>
      </div>

      <div className="max-h-[38vh] overflow-auto rounded-lg bg-muted/40">
        <table className="w-full font-mono text-[10px]">
          <thead className="sticky top-0 bg-muted text-muted-foreground">
            <tr>
              {["#", "event", "type", "btn", "buttons", "press", "w", "h", "tiltX", "tiltY"].map((h) => (
                <th key={h} className="px-1 py-0.5 text-left font-semibold">
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 && (
              <tr>
                <td colSpan={10} className="px-1 py-2 text-muted-foreground">
                  nothing yet…
                </td>
              </tr>
            )}
            {rows.map((r) => (
              <tr
                key={r.n}
                className={
                  r.type.startsWith("NATIVE")
                    ? "bg-violet-500/30 font-bold"
                    : r.type === "CONTEXTMENU"
                      ? "bg-amber-500/25 font-bold"
                    : r.buttons & (2 | 32)
                      ? "bg-emerald-500/25 font-bold"
                      : ""
                }
              >
                <td className="px-1">{r.n}</td>
                <td className="px-1">{r.type}</td>
                <td className="px-1">{r.pointerType}</td>
                <td className="px-1">{r.button}</td>
                <td className="px-1">{r.buttons}</td>
                <td className="px-1">{r.pressure}</td>
                <td className="px-1">{r.w}</td>
                <td className="px-1">{r.h}</td>
                <td className="px-1">{r.tiltX}</td>
                <td className="px-1">{r.tiltY}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <p className="mt-1 text-[9px] leading-snug text-muted-foreground">
        Violet NATIVE row = Android itself reported the side button and the native
        bridge delivered it — this is the route that works on Samsung. Green row =
        the barrel (2) or eraser (32) bit reached web content on its own. Amber
        CONTEXTMENU = the button arrives as a right-click. Nothing at all while you
        hold it means the press never left the pen.
      </p>
    </div>
  );
}
