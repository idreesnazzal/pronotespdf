"use client";

/**
 * Tutorial Modal
 * ===============
 * A first-run onboarding modal that explains how to use the whiteboard,
 * especially the Connect feature (which was confusing users).
 *
 * Shows on first load (when no tutorial-seen flag is in localStorage).
 * Can be reopened via the Help button (?).
 */

import React, { useEffect, useState } from "react";
import { useWhiteboard } from "@/store/whiteboard";
import {
  X,
  MousePointer2,
  Pen,
  Type,
  StickyNote,
  Link2,
  Network,
  Search,
  ChevronRight,
  ChevronLeft,
  Sparkles,
} from "lucide-react";
import { Button } from "@/components/ui/button";

interface TutorialStep {
  title: string;
  icon: React.ComponentType<{ size?: number; className?: string }>;
  content: React.ReactNode;
}

const STEPS: TutorialStep[] = [
  {
    title: "Welcome to ProNotes",
    icon: Sparkles,
    content: (
      <div className="space-y-3 text-sm">
        <p>
          ProNotes is an infinite canvas for notes, ideas, and visual knowledge graphs —
          inspired by Microsoft Whiteboard + Obsidian Canvas.
        </p>
        <p className="text-muted-foreground">
          Let's walk through the key features. You can reopen this tutorial
          anytime with the <strong>?</strong> button (top-right).
        </p>
      </div>
    ),
  },
  {
    title: "1. Draw & Write",
    icon: Pen,
    content: (
      <div className="space-y-3 text-sm">
        <p>
          <strong>Pen (P):</strong> Draw freehand with pressure-sensitive smoothing.
        </p>
        <p>
          <strong>Text (T):</strong> Click anywhere on the canvas to add text.
          Double-click empty space to quick-add text.
        </p>
        <p>
          <strong>Sticky Note (N):</strong> Add colored sticky notes.
        </p>
        <p className="text-muted-foreground">
          Each tool remembers its own color and size — switch between them
          without losing your settings.
        </p>
      </div>
    ),
  },
  {
    title: "2. How to CONNECT Elements",
    icon: Link2,
    content: (
      <div className="space-y-3 text-sm">
        <p className="font-medium text-primary">
          This is the key feature — here's how to connect things:
        </p>
        <ol className="space-y-2 list-decimal list-inside">
          <li>
            Press <kbd className="px-1.5 py-0.5 rounded border bg-muted text-xs">C</kbd>{" "}
            or click the <Link2 className="inline" size={14} /> <strong>Connect</strong> tool
            in the bottom toolbar (chain icon).
          </li>
          <li>
            <strong>Click and hold</strong> on the first element (e.g., a sticky note).
          </li>
          <li>
            <strong>Drag</strong> to the second element — a dashed preview line follows
            your cursor.
          </li>
          <li>
            <strong>Release</strong> on the target element → a colored arrow is created!
          </li>
        </ol>
        <p className="text-muted-foreground">
          The arrow's color depends on the <strong>link type</strong> you choose
          in the style bar (Relates = blue, Depends = red, etc.).
        </p>
      </div>
    ),
  },
  {
    title: "3. Link Types & Colors",
    icon: Network,
    content: (
      <div className="space-y-3 text-sm">
        <p>Each connection has a <strong>type</strong> that determines its color:</p>
        <div className="space-y-1.5">
          <div className="flex items-center gap-2">
            <span className="w-4 h-1.5 rounded-full" style={{ backgroundColor: "#3b82f6" }} />
            <span><strong>Relates to</strong> — general relationship</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-4 h-1.5 rounded-full" style={{ backgroundColor: "#ef4444" }} />
            <span><strong>Depends on</strong> — "needs this first"</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-4 h-1.5 rounded-full" style={{ backgroundColor: "#8b5cf6" }} />
            <span><strong>Leads to</strong> — sequence / flow order</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-4 h-1.5 rounded-full" style={{ backgroundColor: "#8b5cf6" }} />
            <span><strong>Flows into</strong> — data / process flow</span>
          </div>
        </div>
        <p className="text-muted-foreground">
          You can also <strong>create your own link type</strong>: click "+ New type"
          in the style bar, enter a name + color. Custom types appear in the legend.
        </p>
        <p className="text-muted-foreground">
          Every arrow shows a <strong>label pill</strong> with the relationship name.
        </p>
      </div>
    ),
  },
  {
    title: "4. Folders, Boards & Graph",
    icon: Network,
    content: (
      <div className="space-y-3 text-sm">
        <p>
          <strong>Folders</strong> contain boards. Every board is automatically a
          "child" of its folder.
        </p>
        <p>
          Press <kbd className="px-1.5 py-0.5 rounded border bg-muted text-xs">Ctrl+G</kbd>{" "}
          to open the <strong>Graph View</strong> — see all boards and folders as a
          network:
        </p>
        <ul className="space-y-1 list-disc list-inside text-muted-foreground">
          <li>Squares = folders, Circles = boards</li>
          <li>Dashed lines = folder contains board</li>
          <li>Solid colored lines = wikilinks</li>
        </ul>
        <p>
          Press <kbd className="px-1.5 py-0.5 rounded border bg-muted text-xs">Ctrl+K</kbd>{" "}
          to <strong>search</strong> across all boards.
        </p>
      </div>
    ),
  },
  {
    title: "5. Wikilinks ([[link]])",
    icon: Type,
    content: (
      <div className="space-y-3 text-sm">
        <p>
          Besides visual arrows, you can create <strong>text links</strong> inside
          any text or sticky note:
        </p>
        <p>
          Type <code className="px-1 py-0.5 rounded bg-muted text-xs">[[Board Name]]</code>{" "}
          — it becomes a clickable blue link.
        </p>
        <p>
          Or select a text element and click the <strong>"Link"</strong> button
          that appears above it → pick a board → the wikilink is inserted automatically.
        </p>
        <p className="text-muted-foreground">
          Clicking a wikilink navigates to that board (creates it if it doesn't exist).
        </p>
      </div>
    ),
  },
  {
    title: "You're ready!",
    icon: Sparkles,
    content: (
      <div className="space-y-3 text-sm">
        <p className="font-medium">Quick reference:</p>
        <div className="grid grid-cols-2 gap-2 text-xs">
          <div className="flex items-center gap-1.5"><kbd className="px-1.5 py-0.5 rounded border bg-muted">V</kbd> Select</div>
          <div className="flex items-center gap-1.5"><kbd className="px-1.5 py-0.5 rounded border bg-muted">P</kbd> Pen</div>
          <div className="flex items-center gap-1.5"><kbd className="px-1.5 py-0.5 rounded border bg-muted">T</kbd> Text</div>
          <div className="flex items-center gap-1.5"><kbd className="px-1.5 py-0.5 rounded border bg-muted">N</kbd> Sticky</div>
          <div className="flex items-center gap-1.5"><kbd className="px-1.5 py-0.5 rounded border bg-muted">C</kbd> Connect</div>
          <div className="flex items-center gap-1.5"><kbd className="px-1.5 py-0.5 rounded border bg-muted">Ctrl+G</kbd> Graph</div>
          <div className="flex items-center gap-1.5"><kbd className="px-1.5 py-0.5 rounded border bg-muted">Ctrl+K</kbd> Search</div>
          <div className="flex items-center gap-1.5"><kbd className="px-1.5 py-0.5 rounded border bg-muted">Ctrl+Z</kbd> Undo</div>
        </div>
        <p className="text-muted-foreground pt-2">
          Reopen this tutorial anytime with <kbd className="px-1.5 py-0.5 rounded border bg-muted text-xs">?</kbd>
        </p>
      </div>
    ),
  },
];

const TUTORIAL_SEEN_KEY = "z-whiteboard-tutorial-seen";

export function TutorialModal() {
  const [open, setOpen] = useState(false);
  const [step, setStep] = useState(0);

  // Check if first run (no tutorial-seen flag) OR if the flag was cleared
  // by the Help button (check on mount and also listen for storage changes)
  React.useEffect(() => {
    if (typeof window === "undefined") return;
    // getItem itself can throw (private mode, disabled storage): showing the
    // tutorial again beats crashing the first-run path.
    let seen: string | null = null;
    try {
      seen = window.localStorage.getItem(TUTORIAL_SEEN_KEY);
    } catch {
      /* fall through with seen === null, i.e. show the tutorial */
    }
    if (!seen) {
      setOpen(true);
    }
    // Listen for the Help button clearing the flag
    const onStorage = (e: StorageEvent) => {
      if (e.key === TUTORIAL_SEEN_KEY && e.newValue === null) {
        setOpen(true);
        setStep(0);
      }
    };
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, []);

  // Settings > Help > "Show the tutorial again" reopens it on demand. Without
  // this the tutorial was unreachable after the first dismissal.
  useEffect(() => {
    const reopen = () => {
      setStep(0);
      setOpen(true);
    };
    window.addEventListener("wb:open-tutorial", reopen);
    return () => window.removeEventListener("wb:open-tutorial", reopen);
  }, []);

  // NOTE: "?" intentionally does NOT open this tutorial — the canvas binds
  // "?" to the Keyboard Shortcuts modal. Opening both on one keypress stacked
  // two dialogs (tutorial on top, shortcuts hidden underneath).

  const handleClose = () => {
    setOpen(false);
    if (typeof window !== "undefined") {
      try {
        window.localStorage.setItem(TUTORIAL_SEEN_KEY, "1");
      } catch {
        /* remembering dismissal is a convenience, never a requirement */
      }
    }
  };

  if (!open) return null;

  const currentStep = STEPS[step];
  const Icon = currentStep.icon;
  const isLast = step === STEPS.length - 1;

  return (
    <div data-wb-modal
      className="fixed inset-0 z-[100] flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="w-full max-w-lg bg-white dark:bg-zinc-900 rounded-2xl shadow-2xl border border-border overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3 border-b border-border bg-muted/30">
          <div className="flex items-center gap-2">
            <Icon size={18} className="text-primary" />
            <span className="text-sm font-medium">{currentStep.title}</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-muted-foreground tabular-nums">
              {step + 1} / {STEPS.length}
            </span>
            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={handleClose}>
              <X size={16} />
            </Button>
          </div>
        </div>

        {/* Content */}
        <div className="px-5 py-5 min-h-[200px]">
          {currentStep.content}
        </div>

        {/* Progress dots */}
        <div className="flex items-center justify-center gap-1.5 pb-3">
          {STEPS.map((_, i) => (
            <button
              key={i}
              className={cn(
                "h-1.5 rounded-full transition-all",
                i === step ? "w-6 bg-primary" : "w-1.5 bg-muted-foreground/30"
              )}
              onClick={() => setStep(i)}
            />
          ))}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-5 py-3 border-t border-border bg-muted/30">
          <Button
            variant="ghost"
            size="sm"
            disabled={step === 0}
            onClick={() => setStep(step - 1)}
          >
            <ChevronLeft size={14} className="mr-1" />
            Back
          </Button>
          {isLast ? (
            <Button size="sm" onClick={handleClose}>
              <Sparkles size={14} className="mr-1" />
              Get started
            </Button>
          ) : (
            <Button size="sm" onClick={() => setStep(step + 1)}>
              Next
              <ChevronRight size={14} className="ml-1" />
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}

// Inline cn to avoid import cycle in this file
function cn(...classes: (string | false | undefined)[]): string {
  return classes.filter(Boolean).join(" ");
}
