"use client";

import React from "react";
import { useTheme } from "next-themes";
import { Sun, Moon, Laptop, Check } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";

interface ThemeToggleProps {
  className?: string;
  size?: "sm" | "default" | "icon";
  variant?: "ghost" | "outline" | "default";
}

export function ThemeToggle({ className, size = "icon", variant = "ghost" }: ThemeToggleProps) {
  const { theme, setTheme, resolvedTheme } = useTheme();
  const [mounted, setMounted] = React.useState(false);

  React.useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted) {
    return (
      <button
        className={cn(
          "p-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted transition-colors",
          className
        )}
        aria-label="Toggle theme"
      >
        <Sun size={16} />
      </button>
    );
  }

  const currentIcon = resolvedTheme === "dark" ? <Moon size={16} /> : <Sun size={16} />;

  return (
    <DropdownMenu>
      <Tooltip>
        <TooltipTrigger asChild>
          <DropdownMenuTrigger asChild>
            <button
              className={cn(
                "p-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted transition-colors flex items-center justify-center",
                className
              )}
              aria-label="Toggle theme (Ctrl+Shift+D)"
            >
              {currentIcon}
            </button>
          </DropdownMenuTrigger>
        </TooltipTrigger>
        <TooltipContent side="top">
          Theme ({theme ? theme.charAt(0).toUpperCase() + theme.slice(1) : "System"})
        </TooltipContent>
      </Tooltip>
      <DropdownMenuContent align="end" className="w-36 z-50">
        <DropdownMenuItem
          onClick={() => setTheme("light")}
          className={cn("flex items-center justify-between text-xs cursor-pointer", theme === "light" && "font-semibold text-primary")}
        >
          <div className="flex items-center gap-2">
            <Sun size={14} />
            <span>Light</span>
          </div>
          {theme === "light" && <Check size={12} className="text-primary" />}
        </DropdownMenuItem>
        <DropdownMenuItem
          onClick={() => setTheme("dark")}
          className={cn("flex items-center justify-between text-xs cursor-pointer", theme === "dark" && "font-semibold text-primary")}
        >
          <div className="flex items-center gap-2">
            <Moon size={14} />
            <span>Dark</span>
          </div>
          {theme === "dark" && <Check size={12} className="text-primary" />}
        </DropdownMenuItem>
        <DropdownMenuItem
          onClick={() => setTheme("system")}
          className={cn("flex items-center justify-between text-xs cursor-pointer", theme === "system" && "font-semibold text-primary")}
        >
          <div className="flex items-center gap-2">
            <Laptop size={14} />
            <span>System</span>
          </div>
          {theme === "system" && <Check size={12} className="text-primary" />}
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
