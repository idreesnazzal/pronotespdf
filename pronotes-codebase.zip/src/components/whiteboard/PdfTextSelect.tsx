"use client";

/**
 * Select text on PDF / Word / PowerPoint pages
 * ============================================
 * The "Select text" tool: drag over a page's text with the pen, a finger or
 * the mouse to select it, double-tap for a word (triple-tap for the line), then
 * Copy, Highlight, Underline or Strike it from the floating bar.
 *
 * How it stays out of the way of writing
 * --------------------------------------
 * There is no DOM text layer over the page. The page's text is geometry (runs
 * with boxes, see lib/whiteboard/pdfText.ts), and this tool hit-tests it from
 * the canvas's OWN pointer handlers - only while it is the active tool. So
 * nothing extra ever sits between the S Pen and the page: pens, the eraser,
 * the lasso, palm rejection, pinch and scrolling are exactly as before, and
 * the Android WebView never gets a chance to start its own text selection
 * (with its own handles and Copy / Share bar) over the ink.
 *
 * The selection and its handles are drawn in world space, inside the camera
 * group, so they sit on the text at every zoom and scroll - in whichever split
 * pane is live, since the live pane IS this canvas. The whole layer is
 * pointer-events: none and lives only in the canvas, never in an export.
 *
 * Highlight / underline / strike make ordinary strokes - the highlighter's and
 * the fineliner's - laid along the selected lines: saved, undoable in one step,
 * erasable, and exported exactly like a line you drew yourself.
 *
 * It also listens for `wb:pdf-find` (sent by the search panel after it opens a
 * page) and briefly lights up every match on that page, as PDF viewers do.
 */

import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Check, Copy, Search, Strikethrough, Underline } from "lucide-react";
import { nanoid } from "nanoid";
import type { Board, Camera, NotebookPage, ToolType, WhiteboardElement } from "@/lib/whiteboard/types";
import {
  caretAt,
  findAll,
  lineSegments,
  markStrokes,
  offsetAt,
  pageBoxOnSheet,
  queryTerms,
  rangeRects,
  selectedText,
  setCharMeasurer,
  wordRangeAt,
  type LineRect,
  type MarkKind,
  type PageLayout,
  type Rect,
} from "@/lib/whiteboard/pdfText";
import { cn } from "@/lib/utils";

/** The I-beam over a marked line: "select the text", not "type text". */
export function TextSelectIcon({ size = 18, className }: { size?: number; className?: string }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={2}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      <rect x="3" y="9" width="12" height="6" rx="1.5" fill="currentColor" opacity="0.28" stroke="none" />
      <path d="M3 5h9M3 19h7" />
      <path d="M18 4v16M15.5 4h5M15.5 20h5" />
    </svg>
  );
}

// ---------------------------------------------------------------------------
// Colours
// ---------------------------------------------------------------------------

/** Highlighter tints, each with the ink its underline / strike is drawn in. */
const MARK_COLORS = [
  { name: "Yellow", fill: "#fde047", ink: "#ca8a04" },
  { name: "Green", fill: "#86efac", ink: "#16a34a" },
  { name: "Pink", fill: "#f9a8d4", ink: "#db2777" },
  { name: "Blue", fill: "#93c5fd", ink: "#2563eb" },
] as const;

const COLOR_KEY = "pronotes:textMarkColor";

function loadColorIndex(): number {
  try {
    const n = Number(localStorage.getItem(COLOR_KEY));
    return Number.isInteger(n) && n >= 0 && n < MARK_COLORS.length ? n : 0;
  } catch {
    return 0;
  }
}

// ---------------------------------------------------------------------------
// Find highlight (wb:pdf-find)
// ---------------------------------------------------------------------------

interface FindRequest {
  boardId: string;
  pageId?: string;
  pageIndex: number;
  query: string;
  /** Which match on the page to bring into view (0 = the first). */
  ordinal: number;
  at: number;
}

/** A request waits this long for its page to be the one on screen. */
const FIND_WAIT_MS = 4000;
const FLASH_MS = 2600;

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function installMeasurer() {
  if (typeof document === "undefined") return;
  const ctx = document.createElement("canvas").getContext("2d");
  if (!ctx) return;
  ctx.font = "16px sans-serif";
  setCharMeasurer((s) => Array.from(s, (ch) => ctx.measureText(ch).width));
}
let measurerInstalled = false;

async function copyToClipboard(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    // Older WebViews: the textarea route still reaches the system clipboard.
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.setAttribute("readonly", "");
    ta.style.cssText = "position:fixed;left:-9999px;top:0;opacity:0";
    document.body.appendChild(ta);
    ta.select();
    let ok = false;
    try {
      ok = document.execCommand("copy");
    } catch {
      ok = false;
    }
    ta.remove();
    return ok;
  }
}

// ---------------------------------------------------------------------------
// The hook
// ---------------------------------------------------------------------------

interface Params {
  tool: ToolType;
  board: Board | null;
  isNb: boolean;
  activePage: NotebookPage | null;
  activeIndex: number;
  pageDim: { width: number; height: number };
  camera: Camera;
  viewport: { width: number; height: number };
  getWorldPoint: (clientX: number, clientY: number) => { x: number; y: number };
  addElements: (els: WhiteboardElement[], commit?: boolean) => void;
  setCamera: (camera: Partial<Camera>) => void;
}

interface Drag {
  pointerId: number;
  /** "select": `anchor` stays put and the pointer moves the other end. */
  anchor: number;
  startX: number;
  startY: number;
  moved: boolean;
  /** The selection before this drag, put back if the drag is cancelled. */
  prev: Selection | null;
}

interface Selection {
  start: number;
  end: number;
}

export function usePdfTextSelect(p: Params) {
  const { tool, board, isNb, activePage, activeIndex, pageDim, camera, viewport } = p;
  const active = tool === "textselect";
  const ref = activePage?.pdf ?? null;
  const pageKey = `${board?.id ?? ""}:${activePage?.id ?? ""}:${ref?.docId ?? ""}:${ref?.pageNumber ?? 0}`;

  // undefined = still reading; null = the page has no text. Kept with the page
  // it belongs to: right after the active page changes (the canvas replays a
  // press on the sheet you touched) the old page's text must not be hit-tested
  // against the new page.
  const [layoutState, setLayoutState] = useState<{ key: string; value: PageLayout | null | undefined }>({
    key: "",
    value: undefined,
  });
  const layout = layoutState.key === pageKey ? layoutState.value : undefined;
  const setLayout = useCallback(
    (value: PageLayout | null | undefined) => setLayoutState({ key: pageKey, value }),
    [pageKey]
  );
  /** A press that arrived while this page's text was still loading. */
  const pendingRef = useRef<{ pointerId: number; x0: number; y0: number; x: number; y: number } | null>(null);
  const [legacyOffice, setLegacyOffice] = useState(false);
  const [sel, setSel] = useState<Selection | null>(null);
  const [dragging, setDragging] = useState(false);
  const [copied, setCopied] = useState(false);
  /** The action bar's measured width, to keep it inside the screen. */
  const [barW, setBarW] = useState(380);
  const [colorIndex, setColorIndex] = useState(0);
  const [flash, setFlash] = useState<{ ranges: Array<[number, number]>; key: number } | null>(null);
  const [findTick, setFindTick] = useState(0);
  const findRef = useRef<FindRequest | null>(null);
  const dragRef = useRef<Drag | null>(null);
  const tapsRef = useRef<{ at: number; x: number; y: number; type: string; count: number }>({ at: 0, x: 0, y: 0, type: "", count: 0 });

  useEffect(() => {
    if (!measurerInstalled) {
      measurerInstalled = true;
      installMeasurer();
    }
    setColorIndex(loadColorIndex());
  }, []);

  // A find request that is waiting for THIS page (the search panel navigates
  // first and asks second, so it may arrive a render early).
  const findForPage = (() => {
    const f = findRef.current;
    if (!f || !board || f.boardId !== board.id || Date.now() - f.at > FIND_WAIT_MS) return null;
    const onPage = f.pageId ? f.pageId === activePage?.id : f.pageIndex === activeIndex;
    return onPage ? f : null;
  })();

  // Text is read only when something needs it: the tool is in hand, or a find
  // is waiting. Scrolling a 90-page PDF with a pen never reads any.
  const wanted = Boolean(ref) && (active || findForPage !== null || flash !== null);
  useEffect(() => {
    setSel(null);
    // Match boxes belong to the page they were found on.
    setFlash(null);
    setLegacyOffice(false);
    dragRef.current = null;
    setDragging(false);
    if (!ref || !wanted) {
      setLayout(ref ? undefined : null);
      return;
    }
    let alive = true;
    setLayout(undefined);
    (async () => {
      const { getPageLayout, isImageOnlyOfficeImport } = await import("@/lib/whiteboard/pdfTextIndex");
      const l = await getPageLayout(ref);
      if (!alive) return;
      setLayout(l);
      if (!l && (await isImageOnlyOfficeImport(ref.docId)) && alive) setLegacyOffice(true);
    })().catch(() => alive && setLayout(null));
    return () => {
      alive = false;
    };
    // `ref` is identified by pageKey.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pageKey, wanted]);

  // Putting the tool down drops the selection.
  useEffect(() => {
    if (!active) {
      setSel(null);
      dragRef.current = null;
      setDragging(false);
    }
  }, [active]);

  useEffect(() => {
    const onFind = (e: Event) => {
      const d = (e as CustomEvent).detail as Partial<FindRequest> | undefined;
      if (!d || typeof d.boardId !== "string" || typeof d.query !== "string" || !d.query.trim()) return;
      findRef.current = {
        boardId: d.boardId,
        pageId: typeof d.pageId === "string" ? d.pageId : undefined,
        pageIndex: typeof d.pageIndex === "number" ? d.pageIndex : -1,
        query: d.query,
        ordinal: typeof (d as { ordinal?: unknown }).ordinal === "number" ? Math.max(0, (d as { ordinal: number }).ordinal) : 0,
        at: Date.now(),
      };
      setFindTick((n) => n + 1);
    };
    window.addEventListener("wb:pdf-find", onFind);
    return () => window.removeEventListener("wb:pdf-find", onFind);
  }, []);

  const box = useMemo(
    () => (layout ? pageBoxOnSheet(layout.page, pageDim.width, pageDim.height) : null),
    [layout, pageDim.width, pageDim.height]
  );
  const toWorld = useCallback(
    (r: Rect): Rect => (box ? { x: box.x + r.x * box.w, y: box.y + r.y * box.h, w: r.w * box.w, h: r.h * box.h } : r),
    [box]
  );
  const toScreen = useCallback(
    (x: number, y: number) => ({
      x: (x - camera.x) * camera.zoom + viewport.width / 2,
      y: (y - camera.y) * camera.zoom + viewport.height / 2,
    }),
    [camera.x, camera.y, camera.zoom, viewport.width, viewport.height]
  );

  // Serve a waiting find once this page's text is in.
  useEffect(() => {
    const f = findForPage;
    if (!f || !layout || !box) return;
    findRef.current = null;
    // Every word of the query lights up (search matches them in any order);
    // the view goes to the match the search stepped to.
    const terms = queryTerms(f.query);
    const ranges = terms.flatMap((t) => findAll(layout.text, t, 200)).sort((a, b) => a[0] - b[0]);
    if (!ranges.length) return;
    const key = Date.now();
    setFlash({ ranges, key });
    const lead = findAll(layout.text, terms[0] ?? f.query, 200);
    const target = lead[Math.min(f.ordinal, lead.length - 1)] ?? ranges[0];
    const r = rangeRects(layout, target[0], target[1]).map(toWorld)[0];
    if (r) {
      const top = (r.y - camera.y) * camera.zoom + viewport.height / 2;
      if (top < 40 || top > viewport.height - 60) {
        p.setCamera({ y: r.y + viewport.height * 0.15 / camera.zoom });
      }
    }
    const t = setTimeout(() => setFlash((cur) => (cur?.key === key ? null : cur)), FLASH_MS + 200);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [findTick, layout, box, pageKey]);

  // A press held while the text loaded starts now, from where it landed.
  useEffect(() => {
    const pend = pendingRef.current;
    if (!pend || layout === undefined) return;
    pendingRef.current = null;
    if (!layout || !box) return;
    const w0 = p.getWorldPoint(pend.x0, pend.y0);
    if (w0.x < box.x || w0.x > box.x + box.w || w0.y < box.y || w0.y > box.y + box.h) return;
    const at = offsetAt(layout, (w0.x - box.x) / box.w, (w0.y - box.y) / box.h);
    if (at === null) return;
    const moved = Math.hypot(pend.x - pend.x0, pend.y - pend.y0) >= 4;
    dragRef.current = { pointerId: pend.pointerId, anchor: at, startX: pend.x0, startY: pend.y0, moved, prev: null };
    setDragging(true);
    if (moved) {
      const w = p.getWorldPoint(pend.x, pend.y);
      const now = offsetAt(layout, (w.x - box.x) / box.w, (w.y - box.y) / box.h);
      if (now !== null && now !== at) setSel({ start: Math.min(now, at), end: Math.max(now, at) });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [layout, box]);

  const offsetAtClient = useCallback(
    (clientX: number, clientY: number): number | null => {
      if (!layout || !box) return null;
      const w = p.getWorldPoint(clientX, clientY);
      return offsetAt(layout, (w.x - box.x) / box.w, (w.y - box.y) / box.h);
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [layout, box, p.getWorldPoint]
  );

  const selWorldRects = useMemo(
    () => (layout && sel ? rangeRects(layout, sel.start, sel.end).map((r) => ({ ...toWorld(r), line: r.line })) : []),
    [layout, sel, toWorld]
  );
  const carets = useMemo(() => {
    if (!layout || !sel || sel.end <= sel.start) return null;
    const a = caretAt(layout, sel.start, "start");
    const b = caretAt(layout, sel.end, "end");
    if (!a || !b) return null;
    const wa = toWorld({ x: a.x, y: a.y, w: 0, h: a.h });
    const wb = toWorld({ x: b.x, y: b.y, w: 0, h: b.h });
    return { start: { x: wa.x, y: wa.y, h: wa.h }, end: { x: wb.x, y: wb.y, h: wb.h } };
  }, [layout, sel, toWorld]);

  /** Knob radius in screen pixels; the grab area is wider for a finger. */
  const KNOB = 7;
  const handleAt = (clientX: number, clientY: number, pointerType: string, svgRect: DOMRect | null): "start" | "end" | null => {
    if (!carets || !svgRect) return null;
    const reach = pointerType === "touch" ? 30 : 18;
    for (const which of ["start", "end"] as const) {
      const c = carets[which];
      const s = toScreen(c.x, c.y + c.h);
      const dx = clientX - svgRect.left - s.x;
      const dy = clientY - svgRect.top - (s.y + KNOB);
      // The knob hangs BELOW the line: a press on the text itself (small
      // text, zoomed out) is aimed at the text, not at the knob under it.
      if (Math.hypot(dx, dy) <= reach && clientY - svgRect.top >= s.y - 4) return which;
    }
    return null;
  };

  /**
   * A press with the tool in hand. False means "not on any text": the canvas
   * pans instead, so a drag in the margin (or on a page with no text) still
   * scrolls the notebook.
   */
  const pointerDown = (e: React.PointerEvent<Element>): boolean => {
    if (!active) return false;
    if (e.pointerType === "mouse" && e.button !== 0) return false;
    const svgRect = (e.currentTarget as Element).getBoundingClientRect?.() ?? null;

    // Second and third taps of a multi-tap land on the word just selected -
    // right beside its knobs - and must keep counting, not grab a knob.
    const t = tapsRef.current;
    const now = Date.now();
    const again =
      now - t.at < 380 && t.type === e.pointerType && Math.hypot(e.clientX - t.x, e.clientY - t.y) < 24;

    const grab = sel && !again ? handleAt(e.clientX, e.clientY, e.pointerType, svgRect) : null;
    if (grab && sel) {
      dragRef.current = {
        pointerId: e.pointerId,
        anchor: grab === "start" ? sel.end : sel.start,
        startX: e.clientX,
        startY: e.clientY,
        moved: true,
        prev: sel,
      };
      setDragging(true);
      return true;
    }

    if (layout === undefined && ref) {
      // This page's text is still coming (the page was just switched to).
      // Hold the press and start it the moment the text is in, rather than
      // scrolling the page away from under the pen.
      pendingRef.current = { pointerId: e.pointerId, x0: e.clientX, y0: e.clientY, x: e.clientX, y: e.clientY };
      return true;
    }
    if (!layout || !box) {
      setSel(null);
      return false;
    }
    const w = p.getWorldPoint(e.clientX, e.clientY);
    const onPage = w.x >= box.x && w.x <= box.x + box.w && w.y >= box.y && w.y <= box.y + box.h;
    if (!onPage) {
      setSel(null);
      return false;
    }
    const at = offsetAtClient(e.clientX, e.clientY);
    if (at === null) return false;

    // Double tap: the word. Triple tap: the whole line.
    const count = again ? t.count + 1 : 1;
    tapsRef.current = { at: now, x: e.clientX, y: e.clientY, type: e.pointerType, count };
    if (count >= 2) {
      let range: [number, number];
      if (count === 2) {
        range = wordRangeAt(layout.text, at);
      } else {
        const run = layout.runs.find((r) => at >= r.start && at <= r.end) ?? layout.runs[0];
        const line = layout.runs.filter((r) => r.line === run.line);
        range = [line[0].start, line[line.length - 1].end];
      }
      dragRef.current = null;
      setDragging(false);
      setSel(range[1] > range[0] ? { start: range[0], end: range[1] } : null);
      return true;
    }

    dragRef.current = { pointerId: e.pointerId, anchor: at, startX: e.clientX, startY: e.clientY, moved: false, prev: sel };
    setDragging(true);
    return true;
  };

  const pointerMove = (e: React.PointerEvent<Element>): boolean => {
    const pend = pendingRef.current;
    if (pend && pend.pointerId === e.pointerId) {
      pend.x = e.clientX;
      pend.y = e.clientY;
      return true;
    }
    const d = dragRef.current;
    if (!d || d.pointerId !== e.pointerId) return false;
    if (!d.moved && Math.hypot(e.clientX - d.startX, e.clientY - d.startY) < 4) return true;
    d.moved = true;
    const at = offsetAtClient(e.clientX, e.clientY);
    if (at === null) return true;
    setSel(at === d.anchor ? null : { start: Math.min(at, d.anchor), end: Math.max(at, d.anchor) });
    return true;
  };

  const pointerUp = (e: React.PointerEvent<Element>): boolean => {
    if (pendingRef.current?.pointerId === e.pointerId) {
      pendingRef.current = null;
      return true;
    }
    const d = dragRef.current;
    if (!d || d.pointerId !== e.pointerId) return false;
    dragRef.current = null;
    setDragging(false);
    // A plain tap on text clears the selection, as in every reader.
    if (!d.moved && tapsRef.current.count < 2) setSel(null);
    return true;
  };

  /**
   * A second finger arrived (pinch) or the system took the pointer: whatever
   * the first finger dragged out on its way was not meant as a selection.
   */
  const cancel = (pointerId?: number) => {
    // Only the pointer doing the drag can cancel it: a palm the system
    // cancels while the pen selects must leave the pen's selection alone.
    if (pointerId !== undefined && pendingRef.current?.pointerId === pointerId) pendingRef.current = null;
    if (pointerId === undefined) pendingRef.current = null;
    const d = dragRef.current;
    if (!d) return;
    if (pointerId !== undefined && d.pointerId !== pointerId) return;
    dragRef.current = null;
    setDragging(false);
    setSel(d.prev);
  };

  const text = layout && sel ? selectedText(layout, sel.start, sel.end) : "";

  const doCopy = useCallback(async () => {
    if (!text) return;
    const copiedSel = sel;
    if (await copyToClipboard(text)) {
      setCopied(true);
      setTimeout(() => {
        setCopied(false);
        // Only the selection that was copied goes away - not one you started
        // in the moment since.
        setSel((cur) => (cur && copiedSel && cur.start === copiedSel.start && cur.end === copiedSel.end ? null : cur));
      }, 900);
    }
  }, [text, sel]);

  // Ctrl/Cmd+C copies the selection while there is one.
  useEffect(() => {
    if (!active || !text) return;
    const onKey = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && (e.code === "KeyC" || e.key.toLowerCase() === "c")) {
        const tgt = e.target as HTMLElement | null;
        if (tgt && (tgt.isContentEditable || /^(INPUT|TEXTAREA)$/.test(tgt.tagName))) return;
        e.preventDefault();
        void doCopy();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [active, text, doCopy]);

  const mark = (kind: MarkKind, ci = colorIndex) => {
    if (!layout || !sel || !box) return;
    const aspect = layout.page.h > 0 ? layout.page.w / layout.page.h : 1;
    const segs = lineSegments(rangeRects(layout, sel.start, sel.end), aspect).map((r: LineRect) => toWorld(r));
    const strokes = markStrokes(kind, segs, MARK_COLORS[ci], () => nanoid(8));
    if (strokes.length) p.addElements(strokes, true);
    setSel(null);
  };

  const pickColor = (ci: number) => {
    setColorIndex(ci);
    try {
      localStorage.setItem(COLOR_KEY, String(ci));
    } catch {
      /* remembered for this session only */
    }
    mark("highlight", ci);
  };

  const findOnPage = () => {
    const q = text.replace(/\s+/g, " ").trim().slice(0, 80);
    if (!q || !board) return;
    // The find bar opens on this query, goes to the first match from this
    // page on and lights up every match there (via wb:pdf-find).
    window.dispatchEvent(new CustomEvent("wb:open-search", { detail: { query: q } }));
    setSel(null);
  };

  // ---- world-space layer ---------------------------------------------------

  const zoom = camera.zoom || 1;
  const flashRects = useMemo(
    () =>
      layout && flash
        ? flash.ranges.flatMap(([s, e]) => rangeRects(layout, s, e).map(toWorld))
        : [],
    [layout, flash, toWorld]
  );

  const worldLayer =
    selWorldRects.length || flashRects.length ? (
      <g pointerEvents="none" data-pdf-text-layer="">
        {flashRects.map((r, i) => (
          <rect
            key={`f${flash?.key}-${i}`}
            x={r.x - 1.5 / zoom}
            y={r.y - 1 / zoom}
            width={r.w + 3 / zoom}
            height={r.h + 2 / zoom}
            rx={2 / zoom}
            fill="#f59e0b"
            stroke="#d97706"
            strokeWidth={1.5 / zoom}
            opacity={0}
          >
            <animate
              attributeName="opacity"
              values="0;0.6;0.45;0.6;0.45;0"
              keyTimes="0;0.08;0.3;0.5;0.8;1"
              dur={`${FLASH_MS}ms`}
              fill="freeze"
            />
          </rect>
        ))}
        {selWorldRects.map((r, i) => (
          <rect key={i} x={r.x} y={r.y} width={r.w} height={r.h} rx={1.5 / zoom} fill="#3b82f6" fillOpacity={0.3} />
        ))}
        {carets &&
          (["start", "end"] as const).map((which) => {
            const c = carets[which];
            const k = KNOB / zoom;
            return (
              <g key={which}>
                <line x1={c.x} y1={c.y} x2={c.x} y2={c.y + c.h} stroke="#2563eb" strokeWidth={2 / zoom} />
                <circle
                  cx={c.x}
                  cy={c.y + c.h + k}
                  r={k}
                  fill="#2563eb"
                  stroke="#ffffff"
                  strokeWidth={1.5 / zoom}
                />
              </g>
            );
          })}
      </g>
    ) : null;

  // ---- screen overlay: the action bar and the hint --------------------------

  let menu: React.ReactNode = null;
  if (active && sel && !dragging && selWorldRects.length && text) {
    const xs = selWorldRects.flatMap((r) => [r.x, r.x + r.w]);
    const top = Math.min(...selWorldRects.map((r) => r.y));
    const bottom = Math.max(...selWorldRects.map((r) => r.y + r.h));
    const a = toScreen((Math.min(...xs) + Math.max(...xs)) / 2, top);
    const b = toScreen(0, bottom);
    const BAR_H = 48;
    // Centred over the selection, but never past either edge: the bar is
    // ~370px wide, and right-aligned Hebrew near the edge hid Copy or Find.
    const half = Math.min(barW, viewport.width - 16) / 2;
    const barX = Math.max(8 + half, Math.min(viewport.width - 8 - half, a.x));
    const above = a.y - BAR_H - 14 > 8;
    const y = above ? a.y - BAR_H - 14 : Math.min(viewport.height - BAR_H - 8, b.y + KNOB * 2 + 16);
    menu = (
      <div
        className="pointer-events-none absolute inset-0 z-30 overflow-hidden"
        style={{ touchAction: "none" }}
      >
        <div
          role="toolbar"
          aria-label="Selected text"
          ref={(el) => {
            if (el && Math.abs(el.offsetWidth - barW) > 1) setBarW(el.offsetWidth);
          }}
          className="pointer-events-auto absolute flex items-center gap-0.5 rounded-2xl border border-white/10 bg-zinc-900/95 p-1 text-zinc-100 shadow-[0_12px_32px_-8px_rgba(0,0,0,0.55)] backdrop-blur-md animate-in fade-in zoom-in-95 duration-150"
          style={{
            left: barX,
            top: Math.max(8, y),
            transform: "translateX(-50%)",
            maxWidth: viewport.width - 16,
          }}
          onPointerDown={(e) => e.stopPropagation()}
        >
          <button
            type="button"
            onClick={doCopy}
            className="flex h-10 items-center gap-1.5 rounded-xl px-3 text-sm font-medium transition-colors hover:bg-white/10 active:bg-white/15"
            aria-label="Copy text"
          >
            {copied ? <Check size={16} className="text-emerald-400" /> : <Copy size={16} />}
            <span>{copied ? "Copied" : "Copy"}</span>
          </button>
          <span className="mx-1 h-6 w-px bg-white/15" />
          <div className="flex items-center gap-1 px-1" aria-label="Highlight">
            {MARK_COLORS.map((c, i) => (
              <button
                key={c.name}
                type="button"
                onClick={() => pickColor(i)}
                aria-label={`Highlight ${c.name.toLowerCase()}`}
                title={`Highlight ${c.name.toLowerCase()}`}
                className={cn(
                  "flex h-10 w-8 items-center justify-center rounded-xl transition-transform hover:bg-white/10 active:scale-90"
                )}
              >
                <span
                  className={cn(
                    "block h-5 w-5 rounded-full ring-offset-2 ring-offset-zinc-900",
                    i === colorIndex && "ring-2 ring-white/80"
                  )}
                  style={{ backgroundColor: c.fill }}
                />
              </button>
            ))}
          </div>
          <span className="mx-1 h-6 w-px bg-white/15" />
          <button
            type="button"
            onClick={() => mark("underline")}
            className="flex h-10 w-10 items-center justify-center rounded-xl transition-colors hover:bg-white/10 active:bg-white/15"
            aria-label="Underline"
            title="Underline"
          >
            <Underline size={17} style={{ color: MARK_COLORS[colorIndex].fill }} />
          </button>
          <button
            type="button"
            onClick={() => mark("strike")}
            className="flex h-10 w-10 items-center justify-center rounded-xl transition-colors hover:bg-white/10 active:bg-white/15"
            aria-label="Strikethrough"
            title="Strikethrough"
          >
            <Strikethrough size={17} style={{ color: MARK_COLORS[colorIndex].fill }} />
          </button>
          <span className="mx-1 h-6 w-px bg-white/15" />
          <button
            type="button"
            onClick={findOnPage}
            className="flex h-10 w-10 items-center justify-center rounded-xl transition-colors hover:bg-white/10 active:bg-white/15"
            aria-label="Find in note"
            title="Find in note"
          >
            <Search size={17} />
          </button>
        </div>
      </div>
    );
  }

  let hint: string | null = null;
  if (active) {
    if (!board || !isNb || !activePage) hint = "Select text works on PDF, Word and PowerPoint notebooks.";
    else if (!ref) hint = "This page has no document under it - there is no text to select.";
    else if (layout === undefined) hint = "Reading the page text…";
    else if (layout === null)
      hint = legacyOffice
        ? "This page was converted before ProNotes kept document text. Open the Word or PowerPoint file again to select its text."
        : "No selectable text on this page - it is a picture (a scan or a photo).";
  }
  const hintNode = hint ? (
    // Below the floating top bar, never over it.
    <div className="pointer-events-none absolute inset-x-0 top-20 z-20 flex justify-center px-4">
      <div className="flex max-w-md items-center gap-2 rounded-2xl border border-border/60 bg-background/90 px-3.5 py-2 text-xs leading-snug text-muted-foreground shadow-sm backdrop-blur animate-in fade-in duration-300">
        <TextSelectIcon size={14} className="shrink-0 opacity-70" />
        <span>{hint}</span>
      </div>
    </div>
  ) : null;

  const overlay = (
    <>
      {hintNode}
      {menu}
    </>
  );

  return { pointerDown, pointerMove, pointerUp, cancel, worldLayer, overlay };
}
