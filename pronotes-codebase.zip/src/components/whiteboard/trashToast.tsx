"use client";

/**
 * Sidebar deletes with Undo.
 * ==========================
 * Every destructive sidebar action (row delete, batch delete, folder delete)
 * goes through here instead of `window.confirm`: the store snapshots the
 * removed boards/folders into an undo buffer, the toast offers Undo, and the
 * buffer (plus its pictures/PDFs, which the pruner treats as referenced)
 * expires after UNDO_MS. Replaces, never duplicates: a new trash discards
 * the previous buffer first so only one Undo is ever pending.
 */

import * as React from "react";
import { toast } from "@/hooks/use-toast";
import { ToastAction } from "@/components/ui/toast";
import { useWhiteboard } from "@/store/whiteboard";

export const TRASH_UNDO_MS = 8000;

let expiryTimer: ReturnType<typeof setTimeout> | null = null;

function clearExpiry() {
  if (expiryTimer !== null) {
    clearTimeout(expiryTimer);
    expiryTimer = null;
  }
}

function describeBuffer(): string | null {
  const buf = useWhiteboard.getState().lastDeleted;
  if (!buf) return null;
  const parts: string[] = [];
  if (buf.removedBoards.length > 0) {
    parts.push(`${buf.removedBoards.length} board${buf.removedBoards.length === 1 ? "" : "s"}`);
  }
  if (buf.removedFolders.length > 0) {
    parts.push(`${buf.removedFolders.length} folder${buf.removedFolders.length === 1 ? "" : "s"}`);
  }
  return parts.length > 0 ? parts.join(" and ") : "items";
}

/** Trash boards/folders with an Undo toast. No-ops (with no toast) when nothing matches. */
export function trashWithUndo(boardIds: string[], folderIds: string[]) {
  const st = useWhiteboard.getState();
  if (st.lastDeleted) st.discardTrash();
  clearExpiry();
  st.trashItems(boardIds, folderIds);
  const what = describeBuffer();
  if (!what) return;
  const t = toast({
    title: `Deleted ${what}`,
    description: "Undo within 8 seconds — pictures and PDFs survive until then.",
    duration: TRASH_UNDO_MS,
    action: (
      <ToastAction
        altText="Undo delete"
        onClick={() => {
          clearExpiry();
          useWhiteboard.getState().undoTrash();
          t.dismiss();
        }}
      >
        Undo
      </ToastAction>
    ),
  });
  expiryTimer = setTimeout(() => {
    expiryTimer = null;
    useWhiteboard.getState().discardTrash();
    t.dismiss();
  }, TRASH_UNDO_MS);
}
