"use client";

/**
 * Contextual tool properties
 * ==========================
 * Follows the pattern every serious note app uses (Samsung Notes, Concepts,
 * GoodNotes): the tool row only SELECTS a tool, and a second row shows the
 * properties of whatever is selected — colour, thickness — with a ⚙ that opens
 * the full panel for everything else.
 *
 * The point is that the common controls (colour, size) are one tap away
 * instead of hidden in a popover, while rarely-changed options stay out of
 * sight until asked for.
 */

import React from "react";
import { useWhiteboard } from "@/store/whiteboard";
import {
  FONT_FAMILIES,
  LASER_COLORS,
  PEN_COLORS,
  PEN_TYPE_PRESETS,
  PEN_TYPES,
  STROKE_TOOL_IDS,
  STICKY_COLORS,
  getToolColor,
  getToolSize,
  setToolColor,
  setToolSize,
  type DashStyle,
  type FillStyle,
  type LaserMode,
  type StickyColor,
  type StrokeStyle,
  type ToolType,
  type PressureCurve,
  type PenFeel,
  isVerticalDock,
  penFeelFor,
  penUsesPressure,
} from "@/lib/whiteboard/types";
import { buildStrokePath, calibratePressure } from "@/lib/whiteboard/stroke";
import { ColorRow, Swatch } from "./ColorSwatches";
import { flyoutSide } from "./DockControls";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { StepperRow } from "./StepperControl";
import { Settings2, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const STROKE_TOOLS: ToolType[] = STROKE_TOOL_IDS as ToolType[];
const SHAPE_TOOLS: ToolType[] = ["rectangle", "ellipse", "diamond", "triangle", "star", "cloud"];
const LINE_TOOLS: ToolType[] = ["line", "arrow"];
const TEXT_TOOLS: ToolType[] = ["text", "sticky"];

/** Tools with nothing to configure — the bar hides entirely for these. */
const BARE_TOOLS: ToolType[] = ["select", "lasso", "pan", "image", "textselect"];

// These mirror the DashStyle / FillStyle unions in types.ts, which are types
// rather than runtime values.
const DASH_STYLES: DashStyle[] = ["solid", "dashed", "dotted"];
const FILL_STYLES: FillStyle[] = ["transparent", "solid", "semi", "hatch"];

export function toolHasProperties(tool: ToolType): boolean {
  return !BARE_TOOLS.includes(tool);
}

/** The laser's three looks, with what each is for. */
const LASER_MODES: Array<{ id: LaserMode; label: string; hint: string }> = [
  { id: "dot", label: "Dot", hint: "Just a glowing dot where you point" },
  { id: "trail", label: "Trail", hint: "The dot leaves a short tail that fades at once" },
  { id: "draw", label: "Draw", hint: "Circle or underline; the lines fade after you lift the pen" },
];

/** "Draw" mode: how long the lines stay after the pen lifts. */
const LASER_FADE_CHOICES = [
  { value: 800, label: "Short" },
  { value: 1500, label: "Normal" },
  { value: 3000, label: "Long" },
  { value: 6000, label: "6 s" },
];

function sizeRangeFor(tool: ToolType): { min: number; max: number; presets: number[] } {
  if (tool === "laser") return { min: 4, max: 40, presets: [6, 10, 16, 24] };
  if (tool === "eraser") return { min: 4, max: 96, presets: [8, 16, 32, 64] };
  if (TEXT_TOOLS.includes(tool)) return { min: 10, max: 96, presets: [14, 18, 24, 32, 48] };
  if (STROKE_TOOLS.includes(tool)) return { min: 1, max: 64, presets: [2, 4, 8, 16, 24] };
  return { min: 1, max: 32, presets: [1, 2, 4, 8, 12] };
}

// ---------------------------------------------------------------------------
// Contextual bar (row above the tool dock)
// ---------------------------------------------------------------------------

export function ToolPropertiesBar({ onOpenPanel }: { onOpenPanel: () => void }) {
  const tool = useWhiteboard((s) => s.tool);
  const style = useWhiteboard((s) => s.style);
  const setStyle = useWhiteboard((s) => s.setStyle);
  const dockPos = useWhiteboard((s) => s.toolbarPosition);
  const vertical = isVerticalDock(dockPos);
  const editingId = useWhiteboard((s) => s.editingId);
  const collapsed = useWhiteboard((s) => s.toolPropsBarCollapsed);

  if (!toolHasProperties(tool)) return null;
  // Folded away by the chevron pinned at the end of the tool row.
  if (collapsed) return null;
  // While typing in a text box this bar would edit the text TOOL's default -
  // for the next box - not the one being typed in, so pressing + read "21px"
  // while the box stayed 17px. The box's own bar is the one place now.
  if (editingId) return null;

  const { min, max } = sizeRangeFor(tool);
  const isSticky = tool === "sticky";
  const stickyColorsList = Object.keys(STICKY_COLORS).map((k) => STICKY_COLORS[k as StickyColor].bg);
  const color = isSticky ? STICKY_COLORS[style.stickyColor]?.bg ?? "#fef9c3" : getToolColor(style, tool);
  const size = getToolSize(style, tool);

  const onColorChange = (c: string) => {
    if (isSticky) {
      const match = (Object.keys(STICKY_COLORS) as StickyColor[]).find(
        (k) => STICKY_COLORS[k].bg.toLowerCase() === c.toLowerCase()
      );
      if (match) {
        setStyle({ stickyColor: match });
        return;
      }
    }
    setStyle(setToolColor(style, tool, c));
  };

  const showColor = tool !== "eraser";

  return (
    <div
      className={cn(
        "flex items-center gap-2 rounded-2xl border border-border/80 bg-white/95 p-1.5 shadow-lg backdrop-blur-xl dark:bg-zinc-900/95",
        vertical ? "max-h-full flex-col overflow-y-auto" : "max-w-full overflow-x-auto"
      )}
    >
      {/* Thickness: a live slider, right here. Five fixed presets meant any
          other size needed the panel; dragging is one gesture and covers the
          whole range. The dot previews the ACTUAL width in the current colour. */}
      <div className={cn("flex shrink-0 items-center gap-2", vertical ? "flex-col pt-0.5" : "pl-0.5")}>
        <span
          className="shrink-0 rounded-full border border-black/10 dark:border-white/15"
          style={{
            width: Math.max(4, Math.min(20, size)),
            height: Math.max(4, Math.min(20, size)),
            backgroundColor: tool === "eraser" ? "transparent" : color,
            borderStyle: tool === "eraser" ? "dashed" : "solid",
          }}
          title={`${size}px`}
        />
        <StepperRow
          value={size}
          min={min}
          max={max}
          onChange={(next) => setStyle(setToolSize(style, tool, next))}
        >
          <input
            type="range"
            min={min}
            max={max}
            value={size}
            onChange={(e) => setStyle(setToolSize(style, tool, Number(e.target.value)))}
            aria-label="Thickness"
            title={`Thickness — ${size}px`}
            className={cn(
              "h-1.5 cursor-pointer appearance-none rounded-lg bg-muted accent-primary",
              vertical ? "w-16" : "w-24"
            )}
          />
        </StepperRow>
        <span className="w-9 shrink-0 text-[11px] font-semibold tabular-nums text-muted-foreground">
          {size}px
        </span>
      </div>

      {tool === "laser" && (
        <>
          <span className={cn("shrink-0 bg-border", vertical ? "h-px w-5" : "h-5 w-px")} />
          <div className={cn("flex shrink-0 gap-0.5 rounded-lg bg-muted p-0.5", vertical ? "flex-col" : "items-center")}>
            {LASER_MODES.map((m) => (
              <button
                key={m.id}
                onClick={() => setStyle({ laserMode: m.id })}
                title={m.hint}
                className={cn(
                  "rounded-md px-2 py-1 text-[11px] font-medium transition-colors",
                  (style.laserMode ?? "trail") === m.id
                    ? "bg-background shadow-sm"
                    : "text-muted-foreground hover:text-foreground"
                )}
              >
                {m.label}
              </button>
            ))}
          </div>
        </>
      )}

      {tool === "eraser" && (
        <>
          <span className={cn("shrink-0 bg-border", vertical ? "h-px w-5" : "h-5 w-px")} />
          <div className={cn("flex shrink-0 gap-0.5 rounded-lg bg-muted p-0.5", vertical ? "flex-col" : "items-center")}>
            {([
              { id: "pixel", label: "Pixel" },
              { id: "object", label: "Whole" },
            ] as const).map((m) => (
              <button
                key={m.id}
                onClick={() => setStyle({ eraserMode: m.id })}
                title={
                  m.id === "pixel"
                    ? "Rub out only the ink you touch; text boxes and pictures are left alone"
                    : "Delete the whole element on contact"
                }
                className={cn(
                  "rounded-md px-2 py-1 text-[11px] font-medium transition-colors",
                  style.eraserMode === m.id
                    ? "bg-background shadow-sm"
                    : "text-muted-foreground hover:text-foreground"
                )}
              >
                {m.label}
              </button>
            ))}
          </div>
        </>
      )}

      {showColor && (
        <>
          <span className={cn("shrink-0 bg-border", vertical ? "h-px w-5" : "h-5 w-px")} />
          {vertical ? (
            // Six swatches in a column would make the dock taller than the
            // window, so the colours open outward over the canvas instead.
            <Popover>
              <PopoverTrigger asChild>
                <button
                  title="Colour"
                  aria-label="Colour"
                  className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg border border-border transition-colors hover:bg-muted"
                >
                  <span
                    className="h-4 w-4 rounded-full border border-black/15 dark:border-white/20"
                    style={{ backgroundColor: color }}
                  />
                </button>
              </PopoverTrigger>
              <PopoverContent side={flyoutSide(dockPos)} align="center" className="w-auto p-2">
                <ColorRow
                  colors={isSticky ? stickyColorsList : tool === "laser" ? LASER_COLORS : PEN_COLORS}
                  value={color}
                  onChange={onColorChange}
                />
              </PopoverContent>
            </Popover>
          ) : (
            <ColorRow
              compact
              colors={isSticky ? stickyColorsList : tool === "laser" ? LASER_COLORS : PEN_COLORS.slice(0, 6)}
              value={color}
              onChange={onColorChange}
            />
          )}
        </>
      )}

      <span className={cn("shrink-0 bg-border", vertical ? "h-px w-5" : "h-5 w-px")} />
      <button
        onClick={onOpenPanel}
        title={`${tool === "laser" ? "Laser" : PEN_TYPE_PRESETS[tool as StrokeStyle]?.label ?? "Tool"} settings`}
        className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
      >
        <Settings2 size={15} />
      </button>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Full panel (opened from the ⚙)
// ---------------------------------------------------------------------------

/**
 * A tiny sample squiggle whose shape hints at the pen: tapered pens get a
 * stroke that narrows, even pens get a constant one.
 */
function penPreviewPath(style: StrokeStyle): string {
  const p = PEN_TYPE_PRESETS[style];
  return p.endTaper > 0 || p.thinning > 0.3
    ? "M2,13 C10,3 18,15 26,7 S40,3 44,6"
    : "M2,9 C10,4 18,14 26,9 S40,7 44,9";
}

// ---------------------------------------------------------------------------
// Pen panel - compact, in the manner of GoodNotes / Samsung Notes
// ---------------------------------------------------------------------------
//
// One small card: a live preview line, the pen types, thickness, colour, and
// a folded "Writing feel" section. The old panel was a near-full-screen sheet
// of engineering terms with a scratchpad that did not write like the page
// (different input path), which made it look like the pen was broken.

const SMOOTHING_CHOICES = [
  { value: 0, label: "Off" },
  { value: 25, label: "Low" },
  { value: 50, label: "Normal" },
  { value: 80, label: "High" },
] as const;

const PRESSURE_CHOICES: { value: PressureCurve; label: string; hint: string }[] = [
  { value: "off", label: "Off", hint: "Same width however hard you press." },
  { value: "soft", label: "Light", hint: "Full width with a light touch." },
  { value: "standard", label: "Normal", hint: "Width follows your pressure." },
  { value: "firm", label: "Firm", hint: "Press harder for a thicker line." },
];

/**
 * The preview line: a handwriting-like wave drawn by the SAME path builder
 * and pressure curve as the page, with a light-heavy-light pressure run like
 * a real stroke (0.2 to 0.6, the range measured from a Galaxy Tab S9 S Pen).
 */
function PenPreview({
  tool,
  color,
  size,
  smoothing,
  sensitivity,
  curve,
}: {
  tool: StrokeStyle;
  color: string;
  size: number;
  smoothing: number;
  sensitivity: number;
  curve: PressureCurve;
}) {
  const preset = PEN_TYPE_PRESETS[tool] ?? PEN_TYPE_PRESETS.gel;
  const d = React.useMemo(() => {
    const pts: Array<[number, number, number]> = [];
    const N = 90;
    for (let i = 0; i <= N; i++) {
      const t = i / N;
      const raw = 0.2 + 0.4 * Math.sin(t * Math.PI);
      pts.push([12 + t * 256, 30 + Math.sin(t * Math.PI * 5) * 11, calibratePressure(raw, sensitivity, curve)]);
    }
    return buildStrokePath({
      id: "preview",
      type: "stroke",
      x: 0,
      y: 0,
      rotation: 0,
      opacity: 1,
      createdAt: 0,
      updatedAt: 0,
      points: pts,
      color,
      strokeWidth: size,
      strokeStyle: tool,
      smoothing,
    });
  }, [tool, color, size, smoothing, sensitivity, curve]);
  return (
    <svg viewBox="0 0 280 60" className="h-14 w-full rounded-xl border border-border/70 bg-white dark:bg-zinc-950">
      <path
        d={d}
        fill={color}
        opacity={preset.opacity ?? 1}
        style={preset.mixBlendMode === "multiply" ? { mixBlendMode: "multiply" } : undefined}
      />
    </svg>
  );
}

function Choice<T extends string | number>({
  value,
  current,
  label,
  onPick,
}: {
  value: T;
  current: T;
  label: string;
  onPick: (v: T) => void;
}) {
  return (
    <button
      type="button"
      onClick={() => onPick(value)}
      className={cn(
        "flex-1 rounded-lg border py-1.5 text-[11px] font-medium transition-colors",
        current === value
          ? "border-primary bg-primary/10 text-primary"
          : "border-border text-muted-foreground hover:bg-muted"
      )}
    >
      {label}
    </button>
  );
}

function PenPanel({ onClose }: { onClose: () => void }) {
  const tool = useWhiteboard((s) => s.tool) as StrokeStyle;
  const style = useWhiteboard((s) => s.style);
  const setStyle = useWhiteboard((s) => s.setStyle);
  const setTool = useWhiteboard((s) => s.setTool);
  const touchSettings = useWhiteboard((s) => s.touchSettings);
  const setTouchSettings = useWhiteboard((s) => s.setTouchSettings);

  const color = getToolColor(style, tool);
  const size = getToolSize(style, tool);
  const { min, max } = sizeRangeFor(tool);
  // Each pen keeps its own feel; editing it here changes only this pen.
  const { smoothing, sensitivity, curve } = penFeelFor(touchSettings, tool);
  const setFeel = (patch: PenFeel) =>
    setTouchSettings({
      penFeel: { ...touchSettings.penFeel, [tool]: { ...touchSettings.penFeel?.[tool], ...patch } },
    });
  const usesPressure = penUsesPressure(tool);
  // What this pen does instead, where pressure has no effect.
  const noPressureNote =
    tool === "brush"
      ? "The brush gets thinner the faster you write."
      : "Same width on every stroke, however hard you press.";
  const curveHint = PRESSURE_CHOICES.find((c) => c.value === curve)?.hint ?? "";
  // Ballpoint and fineliner strokes still exist; they show as "Pen".
  const shownTool: StrokeStyle = tool === "ballpoint" || tool === "fineliner" ? "gel" : tool;
  // The closest named smoothing step, so a value set elsewhere still shows.
  const smoothingStep = SMOOTHING_CHOICES.reduce((a, c) =>
    Math.abs(c.value - smoothing) < Math.abs(a.value - smoothing) ? c : a
  ).value;

  return (
    <div
      data-wb-modal
      className="fixed inset-0 z-[85] flex items-end justify-center bg-black/10 pb-28 sm:items-center sm:pb-0"
      onClick={onClose}
    >
      <div
        className="max-h-[80vh] w-[20rem] max-w-[calc(100vw-2rem)] space-y-3 overflow-y-auto rounded-2xl border border-border bg-white p-3 shadow-2xl dark:bg-zinc-900"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold">{PEN_TYPE_PRESETS[tool]?.label ?? "Pen"}</h3>
          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={onClose} aria-label="Close pen settings">
            <X size={15} />
          </Button>
        </div>

        <PenPreview
          tool={tool}
          color={color}
          size={size}
          smoothing={smoothing}
          sensitivity={sensitivity}
          curve={curve}
        />

        <div className="grid grid-cols-3 gap-1">
          {PEN_TYPES.map((st) => {
            const p = PEN_TYPE_PRESETS[st];
            return (
              <button
                key={st}
                type="button"
                onClick={() => setTool(st as ToolType)}
                title={p.hint}
                className={cn(
                  "flex flex-col items-center gap-0.5 rounded-lg border px-1 py-1.5 transition-colors",
                  shownTool === st ? "border-primary bg-primary/10" : "border-transparent hover:bg-muted"
                )}
              >
                <svg width="34" height="14" viewBox="0 0 46 18" aria-hidden>
                  <path
                    d={penPreviewPath(st)}
                    fill="none"
                    stroke={color}
                    strokeLinecap={p.cap === "flat" ? "butt" : "round"}
                    strokeWidth={p.cap === "flat" ? 7 : 3}
                    opacity={p.opacity}
                  />
                </svg>
                <span className="w-full truncate text-center text-[10px] leading-tight">{p.label}</span>
              </button>
            );
          })}
        </div>

        <div>
          <div className="mb-1 flex items-center justify-between">
            <span className="text-xs font-medium">Thickness</span>
            <span className="text-[11px] font-semibold tabular-nums text-muted-foreground">{size}px</span>
          </div>
          <StepperRow value={size} min={min} max={max} onChange={(v) => setStyle(setToolSize(style, tool, v))}>
            <input
              type="range"
              min={min}
              max={max}
              value={size}
              aria-label="Thickness"
              onChange={(e) => setStyle(setToolSize(style, tool, Number(e.target.value)))}
              className="h-1.5 w-full cursor-pointer appearance-none rounded-lg bg-muted accent-primary"
            />
          </StepperRow>
        </div>

        <div>
          <div className="mb-1 text-xs font-medium">Colour</div>
          <ColorRow colors={PEN_COLORS} value={color} onChange={(c) => setStyle(setToolColor(style, tool, c))} />
        </div>

        <details className="group rounded-xl border border-border/70 px-2.5 py-2">
          <summary className="cursor-pointer select-none text-xs font-medium">
            Writing feel <span className="font-normal text-muted-foreground">(this pen only)</span>
          </summary>
          <div className="mt-2 space-y-3">
            <div>
              <div className="mb-1 text-[11px] text-muted-foreground">Smoothing</div>
              <div className="flex gap-1">
                {SMOOTHING_CHOICES.map((c) => (
                  <Choice
                    key={c.value}
                    value={c.value as number}
                    current={smoothingStep}
                    label={c.label}
                    onPick={(v) => setFeel({ smoothing: v })}
                  />
                ))}
              </div>
            </div>
            <div>
              <div className="mb-1 text-[11px] text-muted-foreground">Pressure</div>
              {usesPressure ? (
                <>
                  <div className="flex gap-1">
                    {PRESSURE_CHOICES.map((c) => (
                      <Choice
                        key={c.value}
                        value={c.value}
                        current={curve}
                        label={c.label}
                        onPick={(v) => setFeel({ curve: v })}
                      />
                    ))}
                  </div>
                  <p className="mt-1 text-[10px] text-muted-foreground">{curveHint}</p>
                </>
              ) : (
                <p className="text-[10px] text-muted-foreground">{noPressureNote}</p>
              )}
            </div>
            <label className="flex cursor-pointer items-center justify-between gap-3 text-[11px]">
              <span>Hold at the end of a line to straighten it</span>
              <input
                type="checkbox"
                checked={touchSettings.penAutoStraighten !== false}
                onChange={(e) => setTouchSettings({ penAutoStraighten: e.target.checked })}
                className="h-4 w-4 accent-primary"
              />
            </label>
            <label className="flex cursor-pointer items-center justify-between gap-3 text-[11px]">
              <span>Show a dot where the pen will touch</span>
              <input
                type="checkbox"
                checked={touchSettings.penHoverIndicator !== false}
                onChange={(e) => setTouchSettings({ penHoverIndicator: e.target.checked })}
                className="h-4 w-4 accent-primary"
              />
            </label>
          </div>
        </details>
      </div>
    </div>
  );
}

/** A small animated-looking sample of the laser in its current look. */
function LaserPreview({ mode, color, size }: { mode: LaserMode; color: string; size: number }) {
  const r = Math.max(2, Math.min(14, size / 2));
  return (
    <div className="flex h-16 items-center justify-center rounded-xl bg-zinc-900">
      <svg width="220" height="56" viewBox="0 0 220 56" aria-hidden>
        <defs>
          <filter id="laser-glow" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation={Math.max(1.5, r * 0.8)} />
          </filter>
          <linearGradient id="laser-tail" x1="0" x2="1">
            <stop offset="0" stopColor={color} stopOpacity="0" />
            <stop offset="1" stopColor={color} stopOpacity="1" />
          </linearGradient>
        </defs>
        {mode === "trail" && (
          <path d="M40 40 Q 90 8 150 28" fill="none" stroke="url(#laser-tail)" strokeWidth={r * 1.4} strokeLinecap="round" />
        )}
        {mode === "draw" && (
          <>
            <ellipse cx="110" cy="28" rx="70" ry="18" fill="none" stroke={color} strokeWidth={r * 1.2} filter="url(#laser-glow)" />
            <ellipse cx="110" cy="28" rx="70" ry="18" fill="none" stroke={color} strokeWidth={r * 1.2} />
            <ellipse cx="110" cy="28" rx="70" ry="18" fill="none" stroke="white" strokeOpacity="0.9" strokeWidth={Math.max(1, r * 0.4)} />
          </>
        )}
        {mode !== "draw" && (
          <>
            <circle cx="150" cy="28" r={r * 2.4} fill={color} opacity="0.45" filter="url(#laser-glow)" />
            <circle cx="150" cy="28" r={r} fill={color} />
            <circle cx="150" cy="28" r={r * 0.42} fill="white" opacity="0.92" />
          </>
        )}
      </svg>
    </div>
  );
}

function LaserPanel({ onClose }: { onClose: () => void }) {
  const style = useWhiteboard((s) => s.style);
  const setStyle = useWhiteboard((s) => s.setStyle);
  const mode = style.laserMode ?? "trail";
  const color = getToolColor(style, "laser");
  const size = getToolSize(style, "laser");
  const { min, max, presets } = sizeRangeFor("laser");
  const fade = style.laserFadeMs ?? 1500;

  return (
    <div
      data-wb-modal
      className="fixed inset-0 z-[85] flex items-end justify-center bg-black/10 pb-28 sm:items-center sm:pb-0"
      onClick={onClose}
    >
      <div
        className="max-h-[80vh] w-[20rem] max-w-[calc(100vw-2rem)] space-y-3 overflow-y-auto rounded-2xl border border-border bg-white p-3 shadow-2xl dark:bg-zinc-900"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold">Laser pointer</h3>
          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={onClose} aria-label="Close laser settings">
            <X size={15} />
          </Button>
        </div>

        <LaserPreview mode={mode} color={color} size={size} />

        <div>
          <div className="mb-1 text-xs font-medium">Type</div>
          <div className="grid grid-cols-3 gap-1">
            {LASER_MODES.map((m) => (
              <button
                key={m.id}
                type="button"
                onClick={() => setStyle({ laserMode: m.id })}
                className={cn(
                  "rounded-lg border px-1.5 py-1.5 text-left transition-colors",
                  mode === m.id ? "border-primary bg-primary/10 text-primary" : "border-border hover:bg-muted"
                )}
              >
                <span className="block text-[11px] font-semibold">{m.label}</span>
                <span className="block text-[10px] leading-tight text-muted-foreground">{m.hint}</span>
              </button>
            ))}
          </div>
        </div>

        <div>
          <div className="mb-1 flex items-center justify-between">
            <span className="text-xs font-medium">Size</span>
            <span className="text-[11px] font-semibold tabular-nums text-muted-foreground">{size}px</span>
          </div>
          <div className="mb-2 flex gap-1">
            {presets.map((p) => (
              <Choice key={p} value={p} current={size} label={`${p}`} onPick={(v) => setStyle(setToolSize(style, "laser", v))} />
            ))}
          </div>
          <StepperRow value={size} min={min} max={max} onChange={(v) => setStyle(setToolSize(style, "laser", v))}>
            <input
              type="range"
              min={min}
              max={max}
              value={size}
              aria-label="Laser size"
              onChange={(e) => setStyle(setToolSize(style, "laser", Number(e.target.value)))}
              className="h-1.5 w-full cursor-pointer appearance-none rounded-lg bg-muted accent-primary"
            />
          </StepperRow>
        </div>

        <div>
          <div className="mb-1 text-xs font-medium">Colour</div>
          <ColorRow colors={LASER_COLORS} value={color} onChange={(c) => setStyle(setToolColor(style, "laser", c))} />
        </div>

        {mode === "draw" && (
          <div>
            <div className="mb-1 text-xs font-medium">Lines stay for</div>
            <div className="flex gap-1">
              {LASER_FADE_CHOICES.map((c) => (
                <Choice key={c.value} value={c.value} current={fade} label={c.label} onPick={(v) => setStyle({ laserFadeMs: v })} />
              ))}
            </div>
          </div>
        )}

        <p className="text-[10px] leading-snug text-muted-foreground">
          The laser never writes on the page: nothing it shows is saved or exported. Hover the S Pen
          over the screen to point without touching.
        </p>
      </div>
    </div>
  );
}

export function ToolPropertiesPanel({ open, onClose }: { open: boolean; onClose: () => void }) {
  const tool = useWhiteboard((s) => s.tool);
  const style = useWhiteboard((s) => s.style);
  const setStyle = useWhiteboard((s) => s.setStyle);

  if (!open || !toolHasProperties(tool)) return null;
  if (STROKE_TOOLS.includes(tool)) return <PenPanel onClose={onClose} />;
  if (tool === "laser") return <LaserPanel onClose={onClose} />;

  const { min, max } = sizeRangeFor(tool);
  const color = getToolColor(style, tool);
  const size = getToolSize(style, tool);

  const isStroke = STROKE_TOOLS.includes(tool);
  const isShape = SHAPE_TOOLS.includes(tool);
  const isLine = LINE_TOOLS.includes(tool);
  const isText = TEXT_TOOLS.includes(tool);

  const title = isStroke
    ? PEN_TYPE_PRESETS[tool as StrokeStyle].label
    : tool.charAt(0).toUpperCase() + tool.slice(1);

  return (
    <div
      data-wb-modal
      className="fixed inset-0 z-[85] flex items-end justify-center bg-black/30 pb-28 backdrop-blur-[2px] sm:items-center sm:pb-0"
      onClick={onClose}
    >
      <div
        className={cn(
          "overflow-y-auto rounded-2xl border border-border bg-white p-4 shadow-2xl dark:bg-zinc-900 transition-all",
          isStroke ? "w-full max-w-md sm:max-w-lg max-h-[85vh]" : "w-full max-w-xs max-h-[70vh]"
        )}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-semibold">{title}</h3>
          </div>
          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={onClose}>
            <X size={15} />
          </Button>
        </div>

        <div className="space-y-4">
          {/* Thickness with quick preset pills */}
          <div>
            <div className="mb-1.5 flex items-center justify-between">
              <span className="text-xs font-medium">{isText ? "Font size" : "Thickness"}</span>
              <span className="rounded-md bg-muted px-2 py-0.5 text-xs font-semibold tabular-nums">
                {size}px
              </span>
            </div>
            {isStroke && (
              <div className="mb-2 flex gap-1">
                {[2, 4, 8, 16, 24].map((sz) => (
                  <button
                    key={sz}
                    type="button"
                    onClick={() => setStyle(setToolSize(style, tool, sz))}
                    className={cn(
                      "flex-1 rounded-md border py-1 text-[11px] font-semibold transition-colors",
                      size === sz
                        ? "border-primary bg-primary/10 text-primary"
                        : "border-border text-muted-foreground hover:bg-muted"
                    )}
                  >
                    {sz}px
                  </button>
                ))}
              </div>
            )}
            <StepperRow value={size} min={min} max={max} onChange={(v) => setStyle(setToolSize(style, tool, v))}>
              <input
                type="range"
                min={min}
                max={max}
                value={size}
                aria-label={isText ? "Font size" : "Thickness"}
                onChange={(e) => setStyle(setToolSize(style, tool, Number(e.target.value)))}
                className="h-1.5 w-full cursor-pointer appearance-none rounded-lg bg-muted accent-primary"
              />
            </StepperRow>
          </div>

          {tool === "eraser" && (
            <div>
              <div className="mb-1.5 text-xs font-medium">Eraser mode</div>
              <div className="flex gap-1.5">
                {([
                  { id: "pixel", label: "Pixel", hint: "Rub out ink" },
                  { id: "object", label: "Whole object", hint: "Delete on contact" },
                ] as const).map((m) => (
                  <button
                    key={m.id}
                    onClick={() => setStyle({ eraserMode: m.id })}
                    className={cn(
                      "flex-1 rounded-lg border px-2 py-1.5 text-left transition-colors",
                      style.eraserMode === m.id
                        ? "border-primary bg-primary/10 text-primary"
                        : "border-border hover:bg-muted"
                    )}
                  >
                    <span className="block text-[11px] font-medium">{m.label}</span>
                    <span className="block text-[10px] text-muted-foreground">{m.hint}</span>
                  </button>
                ))}
              </div>
              <p className="mt-1.5 text-[11px] leading-snug text-muted-foreground">
                Pixel rubs out ink only: drawn shapes and lines go whole, and text boxes, notes and
                pictures are never touched. Use Whole object to delete those.
              </p>
            </div>
          )}

          {tool !== "eraser" && (
            <div>
              <div className="mb-1.5 text-xs font-medium">Ink Colour</div>
              <ColorRow
                colors={PEN_COLORS}
                value={color}
                onChange={(c) => setStyle(setToolColor(style, tool, c))}
              />
            </div>
          )}

          {/* Shape-only: fill and outline style */}
          {(isShape || isLine) && (
            <>
              <div>
                <div className="mb-1.5 text-xs font-medium">Line style</div>
                <div className="flex gap-1.5">
                  {DASH_STYLES.map((d) => (
                    <button
                      key={d}
                      onClick={() => setStyle({ dashStyle: d })}
                      className={cn(
                        "flex-1 rounded-lg border px-2 py-1.5 text-[11px] capitalize transition-colors",
                        style.dashStyle === d
                          ? "border-primary bg-primary/10 text-primary"
                          : "border-border hover:bg-muted"
                      )}
                    >
                      {d}
                    </button>
                  ))}
                </div>
              </div>

              {isShape && (
                <>
                  <div>
                    <div className="mb-1.5 text-xs font-medium">Fill</div>
                    <ColorRow
                      colors={PEN_COLORS}
                      value={style.shapeFillColor}
                      onChange={(c) => setStyle({ shapeFillColor: c, fillColor: c })}
                      swatchSize={20}
                    />
                  </div>
                  <div>
                    <div className="mb-1.5 text-xs font-medium">Fill style</div>
                    <div className="flex gap-1.5">
                      {FILL_STYLES.map((f) => (
                        <button
                          key={f}
                          onClick={() => setStyle({ fillStyle: f })}
                          className={cn(
                            "flex-1 rounded-lg border px-2 py-1.5 text-[11px] capitalize transition-colors",
                            style.fillStyle === f
                              ? "border-primary bg-primary/10 text-primary"
                              : "border-border hover:bg-muted"
                          )}
                        >
                          {f}
                        </button>
                      ))}
                    </div>
                  </div>
                </>
              )}
            </>
          )}

          {/* Text-only */}
          {isText && (
            <div>
              <div className="mb-1.5 text-xs font-medium">Font</div>
              <div className="grid grid-cols-2 gap-1.5">
                {FONT_FAMILIES.map((f) => (
                  <button
                    key={f.value}
                    onClick={() => setStyle({ fontFamily: f.value })}
                    className={cn(
                      "truncate rounded-lg border px-2 py-1.5 text-[11px] transition-colors",
                      style.fontFamily === f.value
                        ? "border-primary bg-primary/10 text-primary"
                        : "border-border hover:bg-muted"
                    )}
                    style={{ fontFamily: f.value }}
                  >
                    {f.label}
                  </button>
                ))}
              </div>
            </div>
          )}

          {tool === "sticky" && (
            <div>
              <div className="mb-1.5 text-xs font-medium">Note colour</div>
              <div className="flex flex-wrap gap-1.5">
                {(Object.keys(STICKY_COLORS) as StickyColor[]).map((sc) => (
                  <Swatch
                    key={sc}
                    color={STICKY_COLORS[sc].bg}
                    title={sc}
                    active={style.stickyColor === sc}
                    onSelect={() => setStyle({ stickyColor: sc })}
                  />
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
