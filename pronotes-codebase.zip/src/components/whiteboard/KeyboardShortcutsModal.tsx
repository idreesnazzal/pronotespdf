"use client";

import React, { useState, useMemo } from "react";
import {
  Keyboard,
  Search,
  Wrench,
  Navigation,
  Edit3,
  BookOpen,
  Tablet,
  X,
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";

interface ShortcutItem {
  name: string;
  keys: string[];
  description?: string;
}

interface ShortcutCategory {
  id: string;
  name: string;
  icon: React.ElementType;
  shortcuts: ShortcutItem[];
}

const SHORTCUT_CATEGORIES: ShortcutCategory[] = [
  {
    id: "tools",
    name: "Drawing & Creation Tools",
    icon: Wrench,
    shortcuts: [
      { name: "Select Tool", keys: ["V"], description: "Default selection pointer" },
      { name: "Lasso Select", keys: ["Q"], description: "Freehand lasso multi-selection" },
      { name: "Pan Canvas", keys: ["H"], description: "Hand tool or hold Space" },
      { name: "Laser Pointer", keys: ["K"], description: "Point without writing; hover the pen to aim" },
      { name: "Select Text", keys: ["I"], description: "Select PDF / Word / PowerPoint text to copy or highlight" },
      { name: "Pen / Brush", keys: ["P"], description: "Freehand stroke drawing" },
      { name: "Highlighter", keys: ["Y"], description: "Semi-transparent highlighter" },
      { name: "Eraser", keys: ["E"], description: "Continuous drag or tap eraser" },
      { name: "Rectangle", keys: ["R"], description: "Create box or container" },
      { name: "Ellipse / Circle", keys: ["O"], description: "Create circle or oval" },
      { name: "Diamond", keys: ["D"], description: "Decision node shape" },
      { name: "Line", keys: ["L"], description: "Straight line segment" },
      { name: "Arrow", keys: ["A"], description: "Directional arrow line" },
      { name: "Text Box", keys: ["T"], description: "Click or double-click to type" },
      { name: "Sticky Note", keys: ["N"], description: "Colored markdown note card" },
      { name: "Smart Connector", keys: ["C"], description: "Connect notes with typed relationship" },
      { name: "Upload Image", keys: ["I"], description: "Insert image or paste via Ctrl+V" },
    ],
  },
  {
    id: "navigation",
    name: "Navigation & View",
    icon: Navigation,
    shortcuts: [
      { name: "Pan Canvas", keys: ["Space", "Drag"], description: "Or hold Middle Mouse button" },
      { name: "Zoom In / Out", keys: ["Ctrl", "+ / -"], description: "Or Ctrl + Mouse Wheel" },
      { name: "Reset Zoom to 100%", keys: ["Ctrl", "0"], description: "Default 1:1 camera scale" },
      { name: "Zoom to Fit Content", keys: ["Shift", "1"], description: "Fit all board elements in view" },
      { name: "Toggle Minimap", keys: ["M"], description: "Radar navigator overlay" },
      { name: "Toggle Theme", keys: ["Ctrl", "Shift", "D"], description: "Switch Dark / Light / System theme" },
    ],
  },
  {
    id: "editing",
    name: "Selection & Editing",
    icon: Edit3,
    shortcuts: [
      { name: "Select All", keys: ["Ctrl", "A"], description: "Select all elements on active board" },
      { name: "Delete Selected", keys: ["Delete"], description: "Or Backspace key" },
      { name: "Undo", keys: ["Ctrl", "Z"], description: "Undo last canvas modification" },
      { name: "Redo", keys: ["Ctrl", "Y"], description: "Or Ctrl + Shift + Z" },
      { name: "Duplicate Elements", keys: ["Ctrl", "D"], description: "Clone selected elements" },
      { name: "Lock / Unlock", keys: ["Ctrl", "Shift", "L"], description: "Prevent accidental moving" },
      { name: "Bring to Front", keys: ["Ctrl", "]"], description: "Move element to top layer" },
      { name: "Send to Back", keys: ["Ctrl", "["], description: "Move element to background layer" },
      { name: "Snap to Grid", keys: ["Ctrl", "Shift", "G"], description: "Or press S to toggle grid alignment" },
      { name: "Clear Selection / Exit", keys: ["Esc"], description: "Deselect or cancel active interaction" },
    ],
  },
  {
    id: "obsidian",
    name: "Obsidian & Knowledge Graph",
    icon: BookOpen,
    shortcuts: [
      { name: "Search Everywhere", keys: ["Ctrl", "K"], description: "Names, folders, tags, text, stickies, PDF text - nearest first" },
      { name: "Find in This Note", keys: ["Ctrl", "F"], description: "Step through matches with Enter / Shift+Enter" },
      { name: "Next Page", keys: ["Page Down"], description: "Turn to the next page of a notebook" },
      { name: "Previous Page", keys: ["Page Up"], description: "Turn to the previous page of a notebook" },
      { name: "Knowledge Graph View", keys: ["Ctrl", "G"], description: "Interactive bi-directional network graph" },
      { name: "Toggle Backlinks Panel", keys: ["Ctrl", "B"], description: "Inspect incoming and outgoing links" },
      { name: "Link Files Manager", keys: ["Ctrl", "L"], description: "Batch connect boards and references" },
      { name: "Export Board", keys: ["Ctrl", "E"], description: "Export to high-res PNG or vector SVG" },
      { name: "Obsidian WikiLink", keys: ["[[Board]]"], description: "Syntax to link any board inline" },
      { name: "Tag Classification", keys: ["#tag"], description: "Syntax to categorize notes and thoughts" },
      { name: "Keyboard Shortcuts Help", keys: ["?"], description: "Or Ctrl + / to open this help modal" },
    ],
  },
  {
    id: "touch",
    name: "Touchscreen & Stylus Gestures",
    icon: Tablet,
    shortcuts: [
      { name: "Pinch to Zoom", keys: ["2-Finger Pinch"], description: "Smooth zoom in and out centered on fingers" },
      { name: "2-Finger Pan", keys: ["2-Finger Drag"], description: "Pan canvas smoothly while drawing" },
      { name: "Quick Undo", keys: ["2-Finger Tap"], description: "Tap two fingers together on screen" },
      { name: "Quick Redo", keys: ["3-Finger Tap"], description: "Tap three fingers together on screen" },
      { name: "Create Quick Note", keys: ["Double Tap"], description: "Double-tap empty canvas with finger or stylus" },
      { name: "Palm Rejection", keys: ["Stylus Mode"], description: "Exempts palm touches from drawing" },
    ],
  },
];

interface KeyboardShortcutsModalProps {
  open: boolean;
  onClose: () => void;
}

export function KeyboardShortcutsModal({ open, onClose }: KeyboardShortcutsModalProps) {
  const [searchQuery, setSearchQuery] = useState("");

  const filteredCategories = useMemo(() => {
    const q = searchQuery.toLowerCase().trim();
    if (!q) return SHORTCUT_CATEGORIES;

    return SHORTCUT_CATEGORIES.map((cat) => {
      const filtered = cat.shortcuts.filter(
        (item) =>
          item.name.toLowerCase().includes(q) ||
          item.keys.some((k) => k.toLowerCase().includes(q)) ||
          (item.description && item.description.toLowerCase().includes(q))
      );
      return { ...cat, shortcuts: filtered };
    }).filter((cat) => cat.shortcuts.length > 0);
  }, [searchQuery]);

  return (
    <Dialog open={open} onOpenChange={(isOpen) => !isOpen && onClose()}>
      <DialogContent className="max-w-3xl max-h-[85vh] p-0 gap-0 overflow-hidden bg-white/98 dark:bg-zinc-900/98 backdrop-blur-xl border border-border/80 shadow-2xl rounded-2xl flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b border-border/60 bg-muted/20 flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-primary/10 text-primary flex items-center justify-center font-bold">
                <Keyboard size={18} />
              </div>
              <div>
                <DialogTitle className="text-base font-semibold text-foreground">
                  Keyboard Shortcuts & Gestures
                </DialogTitle>
                <DialogDescription className="text-xs text-muted-foreground">
                  Pro-grade hotkeys for keyboard, mouse, and multi-touch tablet controls.
                </DialogDescription>
              </div>
            </div>
          </div>

          {/* Live Search Box */}
          <div className="relative">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search shortcuts (e.g., zoom, pen, wikilink, export, undo)…"
              className="h-9 pl-9 text-xs bg-background/80"
              autoFocus
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery("")}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              >
                <X size={14} />
              </button>
            )}
          </div>
        </div>

        {/* Scrollable Shortcut Cards */}
        <ScrollArea className="flex-1 p-6 overflow-y-auto max-h-[60vh]">
          {filteredCategories.length === 0 ? (
            <div className="py-12 text-center text-xs text-muted-foreground">
              No shortcuts found matching &ldquo;{searchQuery}&rdquo;
            </div>
          ) : (
            <div className="space-y-6">
              {filteredCategories.map((category) => {
                const Icon = category.icon;
                return (
                  <div key={category.id} className="space-y-2.5">
                    <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                      <Icon size={14} className="text-primary" />
                      <span>{category.name}</span>
                      <span className="text-[10px] font-normal px-1.5 py-0.2 rounded-full bg-muted">
                        {category.shortcuts.length}
                      </span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                      {category.shortcuts.map((item, idx) => (
                        <div
                          key={idx}
                          className="flex items-center justify-between p-2.5 rounded-xl border border-border/70 bg-card/60 hover:bg-muted/40 transition-colors"
                        >
                          <div className="space-y-0.5 pr-2 truncate">
                            <div className="text-xs font-medium text-foreground truncate">
                              {item.name}
                            </div>
                            {item.description && (
                              <div className="text-[11px] text-muted-foreground truncate">
                                {item.description}
                              </div>
                            )}
                          </div>

                          <div className="flex items-center gap-1 shrink-0">
                            {item.keys.map((k, kIdx) => (
                              <React.Fragment key={kIdx}>
                                <kbd className="px-2 py-1 text-[11px] font-mono font-semibold text-foreground bg-muted/80 border border-border/80 rounded-md shadow-xs">
                                  {k}
                                </kbd>
                                {kIdx < item.keys.length - 1 && (
                                  <span className="text-xs text-muted-foreground">+</span>
                                )}
                              </React.Fragment>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </ScrollArea>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-border/60 bg-muted/20 flex items-center justify-between text-xs text-muted-foreground">
          <span>Press <kbd className="px-1.5 py-0.5 font-mono text-[10px] bg-muted border rounded">?</kbd> anywhere on canvas to open help</span>
          <span>ProNotes v3</span>
        </div>
      </DialogContent>
    </Dialog>
  );
}
