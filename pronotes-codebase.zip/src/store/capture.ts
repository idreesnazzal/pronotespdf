/**
 * Screenshot mode and the open capture, kept out of the main store.
 *
 * Screenshot mode is a switch on the SELECT tool: while it is on, the box or
 * loop you draw with Select takes a picture of that area instead of picking
 * up objects. It stays on until you switch it off, so several captures can be
 * taken in a row - and it only acts while Select (box) or Lasso is the tool,
 * so picking up the pen writes as always.
 *
 * Both are TRANSIENT on purpose: nothing here is persisted, so the app never
 * starts up with the select tool mysteriously refusing to select because a
 * mode was left on last week.
 */

import { create } from "zustand";
import type { CaptureShape, CaptureSource } from "@/lib/whiteboard/capture";

export interface CaptureRequest {
  source: CaptureSource;
  /** Drawn over an area, or taken from the current selection. */
  origin: "area" | "selection";
  shape: CaptureShape;
  /** What was selected, for the panel's "selection only" choice. */
  selectionIds?: string[];
  /** The zoom and pixel ratio it was seen at, for the default sharpness. */
  zoom: number;
  dpr: number;
}

interface CaptureState {
  screenshotMode: boolean;
  request: CaptureRequest | null;
  setScreenshotMode: (on: boolean) => void;
  open: (request: CaptureRequest) => void;
  close: () => void;
}

export const useCapture = create<CaptureState>((set) => ({
  screenshotMode: false,
  request: null,
  setScreenshotMode: (on) => set({ screenshotMode: on }),
  open: (request) => set({ request }),
  close: () => set({ request: null }),
}));

/**
 * The shape a press will capture with right now, or null when a press does
 * what it normally does. Screenshot mode only borrows the SELECT gestures.
 */
export function screenshotShapeFor(screenshotMode: boolean, tool: string): CaptureShape | null {
  if (!screenshotMode) return null;
  if (tool === "select") return "rectangle";
  if (tool === "lasso") return "lasso";
  return null;
}
