/**
 * Whiteboard Zustand Store (v3 — Obsidian Canvas & Vector Grade)
 * ===============================================================
 * Single source of truth for documents, canvas elements, history, and active editing state.
 */

import { create } from "zustand";
import { nanoid } from "nanoid";
import {
  getActivePageIndex as getActivePageIndexOf,
  addPage as nbAddPage,
  addPageBefore as nbAddPageBefore,
  togglePageBookmark as nbTogglePageBookmark,
  templateFromPage,
  insertTemplatePage,
  getPages,
  pageSizeOf,
  allElements,
  cloneBoardContent,
  deletePage as nbDeletePage,
  duplicatePage as nbDuplicatePage,
  getActivePage,
  getBoardElements,
  isNotebook,
  makeNotebook,
  mapAllBoardElements,
  mapBoardElements,
  movePage as nbMovePage,
  setActivePage,
  setActivePage as nbSetActivePage,
  setPageBackground as nbSetPageBackground,
  stepPage as nbStepPage,
  insertPageAt as nbInsertPageAt,
  copyPagesFrom,
  insertPages as nbInsertPages,
  pageFromPdf,
  resolvePageRange,
  createPage,
} from "../lib/whiteboard/notebook";
import { placeCaptureBeside, placeCaptureOnPage } from "../lib/whiteboard/placement";
import { PAGE_GAP as PAGE_GAP_STORE, minNotebookZoom } from "../lib/whiteboard/notebook";
import { collectReferencedAssets } from "../lib/whiteboard/workspace";
import { isAbandonedTextBox } from "../lib/whiteboard/textbox";
import {
  DEFAULT_STYLE,
  DEFAULT_TOUCH_SETTINGS,
  DEFAULT_PAGE_SIZE,
  DEFAULT_TOOLBAR_ITEMS,
  ALL_TOOLBAR_ITEMS,
  mergeToolbarItems,
  type ToolbarItemId,
  type Board,
  type BoardBackground,
  type PageSizeId,
  type PageTemplate,
  type Camera,
  type ConnectionElement,
  type ConnectionRouting,
  type Folder,
  type NodeAnchor,
  type DockPosition,
  type SplitOrientation,
  type PinnedBarPosition,
  type PinnedPen,
  type StyleState,
  type ToolType,
  type TouchSettings,
  type NotebookPage,
  type ImageElement,
  type WhiteboardElement,
} from "../lib/whiteboard/types";
import {
  buildToolInk,
  getToolColor,
  getToolSize,
  isStrokeTool,
  setToolInk,
  STROKE_TOOL_IDS,
} from "../lib/whiteboard/types";
import { MIN_ZOOM, MAX_ZOOM, effectiveSelectFilter, passesSelectFilter } from "../lib/whiteboard/types";
import { resolveDictationLang } from "../lib/whiteboard/speechRecognition";
import { clamp, type Viewport, getElementBounds } from "../lib/whiteboard/geometry";
import { focusBounds } from "../lib/whiteboard/search";
import {
  loadState,
  loadWorkspace,
  scheduleSave,
  flushSave,
  watchExternalSaves,
  loadHistory,
  scheduleHistorySave,
  flushHistorySave,
  restorableHistory,
  HISTORY_PAST_MAX,
  HISTORY_FUTURE_MAX,
} from "../lib/whiteboard/persistence";
import { requestPersistentStorage, workspaceDbAvailable } from "../lib/whiteboard/workspaceDb";
import {
  mergeWorkspaces,
  type MergeReport,
  type WorkspaceSnapshot,
} from "../lib/whiteboard/workspace";

/**
 * Keeps a notebook's camera inside the document.
 *
 * A whiteboard is meant to be unbounded. A notebook is a finite stack of
 * sheets, and panning past the ends put you in an empty grey void with the
 * paper nowhere on screen and no way back except zoom-to-fit — measured on a
 * Galaxy Tab S9 as a full screen of nothing after a few swipes. That is what
 * "it goes to a very far place" was.
 *
 * Geometry: the ACTIVE page always sits at world origin, so page `i` sits at
 * `(i - activeIndex) * stride`. The document therefore runs from
 * `-(activeIndex * stride)` to `(lastIndex - activeIndex) * stride + height`.
 * Both bounds are expressed that way so they keep moving with the anchor and
 * never fight the re-anchoring that turns pages.
 *
 * The slack is deliberately generous — you must be able to pull the first page
 * down to a comfortable writing position — but finite.
 */
function boundCamera<T extends { boards: Board[]; activeBoardId: string | null }>(
  s: T,
  camera: Camera
): Camera {
  const board = s.boards.find((b) => b.id === s.activeBoardId);
  if (!isNotebook(board)) return camera;

  const { width, height } = pageSizeOf(board);
  const pages = getPages(board);
  const count = Math.max(1, pages.length);
  const activeIndex = Math.max(0, getActivePageIndexOf(board));
  const stride = height + PAGE_GAP_STORE;

  const xSlack = width * 0.5;
  const ySlack = height * 0.5;
  const top = -(activeIndex * stride) - ySlack;
  const bottom = (count - 1 - activeIndex) * stride + height + ySlack;

  return {
    ...camera,
    x: clamp(camera.x, -xSlack, width + xSlack),
    y: clamp(camera.y, top, bottom),
  };
}

export interface PersistedState {
  version: number;
  folders: Folder[];
  boards: Board[];
  activeBoardId: string | null;
  activeFolderId: string | null;
  customLinkTypes?: Array<{ id: string; name: string; color: string }>;
  pinnedPens?: PinnedPen[];
  pinnedBarPos?: PinnedBarPosition | null;
  toolbarPosition?: DockPosition;
  pageTemplates?: PageTemplate[];
  splitBoardId?: string | null;
  splitRatio?: number;
  splitSide?: "left" | "right";
  splitOrientation?: SplitOrientation;
  recentColors?: string[];
  // Tool setup and preferences. Without these, every pen colour, size, font
  // size and the stylus mode reset to defaults on every launch.
  style?: Partial<StyleState>;
  tool?: ToolType;
  lastStrokeTool?: ToolType;
  touchSettings?: Partial<TouchSettings>;
  snapToGrid?: boolean;
  minimapOpen?: boolean;
  legendOpen?: boolean;
  zoomDockOpen?: boolean;
  shapeRecognition?: boolean;
  defaultPaper?: BoardBackground;
  pinnedBarOpen?: boolean;
  pinnedBarVertical?: boolean;
  propsPanelCollapsed?: boolean;
  /** Spoken language for voice dictation (BCP-47, e.g. "he-IL"). */
  dictationLang?: string;
  /** Samsung-style strict encircle: loops must close, neighbours only grazed stay out. */
  lassoStrict?: boolean;
  /** Tool properties row folded away behind the dock's chevron. */
  toolPropsBarCollapsed?: boolean;
  /** Saved as `toolbarTools`: lists saved under the first name still held the hand. */
  toolbarTools?: ToolbarItemId[];
  toolbarHidden?: ToolbarItemId[];
}

interface HistoryEntry {
  /**
   * Notebooks only. Undo must put the strokes back on the page they came
   * from — without this, undoing after turning the page would restore page 3's
   * content on top of page 7.
   */
  pageId?: string;
  elements: WhiteboardElement[];
  /** Full pages snapshot of a notebook for page structure changes (e.g. merge/insert). */
  pages?: NotebookPage[];
  boardId: string;
  /**
   * The document that was LIVE when this was recorded. Usually the same as
   * `boardId`; different when an action changed another notebook from here -
   * merging pages into a closed notebook from the Duplicate dialog. Undo
   * reverses what you did from where you are (see lastIndexForContext).
   * Missing on entries saved by older builds, which means `boardId`.
   */
  activeAt?: string;
  /** Epoch ms. Orders entries back into one list when restored after a restart. */
  at?: number;
}

interface HistoryState {
  past: HistoryEntry[];
  future: HistoryEntry[];
}

/**
 * One sidebar deletion, restorable. Boards keep their original indices so
 * undo puts the tree back exactly; folders keep whole objects; boards a
 * trashed folder filed to root remember where they came from. Asset bytes
 * stay in IndexedDB while this lives (see collectReferencedAssets).
 */
export interface TrashBuffer {
  removedBoards: Array<{ board: Board; index: number }>;
  removedFolders: Folder[];
  movedToRoot: Array<{ id: string; folderId: string | null }>;
  activeBoardId: string | null;
  activeFolderId: string | null;
  at: number;
}

interface WhiteboardState {
  // Document tree
  folders: Folder[];
  boards: Board[];
  activeBoardId: string | null;
  activeFolderId: string | null;

  // Active board canvas state
  camera: Camera;
  tool: ToolType;
  style: StyleState;
  selectedIds: string[];
  editingId: string | null; // ID of text/sticky element currently being edited inline
  customLinkTypes: Array<{ id: string; name: string; color: string }>;

  // History per board
  history: HistoryState;

  // UI & Touch state
  sidebarOpen: boolean;
  sidebarSortBy: "updated" | "created" | "name";
  sidebarSortOrder: "asc" | "desc";
  pagePanelOpen: boolean;
  isExporting: boolean;
  isReady: boolean;
  minimapOpen: boolean;
  legendOpen: boolean;
  zoomDockOpen: boolean;
  /** Pen strokes that are clearly a shape become that exact shape. */
  shapeRecognition: boolean;
  toggleShapeRecognition: () => void;
  /** Selection inspector folded to its header bar (the compact panel option). */
  propsPanelCollapsed: boolean;
  /**
   * The ACTIVE TOOL's properties row (colour, thickness) folded away. Distinct
   * from propsPanelCollapsed, which is the selection inspector.
   */
  toolPropsBarCollapsed: boolean;
  toggleToolPropsBar: () => void;
  /** The tool bar's buttons, in order (its "Customize tool bar" button). */
  toolbarItems: ToolbarItemId[];
  setToolbarItems: (items: ToolbarItemId[]) => void;
  /**
   * "Locked items" mode of the Select tool: while on, ONLY locked things can
   * be picked, so they can be unlocked (see LockedModeBar). Never saved.
   */
  lockedMode: boolean;
  /** The picture open in the image editor, if any. Never saved. */
  imageStudioId: string | null;
  snapToGrid: boolean;
  touchSettings: TouchSettings;
  /** App default paper: new boards and new pages start with it. Past notes keep theirs. */
  defaultPaper: BoardBackground;

  /** Colours the user actually mixed, most recent first (max 8). */
  recentColors: string[];
  addRecentColor: (color: string) => void;

  // Favorite pens bar
  pinnedPens: PinnedPen[];
  pinnedBarOpen: boolean;
  pinnedBarPos: PinnedBarPosition | null;
  toolbarPosition: DockPosition;
  addPinnedPen: (pen: Omit<PinnedPen, "id">) => string;
  pinCurrentPen: () => string | null;
  updatePinnedPen: (id: string, patch: Partial<Omit<PinnedPen, "id">>) => void;
  removePinnedPen: (id: string) => void;
  reorderPinnedPens: (fromIndex: number, toIndex: number) => void;
  applyPinnedPen: (id: string) => void;
  togglePinnedBar: () => void;
  setPinnedBarPos: (pos: PinnedBarPosition | null) => void;
  setToolbarPosition: (pos: DockPosition) => void;

  // ----- Split view -----
  /** The board shown in the reference pane, or null when the split is closed. */
  splitBoardId: string | null;
  /** Fraction of the width given to the editable pane, 0.2-0.8. */
  splitRatio: number;
  setSplitBoard: (boardId: string | null) => void;
  setSplitRatio: (ratio: number) => void;
  /**
   * Stores a camera against a board that is NOT the active one — the split
   * view's other pane. Both panes then read the same camera per document, so
   * swapping which side is editable does not move anything.
   */
  setBoardCamera: (boardId: string, camera: Camera) => void;
  swapSplit: () => void;
  /**
   * Which slot holds the editable document. "left" is the FIRST slot: the
   * left pane side by side, the TOP pane when stacked.
   */
  splitSide: "left" | "right";
  /** Side by side (left | right) or stacked (top / bottom). */
  splitOrientation: SplitOrientation;
  setSplitOrientation: (o: SplitOrientation) => void;
  /** Makes the document on `side` the editable one, leaving both in place. */
  focusSplitSide: (side: "left" | "right") => void;
  /** Opens a split with an explicit document in each slot (first = left/top). */
  setSplitPair: (leftBoardId: string, rightBoardId: string, orientation?: SplitOrientation) => void;
  /** Vertical rail or horizontal strip — a strip is what you want docked at the top. */
  pinnedBarVertical: boolean;
  togglePinnedBarOrientation: () => void;

  setTouchSettings: (settings: Partial<TouchSettings>) => void;
  /** Spoken language for voice dictation (BCP-47, e.g. "he-IL"). */
  dictationLang: string;
  setDictationLang: (lang: string) => void;
  /** Samsung-style strict encircle: loops must close, neighbours only grazed stay out. */
  lassoStrict: boolean;
  setLassoStrict: (strict: boolean) => void;
  toggleMinimap: () => void;
  setMinimapOpen: (open: boolean) => void;
  toggleLegend: () => void;
  setLegendOpen: (open: boolean) => void;
  toggleZoomDock: () => void;
  setZoomDockOpen: (open: boolean) => void;
  setPropsPanelCollapsed: (collapsed: boolean) => void;
  toggleSnapToGrid: () => void;
  setSnapToGrid: (snap: boolean) => void;
  togglePagePanel: () => void;
  setPagePanelOpen: (open: boolean) => void;


  // Initialization
  init: () => void;

  // Custom link types
  addCustomLinkType: (name: string, color: string) => string;
  removeCustomLinkType: (id: string) => void;

  // Folders
  createFolder: (name: string, parentId: string | null, color?: string) => string;
  renameFolder: (folderId: string, name: string) => void;
  deleteFolder: (folderId: string) => void;
  toggleFolderExpanded: (folderId: string) => void;
  revealFolder: (folderId: string) => void;
  /**
   * Open a board AND centre the viewport on one element, selecting it (unless
   * `select: false` - search only shows where a match is). In a notebook the
   * element may be on any page; that page is turned to.
   */
  focusElement: (boardId: string, elementId: string, opts?: { select?: boolean }) => void;
  moveFolder: (folderId: string, newParentId: string | null) => void;
  setFolderColor: (folderId: string, color: string) => void;

  // Boards
  createBoard: (name: string, folderId: string | null, color?: string) => string;
  createNotebook: (name: string, folderId: string | null, pageSize?: PageSizeId, color?: string) => string;
  convertToNotebook: (boardId: string, pageSize?: PageSizeId) => void;
  /**
   * Deletes PDFs and images in IndexedDB that no board references any more.
   * Without it, deleting a PDF notebook strands tens of megabytes that nothing
   * can ever open again.
   */
  pruneOrphanedAssets: () => Promise<void>;
  importPdfAsNotebook: (file: File, folderId?: string | null) => Promise<string>;
  /**
   * PDF, Word (.docx) or PowerPoint (.pptx) -> a notebook. Office files are
   * converted to a PDF on the device first (lib/whiteboard/officeImport.ts),
   * then imported exactly like a PDF, so everything that works on PDF
   * notebooks works on them. Every import path calls this one.
   */
  importDocumentAsNotebook: (
    file: File,
    folderId?: string | null,
    onProgress?: (p: { label: string; done: number; total: number }) => void
  ) => Promise<string>;
  /**
   * Inserts a run of pages from ANOTHER board into a notebook (targetBoardId or active).
   * `range` can be { from, to }, { indices }, or number[] (0-based indices).
   * `atIndex` is 0-based and clamped.
   * Returns how many pages were inserted.
   */
  insertPagesFromBoard: (
    sourceBoardId: string,
    range: { from?: number; to?: number; indices?: number[] } | number[],
    atIndex: number,
    targetBoardId?: string
  ) => number;
  /**
   * Inserts a run of pages from a PDF file into the active notebook.
   * `range` is 1-based and inclusive over the PDF's own page numbering.
   */
  insertPdfPages: (
    file: File,
    range: { from: number; to: number },
    atIndex: number
  ) => Promise<number>;
  addImagePages: (images: Array<{ src: string; width: number; height: number }>) => void;
  /**
   * Adds a captured picture to ANY document, as one undoable step taken from
   * the document you are in. A notebook gets it on a fresh page (after
   * `afterPageId`, or at the end); a whiteboard gets it beside its content.
   * Returns where it went, or null when the document does not exist.
   */
  addCaptureToBoard: (
    boardId: string,
    image: {
      src: string;
      naturalWidth: number;
      naturalHeight: number;
      /** Its size on the page it came from, in world units. */
      size: { width: number; height: number };
      afterPageId?: string;
    }
  ) => { elementId: string; pageId?: string; pageNumber?: number } | null;

  // ----- Notebook pages -----
  addPage: (afterPageId?: string) => void;
  addPageBefore: (pageId: string) => void;
  togglePageBookmark: (pageId: string) => void;

  // ----- Page templates -----
  pageTemplates: PageTemplate[];
  savePageAsTemplate: (pageId: string, name: string) => void;
  deletePageTemplate: (templateId: string) => void;
  addPageFromTemplate: (templateId: string, afterPageId?: string) => void;
  createImageTemplate: (name: string, src: string, width: number, height: number) => void;
  deletePage: (pageId: string) => void;
  duplicatePage: (pageId: string) => void;
  movePage: (pageId: string, toIndex: number) => void;
  setActivePage: (pageId: string) => void;
  stepPage: (delta: number) => void;
  /**
   * Inserts a blank page at `index` (0 = above the first, pages.length = below
   * the last) and keeps the view still, so the new sheet appears exactly where
   * the "+" between two pages was tapped.
   */
  insertPageAt: (index: number) => void;
  /** Opens a page and shows its TOP, rather than the scroll offset of the last one. */
  goToPage: (pageId: string, viewportHeight: number) => void;
  reanchorPage: (delta: number, stride: number) => void;
  /**
   * The same page hand-over as `reanchorPage`, for a notebook that is NOT the
   * live one - the split view's other pane scrolls continuously too.
   */
  reanchorBoardPage: (boardId: string, delta: number, stride: number) => void;
  /**
   * Opens a page of a notebook that is not the live one, showing its top -
   * the split pane's page buttons. The notebook's OWN active page changes, so
   * the page you were reading is the page you get when you start writing.
   */
  goToBoardPage: (boardId: string, pageId: string, viewportHeight: number) => void;
  setPageBackground: (pageId: string, patch: Partial<BoardBackground>) => void;
  setPageSize: (pageSize: PageSizeId) => void;
  renameBoard: (boardId: string, name: string) => void;
  deleteBoard: (boardId: string) => void;
  duplicateBoard: (boardId: string) => string | null;
  duplicateNotebook: (
    sourceBoardId: string,
    options: { name?: string; folderId?: string | null; pageIndices?: number[] }
  ) => string | null;
  setActiveBoard: (boardId: string) => void;
  moveBoard: (boardId: string, newFolderId: string | null) => void;
  setBoardColor: (boardId: string, color: string) => void;
  setBoardBackground: (
    boardId: string,
    patch: Partial<BoardBackground>,
    opts?: { allPages?: boolean }
  ) => void;
  /** Save paper as the app default for FUTURE boards and pages. */
  setDefaultPaper: (patch: Partial<BoardBackground>) => void;
  toggleStarred: (boardId: string) => void;
  addTag: (boardId: string, tag: string) => void;
  removeTag: (boardId: string, tag: string) => void;
  findOrCreateBoardByName: (name: string) => string;
  searchBoards: (query: string) => Array<{ boardId: string; boardName: string; snippet: string; elementId: string }>;
  getRecentBoards: (limit?: number) => Board[];
  getStarredBoards: () => Board[];
  setSidebarSort: (by: "updated" | "created" | "name", order?: "asc" | "desc") => void;
  batchMoveBoards: (boardIds: string[], targetFolderId: string | null) => void;
  batchDeleteBoards: (boardIds: string[]) => void;
  batchStarBoards: (boardIds: string[], star?: boolean) => void;
  /**
   * Full copies via duplicateBoard (notebooks keep every page, images and
   * PDFs stay referenced by id — no byte duplication). Returns the new ids.
   */
  batchDuplicateBoards: (boardIds: string[]) => string[];
  /**
   * Session-only trash buffer for sidebar deletes. NOT persisted: undo does
   * not survive a restart (the deletion stands), which also bounds how long
   * deleted pictures/PDFs must be protected from the asset pruner.
   */
  lastDeleted: TrashBuffer | null;
  /**
   * Removes boards + folder subtrees like the old delete paths (folders go,
   * their boards survive at root), but keeps everything needed to undo.
   * Unknown ids are ignored; a call that removes nothing leaves any
   * existing buffer — and the toast — alone.
   */
  trashItems: (boardIds: string[], folderIds: string[]) => void;
  /** Restores the trash buffer; a no-op when there is nothing to restore. */
  undoTrash: () => void;
  /** Drops the buffer (undo expires) and reclaims newly orphaned assets. */
  discardTrash: () => void;

  // Elements
  addElement: (el: WhiteboardElement, commit?: boolean) => void;
  addElements: (els: WhiteboardElement[], commit?: boolean) => void;
  /** Add an element to a SPECIFIC board without switching the active board
   *  (switching boards wipes camera/selection/history — wrong for background writes). */
  addElementToBoard: (boardId: string, el: WhiteboardElement, commit?: boolean) => void;
  /** Delete elements from a SPECIFIC board without switching the active board. */
  deleteElementFromBoard: (boardId: string, ids: string[], commit?: boolean) => void;
  updateElement: (id: string, patch: Partial<WhiteboardElement>, commit?: boolean) => void;
  updateElements: (ids: string[], patch: Partial<WhiteboardElement>, commit?: boolean) => void;
  deleteElements: (ids: string[], commit?: boolean) => void;
  deleteSelected: () => void;
  duplicateElements: (ids: string[]) => string[];
  toggleLock: (ids: string[]) => void;
  /** Unlocks these (never locks). Returns how many were locked before. */
  unlockElements: (ids: string[]) => number;
  setLockedMode: (on: boolean) => void;
  setImageStudioId: (id: string | null) => void;
  bringToFront: (ids: string[]) => void;
  sendToBack: (ids: string[]) => void;
  bringForward: (ids: string[]) => void;
  sendBackward: (ids: string[]) => void;

  // Connections
  createConnection: (
    source: { boardId: string; elementId: string; anchor?: NodeAnchor },
    target: { boardId: string; elementId: string; anchor?: NodeAnchor },
    linkType?: string,
    routing?: ConnectionRouting
  ) => string;

  // Selection & Editing
  setSelected: (ids: string[]) => void;
  addToSelection: (id: string) => void;
  removeFromSelection: (id: string) => void;
  toggleSelection: (id: string) => void;
  clearSelection: () => void;
  selectAll: () => void;
  selectByType: (type: "stroke" | "text" | "image" | "shape" | "sticky" | "connection") => void;
  invertSelection: () => void;
  setEditingId: (id: string | null) => void;
  /**
   * Removes a text box that was started but never written in, together with
   * the undo entries that only recorded its creation. Runs automatically
   * whenever editing ends (see the subscription at the bottom of this file).
   * Returns true when something was removed.
   */
  discardAbandonedText: (id: string, boardId: string) => boolean;

  // Camera
  setCamera: (camera: Partial<Camera>) => void;
  panCamera: (dx: number, dy: number) => void;
  zoomTo: (zoom: number, centerX?: number, centerY?: number, viewport?: Viewport) => void;
  /**
   * The canvas area's measured size. The store cannot see the DOM, and
   * `window.innerWidth` is the WHOLE window - sidebar, panels and all - so
   * anything derived from it (the notebook zoom floor, a fit) came out wrong
   * by however wide the sidebar was. The canvas reports its real size here.
   */
  canvasViewport: Viewport;
  setCanvasViewport: (vp: Viewport) => void;
  zoomToFit: (viewport?: Viewport) => void;
  resetCamera: () => void;

  /**
   * The pen you last drew with. Reaching for "the pen" after using the eraser
   * must return the pen you were holding, not a hardcoded default.
   */
  lastStrokeTool: ToolType;

  // Tool / Style
  setTool: (tool: ToolType) => void;
  setStyle: (patch: Partial<StyleState>) => void;

  // History
  undo: () => void;
  redo: () => void;
  commitHistory: () => void;
  canUndo: () => boolean;
  canRedo: () => boolean;

  // UI
  toggleSidebar: () => void;
  setSidebarOpen: (open: boolean) => void;

  // Persistence
  getPersistedState: () => PersistedState;
  saveNow: () => void;

  // Workspace backup / sync
  getWorkspaceSnapshot: () => WorkspaceSnapshot;
  replaceWorkspace: (snapshot: WorkspaceSnapshot) => void;
  mergeWorkspace: (remote: WorkspaceSnapshot) => MergeReport;
}

const DEFAULT_CAMERA: Camera = { x: 0, y: 0, zoom: 1 };

/**
 * Deep-clone elements for history snapshots. A shallow `{ ...el }` shares
 * nested structures (stroke.points, connection.source/target) by reference
 * between the snapshot and the live board — any in-place mutation would
 * retroactively corrupt every snapshot.
 */
function clonePagesForHistory(pages: NotebookPage[]): NotebookPage[] {
  if (typeof structuredClone === "function") {
    return pages.map((p) => structuredClone(p));
  }
  return JSON.parse(JSON.stringify(pages)) as NotebookPage[];
}

/**
 * Sanitizes 0-based page indices from callers (modal, tests, future API):
 * drops non-integers and negatives, dedupes while preserving order.
 *
 * Deduping matters: copyPagesFrom keys its id-remap by source element id,
 * so passing the same page twice would give both copies the SAME new ids.
 * Out-of-range values are left for copyPagesFrom to drop via filter(Boolean).
 */
function sanitizePageIndices(indices: number[]): number[] {
  const seen = new Set<number>();
  const out: number[] = [];
  for (const i of indices) {
    if (!Number.isInteger(i) || i < 0 || seen.has(i)) continue;
    seen.add(i);
    out.push(i);
  }
  return out;
}

/**
 * Puts a history snapshot back. For a notebook the snapshot is restored onto
 * the page it was taken from, re-selecting that page, so undo is never applied
 * to whichever page happens to be open now.
 * If the entry records a full pages list (e.g. from page insertion/merge),
 * it restores the notebook's entire page list.
 */
function restoreHistoryElements(board: Board, entry: HistoryEntry): Board {
  if (entry.pages && isNotebook(board)) {
    const restoredPages = clonePagesForHistory(entry.pages);
    const activeId =
      entry.pageId && restoredPages.some((p) => p.id === entry.pageId)
        ? entry.pageId
        : restoredPages[0]?.id ?? board.activePageId;
    const restoredDocIds = [
      ...new Set(
        restoredPages
          .map((p) => p.pdf?.docId)
          .filter((d): d is string => typeof d === "string")
      ),
    ];
    return {
      ...board,
      pages: restoredPages,
      activePageId: activeId,
      pdfDocIds: restoredDocIds,
      updatedAt: Date.now(),
    };
  }
  if (!isNotebook(board) || !entry.pageId) {
    return mapBoardElements(board, () => entry.elements);
  }
  return mapBoardElements(setActivePage(board, entry.pageId), () => entry.elements);
}

/**
 * Runs a page operation on the active board, if it is a notebook.
 *
 * Page turns clear the SELECTION — handles would otherwise hang over elements
 * that are no longer on screen — but deliberately keep the undo history. Undo
 * spans the whole notebook the way it does in GoodNotes and Notability, and
 * each history entry records the page it was taken on, so undoing after
 * turning the page edits the page the edit actually happened on and brings
 * that page back into view (see `restoreHistoryElements`). Clearing history
 * here instead would make undo silently do nothing after any page turn.
 */
function applyToActiveNotebook(
  set: (fn: (s: WhiteboardState) => Partial<WhiteboardState>) => void,
  get: () => WhiteboardState,
  fn: (board: Board) => Board,
  opts: { keepSelection?: boolean } = {}
): void {
  const activeId = get().activeBoardId;
  const board = get().boards.find((b) => b.id === activeId);
  if (!board || !isNotebook(board)) return;

  set((s) => ({
    boards: s.boards.map((b) => (b.id === activeId ? fn(b) : b)),
    ...(opts.keepSelection ? {} : { selectedIds: [], editingId: null }),
  }));
  get().saveNow();
}

/**
 * Undo reverses what you did FROM the document you are in.
 *
 * History is one list. Every entry records which document was live when it
 * was made (`activeAt`), and undo/redo take the newest entry made from the
 * live document. That one rule covers every case:
 *
 *  - Split view: draw on the right, tap left, draw on the left. Undo takes the
 *    left stroke, and then stops - it never reaches across the divider and
 *    edits the pane you are not in.
 *  - Merging pages into a CLOSED notebook from the Duplicate dialog: the merge
 *    was made from the notebook on screen, so one undo from there cancels it,
 *    even though the pages changed are somewhere else.
 *  - Switching notebooks from the sidebar: each keeps its own undo, and none
 *    silently edits a document that is not on screen.
 *
 * Before, switching board wiped the whole list. In split view tapping the other
 * pane IS a board switch, so every glance across the divider lost your undo.
 */
function contextOf(e: HistoryEntry): string {
  return e.activeAt ?? e.boardId;
}

export function lastIndexForContext(list: HistoryEntry[], activeBoardId: string | null): number {
  if (!activeBoardId) return -1;
  for (let i = list.length - 1; i >= 0; i--) if (contextOf(list[i]) === activeBoardId) return i;
  return -1;
}

function cloneElementsForHistory(elements: WhiteboardElement[]): WhiteboardElement[] {
  if (typeof structuredClone === "function") {
    return elements.map((el) => structuredClone(el));
  }
  return JSON.parse(JSON.stringify(elements)) as WhiteboardElement[];
}

/**
 * History worth persisting: entries for boards that still exist. Pruning here
 * (not only at load) keeps a deleted notebook's steps from accumulating on
 * disk forever.
 */
function persistableHistory(s: WhiteboardState): { past: HistoryEntry[]; future: HistoryEntry[] } {
  const ids = new Set(s.boards.map((b) => b.id));
  const keep = (e: HistoryEntry) =>
    ids.has(e.boardId) && (Array.isArray(e.elements) || Array.isArray(e.pages));
  return { past: s.history.past.filter(keep), future: s.history.future.filter(keep) };
}

function makeUniqueName(name: string, existingNames: string[]): string {
  const trimmed = name.trim() || "Untitled";
  if (!existingNames.includes(trimmed)) return trimmed;
  let i = 2;
  while (existingNames.includes(`${trimmed} (${i})`)) {
    i++;
  }
  return `${trimmed} (${i})`;
}

function getInitialDemoState(): { folders: Folder[]; boards: Board[]; activeBoardId: string } {
  const folderId = nanoid(8);
  const boardId = nanoid(8);
  const welcomeTextId = nanoid(8);
  const sticky1Id = nanoid(8);
  const sticky2Id = nanoid(8);
  const connId = nanoid(8);

  const folders: Folder[] = [
    {
      id: folderId,
      name: "Getting Started",
      parentId: null,
      expanded: true,
      createdAt: Date.now(),
      color: "#3b82f6",
    },
  ];

  const boards: Board[] = [
    {
      id: boardId,
      name: "Welcome to Knowledge Whiteboard",
      folderId: folderId,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      accessedAt: Date.now(),
      starred: true,
      tags: ["welcome", "guide"],
      color: "#3b82f6",
      camera: { x: 0, y: 0, zoom: 1 },
      elements: [
        {
          id: welcomeTextId,
          type: "text",
          x: -260,
          y: -180,
          width: 520,
          height: 90,
          rotation: 0,
          opacity: 1,
          text: "# 🧠 Knowledge Canvas & Infinite Whiteboard\nDouble-click anywhere to type, or use [[WikiLinks]] to connect your thoughts.",
          color: "#1e293b",
          fontSize: 22,
          fontFamily: "var(--font-inter), Inter, system-ui, sans-serif",
          fontWeight: 600,
          align: "center",
          createdAt: Date.now(),
          updatedAt: Date.now(),
        },
        {
          id: sticky1Id,
          type: "sticky",
          x: -280,
          y: -20,
          width: 220,
          height: 180,
          rotation: -0.03,
          opacity: 1,
          text: "💡 **Core Ideas**\n- Obsidian-grade [[WikiLinks]]\n- Bi-directional Backlinks (Ctrl+B)\n- Interactive Knowledge Graph (Ctrl+G)\n#ideas #canvas",
          color: "yellow",
          fontSize: 16,
          align: "left",
          createdAt: Date.now(),
          updatedAt: Date.now(),
        },
        {
          id: sticky2Id,
          type: "sticky",
          x: 60,
          y: -20,
          width: 220,
          height: 180,
          rotation: 0.02,
          opacity: 1,
          text: "🚀 **Smart Connectors**\n- Drag arrows between notes\n- Typed relationships (*Causes*, *Depends*, *Relates*)\n- Auto-docking anchor ports",
          color: "blue",
          fontSize: 16,
          align: "left",
          createdAt: Date.now(),
          updatedAt: Date.now(),
        },
        {
          id: connId,
          type: "connection",
          x: 0,
          y: 0,
          rotation: 0,
          opacity: 1,
          source: { boardId, elementId: sticky1Id, anchor: "right" },
          target: { boardId, elementId: sticky2Id, anchor: "left" },
          linkType: "leads_to",
          label: "Powers",
          routing: "curved",
          dashStyle: "solid",
          startArrowhead: "none",
          endArrowhead: "arrow",
          strokeWidth: 2.5,
          createdAt: Date.now(),
          updatedAt: Date.now(),
        },
      ],
    },
  ];

  return { folders, boards, activeBoardId: boardId };
}

/**
 * Applies a loaded (or absent) workspace to the store. Shared by the
 * synchronous legacy boot and the async IndexedDB boot so both behave
 * identically — the async path only changes WHEN this runs, never WHAT.
 */
function initFromSnapshot(saved: PersistedState | null): void {
  const set = useWhiteboard.setState;
  // Any previously saved state is honored — even one with zero boards
  // (the user may have deliberately deleted everything). The demo board is
  // only seeded when there is no saved state at all, otherwise the user's
  // folders / link types would be wiped and demo content re-injected.
  if (saved && Array.isArray(saved.boards)) {
    const activeBoard = saved.boards.find((b) => b.id === saved.activeBoardId) || saved.boards[0];
    set({
      folders: (saved.folders || []).map((f) => ({
        ...f,
        parentId: f.parentId ?? null,
        expanded: f.expanded !== false,
      })),
      boards: saved.boards,
      activeBoardId: activeBoard ? activeBoard.id : null,
      activeFolderId: saved.activeFolderId || null,
      customLinkTypes: saved.customLinkTypes || [],
      pinnedPens: saved.pinnedPens || [],
      pinnedBarPos: saved.pinnedBarPos ?? null,
      toolbarPosition: saved.toolbarPosition ?? "bottom",
      splitBoardId: saved.splitBoardId ?? null,
      splitRatio: typeof saved.splitRatio === "number" ? saved.splitRatio : 0.5,
      splitSide: saved.splitSide === "right" ? "right" : "left",
      splitOrientation: saved.splitOrientation === "stacked" ? "stacked" : "side",
      pageTemplates: saved.pageTemplates ?? [],
      pinnedBarVertical: saved.pinnedBarVertical !== false,
      recentColors: saved.recentColors || [],
      // Merge over the defaults rather than replacing them, so a preference
      // added in a later version still gets its default on an old save.
      // buildToolInk fills any pen missing from the saved map — from the
      // legacy per-pen fields where they exist, then defaults. Without it a
      // save written before the pen rework leaves the four newest pens with
      // no ink at all.
      lastStrokeTool: (saved.lastStrokeTool && isStrokeTool(saved.lastStrokeTool)
        ? saved.lastStrokeTool
        : "gel") as ToolType,
      style: {
        ...DEFAULT_STYLE,
        ...(saved.style ?? {}),
        toolInk: buildToolInk(saved.style?.toolInk, saved.style),
      },
      touchSettings: { ...DEFAULT_TOUCH_SETTINGS, ...(saved.touchSettings ?? {}) },
      // Never reopen straight into the eraser: a stray tap on a restored
      // board would silently destroy work before the user notices the tool.
      tool: saved.tool && saved.tool !== "eraser" ? saved.tool : "select",
      snapToGrid: saved.snapToGrid ?? false,
      minimapOpen: saved.minimapOpen ?? false,
      legendOpen: saved.legendOpen ?? false,
      zoomDockOpen: saved.zoomDockOpen ?? true,
      shapeRecognition: saved.shapeRecognition ?? false,
      defaultPaper: saved.defaultPaper ?? { pattern: "plain" },
      // Undo survives restarts: this workspace's steps come back oldest
      // first (last 100). Entries for deleted boards are dropped, and
      // corrupt ones never load — a bad entry costs an undo step, not a board.
      history: restorableHistory(
        saved.boards.map((b) => b.id),
        loadHistory()
      ),
      pinnedBarOpen: saved.pinnedBarOpen ?? true,
      propsPanelCollapsed: saved.propsPanelCollapsed ?? true,
      toolPropsBarCollapsed: saved.toolPropsBarCollapsed ?? false,
      toolbarItems: mergeToolbarItems(saved.toolbarTools, saved.toolbarHidden),
      dictationLang: resolveDictationLang(saved.dictationLang),
      lassoStrict: saved.lassoStrict ?? false,
      camera: activeBoard?.camera || { ...DEFAULT_CAMERA },
      isReady: true,
    });
  } else {
    const initial = getInitialDemoState();
    set({
      folders: initial.folders,
      boards: initial.boards,
      activeBoardId: initial.activeBoardId,
      activeFolderId: initial.folders[0]?.id || null,
      isReady: true,
    });
    useWhiteboard.getState().saveNow();
  }
}

export const useWhiteboard = create<WhiteboardState>((set, get) => ({
  folders: [],
  boards: [],
  activeBoardId: null,
  activeFolderId: null,

  camera: { ...DEFAULT_CAMERA },
  canvasViewport: { width: 1200, height: 800 },
  tool: "select",
  style: { ...DEFAULT_STYLE },
  lastStrokeTool: "gel" as ToolType,
  selectedIds: [],
  editingId: null,
  customLinkTypes: [],

  history: { past: [], future: [] },

  sidebarOpen: true,
  sidebarSortBy: "updated",
  sidebarSortOrder: "desc",
  pagePanelOpen: false,
  isExporting: false,
  isReady: false,
  minimapOpen: false,
  legendOpen: false,
  zoomDockOpen: true,
  shapeRecognition: false,
  snapToGrid: false,
  touchSettings: { ...DEFAULT_TOUCH_SETTINGS },
  dictationLang: resolveDictationLang(typeof navigator !== "undefined" ? navigator.language : undefined),
  lassoStrict: false,
  defaultPaper: { pattern: "plain" },

  recentColors: [],

  addRecentColor: (color) => {
    const c = color.toLowerCase();
    set((s) => ({
      // Most recent first, no duplicates, capped — an unbounded list would
      // grow forever in localStorage and overflow the palette row.
      recentColors: [c, ...s.recentColors.filter((x) => x !== c)].slice(0, 8),
    }));
    get().saveNow();
  },

  // ---- Favorite pens bar ----------------------------------------------------
  pinnedPens: [],
  pinnedBarOpen: true,
  // The selection inspector opens folded: on a tablet the full panel buries
  // the shape being edited. One tap unfolds it; the choice persists.
  propsPanelCollapsed: true,
  toolPropsBarCollapsed: false,
  toolbarItems: [...DEFAULT_TOOLBAR_ITEMS],
  lockedMode: false,
  imageStudioId: null,
  pinnedBarPos: null,
  toolbarPosition: "bottom",

  addPinnedPen: (pen) => {
    const id = nanoid(8);
    set((s) => ({ pinnedPens: [...s.pinnedPens, { ...pen, id }] }));
    get().saveNow();
    return id;
  },

  /**
   * Pin whatever the user is drawing with right now. Only stroke tools can be
   * pinned — pinning "select" or "rectangle" would produce a pen that draws
   * nothing.
   */
  pinCurrentPen: () => {
    const s = get();
    const tool = isStrokeTool(s.tool) ? s.tool : s.lastStrokeTool;
    return get().addPinnedPen({
      tool: tool as PinnedPen["tool"],
      color: getToolColor(s.style, tool),
      size: getToolSize(s.style, tool),
    });
  },

  updatePinnedPen: (id, patch) => {
    set((s) => ({
      pinnedPens: s.pinnedPens.map((p) => (p.id === id ? { ...p, ...patch } : p)),
    }));
    get().saveNow();
  },

  removePinnedPen: (id) => {
    set((s) => ({ pinnedPens: s.pinnedPens.filter((p) => p.id !== id) }));
    get().saveNow();
  },

  reorderPinnedPens: (fromIndex, toIndex) => {
    set((s) => {
      const next = [...s.pinnedPens];
      if (
        fromIndex < 0 || fromIndex >= next.length ||
        toIndex < 0 || toIndex >= next.length ||
        fromIndex === toIndex
      ) {
        return {} as Partial<WhiteboardState>;
      }
      const [moved] = next.splice(fromIndex, 1);
      next.splice(toIndex, 0, moved);
      return { pinnedPens: next };
    });
    get().saveNow();
  },

  /** Select a pinned pen: its tool becomes active with its own color & size. */
  applyPinnedPen: (id) => {
    const pin = get().pinnedPens.find((p) => p.id === id);
    if (!pin) return;
    set((s) => ({
      tool: pin.tool as ToolType,
      style: {
        ...s.style,
        // One combined patch: colour and size share the toolInk map, so two
        // spreads would drop the colour.
        ...setToolInk(s.style, pin.tool as ToolType, { color: pin.color, size: pin.size }),
      },
      // Switching to a drawing tool should drop any lingering selection, the
      // same way setTool does.
      selectedIds: [],
    }));
  },

  pinnedBarVertical: true,

  /**
   * Rotate the bar between a vertical rail and a horizontal strip. The position
   * is kept and simply re-clamped on the next render, so rotating can never
   * throw the bar off screen.
   */
  togglePinnedBarOrientation: () => {
    set((s) => ({ pinnedBarVertical: !s.pinnedBarVertical }));
    get().saveNow();
  },

  togglePinnedBar: () => {
    set((s) => ({ pinnedBarOpen: !s.pinnedBarOpen }));
    get().saveNow();
  },

  setPinnedBarPos: (pos) => {
    set({ pinnedBarPos: pos });
    get().saveNow();
  },

  setToolbarPosition: (pos) => {
    set({ toolbarPosition: pos });
    get().saveNow();
  },

  // ----- Split view -----
  splitBoardId: null,
  splitRatio: 0.5,
  splitSide: "left",
  splitOrientation: "side",

  setSplitOrientation: (o) => {
    if (o === get().splitOrientation) return;
    // The documents keep their slots (left becomes top), so nothing jumps to
    // the other end of the screen; each keeps the share of space it had.
    set({ splitOrientation: o });
    get().saveNow();
  },

  /**
   * Editing on either side, without duplicating the store.
   *
   * There is one `activeBoardId`, camera, selection and history, so only one
   * document can be edited at a time. Rather than duplicating all of that,
   * focus simply follows you: tapping the other pane makes ITS document the
   * active one and hands the reference role to the document you left.
   *
   * Neither pane moves — the panes keep their positions and only their roles
   * swap — and because `setActiveBoard` already stores the outgoing board's
   * camera and restores the incoming one, each side keeps its own view.
   */
  focusSplitSide: (side) => {
    const { splitSide, splitBoardId, activeBoardId, editingId } = get();
    if (side === splitSide || !splitBoardId || !activeBoardId) return;
    // Never switch out from under an open text editor: the edit would be
    // discarded and the keystrokes would land nowhere.
    if (editingId) return;
    const incoming = splitBoardId;
    set({ splitBoardId: activeBoardId, splitSide: side });
    get().setActiveBoard(incoming);
  },

  setSplitPair: (leftBoardId, rightBoardId, orientation) => {
    if (leftBoardId === rightBoardId) return;
    // The first (left / top) document becomes the editable one, which is what
    // someone choosing it first expects.
    set({
      splitBoardId: rightBoardId,
      splitSide: "left",
      ...(orientation ? { splitOrientation: orientation } : {}),
    });
    get().setActiveBoard(leftBoardId);
    get().saveNow();
  },

  setSplitBoard: (boardId) => {
    // Showing the document you are editing beside itself is confusing rather
    // than useful: the reference pane would not follow your edits, so the two
    // halves would silently disagree.
    if (boardId && boardId === get().activeBoardId) return;
    set({ splitBoardId: boardId });
    get().saveNow();
  },

  setBoardCamera: (boardId, camera) => {
    // Only for a board being shown elsewhere. The active board's camera is the
    // store's own `camera`, and writing both would fight it every frame.
    if (boardId === get().activeBoardId) return;
    set((s) => ({
      boards: s.boards.map((b) => (b.id === boardId ? { ...b, camera } : b)),
    }));
  },

  setSplitRatio: (ratio) => {
    // Neither pane may be dragged away to nothing, which would look like the
    // split had broken with no way to recover it.
    set({ splitRatio: Math.max(0.2, Math.min(0.8, ratio)) });
    get().saveNow();
  },

  /** Puts the reference document in the editable pane and vice versa. */
  /** Exchanges which document is on which SIDE, keeping widths sensible. */
  swapSplit: () => {
    const { splitBoardId, activeBoardId, splitSide, splitRatio } = get();
    if (!splitBoardId || !activeBoardId) return;

    // Swapping SIDES only moves which slot each document occupies. It must
    // NOT change which one is editable — doing that made this button a
    // duplicate of simply tapping the other pane, and left the documents
    // exactly where they were.
    //
    // The left slot is always `splitRatio` wide, so flipping the ratio too is
    // what keeps each document the width it already had as it changes sides.
    set({
      splitSide: splitSide === "left" ? "right" : "left",
      splitRatio: 1 - splitRatio,
    });
    get().saveNow();
  },

  setTouchSettings: (patch) => {
    set((s) => ({ touchSettings: { ...s.touchSettings, ...patch } }));
    get().saveNow();
  },
  setDictationLang: (lang) => {
    set({ dictationLang: resolveDictationLang(lang) });
    get().saveNow();
  },
  setLassoStrict: (strict) => {
    set({ lassoStrict: strict });
    get().saveNow();
  },
  toggleMinimap: () => {
    set((s) => ({ minimapOpen: !s.minimapOpen }));
    get().saveNow();
  },
  setMinimapOpen: (open) => set({ minimapOpen: open }),
  toggleLegend: () => {
    set((s) => ({ legendOpen: !s.legendOpen }));
    get().saveNow();
  },
  setLegendOpen: (open) => set({ legendOpen: open }),
  toggleZoomDock: () => {
    set((s) => ({ zoomDockOpen: !s.zoomDockOpen }));
    get().saveNow();
  },
  setZoomDockOpen: (open) => set({ zoomDockOpen: open }),
  toggleShapeRecognition: () => {
    set((s) => ({ shapeRecognition: !s.shapeRecognition }));
    get().saveNow();
  },
  setPropsPanelCollapsed: (collapsed) => {
    set({ propsPanelCollapsed: collapsed });
    get().saveNow();
  },
  toggleToolPropsBar: () => {
    set((s) => ({ toolPropsBarCollapsed: !s.toolPropsBarCollapsed }));
    get().saveNow();
  },
  setToolbarItems: (items) => {
    // Never empty: a tool bar with no buttons could not be fixed from itself.
    if (items.length === 0) return;
    set({ toolbarItems: items });
    get().saveNow();
  },
  toggleSnapToGrid: () => {
    set((s) => ({ snapToGrid: !s.snapToGrid }));
    get().saveNow();
  },
  setSnapToGrid: (snap) => set({ snapToGrid: snap }),
  togglePagePanel: () => set((s) => ({ pagePanelOpen: !s.pagePanelOpen })),
  setPagePanelOpen: (open) => set({ pagePanelOpen: open }),


  init: () => {
    // No IndexedDB (unit tests, SSR, exotic WebViews): synchronous legacy
    // load — the old behavior, byte for byte.
    if (!workspaceDbAvailable()) {
      initFromSnapshot(loadState());
      return;
    }
    // Real browsers: the workspace lives in IndexedDB now, so boot waits on
    // it. The loading screen stays up until isReady flips, and this can never
    // reject — every failure path falls back to localStorage, then to demo.
    void (async () => {
      try {
        void requestPersistentStorage();
        initFromSnapshot((await loadWorkspace()).state);
      } catch {
        try {
          initFromSnapshot(loadState());
        } catch {
          initFromSnapshot(null);
        }
      }
    })();
  },

  addCustomLinkType: (name, color) => {
    const id = `custom:${nanoid(6)}`;
    set((s) => ({
      customLinkTypes: [...s.customLinkTypes, { id, name, color }],
    }));
    get().saveNow();
    return id;
  },

  removeCustomLinkType: (id) => {
    set((s) => ({
      customLinkTypes: s.customLinkTypes.filter((t) => t.id !== id),
    }));
    get().saveNow();
  },

  // ----- Folders -----
  createFolder: (name, parentId, color = "#f59e0b") => {
    const id = nanoid(8);
    const existing = get().folders.map((f) => f.name);
    const uniqueName = makeUniqueName(name, existing);
    const newFolder: Folder = {
      id,
      name: uniqueName,
      parentId: parentId ?? null,
      expanded: true,
      createdAt: Date.now(),
      color,
    };
    set((s) => ({
      folders: [
        ...s.folders.map((f) => (f.id === parentId ? { ...f, expanded: true } : f)),
        newFolder,
      ],
      activeFolderId: id,
    }));
    get().saveNow();
    return id;
  },

  renameFolder: (folderId, name) => {
    set((s) => ({
      folders: s.folders.map((f) => (f.id === folderId ? { ...f, name: name.trim() || f.name } : f)),
    }));
    get().saveNow();
  },

  deleteFolder: (folderId) => {
    set((s) => {
      // Collect the FULL descendant set so grandchildren are not orphaned
      // (an orphaned folder is invisible in the tree but persisted forever).
      const doomed = new Set<string>([folderId]);
      let changed = true;
      while (changed) {
        changed = false;
        for (const f of s.folders) {
          if (f.parentId && doomed.has(f.parentId) && !doomed.has(f.id)) {
            doomed.add(f.id);
            changed = true;
          }
        }
      }
      return {
        folders: s.folders.filter((f) => !doomed.has(f.id)),
        boards: s.boards.map((b) =>
          b.folderId && doomed.has(b.folderId) ? { ...b, folderId: null } : b
        ),
        activeFolderId: s.activeFolderId && doomed.has(s.activeFolderId) ? null : s.activeFolderId,
      };
    });
    get().saveNow();
  },

  toggleFolderExpanded: (folderId) => {
    set((s) => ({
      folders: s.folders.map((f) =>
        f.id === folderId ? { ...f, expanded: !f.expanded } : f
      ),
    }));
    get().saveNow();
  },

  /**
   * Jump to a specific element: switch board if needed, centre the camera on
   * it, and select it.
   *
   * The camera is the WORLD point shown at the viewport centre
   * (screen = (world - camera) * zoom + viewport/2), so centring is simply
   * setting the camera to the element's own centre — no viewport size needed,
   * which matters because the store cannot see the viewport.
   */
  focusElement: (boardId, elementId, opts) => {
    const board = get().boards.find((b) => b.id === boardId);
    if (!board) return;
    let siblings = getBoardElements(board);
    let el = siblings.find((e) => e.id === elementId);
    // A notebook shows one page's elements at a time, so an element on
    // another page was "not found" and the jump silently did nothing.
    let pageId: string | null = null;
    if (!el && isNotebook(board)) {
      for (const page of getPages(board)) {
        const found = (page.elements ?? []).find((e) => e.id === elementId);
        if (found) {
          el = found;
          siblings = page.elements;
          pageId = page.id;
          break;
        }
      }
    }
    if (!el) return;

    if (get().activeBoardId !== boardId) get().setActiveBoard(boardId);

    // Page-local coordinates ARE world coordinates once that page is the
    // active one (it is anchored at world y = 0), so the camera maths is the
    // same as on a canvas.
    const bounds = focusBounds(el, siblings);
    const zoom = get().camera.zoom;
    const vp = get().canvasViewport;
    // Never arrive zoomed so far out that the element is a speck, but do not
    // zoom IN on someone who deliberately zoomed out to survey - and never so
    // far in that the element runs off the screen.
    const fit = Math.min(
      (vp.width * 0.85) / Math.max(bounds.width, 1),
      (vp.height * 0.7) / Math.max(bounds.height, 1)
    );
    const floor = isNotebook(board)
      ? Math.min(Math.max(MIN_ZOOM, minNotebookZoom(vp, pageSizeOf(board))), MAX_ZOOM)
      : MIN_ZOOM;
    set((s) => ({
      boards: pageId
        ? s.boards.map((b) => (b.id === boardId ? nbSetActivePage(b, pageId as string) : b))
        : s.boards,
      camera: {
        x: bounds.x + bounds.width / 2,
        y: bounds.y + bounds.height / 2,
        zoom: clamp(Math.min(Math.max(zoom, 0.6), fit), floor, MAX_ZOOM),
      },
      selectedIds: opts?.select === false ? [] : [elementId],
      editingId: null,
    }));
    get().saveNow();
  },

  /**
   * Make a folder visible and selected in the sidebar: expand it AND every
   * ancestor above it, then mark it active. Used when "entering" a folder from
   * somewhere outside the tree (e.g. clicking a folder node in the Graph).
   */
  revealFolder: (folderId) => {
    const folders = get().folders;
    const byId = new Map(folders.map((f) => [f.id, f]));
    if (!byId.has(folderId)) return;

    // Walk up to the root, collecting the chain to expand. The visited guard
    // keeps a pre-existing parentId cycle from spinning forever.
    const toExpand = new Set<string>([folderId]);
    const visited = new Set<string>([folderId]);
    let cursor = byId.get(folderId)?.parentId ?? null;
    while (cursor && !visited.has(cursor)) {
      visited.add(cursor);
      toExpand.add(cursor);
      cursor = byId.get(cursor)?.parentId ?? null;
    }

    set((s) => ({
      folders: s.folders.map((f) =>
        toExpand.has(f.id) ? { ...f, expanded: true } : f
      ),
      activeFolderId: folderId,
      sidebarOpen: true,
    }));
    get().saveNow();
  },

  moveFolder: (folderId, newParentId) => {
    if (folderId === newParentId) return;
    if (newParentId !== null) {
      const folders = get().folders;
      const byId = new Map(folders.map((f) => [f.id, f]));
      if (!byId.has(newParentId)) return; // parent must exist
      // Reject moves that would create a cycle (folder into its own
      // descendant) — a parentId cycle hangs every recursive tree walk.
      let cursor: string | null = newParentId;
      const visited = new Set<string>();
      while (cursor) {
        if (cursor === folderId) return;
        if (visited.has(cursor)) break; // guard against pre-existing corruption
        visited.add(cursor);
        cursor = byId.get(cursor)?.parentId ?? null;
      }
    }
    set((s) => ({
      folders: s.folders.map((f) => (f.id === folderId ? { ...f, parentId: newParentId } : f)),
    }));
    get().saveNow();
  },

  setFolderColor: (folderId, color) => {
    set((s) => ({
      folders: s.folders.map((f) => (f.id === folderId ? { ...f, color } : f)),
    }));
    get().saveNow();
  },

  // ----- Notebook pages -----
  //
  // Every page action rebuilds the active board through the pure helpers in
  // notebook.ts, then clears selection and history. Selection survives a page
  // turn otherwise, leaving handles floating over elements that are no longer
  // on screen; history is per-page and would otherwise undo across the turn.
  addPage: (afterPageId) => applyToActiveNotebook(set, get, (b) => nbAddPage(b, afterPageId)),
  addPageBefore: (pageId) => applyToActiveNotebook(set, get, (b) => nbAddPageBefore(b, pageId)),
  togglePageBookmark: (pageId) =>
    applyToActiveNotebook(set, get, (b) => nbTogglePageBookmark(b, pageId), {
      keepSelection: true,
    }),

  // ----- Page templates -----
  pageTemplates: [],

  savePageAsTemplate: (pageId, name) => {
    const board = get().boards.find((b) => b.id === get().activeBoardId);
    if (!board || !isNotebook(board)) return;
    const page = getPages(board).find((p) => p.id === pageId);
    if (!page) return;
    const dim = pageSizeOf(board);
    set((s) => ({
      pageTemplates: [...s.pageTemplates, templateFromPage(page, name, dim.width, dim.height)],
    }));
    get().saveNow();
  },

  deletePageTemplate: (templateId) => {
    set((s) => ({ pageTemplates: s.pageTemplates.filter((t) => t.id !== templateId) }));
    get().saveNow();
  },

  addPageFromTemplate: (templateId, afterPageId) => {
    const template = get().pageTemplates.find((t) => t.id === templateId);
    if (!template) return;
    applyToActiveNotebook(set, get, (b) => insertTemplatePage(b, template, afterPageId));
  },

  /**
   * Turns an image into a template: one image element covering the sheet.
   * The image is scaled to FIT rather than fill, so a template made from a
   * differently proportioned scan is never cropped.
   */
  createImageTemplate: (name, src, width, height) => {
    const board = get().boards.find((b) => b.id === get().activeBoardId);
    const dim = pageSizeOf(board);
    const scale = Math.min(dim.width / width, dim.height / height);
    const w = width * scale;
    const h = height * scale;

    const template: PageTemplate = {
      id: `tpl_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`,
      name: name.trim() || "Image template",
      createdAt: Date.now(),
      width: dim.width,
      height: dim.height,
      elements: [
        {
          id: nanoid(8),
          type: "image",
          x: (dim.width - w) / 2,
          y: (dim.height - h) / 2,
          width: w,
          height: h,
          angle: 0,
          opacity: 1,
          src,
          // A template is a backdrop you write on top of, so it starts locked.
          locked: true,
          createdAt: Date.now(),
          updatedAt: Date.now(),
        } as unknown as WhiteboardElement,
      ],
    };
    set((s) => ({ pageTemplates: [...s.pageTemplates, template] }));
    get().saveNow();
  },
  deletePage: (pageId) => applyToActiveNotebook(set, get, (b) => nbDeletePage(b, pageId)),
  duplicatePage: (pageId) => applyToActiveNotebook(set, get, (b) => nbDuplicatePage(b, pageId)),
  movePage: (pageId, toIndex) =>
    applyToActiveNotebook(set, get, (b) => nbMovePage(b, pageId, toIndex), { keepSelection: true }),
  setActivePage: (pageId) => applyToActiveNotebook(set, get, (b) => nbSetActivePage(b, pageId)),
  stepPage: (delta) => applyToActiveNotebook(set, get, (b) => nbStepPage(b, delta)),

  // The view is anchored to the ACTIVE page (it always sits at world y = 0), so
  // any page operation that changes which page is active also moves what you
  // see unless the camera is compensated. Before this, adding a page made the
  // view jump. Inserting at `index` makes the new page the anchor; sliding the
  // camera by (index - oldActive) strides leaves every page above the new one
  // exactly where it was on screen, and the new sheet appears in the gap.
  insertPageAt: (index) => {
    const activeId = get().activeBoardId;
    const board = get().boards.find((b) => b.id === activeId);
    if (!board || !isNotebook(board)) return;

    const before = getActivePageIndexOf(board);
    const next = nbInsertPageAt(board, index);
    const at = getActivePageIndexOf(next);
    const stride = pageSizeOf(board).height + PAGE_GAP_STORE;
    const shift = (at - before) * stride;

    set((s) => ({
      boards: s.boards.map((b) => (b.id === activeId ? next : b)),
      camera: { ...s.camera, y: s.camera.y - shift },
      selectedIds: [],
      editingId: null,
    }));
    get().saveNow();
  },

  goToPage: (pageId, viewportHeight) => {
    const activeId = get().activeBoardId;
    const board = get().boards.find((b) => b.id === activeId);
    if (!board || !isNotebook(board)) return;
    const next = nbSetActivePage(board, pageId);
    const z = get().camera.zoom || 1;
    // Page top 24 px below the top of the screen.
    const y = viewportHeight / 2 / z - 24 / z;
    set((s) => ({
      boards: s.boards.map((b) => (b.id === activeId ? next : b)),
      camera: { ...s.camera, y },
      selectedIds: [],
      editingId: null,
    }));
    get().saveNow();
  },

  /**
   * Scrolling across a page boundary.
   *
   * The active page is always anchored at world Y = 0 — that is what lets
   * hit-testing, the selection overlay, the inline editor and export keep
   * working in plain world coordinates instead of every one of them having to
   * know which page it is on. So crossing into the next page swaps which page
   * is active AND slides the camera by one page stride in the opposite
   * direction. The two cancel out, so nothing moves on screen: the scroll
   * looks continuous while the coordinate system stays still.
   */
  reanchorPage: (delta, stride) => {
    const activeId = get().activeBoardId;
    const board = get().boards.find((b) => b.id === activeId);
    if (!board || !isNotebook(board)) return;

    const before = getActivePageIndexOf(board);
    const moved = nbStepPage(board, delta);
    const after = getActivePageIndexOf(moved);
    if (after === before) return; // already at the first or last page

    const shift = (after - before) * stride;
    set((s) => ({
      boards: s.boards.map((b) => (b.id === activeId ? moved : b)),
      camera: { ...s.camera, y: s.camera.y - shift },
      selectedIds: [],
      editingId: null,
    }));
    get().saveNow();
  },
  reanchorBoardPage: (boardId, delta, stride) => {
    if (boardId === get().activeBoardId) {
      get().reanchorPage(delta, stride);
      return;
    }
    const board = get().boards.find((b) => b.id === boardId);
    if (!board || !isNotebook(board)) return;
    const before = getActivePageIndexOf(board);
    const moved = nbStepPage(board, delta);
    const after = getActivePageIndexOf(moved);
    if (after === before) return;
    // Page AND camera in one update. Two updates would draw one frame with the
    // new anchor and the old camera - a visible jump of a whole page.
    const cam = board.camera ?? { ...DEFAULT_CAMERA };
    const shift = (after - before) * stride;
    set((s) => ({
      boards: s.boards.map((b) =>
        b.id === boardId ? { ...moved, camera: { ...cam, y: cam.y - shift } } : b
      ),
    }));
  },

  goToBoardPage: (boardId, pageId, viewportHeight) => {
    if (boardId === get().activeBoardId) {
      get().goToPage(pageId, viewportHeight);
      return;
    }
    const board = get().boards.find((b) => b.id === boardId);
    if (!board || !isNotebook(board)) return;
    const next = nbSetActivePage(board, pageId);
    const cam = board.camera ?? { ...DEFAULT_CAMERA };
    const z = cam.zoom || 1;
    // Same framing as goToPage: the page top 24 px below the top of the pane.
    const y = viewportHeight / 2 / z - 24 / z;
    set((s) => ({
      boards: s.boards.map((b) => (b.id === boardId ? { ...next, camera: { ...cam, y } } : b)),
    }));
    get().saveNow();
  },

  setPageBackground: (pageId, patch) =>
    applyToActiveNotebook(set, get, (b) => nbSetPageBackground(b, pageId, patch), {
      keepSelection: true,
    }),
  setPageSize: (pageSize) =>
    applyToActiveNotebook(set, get, (b) => ({ ...b, pageSize, updatedAt: Date.now() }), {
      keepSelection: true,
    }),

  // ----- Boards -----
  createNotebook: (name, folderId, pageSize = DEFAULT_PAGE_SIZE, color = "#3b82f6") => {
    const id = get().createBoard(name, folderId, color);
    set((s) => ({
      boards: s.boards.map((b) => (b.id === id ? makeNotebook(b, pageSize) : b)),
    }));
    get().saveNow();
    return id;
  },

  /**
   * Turns an existing canvas into a notebook. Whatever was already drawn
   * becomes page 1 rather than being stranded on a field the notebook view
   * never reads — see `makeNotebook`. There is no reverse action: flattening
   * a multi-page notebook back onto one canvas would have to either overlap
   * every page at the same coordinates or throw pages away.
   */
  convertToNotebook: (boardId, pageSize = DEFAULT_PAGE_SIZE) => {
    const board = get().boards.find((b) => b.id === boardId);
    if (!board || isNotebook(board)) return;
    set((s) => ({
      boards: s.boards.map((b) => (b.id === boardId ? makeNotebook(b, pageSize) : b)),
      selectedIds: [],
      editingId: null,
      // Old history entries carry no pageId and would restore onto whichever
      // page is open, so they cannot survive the conversion.
      history: { past: [], future: [] },
    }));
    get().saveNow();
  },

  /**
   * Opens a PDF as a notebook: one page per PDF page, each showing the
   * document underneath and accepting ink on top.
   *
   * The bytes go to IndexedDB once and each page keeps only a reference. The
   * alternative — rasterising every page into the workspace — is tens of
   * megabytes against a ~5 MB localStorage budget, and it fails on SAVE, so
   * you would lose an hour of annotation rather than be told up front.
   */
  importDocumentAsNotebook: async (file, folderId = null, onProgress) => {
    const { officeKindOf, convertOfficeToPdf, LEGACY_OFFICE_MESSAGE } = await import(
      "../lib/whiteboard/officeImport"
    );
    const kind = officeKindOf(file);
    if (kind === "legacy") throw new Error(LEGACY_OFFICE_MESSAGE);
    const pdf = kind ? await convertOfficeToPdf(file, onProgress) : file;
    return get().importPdfAsNotebook(pdf, folderId);
  },

  importPdfAsNotebook: async (file, folderId = null) => {
    const { readPdfFile, openPdf, pdfPageSize, notebookSizeForPdf } = await import(
      "../lib/whiteboard/pdf"
    );
    const { putPdf } = await import("../lib/whiteboard/pdfstore");

    const bytes = await readPdfFile(file);
    const doc = await openPdf(bytes);
    const pageCount = doc.numPages;
    if (pageCount < 1) throw new Error(`"${file.name}" has no pages.`);

    // Page 1 sets the sheet size for the notebook. Mixed-size PDFs exist but
    // are rare; the alternative is a per-page sheet size, which would make
    // continuous scrolling jump about.
    const sheet = notebookSizeForPdf(await pdfPageSize(doc, 1));

    const docId = `pdf_${Date.now().toString(36)}_${nanoid(6)}`;
    await putPdf({ id: docId, name: file.name, bytes, pageCount, addedAt: Date.now() });

    // A converted Word / PowerPoint file is pictures only; the text captured
    // while converting it is stored beside it under the same id. Failing to
    // keep it costs text selection and search, never the import.
    const { takeOfficeText } = await import("../lib/whiteboard/pdfTextStore");
    const officeText = takeOfficeText(file);
    if (officeText) {
      try {
        const { saveOfficeText } = await import("../lib/whiteboard/pdfTextIndex");
        await saveOfficeText(docId, officeText);
      } catch {
        /* the notebook is still whole */
      }
    }

    const now = Date.now();
    const pages = Array.from({ length: pageCount }, (_, i) => ({
      id: `pg_${docId}_${i + 1}`,
      elements: [],
      pdf: { docId, pageNumber: i + 1 },
      createdAt: now,
      updatedAt: now,
    }));

    const id = nanoid(8);
    const name = makeUniqueName(
      file.name.replace(/\.pdf$/i, ""),
      get().boards.map((b) => b.name)
    );
    const board: Board = {
      id,
      name,
      folderId,
      elements: [],
      camera: { ...DEFAULT_CAMERA },
      createdAt: now,
      updatedAt: now,
      accessedAt: now,
      color: "#ef4444",
      kind: "notebook",
      pages,
      activePageId: pages[0].id,
      customPageSize: sheet,
      pdfDocIds: [docId],
      // A PDF page IS the paper; drawing dots over a lecture slide is noise.
      background: { pattern: "plain" },
    };

    set((s) => ({
      boards: [...s.boards, board],
      activeBoardId: id,
      camera: { ...DEFAULT_CAMERA },
      selectedIds: [],
      editingId: null,
      history: { past: [], future: [] },
    }));
    get().saveNow();
    return id;
  },

  /**
   * Inserts pages from another board into the active notebook.
   *
   * A whiteboard counts as a single page, so "put this sketch in front of my
   * lecture notes" works without converting it first.
   *
   * Nothing is moved: the source keeps its pages. Copying rather than moving
   * is the safe default - an accidental insert costs a delete, an accidental
   * move costs work you cannot get back.
   */
  insertPagesFromBoard: (sourceBoardId, range, atIndex, targetBoardId) => {
    const targetId = targetBoardId ?? get().activeBoardId;
    const target = get().boards.find((b) => b.id === targetId);
    const source = get().boards.find((b) => b.id === sourceBoardId);
    if (!target || !isNotebook(target) || !source) return 0;

    let indices: number[];
    if (Array.isArray(range)) {
      indices = sanitizePageIndices(range);
    } else if (range && Array.isArray((range as { indices?: number[] }).indices)) {
      indices = sanitizePageIndices((range as { indices: number[] }).indices);
    } else {
      const sourcePageCount = isNotebook(source) ? getPages(source).length : 1;
      const r = resolvePageRange(
        sourcePageCount,
        (range as { from?: number }).from ?? 1,
        (range as { to?: number }).to ?? sourcePageCount
      );
      indices = r.indices;
    }
    if (indices.length === 0) return 0;

    let incoming: NotebookPage[];
    if (isNotebook(source)) {
      incoming = copyPagesFrom(source, indices, target.id, () => nanoid(8));
    } else {
      const asPage = {
        id: "tmp",
        elements: source.elements ?? [],
        background: source.background,
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };
      incoming = copyPagesFrom(
        { ...source, kind: "notebook", pages: [asPage] } as Board,
        [0],
        target.id,
        () => nanoid(8)
      );
    }
    if (incoming.length === 0) return 0;

    // Snapshot target's current pages for single-step undo!
    const historySnapshot: HistoryEntry = {
      activeAt: get().activeBoardId ?? target.id,
      boardId: target.id,
      pageId: target.activePageId,
      pages: clonePagesForHistory(target.pages ?? []),
      elements: [],
      at: Date.now(),
    };

    // Every PDF the inserted pages still point at has to be listed on the new
    // board too, or the notebook's own record of its documents goes stale.
    const addedDocIds = incoming
      .map((p) => p.pdf?.docId)
      .filter((d): d is string => typeof d === "string");

    set((s) => ({
      boards: s.boards.map((b) =>
        b.id === targetId
          ? {
              ...nbInsertPages(b, incoming, atIndex),
              pdfDocIds: [...new Set([...(b.pdfDocIds ?? []), ...addedDocIds])],
            }
          : b
      ),
      history: {
        past: [...s.history.past, historySnapshot].slice(-HISTORY_PAST_MAX),
        future: [],
      },
      selectedIds: targetId === s.activeBoardId ? [] : s.selectedIds,
      editingId: targetId === s.activeBoardId ? null : s.editingId,
    }));
    get().saveNow();
    scheduleHistorySave(() => persistableHistory(get()));
    return incoming.length;
  },

  /**
   * Inserts a run of a PDF's pages into the active notebook.
   *
   * The bytes go to IndexedDB once and each page keeps only a reference, for
   * the reasons in `importPdfAsNotebook`. The WHOLE document is stored even
   * when only three pages are inserted: pages are referenced by number into
   * the original file, and re-cutting the PDF to match the range would cost
   * more than the space it saves and lose the ability to insert more later.
   */
  insertPdfPages: async (file, range, atIndex) => {
    const targetId = get().activeBoardId;
    const target = get().boards.find((b) => b.id === targetId);
    if (!target || !isNotebook(target)) {
      throw new Error("Pages can only be inserted into a notebook.");
    }

    const { readPdfFile, openPdf } = await import("../lib/whiteboard/pdf");
    const { putPdf } = await import("../lib/whiteboard/pdfstore");

    const bytes = await readPdfFile(file);
    const doc = await openPdf(bytes);
    const pageCount = doc.numPages;
    if (pageCount < 1) throw new Error(`"${file.name}" has no pages.`);

    const { indices } = resolvePageRange(pageCount, range.from, range.to);
    if (indices.length === 0) return 0;

    const docId = `pdf_${Date.now().toString(36)}_${nanoid(6)}`;
    await putPdf({ id: docId, name: file.name, bytes, pageCount, addedAt: Date.now() });

    const incoming = indices.map((i) => pageFromPdf(docId, i + 1));

    set((s) => ({
      boards: s.boards.map((b) =>
        b.id === targetId
          ? {
              ...nbInsertPages(b, incoming, atIndex),
              pdfDocIds: [...new Set([...(b.pdfDocIds ?? []), docId])],
            }
          : b
      ),
      selectedIds: [],
      editingId: null,
    }));
    get().saveNow();
    return incoming.length;
  },

  /**
   * Appends one page per image to the active notebook.
   *
   * Each image is scaled to FIT its sheet and centred — never cropped, because
   * silently cutting the edge off someone's scanned worksheet is destructive
   * and invisible. They are locked, like a PDF page: a backdrop to write on,
   * not an object to drag out of place by accident.
   */
  addImagePages: (images) => {
    const activeId = get().activeBoardId;
    const board = get().boards.find((b) => b.id === activeId);
    if (!board || !isNotebook(board) || images.length === 0) return;

    const dim = pageSizeOf(board);
    const now = Date.now();
    const pages = images.map((img, i) => {
      const scale = Math.min(dim.width / img.width, dim.height / img.height);
      const w = img.width * scale;
      const h = img.height * scale;
      return {
        id: `pg_img_${now.toString(36)}_${i}_${nanoid(4)}`,
        elements: [
          {
            id: nanoid(8),
            type: "image",
            x: (dim.width - w) / 2,
            y: (dim.height - h) / 2,
            width: w,
            height: h,
            angle: 0,
            opacity: 1,
            src: img.src,
            locked: true,
            createdAt: now,
            updatedAt: now,
          } as unknown as WhiteboardElement,
        ],
        background: { pattern: "plain" as const },
        createdAt: now,
        updatedAt: now,
      };
    });

    set((s) => ({
      boards: s.boards.map((b) =>
        b.id === activeId
          ? { ...b, pages: [...getPages(b), ...pages], activePageId: pages[0].id, updatedAt: now }
          : b
      ),
      selectedIds: [],
      editingId: null,
    }));
    get().saveNow();
  },

  addCaptureToBoard: (boardId, image) => {
    const target = get().boards.find((b) => b.id === boardId);
    if (!target) return null;
    const now = Date.now();
    const elementId = nanoid(8);
    const imageAt = (rect: { x: number; y: number; width: number; height: number }): ImageElement => ({
      id: elementId,
      type: "image",
      ...rect,
      rotation: 0,
      opacity: 1,
      src: image.src,
      naturalWidth: image.naturalWidth,
      naturalHeight: image.naturalHeight,
      createdAt: now,
      updatedAt: now,
    });
    // The step belongs to the document that RECEIVED the picture. Filed under
    // the one you captured in, its whole-document snapshot of the other
    // notebook was restored by an Undo there - wiping everything written in
    // that notebook since. Kept with the target, Undo in the target removes
    // it in its proper turn, after any later edits.
    const activeAt = boardId;
    const pushHistory = (entry: HistoryEntry) => (s: WhiteboardState) => ({
      past: [...s.history.past, entry].slice(-HISTORY_PAST_MAX),
      future: s.history.future.filter((e) => contextOf(e) !== activeAt),
    });

    if (isNotebook(target)) {
      const pages = getPages(target);
      const after = image.afterPageId ? pages.findIndex((p) => p.id === image.afterPageId) : -1;
      const at = after >= 0 ? after + 1 : pages.length;
      // A plain new sheet with the NOTEBOOK's paper, like "add page"; not
      // locked like an image page, because a clipping is something you move.
      const page: NotebookPage = {
        ...createPage(target.background),
        elements: [imageAt(placeCaptureOnPage(pageSizeOf(target), image.size))],
      };
      const entry: HistoryEntry = {
        activeAt,
        boardId,
        pageId: target.activePageId,
        pages: clonePagesForHistory(pages),
        elements: [],
        at: now,
      };
      set((s) => ({
        boards: s.boards.map((b) => (b.id === boardId ? nbInsertPages(b, [page], at) : b)),
        history: pushHistory(entry)(s),
        selectedIds: boardId === s.activeBoardId ? [] : s.selectedIds,
        editingId: boardId === s.activeBoardId ? null : s.editingId,
      }));
      get().saveNow();
      scheduleHistorySave(() => persistableHistory(get()));
      return { elementId, pageId: page.id, pageNumber: at + 1 };
    }

    const existing = getBoardElements(target);
    const entry: HistoryEntry = {
      activeAt,
      boardId,
      elements: cloneElementsForHistory(existing),
      at: now,
    };
    const el = imageAt(placeCaptureBeside(existing, image.size));
    set((s) => ({
      boards: s.boards.map((b) => (b.id === boardId ? mapBoardElements(b, (els) => [...els, el]) : b)),
      history: pushHistory(entry)(s),
    }));
    get().saveNow();
    scheduleHistorySave(() => persistableHistory(get()));
    return { elementId };
  },

  pruneOrphanedAssets: async () => {
    // One shared collector (unit-tested in workspace.ts): live boards,
    // templates, AND the trash undo buffer. A picture or PDF on a deleted
    // board must survive until Undo expires — pruning it early would make
    // "Undo" restore a board with holes in it.
    const { pdfIds, imageIds } = collectReferencedAssets(
      get().boards,
      get().pageTemplates,
      (get().lastDeleted?.removedBoards ?? []).map((r) => r.board)
    );

    try {
      const [{ pruneUnusedPdfs }, { pruneUnusedImages }] = await Promise.all([
        import("../lib/whiteboard/pdfstore"),
        import("../lib/whiteboard/imagestore"),
      ]);
      await Promise.all([pruneUnusedPdfs(pdfIds), pruneUnusedImages(imageIds)]);
    } catch {
      // Reclaiming space is housekeeping: failing to do it must never break
      // the delete the user actually asked for.
    }
  },

  createBoard: (name, folderId, color = "#3b82f6") => {
    const id = nanoid(8);
    const existing = get().boards.map((b) => b.name);
    const uniqueName = makeUniqueName(name, existing);
    const newBoard: Board = {
      id,
      name: uniqueName,
      folderId: folderId ?? null,
      elements: [],
      background: { ...get().defaultPaper },
      camera: { ...DEFAULT_CAMERA },
      createdAt: Date.now(),
      updatedAt: Date.now(),
      accessedAt: Date.now(),
      starred: false,
      tags: [],
      color,
    };
    set((s) => ({
      folders: folderId
        ? s.folders.map((f) => (f.id === folderId ? { ...f, expanded: true } : f))
        : s.folders,
      boards: [
        // Capture the outgoing board's viewport before switching away
        ...s.boards.map((b) => (b.id === s.activeBoardId ? { ...b, camera: { ...s.camera } } : b)),
        newBoard,
      ],
      activeBoardId: id,
      camera: { ...DEFAULT_CAMERA },
      selectedIds: [],
      editingId: null,
      history: { past: [], future: [] },
    }));
    get().saveNow();
    return id;
  },

  renameBoard: (boardId, name) => {
    set((s) => ({
      boards: s.boards.map((b) =>
        b.id === boardId ? { ...b, name: name.trim() || b.name, updatedAt: Date.now() } : b
      ),
    }));
    get().saveNow();
  },

  deleteBoard: (boardId) => {
    set((s) => {
      // Strip cross-board connections in OTHER boards that pointed at the
      // deleted board (they would silently dangle forever).
      const remainingBoards = s.boards
        .filter((b) => b.id !== boardId)
        .map((b) =>
          mapAllBoardElements(b, (els) =>
            els.filter((el) => {
              if (el.type !== "connection") return true;
              const conn = el as ConnectionElement;
              return conn.source.boardId !== boardId && conn.target.boardId !== boardId;
            })
          )
        );

      // Deleting a NON-active board must not hijack the user's current canvas,
      // camera, selection, or undo history.
      const wasActive = s.activeBoardId === boardId;
      if (!wasActive) {
        return { boards: remainingBoards };
      }
      const nextActive = remainingBoards[0]?.id || null;
      const nextBoard = remainingBoards.find((b) => b.id === nextActive);
      return {
        boards: remainingBoards,
        activeBoardId: nextActive,
        camera: nextBoard?.camera || { ...DEFAULT_CAMERA },
        selectedIds: [],
        editingId: null,
        history: { past: [], future: [] },
      };
    });
    get().saveNow();
    // Deleting a board is the one moment orphans appear. Fire and forget: the
    // delete has already happened and must not wait on housekeeping.
    void get().pruneOrphanedAssets();
  },

  duplicateBoard: (boardId) => {
    const board = get().boards.find((b) => b.id === boardId);
    if (!board) return null;
    const id = nanoid(8);
    const uniqueName = makeUniqueName(`${board.name} (Copy)`, get().boards.map((b) => b.name));

    // Create a mapping from old element IDs to new element IDs
    const idMap = new Map<string, string>();
    for (const el of allElements(board)) {
      idMap.set(el.id, nanoid(8));
    }

    const remapElement = (el: WhiteboardElement): WhiteboardElement => {
      const newId = idMap.get(el.id) || nanoid(8);
      if (el.type === "connection") {
        const conn = el as ConnectionElement;
        return {
          ...conn,
          id: newId,
          source: {
            ...conn.source,
            boardId: conn.source.boardId === boardId ? id : conn.source.boardId,
            elementId: idMap.get(conn.source.elementId) || conn.source.elementId,
          },
          target: {
            ...conn.target,
            boardId: conn.target.boardId === boardId ? id : conn.target.boardId,
            elementId: idMap.get(conn.target.elementId) || conn.target.elementId,
          },
          updatedAt: Date.now(),
        };
      }
      return {
        ...el,
        id: newId,
        updatedAt: Date.now(),
      };
    };

    const newBoard: Board = {
      ...board,
      id,
      name: uniqueName,
      // Copies every page of a notebook, giving each element a fresh id.
      ...cloneBoardContent(board, remapElement),
      createdAt: Date.now(),
      updatedAt: Date.now(),
      accessedAt: Date.now(),
    };
    set((s) => ({
      boards: [
        // Capture the outgoing board's viewport before switching away
        ...s.boards.map((b) => (b.id === s.activeBoardId ? { ...b, camera: { ...s.camera } } : b)),
        newBoard,
      ],
      activeBoardId: id,
      camera: { ...board.camera },
      selectedIds: [],
      editingId: null,
      history: { past: [], future: [] },
    }));
    get().saveNow();
    return id;
  },

  duplicateNotebook: (sourceBoardId, options) => {
    const source = get().boards.find((b) => b.id === sourceBoardId);
    if (!source) return null;
    const targetBoardId = nanoid(8);
    const uniqueName = makeUniqueName(
      options.name?.trim() || `${source.name} (Copy)`,
      get().boards.map((b) => b.name)
    );

    let copiedPages: NotebookPage[];
    if (isNotebook(source)) {
      const sourcePages = getPages(source);
      const indices = options.pageIndices
        ? sanitizePageIndices(options.pageIndices)
        : sourcePages.map((_, i) => i);
      copiedPages = copyPagesFrom(source, indices, targetBoardId, () => nanoid(8));
    } else {
      // A canvas has no pages, but it does have contents. Copy it through
      // copyPagesFrom like every other path, so connections are remapped to
      // the new board with fresh element ids instead of dangling at the old
      // board/elements.
      const asPage = {
        id: "tmp",
        elements: source.elements ?? [],
        background: source.background,
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };
      copiedPages = copyPagesFrom(
        { ...source, kind: "notebook", pages: [asPage] } as Board,
        [0],
        targetBoardId,
        () => nanoid(8)
      );
    }

    if (copiedPages.length === 0) return null;

    const referencedDocIds = [
      ...new Set(
        copiedPages
          .map((p) => p.pdf?.docId)
          .filter((d): d is string => typeof d === "string")
      ),
    ];

    const newBoard: Board = {
      ...source,
      id: targetBoardId,
      name: uniqueName,
      folderId: options.folderId !== undefined ? options.folderId : (source.folderId ?? null),
      kind: "notebook",
      elements: [], // notebooks must never populate board.elements directly
      pages: copiedPages,
      activePageId: copiedPages[0].id,
      pdfDocIds: referencedDocIds,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      accessedAt: Date.now(),
    };

    set((s) => ({
      boards: [...s.boards, newBoard],
    }));
    get().saveNow();
    return targetBoardId;
  },

  setActiveBoard: (boardId) => {
    const board = get().boards.find((b) => b.id === boardId);
    if (!board) return;
    set((s) => ({
      activeBoardId: boardId,
      camera: board.camera || { ...DEFAULT_CAMERA },
      selectedIds: [],
      editingId: null,
      // History is deliberately KEPT: entries carry their board, and undo only
      // takes the live board's (see lastIndexForBoard). Wiping it here meant
      // that in split view every tap across the divider lost your undo.
      boards: s.boards.map((b) => {
        if (b.id === boardId) return { ...b, accessedAt: Date.now() };
        // Persist the outgoing board's viewport in memory immediately —
        // the debounced save would otherwise never capture it.
        if (b.id === s.activeBoardId) return { ...b, camera: { ...s.camera } };
        return b;
      }),
    }));
    get().saveNow();
  },

  moveBoard: (boardId, newFolderId) => {
    const s = get();
    const board = s.boards.find((b) => b.id === boardId);
    if (!board) return;
    if (newFolderId !== null && !s.folders.some((f) => f.id === newFolderId)) return;
    if (board.folderId === newFolderId) return;
    set((prev) => ({
      boards: prev.boards.map((b) => (b.id === boardId ? { ...b, folderId: newFolderId } : b)),
    }));
    get().saveNow();
  },

  setBoardColor: (boardId, color) => {
    set((s) => ({
      boards: s.boards.map((b) => (b.id === boardId ? { ...b, color } : b)),
    }));
    get().saveNow();
  },

  /** Per-board paper: colour and/or pattern. Undefined colour = follow theme.
   *
   * By default only the board default changes: pages with their own paper keep
   * it, and new pages start with the default. With `allPages`, every existing
   * page in a notebook is rewritten too.
   */
  setBoardBackground: (boardId, patch, opts) => {
    set((s) => ({
      boards: s.boards.map((b) => {
        if (b.id !== boardId) return b;
        const background = { pattern: "dots" as const, ...(b.background ?? {}), ...patch };
        if (!opts?.allPages || !isNotebook(b) || !Array.isArray(b.pages)) {
          return { ...b, background, updatedAt: Date.now() };
        }
        return {
          ...b,
          background,
          pages: b.pages.map((p) => ({
            ...p,
            background: { pattern: "dots" as const, ...(p.background ?? {}), ...patch },
            updatedAt: Date.now(),
          })),
          updatedAt: Date.now(),
        };
      }),
    }));
    get().saveNow();
  },
  setDefaultPaper: (patch) => {
    set((s) => ({ defaultPaper: { ...s.defaultPaper, ...patch } }));
    get().saveNow();
  },

  toggleStarred: (boardId) => {
    set((s) => ({
      boards: s.boards.map((b) => (b.id === boardId ? { ...b, starred: !b.starred } : b)),
    }));
    get().saveNow();
  },

  addTag: (boardId, tag) => {
    const clean = tag.trim().replace(/^#/, "");
    if (!clean) return;
    set((s) => ({
      boards: s.boards.map((b) =>
        b.id === boardId && !b.tags?.includes(clean)
          ? { ...b, tags: [...(b.tags || []), clean] }
          : b
      ),
    }));
    get().saveNow();
  },

  removeTag: (boardId, tag) => {
    set((s) => ({
      boards: s.boards.map((b) =>
        b.id === boardId ? { ...b, tags: (b.tags || []).filter((t) => t !== tag) } : b
      ),
    }));
    get().saveNow();
  },

  findOrCreateBoardByName: (name) => {
    const existing = get().boards.find((b) => b.name.toLowerCase() === name.toLowerCase());
    if (existing) return existing.id;
    return get().createBoard(name, get().activeFolderId);
  },

  searchBoards: (query) => {
    const q = query.toLowerCase().trim();
    if (!q) return [];
    const results: Array<{ boardId: string; boardName: string; snippet: string; elementId: string }> = [];
    for (const board of get().boards) {
      if (board.name.toLowerCase().includes(q)) {
        results.push({
          boardId: board.id,
          boardName: board.name,
          snippet: `Board name matches "${query}"`,
          elementId: "",
        });
      }
      for (const el of allElements(board)) {
        if (el.type === "text" || el.type === "sticky") {
          const text = (el as { text?: string }).text || "";
          if (text.toLowerCase().includes(q)) {
            results.push({
              boardId: board.id,
              boardName: board.name,
              snippet: text.slice(0, 100),
              elementId: el.id,
            });
          }
        }
      }
    }
    return results;
  },

  getRecentBoards: (limit = 5) => {
    return [...get().boards]
      .sort((a, b) => (b.accessedAt || b.createdAt) - (a.accessedAt || a.createdAt))
      .slice(0, limit);
  },

  getStarredBoards: () => {
    return get().boards.filter((b) => b.starred);
  },

  // ----- Elements -----
  addElement: (el, commit = true) => {
    const activeId = get().activeBoardId;
    if (!activeId) return;
    if (commit) get().commitHistory();
    set((s) => ({
      boards: s.boards.map((b) =>
        b.id === activeId ? mapBoardElements(b, (els) => [...els, el]) : b
      ),
    }));
    get().saveNow();
  },

  addElements: (els, commit = true) => {
    const activeId = get().activeBoardId;
    if (!activeId || els.length === 0) return;
    if (commit) get().commitHistory();
    set((s) => ({
      boards: s.boards.map((b) =>
        b.id === activeId ? mapBoardElements(b, (prev) => [...prev, ...els]) : b
      ),
    }));
    get().saveNow();
  },

  addElementToBoard: (boardId, el, commit = true) => {
    if (commit) get().commitHistory();
    set((s) => ({
      boards: s.boards.map((b) =>
        b.id === boardId ? mapBoardElements(b, (els) => [...els, el]) : b
      ),
    }));
    get().saveNow();
  },

  deleteElementFromBoard: (boardId, ids, commit = true) => {
    if (!ids.length) return;
    if (commit) get().commitHistory();
    set((s) => ({
      boards: s.boards.map((b) =>
        b.id === boardId
          ? mapBoardElements(b, (els) => els.filter((el) => !ids.includes(el.id)))
          : b
      ),
      // If the deleted element was being edited, close the editor
      editingId: s.editingId && ids.includes(s.editingId) ? null : s.editingId,
    }));
    get().saveNow();
  },

  updateElement: (id, patch, commit = false) => {
    const activeId = get().activeBoardId;
    if (!activeId) return;
    if (commit) get().commitHistory();
    set((s) => ({
      boards: s.boards.map((b) => {
        if (b.id !== activeId) return b;
        return mapBoardElements(b, (els) =>
          els.map((el) =>
            el.id === id ? ({ ...el, ...patch, updatedAt: Date.now() } as WhiteboardElement) : el
          )
        );
      }),
    }));
    get().saveNow();
  },

  updateElements: (ids, patch, commit = false) => {
    const activeId = get().activeBoardId;
    if (!activeId || ids.length === 0) return;
    if (commit) get().commitHistory();
    set((s) => ({
      boards: s.boards.map((b) => {
        if (b.id !== activeId) return b;
        return mapBoardElements(b, (els) =>
          els.map((el) =>
            ids.includes(el.id) ? ({ ...el, ...patch, updatedAt: Date.now() } as WhiteboardElement) : el
          )
        );
      }),
    }));
    get().saveNow();
  },

  deleteElements: (ids, commit = true) => {
    const activeId = get().activeBoardId;
    if (!activeId || ids.length === 0) return;
    // Locked elements can be selected but never destroyed from the canvas.
    const board = get().boards.find((b) => b.id === activeId);
    const deletable = ids.filter((id) => {
      const el = board ? getBoardElements(board).find((e) => e.id === id) : undefined;
      return el ? !el.locked : true; // unknown ids pass through (connections cleanup)
    });
    if (deletable.length === 0) return;
    ids = deletable;
    if (commit) get().commitHistory();
    set((s) => ({
      boards: s.boards.map((b) => {
        if (b.id !== activeId) return b;
        // Filter out elements and any connection referencing them
        return mapBoardElements(b, (els) =>
          els.filter((el) => {
            if (ids.includes(el.id)) return false;
            if (el.type === "connection") {
              const conn = el as ConnectionElement;
              if (ids.includes(conn.source.elementId) || ids.includes(conn.target.elementId)) {
                return false;
              }
            }
            return true;
          })
        );
      }),
      selectedIds: s.selectedIds.filter((id) => !ids.includes(id)),
      editingId: s.editingId && ids.includes(s.editingId) ? null : s.editingId,
    }));
    get().saveNow();
  },

  deleteSelected: () => {
    get().deleteElements(get().selectedIds, true);
  },

  duplicateElements: (ids) => {
    const activeId = get().activeBoardId;
    if (!activeId || ids.length === 0) return [];
    get().commitHistory();
    const board = get().boards.find((b) => b.id === activeId);
    if (!board) return [];

    const cloned: WhiteboardElement[] = [];
    const idMap = new Map<string, string>();

    for (const id of ids) {
      const el = getBoardElements(board).find((e) => e.id === id);
      if (el && el.type !== "connection") {
        const newId = nanoid(8);
        idMap.set(id, newId);
        cloned.push({
          ...el,
          id: newId,
          x: el.x + 30,
          y: el.y + 30,
          createdAt: Date.now(),
          updatedAt: Date.now(),
        });
      }
    }

    set((s) => ({
      boards: s.boards.map((b) =>
        b.id === activeId ? mapBoardElements(b, (els) => [...els, ...cloned]) : b
      ),
      selectedIds: cloned.map((c) => c.id),
    }));
    get().saveNow();
    return cloned.map((c) => c.id);
  },

  unlockElements: (ids) => {
    const activeId = get().activeBoardId;
    const board = get().boards.find((b) => b.id === activeId);
    if (!board || ids.length === 0) return 0;
    const want = new Set(ids);
    const count = getBoardElements(board).filter((el) => want.has(el.id) && el.locked).length;
    if (count === 0) return 0;
    get().commitHistory();
    set((s) => ({
      boards: s.boards.map((b) =>
        b.id !== activeId
          ? b
          : mapBoardElements(b, (els) =>
              els.map((el) => (want.has(el.id) && el.locked ? { ...el, locked: false, updatedAt: Date.now() } : el))
            )
      ),
    }));
    get().saveNow();
    return count;
  },

  setLockedMode: (on) => {
    // Entering or leaving the mode starts from an empty selection: what was
    // picked belongs to the other set (unlocked vs locked).
    set({ lockedMode: on, selectedIds: [] });
    if (on && get().tool !== "select" && get().tool !== "lasso") set({ tool: "select" });
  },

  setImageStudioId: (id) => set({ imageStudioId: id }),

  toggleLock: (ids) => {
    const activeId = get().activeBoardId;
    if (!activeId || ids.length === 0) return;
    get().commitHistory();
    set((s) => ({
      boards: s.boards.map((b) => {
        if (b.id !== activeId) return b;
        return mapBoardElements(b, (els) =>
          els.map((el) =>
            ids.includes(el.id) ? { ...el, locked: !el.locked, updatedAt: Date.now() } : el
          )
        );
      }),
    }));
    get().saveNow();
  },

  bringToFront: (ids) => {
    const activeId = get().activeBoardId;
    if (!activeId || ids.length === 0) return;
    get().commitHistory();
    set((s) => ({
      boards: s.boards.map((b) => {
        if (b.id !== activeId) return b;
        return mapBoardElements(b, (els) => [
          ...els.filter((e) => !ids.includes(e.id)),
          ...els.filter((e) => ids.includes(e.id)),
        ]);
      }),
    }));
    get().saveNow();
  },

  sendToBack: (ids) => {
    const activeId = get().activeBoardId;
    if (!activeId || ids.length === 0) return;
    get().commitHistory();
    set((s) => ({
      boards: s.boards.map((b) => {
        if (b.id !== activeId) return b;
        return mapBoardElements(b, (els) => [
          ...els.filter((e) => ids.includes(e.id)),
          ...els.filter((e) => !ids.includes(e.id)),
        ]);
      }),
    }));
    get().saveNow();
  },

  bringForward: (ids) => {
    const activeId = get().activeBoardId;
    if (!activeId || ids.length === 0) return;
    get().commitHistory();
    set((s) => ({
      boards: s.boards.map((b) => {
        if (b.id !== activeId) return b;
        // Move each selected element up by ONE position (swap with the
        // element above it), not all the way to the top.
        return mapBoardElements(b, (prev) => {
          const elements = [...prev];
          for (let i = elements.length - 2; i >= 0; i--) {
            if (ids.includes(elements[i].id) && !ids.includes(elements[i + 1].id)) {
              [elements[i], elements[i + 1]] = [elements[i + 1], elements[i]];
            }
          }
          return elements;
        });
      }),
    }));
    get().saveNow();
  },

  sendBackward: (ids) => {
    const activeId = get().activeBoardId;
    if (!activeId || ids.length === 0) return;
    get().commitHistory();
    set((s) => ({
      boards: s.boards.map((b) => {
        if (b.id !== activeId) return b;
        // Move each selected element down by ONE position (swap with the
        // element below it), not all the way to the back.
        return mapBoardElements(b, (prev) => {
          const elements = [...prev];
          for (let i = 1; i < elements.length; i++) {
            if (ids.includes(elements[i].id) && !ids.includes(elements[i - 1].id)) {
              [elements[i], elements[i - 1]] = [elements[i - 1], elements[i]];
            }
          }
          return elements;
        });
      }),
    }));
    get().saveNow();
  },

  // ----- Connections -----
  createConnection: (source, target, linkType = "relates", routing = "curved") => {
    const activeId = get().activeBoardId;
    if (!activeId) return "";
    get().commitHistory();
    const connId = nanoid(8);
    const newConn: ConnectionElement = {
      id: connId,
      type: "connection",
      x: 0,
      y: 0,
      rotation: 0,
      opacity: 1,
      source: {
        boardId: source.boardId,
        elementId: source.elementId,
        anchor: source.anchor || "auto",
      },
      target: {
        boardId: target.boardId,
        elementId: target.elementId,
        anchor: target.anchor || "auto",
      },
      linkType,
      routing,
      dashStyle: "solid",
      startArrowhead: "none",
      endArrowhead: "arrow",
      strokeWidth: 2.5,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    get().addElement(newConn, false);
    return connId;
  },

  // ----- Selection & Inline Editing -----
  setSelected: (ids) => set({ selectedIds: ids }),
  addToSelection: (id) =>
    set((s) => ({ selectedIds: s.selectedIds.includes(id) ? s.selectedIds : [...s.selectedIds, id] })),
  removeFromSelection: (id) =>
    set((s) => ({ selectedIds: s.selectedIds.filter((sid) => sid !== id) })),
  toggleSelection: (id) =>
    set((s) => ({
      selectedIds: s.selectedIds.includes(id)
        ? s.selectedIds.filter((sid) => sid !== id)
        : [...s.selectedIds, id],
    })),
  clearSelection: () => set({ selectedIds: [] }),
  selectAll: () => {
    const board = get().boards.find((b) => b.id === get().activeBoardId);
    if (!board) return;
    // Obeys the Select tool's filter, so "select all" with only Handwriting
    // ticked grabs every stroke on the page and nothing else.
    const filter = effectiveSelectFilter(get().touchSettings.selectFilter);
    // In locked-items mode "all" means every LOCKED thing, ready to unlock.
    const lockedMode = get().lockedMode;
    set({
      selectedIds: getBoardElements(board)
        .filter((el) => (lockedMode ? !!el.locked && el.type !== "connection" : !el.locked && passesSelectFilter(el, filter)))
        .map((el) => el.id),
    });
  },

  selectByType: (type) => {
    const board = get().boards.find((b) => b.id === get().activeBoardId);
    if (!board) return;
    const elements = getBoardElements(board);
    const ids = elements
      .filter((el) => {
        if (el.locked) return false;
        if (type === "stroke") return el.type === "stroke";
        if (type === "text") return el.type === "text";
        if (type === "sticky") return el.type === "sticky";
        if (type === "image") return el.type === "image";
        if (type === "connection") return el.type === "connection";
        if (type === "shape") {
          return [
            "rectangle",
            "ellipse",
            "diamond",
            "triangle",
            "star",
            "cloud",
            "line",
            "arrow",
          ].includes(el.type);
        }
        return false;
      })
      .map((el) => el.id);
    set({ selectedIds: ids });
  },

  invertSelection: () => {
    const board = get().boards.find((b) => b.id === get().activeBoardId);
    if (!board) return;
    const currentSelected = new Set(get().selectedIds);
    const elements = getBoardElements(board);
    const inverted = elements
      .filter((el) => !el.locked && !currentSelected.has(el.id))
      .map((el) => el.id);
    set({ selectedIds: inverted });
  },

  setEditingId: (id) => {
    set({ editingId: id });
    if (id) {
      set({ selectedIds: [id] });
    }
  },

  discardAbandonedText: (id, boardId) => {
    const board = get().boards.find((b) => b.id === boardId);
    if (!board) return false;
    const el = allElements(board).find((e) => e.id === id);
    if (!isAbandonedTextBox(el)) return false;

    const withoutIt = (els: WhiteboardElement[]) =>
      els.filter((e) => {
        if (e.id === id) return false;
        if (e.type === "connection") {
          const c = e as ConnectionElement;
          if (c.source.elementId === id || c.target.elementId === id) return false;
        }
        return true;
      });

    set((s) => ({
      boards: s.boards.map((b) => (b.id === boardId ? mapAllBoardElements(b, withoutIt) : b)),
      selectedIds: s.selectedIds.filter((x) => x !== id),
    }));

    // Undo. Placing the box pushed a snapshot of the page BEFORE it existed
    // (and the editor's first auto-resize may have pushed another that holds
    // the empty box). Left on the stack, the next undo would "undo" nothing
    // visible - or resurrect the empty box. So pop every entry at the top
    // that is identical to the page as it is now, ignoring the discarded box.
    // Comparing CONTENT, not just ids, is what stops this eating a real edit:
    // an earlier move leaves a snapshot with the old position, which differs.
    const after = get().boards.find((b) => b.id === boardId);
    if (after) {
      const pageEls = (pageId?: string) => {
        if (!pageId || !isNotebook(after)) return getBoardElements(after);
        return getPages(after).find((pg) => pg.id === pageId)?.elements ?? [];
      };
      const past = [...get().history.past];
      let popped = 0;
      while (past.length > 0) {
        const top = past[past.length - 1];
        if (top.boardId !== boardId) break;
        const same = JSON.stringify(withoutIt(top.elements)) === JSON.stringify(pageEls(top.pageId));
        if (!same) break;
        past.pop();
        popped++;
      }
      if (popped > 0) set((s) => ({ history: { ...s.history, past } }));
    }

    get().saveNow();
    return true;
  },

  // ----- Camera -----
  setCamera: (camera) =>
    set((s) => ({ camera: boundCamera(s, { ...s.camera, ...camera }) })),

  panCamera: (dx, dy) =>
    set((s) => ({
      camera: boundCamera(s, {
        ...s.camera,
        x: s.camera.x - dx / s.camera.zoom,
        y: s.camera.y - dy / s.camera.zoom,
      }),
    })),

  setCanvasViewport: (vp) => {
    const cur = get().canvasViewport;
    if (!(vp.width > 0) || !(vp.height > 0)) return;
    if (vp.width === cur.width && vp.height === cur.height) return;
    set({ canvasViewport: vp });
  },

  zoomTo: (zoom, centerX, centerY, customViewport) => {
    set((s) => {
      const vp = customViewport || get().canvasViewport;
      // A notebook stops zooming out once the sheet fits: past that point the
      // page only shrinks and the grey desk grows, which is the whole
      // complaint. A whiteboard is infinite and keeps the plain floor.
      const nbBoard = s.boards.find((b) => b.id === s.activeBoardId);
      const floor = isNotebook(nbBoard)
        ? Math.min(Math.max(MIN_ZOOM, minNotebookZoom(vp, pageSizeOf(nbBoard))), MAX_ZOOM)
        : MIN_ZOOM;
      const newZoom = clamp(zoom, floor, MAX_ZOOM);
      if (centerX !== undefined && centerY !== undefined) {
        const worldX = (centerX - vp.width / 2) / s.camera.zoom + s.camera.x;
        const worldY = (centerY - vp.height / 2) / s.camera.zoom + s.camera.y;
        const newCameraX = worldX - (centerX - vp.width / 2) / newZoom;
        const newCameraY = worldY - (centerY - vp.height / 2) / newZoom;
        return { camera: { x: newCameraX, y: newCameraY, zoom: newZoom } };
      }
      return { camera: { ...s.camera, zoom: newZoom } };
    });
  },

  zoomToFit: (customViewport) => {
    const board = get().boards.find((b) => b.id === get().activeBoardId);
    if (!board) return;
    // The stored canvas size, not the window: in split view the window is not
    // the canvas. Defaults to 1200x800 before the first measurement.
    const vp = customViewport || get().canvasViewport;
    if (isNotebook(board)) {
      // Fit the SHEET width, not the ink bounds: on a sparse page the ink box
      // is arbitrary (one dot fits to a dot), while the sheet is the stable
      // frame the user reads. The active page stays anchored at world y = 0,
      // so its centre is always half a sheet down.
      const dim = pageSizeOf(board);
      const MARGIN = 24;
      const fitZoom = clamp((vp.width - MARGIN * 2) / dim.width, MIN_ZOOM, 2.0);
      set({ camera: { x: dim.width / 2, y: dim.height / 2, zoom: fitZoom } });
      return;
    }
    const fitElements = getBoardElements(board);
    if (fitElements.length === 0) {
      get().resetCamera();
      return;
    }
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    for (const el of fitElements) {
      if (el.type === "connection") continue;
      const b = getElementBounds(el);
      if (b.x < minX) minX = b.x;
      if (b.y < minY) minY = b.y;
      if (b.x + b.width > maxX) maxX = b.x + b.width;
      if (b.y + b.height > maxY) maxY = b.y + b.height;
    }
    if (!isFinite(minX)) {
      get().resetCamera();
      return;
    }
    const padding = 120;
    const contentW = maxX - minX + padding * 2;
    const contentH = maxY - minY + padding * 2;
    const cx = (minX + maxX) / 2;
    const cy = (minY + maxY) / 2;
    const zoom = clamp(Math.min(vp.width / contentW, vp.height / contentH), MIN_ZOOM, 2.0);
    set({ camera: { x: cx, y: cy, zoom } });
  },

  resetCamera: () => set({ camera: { ...DEFAULT_CAMERA } }),

  // ----- Tool / Style -----
  setTool: (tool) => {
    // Remember which pen family was in hand, so "go back to the pen" restores
    // the pen you were actually using rather than a hardcoded default.
    set(isStrokeTool(tool) ? { tool, lastStrokeTool: tool } : { tool });
    // Locked-items mode belongs to the Select tool: any other tool ends it.
    if (tool !== "select" && tool !== "lasso" && get().lockedMode) set({ lockedMode: false });
    if (tool !== "select" && tool !== "lasso") {
      // Picking up a pen (or any drawing tool) while typing used to leave the
      // text editor open over the canvas, still grabbing the keyboard. It ends
      // the edit now. Select/Lasso deliberately do NOT: placing a text box
      // starts the edit and then switches to Select in the same breath, and
      // ending it there would throw away the box before you typed a letter.
      // The Text tool keeps it too - the next tap elsewhere starts a new box.
      if (tool === "text") set({ selectedIds: [] });
      else set({ selectedIds: [], editingId: null });
    }
  },

  setStyle: (patch) => {
    set((s) => ({ style: { ...s.style, ...patch } }));
    // saveNow is debounced, so dragging a size slider coalesces into one write.
    get().saveNow();
  },

  // ----- History -----
  commitHistory: () => {
    const board = get().boards.find((b) => b.id === get().activeBoardId);
    if (!board) return;
    set((s) => ({
      history: {
        past: [
          // 100 undo steps, per the feature request (was 50).
          ...s.history.past.slice(-(HISTORY_PAST_MAX - 1)),
          {
            elements: cloneElementsForHistory(getBoardElements(board)),
            boardId: board.id,
            activeAt: board.id,
            pageId: getActivePage(board)?.id,
            at: Date.now(),
          },
        ],
        // A new edit ends the redo of things done from HERE only; the other
        // pane's redo is still valid and must survive.
        future: s.history.future.filter((e) => contextOf(e) !== board.id),
      },
    }));
    scheduleHistorySave(() => persistableHistory(get()));
  },

  undo: () => {
    const state = get();
    if (state.editingId) return; // never revert an in-progress inline edit
    const at = lastIndexForContext(state.history.past, state.activeBoardId);
    if (at < 0) return;
    const last = state.history.past[at];
    const board = state.boards.find((b) => b.id === last.boardId);
    if (!board) return;
    const currentSnapshot: HistoryEntry =
      last.pages && isNotebook(board)
        ? {
            pages: clonePagesForHistory(board.pages ?? []),
            elements: [],
            boardId: board.id,
            activeAt: contextOf(last),
            pageId: board.activePageId,
            at: Date.now(),
          }
        : {
            elements: cloneElementsForHistory(getBoardElements(board)),
            boardId: board.id,
            activeAt: contextOf(last),
            pageId: getActivePage(board)?.id,
            at: Date.now(),
          };
    set((s) => ({
      history: {
        past: s.history.past.filter((_, i) => i !== at),
        future: [...s.history.future, currentSnapshot].slice(-HISTORY_FUTURE_MAX),
      },
      boards: s.boards.map((b) =>
        b.id === board.id ? restoreHistoryElements(b, last) : b
      ),
      selectedIds: board.id === s.activeBoardId ? [] : s.selectedIds,
      editingId: board.id === s.activeBoardId ? null : s.editingId,
    }));
    get().saveNow();
    scheduleHistorySave(() => persistableHistory(get()));
  },

  redo: () => {
    const state = get();
    if (state.editingId) return; // never swap content under the open editor
    const at = lastIndexForContext(state.history.future, state.activeBoardId);
    if (at < 0) return;
    const next = state.history.future[at];
    const board = state.boards.find((b) => b.id === next.boardId);
    if (!board) return;
    const currentSnapshot: HistoryEntry =
      next.pages && isNotebook(board)
        ? {
            pages: clonePagesForHistory(board.pages ?? []),
            elements: [],
            boardId: board.id,
            activeAt: contextOf(next),
            pageId: board.activePageId,
            at: Date.now(),
          }
        : {
            elements: cloneElementsForHistory(getBoardElements(board)),
            boardId: board.id,
            activeAt: contextOf(next),
            pageId: getActivePage(board)?.id,
            at: Date.now(),
          };
    set((s) => ({
      history: {
        past: [...s.history.past, currentSnapshot].slice(-HISTORY_PAST_MAX),
        future: s.history.future.filter((_, i) => i !== at),
      },
      boards: s.boards.map((b) =>
        b.id === board.id ? restoreHistoryElements(b, next) : b
      ),
      selectedIds: board.id === s.activeBoardId ? [] : s.selectedIds,
      editingId: board.id === s.activeBoardId ? null : s.editingId,
    }));
    get().saveNow();
    scheduleHistorySave(() => persistableHistory(get()));
  },

  canUndo: () => lastIndexForContext(get().history.past, get().activeBoardId) >= 0,
  canRedo: () => lastIndexForContext(get().history.future, get().activeBoardId) >= 0,

  toggleSidebar: () => set((s) => ({ sidebarOpen: !s.sidebarOpen })),
  setSidebarOpen: (open) => set({ sidebarOpen: open }),

  setSidebarSort: (by, order) => {
    set((s) => ({
      sidebarSortBy: by,
      sidebarSortOrder:
        order ??
        (s.sidebarSortBy === by
          ? s.sidebarSortOrder === "asc"
            ? "desc"
            : "asc"
          : by === "name"
          ? "asc"
          : "desc"),
    }));
  },

  batchMoveBoards: (boardIds, targetFolderId) => {
    if (boardIds.length === 0) return;
    const s = get();
    if (targetFolderId !== null && !s.folders.some((f) => f.id === targetFolderId)) return;
    const toMoveSet = new Set(boardIds);
    set((prev) => ({
      boards: prev.boards.map((b) => (toMoveSet.has(b.id) ? { ...b, folderId: targetFolderId } : b)),
    }));
    get().saveNow();
  },

  batchDeleteBoards: (boardIds) => {
    if (boardIds.length === 0) return;
    const toDeleteSet = new Set(boardIds);
    set((s) => {
      const remainingBoards = s.boards
        .filter((b) => !toDeleteSet.has(b.id))
        .map((b) =>
          mapAllBoardElements(b, (els) =>
            els.filter((el) => {
              if (el.type !== "connection") return true;
              const conn = el as ConnectionElement;
              return !toDeleteSet.has(conn.source.boardId) && !toDeleteSet.has(conn.target.boardId);
            })
          )
        );

      const activeWasDeleted = s.activeBoardId && toDeleteSet.has(s.activeBoardId);
      if (!activeWasDeleted) {
        return { boards: remainingBoards };
      }
      const nextActive = remainingBoards[0]?.id || null;
      const nextBoard = remainingBoards.find((b) => b.id === nextActive);
      return {
        boards: remainingBoards,
        activeBoardId: nextActive,
        camera: nextBoard?.camera || { ...DEFAULT_CAMERA },
        selectedIds: [],
        editingId: null,
        history: { past: [], future: [] },
      };
    });
    get().saveNow();
  },

  batchStarBoards: (boardIds, star) => {
    if (boardIds.length === 0) return;
    const toStarSet = new Set(boardIds);
    set((prev) => ({
      boards: prev.boards.map((b) => {
        if (!toStarSet.has(b.id)) return b;
        return { ...b, starred: star !== undefined ? star : !b.starred };
      }),
    }));
    get().saveNow();
  },

  lastDeleted: null,

  batchDuplicateBoards: (boardIds) => {
    const ids: string[] = [];
    for (const id of boardIds) {
      const created = get().duplicateBoard(id);
      if (created) ids.push(created);
    }
    return ids;
  },

  trashItems: (boardIds, folderIds) => {
    const s = get();
    const byId = new Map(s.boards.map((b) => [b.id, b]));
    const byFolder = new Map(s.folders.map((f) => [f.id, f]));
    // Expand folder subtrees (same rule as deleteFolder: grandchildren die
    // with the folder, so they can never be orphaned).
    const doomed = new Set<string>();
    for (const fid of folderIds) {
      if (!byFolder.has(fid) || doomed.has(fid)) continue;
      doomed.add(fid);
      let changed = true;
      while (changed) {
        changed = false;
        for (const f of s.folders) {
          if (f.parentId && doomed.has(f.parentId) && !doomed.has(f.id)) {
            doomed.add(f.id);
            changed = true;
          }
        }
      }
    }
    const doomedFolders = s.folders.filter((f) => doomed.has(f.id));
    const trashBoards = boardIds.map((id) => byId.get(id)).filter((b) => b !== undefined);
    if (trashBoards.length === 0 && doomedFolders.length === 0) return;
    const trashSet = new Set(trashBoards.map((b) => b.id));
    const removedBoards = s.boards
      .map((b, index) => ({ board: b, index }))
      .filter(({ board }) => trashSet.has(board.id));
    // Boards a trashed folder filed to root remember their folder for undo.
    const movedToRoot: Array<{ id: string; folderId: string | null }> = [];
    const remaining = s.boards
      .filter((b) => !trashSet.has(b.id))
      .map((b) => {
        if (b.folderId && doomed.has(b.folderId)) {
          movedToRoot.push({ id: b.id, folderId: b.folderId });
          return { ...b, folderId: null as string | null };
        }
        return b;
      });
    const activeWasDeleted = s.activeBoardId !== null && trashSet.has(s.activeBoardId);
    const nextActive = activeWasDeleted ? remaining[0]?.id || null : s.activeBoardId;
    const nextBoard = remaining.find((b) => b.id === nextActive);
    set({
      boards: remaining,
      folders: s.folders.filter((f) => !doomed.has(f.id)),
      activeBoardId: nextActive,
      activeFolderId: s.activeFolderId && doomed.has(s.activeFolderId) ? null : s.activeFolderId,
      ...(activeWasDeleted
        ? {
            camera: nextBoard?.camera || { ...DEFAULT_CAMERA },
            selectedIds: [],
            editingId: null,
            history: { past: [], future: [] },
          }
        : {}),
      lastDeleted: {
        removedBoards,
        removedFolders: doomedFolders,
        movedToRoot,
        activeBoardId: s.activeBoardId,
        activeFolderId: s.activeFolderId,
        at: Date.now(),
      },
    });
    get().saveNow();
    // No immediate prune: the buffer's pictures/PDFs stay referenced until
    // undo expires (discardTrash) or is used (undoTrash).
  },

  undoTrash: () => {
    const s = get();
    const buf = s.lastDeleted;
    if (!buf) return;
    // Reinsert removed boards at their original indices (clamped: the user
    // may have created boards meanwhile, which must not move).
    const returning = [...buf.removedBoards].sort((a, b) => a.index - b.index);
    const boards = [...s.boards];
    for (const { board, index } of returning) {
      if (boards.some((b) => b.id === board.id)) continue;
      boards.splice(Math.min(index, boards.length), 0, board);
    }
    const folderIds = new Set(s.folders.map((f) => f.id));
    const folders = [...s.folders, ...buf.removedFolders.filter((f) => !folderIds.has(f.id))];
    // Restore filed-to-root boards only if they are still at root: a board
    // the user re-filed meanwhile keeps its new home.
    const movedBack = new Map(buf.movedToRoot.map((m) => [m.id, m.folderId]));
    const restored = boards.map((b) => {
      const was = movedBack.get(b.id);
      if (was !== undefined && (b.folderId === null || b.folderId === undefined)) {
        return { ...b, folderId: was };
      }
      return b;
    });
    // Never hijack: only take back the active board/folder when what the
    // user looks at now is gone.
    const activeAlive = restored.some((b) => b.id === s.activeBoardId);
    const folderAlive = !s.activeFolderId || folders.some((f) => f.id === s.activeFolderId);
    set({
      boards: restored,
      folders,
      activeBoardId: !activeAlive && buf.activeBoardId ? buf.activeBoardId : s.activeBoardId,
      activeFolderId: !folderAlive ? buf.activeFolderId : s.activeFolderId,
      lastDeleted: null,
    });
    get().saveNow();
  },

  discardTrash: () => {
    if (!get().lastDeleted) return;
    set({ lastDeleted: null });
    // The buffer was the only thing keeping those files referenced.
    void get().pruneOrphanedAssets();
  },

  getPersistedState: () => {
    const s = get();
    return {
      version: 1,
      folders: s.folders,
      // Inject the live camera into the active board on every save so the
      // viewport position survives reloads (previously board.camera was frozen
      // at creation time and never updated).
      boards: s.boards.map((b) =>
        b.id === s.activeBoardId ? { ...b, camera: { ...s.camera } } : b
      ),
      activeBoardId: s.activeBoardId,
      activeFolderId: s.activeFolderId,
      customLinkTypes: s.customLinkTypes,
      pinnedPens: s.pinnedPens,
      pinnedBarPos: s.pinnedBarPos,
      toolbarPosition: s.toolbarPosition,
      splitBoardId: s.splitBoardId,
      splitRatio: s.splitRatio,
      splitSide: s.splitSide,
      splitOrientation: s.splitOrientation,
      pageTemplates: s.pageTemplates,
      pinnedBarVertical: s.pinnedBarVertical,
      recentColors: s.recentColors,
      style: s.style,
      tool: s.tool,
      lastStrokeTool: s.lastStrokeTool,
      touchSettings: s.touchSettings,
      dictationLang: s.dictationLang,
      lassoStrict: s.lassoStrict,
      snapToGrid: s.snapToGrid,
      minimapOpen: s.minimapOpen,
      legendOpen: s.legendOpen,
      zoomDockOpen: s.zoomDockOpen,
      shapeRecognition: s.shapeRecognition,
      propsPanelCollapsed: s.propsPanelCollapsed,
      toolPropsBarCollapsed: s.toolPropsBarCollapsed,
      toolbarTools: s.toolbarItems,
      toolbarHidden: ALL_TOOLBAR_ITEMS.filter((id) => !s.toolbarItems.includes(id)),
      defaultPaper: s.defaultPaper,
      pinnedBarOpen: s.pinnedBarOpen,
    };
  },

  saveNow: () => {
    scheduleSave(() => get().getPersistedState());
  },

  /** Everything worth backing up or syncing, with the live camera folded in. */
  getWorkspaceSnapshot: () => {
    const s = get();
    return {
      folders: s.folders,
      boards: s.boards.map((b) =>
        b.id === s.activeBoardId ? { ...b, camera: { ...s.camera } } : b
      ),
      activeBoardId: s.activeBoardId,
      activeFolderId: s.activeFolderId,
      customLinkTypes: s.customLinkTypes,
      pinnedPens: s.pinnedPens,
      pinnedBarPos: s.pinnedBarPos,
      toolbarPosition: s.toolbarPosition,
      splitBoardId: s.splitBoardId,
      splitRatio: s.splitRatio,
      splitSide: s.splitSide,
      splitOrientation: s.splitOrientation,
      pageTemplates: s.pageTemplates,
      recentColors: s.recentColors,
      style: s.style,
      tool: s.tool,
      touchSettings: s.touchSettings,
      dictationLang: s.dictationLang,
      lassoStrict: s.lassoStrict,
      snapToGrid: s.snapToGrid,
      minimapOpen: s.minimapOpen,
      legendOpen: s.legendOpen,
      zoomDockOpen: s.zoomDockOpen,
      shapeRecognition: s.shapeRecognition,
      propsPanelCollapsed: s.propsPanelCollapsed,
      toolPropsBarCollapsed: s.toolPropsBarCollapsed,
      toolbarTools: s.toolbarItems,
      toolbarHidden: ALL_TOOLBAR_ITEMS.filter((id) => !s.toolbarItems.includes(id)),
      defaultPaper: s.defaultPaper,
      pinnedBarOpen: s.pinnedBarOpen,
    };
  },

  /**
   * Swap the entire workspace (restore from a backup). History is dropped on
   * purpose: undo stacks describe elements that no longer exist, and replaying
   * them over restored data would corrupt it.
   */
  replaceWorkspace: (snapshot) => {
    const activeBoard =
      snapshot.boards.find((b) => b.id === snapshot.activeBoardId) || snapshot.boards[0];
    set({
      folders: snapshot.folders,
      boards: snapshot.boards,
      activeBoardId: activeBoard ? activeBoard.id : null,
      activeFolderId: snapshot.activeFolderId ?? null,
      customLinkTypes: snapshot.customLinkTypes ?? [],
      pinnedPens: snapshot.pinnedPens ?? [],
      pinnedBarPos: snapshot.pinnedBarPos ?? null,
      camera: activeBoard?.camera ? { ...activeBoard.camera } : { ...DEFAULT_CAMERA },
      selectedIds: [],
      editingId: null,
      history: { past: [], future: [] },
    });
    get().saveNow();
  },

  /** Fold a remote workspace in per board (see mergeWorkspaces for the rules). */
  mergeWorkspace: (remote) => {
    const { merged, report } = mergeWorkspaces(get().getWorkspaceSnapshot(), remote);
    get().replaceWorkspace(merged);
    return report;
  },
}));

export function useActiveBoard(): Board | null {
  return useWhiteboard((s) => {
    const board = s.boards.find((b) => b.id === s.activeBoardId);
    return board ?? null;
  });
}

export function useActiveElements(): WhiteboardElement[] {
  return useWhiteboard((s) => {
    const board = s.boards.find((b) => b.id === s.activeBoardId);
    return getBoardElements(board);
  });
}

// Editing ends in many places - Done, tapping away, switching tools, turning
// the page, switching board, deleting - and a dozen of them set `editingId`
// directly. Hooking the TRANSITION catches every one, where patching each
// caller would miss the next one someone adds. The discard's own `set` sees
// the previous editingId already null, so this cannot loop.
useWhiteboard.subscribe((state, prev) => {
  if (prev.editingId && prev.editingId !== state.editingId && prev.activeBoardId) {
    state.discardAbandonedText(prev.editingId, prev.activeBoardId);
  }
});

if (typeof window !== "undefined") {
  // Debug handle for the dev server only - a release build must not hand
  // the whole store to anything running in the page.
  if (process.env.NODE_ENV !== "production") {
    (window as unknown as Record<string, unknown>).__wbStore = useWhiteboard;
  }
  const flushAll = () => {
    // Best-effort by necessity: IndexedDB writes are async and the page may
    // die mid-write. The 500 ms debounced autosave bounds the exposure, and
    // visibilitychange/pagehide below fire while the page can still finish.
    flushSave(() => useWhiteboard.getState().getPersistedState());
    flushHistorySave(() => persistableHistory(useWhiteboard.getState()));
  };
  window.addEventListener("beforeunload", flushAll);
  if (typeof document !== "undefined" && typeof document.addEventListener === "function") {
    // Mobile apps are backgrounded far more often than unloaded — and
    // beforeunload is unreliable there. Flushing on hide catches the
    // app-switch-to-WhatsApp case while writes can still complete.
    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "hidden") flushAll();
    });
  }
  window.addEventListener("pagehide", flushAll);

  // Multi-tab: the workspace save stamps a tiny localStorage heartbeat, so a
  // write from another tab still surfaces here even though the boards
  // themselves live in IndexedDB (which fires no cross-tab events).
  watchExternalSaves(() => {
    window.dispatchEvent(new CustomEvent("wb:external-change"));
  });
}
