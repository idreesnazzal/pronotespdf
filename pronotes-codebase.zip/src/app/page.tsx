"use client";

import React, { useEffect, useState } from "react";
import { WhiteboardApp } from "@/components/whiteboard/WhiteboardApp";

export default function Home() {
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted) {
    return (
      <div className="w-screen h-screen flex items-center justify-center bg-background">
        <div className="text-muted-foreground text-sm font-medium animate-pulse">Loading whiteboard…</div>
      </div>
    );
  }

  return <WhiteboardApp />;
}

