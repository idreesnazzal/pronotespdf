"use client";

import { useRef } from "react";

/**
 * Long-press = the touch equivalent of double-click.
 *
 * Some tool options are reachable on desktop by DOUBLE-CLICKING the tool
 * button, which is a mouse gesture: on the Android build a double tap is not
 * reliably delivered as `dblclick` to a button, so on the tablet there would
 * be no way to reach them at all. Long-press is what mobile users already
 * expect for "more options", and it costs the mouse path nothing (mouse
 * presses never start the timer).
 */
export function useLongPress(onLongPress: () => void, ms = 450) {
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const firedRef = useRef(false);
  const startRef = useRef<{ x: number; y: number } | null>(null);

  const clear = () => {
    if (timer.current) clearTimeout(timer.current);
    timer.current = null;
  };

  return {
    /** True when the press already opened the panel, so the click is a no-op. */
    firedRef,
    handlers: {
      onPointerDown: (e: React.PointerEvent) => {
        // Mouse users have double-click; a long mouse press should not steal
        // an ordinary click-and-hold.
        if (e.pointerType === "mouse") return;
        firedRef.current = false;
        clear();
        startRef.current = { x: e.clientX, y: e.clientY };
        timer.current = setTimeout(() => {
          firedRef.current = true;
          onLongPress();
        }, ms);
      },
      // A press that travels is a swipe (the tool bar scrolls), not a hold.
      onPointerMove: (e: React.PointerEvent) => {
        const s = startRef.current;
        if (timer.current && s && Math.hypot(e.clientX - s.x, e.clientY - s.y) > 10) clear();
      },
      onPointerUp: clear,
      onPointerLeave: clear,
      onPointerCancel: clear,
    },
  };
}
