/**
 * Keyboard combo predicates.
 *
 * These live outside the component so they can be unit-tested. They match on
 * `event.code` (the PHYSICAL key) rather than `event.key` (the produced
 * character), because `event.key` carries the shifted/caps form:
 *
 *   Ctrl+Shift+Z  -> event.key === "Z"   (uppercase!)
 *   Ctrl+Z + CapsLock -> event.key === "Z"
 *
 * so a check for `event.key === "z"` silently misses both. `event.code` is
 * also layout-stable, which matters for non-QWERTY keyboards.
 */

export interface ComboEvent {
  code: string;
  ctrlKey: boolean;
  metaKey: boolean;
  shiftKey: boolean;
}

const withModifier = (e: ComboEvent) => e.ctrlKey || e.metaKey;

/** Ctrl/Cmd + Z (without Shift) — step back. */
export function isUndoCombo(e: ComboEvent): boolean {
  return withModifier(e) && e.code === "KeyZ" && !e.shiftKey;
}

/** Ctrl/Cmd + Y, or Ctrl/Cmd + Shift + Z — step forward again. */
export function isRedoCombo(e: ComboEvent): boolean {
  return withModifier(e) && (e.code === "KeyY" || (e.code === "KeyZ" && e.shiftKey));
}
