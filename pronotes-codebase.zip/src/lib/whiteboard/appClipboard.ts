/**
 * ProNotes' own clipboard for pictures
 * ====================================
 * "Copy" on a capture has to work, and inside the Android app the system
 * clipboard often will not take a picture: the WebView refuses
 * `navigator.clipboard.write` for images (NotAllowedError), and the Capacitor
 * clipboard plugin pastes an image as a long line of text. There is no honest
 * way to put a PNG on the Android clipboard from here.
 *
 * So every copy lands in two places: the system clipboard when it allows it
 * (desktop browsers, Electron), and always this in-memory slot. Pasting inside
 * ProNotes - Ctrl+V on the canvas, or "Paste" in the Add-a-picture sheet -
 * falls back to this slot when the system clipboard has no picture, which
 * means a copy made here can always be pasted here.
 *
 * Memory only, on purpose: a clipboard that survived a restart would paste
 * something you copied last week.
 */

export interface AppClipImage {
  dataUrl: string;
  /** Pixel size of the picture. */
  width: number;
  height: number;
  /** The size it had on the page, in world units, so a paste lands 1:1. */
  worldSize?: { width: number; height: number };
  /** True when the system clipboard accepted it as well. */
  systemCopied: boolean;
  at: number;
}

let slot: AppClipImage | null = null;

// Anything copied since (text from a PDF, a note, a text box) is newer than
// our picture: a later paste must not bring the old capture back.
if (typeof document !== "undefined") {
  document.addEventListener("copy", () => {
    slot = null;
  }, true);
  document.addEventListener("cut", () => {
    slot = null;
  }, true);
}

export function putAppClipImage(clip: Omit<AppClipImage, "at">): void {
  slot = { ...clip, at: Date.now() };
}

export function getAppClipImage(): AppClipImage | null {
  return slot;
}

export function clearAppClip(): void {
  slot = null;
}

/**
 * Puts a PNG on the system clipboard. True only when the platform says it
 * did - the caller tells the user what really happened.
 */
export async function writeImageToSystemClipboard(blob: Blob): Promise<boolean> {
  try {
    if (
      typeof navigator === "undefined" ||
      !navigator.clipboard ||
      typeof navigator.clipboard.write !== "function" ||
      typeof ClipboardItem === "undefined"
    ) {
      return false;
    }
    const png = blob.type === "image/png" ? blob : new Blob([blob], { type: "image/png" });
    await navigator.clipboard.write([new ClipboardItem({ "image/png": png })]);
    return true;
  } catch (err) {
    console.warn("[clipboard] The system clipboard refused the picture.", err);
    return false;
  }
}

/**
 * Whether a paste that found no picture on the system clipboard should use
 * ours instead: only when our last copy did NOT reach the system clipboard.
 * If it did, the system clipboard is the truth - something copied elsewhere
 * since then must not be overridden by an older capture.
 */
export function appClipForPaste(): AppClipImage | null {
  return slot && !slot.systemCopied ? slot : null;
}
