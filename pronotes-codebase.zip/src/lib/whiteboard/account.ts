/**
 * Accounts & cloud sync (Supabase)
 * =================================
 * Self-service sign-up: anyone can create their own account with an email and
 * password — nobody has to be added by hand. Each account gets exactly one
 * workspace row, and Postgres row-level security makes it impossible for one
 * account to read another's, even with the public key in hand.
 *
 * Email + password is deliberate rather than OAuth: this app also ships as an
 * Android APK, and inside a WebView an OAuth redirect round-trip is fragile,
 * while an email/password call is a plain HTTPS request that just works.
 *
 * Not configured? Everything here reports "unavailable" and the app keeps
 * working offline with local storage plus backup files.
 */

import { createClient, type SupabaseClient, type User } from "@supabase/supabase-js";
import { parseWorkspace, serializeWorkspace, type WorkspaceSnapshot } from "./workspace";

const TABLE = "workspaces";

let client: SupabaseClient | null = null;

export function getConfig(): { url: string; anonKey: string } | null {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL?.trim();
  const anonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY?.trim();
  if (!url || !anonKey) return null;
  return { url, anonKey };
}

export function isConfigured(): boolean {
  return !!getConfig();
}

function getClient(): SupabaseClient {
  const cfg = getConfig();
  if (!cfg) throw new Error("Accounts are not set up in this build.");
  if (!client) {
    client = createClient(cfg.url, cfg.anonKey, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
        // No OAuth redirects are used, so there is nothing to detect in the URL;
        // leaving this on makes the APK's file:// origin log spurious warnings.
        detectSessionInUrl: false,
      },
    });
  }
  return client;
}

export interface AccountUser {
  id: string;
  email: string | null;
  /** False until the confirmation link is clicked, when confirmation is on. */
  confirmed: boolean;
}

function toAccountUser(user: User | null): AccountUser | null {
  if (!user) return null;
  return {
    id: user.id,
    email: user.email ?? null,
    confirmed: !!user.email_confirmed_at || !!user.confirmed_at,
  };
}

export async function getCurrentUser(): Promise<AccountUser | null> {
  if (!isConfigured()) return null;
  const { data } = await getClient().auth.getUser();
  return toAccountUser(data.user ?? null);
}

export function onAuthChange(cb: (user: AccountUser | null) => void): () => void {
  if (!isConfigured()) return () => {};
  const { data } = getClient().auth.onAuthStateChange((_event, session) => {
    cb(toAccountUser(session?.user ?? null));
  });
  return () => data.subscription.unsubscribe();
}

export interface SignUpResult {
  user: AccountUser | null;
  /** True when Supabase requires the emailed confirmation link first. */
  needsEmailConfirmation: boolean;
}

export async function signUp(email: string, password: string): Promise<SignUpResult> {
  const { data, error } = await getClient().auth.signUp({ email, password });
  if (error) throw new Error(friendlyAuthError(error.message));
  // Supabase returns a user with no session when confirmation is required.
  return {
    user: toAccountUser(data.user),
    needsEmailConfirmation: !data.session,
  };
}

export async function signIn(email: string, password: string): Promise<AccountUser | null> {
  const { data, error } = await getClient().auth.signInWithPassword({ email, password });
  if (error) throw new Error(friendlyAuthError(error.message));
  return toAccountUser(data.user);
}

export async function sendPasswordReset(email: string): Promise<void> {
  const { error } = await getClient().auth.resetPasswordForEmail(email);
  if (error) throw new Error(friendlyAuthError(error.message));
}

export async function signOut(): Promise<void> {
  await getClient().auth.signOut();
}

/** Supabase's raw messages are terse; make the common ones actionable. */
function friendlyAuthError(message: string): string {
  const m = message.toLowerCase();
  if (m.includes("invalid login credentials")) return "Wrong email or password.";
  if (m.includes("already registered") || m.includes("already been registered")) {
    return "That email already has an account — sign in instead.";
  }
  if (m.includes("password") && m.includes("6")) {
    return "Password must be at least 6 characters.";
  }
  if (m.includes("email not confirmed")) {
    return "Check your inbox and click the confirmation link first.";
  }
  if (m.includes("rate limit") || m.includes("too many")) {
    return "Too many attempts — wait a minute and try again.";
  }
  return message;
}

// ---------------------------------------------------------------------------
// Workspace row
// ---------------------------------------------------------------------------

export interface RemoteRow {
  snapshot: WorkspaceSnapshot;
  updatedAt: number;
}

/** The signed-in account's workspace, or null if they have never synced. */
export async function pullWorkspace(): Promise<RemoteRow | null> {
  const supa = getClient();
  const { data: userData } = await supa.auth.getUser();
  const uid = userData.user?.id;
  if (!uid) throw new Error("Not signed in.");

  const { data, error } = await supa
    .from(TABLE)
    .select("doc, updated_at")
    .eq("user_id", uid)
    .maybeSingle();

  if (error) throw new Error(`Could not load your workspace: ${error.message}`);
  if (!data?.doc) return null;

  // The row is stored as the same portable document as a backup file, so it
  // goes through the identical validation — a malformed row cannot brick the app.
  const snapshot = parseWorkspace(
    typeof data.doc === "string" ? data.doc : JSON.stringify(data.doc)
  );
  return { snapshot, updatedAt: Date.parse(data.updated_at) || 0 };
}

export async function pushWorkspace(
  snapshot: WorkspaceSnapshot,
  deviceLabel?: string
): Promise<void> {
  const supa = getClient();
  const { data: userData } = await supa.auth.getUser();
  const uid = userData.user?.id;
  if (!uid) throw new Error("Not signed in.");

  const { error } = await supa.from(TABLE).upsert(
    {
      user_id: uid,
      doc: JSON.parse(serializeWorkspace(snapshot, deviceLabel)),
      updated_at: new Date().toISOString(),
    },
    { onConflict: "user_id" }
  );
  if (error) throw new Error(`Could not save your workspace: ${error.message}`);
}
