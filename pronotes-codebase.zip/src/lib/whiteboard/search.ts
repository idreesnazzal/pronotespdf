/**
 * Search: what is searchable, what is in scope, and in what order it is shown.
 * ==========================================================================
 * Pure (no React, no store) so the ranking can be unit-tested.
 *
 * What is searchable - and nothing else, so the panel can say so honestly:
 *  - note (board / notebook) names, folder names and note tags
 *  - text boxes, sticky notes and connection labels, on every notebook page
 *  - document text of PDF pages, supplied separately by pdfTextIndex.ts
 * Handwriting is ink with no recognition behind it, shapes carry no text and
 * pictures carry no name, so none of those can be found.
 *
 * Ranking in the wider scopes is by NEARNESS first: the note you are in, then
 * its folder, then the folders around it (sub-folders and the parent chain),
 * then everything else. Someone searching "lecture 3" from inside Physics means
 * Physics' lecture 3, not the one in an old course that happens to match
 * better. Within a group, match quality then recency decide.
 */

import type { Board, Folder, WhiteboardElement } from "./types";
import { getBoardElements, getPages, isNotebook } from "./notebook";
import { getElementBounds, type BoundingBox } from "./geometry";

export type SearchScope = "note" | "folder" | "everywhere";

export type SearchKind = "board" | "folder" | "tag" | "text" | "sticky" | "connection" | "pdf";

/** How close a result is to where you are. Also the group it is shown under. */
export type Nearness = "note" | "folder" | "near" | "elsewhere";

export const NEARNESS_ORDER: Nearness[] = ["note", "folder", "near", "elsewhere"];

/** One searchable string. */
export interface SearchEntry {
  /** Stable across rebuilds, so a highlighted row survives a re-index. */
  id: string;
  kind: SearchKind;
  /** Plain, single-line display text (markdown markers removed). */
  text: string;
  /** `foldText(text)` - what queries are matched against. */
  folded: string;
  boardId: string | null;
  /** The folder it lives in; for a folder entry, the folder itself. */
  folderId: string | null;
  elementId?: string;
  pageId?: string;
  /** 0-based page index in a notebook. */
  pageIndex?: number;
  /** Document text: which match on its page this is (0 = the first). */
  ordinal?: number;
  /** Position on its page, for find-in-page order (top to bottom). */
  y?: number;
  x?: number;
  updatedAt: number;
}

export interface SearchHit {
  entry: SearchEntry;
  score: number;
  nearness: Nearness;
  /** Match ranges in `entry.folded` coordinates. */
  ranges: Array<[number, number]>;
  /** Ranges already in display coordinates, when the source supplied them. */
  displayRanges?: Array<[number, number]>;
}

export interface SearchContext {
  activeBoardId: string | null;
  /**
   * The folder you are "in": the open note's folder, or the sidebar's folder
   * when no note is open. Null is the top level.
   */
  folderId: string | null;
  folders: Folder[];
}

// ---------------------------------------------------------------------------
// Text normalisation
// ---------------------------------------------------------------------------

const COMBINING = /\p{M}/u;
const WORD_CHAR = /[\p{L}\p{N}_]/u;

/**
 * Case- and accent-insensitive form of a string. Combining marks (accents,
 * Hebrew niqqud and cantillation) are dropped, so "שָׁלוֹם" is found by "שלום"
 * and "café" by "cafe". Returns the map back to the original indices so a
 * match can be highlighted in the text as written.
 */
export function foldWithMap(s: string): { folded: string; map: number[] | null } {
  // Fast path: plain ASCII keeps its length, so no map is needed.
  if (!/[^\x00-\x7f]/.test(s)) return { folded: s.toLowerCase(), map: null };
  let folded = "";
  const map: number[] = [];
  for (let i = 0; i < s.length; i++) {
    const code = s.charCodeAt(i);
    if (code < 0x80) {
      folded += s[i].toLowerCase();
      map.push(i);
      continue;
    }
    // Keep a surrogate pair together (emoji etc.); it has no case or accent.
    if (code >= 0xd800 && code <= 0xdbff && i + 1 < s.length) {
      folded += s[i] + s[i + 1];
      map.push(i, i + 1);
      i++;
      continue;
    }
    const ch = s[i];
    if (COMBINING.test(ch)) continue;
    let f = ch.normalize("NFD").replace(/\p{M}/gu, "").toLowerCase();
    // A few letters lowercase to two characters (e.g. "İ"); keep the length so
    // the map stays one-to-one.
    if (f.length !== 1) f = ch.toLowerCase().length === 1 ? ch.toLowerCase() : ch;
    folded += f;
    map.push(i);
  }
  return { folded, map };
}

export function foldText(s: string): string {
  return foldWithMap(s).folded;
}

/**
 * Text boxes and sticky notes hold markdown. Search the text as the canvas
 * SHOWS it - "**Exam** date" must be found by "exam date" - and on one line,
 * because a result row is one line.
 */
export function plainText(markdown: string): string {
  return markdown
    .replace(/<\/?u>/gi, "")
    .replace(/^\s{0,3}#{1,6}\s+/gm, "")
    .replace(/^\s*[-*]\s*\[[ xX]\]\s*/gm, "")
    .replace(/^\s*[-*+]\s+/gm, "")
    .replace(/^\s*>\s?/gm, "")
    .replace(/\*\*|__|~~|==|`/g, "")
    .replace(/\[\[([^\]|]*)(?:\|([^\]]*))?\]\]/g, (_, target: string, alias?: string) => alias || target)
    .replace(/\s+/g, " ")
    .trim();
}

// ---------------------------------------------------------------------------
// Index
// ---------------------------------------------------------------------------

function entry(partial: Omit<SearchEntry, "folded">): SearchEntry {
  return { ...partial, folded: foldText(partial.text) };
}

/** The searchable text of one element, or null for ink, shapes and pictures. */
function elementText(el: WhiteboardElement): { kind: SearchKind; text: string } | null {
  if (el.type === "text" || el.type === "sticky") {
    const text = plainText(typeof el.text === "string" ? el.text : "");
    return text ? { kind: el.type, text } : null;
  }
  if (el.type === "connection") {
    const text = typeof el.label === "string" ? el.label.replace(/\s+/g, " ").trim() : "";
    return text ? { kind: "connection", text } : null;
  }
  return null;
}

function elementEntries(
  board: Board,
  elements: WhiteboardElement[],
  page?: { id: string; index: number }
): SearchEntry[] {
  const out: SearchEntry[] = [];
  for (const el of elements ?? []) {
    const t = elementText(el);
    if (!t) continue;
    const b = focusBounds(el, elements);
    out.push(
      entry({
        id: `${board.id}:${el.id}`,
        kind: t.kind,
        text: t.text,
        boardId: board.id,
        folderId: board.folderId ?? null,
        elementId: el.id,
        pageId: page?.id,
        pageIndex: page?.index,
        x: Number.isFinite(b.x) ? b.x : 0,
        y: Number.isFinite(b.y) ? b.y : 0,
        updatedAt: el.updatedAt || board.updatedAt || 0,
      })
    );
  }
  return out;
}

// Re-indexing only what changed. Boards, pages and element arrays are replaced
// (never mutated) on every edit, so an unchanged one keeps its identity and
// its cached entries - with the panel open, a stroke on one page re-reads that
// page, not 900 of them.
const pageCache = new WeakMap<object, SearchEntry[]>();
const boardCache = new WeakMap<Board, SearchEntry[]>();

function boardEntries(board: Board): SearchEntry[] {
  const cached = boardCache.get(board);
  if (cached) return cached;
  const out: SearchEntry[] = [];
  const recency = board.accessedAt || board.updatedAt || board.createdAt || 0;
  out.push(
    entry({
      id: `board:${board.id}`,
      kind: "board",
      text: board.name || "Untitled",
      boardId: board.id,
      folderId: board.folderId ?? null,
      updatedAt: recency,
    })
  );
  for (const tag of new Set(board.tags ?? [])) {
    if (typeof tag !== "string" || !tag.trim()) continue;
    out.push(
      entry({
        id: `tag:${board.id}:${tag}`,
        kind: "tag",
        text: `#${tag.replace(/^#/, "")}`,
        boardId: board.id,
        folderId: board.folderId ?? null,
        updatedAt: recency,
      })
    );
  }
  if (isNotebook(board)) {
    getPages(board).forEach((page, index) => {
      // The cache key is the page object, but the entries carry the index -
      // so a page moved to a new position must not reuse them.
      const key = page.elements ?? page;
      let pageEntries = pageCache.get(key);
      if (!pageEntries || pageEntries.some((e) => e.pageIndex !== index || e.folderId !== (board.folderId ?? null) || e.pageId !== page.id)) {
        pageEntries = elementEntries(board, page.elements ?? [], { id: page.id, index });
        pageCache.set(key, pageEntries);
      }
      out.push(...pageEntries);
    });
  } else {
    out.push(...elementEntries(board, getBoardElements(board)));
  }
  boardCache.set(board, out);
  return out;
}

export function buildSearchIndex(boards: Board[], folders: Folder[]): SearchEntry[] {
  const out: SearchEntry[] = [];
  for (const f of folders) {
    out.push(
      entry({
        id: `folder:${f.id}`,
        kind: "folder",
        text: f.name || "Untitled folder",
        boardId: null,
        folderId: f.id,
        updatedAt: f.createdAt || 0,
      })
    );
  }
  for (const b of boards) out.push(...boardEntries(b));
  return out;
}

/**
 * Where to point the camera for an element. A connection's own x/y is not
 * where it is drawn - it runs between its two ends - so aim at the middle of
 * the line, which is where its label sits.
 */
export function focusBounds(el: WhiteboardElement, siblings: WhiteboardElement[]): BoundingBox {
  if (el.type === "connection") {
    const a = siblings.find((s) => s.id === el.source?.elementId);
    const b = siblings.find((s) => s.id === el.target?.elementId);
    if (a && b) {
      const ba = getElementBounds(a);
      const bb = getElementBounds(b);
      const cx = (ba.x + ba.width / 2 + bb.x + bb.width / 2) / 2;
      const cy = (ba.y + ba.height / 2 + bb.y + bb.height / 2) / 2;
      return { x: cx - 60, y: cy - 16, width: 120, height: 32 };
    }
  }
  return getElementBounds(el);
}

// ---------------------------------------------------------------------------
// Folders
// ---------------------------------------------------------------------------

/** Every folder below `folderId`, at any depth. Cycle-safe. */
export function descendantFolderIds(folderId: string | null, folders: Folder[]): Set<string> {
  const out = new Set<string>();
  const children = new Map<string | null, string[]>();
  for (const f of folders) {
    const list = children.get(f.parentId ?? null) ?? [];
    list.push(f.id);
    children.set(f.parentId ?? null, list);
  }
  const stack = [...(children.get(folderId) ?? [])];
  while (stack.length) {
    const id = stack.pop() as string;
    if (out.has(id) || id === folderId) continue;
    out.add(id);
    stack.push(...(children.get(id) ?? []));
  }
  return out;
}

/** The folders above `folderId`, nearest first. Cycle-safe. */
export function ancestorFolderIds(folderId: string | null, folders: Folder[]): string[] {
  const byId = new Map(folders.map((f) => [f.id, f]));
  const out: string[] = [];
  const seen = new Set<string>(folderId ? [folderId] : []);
  let cursor = folderId ? byId.get(folderId)?.parentId ?? null : null;
  while (cursor && !seen.has(cursor)) {
    seen.add(cursor);
    out.push(cursor);
    cursor = byId.get(cursor)?.parentId ?? null;
  }
  return out;
}

/** Folder names from the top down to `folderId`, e.g. ["Uni", "Physics"]. */
export function folderPath(folderId: string | null, folders: Folder[]): string[] {
  if (!folderId) return [];
  const byId = new Map(folders.map((f) => [f.id, f]));
  const own = byId.get(folderId);
  if (!own) return [];
  return [
    ...ancestorFolderIds(folderId, folders)
      .reverse()
      .map((id) => byId.get(id)?.name ?? ""),
    own.name,
  ];
}

// ---------------------------------------------------------------------------
// Scope and nearness
// ---------------------------------------------------------------------------

const CONTENT_KINDS: ReadonlySet<SearchKind> = new Set(["text", "sticky", "connection", "pdf"]);

/**
 * Precomputed folder relations for one search, so a 20 000-entry scan does
 * not walk the folder tree per entry.
 */
export interface ScopeInfo {
  ctx: SearchContext;
  below: Set<string>;
  above: Set<string>;
}

export function scopeInfo(ctx: SearchContext): ScopeInfo {
  return {
    ctx,
    below: descendantFolderIds(ctx.folderId, ctx.folders),
    above: new Set(ancestorFolderIds(ctx.folderId, ctx.folders)),
  };
}

export function nearnessOf(e: SearchEntry, info: ScopeInfo): Nearness {
  const { ctx } = info;
  if (e.kind !== "folder" && ctx.activeBoardId && e.boardId === ctx.activeBoardId) return "note";
  if (e.folderId === ctx.folderId) return "folder";
  // At the top level every folder is "below", which would make everything
  // near; there, only the top level itself counts as close.
  if (ctx.folderId === null) return "elsewhere";
  if (e.folderId && (info.below.has(e.folderId) || info.above.has(e.folderId))) return "near";
  return "elsewhere";
}

export function inScope(e: SearchEntry, scope: SearchScope, info: ScopeInfo): boolean {
  const { ctx } = info;
  if (scope === "everywhere") return true;
  if (scope === "note") {
    // Find-in-note: the note's content. Its own name and tags are not "in" it.
    return !!ctx.activeBoardId && e.boardId === ctx.activeBoardId && CONTENT_KINDS.has(e.kind);
  }
  // This folder, sub-folders included - the way Finder and Explorer search a
  // folder. The folder's own name is the scope, not a result.
  if (e.kind === "folder") return e.folderId !== null && info.below.has(e.folderId) && ctx.folderId !== null;
  if (e.folderId === ctx.folderId) return true;
  // The top level has everything below it; "this folder" there means the
  // loose notes at the top, otherwise it would just be "Everywhere".
  return ctx.folderId !== null && e.folderId !== null && info.below.has(e.folderId);
}

/** Whether a board's content is in scope - used to decide whose PDF text to search. */
export function boardInScope(board: Board, scope: SearchScope, info: ScopeInfo): boolean {
  return inScope(
    { id: "", kind: "pdf", text: "", folded: "", boardId: board.id, folderId: board.folderId ?? null, updatedAt: 0 },
    scope,
    info
  );
}

// ---------------------------------------------------------------------------
// Matching
// ---------------------------------------------------------------------------

/** Folded query words. Quotes are ignored rather than half-supported. */
export function parseQuery(query: string): string[] {
  return foldText(query.replace(/["“”]/g, " "))
    .split(/\s+/)
    .filter(Boolean);
}

/** Match strength of one occurrence: 3 whole word, 2 word start, 1 inside a word. */
function occurrenceQuality(text: string, at: number, len: number): number {
  const startOk = at === 0 || !WORD_CHAR.test(text[at - 1]);
  if (!startOk) return 1;
  const end = at + len;
  const endOk = end >= text.length || !WORD_CHAR.test(text[end]);
  return endOk ? 3 : 2;
}

/** The best occurrence of `term` in `text`, or null. */
function bestOccurrence(text: string, term: string): { at: number; quality: number } | null {
  let best: { at: number; quality: number } | null = null;
  let from = 0;
  // A handful of occurrences is enough to find a whole-word one; scanning
  // every "e" in a long note would cost more than it could change.
  for (let n = 0; n < 24; n++) {
    const at = text.indexOf(term, from);
    if (at === -1) break;
    const quality = occurrenceQuality(text, at, term.length);
    if (!best || quality > best.quality) best = { at, quality };
    if (quality === 3) break;
    from = at + 1;
  }
  return best;
}

/** Title-like results outrank content: finding a note by its name is the usual intent. */
const KIND_WEIGHT: Record<SearchKind, number> = {
  board: 20,
  folder: 20,
  tag: 10,
  text: 0,
  sticky: 0,
  connection: 0,
  pdf: 0,
};

/**
 * Scores an entry against the query words. Every word must occur (AND); the
 * weakest word decides the quality, so "exam physics" is not ranked as a
 * whole-word hit because "exam" was one. The whole phrase occurring in order,
 * and the text being exactly the query, both add a little on top.
 */
export function matchEntry(
  e: SearchEntry,
  terms: string[]
): { score: number; ranges: Array<[number, number]> } | null {
  if (terms.length === 0) return null;
  const text = e.folded;
  const phrase = terms.join(" ");
  const ranges: Array<[number, number]> = [];
  let quality = 3;

  const whole = terms.length > 1 ? bestOccurrence(text, phrase) : null;
  if (whole) {
    quality = whole.quality;
    ranges.push([whole.at, phrase.length]);
  } else {
    for (const term of terms) {
      const occ = bestOccurrence(text, term);
      if (!occ) return null;
      quality = Math.min(quality, occ.quality);
      ranges.push([occ.at, term.length]);
    }
    ranges.sort((a, b) => a[0] - b[0]);
  }

  let score = KIND_WEIGHT[e.kind] + quality;
  if (whole) score += 0.5;
  if (text === phrase || (e.kind === "tag" && text === `#${phrase.replace(/^#/, "")}`)) score += 2;
  return { score, ranges };
}

// ---------------------------------------------------------------------------
// Search and grouping
// ---------------------------------------------------------------------------

function documentOrder(a: SearchEntry, b: SearchEntry): number {
  return (
    (a.pageIndex ?? 0) - (b.pageIndex ?? 0) ||
    (a.y ?? 0) - (b.y ?? 0) ||
    (a.x ?? 0) - (b.x ?? 0)
  );
}

/**
 * All hits for `query` in `scope`, in display order.
 *
 * "This note" is find-in-page: top to bottom, page by page, the order you
 * would step through. The wider scopes go nearest-first, then best match,
 * then most recently touched.
 */
export function searchEntries(
  entries: SearchEntry[],
  query: string,
  scope: SearchScope,
  ctx: SearchContext
): SearchHit[] {
  const terms = parseQuery(query);
  if (terms.length === 0) return [];
  const info = scopeInfo(ctx);
  const hits: SearchHit[] = [];
  for (const e of entries) {
    if (!inScope(e, scope, info)) continue;
    const m = matchEntry(e, terms);
    if (!m) continue;
    hits.push({ entry: e, score: m.score, ranges: m.ranges, nearness: nearnessOf(e, info) });
  }
  return sortHits(hits, scope);
}

export function sortHits(hits: SearchHit[], scope: SearchScope): SearchHit[] {
  if (scope === "note") return hits.sort((a, b) => documentOrder(a.entry, b.entry));
  const rank = (n: Nearness) => NEARNESS_ORDER.indexOf(n);
  return hits.sort(
    (a, b) =>
      rank(a.nearness) - rank(b.nearness) ||
      b.score - a.score ||
      b.entry.updatedAt - a.entry.updatedAt ||
      documentOrder(a.entry, b.entry)
  );
}

export interface SearchGroup {
  id: Nearness;
  label: string;
  hits: SearchHit[];
}

/** Group headers, so the nearest-first order explains itself. */
export function groupLabel(id: Nearness, scope: SearchScope, ctx: SearchContext): string {
  const folderName = ctx.folderId
    ? ctx.folders.find((f) => f.id === ctx.folderId)?.name || "this folder"
    : "Top level";
  switch (id) {
    case "note":
      return "In this note";
    case "folder":
      return ctx.folderId ? `In ${folderName}` : "Top level";
    case "near":
      return scope === "folder" ? "In sub-folders" : "Sub-folders & parent";
    default:
      return "Elsewhere";
  }
}

/** Splits sorted hits into their nearness groups, keeping the order. */
export function groupHits(hits: SearchHit[], scope: SearchScope, ctx: SearchContext): SearchGroup[] {
  const groups = new Map<Nearness, SearchHit[]>();
  for (const h of hits) {
    const list = groups.get(h.nearness) ?? [];
    list.push(h);
    groups.set(h.nearness, list);
  }
  return NEARNESS_ORDER.filter((id) => groups.has(id)).map((id) => ({
    id,
    label: groupLabel(id, scope, ctx),
    hits: groups.get(id) as SearchHit[],
  }));
}

/** Whether opening a hit lands on a spot in a note (and so can be stepped through). */
export function isLocatable(h: SearchHit): boolean {
  return CONTENT_KINDS.has(h.entry.kind);
}

// ---------------------------------------------------------------------------
// Snippets
// ---------------------------------------------------------------------------

export interface Snippet {
  text: string;
  /** Highlight ranges in `text`. */
  ranges: Array<[number, number]>;
}

/**
 * A readable window of the text around the first match, with the matches
 * mapped back from folded to written positions.
 */
export function makeSnippet(hit: SearchHit, width = 96): Snippet {
  const text = hit.entry.text;
  let ranges = hit.displayRanges;
  if (!ranges) {
    const { map } = foldWithMap(text);
    ranges = hit.ranges.map(([at, len]) => {
      if (!map) return [at, len] as [number, number];
      const start = map[at] ?? text.length;
      const lastFolded = Math.min(at + len - 1, map.length - 1);
      const end = (map[lastFolded] ?? start) + 1;
      return [start, Math.max(1, end - start)] as [number, number];
    });
  }
  if (text.length <= width) return { text, ranges };

  const first = ranges[0]?.[0] ?? 0;
  // Some context before the match, but mostly after it: people read on.
  let start = Math.max(0, first - Math.floor(width * 0.3));
  // Start on a word boundary so the snippet does not open mid-word.
  if (start > 0) {
    const space = text.indexOf(" ", start);
    if (space !== -1 && space < first) start = space + 1;
  }
  const end = Math.min(text.length, start + width);
  const lead = start > 0 ? "…" : "";
  const tail = end < text.length ? "…" : "";
  const shift = lead.length - start;
  return {
    text: lead + text.slice(start, end) + tail,
    ranges: ranges
      .filter(([at]) => at >= start && at < end)
      .map(([at, len]) => [at + shift, Math.min(len, end - at)] as [number, number]),
  };
}

/** Splits text into plain and highlighted parts for rendering. */
export function highlightParts(snippet: Snippet): Array<{ text: string; hit: boolean }> {
  const parts: Array<{ text: string; hit: boolean }> = [];
  const ranges = [...snippet.ranges].sort((a, b) => a[0] - b[0]);
  let pos = 0;
  for (const [at, len] of ranges) {
    if (at < pos) continue; // overlapping ranges: the first one wins
    if (at > pos) parts.push({ text: snippet.text.slice(pos, at), hit: false });
    parts.push({ text: snippet.text.slice(at, at + len), hit: true });
    pos = at + len;
  }
  if (pos < snippet.text.length) parts.push({ text: snippet.text.slice(pos), hit: false });
  return parts;
}

// ---------------------------------------------------------------------------
// Document text (PDF) hits
// ---------------------------------------------------------------------------

/**
 * Turns a PDF text hit into a search hit, so it ranks and groups like any
 * other. The snippet is the text layer's own; its match range is trusted for
 * highlighting, and re-matched only to judge quality (whole word or not).
 */
export function pdfHit(
  board: Board,
  raw: { pageIndex: number; pageId?: string; snippet: string; matchStart: number; matchLength: number; ordinal?: number },
  query: string,
  ordinal: number,
  info: ScopeInfo
): SearchHit {
  const pages = getPages(board);
  const e = entry({
    id: `pdf:${board.id}:${raw.pageIndex}:${ordinal}`,
    kind: "pdf",
    text: raw.snippet.replace(/\s+/g, " "),
    boardId: board.id,
    folderId: board.folderId ?? null,
    pageId: raw.pageId ?? pages[raw.pageIndex]?.id,
    pageIndex: raw.pageIndex,
    ordinal: raw.ordinal,
    // Document text sits under the page's ink and notes: list it first on
    // its page, in reading order.
    y: -1e9 + ordinal,
    x: 0,
    updatedAt: board.updatedAt || 0,
  });
  const m = matchEntry(e, parseQuery(query));
  const start = Math.max(0, Math.min(raw.matchStart, e.text.length));
  return {
    entry: e,
    score: m ? m.score : 1,
    ranges: m ? m.ranges : [[start, raw.matchLength]],
    displayRanges: [[start, Math.max(1, Math.min(raw.matchLength, e.text.length - start))]],
    nearness: nearnessOf(e, info),
  };
}
