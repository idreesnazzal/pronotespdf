/**
 * Page text storage (IndexedDB)
 * =============================
 * The text of imported documents, one record per stored PDF (same id), in a
 * database of its own next to `pronotes-pdfs`.
 *
 * Two kinds of record live here:
 *  - "office": the text of a Word / PowerPoint file, captured while it was
 *    converted. The PDF that file became is pictures only, so this record is
 *    the ONLY copy of its text - it is never thrown away while the PDF lives.
 *  - "pdf": a cache of what pdf.js extracted from a real PDF, filled a page at
 *    a time as pages are looked at or searched. Losing it costs a re-read.
 *
 * Why a sidecar rather than invisible text inside the PDF: jsPDF's built-in
 * fonts cannot encode Hebrew or Arabic, so embedding would mean shipping a
 * Unicode font into every converted file (hundreds of KB each) and trusting
 * pdf.js to read our own positioning back. A record of runs with boxes needs no
 * font, keeps Hebrew exactly as the browser laid it out, and is read with no
 * parsing at all.
 *
 * A separate database (not a second store in `pronotes-pdfs`) so that opening
 * it can never trigger a version upgrade of the PDF store itself.
 */

import type { PageText } from "./pdfText";

const DB_NAME = "pronotes-pdftext";
const DB_VERSION = 1;
const STORE = "docs";

/**
 * Bumped when extraction changes, so cached "pdf" records are re-read. Never
 * affects "office" records: their source is gone and cannot be re-read.
 */
export const PDF_TEXT_VERSION = 1;

export interface StoredDocText {
  /** The id of the PDF in `pronotes-pdfs`. */
  id: string;
  source: "office" | "pdf";
  version: number;
  /** Indexed by page number - 1. `null` = not extracted yet ("pdf" only). */
  pages: Array<PageText | null>;
}

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === "undefined") {
      reject(new Error("No IndexedDB"));
      return;
    }
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE, { keyPath: "id" });
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error ?? new Error("Could not open the text store"));
  });
}

/**
 * One request in its own transaction. Settles when the TRANSACTION does, not
 * the request: a write whose commit then aborts (a full disk) must report
 * failure - for a Word file's text there is no second copy.
 */
function tx<T>(mode: IDBTransactionMode, run: (store: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  return openDb().then(
    (db) =>
      new Promise<T>((resolve, reject) => {
        let result: T;
        const fail = (err: unknown) => {
          db.close();
          reject(err ?? new Error("Text store request failed"));
        };
        let t: IDBTransaction;
        try {
          t = db.transaction(STORE, mode);
        } catch (err) {
          fail(err);
          return;
        }
        const req = run(t.objectStore(STORE));
        req.onsuccess = () => {
          result = req.result;
        };
        t.oncomplete = () => {
          db.close();
          resolve(result);
        };
        t.onabort = () => fail(t.error ?? req.error);
        t.onerror = () => fail(t.error ?? req.error);
      })
  );
}

export function getDocText(id: string): Promise<StoredDocText | undefined> {
  return tx<StoredDocText | undefined>("readonly", (s) => s.get(id));
}

export function putDocText(rec: StoredDocText): Promise<void> {
  return tx("readwrite", (s) => s.put(rec) as unknown as IDBRequest<void>).then(() => undefined);
}

export function deleteDocText(id: string): Promise<void> {
  return tx("readwrite", (s) => s.delete(id) as unknown as IDBRequest<void>).then(() => undefined);
}

/** Drops the text of every document that is no longer stored. */
export async function pruneDocTexts(keepIds: Set<string>): Promise<void> {
  const keys = await tx<IDBValidKey[]>("readonly", (s) => s.getAllKeys());
  for (const k of keys) if (typeof k === "string" && !keepIds.has(k)) await deleteDocText(k);
}

// ---------------------------------------------------------------------------
// Hand-over from the Office converter to the PDF import
// ---------------------------------------------------------------------------

/**
 * The converter returns a plain PDF `File`, and the PDF import that stores it
 * (and chooses its id) knows nothing about Office. The captured text rides
 * along keyed on that File object; the import takes it once it has an id.
 * A WeakMap, so a conversion that is never imported leaves nothing behind.
 */
const pendingOfficeText = new WeakMap<object, PageText[]>();

export function attachOfficeText(file: object, pages: PageText[]) {
  pendingOfficeText.set(file, pages);
}

export function takeOfficeText(file: object): PageText[] | undefined {
  const pages = pendingOfficeText.get(file);
  pendingOfficeText.delete(file);
  return pages;
}
