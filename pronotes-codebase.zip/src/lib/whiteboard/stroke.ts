/**
 * Whiteboard Stroke Rendering (v4.6 — Pixel-Perfect Path & Anti-Wedge Engine)
 * ============================================================================
 * Features:
 * - Mathematical fix for getSvgPathFromStroke: Smoothly connects polygon perimeter
 *   to start point without creating sharp triangular cross-over flap wedges!
 * - Single point dots (periods, letter dots, niqqud, dagesh, i/j dots)
 * - Anti-Hook lift-off filter for touchscreens
 * - Smooth freehand spline with perfect-freehand
 */

import { getStroke, getStrokePoints } from "perfect-freehand";
import type { StrokeElement, PressureCurve } from "./types";
import { PEN_TYPE_PRESETS } from "./types";

export interface StrokeOptions {
  size: number;
  thinning: number;
  smoothing: number;
  streamline: number;
  easing: (t: number) => number;
  start: { cap: boolean; taper: number };
  end: { cap: boolean; taper: number };
  simulatePressure: boolean;
  last: boolean;
}

/**
 * Calibrate raw hardware digitizer pressure (0..1) through a user-selected
 * response curve and dynamic sensitivity range.
 */
export function calibratePressure(
  rawPressure: number,
  sensitivity: number = 50,
  curve: PressureCurve = "standard"
): number {
  if (curve === "off" || sensitivity <= 0) return 0.5;

  let p = Math.max(0.01, Math.min(1.0, rawPressure));

  // Apply response curve
  if (curve === "soft") {
    // Concave: reaches expressive thick ink faster with gentle S Pen touch
    p = Math.pow(p, 0.7);
  } else if (curve === "firm") {
    // Convex: requires deliberate, firm pressure for broad strokes
    p = Math.pow(p, 1.4);
  }

  // Dynamic sensitivity scaling around midpoint 0.5
  // sensitivity = 50 -> scale = 1.0 (exact curve)
  // sensitivity = 100 -> maximum dynamic thickness variation
  // sensitivity = 0 -> completely uniform line
  const scale = sensitivity / 50;
  const delta = (p - 0.5) * scale;
  return Math.max(0.02, Math.min(1.0, 0.5 + delta));
}

export function getStrokeOptionsForStyle(
  style: string,
  baseSize: number,
  isLast = true,
  smoothingLevel: number = 50
): Partial<StrokeOptions> {
  const preset = PEN_TYPE_PRESETS[style as keyof typeof PEN_TYPE_PRESETS] || PEN_TYPE_PRESETS.gel;
  // Line weight is the single most visible difference between writing pens.
  const sizeMultiplier = preset.sizeScale ?? 1;
  const roundCap = preset.cap !== "flat";

  // When smoothingLevel is 50 (default), scale is 1.0 — exactly matches preset defaults.
  // 0% gives raw digitizer input; 100% gives maximum stroke stabilization.
  const scale = Math.max(0, smoothingLevel) / 50;
  const smoothing = Math.min(0.98, Math.max(0.02, preset.smoothing * scale));
  const streamline = Math.min(0.95, Math.max(0.02, preset.streamline * scale));

  return {
    size: baseSize * sizeMultiplier,
    thinning: preset.thinning,
    smoothing,
    streamline,
    simulatePressure: preset.simulatePressure,
    // A flat cap is what gives a marker/highlighter its squared-off chisel end;
    // a round cap is a pen. This is visible at both ends of every stroke.
    start: { cap: roundCap, taper: preset.startTaper },
    end: { cap: roundCap, taper: preset.endTaper },
    last: isLast,
  };
}

/**
 * Re-weight a stroke's per-point pressure to express the pen's character.
 *
 * perfect-freehand only varies width via `pressure` x `thinning`. With a mouse
 * every point arrives at ~0.5, so ANY preset that merely tweaks `thinning`
 * renders identically — which is why the old pen, marker, highlighter and
 * pencil were indistinguishable. These two modifiers give each pen a real,
 * measurable geometry:
 *
 * - **speedResponse** — fast strokes thin out, as a real ballpoint or fountain
 *   pen does. Computed from the distance between consecutive points.
 * - **nibAngle** — a chisel nib is wide across its edge and narrow along it, so
 *   width becomes a function of the DIRECTION of travel. This is what makes a
 *   fountain pen calligraphic instead of merely thin.
 */
export function applyPenDynamics(
  points: Array<[number, number, number]>,
  style: string
): Array<[number, number, number]> {
  const preset = PEN_TYPE_PRESETS[style as keyof typeof PEN_TYPE_PRESETS];
  if (!preset) return points;
  const { speedResponse, nibAngle } = preset;
  if (!speedResponse && nibAngle === undefined) return points;

  const nibRad = nibAngle !== undefined ? (nibAngle * Math.PI) / 180 : null;
  // Speed at which a stroke is considered "fast"; above this the width stops
  // thinning further, so a flick cannot collapse the line to nothing.
  const FAST = 22;

  return points.map((pt, i) => {
    const prev = points[i - 1] ?? points[i + 1] ?? pt;
    const dx = pt[0] - prev[0];
    const dy = pt[1] - prev[1];
    const dist = Math.hypot(dx, dy);

    // The stored pressure is used as is. The pressure curve is applied ONCE,
    // when the point is captured (see calibratePressure): applying it here as
    // well calibrated every new stroke twice, and re-drew every stroke already
    // in the notebook with a curve that did not exist when it was written.
    let pressure = pt[2];

    if (speedResponse) {
      const fast = Math.min(1, dist / FAST);
      pressure *= 1 - fast * speedResponse;
    }

    if (nibRad !== null && dist > 0.001) {
      // |sin| of the angle between travel and the nib: 1 across the nib
      // (widest), 0 along it (thinnest). Floored so the line never vanishes.
      const travel = Math.atan2(dy, dx);
      const across = Math.abs(Math.sin(travel - nibRad));
      pressure *= 0.22 + 0.78 * across;
    }

    return [pt[0], pt[1], Math.max(0.02, Math.min(1, pressure))];
  });
}

/**
 * Filter out spurious lift-off hooks (the sharp trailing tail caused by lifting
 * finger/stylus off capacitive glass screens).
 */
export function pruneTerminalHooks(points: [number, number, number][]): [number, number, number][] {
  if (!points || points.length < 4) return points || [];

  const pts = [...points];

  // Pass 1: Check the very last point
  const last = pts[pts.length - 1];
  const prev = pts[pts.length - 2];
  const prev2 = pts[pts.length - 3];

  const dx1 = prev[0] - prev2[0];
  const dy1 = prev[1] - prev2[1];
  const len1 = Math.hypot(dx1, dy1);

  const dx2 = last[0] - prev[0];
  const dy2 = last[1] - prev[1];
  const len2 = Math.hypot(dx2, dy2);

  if (len1 > 1.5 && len2 > 1.5) {
    const dot = (dx1 * dx2 + dy1 * dy2) / (len1 * len2);
    // If angle > ~95 degrees reversal and tail is relatively short (< 40px)
    if (dot < -0.1 && len2 < 45) {
      pts.pop();
    }
  }

  // Pass 2: Check the new last point in case of a 2-step hook
  if (pts.length >= 4) {
    const l1 = pts[pts.length - 1];
    const p1 = pts[pts.length - 2];
    const p2 = pts[pts.length - 3];
    const dX1 = p1[0] - p2[0];
    const dY1 = p1[1] - p2[1];
    const L1 = Math.hypot(dX1, dY1);
    const dX2 = l1[0] - p1[0];
    const dY2 = l1[1] - p1[1];
    const L2 = Math.hypot(dX2, dY2);
    if (L1 > 1.5 && L2 > 1.5) {
      const dot2 = (dX1 * dX2 + dY1 * dY2) / (L1 * L2);
      if (dot2 < -0.15 && L2 < 35) {
        pts.pop();
      }
    }
  }

  return pts;
}

/**
 * Standard perfect-freehand SVG path builder.
 * Connects the outline polygon cleanly with true closed perimeter midpoint B-splines
 * without creating sharp triangular cross-over flap wedges at endpoints.
 */
export function getSvgPathFromStroke(
  inputPoints: number[][],
  closed = true
): string {
  let points = inputPoints;
  let len = points.length;
  if (len === 0) return "";
  if (len === 1) {
    const [x, y] = points[0];
    return `M ${(x - 1).toFixed(2)},${y.toFixed(2)} a 1,1 0 1,0 2,0 a 1,1 0 1,0 -2,0 Z`;
  }
  if (len === 2) {
    const [p0, p1] = points;
    return `M ${p0[0].toFixed(2)},${p0[1].toFixed(2)} L ${p1[0].toFixed(2)},${p1[1].toFixed(2)} Z`;
  }

  // Collapse consecutive coincident vertices FIRST.
  //
  // perfect-freehand converges a tapered end to a point by emitting several
  // vertices at the same coordinate (measured: three vertices all 0px from the
  // last input point, with the next real vertices 17.9px away). Those
  // zero-length edges have no defined angle, so the sharp-corner test bailed
  // out and the tip was smoothed away — the stroke ended in a flat chisel cut
  // instead of a point. With duplicates removed, the tip becomes a single
  // vertex between two long edges and is correctly seen as sharp.
  const deduped: number[][] = [points[0]];
  for (let i = 1; i < len; i++) {
    const prev = deduped[deduped.length - 1];
    if (Math.hypot(points[i][0] - prev[0], points[i][1] - prev[1]) > 0.01) {
      deduped.push(points[i]);
    }
  }
  // A closed outline also wraps: drop a final point coincident with the first.
  if (
    deduped.length > 1 &&
    Math.hypot(
      deduped[deduped.length - 1][0] - deduped[0][0],
      deduped[deduped.length - 1][1] - deduped[0][1]
    ) <= 0.01
  ) {
    deduped.pop();
  }
  if (deduped.length >= 3) {
    points = deduped;
    len = deduped.length;
  }

  if (closed) {
    const startMidX = (points[0][0] + points[len - 1][0]) / 2;
    const startMidY = (points[0][1] + points[len - 1][1]) / 2;
    let d = `M ${startMidX.toFixed(2)},${startMidY.toFixed(2)}`;

    for (let i = 0; i < len; i++) {
      const prev = points[(i - 1 + len) % len];
      const curr = points[i];
      const next = points[(i + 1) % len];
      const midX = (curr[0] + next[0]) / 2;
      const midY = (curr[1] + next[1]) / 2;

      if (isSharpCorner(prev, curr, next)) {
        // Route THROUGH the vertex. A midpoint quadratic only ever passes
        // through edge midpoints, so at a sharp vertex it cuts the corner off —
        // measured at 17% of the stroke width at a pen tip, which is what made
        // the end of a stroke look chopped instead of pointed.
        d += ` L ${curr[0].toFixed(2)},${curr[1].toFixed(2)}`;
        d += ` L ${midX.toFixed(2)},${midY.toFixed(2)}`;
      } else {
        d += ` Q ${curr[0].toFixed(2)},${curr[1].toFixed(2)} ${midX.toFixed(2)},${midY.toFixed(2)}`;
      }
    }
    d += " Z";
    return d;
  } else {
    let d = `M ${points[0][0].toFixed(2)},${points[0][1].toFixed(2)}`;
    for (let i = 0; i < len - 1; i++) {
      const prev = points[i === 0 ? 0 : i - 1];
      const curr = points[i];
      const next = points[i + 1];
      const midX = (curr[0] + next[0]) / 2;
      const midY = (curr[1] + next[1]) / 2;
      if (i > 0 && isSharpCorner(prev, curr, next)) {
        d += ` L ${curr[0].toFixed(2)},${curr[1].toFixed(2)}`;
        d += ` L ${midX.toFixed(2)},${midY.toFixed(2)}`;
      } else {
        d += ` Q ${curr[0].toFixed(2)},${curr[1].toFixed(2)} ${midX.toFixed(2)},${midY.toFixed(2)}`;
      }
    }
    const last = points[len - 1];
    d += ` L ${last[0].toFixed(2)},${last[1].toFixed(2)}`;
    return d;
  }
}

/**
 * Is the turn at `curr` sharp enough that rounding it would visibly blunt the
 * shape? Measured across real stroke outlines, tips and true corners fall at
 * 112-125° while ordinary curvature stays at 137° and above, so 130° separates
 * them cleanly: tips stay pointed, curves stay smooth.
 */
const SHARP_CORNER_DEG = 130;

function isSharpCorner(
  prev: number[],
  curr: number[],
  next: number[]
): boolean {
  const v1x = prev[0] - curr[0];
  const v1y = prev[1] - curr[1];
  const v2x = next[0] - curr[0];
  const v2y = next[1] - curr[1];
  const l1 = Math.hypot(v1x, v1y);
  const l2 = Math.hypot(v2x, v2y);
  // Degenerate/duplicate points have no meaningful angle; treat them as smooth
  // so they keep the existing behaviour instead of injecting stray corners.
  if (l1 < 0.001 || l2 < 0.001) return false;
  const cos = (v1x * v2x + v1y * v2y) / (l1 * l2);
  const deg = (Math.acos(Math.max(-1, Math.min(1, cos))) * 180) / Math.PI;
  return deg < SHARP_CORNER_DEG;
}

/**
 * Build the SVG `d` attribute for a StrokeElement.
 */
export function buildStrokePath(
  el: StrokeElement,
  isDraft = false,
  smoothingOverride?: number
): string {
  if (!el.points || el.points.length === 0) return "";

  const strokeWidth = Math.max(el.strokeWidth || 2, 1);
  const dotRadius = Math.max(strokeWidth / 2, 2);

  // Clean points of any trailing hooks if committing. A settled stroke's
  // points are the finished line (and its ends may be eraser cuts, which
  // are not pen hooks).
  const cleanPoints = isDraft || el.settled ? el.points : pruneTerminalHooks(el.points);

  // Single point -> render exact solid circular dot with r = max(strokeWidth / 2, 2)
  if (cleanPoints.length === 1) {
    const [x, y] = cleanPoints[0];
    const r = dotRadius;
    return `M ${(x - r).toFixed(2)},${y.toFixed(2)} a ${r.toFixed(2)},${r.toFixed(2)} 0 1,0 ${(r * 2).toFixed(2)},0 a ${r.toFixed(2)},${r.toFixed(2)} 0 1,0 ${(-r * 2).toFixed(2)},0 Z`;
  }

  // Calculate bounding diagonal span of points to detect micro-movements on tap
  let minX = Infinity;
  let minY = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;
  for (const [px, py] of cleanPoints) {
    if (px < minX) minX = px;
    if (py < minY) minY = py;
    if (px > maxX) maxX = px;
    if (py > maxY) maxY = py;
  }
  const span = Math.hypot(maxX - minX, maxY - minY);
  const dotThreshold = Math.max(4, strokeWidth * 0.6);

  if (span <= dotThreshold || (cleanPoints.length <= 2 && span < 6)) {
    const avgX = (minX + maxX) / 2;
    const avgY = (minY + maxY) / 2;
    const r = dotRadius;
    return `M ${(avgX - r).toFixed(2)},${avgY.toFixed(2)} a ${r.toFixed(2)},${r.toFixed(2)} 0 1,0 ${(r * 2).toFixed(2)},0 a ${r.toFixed(2)},${r.toFixed(2)} 0 1,0 ${(-r * 2).toFixed(2)},0 Z`;
  }

  // Settled points were smoothed once already; smoothing them again would
  // move them.
  const smoothingLevel = el.settled ? 0 : smoothingOverride ?? el.smoothing ?? 50;
  const options = getStrokeOptionsForStyle(el.strokeStyle, strokeWidth, !isDraft, smoothingLevel);
  if (el.cutStart && options.start) options.start = { ...options.start, taper: 0 };
  if (el.cutEnd && options.end) options.end = { ...options.end, taper: 0 };
  // Pen character is applied to the POINTS, not the options: perfect-freehand
  // derives width from pressure, so this is the only place a preset can make a
  // visible difference when the input pressure is flat (mouse, or a stylus at
  // steady force).
  const dynamic = applyPenDynamics(
    cleanPoints as Array<[number, number, number]>,
    el.strokeStyle
  );
  const inputPoints = dynamic.map(([x, y, p]) => [x, y, p]);
  const outline = getStroke(inputPoints, options);

  if (!outline || outline.length < 3) {
    const avgX = (minX + maxX) / 2;
    const avgY = (minY + maxY) / 2;
    const r = dotRadius;
    return `M ${(avgX - r).toFixed(2)},${avgY.toFixed(2)} a ${r.toFixed(2)},${r.toFixed(2)} 0 1,0 ${(r * 2).toFixed(2)},0 a ${r.toFixed(2)},${r.toFixed(2)} 0 1,0 ${(-r * 2).toFixed(2)},0 Z`;
  }

  return getSvgPathFromStroke(outline, true);
}

/**
 * The line a stroke is actually drawn along, as points: its raw points after
 * the same hook trimming and smoothing the renderer applies. The eraser cuts
 * THIS - what you see - and its pieces keep it, so nothing beside a cut moves.
 */
export function settledStrokePoints(el: StrokeElement): [number, number, number][] {
  if (el.settled || !el.points || el.points.length < 3) return el.points;
  const strokeWidth = Math.max(el.strokeWidth || 2, 1);
  const options = getStrokeOptionsForStyle(el.strokeStyle, strokeWidth, true, el.smoothing ?? 50);
  const clean = pruneTerminalHooks(el.points);
  const sp = getStrokePoints(
    clean.map(([x, y, p]) => [x, y, p]),
    options
  );
  if (sp.length < 2) return el.points;
  return sp.map((s) => [s.point[0], s.point[1], s.pressure] as [number, number, number]);
}

export function computePressureFromSpeed(
  points: Array<[number, number, number]>
): number {
  if (points.length < 2) return 0.5;
  const prev = points[points.length - 2];
  const curr = points[points.length - 1];
  if (!prev || !curr) return 0.5;
  const dx = curr[0] - prev[0];
  const dy = curr[1] - prev[1];
  const dist = Math.hypot(dx, dy);
  const maxSpeed = 10;
  const t = Math.min(1, dist / maxSpeed);
  return 0.52 - t * 0.08;
}

export function getArrowheadPath(
  tipX: number,
  tipY: number,
  angle: number,
  size: number
): string {
  const cos = Math.cos(angle);
  const sin = Math.sin(angle);

  const bx1 = tipX - cos * size + sin * (size * 0.4);
  const by1 = tipY - sin * size - cos * (size * 0.4);
  const bx2 = tipX - cos * size - sin * (size * 0.4);
  const by2 = tipY - sin * size + cos * (size * 0.4);

  return `M ${tipX},${tipY} L ${bx1},${by1} L ${bx2},${by2} Z`;
}

/**
 * Clip one segment against the eraser capsule, returning the covered parameter
 * range(s) in [0,1], or null when it misses.
 *
 * The capsule (segment A->B thickened by `r`) is the union of a rectangle and
 * the two end discs, so each piece is clipped analytically and the results
 * unioned. This is O(1) per segment. The previous version approximated the
 * capsule by sampling circles along it, which cost O(samples) per segment and
 * blew the frame budget on a fast drag (measured 8.2ms for one event).
 */
function clipSegmentToCapsule(
  x0: number,
  y0: number,
  x1: number,
  y1: number,
  ax: number,
  ay: number,
  bx: number,
  by: number,
  r: number
): [number, number] | null {
  const ex = bx - ax;
  const ey = by - ay;
  const len = Math.hypot(ex, ey);

  // Work in the capsule's frame: origin A, x along A->B, y perpendicular.
  let ux = 1;
  let uy = 0;
  if (len > 1e-9) {
    ux = ex / len;
    uy = ey / len;
  }
  const toLocal = (px: number, py: number): [number, number] => {
    const dx = px - ax;
    const dy = py - ay;
    return [dx * ux + dy * uy, -dx * uy + dy * ux];
  };

  const [lx0, ly0] = toLocal(x0, y0);
  const [lx1, ly1] = toLocal(x1, y1);
  const dx = lx1 - lx0;
  const dy = ly1 - ly0;

  let lo = Infinity;
  let hi = -Infinity;
  const add = (a: number, b: number) => {
    if (b < a) [a, b] = [b, a];
    a = Math.max(0, a);
    b = Math.min(1, b);
    if (b >= a) {
      lo = Math.min(lo, a);
      hi = Math.max(hi, b);
    }
  };

  // 1. The rectangular body: |y| <= r AND 0 <= x <= len.
  if (len > 1e-9) {
    let yLo = 0;
    let yHi = 1;
    if (Math.abs(dy) < 1e-9) {
      if (Math.abs(ly0) > r) {
        yLo = 1;
        yHi = 0; // never inside the slab
      }
    } else {
      yLo = (-r - ly0) / dy;
      yHi = (r - ly0) / dy;
      if (yLo > yHi) [yLo, yHi] = [yHi, yLo];
    }
    let xLo = 0;
    let xHi = 1;
    if (Math.abs(dx) < 1e-9) {
      if (lx0 < 0 || lx0 > len) {
        xLo = 1;
        xHi = 0;
      }
    } else {
      xLo = (0 - lx0) / dx;
      xHi = (len - lx0) / dx;
      if (xLo > xHi) [xLo, xHi] = [xHi, xLo];
    }
    const a = Math.max(yLo, xLo);
    const b = Math.min(yHi, xHi);
    if (b >= a) add(a, b);
  }

  // 2. The two end discs.
  const disc = (cx: number, cy: number) => {
    const fx = lx0 - cx;
    const fy = ly0 - cy;
    const A = dx * dx + dy * dy;
    if (A < 1e-9) {
      if (fx * fx + fy * fy <= r * r) add(0, 1);
      return;
    }
    const B = 2 * (fx * dx + fy * dy);
    const C = fx * fx + fy * fy - r * r;
    const disc2 = B * B - 4 * A * C;
    if (disc2 < 0) return;
    const sq = Math.sqrt(disc2);
    add((-B - sq) / (2 * A), (-B + sq) / (2 * A));
  };
  disc(0, 0);
  if (len > 1e-9) disc(len, 0);

  return hi >= lo ? [lo, hi] : null;
}

/**
 * Pixel eraser: remove the part of a stroke swept by the eraser and return the
 * surviving pieces.
 *
 * The eraser is a CAPSULE, not a point: `(ax, ay)` is where it was at the last
 * pointer event and `(bx, by)` where it is now. Testing only the current
 * position leaves un-erased gaps whenever the user drags faster than the event
 * rate.
 *
 * Each stroke SEGMENT is clipped analytically against the eraser, rather than
 * testing the recorded points. Point-sampling has two failure modes that make
 * the eraser feel broken, both measured on a stroke with 30px point spacing:
 *   - a small eraser passing BETWEEN two recorded points erased nothing at all;
 *   - a 24px eraser removed 60px of stroke, because the cut could only land on
 *     an existing point.
 * Clipping cuts exactly at the eraser's edge whatever the point spacing.
 *
 * `points` and the eraser coordinates are all in the stroke's local space.
 *
 * Returns `null` when nothing was touched (so the caller can skip the write —
 * this runs on every pointermove of a drag), `[]` when the stroke is gone, or
 * the surviving runs.
 */
export function eraseFromStroke(
  points: Array<[number, number, number]>,
  ax: number,
  ay: number,
  bx: number,
  by: number,
  radius: number
): Array<Array<[number, number, number]>> | null {
  if (!points || points.length < 2) {
    // A dot has no segments: fall back to a distance test.
    if (points && points.length === 1) {
      const [px, py] = points[0];
      return distanceToSegment(px, py, ax, ay, bx, by) <= radius ? [] : null;
    }
    return null;
  }

  // Bounding box of the swept eraser, used to reject segments cheaply. Without
  // this every segment of every stroke paid for the full clip on every
  // pointermove, which is what made a fast drag stutter.
  const sweepMinX = Math.min(ax, bx) - radius;
  const sweepMaxX = Math.max(ax, bx) + radius;
  const sweepMinY = Math.min(ay, by) - radius;
  const sweepMaxY = Math.max(ay, by) + radius;

  let touched = false;
  const covered: Array<[number, number] | null> = [];

  for (let i = 0; i < points.length - 1; i++) {
    const [x0, y0] = points[i];
    const [x1, y1] = points[i + 1];

    if (
      Math.max(x0, x1) < sweepMinX ||
      Math.min(x0, x1) > sweepMaxX ||
      Math.max(y0, y1) < sweepMinY ||
      Math.min(y0, y1) > sweepMaxY
    ) {
      covered.push(null);
      continue;
    }

    const span = clipSegmentToCapsule(x0, y0, x1, y1, ax, ay, bx, by, radius);
    if (span) touched = true;
    covered.push(span);
  }

  if (!touched) return null;

  const lerp = (i: number, t: number): [number, number, number] => {
    const [x0, y0, p0] = points[i];
    const [x1, y1, p1] = points[i + 1];
    return [x0 + (x1 - x0) * t, y0 + (y1 - y0) * t, p0 + (p1 - p0) * t];
  };

  const runs: Array<Array<[number, number, number]>> = [];
  let current: Array<[number, number, number]> = [];
  const EPS = 1e-6;

  for (let i = 0; i < points.length - 1; i++) {
    const span = covered[i];
    if (!span) {
      // Untouched segment: the run continues through it.
      if (current.length === 0) current.push(points[i]);
      current.push(points[i + 1]);
      continue;
    }
    const [lo, hi] = span;
    if (lo > EPS) {
      if (current.length === 0) current.push(points[i]);
      current.push(lerp(i, lo));
    }
    if (current.length > 0) {
      runs.push(current);
      current = [];
    }
    if (hi < 1 - EPS) {
      current.push(lerp(i, hi));
      current.push(points[i + 1]);
    }
  }
  if (current.length > 0) runs.push(current);

  // Drop crumbs. A fragment shorter than the eraser itself is a bead or a
  // sliver left behind mid-rub — it reads as debris, not as ink the user chose
  // to keep, and each one is a full element with its own round caps.
  const minLength = Math.max(radius, 1);
  return runs.filter((run) => {
    if (run.length < 2) return false;
    let length = 0;
    for (let i = 1; i < run.length; i++) {
      length += Math.hypot(run[i][0] - run[i - 1][0], run[i][1] - run[i - 1][1]);
    }
    return length >= minLength;
  });
}

/** Shortest distance from a point to a segment — used for dot strokes. */
function distanceToSegment(
  px: number,
  py: number,
  ax: number,
  ay: number,
  bx: number,
  by: number
): number {
  const dx = bx - ax;
  const dy = by - ay;
  const len2 = dx * dx + dy * dy;
  if (len2 < 1e-9) return Math.hypot(px - ax, py - ay);
  let t = ((px - ax) * dx + (py - ay) * dy) / len2;
  t = Math.max(0, Math.min(1, t));
  return Math.hypot(px - (ax + dx * t), py - (ay + dy * t));
}

/**
 * Determine whether a freehand stroke approximates an intentional straight line.
 * Used for "Draw and Hold" auto-straightening (e.g. underlining, arrows, highlighters).
 */
export function isStrokeStraight(
  points: Array<[number, number, number]>,
  toleranceRatio: number = 0.88
): boolean {
  if (!points || points.length < 5) return false;
  const first = points[0];
  const last = points[points.length - 1];
  const chord = Math.hypot(last[0] - first[0], last[1] - first[1]);
  if (chord < 28) return false; // too short to classify as intentional line

  let totalLength = 0;
  for (let i = 1; i < points.length; i++) {
    totalLength += Math.hypot(
      points[i][0] - points[i - 1][0],
      points[i][1] - points[i - 1][1]
    );
  }
  if (totalLength <= 0) return false;
  return chord / totalLength >= toleranceRatio;
}

/**
 * The stroke without the points recorded while the pen was held still at its
 * end. A held pen keeps reporting tiny moves; left in, their scribble adds
 * path length the line never had, and a ruler-straight line followed by a
 * one-second hold measured as a curve (length ratio ~0.6), so draw-and-hold
 * never straightened anything drawn by a real hand.
 */
export function trimHoldTail(
  points: Array<[number, number, number]>,
  radius: number
): Array<[number, number, number]> {
  if (points.length < 3) return points;
  const last = points[points.length - 1];
  let i = points.length - 1;
  while (i > 0 && Math.hypot(points[i - 1][0] - last[0], points[i - 1][1] - last[1]) <= radius) i--;
  // Keep the first point of the hold so the line still ends where the pen is.
  return [...points.slice(0, i), last];
}

/**
 * Replace a jagged freehand stroke with an evenly interpolated straight line
 * between the start and end point, preserving average stroke pressure.
 */
export function straightenStrokePoints(
  points: Array<[number, number, number]>,
  segments: number = 8
): Array<[number, number, number]> {
  if (!points || points.length < 2) return points;
  const first = points[0];
  const last = points[points.length - 1];
  const avgPressure =
    points.reduce((acc, pt) => acc + (pt[2] ?? 0.5), 0) / points.length;

  const result: Array<[number, number, number]> = [];
  for (let i = 0; i <= segments; i++) {
    const t = i / segments;
    const x = first[0] + (last[0] - first[0]) * t;
    const y = first[1] + (last[1] - first[1]) * t;
    result.push([x, y, avgPressure]);
  }
  return result;
}
