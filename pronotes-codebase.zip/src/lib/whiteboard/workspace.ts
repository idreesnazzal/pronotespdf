/**
 * Workspace Backup / Restore / Merge
 * ===================================
 * One portable JSON document holding the WHOLE workspace (folders, boards,
 * elements, custom link types, pinned pens).
 *
 * This is the migration path off per-browser localStorage — and the same
 * document that gets pushed to and pulled from OneDrive, so the merge rules
 * here are what make two devices converge instead of overwriting each other.
 */

import { migrateState } from "./persistence";
import { allElements, getPages } from "./notebook";
import type { Board, Folder, PinnedBarPosition, PinnedPen, WhiteboardElement } from "./types";

/** Bumped only if the FILE format changes, independent of the store schema. */
export const WORKSPACE_FORMAT = 1;

export interface WorkspaceDoc {
  format: number;
  app: "pronotes";
  exportedAt: number;
  /** Which device wrote this — shown when reporting a sync conflict. */
  deviceLabel?: string;
  folders: Folder[];
  boards: Board[];
  activeBoardId: string | null;
  activeFolderId: string | null;
  customLinkTypes?: Array<{ id: string; name: string; color: string }>;
  pinnedPens?: PinnedPen[];
  pinnedBarPos?: PinnedBarPosition | null;
}

export interface WorkspaceSnapshot {
  folders: Folder[];
  boards: Board[];
  activeBoardId: string | null;
  activeFolderId: string | null;
  customLinkTypes?: Array<{ id: string; name: string; color: string }>;
  pinnedPens?: PinnedPen[];
  pinnedBarPos?: PinnedBarPosition | null;
}

export function buildWorkspaceDoc(
  snapshot: WorkspaceSnapshot,
  deviceLabel?: string
): WorkspaceDoc {
  return {
    format: WORKSPACE_FORMAT,
    app: "pronotes",
    exportedAt: Date.now(),
    deviceLabel,
    folders: snapshot.folders,
    boards: snapshot.boards,
    activeBoardId: snapshot.activeBoardId,
    activeFolderId: snapshot.activeFolderId,
    customLinkTypes: snapshot.customLinkTypes ?? [],
    pinnedPens: snapshot.pinnedPens ?? [],
    pinnedBarPos: snapshot.pinnedBarPos ?? null,
  };
}

export function serializeWorkspace(
  snapshot: WorkspaceSnapshot,
  deviceLabel?: string
): string {
  return JSON.stringify(buildWorkspaceDoc(snapshot, deviceLabel), null, 2);
}

export class WorkspaceParseError extends Error {}

/**
 * Parse a backup file. Anything structurally wrong is rejected with a message
 * a human can act on, rather than silently importing an empty workspace over
 * good data — restoring the WRONG file is unrecoverable without version control.
 */
export function parseWorkspace(json: string): WorkspaceSnapshot {
  let raw: unknown;
  try {
    raw = JSON.parse(json);
  } catch {
    throw new WorkspaceParseError("That file is not valid JSON.");
  }
  if (!raw || typeof raw !== "object") {
    throw new WorkspaceParseError("That file does not contain a workspace.");
  }
  const doc = raw as Partial<WorkspaceDoc>;
  if (doc.app !== "pronotes") {
    throw new WorkspaceParseError("That file was not exported from ProNotes.");
  }
  if (typeof doc.format !== "number" || doc.format > WORKSPACE_FORMAT) {
    throw new WorkspaceParseError(
      "That backup was made by a NEWER version of ProNotes. Update the app first."
    );
  }
  if (!Array.isArray(doc.boards)) {
    throw new WorkspaceParseError("That backup has no boards in it.");
  }

  // Route through the same hardening as a local load so a hand-edited or
  // truncated backup cannot brick the app.
  const migrated = migrateState({
    version: 1,
    folders: (doc.folders ?? []) as Folder[],
    boards: doc.boards as Board[],
    activeBoardId: doc.activeBoardId ?? null,
    activeFolderId: doc.activeFolderId ?? null,
    customLinkTypes: doc.customLinkTypes,
    pinnedPens: doc.pinnedPens,
    pinnedBarPos: doc.pinnedBarPos,
  });

  return {
    folders: migrated.folders,
    boards: migrated.boards,
    activeBoardId: migrated.activeBoardId,
    activeFolderId: migrated.activeFolderId,
    customLinkTypes: migrated.customLinkTypes,
    pinnedPens: migrated.pinnedPens,
    pinnedBarPos: migrated.pinnedBarPos,
  };
}

/**
 * Every image/PDF id still reachable: live boards, page templates (which
 * outlive the page they were made from), plus any extra boards the caller
 * passes — notably the trash undo buffer, whose pictures and PDFs must NOT
 * be reclaimed while Undo can still bring them back.
 *
 * Pure so the sidebar's delete-undo can be unit-tested without IndexedDB.
 */
export function collectReferencedAssets(
  boards: Board[],
  templates: Array<{ elements: WhiteboardElement[] }> = [],
  extraBoards: Board[] = []
): { pdfIds: Set<string>; imageIds: Set<string> } {
  const pdfIds = new Set<string>();
  const imageIds = new Set<string>();
  const scan = (b: Board) => {
    for (const p of getPages(b)) if (p.pdf?.docId) pdfIds.add(p.pdf.docId);
    for (const el of allElements(b)) {
      const src = (el as { src?: string }).src;
      if (typeof src === "string" && src.startsWith("asset:")) imageIds.add(src.slice(6));
    }
  };
  for (const b of boards) scan(b);
  for (const b of extraBoards) scan(b);
  for (const t of templates) {
    for (const el of t.elements) {
      const src = (el as { src?: string }).src;
      if (typeof src === "string" && src.startsWith("asset:")) imageIds.add(src.slice(6));
    }
  }
  return { pdfIds, imageIds };
}

export interface MergeReport {
  added: number;
  updatedFromRemote: number;
  keptLocal: number;
  foldersAdded: number;
}

/**
 * Merge a remote workspace into the local one, per board, by `updatedAt`.
 *
 * Whole-document last-write-wins is what silently destroys work: edit board A
 * on the tablet and board B on the PC, and whichever syncs second erases the
 * other's board entirely. Merging per board means both survive; only a board
 * edited on BOTH devices has to pick a winner, and there the newer timestamp
 * wins and the loss is limited to that one board.
 */
export function mergeWorkspaces(
  local: WorkspaceSnapshot,
  remote: WorkspaceSnapshot
): { merged: WorkspaceSnapshot; report: MergeReport } {
  const report: MergeReport = {
    added: 0,
    updatedFromRemote: 0,
    keptLocal: 0,
    foldersAdded: 0,
  };

  const byId = new Map<string, Board>();
  for (const b of local.boards) byId.set(b.id, b);

  for (const remoteBoard of remote.boards) {
    const localBoard = byId.get(remoteBoard.id);
    if (!localBoard) {
      byId.set(remoteBoard.id, remoteBoard);
      report.added++;
      continue;
    }
    const localAt = localBoard.updatedAt ?? 0;
    const remoteAt = remoteBoard.updatedAt ?? 0;
    if (remoteAt > localAt) {
      byId.set(remoteBoard.id, remoteBoard);
      report.updatedFromRemote++;
    } else {
      report.keptLocal++;
    }
  }

  const folderById = new Map<string, Folder>();
  for (const f of local.folders) folderById.set(f.id, f);
  for (const f of remote.folders) {
    if (!folderById.has(f.id)) {
      folderById.set(f.id, f);
      report.foldersAdded++;
    }
  }

  // Union the link types by id — losing a custom type would leave connections
  // rendering as unlabelled grey lines on the device that lost it.
  const linkTypes = new Map<string, { id: string; name: string; color: string }>();
  for (const t of local.customLinkTypes ?? []) linkTypes.set(t.id, t);
  for (const t of remote.customLinkTypes ?? []) if (!linkTypes.has(t.id)) linkTypes.set(t.id, t);

  const boards = [...byId.values()];
  const activeStillExists = boards.some((b) => b.id === local.activeBoardId);

  return {
    merged: {
      folders: [...folderById.values()],
      boards,
      // Keep looking at whatever THIS device was looking at; only fall back if
      // that board no longer exists after the merge.
      activeBoardId: activeStillExists ? local.activeBoardId : boards[0]?.id ?? null,
      activeFolderId: local.activeFolderId,
      customLinkTypes: [...linkTypes.values()],
      // Pens and bar position are per-device preferences, not shared documents.
      pinnedPens: local.pinnedPens,
      pinnedBarPos: local.pinnedBarPos,
    },
    report,
  };
}
