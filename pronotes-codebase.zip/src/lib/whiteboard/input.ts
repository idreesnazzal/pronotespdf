/**
 * Wheel input interpretation
 * ==========================
 * Turns a raw wheel event into "zoom by this factor" or "pan by this much",
 * kept out of the component so it can be unit-tested against what real devices
 * actually send.
 *
 * Two things browsers get you wrong if you ignore them:
 *
 * 1. `deltaMode`. Chrome sends pixels (0), but Firefox sends LINES (1) — about
 *    3 per wheel notch — and page mode (2) exists too. Treating 3 lines as 3
 *    pixels makes the wheel feel inert and pinch-zoom crawl at 0.2% per event.
 *
 * 2. A trackpad pinch arrives as a wheel event with `ctrlKey` set. That is a
 *    browser convention, not a real Ctrl press, so pinch and Ctrl+wheel are
 *    indistinguishable — and both should zoom.
 */

export type WheelMode = "auto" | "trackpad" | "mouse";

export interface RawWheel {
  deltaX: number;
  deltaY: number;
  deltaMode: number;
  ctrlKey: boolean;
  metaKey: boolean;
  shiftKey: boolean;
}

export type WheelAction =
  | { kind: "zoom"; factor: number }
  | { kind: "pan"; dx: number; dy: number };

/** One wheel notch in Firefox's line units is roughly this many pixels. */
const PIXELS_PER_LINE = 16;
const PIXELS_PER_PAGE = 800;

export function normalizeWheelDelta(e: RawWheel): { dx: number; dy: number } {
  const scale =
    e.deltaMode === 1 ? PIXELS_PER_LINE : e.deltaMode === 2 ? PIXELS_PER_PAGE : 1;
  return { dx: e.deltaX * scale, dy: e.deltaY * scale };
}

/**
 * Is this event from a mouse wheel rather than a trackpad?
 *
 * Mouse wheels emit large, quantised steps on one axis (100/120px in Chrome,
 * 3 lines in Firefox) and never a horizontal component. Trackpads emit small,
 * often fractional deltas and usually some horizontal drift. This is a
 * heuristic, which is why the user can override it in Settings.
 */
export function looksLikeMouseWheel(e: RawWheel): boolean {
  if (e.deltaMode !== 0) return true; // line/page units only ever come from a wheel
  if (e.deltaX !== 0) return false; // trackpads drift sideways; wheels do not
  const abs = Math.abs(e.deltaY);
  return abs >= 50 && Number.isInteger(e.deltaY);
}

// ---------------------------------------------------------------------------
// Which device is this, really?
// ---------------------------------------------------------------------------
//
// `looksLikeMouseWheel` judges ONE event, and that is what made two-finger
// scrolling zoom "sometimes": a Windows precision touchpad flicked straight
// down sends deltaX exactly 0 with an integer deltaY over 50 — identical to a
// wheel notch — while the same gesture with a little sideways drift reads as a
// trackpad. One gesture, two answers, so the canvas zoomed at random.
//
// A device does not change between events. So the source is decided across a
// short run of events and then held, and only re-decided after a pause long
// enough to mean a new gesture.

export type WheelSource = "mouse" | "trackpad";

export interface WheelSample {
  deltaX: number;
  deltaY: number;
  deltaMode: number;
  time: number;
}

export interface WheelDeviceState {
  samples: WheelSample[];
  verdict: WheelSource | null;
}

/** A gap longer than this means a new gesture; the verdict is re-decided. */
export const WHEEL_GESTURE_GAP_MS = 400;
/** Trackpads stream; wheels click. Consecutive events closer than this are a stream. */
export const TRACKPAD_STREAM_GAP_MS = 40;

const MAX_SAMPLES = 12;

export function createWheelDeviceState(): WheelDeviceState {
  return { samples: [], verdict: null };
}

/** Decisive evidence from the samples themselves, or null when unsure. */
function decideSource(samples: WheelSample[]): WheelSource | null {
  for (let i = samples.length - 1; i >= 0; i--) {
    const s = samples[i];
    // Line and page units only ever come from a real wheel.
    if (s.deltaMode !== 0) return "mouse";
    // Wheels have no horizontal axis, and cannot produce fractions.
    if (s.deltaX !== 0) return "trackpad";
    if (!Number.isInteger(s.deltaY)) return "trackpad";
  }

  // Cadence is what separates the ambiguous case: a touchpad reports a
  // continuous stream every few milliseconds, a wheel sends discrete notches.
  if (samples.length >= 3) {
    let rapid = 0;
    for (let i = 1; i < samples.length; i++) {
      if (samples[i].time - samples[i - 1].time < TRACKPAD_STREAM_GAP_MS) rapid++;
    }
    if (rapid >= 2) return "trackpad";
  }

  return null;
}

export function observeWheel(state: WheelDeviceState, sample: WheelSample): WheelDeviceState {
  const last = state.samples[state.samples.length - 1];
  const newGesture = !last || sample.time - last.time > WHEEL_GESTURE_GAP_MS;

  const samples = (newGesture ? [] : state.samples).concat(sample).slice(-MAX_SAMPLES);
  const carried = newGesture ? null : state.verdict;
  return { samples, verdict: decideSource(samples) ?? carried };
}

/** The device behind this event: the held verdict, else the single-event guess. */
export function wheelSourceOf(state: WheelDeviceState, e: RawWheel): WheelSource {
  return state.verdict ?? (looksLikeMouseWheel(e) ? "mouse" : "trackpad");
}

/**
 * Turns a scroll pan into the arguments `panCamera` expects.
 *
 * Two opposite conventions meet here, which is exactly why scrolling came out
 * inverted:
 *   - a DRAG delta is how far a finger moved, and the content follows the hand
 *     (`panCamera` subtracts it from the camera);
 *   - a SCROLL delta means "show me what is further down", so the camera must
 *     move the OTHER way.
 *
 * Passing a scroll delta straight to `panCamera` therefore scrolls backwards:
 * swiping up on the touchpad moved the view up instead of down.
 */
export function cameraPanForScroll(pan: { dx: number; dy: number }): { dx: number; dy: number } {
  return { dx: -pan.dx, dy: -pan.dy };
}

export function resolveWheelAction(
  e: RawWheel,
  mode: WheelMode,
  source?: WheelSource
): WheelAction {
  const { dx, dy } = normalizeWheelDelta(e);

  // A pinch (ctrlKey) always zooms, in every mode — otherwise pinching would
  // scroll the canvas away, which is never what the gesture means.
  const pinchOrModifier = e.ctrlKey || e.metaKey;

  const treatAsMouse =
    mode === "mouse" ||
    (mode === "auto" && (source ? source === "mouse" : looksLikeMouseWheel(e)));

  if (pinchOrModifier || (treatAsMouse && !e.shiftKey)) {
    // 0.0015 per pixel gives ~14% per mouse notch and a smooth trackpad pinch,
    // and being exponential it is symmetric: zooming in then out returns
    // exactly where you started.
    return { kind: "zoom", factor: Math.exp(-dy * 0.0015) };
  }

  // Shift swaps the axis, the long-standing convention for horizontal scroll
  // on a device that only has a vertical wheel.
  if (e.shiftKey && dx === 0) return { kind: "pan", dx: dy, dy: 0 };

  return { kind: "pan", dx, dy };
}


// ---------------------------------------------------------------------------
// Stylus buttons
// ---------------------------------------------------------------------------

/**
 * Bits in PointerEvent.buttons that mean "the user wants to erase with this
 * stylus", per the Pointer Events spec:
 *   2  — barrel (side) button held
 *   32 — the eraser end of the pen is in contact
 *
 * Note on the Samsung S Pen specifically: its BLE *remote* button (the one used
 * for Air Actions — single click, double click, gestures) is NOT delivered to
 * web content at all. It is only readable through the native S Pen Remote SDK,
 * so a double-click-for-undo cannot be implemented from inside a WebView. The
 * barrel button and the eraser end below ARE delivered, and hold-to-erase is
 * the behaviour OneNote and Samsung Notes both use.
 */
export const STYLUS_BARREL_BUTTON = 2;
export const STYLUS_ERASER_TIP = 32;

export interface StylusButtonState {
  pointerType: string;
  buttons: number;
}

/** True when a pen event carries the barrel button or the eraser end. */
export function isStylusEraseRequest(e: StylusButtonState): boolean {
  if (e.pointerType !== "pen") return false;
  return (e.buttons & STYLUS_BARREL_BUTTON) !== 0 || (e.buttons & STYLUS_ERASER_TIP) !== 0;
}

/**
 * What a pen event should do to the borrowed-eraser state.
 *
 * Keyed on the BUTTON, not on the nib. Holding the barrel button while merely
 * hovering has to arm the eraser already, and releasing it has to hand the pen
 * back at once - even with the nib still on the glass. Driving this from
 * pointerdown/pointerup alone, as the first version did, meant the eraser only
 * appeared once you touched the paper and you stayed stuck in it until you
 * lifted off.
 *
 * `borrowed` is whether the eraser is currently on loan, so the caller gets an
 * edge rather than a level and never re-enters the eraser it is already in
 * (which would overwrite the tool being held for you).
 */
export type StylusEraseAction = "engage" | "release" | "none";

export function stylusEraseTransition(
  borrowed: boolean,
  e: StylusButtonState
): StylusEraseAction {
  // A finger or a mouse says nothing about the pen's button, and must never
  // release an eraser the pen is holding.
  if (e.pointerType !== "pen") return "none";
  const wants = isStylusEraseRequest(e);
  if (wants && !borrowed) return "engage";
  if (!wants && borrowed) return "release";
  return "none";
}
