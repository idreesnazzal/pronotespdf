/**
 * Workspace database (IndexedDB)
 * ==============================
 * The workspace — every board and all of its ink — lives here, NOT in
 * localStorage.
 *
 * The measured problem: a tablet workspace grew past ~4 MB against
 * localStorage's ~5 MB per-origin cap, and EVERY save began failing with
 * QuotaExceededError (see the device logs: dozens of
 * "[whiteboard] Failed to save state" in a row). localStorage cannot be
 * raised — 5 MB is hard-wired — so the only fix is a store without that cap.
 *
 * This follows the same split the industry settled on (tldraw persists
 * documents to IndexedDB; Excalidraw moved scenes off localStorage for the
 * identical 5 MB failure in issue #711): bulk document data goes to
 * IndexedDB, whose quota is a share of free disk (gigabytes, not megabytes),
 * while localStorage keeps only tiny synchronous keys (a save heartbeat and
 * the legacy copy during migration).
 *
 * Design notes (all deliberate):
 * - Same single-snapshot semantics as before: one record, last-write-wins.
 *   Per-board incremental writes would be cheaper per save but introduce
 *   partial-write states (board A saved, board B not); atomic snapshots
 *   cannot half-save.
 * - The record stores BYTES (optionally gzipped), not the object tree, so
 *   IndexedDB's main-thread structured clone is a memcpy rather than a walk
 *   of millions of stroke points (web.dev's IndexedDB best-practice warning).
 * - gzip kicks in above 1 MB of JSON. Ink compresses ~85-90% (repetitive
 *   coordinates), so a 4 MB workspace stores as ~0.5 MB. Below the threshold
 *   the JSON is stored raw: faster, and still human-inspectable when
 *   debugging a device.
 * - The backend is injectable: production uses real IndexedDB, unit tests use
 *   an in-memory Map. No singletons, no ambient state except the save queue.
 * - navigator.storage.persist() is requested at boot so the OS does not treat
 *   these boards as evictable cache data (Capacitor docs call this out: on
 *   Android the persisted API is what protects IndexedDB).
 */

export const WORKSPACE_DB_NAME = "pronotes-workspace";
export const WORKSPACE_DB_VERSION = 1;
export const WORKSPACE_STORE = "kv";
export const WORKSPACE_RECORD_KEY = "workspace";
/** Payloads at or above this JSON size are gzipped before storing. */
export const GZIP_THRESHOLD_CHARS = 1_000_000;
/** Early-warning line: tell the user BEFORE writes start failing. */
export const STORAGE_PRESSURE_RATIO = 0.85;
/** localStorage heartbeat: ~50 bytes that keep cross-tab save detection alive. */
export const HEARTBEAT_KEY = "z-whiteboard-rev";

export interface WorkspaceRecord {
  v: 1;
  format: "raw" | "gzip";
  savedAt: number;
  data: string | Uint8Array;
}

export interface WorkspaceBackend {
  load(): Promise<WorkspaceRecord | null>;
  save(rec: WorkspaceRecord): Promise<void>;
  clear(): Promise<void>;
}

function idbAvailable(): boolean {
  return typeof indexedDB !== "undefined";
}

export function workspaceDbAvailable(): boolean {
  return idbAvailable();
}

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (!idbAvailable()) {
      reject(new Error("This browser has no IndexedDB, so the workspace cannot be stored there."));
      return;
    }
    const req = indexedDB.open(WORKSPACE_DB_NAME, WORKSPACE_DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(WORKSPACE_STORE)) db.createObjectStore(WORKSPACE_STORE);
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error ?? new Error("Could not open the workspace store"));
  });
}

function tx<T>(mode: IDBTransactionMode, run: (s: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  return openDb().then(
    (db) =>
      new Promise<T>((resolve, reject) => {
        let settled = false;
        const done = (fn: () => void) => {
          if (!settled) {
            settled = true;
            fn();
          }
        };
        try {
          const t = db.transaction(WORKSPACE_STORE, mode);
          t.oncomplete = () => db.close();
          t.onerror = () => db.close();
          const req = run(t.objectStore(WORKSPACE_STORE));
          req.onsuccess = () => done(() => resolve(req.result));
          req.onerror = () =>
            done(() => {
              try {
                db.close();
              } catch {
                /* closing is best-effort */
              }
              reject(req.error ?? new Error("Workspace store request failed"));
            });
        } catch (err) {
          try {
            db.close();
          } catch {
            /* closing is best-effort */
          }
          reject(err);
        }
      })
  );
}

/** Production backend: real IndexedDB. Thin — all decisions live elsewhere. */
export function createIdbWorkspaceBackend(): WorkspaceBackend {
  return {
    load: () => tx<WorkspaceRecord | undefined>("readonly", (s) => s.get(WORKSPACE_RECORD_KEY)).then((r) => r ?? null),
    save: (rec) => tx<void>("readwrite", (s) => s.put(rec, WORKSPACE_RECORD_KEY) as unknown as IDBRequest<void>).then(() => undefined),
    clear: () => tx<void>("readwrite", (s) => s.delete(WORKSPACE_RECORD_KEY) as unknown as IDBRequest<void>).then(() => undefined),
  };
}

/** Test backend: same interface over a Map. No quota, no async storage. */
export function createMemoryWorkspaceBackend(): WorkspaceBackend & { records: Map<string, WorkspaceRecord> } {
  const records = new Map<string, WorkspaceRecord>();
  return {
    records,
    load: () => Promise.resolve(records.get(WORKSPACE_RECORD_KEY) ?? null),
    save: (rec) => {
      records.set(WORKSPACE_RECORD_KEY, rec);
      return Promise.resolve();
    },
    clear: () => {
      records.delete(WORKSPACE_RECORD_KEY);
      return Promise.resolve();
    },
  };
}

function compressionAvailable(): boolean {
  return typeof CompressionStream !== "undefined" && typeof DecompressionStream !== "undefined";
}

async function gzipString(text: string): Promise<Uint8Array> {
  const stream = new Response(new Blob([text]).stream().pipeThrough(new CompressionStream("gzip")));
  const buf = await stream.arrayBuffer();
  return new Uint8Array(buf);
}

async function gunzipBytes(bytes: Uint8Array): Promise<string> {
  // Slice the view: response over the whole backing buffer would decode
  // neighbouring bytes if this Uint8Array is itself a view.
  const copy = bytes.slice().buffer as ArrayBuffer;
  const stream = new Response(new Blob([copy]).stream().pipeThrough(new DecompressionStream("gzip")));
  return stream.text();
}

/**
 * Serialized JSON -> storable record. Large payloads are gzipped; small ones
 * stay raw. Throws only if compression itself fails — callers treat that as
 * "store raw instead", never as lost data.
 */
export async function encodeWorkspace(json: string): Promise<WorkspaceRecord> {
  if (json.length >= GZIP_THRESHOLD_CHARS && compressionAvailable()) {
    const data = await gzipString(json);
    return { v: 1, format: "gzip", savedAt: Date.now(), data };
  }
  return { v: 1, format: "raw", savedAt: Date.now(), data: json };
}

/**
 * Storable record -> serialized JSON. Throws on structural problems or a
 * failed gunzip; callers fall back to the previous copy, never to nothing.
 */
export async function decodeWorkspace(rec: WorkspaceRecord): Promise<string> {
  if (!rec || typeof rec !== "object") throw new Error("Workspace record is not an object");
  if (rec.v !== 1) throw new Error(`Unsupported workspace record version ${(rec as { v?: unknown }).v}`);
  if (rec.format === "raw") {
    if (typeof rec.data !== "string") throw new Error("Raw workspace record holds no string");
    return rec.data;
  }
  if (rec.format === "gzip") {
    if (!(rec.data instanceof Uint8Array)) throw new Error("Gzipped workspace record holds no bytes");
    if (!compressionAvailable()) throw new Error("Cannot gunzip without DecompressionStream");
    return gunzipBytes(rec.data);
  }
  throw new Error(`Unknown workspace record format ${(rec as { format?: unknown }).format}`);
}

/**
 * Ask the OS to treat this origin's storage as persistent (not evictable
 * cache). Best-effort: resolves false when unsupported or denied. Must never
 * throw into boot.
 */
export async function requestPersistentStorage(): Promise<boolean> {
  try {
    const storage = (typeof navigator !== "undefined" && navigator.storage) || undefined;
    if (!storage || typeof storage.persist !== "function") return false;
    return await storage.persist();
  } catch {
    return false;
  }
}

export interface StoragePressure {
  usage: number;
  quota: number;
  ratio: number;
}

/** How full the origin's pooled storage is, or null when unmeasurable. */
export async function measureStoragePressure(): Promise<StoragePressure | null> {
  try {
    const storage = (typeof navigator !== "undefined" && navigator.storage) || undefined;
    if (!storage || typeof storage.estimate !== "function") return null;
    const { usage, quota } = await storage.estimate();
    if (typeof usage !== "number" || typeof quota !== "number" || quota <= 0) return null;
    return { usage, quota, ratio: usage / quota };
  } catch {
    return null;
  }
}
