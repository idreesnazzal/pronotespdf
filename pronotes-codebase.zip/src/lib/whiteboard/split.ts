/**
 * Split view geometry, kept free of React so it can be unit-tested.
 */

/**
 * Each pane keeps at least this much room: the live pane carries the tool
 * dock, the page bar and the top bar, and below ~260px they overlap.
 */
export const MIN_PANE_PX = 260;

/** The ratio for a pointer at `pos` px along a `length` px row, kept usable. */
export function dividerRatio(pos: number, length: number): number {
  if (!(length > 0)) return 0.5;
  const min = Math.min(0.45, MIN_PANE_PX / length);
  return Math.max(Math.max(0.2, min), Math.min(1 - Math.max(0.2, min), pos / length));
}
