/**
 * Whiteboard Export Engine (v3 — SVG Vector & 2x Retina PNG Canvas)
 * =================================================================
 * Serializes whiteboard boards and elements to standalone vector SVG or high-resolution PNG.
 */

import type {
  Board,
  WhiteboardElement,
  StrokeElement,
  RectangleElement,
  EllipseElement,
  DiamondElement,
  TriangleElement,
  StarElement,
  CloudElement,
  LineElement,
  ArrowElement,
  TextElement,
  StickyElement,
  ImageElement,
  ConnectionElement,
  FillStyle,
  DashStyle,
} from "./types";
import { STICKY_COLORS, PEN_TYPE_PRESETS, getLinkTypeColor, getLinkTypeLabel, BOARD_BACKGROUNDS } from "./types";
import type { NotebookPage } from "./types";
import {
  getElementBounds,
  getElementCenter,
  getUnionBounds,
  getOptimalConnectionAnchors,
  getConnectionPath,
  getArrowheadPath,
} from "./geometry";
import { buildStrokePath } from "./stroke";
import { imageSvgMarkup, isUnedited } from "./imageEdit";
import { detectLineDir, markdownToPlainLines, resolveLineDir } from "./textParser";

/**
 * Baked writing direction for one exported line: an explicit override wins,
 * otherwise the same first-strong-character rule the canvas uses. SVG/PNG/PDF
 * all rasterize through this SVG in a browser, so one attribute covers them.
 */
function exportLineDir(
  lineDirs: Array<"ltr" | "rtl" | "auto"> | undefined,
  lineIndex: number,
  lineText: string
): "ltr" | "rtl" {
  const d = resolveLineDir(lineDirs, lineIndex);
  return d === "auto" ? detectLineDir(lineText) : d;
}
import {
  getBoardElements,
  getPages,
  getActivePage,
  isNotebook,
  pageSizeOf,
  backgroundForPage,
  resolvePageRange,
  formatPageSelection,
  PAGE_GAP,
} from "./notebook";

/** A 1-based, inclusive run of notebook pages. */
export interface PageRange {
  from: number;
  to: number;
}
import { blobToDataUrl, saveBlob, shareBlob } from "./share";
import type { ShareOutcome } from "./share";
import { zipSync } from "fflate";

/**
 * Packs finished export files into one .zip (batch sidebar export).
 * Filenames must already be unique — see exportFilename, which derives them
 * per board. Pure bytes in/out, so the sidebar's zip round-trips in node.
 */
export function zipExportFiles(files: Array<{ filename: string; data: Uint8Array }>): Uint8Array {
  const entries: Record<string, Uint8Array> = {};
  for (const f of files) entries[f.filename] = f.data;
  return zipSync(entries);
}

export { isNativeApp, canChooseApp, shareRoute, downloadBlob, saveBlob, shareBlob } from "./share";
export type { ShareOutcome, ShareRoute } from "./share";

/**
 * Every raster format the canvas can encode. JPEG and WEBP are here because
 * "export an image" means different things in different places - a mail client
 * that chokes on a 40 MB PNG takes the same notebook as a 2 MB JPEG happily.
 */
export type RasterFormat = "png" | "jpeg" | "webp";

export const RASTER_MIME: Record<RasterFormat, string> = {
  png: "image/png",
  jpeg: "image/jpeg",
  webp: "image/webp",
};

/** Every format an export can be written as. */
export type ExportFormat = RasterFormat | "svg" | "pdf";

export const EXPORT_EXTENSION: Record<ExportFormat, string> = {
  png: "png",
  jpeg: "jpg",
  webp: "webp",
  svg: "svg",
  pdf: "pdf",
};

/** JPEG and WEBP are lossy; 0.92 is the usual "you cannot see it" threshold. */
const LOSSY_QUALITY = 0.92;

export interface ExportOptions {
  background?: "white" | "dark" | "transparent";
  padding?: number;
  scale?: number;
  includeLocked?: boolean;
  /**
   * Notebooks only. "all" (the default) exports every page, "current" the page
   * on screen, and `{ from, to }` a 1-based inclusive range - "pages 4 to 9 of
   * this notebook", which is what you want when handing in one question of a
   * problem set. Whiteboards ignore it.
   *
   * Export used to read only the active page while the dialog counted every
   * page's elements, so a 20-page notebook advertised all of its content and
   * wrote out a single sheet.
   */
  pages?: "all" | "current" | PageRange | number[];
  /** Called as each sheet is rasterised, so the UI can show real progress. */
  onProgress?: ProgressFn;
}

/**
 * Progress while an export runs. A 40-page notebook takes long enough that a
 * button which simply sits there reads as a hang, so every page reports in.
 */
export interface ExportProgress {
  /** Sheets finished so far. */
  done: number;
  /** Sheets in total, 1 for a whiteboard. */
  total: number;
  /** A short line to show, e.g. "Rendering page 3 of 10". */
  label: string;
}

export type ProgressFn = (p: ExportProgress) => void;

/** What an export could not include, so the UI can say so instead of hiding it. */
export interface ExportReport {
  /** Pictures whose pixels were missing from IndexedDB, drawn as grey boxes. */
  missingImages: number;
  /** PDF-backed pages whose PDF could not be loaded, exported as plain paper. */
  missingPdfPages: number;
  /** Sheets exported (1 for a whiteboard). */
  pages: number;
}

function escapeXml(unsafe: string): string {
  if (!unsafe) return "";
  return unsafe
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

function getFillAndDash(
  fillStyle: string = "transparent",
  dashStyle: string = "solid",
  strokeColor: string = "#1e293b",
  fillColor: string = "transparent"
) {
  let fill = "transparent";
  if (fillStyle === "solid") fill = fillColor === "transparent" ? strokeColor : fillColor;
  else if (fillStyle === "semi") fill = fillColor === "transparent" ? `${strokeColor}33` : `${fillColor}40`;

  let strokeDasharray = "";
  if (dashStyle === "dashed") strokeDasharray = 'stroke-dasharray="8,6"';
  else if (dashStyle === "dotted") strokeDasharray = 'stroke-dasharray="3,4"';

  return { fill, strokeDasharray };
}

function getRotationTransform(el: WhiteboardElement): string {
  if (!el.rotation || el.rotation === 0) return "";
  const center = getElementCenter(el);
  const deg = (el.rotation * 180) / Math.PI;
  return `transform="rotate(${deg.toFixed(2)}, ${center.x.toFixed(2)}, ${center.y.toFixed(2)})"`;
}

/**
 * The transform the ON-SCREEN renderer wraps every element in:
 * `translate(x, y)` plus a rotation about the element's own centre.
 *
 * Most element types are written here with absolute coordinates already baked
 * in (a rect emits `x="${rect.x}"`), so they must NOT be wrapped. Strokes are
 * the exception: their points are stored RELATIVE to the element origin, which
 * is why they need the same translate the renderer applies.
 */
function localTransform(el: WhiteboardElement): string {
  const rotate =
    el.rotation && el.rotation !== 0
      ? ` rotate(${((el.rotation * 180) / Math.PI).toFixed(2)}, ${(getElementCenter(el).x - el.x).toFixed(2)}, ${(
          getElementCenter(el).y - el.y
        ).toFixed(2)})`
      : "";
  return `translate(${el.x}, ${el.y})${rotate}`;
}

/**
 * The SVG markup for a list of elements, in their own coordinates.
 *
 * Shared by whole-board export and per-page notebook export. `elements` is
 * also the lookup set for connections, so a connector only draws when both
 * ends are in the same exported frame.
 */
export function serializeElements(
  elements: WhiteboardElement[],
  background: "white" | "dark" | "transparent",
  customLinkTypes: Array<{ id: string; name: string; color: string }>,
  resolvedImages: Map<string, string> | undefined,
  stats: { missingImages: number },
  /**
   * Markup to use INSTEAD of the serializer for an element, or null to
   * serialize it. A capture hands in the canvas' own text boxes and notes,
   * so their wrapping matches the screen exactly.
   */
  override?: (el: WhiteboardElement) => string | null
): string {
  let svgElements = "";

  // Render elements in order
  for (const el of elements) {
    const replaced = override?.(el);
    if (replaced) {
      svgElements += `  ${replaced}\n`;
      continue;
    }
    const opacity = el.opacity ?? 1;
    const opacityAttr = opacity < 1 ? `opacity="${opacity.toFixed(2)}"` : "";
    const rot = getRotationTransform(el);

    switch (el.type) {
      case "stroke": {
        const str = el as StrokeElement;
        // ALWAYS derive the path from the points, exactly as the on-screen
        // renderer does. The legacy `str.path` cache froze a stroke's geometry
        // at draw time; it is stripped on load and must never be preferred
        // here, or an export could disagree with the screen.
        const pathData = buildStrokePath(str, false);
        if (pathData) {
          const preset = PEN_TYPE_PRESETS[str.strokeStyle] || PEN_TYPE_PRESETS.pen;
          const strokeOpacity = (preset.opacity ?? 1) * opacity;
          // Canvas applies mixBlendMode for multiply pens (highlighter);
          // mirror it so exports don't flatten to opaque.
          const blend = preset.mixBlendMode === "multiply" ? ' style="mix-blend-mode: multiply"' : "";
          // A stroke's points are stored RELATIVE to its origin, so the path
          // has to be placed by the same translate the renderer uses. Without
          // it every stroke on every page collapsed into the top-left corner
          // of the sheet and was clipped away - handwriting simply vanished
          // from exported PDFs while looking perfect on screen.
          svgElements += `  <g transform="${localTransform(str)}"><path d="${pathData}" fill="${escapeXml(
            str.color
          )}" opacity="${strokeOpacity.toFixed(2)}"${blend} /></g>\n`;
        }
        break;
      }

      case "rectangle": {
        const rect = el as RectangleElement;
        const { fill, strokeDasharray } = getFillAndDash(rect.fillStyle, rect.dashStyle, rect.strokeColor, rect.fillColor);
        const rx = rect.cornerRadius || 6;
        svgElements += `  <rect x="${rect.x}" y="${rect.y}" width="${Math.max(rect.width, 2)}" height="${Math.max(rect.height, 2)}" rx="${rx}" ry="${rx}" fill="${escapeXml(fill)}" stroke="${escapeXml(rect.strokeColor)}" stroke-width="${rect.strokeWidth || 2}" ${strokeDasharray} ${opacityAttr} ${rot} />\n`;
        break;
      }

      case "ellipse": {
        const ell = el as EllipseElement;
        const { fill, strokeDasharray } = getFillAndDash(ell.fillStyle, ell.dashStyle, ell.strokeColor, ell.fillColor);
        const rx = Math.max(ell.width / 2, 1);
        const ry = Math.max(ell.height / 2, 1);
        const cx = ell.x + rx;
        const cy = ell.y + ry;
        svgElements += `  <ellipse cx="${cx}" cy="${cy}" rx="${rx}" ry="${ry}" fill="${escapeXml(fill)}" stroke="${escapeXml(ell.strokeColor)}" stroke-width="${ell.strokeWidth || 2}" ${strokeDasharray} ${opacityAttr} ${rot} />\n`;
        break;
      }

      case "diamond": {
        const dia = el as DiamondElement;
        const { fill, strokeDasharray } = getFillAndDash(dia.fillStyle, dia.dashStyle, dia.strokeColor, dia.fillColor);
        const w = dia.width;
        const h = dia.height;
        const pts = `${dia.x + w / 2},${dia.y} ${dia.x + w},${dia.y + h / 2} ${dia.x + w / 2},${dia.y + h} ${dia.x},${dia.y + h / 2}`;
        svgElements += `  <polygon points="${pts}" fill="${escapeXml(fill)}" stroke="${escapeXml(dia.strokeColor)}" stroke-width="${dia.strokeWidth || 2}" ${strokeDasharray} ${opacityAttr} ${rot} />\n`;
        break;
      }

      case "triangle": {
        const tri = el as TriangleElement;
        const { fill, strokeDasharray } = getFillAndDash(tri.fillStyle, tri.dashStyle, tri.strokeColor, tri.fillColor);
        const w = tri.width;
        const h = tri.height;
        const pts = `${tri.x + w / 2},${tri.y} ${tri.x + w},${tri.y + h} ${tri.x},${tri.y + h}`;
        svgElements += `  <polygon points="${pts}" fill="${escapeXml(fill)}" stroke="${escapeXml(tri.strokeColor)}" stroke-width="${tri.strokeWidth || 2}" ${strokeDasharray} ${opacityAttr} ${rot} />\n`;
        break;
      }

      case "star": {
        const star = el as StarElement;
        const { fill, strokeDasharray } = getFillAndDash(star.fillStyle, star.dashStyle, star.strokeColor, star.fillColor);
        const cx = star.x + star.width / 2;
        const cy = star.y + star.height / 2;
        const spikes = 5;
        const outerR = Math.min(star.width, star.height) / 2;
        const innerR = outerR * 0.45;
        let pts = "";
        for (let i = 0; i < spikes * 2; i++) {
          const r = i % 2 === 0 ? outerR : innerR;
          const angle = (i * Math.PI) / spikes - Math.PI / 2;
          const px = cx + Math.cos(angle) * r;
          const py = cy + Math.sin(angle) * r;
          pts += `${px.toFixed(1)},${py.toFixed(1)} `;
        }
        svgElements += `  <polygon points="${pts.trim()}" fill="${escapeXml(fill)}" stroke="${escapeXml(star.strokeColor)}" stroke-width="${star.strokeWidth || 2}" ${strokeDasharray} ${opacityAttr} ${rot} />\n`;
        break;
      }

      case "cloud": {
        const cld = el as CloudElement;
        const { fill, strokeDasharray } = getFillAndDash(cld.fillStyle, cld.dashStyle, cld.strokeColor, cld.fillColor);
        const w = cld.width;
        const h = cld.height;
        const r = Math.min(w, h) * 0.2;
        const d = `M ${cld.x + r * 1.5},${cld.y + h - r} A ${r},${r} 0 0,1 ${cld.x + r},${cld.y + h * 0.5} A ${r * 1.2},${r * 1.2} 0 0,1 ${cld.x + w * 0.35},${cld.y + r} A ${r * 1.5},${r * 1.5} 0 0,1 ${cld.x + w * 0.7},${cld.y + r * 1.2} A ${r},${r} 0 0,1 ${cld.x + w - r * 0.5},${cld.y + h * 0.55} A ${r * 0.9},${r * 0.9} 0 0,1 ${cld.x + w - r},${cld.y + h - r} Z`;
        svgElements += `  <path d="${d}" fill="${escapeXml(fill)}" stroke="${escapeXml(cld.strokeColor)}" stroke-width="${cld.strokeWidth || 2}" ${strokeDasharray} ${opacityAttr} ${rot} />\n`;
        break;
      }

      case "line": {
        const line = el as LineElement;
        let strokeDasharray = "";
        if (line.dashStyle === "dashed") strokeDasharray = 'stroke-dasharray="8,6"';
        else if (line.dashStyle === "dotted") strokeDasharray = 'stroke-dasharray="3,4"';
        svgElements += `  <line x1="${line.x}" y1="${line.y}" x2="${line.x + line.x2}" y2="${line.y + line.y2}" stroke="${escapeXml(line.strokeColor)}" stroke-width="${line.strokeWidth || 2}" stroke-linecap="round" ${strokeDasharray} ${opacityAttr} ${rot} />\n`;
        break;
      }

      case "arrow": {
        const arr = el as ArrowElement;
        let strokeDasharray = "";
        if (arr.dashStyle === "dashed") strokeDasharray = 'stroke-dasharray="8,6"';
        else if (arr.dashStyle === "dotted") strokeDasharray = 'stroke-dasharray="3,4"';
        const head = getArrowheadPath(
          arr.x + arr.x2,
          arr.y + arr.y2,
          arr.x,
          arr.y,
          arr.endArrowhead || "arrow",
          arr.arrowheadSize || 12
        );
        svgElements += `  <g ${opacityAttr} ${rot}>\n`;
        svgElements += `    <line x1="${arr.x}" y1="${arr.y}" x2="${arr.x + arr.x2}" y2="${arr.y + arr.y2}" stroke="${escapeXml(arr.strokeColor)}" stroke-width="${arr.strokeWidth || 2}" stroke-linecap="round" ${strokeDasharray} />\n`;
        if (head) {
          svgElements += `    <path d="${head.path}" fill="${escapeXml(arr.strokeColor)}" stroke="${head.stroke || "none"}" />\n`;
        }
        svgElements += `  </g>\n`;
        break;
      }

      case "text": {
        const txt = el as TextElement;
        const fontSize = txt.fontSize || 18;
        const fontColor = txt.color || (background === "dark" ? "#f4f4f5" : "#1e293b");
        // The lines as the canvas shows them: markdown markers become their
        // visual form (☐, •, headings) and [[WikiLink|alias]] its alias.
        const lines = markdownToPlainLines(txt.text || "");
        // Card mode draws the same box the canvas does, and its text sits
        // inside the padding.
        const isCard = !!(txt.cardMode || (txt.backgroundColor && txt.backgroundColor !== "transparent"));
        const pad = isCard ? txt.padding || 12 : 0;
        // Anchor x must account for the element width — the on-canvas renderer
        // centers/right-aligns inside the text box, not at its left edge.
        const anchorX =
          txt.align === "center"
            ? txt.x + txt.width / 2
            : txt.align === "right"
            ? txt.x + txt.width - pad
            : txt.x + pad;
        svgElements += `  <g ${opacityAttr} ${rot}>\n`;
        if (isCard) {
          svgElements += `    <rect x="${txt.x}" y="${txt.y}" width="${txt.width}" height="${txt.height}" rx="${txt.borderRadius || 8}" ry="${txt.borderRadius || 8}" fill="${escapeXml(txt.backgroundColor || "#ffffff")}" stroke="${escapeXml(txt.borderColor || "rgba(0,0,0,0.12)")}" stroke-width="1.5" />\n`;
        }
        let yPos = txt.y + pad;
        lines.forEach((line) => {
          const size = fontSize * line.scale;
          yPos += size * 1.35;
          const weight = Math.max(line.weight ?? 0, Number(txt.fontWeight) || 400);
          svgElements += `    <text x="${anchorX.toFixed(2)}" y="${yPos.toFixed(2)}" fill="${escapeXml(fontColor)}" font-family="${escapeXml(txt.fontFamily || "Inter, system-ui, sans-serif")}" font-size="${size.toFixed(2)}" font-weight="${weight}" text-anchor="${txt.align === "center" ? "middle" : txt.align === "right" ? "end" : "start"}" direction="${exportLineDir(txt.lineDirs, line.lineIndex, line.text)}" style="unicode-bidi:embed" xml:space="preserve">${escapeXml(line.text)}</text>\n`;
        });
        svgElements += `  </g>\n`;
        break;
      }

      case "sticky": {
        const st = el as StickyElement;
        const colors = STICKY_COLORS[st.color] || STICKY_COLORS.yellow;
        const fontSize = st.fontSize || 16;
        const lines = markdownToPlainLines(st.text || "");
        const pad = 14;
        const stickyAnchorX =
          st.align === "center"
            ? st.x + st.width / 2
            : st.align === "right"
            ? st.x + st.width - pad
            : st.x + pad;
        svgElements += `  <g ${opacityAttr} ${rot}>\n`;
        svgElements += `    <rect x="${st.x}" y="${st.y}" width="${st.width}" height="${st.height}" rx="8" ry="8" fill="${escapeXml(colors.bg)}" stroke="${escapeXml(colors.border)}" stroke-width="1.5" />\n`;
        let stickyY = st.y + 24;
        lines.forEach((line) => {
          const size = fontSize * line.scale;
          stickyY += size * 1.3;
          if (stickyY < st.y + st.height - 8) {
            svgElements += `    <text x="${stickyAnchorX.toFixed(2)}" y="${stickyY.toFixed(2)}" fill="${escapeXml(colors.text)}" font-family="Inter, system-ui, sans-serif" font-size="${size.toFixed(2)}"${line.weight ? ` font-weight="${line.weight}"` : ""} text-anchor="${st.align === "center" ? "middle" : st.align === "right" ? "end" : "start"}" direction="${exportLineDir(st.lineDirs, line.lineIndex, line.text)}" style="unicode-bidi:embed" xml:space="preserve">${escapeXml(line.text)}</text>\n`;
          }
        });
        svgElements += `  </g>\n`;
        break;
      }

      case "image": {
        const img = el as ImageElement;
        // An unresolved asset ref would write a href no viewer can load, so the
        // image is omitted rather than exported broken.
        const href = resolvedImages?.get(img.src) ?? img.src;
        if (href && !href.startsWith("asset:") && !isUnedited(img)) {
          // Cropped, flipped, filtered or framed: the same layout the canvas draws.
          svgElements += `  <g ${opacityAttr} ${rot}>${imageSvgMarkup(img, href)}</g>\n`;
        } else if (href && !href.startsWith("asset:")) {
          svgElements += `  <image href="${escapeXml(href)}" x="${img.x}" y="${img.y}" width="${img.width}" height="${img.height}" preserveAspectRatio="xMidYMid meet" ${opacityAttr} ${rot} />\n`;
        } else {
          // The pixels are gone (IndexedDB cleared, or never stored). A grey
          // placeholder keeps the layout honest, and it is COUNTED so the user
          // is told, instead of finding a hole in the printout later.
          stats.missingImages++;
          svgElements += `  <rect x="${img.x}" y="${img.y}" width="${img.width}" height="${img.height}" rx="6" fill="#e4e4e7" stroke="#a1a1aa" ${opacityAttr} ${rot} />\n`;
        }
        break;
      }

      case "connection": {
        const conn = el as ConnectionElement;
        const sourceEl = elements.find((e) => e.id === conn.source.elementId);
        const targetEl = elements.find((e) => e.id === conn.target.elementId);
        if (sourceEl && targetEl) {
          const { source, target } = getOptimalConnectionAnchors(sourceEl, targetEl, conn.source.anchor, conn.target.anchor);
          const pathD = getConnectionPath(source, target, conn.routing || "curved");
          const connColor = getLinkTypeColor(conn.linkType, customLinkTypes);
          const endHead = getArrowheadPath(
            target.x,
            target.y,
            target.x + target.nx * 20,
            target.y + target.ny * 20,
            conn.endArrowhead || "arrow",
            12
          );
          const startHead =
            conn.startArrowhead && conn.startArrowhead !== "none"
              ? getArrowheadPath(
                  source.x,
                  source.y,
                  source.x - source.nx * 20,
                  source.y - source.ny * 20,
                  conn.startArrowhead,
                  12
                )
              : null;

          let strokeDasharray = "";
          if (conn.dashStyle === "dashed") strokeDasharray = 'stroke-dasharray="6,4"';
          else if (conn.dashStyle === "dotted") strokeDasharray = 'stroke-dasharray="2,4"';

          svgElements += `  <g ${opacityAttr}>\n`;
          svgElements += `    <path d="${pathD}" fill="none" stroke="${escapeXml(connColor)}" stroke-width="${conn.strokeWidth || 2.5}" stroke-linecap="round" ${strokeDasharray} />\n`;
          if (startHead) {
            svgElements += `    <path d="${startHead.path}" fill="${escapeXml(connColor)}" stroke="none" />\n`;
          }
          if (endHead) {
            svgElements += `    <path d="${endHead.path}" fill="${escapeXml(connColor)}" stroke="none" />\n`;
          }

          const label = conn.label ?? getLinkTypeLabel(conn.linkType, customLinkTypes);
          if (label) {
            const pillLabel = label.length > 40 ? `${label.slice(0, 39)}…` : label;
            const midX = (source.x + target.x) / 2;
            const midY = (source.y + target.y) / 2;
            const rectW = pillLabel.length * 8.2 + 24;
            svgElements += `    <g transform="translate(${midX}, ${midY})">\n`;
            svgElements += `      <rect x="${-(rectW / 2)}" y="-11" width="${rectW}" height="22" rx="11" fill="${background === "dark" ? "#27272a" : "#ffffff"}" stroke="${connColor}" stroke-width="1.5" />\n`;
            svgElements += `      <text x="0" y="3.5" fill="${escapeXml(connColor)}" text-anchor="middle" font-size="11" font-weight="600" font-family="Inter, system-ui, sans-serif">${escapeXml(pillLabel)}</text>\n`;
            svgElements += `    </g>\n`;
          }
          svgElements += `  </g>\n`;
        }
        break;
      }
    }
  }

  return svgElements;
}

/**
 * Serializes a whiteboard board into a standalone, valid XML SVG string.
 */
/**
 * Image pixels now live in IndexedDB, referenced as `asset:<id>` (see
 * lib/whiteboard/imagestore.ts). An exported SVG is a standalone file, so
 * those references mean nothing outside the app - every image would come out
 * blank. This resolves them to real data URLs first.
 */
export async function resolveExportImages(board: Board): Promise<Map<string, string>> {
  const { isAssetRef, assetIdOf, loadImage } = await import("./imagestore");
  const { allElements } = await import("./notebook");

  const refs = new Set<string>();
  for (const el of allElements(board)) {
    const src = (el as { src?: string }).src;
    if (src && isAssetRef(src)) refs.add(src);
  }

  const out = new Map<string, string>();
  await Promise.all(
    [...refs].map(async (ref) => {
      const url = await loadImage(assetIdOf(ref));
      if (url) out.set(ref, url);
    })
  );
  return out;
}

/**
 * PDF page rasters for notebook pages that sit on an imported PDF, keyed by
 * page id. Without these an annotated lecture exports as the annotations alone,
 * floating on blank paper, which is useless as a study copy.
 *
 * A page whose PDF bytes are missing is left out of the map and counted by the
 * caller, so the export is still produced and the user is told.
 */
export async function resolvePageBackdrops(
  pages: NotebookPage[],
  targetWidth: number,
  /** Raster density per world unit. A capture asks for up to 3 so a small
   *  crop of a lecture slide stays as sharp as the screen showed it. */
  dpr = 2
): Promise<Map<string, string>> {
  const out = new Map<string, string>();
  const withPdf = pages.filter((p) => p.pdf);
  if (withPdf.length === 0) return out;

  const { getPdf } = await import("./pdfstore");
  const { openPdf, renderPdfPage } = await import("./pdf");
  type Doc = Awaited<ReturnType<typeof openPdf>>;
  const docs = new Map<string, Doc | null>();

  for (const page of withPdf) {
    const ref = page.pdf!;
    if (!docs.has(ref.docId)) {
      try {
        const stored = await getPdf(ref.docId);
        docs.set(ref.docId, stored ? await openPdf(stored.bytes) : null);
      } catch {
        docs.set(ref.docId, null);
      }
    }
    const doc = docs.get(ref.docId);
    if (!doc) continue;
    try {
      out.set(page.id, await renderPdfPage(doc, ref.pageNumber, targetWidth, dpr));
    } catch {
      /* a page that will not render exports as plain paper, and is counted */
    }
  }
  for (const doc of docs.values()) {
    try {
      // Frees the rendered pages; the document itself is garbage collected.
      await doc?.cleanup();
    } catch {
      /* already torn down */
    }
  }
  return out;
}

/** The pages an export covers, per `options.pages`. */
function exportPages(board: Board, options: ExportOptions): NotebookPage[] {
  const scope = options.pages;
  if (scope === "current") {
    const active = getActivePage(board);
    return active ? [active] : [];
  }
  const all = getPages(board);
  // An explicit list of 1-based page numbers - what the page picker produces.
  if (Array.isArray(scope)) {
    return scope
      .filter((n) => Number.isFinite(n) && n >= 1 && n <= all.length)
      .sort((a, b) => a - b)
      .map((n) => all[n - 1]);
  }
  if (scope && typeof scope === "object") {
    return resolvePageRange(all.length, scope.from, scope.to).indices.map((i) => all[i]);
  }
  return all;
}

/**
 * Paper colour and ruling for one sheet, matching what the canvas draws.
 * `page` null means a whiteboard's own paper.
 */
export function paperFor(board: Board, page: NotebookPage | null, background: "white" | "dark" | "transparent") {
  const bg = backgroundForPage(board, page) ?? board.background;
  const dark = background === "dark";
  const preset = BOARD_BACKGROUNDS.find((x) => x.id === bg?.color);
  const chosen = preset ? (dark ? preset.dark : preset.light) : bg?.color || "";
  return {
    fill: chosen || (dark ? "#18181b" : "#ffffff"),
    // zinc-300 / zinc-700: the colours the on-screen paper pattern uses.
    ink: dark ? "#3f3f46" : "#d4d4d8",
    pattern: bg?.pattern ?? "dots",
    size: Math.max(6, Math.min(120, bg?.size ?? 24)),
  };
}

/**
 * The ruling as an SVG `<pattern>` in world units, tiled from the origin of
 * whatever user space references it - a sheet's top-left corner, or a
 * whiteboard's world origin, exactly as the canvas tiles it. Empty for plain
 * paper.
 */
export function paperPatternSvg(id: string, paper: ReturnType<typeof paperFor>): string {
  if (paper.pattern === "plain") return "";
  const z = paper.size;
  const shape =
    paper.pattern === "dots"
      ? `<circle cx="${z / 2}" cy="${z / 2}" r="${Math.max(0.5, z / 20)}" fill="${paper.ink}" />`
      : paper.pattern === "grid"
      ? `<path d="M ${z} 0 L 0 0 0 ${z}" fill="none" stroke="${paper.ink}" stroke-width="0.8" />`
      : `<path d="M 0 ${z} L ${z} ${z}" fill="none" stroke="${paper.ink}" stroke-width="0.8" />`;
  return `<pattern id="${id}" x="0" y="0" width="${z}" height="${z}" patternUnits="userSpaceOnUse">${shape}</pattern>`;
}

/**
 * Which layers of a sheet to paint. Export wants all of them; a capture with
 * "white" or "no" background drops the paper and ruling but, for white, keeps
 * the PDF page - that is content the user is looking at, not decoration.
 */
export interface SheetLayers {
  /** false: no paper at all; a string: paint this colour instead of the page's. */
  paper?: false | string;
  ruling?: boolean;
  backdrop?: boolean;
  /** Which of the page's elements to draw (a capture of the selection only). */
  keep?: (el: WhiteboardElement) => boolean;
  /** Replacement markup per element; see `serializeElements`. */
  override?: (el: WhiteboardElement) => string | null;
}

/**
 * One sheet as an SVG group, drawn at `offsetY`.
 *
 * Everything is CLIPPED to the sheet. Ink from before sheets were enforced can
 * sit outside the page; on screen it is invisible past the paper edge, and an
 * export that included it came out as a smear the user never saw.
 */
export function sheetSvg(
  board: Board,
  page: NotebookPage,
  index: number,
  offsetY: number,
  width: number,
  height: number,
  options: ExportOptions,
  customLinkTypes: Array<{ id: string; name: string; color: string }>,
  resolvedImages: Map<string, string> | undefined,
  backdrops: Map<string, string> | undefined,
  report: ExportReport,
  outlined: boolean,
  layers: SheetLayers = {}
): string {
  const background = options.background ?? "white";
  const includeLocked = options.includeLocked ?? true;
  const paper = paperFor(board, page, background);
  const clipId = `pn-sheet-${index}`;
  const patId = `pn-paper-${index}`;
  const wantBackdrop = layers.backdrop !== false;
  const backdrop = wantBackdrop ? backdrops?.get(page.id) : undefined;
  if (wantBackdrop && page.pdf && !backdrop) report.missingPdfPages++;

  // Ruling goes OVER a PDF scan when the page asks for it, matching the
  // canvas. PDF notebooks default to plain, so scans stay clean unless you
  // pick a ruling for that page.
  const pattern = layers.ruling === false ? "" : paperPatternSvg(patId, paper);
  const patternRect = pattern
    ? `<rect x="0" y="0" width="${width}" height="${height}" fill="url(#${patId})" />`
    : "";
  const fill = layers.paper === false ? null : layers.paper ?? paper.fill;

  const elements = (page.elements ?? []).filter(
    (el) => (includeLocked || !el.locked) && (!layers.keep || layers.keep(el))
  );
  const body = serializeElements(elements, background, customLinkTypes, resolvedImages, report, layers.override);

  // The PDF page is letterboxed ("meet"), never stretched, exactly as
  // PdfPageLayer draws it on the canvas: a slide inserted into an A4 notebook
  // keeps its own proportions in the file too.
  return `  <g transform="translate(0, ${offsetY})">
    <defs><clipPath id="${clipId}"><rect x="0" y="0" width="${width}" height="${height}" /></clipPath>${pattern}</defs>
    ${fill ? `<rect x="0" y="0" width="${width}" height="${height}" fill="${fill}" />` : ""}
    ${backdrop ? `<image href="${escapeXml(backdrop)}" x="0" y="0" width="${width}" height="${height}" preserveAspectRatio="xMidYMid meet" />` : ""}${patternRect}
    <g clip-path="url(#${clipId})">
${body}    </g>
    ${outlined ? `<rect x="0" y="0" width="${width}" height="${height}" fill="none" stroke="#d4d4d8" stroke-width="1" />` : ""}
  </g>
`;
}

// No webfont @import here. An SVG rasterised through an Image cannot load
// external resources at all - the rule was silently dropped every time - and
// reaching for fonts.googleapis.com would break the app's offline promise on
// a tablet with no connection. The stack below resolves locally on every
// platform the app ships to.
export const SVG_HEAD_STYLE = `  <defs>
    <style>
      text { font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; }
    </style>
  </defs>`;

/**
 * Builds the export SVG and reports its size and anything left out.
 *
 * A notebook exports as its SHEETS - every page by default, stacked with the
 * same gap as the scroll view - each clipped to the paper with its ruling and
 * any PDF underneath. A whiteboard exports the bounding box of its content, as
 * before.
 */
export function buildExportSvg(
  board: Board,
  options: ExportOptions = {},
  customLinkTypes: Array<{ id: string; name: string; color: string }> = [],
  resolvedImages?: Map<string, string>,
  backdrops?: Map<string, string>
): { svg: string; width: number; height: number; report: ExportReport } {
  const background = options.background ?? "white";
  const report: ExportReport = { missingImages: 0, missingPdfPages: 0, pages: 1 };
  const bgFill = background === "white" ? "#ffffff" : background === "dark" ? "#18181b" : "transparent";

  if (isNotebook(board)) {
    const { width, height } = pageSizeOf(board);
    const pages = exportPages(board, options);
    report.pages = pages.length;
    const count = Math.max(1, pages.length);
    const totalH = count * height + (count - 1) * PAGE_GAP;
    const stacked = pages.length > 1;

    let sheets = "";
    pages.forEach((page, i) => {
      sheets += sheetSvg(
        board, page, i, i * (height + PAGE_GAP), width, height,
        options, customLinkTypes, resolvedImages, backdrops, report, stacked
      );
    });

    const svg = `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${width} ${totalH}" width="${width}" height="${totalH}">
${SVG_HEAD_STYLE}
  ${stacked && bgFill !== "transparent" ? `<rect x="0" y="0" width="${width}" height="${totalH}" fill="${bgFill}" />` : ""}
${sheets}</svg>`;
    return { svg, width, height: totalH, report };
  }

  const padding = options.padding ?? 40;
  const includeLocked = options.includeLocked ?? true;
  const elements = getBoardElements(board).filter((el) => includeLocked || !el.locked);

  const rawBounds = getUnionBounds(elements);
  const bounds = rawBounds ?? { x: -400, y: -300, width: 800, height: 600 };
  const exportX = bounds.x - padding;
  const exportY = bounds.y - padding;
  const exportW = Math.max(bounds.width + padding * 2, 100);
  const exportH = Math.max(bounds.height + padding * 2, 100);

  const svgElements = serializeElements(elements, background, customLinkTypes, resolvedImages, report);

  const svg = `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="${exportX.toFixed(2)} ${exportY.toFixed(2)} ${exportW.toFixed(2)} ${exportH.toFixed(2)}" width="${exportW.toFixed(2)}" height="${exportH.toFixed(2)}">
${SVG_HEAD_STYLE}
  ${bgFill !== "transparent" ? `<rect x="${exportX.toFixed(2)}" y="${exportY.toFixed(2)}" width="${exportW.toFixed(2)}" height="${exportH.toFixed(2)}" fill="${bgFill}" />\n` : ""}
${svgElements}</svg>`;
  return { svg, width: exportW, height: exportH, report };
}

export function exportBoardToSvg(
  board: Board,
  options: ExportOptions = {},
  customLinkTypes: Array<{ id: string; name: string; color: string }> = [],
  /** `asset:<id>` -> data URL, from `resolveExportImages`. */
  resolvedImages?: Map<string, string>,
  /** page id -> PDF raster, from `resolvePageBackdrops`. */
  backdrops?: Map<string, string>
): string {
  return buildExportSvg(board, options, customLinkTypes, resolvedImages, backdrops).svg;
}

/** Everything an export needs from IndexedDB, fetched once. */
async function resolveExportAssets(board: Board, options: ExportOptions) {
  const images = await resolveExportImages(board);
  const backdrops = isNotebook(board)
    ? await resolvePageBackdrops(exportPages(board, options), pageSizeOf(board).width)
    : new Map<string, string>();
  return { images, backdrops };
}

/**
 * Canvas limits. Desktop Chrome allows ~16k px a side, but an Android WebView
 * gives out far earlier on AREA - a 30-page notebook stacked at 2x is ~1600 x
 * 70000 px and simply produces a blank or failed canvas. The scale is lowered
 * to fit rather than failing.
 */
const MAX_CANVAS_SIDE = 16000;
const MAX_CANVAS_AREA = 40_000_000;

export function fitScale(width: number, height: number, wanted: number): number {
  let s = wanted;
  s = Math.min(s, MAX_CANVAS_SIDE / Math.max(width, height, 1));
  s = Math.min(s, Math.sqrt(MAX_CANVAS_AREA / Math.max(width * height, 1)));
  return Math.max(0.1, s);
}

/** Draws an SVG string onto a canvas and returns it as a PNG. */
export function rasterizeSvg(
  svgString: string,
  width: number,
  height: number,
  scale: number,
  background: "white" | "dark" | "transparent",
  format: RasterFormat = "png",
  /**
   * Load the SVG from a data: URL instead of a blob: URL. Chrome taints the
   * canvas when a BLOB-loaded SVG contains a <foreignObject> (HTML), which
   * makes toBlob throw; the same SVG from a data URL stays exportable. Only
   * a capture carries HTML, so exports keep the cheaper blob URL.
   */
  viaDataUrl = false
): Promise<Blob> {
  const s = fitScale(width, height, scale);
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.round(width * s));
  canvas.height = Math.max(1, Math.round(height * s));
  const ctx = canvas.getContext("2d");
  if (!ctx) return Promise.reject(new Error("Could not create 2D canvas context for PNG export"));

  const url = viaDataUrl
    ? `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svgString)}`
    : URL.createObjectURL(new Blob([svgString], { type: "image/svg+xml;charset=utf-8" }));
  return new Promise<Blob>((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      try {
        // JPEG cannot store transparency: without a painted background the
        // encoder fills it black, so ink and paper both disappear.
        const opaque = background !== "transparent" || format === "jpeg";
        if (opaque) {
          ctx.fillStyle = background === "dark" ? "#18181b" : "#ffffff";
          ctx.fillRect(0, 0, canvas.width, canvas.height);
        }
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        URL.revokeObjectURL(url);
        canvas.toBlob(
          (blob) => {
            if (!blob) {
              reject(new Error("Canvas toBlob failed"));
              return;
            }
            // A browser that cannot encode WEBP silently hands back a PNG.
            // Saying so beats a file whose contents do not match its name.
            if (blob.type && blob.type !== RASTER_MIME[format]) {
              reject(new Error(`This browser cannot write ${format.toUpperCase()} images. Try PNG.`));
              return;
            }
            resolve(blob);
          },
          RASTER_MIME[format],
          format === "png" ? undefined : LOSSY_QUALITY
        );
      } catch (err) {
        URL.revokeObjectURL(url);
        reject(err);
      }
    };
    img.onerror = (err) => {
      URL.revokeObjectURL(url);
      reject(new Error(`Failed to load SVG into image for rasterization: ${err}`));
    };
    img.src = url;
  });
}

/** Raster export (PNG/JPEG/WEBP) plus what it had to leave out. */
export async function exportBoardToRasterWithReport(
  board: Board,
  options: ExportOptions = {},
  customLinkTypes: Array<{ id: string; name: string; color: string }> = [],
  format: RasterFormat = "png"
): Promise<{ blob: Blob; report: ExportReport }> {
  options.onProgress?.({ done: 0, total: 1, label: "Rendering" });
  const { images, backdrops } = await resolveExportAssets(board, options);
  const built = buildExportSvg(board, options, customLinkTypes, images, backdrops);
  await yieldToPaint();
  const blob = await rasterizeSvg(
    built.svg,
    built.width,
    built.height,
    options.scale ?? 2,
    options.background ?? "white",
    format
  );
  options.onProgress?.({ done: 1, total: 1, label: "Finishing" });
  return { blob, report: built.report };
}

/** PNG export plus what it had to leave out. */
export async function exportBoardToPngWithReport(
  board: Board,
  options: ExportOptions = {},
  customLinkTypes: Array<{ id: string; name: string; color: string }> = []
): Promise<{ blob: Blob; report: ExportReport }> {
  return exportBoardToRasterWithReport(board, options, customLinkTypes, "png");
}

/**
 * Rasterizes a board to a high-resolution PNG. A notebook comes out as its
 * pages stacked top to bottom.
 */
export async function exportBoardToPng(
  board: Board,
  options: ExportOptions = {},
  customLinkTypes: Array<{ id: string; name: string; color: string }> = []
): Promise<Blob> {
  return (await exportBoardToPngWithReport(board, options, customLinkTypes)).blob;
}

/**
 * A filename that every target accepts.
 *
 * Android's share sheet, the Windows file dialog and ext4 disagree about what
 * is legal, so this keeps to the intersection. The page range is part of the
 * name on purpose: three exports of one notebook otherwise land in Downloads
 * as three files nobody can tell apart.
 */
export function exportFilename(board: Board, format: ExportFormat, options: ExportOptions = {}): string {
  const base =
    (board.name || "whiteboard").replace(/[^a-z0-9-_ ]/gi, "_").trim().replace(/ +/g, "_") || "whiteboard";
  let suffix = "";
  const scope = options.pages;
  if (isNotebook(board)) {
    if (scope === "current") {
      const activeId = getActivePage(board)?.id;
      const i = getPages(board).findIndex((p) => p.id === activeId);
      if (i >= 0) suffix = `_p${i + 1}`;
    } else if (Array.isArray(scope)) {
      const all = getPages(board).length;
      const chosen = scope.filter((n) => n >= 1 && n <= all);
      // Only name the pages when it is a subset worth distinguishing, and keep
      // it short: a 40-page pick would otherwise produce an unusable filename.
      if (chosen.length > 0 && chosen.length < all) {
        const label = formatPageSelection(chosen).replace(/,\s*/g, "_");
        suffix = label.length <= 24 ? `_p${label}` : `_${chosen.length}pages`;
      }
    } else if (scope && typeof scope === "object") {
      const r = resolvePageRange(getPages(board).length, scope.from, scope.to);
      suffix = r.from === r.to ? `_p${r.from}` : `_p${r.from}-${r.to}`;
    }
  }
  return `${base}${suffix}.${EXPORT_EXTENSION[format]}`;
}

/** Builds the file for any format, without deciding where it goes. */
export async function buildExportBlob(
  board: Board,
  format: ExportFormat,
  options: ExportOptions = {},
  customLinkTypes: Array<{ id: string; name: string; color: string }> = []
): Promise<{ blob: Blob; report: ExportReport; filename: string }> {
  const filename = exportFilename(board, format, options);
  if (format === "svg") {
    const { images, backdrops } = await resolveExportAssets(board, options);
    const built = buildExportSvg(board, options, customLinkTypes, images, backdrops);
    return {
      blob: new Blob([built.svg], { type: "image/svg+xml;charset=utf-8" }),
      report: built.report,
      filename,
    };
  }
  if (format === "pdf") {
    const { blob, report } = await exportBoardToPdfWithReport(board, options, customLinkTypes);
    return { blob, report, filename };
  }
  const { blob, report } = await exportBoardToRasterWithReport(board, options, customLinkTypes, format);
  return { blob, report, filename };
}

/**
 * Exports and delivers a board in one call.
 *
 * `destination` is the user's choice between "put it in my Downloads" and
 * "let me pick an app", and the outcome comes back so the UI can report what
 * really happened - including that they dismissed the share sheet.
 */
export async function exportBoard(
  board: Board,
  format: ExportFormat,
  options: ExportOptions = {},
  customLinkTypes: Array<{ id: string; name: string; color: string }> = [],
  destination: "save" | "share" = "save"
): Promise<{ report: ExportReport; outcome: ShareOutcome; filename: string }> {
  const { blob, report, filename } = await buildExportBlob(board, format, options, customLinkTypes);
  const outcome =
    destination === "share" ? await shareBlob(blob, filename, board.name) : await saveBlob(blob, filename);
  return { report, outcome, filename };
}

/**
 * Exports and downloads SVG vector file.
 */
export async function downloadSvg(
  board: Board,
  options: ExportOptions = {},
  filename?: string,
  customLinkTypes: Array<{ id: string; name: string; color: string }> = []
): Promise<ExportReport> {
  const { images, backdrops } = await resolveExportAssets(board, options);
  const built = buildExportSvg(board, options, customLinkTypes, images, backdrops);
  const blob = new Blob([built.svg], { type: "image/svg+xml;charset=utf-8" });
  const safeName = (filename || board.name || "whiteboard").replace(/[^a-z0-9-_]/gi, "_");
  await saveBlob(blob, `${safeName}.svg`);
  return built.report;
}

/**
 * Exports and downloads PNG raster file.
 */
export async function downloadPng(
  board: Board,
  options: ExportOptions = {},
  filename?: string,
  customLinkTypes: Array<{ id: string; name: string; color: string }> = []
): Promise<ExportReport> {
  const { blob, report } = await exportBoardToPngWithReport(board, options, customLinkTypes);
  const safeName = (filename || board.name || "whiteboard").replace(/[^a-z0-9-_]/gi, "_");
  await saveBlob(blob, `${safeName}.png`);
  return report;
}

// ---------------------------------------------------------------------------
// PDF
// ---------------------------------------------------------------------------

/**
 * Largest page side most PDF viewers will open (200in at 72pt/in). A big
 * whiteboard can exceed it, so the page is scaled down to fit rather than
 * producing a file that silently fails to render.
 */
const PDF_MAX_POINTS = 14400;

/**
 * Yields to the browser between sheets.
 *
 * Rasterising is synchronous enough to starve the main thread, which freezes
 * the very progress bar that is meant to show the export moving - on a tablet
 * it reads as the app having hung. One frame between pages costs nothing and
 * keeps the UI alive.
 */
function yieldToPaint(): Promise<void> {
  return new Promise((resolve) => {
    let settled = false;
    const finish = () => {
      if (settled) return;
      settled = true;
      resolve();
    };
    // requestAnimationFrame paints before the next frame, which is what makes
    // the progress bar actually move - but it NEVER fires while the document
    // is hidden: a backgrounded tab, a locked tablet, or the Android app
    // sitting behind its own share sheet. Waiting on it alone deadlocks the
    // export exactly when the user has looked away. A timer races it so the
    // work always continues, and whichever arrives first wins.
    if (typeof requestAnimationFrame === "function") requestAnimationFrame(finish);
    setTimeout(finish, 32);
  });
}

/**
 * Exports the board as a PDF.
 *
 * A notebook gets ONE PDF PAGE PER SHEET, each at the sheet's own size - the
 * thing you print or hand in. A whiteboard is a single page sized to the
 * drawing.
 *
 * Pages carry a raster image rather than vector art. Vector would come from the
 * SVG, but the highlighter pens rely on `mix-blend-mode`, which SVG-to-PDF
 * converters do not reproduce faithfully. SVG export already covers the vector
 * case, so PDF optimises for looking exactly like the board. Each page is 1:1
 * in points while its image is `scale` times denser, so it stays sharp printed.
 */
export async function exportBoardToPdfWithReport(
  board: Board,
  options: ExportOptions = {},
  customLinkTypes: Array<{ id: string; name: string; color: string }> = []
): Promise<{ blob: Blob; report: ExportReport }> {
  // A transparent page is meaningless here: a PDF viewer paints it over its
  // own background, so dark ink can land on a dark page and vanish.
  const background = options.background === "transparent" ? "white" : options.background ?? "white";
  const scale = options.scale ?? 2;
  const opts: ExportOptions = { ...options, background };
  const { images, backdrops } = await resolveExportAssets(board, opts);
  const { jsPDF } = await import("jspdf");

  // Each entry is one PDF page: the SVG to rasterise and its size in points.
  const sheets: Array<{ svg: string; width: number; height: number }> = [];
  const report: ExportReport = { missingImages: 0, missingPdfPages: 0, pages: 0 };

  if (isNotebook(board)) {
    for (const page of exportPages(board, opts)) {
      // Build each sheet on its own, as a one-page notebook, so it is exactly
      // the paper with nothing of its neighbours.
      const single: Board = { ...board, pages: [page], activePageId: page.id };
      const built = buildExportSvg(single, { ...opts, pages: "current" }, customLinkTypes, images, backdrops);
      sheets.push({ svg: built.svg, width: built.width, height: built.height });
      report.missingImages += built.report.missingImages;
      report.missingPdfPages += built.report.missingPdfPages;
    }
  } else {
    const built = buildExportSvg(board, opts, customLinkTypes, images, backdrops);
    sheets.push({ svg: built.svg, width: built.width, height: built.height });
    report.missingImages += built.report.missingImages;
  }
  report.pages = sheets.length;
  if (sheets.length === 0) throw new Error("There is nothing to export - the notebook has no pages.");

  const report_ = options.onProgress;
  let doc: InstanceType<typeof jsPDF> | null = null;
  let sheetNo = 0;
  for (const sheet of sheets) {
    sheetNo++;
    report_?.({
      done: sheetNo - 1,
      total: sheets.length,
      label: sheets.length > 1 ? `Rendering page ${sheetNo} of ${sheets.length}` : "Rendering",
    });
    await yieldToPaint();
    const png = await rasterizeSvg(sheet.svg, sheet.width, sheet.height, scale, background);
    const dataUrl = await blobToDataUrl(png);

    let pageW = sheet.width;
    let pageH = sheet.height;
    const overflow = Math.max(pageW, pageH) / PDF_MAX_POINTS;
    if (overflow > 1) {
      pageW /= overflow;
      pageH /= overflow;
    }
    // jsPDF reorders `format` to match the orientation, so the two must agree
    // or the page comes out with its dimensions swapped.
    const orientation = pageW >= pageH ? "landscape" : "portrait";
    if (!doc) {
      doc = new jsPDF({ orientation, unit: "pt", format: [pageW, pageH], compress: true });
    } else {
      doc.addPage([pageW, pageH], orientation);
    }
    doc.addImage(dataUrl, "PNG", 0, 0, pageW, pageH, undefined, "FAST");
  }
  report_?.({ done: sheets.length, total: sheets.length, label: "Writing the PDF" });
  await yieldToPaint();
  return { blob: doc!.output("blob"), report };
}

export async function exportBoardToPdf(
  board: Board,
  options: ExportOptions = {},
  customLinkTypes: Array<{ id: string; name: string; color: string }> = []
): Promise<Blob> {
  return (await exportBoardToPdfWithReport(board, options, customLinkTypes)).blob;
}

/** Exports and saves a PDF (share sheet on Android, download elsewhere). */
export async function downloadPdf(
  board: Board,
  options: ExportOptions = {},
  filename?: string,
  customLinkTypes: Array<{ id: string; name: string; color: string }> = []
): Promise<ExportReport> {
  const { blob, report } = await exportBoardToPdfWithReport(board, options, customLinkTypes);
  const safeName = (filename || board.name || "whiteboard").replace(/[^a-z0-9-_]/gi, "_");
  await saveBlob(blob, `${safeName}.pdf`);
  return report;
}

/**
 * Copies high-resolution PNG image directly to system clipboard.
 */
export async function copyPngToClipboard(
  board: Board,
  options: ExportOptions = {},
  customLinkTypes: Array<{ id: string; name: string; color: string }> = []
): Promise<boolean> {
  try {
    const blob = await exportBoardToPng(board, options, customLinkTypes);
    if (typeof navigator !== "undefined" && navigator.clipboard && typeof ClipboardItem !== "undefined") {
      await navigator.clipboard.write([new ClipboardItem({ "image/png": blob })]);
      return true;
    }
    return false;
  } catch (err) {
    console.error("Failed to copy image to clipboard:", err);
    return false;
  }
}
