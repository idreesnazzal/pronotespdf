/**
 * PDF rendering
 * =============
 * Opens an imported PDF and rasterises single pages on demand.
 *
 * pdf.js is loaded with `await import()` so it never enters the main bundle —
 * it is ~1 MB, and someone who never imports a PDF should not pay for it. Its
 * worker is served from the app's own root (see PDF_WORKER_PATH) rather than a
 * CDN, because the app has to work with no internet: that is the whole premise
 * of it being local-first, and every other app in this category is criticised
 * for needing a connection.
 */

import type { PDFDocumentProxy } from "pdfjs-dist";

/** Rasterising above this loses more to memory than it gains in sharpness. */
export const PDF_MAX_RENDER_SCALE = 3;

/**
 * Where the pdf.js worker is served from. It is copied into public/ by
 * `npm run sync:pdf-worker`, which the build scripts run, so it ends up at the
 * app root in every package.
 */
export const PDF_WORKER_PATH = "/pdf.worker.min.mjs";

export interface PdfPageSize {
  width: number;
  height: number;
}

type PdfJs = typeof import("pdfjs-dist");

let pdfjsPromise: Promise<PdfJs> | null = null;

async function loadPdfJs(): Promise<PdfJs> {
  if (!pdfjsPromise) {
    pdfjsPromise = (async () => {
      const pdfjs = await import("pdfjs-dist");
      // The worker is shipped in public/ and served from the app's own
      // root, NOT from a CDN and NOT via `new URL(..., import.meta.url)`.
      //
      // A CDN would break the offline promise outright. import.meta.url works
      // in the Next bundle but cannot be compiled to CommonJS, which is what
      // the node test suite uses — and the store imports this module, so the
      // whole suite failed to compile. A plain root-relative path works in
      // every target: the dev server, the static export, Electron's
      // `pronotes://app/` scheme, and the APK's asset root.
      pdfjs.GlobalWorkerOptions.workerSrc = `${PDF_WORKER_PATH}`;
      return pdfjs;
    })();
  }
  return pdfjsPromise;
}

/**
 * Opens a PDF from raw bytes.
 *
 * The buffer is copied first: pdf.js takes ownership of what it is given and
 * detaches it, which would leave the caller's copy — the one being written to
 * IndexedDB — as a zero-length buffer.
 */
export async function openPdf(bytes: ArrayBuffer): Promise<PDFDocumentProxy> {
  const pdfjs = await loadPdfJs();
  return pdfjs.getDocument({ data: bytes.slice(0) }).promise;
}

/** Open stored documents, so a 40 MB PDF is parsed once however many parts read it. */
const storedDocs = new Map<string, Promise<PDFDocumentProxy>>();

/**
 * Opens a PDF kept in the PDF store, once. The page pictures and the page text
 * both read through here - two separate caches would parse (and hold) every
 * document twice.
 */
export function openStoredPdf(docId: string): Promise<PDFDocumentProxy> {
  let d = storedDocs.get(docId);
  if (!d) {
    d = (async () => {
      const { getPdf } = await import("./pdfstore");
      const stored = await getPdf(docId);
      if (!stored) throw new Error("This PDF is no longer stored on this device.");
      return openPdf(stored.bytes);
    })();
    storedDocs.set(docId, d);
    // A failed open must not be cached forever, or a transient error would
    // leave the notebook permanently blank until a restart.
    d.catch(() => storedDocs.delete(docId));
  }
  return d;
}

/** The stored document if something already has it open, else undefined. */
export function peekStoredPdf(docId: string): Promise<PDFDocumentProxy> | undefined {
  return storedDocs.get(docId);
}

/** Page size in CSS pixels at 100%, respecting the page's own rotation. */
export async function pdfPageSize(doc: PDFDocumentProxy, pageNumber: number): Promise<PdfPageSize> {
  const page = await doc.getPage(pageNumber);
  const viewport = page.getViewport({ scale: 1 });
  return { width: Math.round(viewport.width), height: Math.round(viewport.height) };
}

/**
 * Renders one page to a PNG data URL.
 *
 * `targetWidth` is the width the page will be drawn at on screen; the raster
 * is made at `dpr` times that so it stays sharp on a high-DPI tablet without
 * rendering the whole document at maximum resolution.
 */
export async function renderPdfPage(
  doc: PDFDocumentProxy,
  pageNumber: number,
  targetWidth: number,
  dpr = 2
): Promise<string> {
  const page = await doc.getPage(pageNumber);
  const base = page.getViewport({ scale: 1 });
  const scale = Math.min(PDF_MAX_RENDER_SCALE, (targetWidth * dpr) / base.width);
  const viewport = page.getViewport({ scale });

  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.floor(viewport.width));
  canvas.height = Math.max(1, Math.floor(viewport.height));
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Could not get a 2D context to render the PDF page");

  // PDFs assume paper: without this, a page with no background paints as
  // transparent and the canvas shows through in dark mode.
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  await page.render({ canvas, canvasContext: ctx, viewport }).promise;
  return canvas.toDataURL("image/png");
}

/** Reads a File into an ArrayBuffer, rejecting anything that is not a PDF. */
export function readPdfFile(file: File): Promise<ArrayBuffer> {
  return new Promise((resolve, reject) => {
    const looksLikePdf =
      file.type === "application/pdf" || /\.pdf$/i.test(file.name);
    if (!looksLikePdf) {
      reject(new Error(`"${file.name}" is not a PDF.`));
      return;
    }
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as ArrayBuffer);
    reader.onerror = () => reject(new Error(`Could not read "${file.name}".`));
    reader.readAsArrayBuffer(file);
  });
}

/**
 * The page size a notebook should use for this PDF, clamped so a poster-sized
 * page cannot produce a sheet too large to work with.
 */
export function notebookSizeForPdf(size: PdfPageSize, maxWidth = 1400): PdfPageSize {
  if (size.width <= maxWidth) return size;
  const scale = maxWidth / size.width;
  return { width: Math.round(size.width * scale), height: Math.round(size.height * scale) };
}
