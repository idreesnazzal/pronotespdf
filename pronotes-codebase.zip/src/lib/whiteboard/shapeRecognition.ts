/**
 * Shape recognition
 * =================
 * Turns a hand-drawn stroke into the shape it was meant to be - a circle, an
 * ellipse, a straight line, a triangle, a rectangle or square, or another
 * polygon - at the same place and the same size. Anything it is not sure of is
 * left exactly as drawn: a wrong guess destroys what you wrote, a missed one
 * costs nothing.
 *
 * How it decides:
 *  - A line is an open stroke whose ends are almost as far apart as the whole
 *    path is long, and which never strays far from the straight chord.
 *  - A closed stroke (the pen came back near where it started) is cut to one
 *    loop, resampled evenly, and its CORNERS are found: places where the
 *    direction turns sharply within a short stretch. A drawn circle turns
 *    steadily and has none; a square has four.
 *  - 3-6 corners with straight sides between them -> a polygon, its corners
 *    placed where the fitted sides meet (not where the pen happened to turn).
 *    Four right angles -> a rectangle, or a square when the sides match.
 *  - No corners and a good ellipse fit -> an ellipse, or a circle when the
 *    axes match.
 *  - Near-horizontal / vertical lines, rectangles and ellipses snap straight.
 *
 * Points are [x, y, pressure] in the stroke's own coordinates, in and out.
 */

export type ShapeKind =
  | "line"
  | "circle"
  | "ellipse"
  | "triangle"
  | "square"
  | "rectangle"
  | "quadrilateral"
  | "pentagon"
  | "hexagon";

export interface RecognizedShape {
  kind: ShapeKind;
  /** Dense points along the perfect shape, closed shapes ending where they start. */
  points: [number, number, number][];
  /**
   * The shape's key points: a line's two ends, a polygon's corners (none for
   * an ellipse). What the next line you draw can snap onto.
   */
  vertices: [number, number][];
}

type P = [number, number];
type Pt = [number, number, number];

const SHAPE_LABELS: Record<ShapeKind, string> = {
  line: "Line",
  circle: "Circle",
  ellipse: "Ellipse",
  triangle: "Triangle",
  square: "Square",
  rectangle: "Rectangle",
  quadrilateral: "Shape",
  pentagon: "Pentagon",
  hexagon: "Hexagon",
};

export function shapeLabel(kind: ShapeKind): string {
  return SHAPE_LABELS[kind];
}

// ---------------------------------------------------------------------------
// Geometry helpers
// ---------------------------------------------------------------------------

const dist = (a: P, b: P) => Math.hypot(a[0] - b[0], a[1] - b[1]);

function pathLength(pts: P[]): number {
  let n = 0;
  for (let i = 1; i < pts.length; i++) n += dist(pts[i - 1], pts[i]);
  return n;
}

/** `n` points evenly spaced along the path. */
function resample(pts: P[], n: number): P[] {
  const total = pathLength(pts);
  if (total === 0) return [pts[0]];
  const step = total / (n - 1);
  const out: P[] = [pts[0]];
  let acc = 0;
  let prev = pts[0];
  for (let i = 1; i < pts.length && out.length < n; i++) {
    let cur = pts[i];
    let d = dist(prev, cur);
    while (acc + d >= step && out.length < n) {
      const t = (step - acc) / d;
      const q: P = [prev[0] + (cur[0] - prev[0]) * t, prev[1] + (cur[1] - prev[1]) * t];
      out.push(q);
      prev = q;
      d = dist(prev, cur);
      acc = 0;
    }
    acc += d;
    prev = cur;
    cur = pts[i];
  }
  while (out.length < n) out.push(pts[pts.length - 1]);
  return out;
}

function distToSegment(p: P, a: P, b: P): number {
  const dx = b[0] - a[0];
  const dy = b[1] - a[1];
  const len2 = dx * dx + dy * dy;
  if (len2 === 0) return dist(p, a);
  const t = Math.max(0, Math.min(1, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / len2));
  return dist(p, [a[0] + dx * t, a[1] + dy * t]);
}

function polygonArea(pts: P[]): number {
  let a = 0;
  for (let i = 0; i < pts.length; i++) {
    const [x1, y1] = pts[i];
    const [x2, y2] = pts[(i + 1) % pts.length];
    a += x1 * y2 - x2 * y1;
  }
  return Math.abs(a) / 2;
}

/** Angle between two directions, 0..PI. */
function turn(a: P, b: P, c: P): number {
  const v1x = b[0] - a[0];
  const v1y = b[1] - a[1];
  const v2x = c[0] - b[0];
  const v2y = c[1] - b[1];
  const l1 = Math.hypot(v1x, v1y);
  const l2 = Math.hypot(v2x, v2y);
  if (l1 === 0 || l2 === 0) return 0;
  const cos = Math.max(-1, Math.min(1, (v1x * v2x + v1y * v2y) / (l1 * l2)));
  return Math.acos(cos);
}

/** A best-fit line through points: a point on it and its unit direction. */
function fitLine(pts: P[]): { c: P; d: P } {
  const n = pts.length;
  const cx = pts.reduce((s, p) => s + p[0], 0) / n;
  const cy = pts.reduce((s, p) => s + p[1], 0) / n;
  let sxx = 0;
  let syy = 0;
  let sxy = 0;
  for (const [x, y] of pts) {
    sxx += (x - cx) * (x - cx);
    syy += (y - cy) * (y - cy);
    sxy += (x - cx) * (y - cy);
  }
  const angle = 0.5 * Math.atan2(2 * sxy, sxx - syy);
  return { c: [cx, cy], d: [Math.cos(angle), Math.sin(angle)] };
}

function intersect(l1: { c: P; d: P }, l2: { c: P; d: P }): P | null {
  const det = l1.d[0] * l2.d[1] - l1.d[1] * l2.d[0];
  if (Math.abs(det) < 1e-9) return null;
  const t = ((l2.c[0] - l1.c[0]) * l2.d[1] - (l2.c[1] - l1.c[1]) * l2.d[0]) / det;
  return [l1.c[0] + l1.d[0] * t, l1.c[1] + l1.d[1] * t];
}

/** Snaps an angle (radians) to the nearest multiple of `step` when within `tol`. */
function snapAngle(a: number, step: number, tol: number): number {
  const k = Math.round(a / step);
  return Math.abs(a - k * step) <= tol ? k * step : a;
}

const DEG = Math.PI / 180;

// ---------------------------------------------------------------------------
// Output builders (dense points, so the pen draws them evenly and the pixel
// eraser can cut them like any stroke)
// ---------------------------------------------------------------------------

function densify(corners: P[], closed: boolean, spacing: number, pressure: number): Pt[] {
  const out: Pt[] = [];
  const ring = closed ? [...corners, corners[0]] : corners;
  for (let i = 0; i < ring.length - 1; i++) {
    const a = ring[i];
    const b = ring[i + 1];
    const n = Math.max(1, Math.ceil(dist(a, b) / spacing));
    for (let k = 0; k < n; k++) {
      const t = k / n;
      out.push([a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, pressure]);
    }
  }
  const end = ring[ring.length - 1];
  out.push([end[0], end[1], pressure]);
  return out;
}

function ellipsePoints(c: P, a: number, b: number, rot: number, start: number, pressure: number): Pt[] {
  const n = Math.max(48, Math.min(160, Math.round((Math.PI * (a + b)) / 3)));
  const out: Pt[] = [];
  const cos = Math.cos(rot);
  const sin = Math.sin(rot);
  for (let i = 0; i <= n; i++) {
    const t = start + (i / n) * Math.PI * 2;
    const u = a * Math.cos(t);
    const v = b * Math.sin(t);
    out.push([c[0] + u * cos - v * sin, c[1] + u * sin + v * cos, pressure]);
  }
  return out;
}

// ---------------------------------------------------------------------------
// Recognition
// ---------------------------------------------------------------------------

export interface RecognizeOptions {
  /** Smallest shape (bounding-box diagonal) worth recognising, in the points' units. */
  minSize?: number;
  /** Filled with the measurements behind the decision (tests and tuning). */
  explain?: Record<string, unknown>;
}

/**
 * The shape a stroke was meant to be, or null when it is not clearly one.
 * `points` are the finished stroke's points (hooks already trimmed).
 */
export function recognizeShape(points: Pt[], opts: RecognizeOptions = {}): RecognizedShape | null {
  if (!points || points.length < 5) return null;
  const raw: P[] = points.map((p) => [p[0], p[1]]);
  const pressure = median(points.map((p) => (typeof p[2] === "number" && p[2] > 0 ? p[2] : 0.5)));

  let minX = Infinity;
  let minY = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;
  for (const [x, y] of raw) {
    minX = Math.min(minX, x);
    minY = Math.min(minY, y);
    maxX = Math.max(maxX, x);
    maxY = Math.max(maxY, y);
  }
  const diag = Math.hypot(maxX - minX, maxY - minY);
  if (diag < (opts.minSize ?? 20)) return null;

  const L = pathLength(raw);
  if (L === 0) return null;
  const ex = opts.explain;
  if (ex) Object.assign(ex, { diag, L, gapOverL: dist(raw[0], raw[raw.length - 1]) / L });

  // ---- Line -----------------------------------------------------------------
  const line = tryLine(raw, L, pressure) ?? tryLine(...trimHooks(raw), pressure);
  if (ex) ex.line = !!line;
  if (line) return { kind: "line", points: line, vertices: [[line[0][0], line[0][1]], [line[line.length - 1][0], line[line.length - 1][1]]] };

  // ---- One closed loop --------------------------------------------------------
  // Hands rarely end exactly where they began: they stop short, run on past
  // the start (a tail), trace back over the first side, or cross over it.
  // The loop is the stretch between the pair of points - one early, one
  // late - where the stroke comes back closest to itself.
  const lap = findLoop(raw, L);
  if (ex) Object.assign(ex, { lapGap: lap ? lap.d / diag : null, lapShare: lap ? lap.len / L : null });
  // Stopping short or running just past the start leaves a gap; cutting off
  // a long tail (a retrace, a crossing) is trusted only where the stroke
  // really meets itself - otherwise a spiral's turns would pass as a lap.
  const lapTol = lap && lap.len >= L * 0.92 ? Math.max(diag * 0.22, lap.len * 0.08) : diag * 0.05;
  if (!lap || lap.d > lapTol) return null;
  const loop = raw.slice(lap.i, lap.j + 1);
  const first = loop[0];
  const N = 96;
  const ring = resample(loop, N + 1).slice(0, N); // closed ring, no repeat
  if (ring.length < N) return null;
  const area = polygonArea(ring);
  // Measured on the loop itself: a tail cut off must not make it look bigger.
  const ringDiag = (() => {
    const xs = ring.map((p) => p[0]);
    const ys = ring.map((p) => p[1]);
    return Math.hypot(Math.max(...xs) - Math.min(...xs), Math.max(...ys) - Math.min(...ys));
  })();
  // A scribble back and forth over itself encloses nothing.
  if (area < ringDiag * ringDiag * 0.06) return null;

  // ---- Corners --------------------------------------------------------------
  const W = 4; // samples either side: ~8% of the perimeter
  const turning = ring.map((_, i) => turn(ring[(i - W + N) % N], ring[i], ring[(i + W) % N]));
  // The same over half the stretch. A corner turns nearly all of its angle
  // in that short span; the tip of a thin ellipse spreads its turn out, so
  // there the short span carries only about half.
  const W2 = 2;
  const tight = ring.map((_, i) => turn(ring[(i - W2 + N) % N], ring[i], ring[(i + W2) % N]));
  const findCorners = (sharpness: number): number[] => {
    const found: number[] = [];
    for (let i = 0; i < N; i++) {
      const t = turning[i];
      if (t < 50 * DEG) continue;
      const sharp = Math.max(tight[i], tight[(i + 1) % N], tight[(i - 1 + N) % N]);
      if (sharp < sharpness * t) continue;
      // A local maximum of turning, and not the second peak of the same corner.
      let isMax = true;
      for (let k = -W; k <= W; k++) {
        if (k === 0) continue;
        const j = (i + k + N) % N;
        if (turning[j] > t || (turning[j] === t && k < 0)) {
          isMax = false;
          break;
        }
      }
      if (isMax) found.push(i);
    }
    return found;
  };
  /**
   * The one corner the turning test missed in a box: three corners were
   * found and the fourth was drawn round and wide. The point farthest from
   * the triangle of the three is that corner. Only ever this one step: a
   * heart or a D shows two corners, and "finding" more on its curves would
   * turn it into a polygon it never was.
   */
  // Turning over a wider stretch: a corner drawn round still turns like a
  // corner here (~90 deg), the middle of an arc (a D's round, a heart's
  // lobe) only gently.
  const WW = 8;
  const wide = ring.map((_, i) => turn(ring[(i - WW + N) % N], ring[i], ring[(i + WW) % N]));
  const tryGrowing = (start: number[], ellipseErr: number): RecognizedShape | null => {
    if (start.length !== 3) return null;
    const cs = [...start].sort((p, q) => p - q);
    let added = 0;
    while (cs.length <= 4) {
      if (cs.length >= 3) {
        const r = tryPolygon(cs, ellipseErr);
        if (r) return r;
      }
      if (cs.length === 4) break;
      const outline = cs.length >= 2 ? cs.map((i) => ring[i]) : [ring[0], ring[Math.floor(N / 2)]];
      let far = -1;
      let farD = 0;
      for (let i = 0; i < N; i++) {
        if (cs.some((c) => Math.min(Math.abs(c - i), N - Math.abs(c - i)) < 5)) continue;
        let d = Infinity;
        for (let k = 0; k < outline.length; k++) d = Math.min(d, distToSegment(ring[i], outline[k], outline[(k + 1) % outline.length]));
        if (d > farD) {
          farD = d;
          far = i;
        }
      }
      if (far < 0 || farD < ringDiag * 0.04) break;
      if (ex) (ex.grow = (ex.grow as unknown[] | undefined) ?? []).push({ k: cs.length, wide: wide[far] / DEG, farD: farD / ringDiag });
      // It must still turn like a corner over a wider stretch.
      if (added >= 1 || wide[far] < 40 * DEG) break;
      if (cs.length < 2 && !cs.includes(0)) cs.push(0);
      cs.push(far);
      added++;
      cs.sort((p, q) => p - q);
    }
    return null;
  };
  const tryPolygon = (cs: number[], ellipseErr: number): RecognizedShape | null => {
    if (cs.length < 3 || cs.length > 6) return null;
    const poly = fitPolygon(ring, cs);
    if (!poly) return null;
    const polyErr = meanDistanceToPolygon(ring, poly) / ringDiag;
    const bow = sideBow(ring, cs, poly);
    // Sides must be straight: a wobbly loop with a few kinks is not a
    // polygon, and neither is a circle that fits better as a circle.
    if (ex) (ex.polyTries = (ex.polyTries as unknown[] | undefined) ?? []).push({ k: cs.length, polyErr, bow, angles: interiorAngles(poly).map((x) => Math.round(x / DEG)) });
    if (polyErr >= 0.035 || bow > 0.13) return null;
    if (cs.length >= 5 && ellipseErr < polyErr * 0.8) return null;
    return polygonShape(poly, ringDiag, pressure);
  };

  const ellipse = fitEllipse(ring);
  const ellErr = ellipse ? ellipse.err : Infinity;

  // 1. Clear corners: a polygon.
  const corners = findCorners(0.68);
  if (ex) Object.assign(ex, { ellErr, sharpCorners: corners.length, softCorners: findCorners(0).length, area: area / (ringDiag * ringDiag) });
  const sharpPoly = tryPolygon(corners, ellErr);
  if (sharpPoly) return sharpPoly;

  // 2. No corners and a good fit: an ellipse. Two gentle kinks (a lemon, an
  //    eye) still read as one when it fits well.
  if (ellipse && ((corners.length <= 1 && ellErr < 0.085) || (corners.length === 2 && ellErr < 0.06))) {
    return ellipseShape(ellipse, first, pressure);
  }

  // 3. Rounded corners - how most hands draw a square - turn over a longer
  //    stretch. Counted too, but only for a loop that is plainly no ellipse.
  if (ellErr > 0.06) {
    const softCorners = findCorners(0);
    const soft = tryPolygon(softCorners, ellErr) ?? tryGrowing(softCorners, ellErr);
    if (soft) return soft;
  }

  // 4. A box drawn loosely - a rounded corner, a bowed side - may not show
  //    four clean corners, but it still fills its tightest bounding
  //    rectangle almost completely (a circle fills 79%, a triangle 50%).
  if (ellErr > 0.07) {
    const box = minAreaRect(convexHull(ring));
    if (ex) ex.boxFill = box ? area / box.area : null;
    if (box && area / box.area >= 0.86) return polygonShape(box.corners, ringDiag, pressure);
  }
  return null;
}

/** Convex hull (monotone chain), counter-clockwise. */
function convexHull(pts: P[]): P[] {
  const s = [...pts].sort((a, b) => a[0] - b[0] || a[1] - b[1]);
  const cross = (o: P, a: P, b: P) => (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]);
  const lower: P[] = [];
  for (const p of s) {
    while (lower.length >= 2 && cross(lower[lower.length - 2], lower[lower.length - 1], p) <= 0) lower.pop();
    lower.push(p);
  }
  const upper: P[] = [];
  for (let i = s.length - 1; i >= 0; i--) {
    const p = s[i];
    while (upper.length >= 2 && cross(upper[upper.length - 2], upper[upper.length - 1], p) <= 0) upper.pop();
    upper.push(p);
  }
  upper.pop();
  lower.pop();
  return lower.concat(upper);
}

/** The smallest rectangle around a convex polygon (one side lies on a hull edge). */
function minAreaRect(hull: P[]): { corners: P[]; area: number } | null {
  if (hull.length < 3) return null;
  let best: { corners: P[]; area: number } | null = null;
  for (let i = 0; i < hull.length; i++) {
    const a = hull[i];
    const b = hull[(i + 1) % hull.length];
    const len = dist(a, b);
    if (len === 0) continue;
    const ux = (b[0] - a[0]) / len;
    const uy = (b[1] - a[1]) / len;
    let minU = Infinity;
    let maxU = -Infinity;
    let minV = Infinity;
    let maxV = -Infinity;
    for (const p of hull) {
      const u = p[0] * ux + p[1] * uy;
      const v = -p[0] * uy + p[1] * ux;
      minU = Math.min(minU, u);
      maxU = Math.max(maxU, u);
      minV = Math.min(minV, v);
      maxV = Math.max(maxV, v);
    }
    const area = (maxU - minU) * (maxV - minV);
    if (!best || area < best.area) {
      const back = (u: number, v: number): P => [u * ux - v * uy, u * uy + v * ux];
      best = { area, corners: [back(minU, minV), back(maxU, minV), back(maxU, maxV), back(minU, maxV)] };
    }
  }
  return best;
}

/** Cumulative path length at each point. */
function cumulative(pts: P[]): number[] {
  const out = [0];
  for (let i = 1; i < pts.length; i++) out.push(out[i - 1] + dist(pts[i - 1], pts[i]));
  return out;
}

/**
 * A straight line, read from the middle of the stroke: the pen landing and
 * lifting often add a hook at either end, which must not make a straight
 * line "not straight". Null when it is not a line.
 */
function tryLine(raw: P[], L: number, pressure: number): Pt[] | null {
  const cum = cumulative(raw);
  const mid = raw.filter((_, i) => cum[i] >= L * 0.07 && cum[i] <= L * 0.93);
  const core = mid.length >= 3 ? mid : raw;
  const coreL = pathLength(core);
  const chord = dist(core[0], core[core.length - 1]);
  if (coreL === 0 || chord / coreL < 0.93) return null;
  const fit = fitLine(core);
  const perp = (p: P) => Math.abs((p[0] - fit.c[0]) * fit.d[1] - (p[1] - fit.c[1]) * fit.d[0]);
  let dev = 0;
  for (const p of core) dev = Math.max(dev, perp(p));
  if (dev > Math.max(3, chord * 0.075)) return null;
  // Ends: the outermost points still on the line (a hook is not).
  const tol = Math.max(4, chord * 0.07);
  const along = (p: P) => (p[0] - fit.c[0]) * fit.d[0] + (p[1] - fit.c[1]) * fit.d[1];
  let a = 0;
  while (a < raw.length - 1 && perp(raw[a]) > tol) a++;
  let b = raw.length - 1;
  while (b > 0 && perp(raw[b]) > tol) b--;
  if (b <= a) return null;
  const on = (t: number): P => [fit.c[0] + fit.d[0] * t, fit.c[1] + fit.d[1] * t];
  const start = on(along(raw[a]));
  const end = on(along(raw[b]));
  if (dist(start, end) < chord * 0.6) return null;
  return makeLine(start, end, pressure);
}

/**
 * The stroke without a hook at either end: a sharp turn within the first or
 * last quarter, where the pen landed moving one way and then set off the
 * other (or flicked away on lifting).
 */
function trimHooks(raw: P[]): [P[], number] {
  const n = 64;
  const rs = resample(raw, n);
  let a = 0;
  let b = n - 1;
  for (let i = 2; i < n - 2; i++) {
    const t = turn(rs[i - 2], rs[i], rs[i + 2]);
    if (t < 55 * DEG) continue;
    if (i < n * 0.28) a = i;
    else if (i > n * 0.72 && b === n - 1) b = i;
  }
  const cut = rs.slice(a, b + 1);
  return [cut, pathLength(cut)];
}

/**
 * The closed lap inside a stroke: early point i and late point j (at least
 * half the stroke apart) where it comes back closest to itself. A tiny cost
 * for what is cut off keeps as much of the stroke as possible when several
 * pairs are about equally close (a side traced twice).
 */
function findLoop(pts: P[], L: number): { i: number; j: number; d: number; len: number } | null {
  const n = pts.length;
  const cum = cumulative(pts);
  const step = Math.max(1, Math.floor(n / 220));
  let best: { i: number; j: number; d: number; len: number; cost: number } | null = null;
  for (let i = 0; i < n; i += step) {
    if (cum[i] > L * 0.4) break;
    for (let j = n - 1; j > i; j -= step) {
      const len = cum[j] - cum[i];
      if (len < L * 0.5) break;
      const d = dist(pts[i], pts[j]);
      const cost = d + (L - len) * 0.03;
      if (!best || cost < best.cost) best = { i, j, d, len, cost };
    }
  }
  if (!best) return null;
  // Settle on the closest pair right around the one found (the coarse
  // stride may have stepped over the exact crossing).
  const { i: bi, j: bj } = best;
  for (let i = Math.max(0, bi - step); i <= Math.min(n - 1, bi + step); i++) {
    for (let j = Math.max(i + 1, bj - step); j <= Math.min(n - 1, bj + step); j++) {
      const len = cum[j] - cum[i];
      if (len < L * 0.5) continue;
      const d = dist(pts[i], pts[j]);
      const cost = d + (L - len) * 0.03;
      if (cost < best.cost) best = { i, j, d, len, cost };
    }
  }
  return { i: best.i, j: best.j, d: best.d, len: best.len };
}

function median(xs: number[]): number {
  const s = [...xs].sort((a, b) => a - b);
  return s.length ? s[Math.floor(s.length / 2)] : 0.5;
}

/** A straight stroke between two exact points (no levelling). */
export function lineBetween(a: [number, number], b: [number, number], pressure = 0.5): Pt[] {
  return densify([a, b], false, Math.max(2, dist(a, b) / 64), pressure);
}

function makeLine(a: P, b: P, pressure: number): Pt[] {
  // A ruler: horizontal / vertical when nearly so, the first point kept.
  const len = dist(a, b);
  const ang = snapAngle(Math.atan2(b[1] - a[1], b[0] - a[0]), Math.PI / 2, 4 * DEG);
  const end: P = [a[0] + Math.cos(ang) * len, a[1] + Math.sin(ang) * len];
  return densify([a, end], false, Math.max(2, len / 64), pressure);
}

// ---- Ellipse ---------------------------------------------------------------

interface EllipseFit {
  c: P;
  a: number;
  b: number;
  rot: number;
  /** Mean |normalised radius - 1|: 0 is a perfect ellipse. */
  err: number;
}

function fitEllipse(ring: P[]): EllipseFit | null {
  const n = ring.length;
  const cx = ring.reduce((s, p) => s + p[0], 0) / n;
  const cy = ring.reduce((s, p) => s + p[1], 0) / n;
  const { d } = fitLine(ring);
  const rot = Math.atan2(d[1], d[0]);
  const cos = Math.cos(rot);
  const sin = Math.sin(rot);
  const uv: P[] = ring.map(([x, y]) => {
    const dx = x - cx;
    const dy = y - cy;
    return [dx * cos + dy * sin, -dx * sin + dy * cos];
  });
  // Its size and centre are where the drawing actually reaches along each
  // axis (the mean of the few most extreme points, so one stray wobble does
  // not stretch it): "the same size, in the same place" as drawn.
  const ext = (vals: number[]) => {
    const s = [...vals].sort((p, q) => p - q);
    const k = Math.max(1, Math.round(s.length * 0.03));
    const lo = s.slice(0, k).reduce((t, x) => t + x, 0) / k;
    const hi = s.slice(-k).reduce((t, x) => t + x, 0) / k;
    return [lo, hi];
  };
  const [u0, u1] = ext(uv.map((p) => p[0]));
  const [v0, v1] = ext(uv.map((p) => p[1]));
  const a = (u1 - u0) / 2;
  const b = (v1 - v0) / 2;
  if (!(a > 0) || !(b > 0)) return null;
  const mu = (u0 + u1) / 2;
  const mv = (v0 + v1) / 2;
  let err = 0;
  for (const [u, v] of uv) err += Math.abs(Math.hypot((u - mu) / a, (v - mv) / b) - 1);
  const c: P = [cx + mu * cos - mv * sin, cy + mu * sin + mv * cos];
  return { c, a, b, rot, err: err / n };
}

function ellipseShape(e: EllipseFit, penStart: P, pressure: number): RecognizedShape {
  let { a, b, rot } = e;
  const round = Math.abs(a - b) / Math.max(a, b) < 0.14;
  if (round) {
    const r = (a + b) / 2;
    a = r;
    b = r;
    rot = 0;
  } else {
    // Upright when nearly so.
    rot = snapAngle(rot, Math.PI / 2, 8 * DEG);
  }
  // Start where the pen started, so the seam is where you began drawing.
  const cos = Math.cos(rot);
  const sin = Math.sin(rot);
  const dx = penStart[0] - e.c[0];
  const dy = penStart[1] - e.c[1];
  const start = Math.atan2((-dx * sin + dy * cos) / b, (dx * cos + dy * sin) / a);
  return { kind: round ? "circle" : "ellipse", points: ellipsePoints(e.c, a, b, rot, start, pressure), vertices: [] };
}

// ---- Polygon ---------------------------------------------------------------

/** Corners where the fitted straight sides meet. */
function fitPolygon(ring: P[], cornerIdx: number[]): P[] | null {
  const N = ring.length;
  const k = cornerIdx.length;
  const lines: Array<{ c: P; d: P }> = [];
  for (let s = 0; s < k; s++) {
    const i0 = cornerIdx[s];
    const i1 = cornerIdx[(s + 1) % k];
    const span = (i1 - i0 + N) % N;
    if (span < 4) return null;
    // The middle of the side: the rounding at each corner would bend the fit.
    const trim = Math.max(1, Math.floor(span * 0.18));
    const side: P[] = [];
    for (let j = trim; j <= span - trim; j++) side.push(ring[(i0 + j) % N]);
    if (side.length < 2) return null;
    lines.push(fitLine(side));
  }
  const out: P[] = [];
  for (let s = 0; s < k; s++) {
    const p = intersect(lines[(s - 1 + k) % k], lines[s]);
    if (!p) return null;
    // A corner far from where the pen turned means two nearly parallel sides.
    if (dist(p, ring[cornerIdx[s]]) > 0.35 * dist(ring[0], ring[Math.floor(N / 2)]) + 1) return null;
    out.push(p);
  }
  return out;
}

/**
 * How far the drawn sides bow away from straight: for each side, the largest
 * gap between the drawing and the fitted side, over the side's length. A
 * hand-drawn straight side stays small; an arc (a heart's lobe, the round of
 * a D) does not, however well a few segments happen to follow it.
 */
function sideBow(ring: P[], cs: number[], poly: P[]): number {
  const N = ring.length;
  const k = cs.length;
  let worst = 0;
  for (let s = 0; s < k; s++) {
    const a = poly[s];
    const b = poly[(s + 1) % k];
    const len = dist(a, b);
    if (len === 0) return Infinity;
    const i0 = cs[s];
    const span = (cs[(s + 1) % k] - i0 + N) % N;
    let m = 0;
    for (let j = Math.floor(span * 0.15); j <= span - Math.floor(span * 0.15); j++) {
      m = Math.max(m, distToSegment(ring[(i0 + j) % N], a, b));
    }
    worst = Math.max(worst, m / len);
  }
  return worst;
}

function meanDistanceToPolygon(ring: P[], poly: P[]): number {
  let total = 0;
  for (const p of ring) {
    let best = Infinity;
    for (let i = 0; i < poly.length; i++) best = Math.min(best, distToSegment(p, poly[i], poly[(i + 1) % poly.length]));
    total += best;
  }
  return total / ring.length;
}

function interiorAngles(poly: P[]): number[] {
  return poly.map((p, i) => {
    const a = poly[(i - 1 + poly.length) % poly.length];
    const b = poly[(i + 1) % poly.length];
    const v1: P = [a[0] - p[0], a[1] - p[1]];
    const v2: P = [b[0] - p[0], b[1] - p[1]];
    const cos = (v1[0] * v2[0] + v1[1] * v2[1]) / (Math.hypot(...v1) * Math.hypot(...v2));
    return Math.acos(Math.max(-1, Math.min(1, cos)));
  });
}

function polygonShape(poly: P[], diag: number, pressure: number): RecognizedShape {
  const spacing = Math.max(2, diag / 80);
  if (poly.length === 4) {
    const angles = interiorAngles(poly);
    // Meant as a rectangle: every corner near square, or three clearly
    // square and one drawn round and wide (its fitted sides lean in).
    const offs = angles.map((a) => Math.abs(a - Math.PI / 2)).sort((p, q) => p - q);
    const boxy = offs[3] < 20 * DEG || (offs[2] < 12 * DEG && offs[3] < 30 * DEG);
    if (boxy) {
      // A rectangle: its sides' mean direction, straightened when nearly
      // upright, and its extent measured in that frame.
      const dirs = poly.map((p, i) => {
        const q = poly[(i + 1) % 4];
        return Math.atan2(q[1] - p[1], q[0] - p[0]);
      });
      // Average the four directions folded onto a quarter turn.
      let sx = 0;
      let sy = 0;
      for (const d of dirs) {
        sx += Math.cos(4 * d);
        sy += Math.sin(4 * d);
      }
      let rot = Math.atan2(sy, sx) / 4;
      rot = snapAngle(rot, Math.PI / 2, 10 * DEG);
      const cos = Math.cos(rot);
      const sin = Math.sin(rot);
      const uv = poly.map(([x, y]) => [x * cos + y * sin, -x * sin + y * cos] as P);
      const us = uv.map((p) => p[0]).sort((a, b) => a - b);
      const vs = uv.map((p) => p[1]).sort((a, b) => a - b);
      let u0 = (us[0] + us[1]) / 2;
      let u1 = (us[2] + us[3]) / 2;
      let v0 = (vs[0] + vs[1]) / 2;
      let v1 = (vs[2] + vs[3]) / 2;
      let kind: ShapeKind = "rectangle";
      const w = u1 - u0;
      const h = v1 - v0;
      if (Math.abs(w - h) / Math.max(w, h) < 0.12) {
        kind = "square";
        const s = (w + h) / 2;
        const cu = (u0 + u1) / 2;
        const cv = (v0 + v1) / 2;
        u0 = cu - s / 2;
        u1 = cu + s / 2;
        v0 = cv - s / 2;
        v1 = cv + s / 2;
      }
      // Corners in the order the pen drew them round (keeps the seam where
      // the stroke began, and the winding the same).
      const back = (u: number, v: number): P => [u * cos - v * sin, u * sin + v * cos];
      let rect: P[] = [back(u0, v0), back(u1, v0), back(u1, v1), back(u0, v1)];
      const drawnClockwise = signedArea(poly) > 0;
      if (signedArea(rect) > 0 !== drawnClockwise) rect = [rect[0], rect[3], rect[2], rect[1]];
      const startAt = nearestIndex(rect, poly[0]);
      rect = [...rect.slice(startAt), ...rect.slice(0, startAt)];
      return { kind, points: densify(rect, true, spacing, pressure), vertices: rect };
    }
    return { kind: "quadrilateral", points: densify(poly, true, spacing, pressure), vertices: poly };
  }
  if (poly.length === 3) {
    // A near-level side is levelled, turning the triangle about its centre.
    const cx = (poly[0][0] + poly[1][0] + poly[2][0]) / 3;
    const cy = (poly[0][1] + poly[1][1] + poly[2][1]) / 3;
    let fix = 0;
    for (let i = 0; i < 3; i++) {
      const a = poly[i];
      const b = poly[(i + 1) % 3];
      const ang = Math.atan2(b[1] - a[1], b[0] - a[0]);
      const snapped = snapAngle(ang, Math.PI / 2, 5 * DEG);
      if (snapped !== ang && Math.abs(snapped - ang) > Math.abs(fix)) fix = snapped - ang;
    }
    const tri = fix
      ? poly.map(([x, y]) => {
          const dx = x - cx;
          const dy = y - cy;
          return [cx + dx * Math.cos(fix) - dy * Math.sin(fix), cy + dx * Math.sin(fix) + dy * Math.cos(fix)] as P;
        })
      : poly;
    return { kind: "triangle", points: densify(tri, true, spacing, pressure), vertices: tri };
  }
  return { kind: poly.length === 5 ? "pentagon" : "hexagon", points: densify(poly, true, spacing, pressure), vertices: poly };
}

function signedArea(pts: P[]): number {
  let a = 0;
  for (let i = 0; i < pts.length; i++) {
    const [x1, y1] = pts[i];
    const [x2, y2] = pts[(i + 1) % pts.length];
    a += x1 * y2 - x2 * y1;
  }
  return a / 2;
}

function nearestIndex(pts: P[], q: P): number {
  let best = 0;
  for (let i = 1; i < pts.length; i++) if (dist(pts[i], q) < dist(pts[best], q)) best = i;
  return best;
}

// ---------------------------------------------------------------------------
// Joining lines drawn one after another
// ---------------------------------------------------------------------------

export interface JoinTarget {
  id: string;
  /** A straight line's two ends, when the target is a line. */
  line?: [[number, number], [number, number]];
  /** A shape's corners. */
  corners?: [number, number][];
}

export interface JoinResult {
  start: [number, number];
  end: [number, number];
  /** Earlier lines whose end moves to the shared corner (0 = its first end). */
  adjust: Array<{ id: string; end: 0 | 1; to: [number, number] }>;
}

/**
 * A new straight line's ends, joined to what is nearby: drawn right up to
 * (or a little past, or short of) the end of an earlier line, both lines are
 * cut or extended to meet exactly where they cross - so four quick lines make
 * a box with clean corners. Near a shape's corner, the end lands on it.
 * `reach` is how far an end may be from what it joins.
 */
export function joinLine(
  start: [number, number],
  end: [number, number],
  targets: JoinTarget[],
  reach: number
): JoinResult {
  const res: JoinResult = { start, end, adjust: [] };
  const newDir: P = [end[0] - start[0], end[1] - start[1]];
  const newLen = Math.hypot(newDir[0], newDir[1]);
  if (newLen === 0) return res;
  const used = new Set<string>();

  const joinEnd = (e: P): { to: P; adjust?: { id: string; end: 0 | 1; to: P } } | null => {
    let best: { to: P; adjust?: { id: string; end: 0 | 1; to: P }; d: number } | null = null;
    for (const t of targets) {
      if (t.line) {
        const [a, b] = t.line;
        for (const k of [0, 1] as const) {
          if (used.has(`${t.id}:${k}`)) continue;
          const q = k === 0 ? a : b;
          const d = dist(e, q);
          if (d > reach || (best && d >= best.d)) continue;
          const tDir: P = [b[0] - a[0], b[1] - a[1]];
          const tLen = Math.hypot(tDir[0], tDir[1]);
          const sin = tLen ? Math.abs(newDir[0] * tDir[1] - newDir[1] * tDir[0]) / (newLen * tLen) : 0;
          // Lines at a real angle meet where they cross; nearly parallel
          // ones simply continue from the earlier end.
          if (sin > Math.sin(20 * DEG)) {
            const x = intersect({ c: start, d: [newDir[0] / newLen, newDir[1] / newLen] }, { c: a, d: [tDir[0] / tLen, tDir[1] / tLen] });
            if (x && dist(x, e) <= reach * 1.5 && dist(x, q) <= reach * 1.5) {
              best = { to: x, adjust: { id: t.id, end: k, to: x }, d };
              continue;
            }
          }
          best = { to: q, d };
        }
      }
      for (const c of t.corners ?? []) {
        const d = dist(e, c);
        if (d <= reach && (!best || d < best.d)) best = { to: c, d };
      }
    }
    return best;
  };

  const s = joinEnd(start);
  if (s) {
    res.start = s.to;
    if (s.adjust) {
      res.adjust.push(s.adjust);
      used.add(`${s.adjust.id}:${s.adjust.end}`);
    }
  }
  const t = joinEnd(end);
  // Both ends onto one point would fold the line to nothing.
  if (t && dist(t.to, res.start) > newLen * 0.3) {
    res.end = t.to;
    if (t.adjust) res.adjust.push(t.adjust);
  }
  return res;
}
