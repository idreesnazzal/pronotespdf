/**
 * Page text: geometry, reading order, selection and search
 * =========================================================
 * The text of a PDF / Word / PowerPoint page, as runs of text with boxes, and
 * everything the "Select text" tool and search need to do with it. Pure: no
 * DOM, no IndexedDB, no pdf.js - so it is unit-tested in node.
 *
 * Coordinates are fractions of the PAGE (0..1 of its width and height, top-left
 * origin), never pixels or points. The same record then lines up with the page
 * at every zoom, on any sheet size, letterboxed or not.
 *
 * Where the text comes from:
 *  - a real PDF: pdf.js `getTextContent()` (`runsFromPdfItems`);
 *  - a converted Word / PowerPoint file: captured while it was drawn, since the
 *    PDF it becomes holds only pictures (see officeImport.ts).
 *
 * Right-to-left text
 * ------------------
 * Each run's string is expected in LOGICAL (reading) order, which is what
 * pdf.js, the DOM and PowerPoint's text all give. Two ways a PDF breaks that
 * are repaired here:
 *  - glyphs stored one per item, left to right: a Hebrew word then arrives
 *    last-letter-first. Runs of one line are re-ordered visually, with a
 *    right-to-left base when the line is mostly Hebrew/Arabic (`orderLine`).
 *  - whole strings stored in visual order. Hebrew betrays this: final letters
 *    (ך ם ן ף ץ) only ever END a word, so a page whose words keep STARTING with
 *    them is reversed, and its RTL runs are turned back (`looksVisualOrder`).
 */

import { PEN_TYPE_PRESETS, type StrokeElement } from "./types";

/** One piece of text on a page, in page fractions. `t` is in reading order. */
export interface TextRun {
  t: string;
  x: number;
  y: number;
  w: number;
  h: number;
}

/** A page's text. `w` / `h` are the page's own size, used only for its shape. */
export interface PageText {
  w: number;
  h: number;
  runs: TextRun[];
  /**
   * The runs are already in reading order - text captured from Word's layout
   * (document order) or PowerPoint's drawing (the order it was written in) -
   * so lines are never re-sorted by position. A PDF's order is only a hint.
   */
  ordered?: boolean;
}

export type Dir = "l" | "r" | "n";

export interface LaidRun extends TextRun {
  /** Offset of the run's first character in `PageLayout.text`. */
  start: number;
  end: number;
  line: number;
  dir: Dir;
}

export interface PageLayout {
  page: PageText;
  /** The whole page in reading order: runs joined by spaces and newlines. */
  text: string;
  runs: LaidRun[];
}

export interface Rect {
  x: number;
  y: number;
  w: number;
  h: number;
}

export interface LineRect extends Rect {
  line: number;
}

// ---------------------------------------------------------------------------
// Direction
// ---------------------------------------------------------------------------

const RTL_LETTER = /[\u0590-\u08FF\uFB1D-\uFDFF\uFE70-\uFEFF]/;
const RTL_LETTER_G = /[\u0590-\u08FF\uFB1D-\uFDFF\uFE70-\uFEFF]/g;
const LTR_LETTER_G = /[A-Za-zÀ-ɏͰ-ϿЀ-ӿ]/g;

/** Whether a run reads right-to-left, left-to-right, or has no letters at all. */
export function dirOf(s: string): Dir {
  const r = (s.match(RTL_LETTER_G) ?? []).length;
  const l = (s.match(LTR_LETTER_G) ?? []).length;
  if (r === 0 && l === 0) return /\d/.test(s) ? "l" : "n";
  return r >= l ? "r" : "l";
}

export function hasRtlText(s: string): boolean {
  return RTL_LETTER.test(s);
}

/**
 * A string stored in visual order, turned into reading order: reversed, except
 * that numbers and Latin words inside it keep their left-to-right order.
 */
export function visualToLogical(s: string): string {
  // Brackets need no swapping: stored in visual order as their logical
  // characters, plain reversal already reads "(3)" (checked in the tests).
  const rev = Array.from(s).reverse();
  const out: string[] = [];
  let i = 0;
  while (i < rev.length) {
    if (/[A-Za-z0-9]/.test(rev[i])) {
      let j = i;
      // A number keeps its separators ("3.14", "1,000") with it.
      while (j < rev.length && (/[A-Za-z0-9]/.test(rev[j]) || (/[.,:/]/.test(rev[j]) && /[A-Za-z0-9]/.test(rev[j + 1] ?? "")))) j++;
      out.push(...rev.slice(i, j).reverse());
      i = j;
    } else {
      out.push(rev[i]);
      i++;
    }
  }
  return out.join("");
}

const HEBREW_FINALS = /[ךםןףץ]/;

/**
 * True when a page's Hebrew reads backwards: more words START with a final
 * letter than end with one. Words of one letter say nothing and are skipped.
 */
export function looksVisualOrder(text: string): boolean {
  let starts = 0;
  let ends = 0;
  for (const word of text.match(/[א-ת]{2,}/g) ?? []) {
    if (HEBREW_FINALS.test(word[0])) starts++;
    if (HEBREW_FINALS.test(word[word.length - 1])) ends++;
  }
  return starts >= 2 && starts > ends * 2;
}

// ---------------------------------------------------------------------------
// Reading order
// ---------------------------------------------------------------------------

function overlapY(a: Rect, b: Rect): number {
  const top = Math.max(a.y, b.y);
  const bottom = Math.min(a.y + a.h, b.y + b.h);
  return Math.max(0, bottom - top) / Math.max(1e-9, Math.min(a.h, b.h));
}

/** Horizontal gap between two boxes, 0 when they touch or overlap. */
function gapX(a: Rect, b: Rect): number {
  return Math.max(0, Math.max(a.x, b.x) - Math.min(a.x + a.w, b.x + b.w));
}

/**
 * Splits runs into lines WITHOUT re-sorting the page: a run joins the line
 * before it only if it sits on the same baseline band and close by. Sorting
 * the whole page by position would interleave the two columns of a two-column
 * paper; the document's own order already reads column by column.
 */
export function groupLines(runs: TextRun[], aspect = 1): TextRun[][] {
  const lines: TextRun[][] = [];
  let cur: TextRun[] = [];
  let box: Rect | null = null;
  for (const r of runs) {
    // Gaps are compared in the same units as heights, so a wide page and a
    // tall one judge "close by" alike.
    const near = box !== null && overlapY(box, r) >= 0.5 && gapX(box, r) * aspect <= 2.5 * Math.max(box.h, r.h);
    if (!near && cur.length) {
      lines.push(cur);
      cur = [];
      box = null;
    }
    cur.push(r);
    box = box
      ? {
          x: Math.min(box.x, r.x),
          y: Math.min(box.y, r.y),
          w: Math.max(box.x + box.w, r.x + r.w) - Math.min(box.x, r.x),
          h: Math.max(box.y + box.h, r.y + r.h) - Math.min(box.y, r.y),
        }
      : { x: r.x, y: r.y, w: r.w, h: r.h };
  }
  if (cur.length) lines.push(cur);
  return lines;
}

/**
 * One line's runs in reading order. Left to right by position; for a line
 * that is mostly right-to-left, right to left, with any stretch of Latin words
 * or numbers inside it turned back to left-to-right (the Unicode bidi rule L2,
 * applied to whole runs).
 */
export function orderLine(runs: TextRun[]): TextRun[] {
  if (runs.length < 2) return runs.slice();
  const dirs = runs.map((r) => dirOf(r.t));
  const idx = runs.map((_, i) => i).sort((a, b) => runs[a].x + runs[a].w / 2 - (runs[b].x + runs[b].w / 2));
  if (!lineIsRtl(runs)) {
    // A left-to-right line: a Hebrew/Arabic phrase inside it still reads
    // right to left ("The phrase שלום עולם means").
    return reverseStretches(idx, dirs, "r").map((i) => runs[i]);
  }
  idx.reverse();
  const out: number[] = [];
  let i = 0;
  while (i < idx.length) {
    if (dirs[idx[i]] === "l") {
      let j = i;
      while (j < idx.length && dirs[idx[j]] !== "r") j++;
      // Trailing neutrals belong to the right-to-left text that follows.
      let k = j;
      while (k > i && dirs[idx[k - 1]] === "n") k--;
      out.push(...idx.slice(i, k).reverse());
      i = k;
    } else {
      out.push(idx[i]);
      i++;
    }
  }
  return out.map((n) => runs[n]);
}

/**
 * The line's base direction. A clear majority decides; when neither script
 * clearly dominates, the line starts where its first word is - the rightmost
 * word of a Hebrew line, the leftmost of an English one - so
 * "הגדרה: Binary Search Tree הוא עץ" (more Latin letters) still reads
 * right to left, from "הגדרה".
 */
function lineIsRtl(runs: TextRun[]): boolean {
  const r = runs.reduce((n, x) => n + (x.t.match(RTL_LETTER_G) ?? []).length, 0);
  const l = runs.reduce((n, x) => n + (x.t.match(LTR_LETTER_G) ?? []).length, 0);
  if (r === 0) return false;
  if (l === 0) return true;
  if (r >= 3 * l) return true;
  if (l >= 3 * r) return false;
  let right: TextRun | null = null;
  for (const x of runs) {
    const d = dirOf(x.t);
    if (d === "n" || /^[\d\s.,:;/%+\-()]*$/.test(x.t)) continue;
    if (!right || x.x + x.w > right.x + right.w) right = x;
  }
  return right ? dirOf(right.t) === "r" : r > l;
}

/** Positions (in order) with each stretch of `dir` runs reversed; neutrals between them go with them. */
function reverseStretches(idx: number[], dirs: string[], dir: string): number[] {
  const out: number[] = [];
  let i = 0;
  while (i < idx.length) {
    if (dirs[idx[i]] === dir) {
      let j = i;
      let lastStrong = i;
      while (j < idx.length && dirs[idx[j]] !== (dir === "r" ? "l" : "r")) {
        if (dirs[idx[j]] === dir) lastStrong = j;
        j++;
      }
      out.push(...idx.slice(i, lastStrong + 1).reverse());
      i = lastStrong + 1;
    } else {
      out.push(idx[i]);
      i++;
    }
  }
  return out;
}

const EDGE_NEUTRALS = /^([^\p{L}\p{N}]*)([\s\S]*?)([^\p{L}\p{N}]*)$/u;

/**
 * In a right-to-left line, punctuation at the ends of a number or Latin word
 * belongs to the Hebrew around it, not to the number: "בעמוד 12." is drawn
 * ". 12 בעמוד", and pdf.js hands over ".12" as one left-to-right piece, which
 * copied as "בעמוד .12". The punctuation is split off (with its share of the
 * box) so the line order puts it where it is read.
 */
function splitEdgeNeutrals(run: TextRun): TextRun[] {
  const m = EDGE_NEUTRALS.exec(run.t);
  if (!m || !m[2] || (!m[1] && !m[3])) return [run];
  const edges = charEdges(run.t);
  const piece = (from: number, to: number): TextRun => ({
    t: run.t.slice(from, to),
    x: run.x + run.w * edges[from],
    y: run.y,
    w: run.w * (edges[to] - edges[from]),
    h: run.h,
  });
  const a = m[1].length;
  const b = a + m[2].length;
  return [piece(0, a), piece(a, b), piece(b, run.t.length)].filter((r) => r.t.trim() !== "");
}

/** Arabic presentation forms (what many PDFs store) -> plain letters. */
const PRESENTATION_FORM = /[\uFB50-\uFDFF\uFE70-\uFEFC]/;
const PRESENTATION_FORMS = /[\uFB50-\uFDFF\uFE70-\uFEFC]+/g;

/** Lays a page out for reading: line order, separators, offsets. */
export function layoutPage(page: PageText): PageLayout {
  const aspect = page.h > 0 ? page.w / page.h : 1;
  const clean = page.runs
    .filter((r) => r.t.trim() !== "" && r.w > 0 && r.h > 0)
    .map((r) => (PRESENTATION_FORM.test(r.t) ? { ...r, t: r.t.replace(PRESENTATION_FORMS, (s) => s.normalize("NFKC")) } : r));
  let lines = groupLines(clean, aspect);
  if (!page.ordered) {
    lines = lines.map((line) =>
      orderLine(lineIsRtl(line) ? line.flatMap((r) => (dirOf(r.t) === "l" ? splitEdgeNeutrals(r) : [r])) : line)
    );
    // Whole strings stored backwards: turn every right-to-left run around, once.
    const probe = lines.map((l) => l.map((r) => r.t).join(" ")).join("\n");
    if (looksVisualOrder(probe)) {
      lines = lines.map((l) => orderLine(l.map((r) => (dirOf(r.t) === "r" ? { ...r, t: visualToLogical(r.t) } : r))));
    }
  }

  const out: LaidRun[] = [];
  let text = "";
  lines.forEach((line, li) => {
    if (li > 0) text += "\n";
    line.forEach((r, ri) => {
      if (ri > 0) {
        const prev = line[ri - 1];
        const gap = gapX(prev, r) * aspect;
        const joined = /\s$/.test(prev.t) || /^\s/.test(r.t);
        if (!joined && gap > 0.15 * Math.min(prev.h, r.h)) text += " ";
      }
      const start = text.length;
      text += r.t;
      out.push({ ...r, start, end: text.length, line: li, dir: dirOf(r.t) });
    });
  });
  return { page, text, runs: out };
}

// ---------------------------------------------------------------------------
// Character geometry
// ---------------------------------------------------------------------------

/**
 * Relative advance of each character of a string. The browser plugs in a
 * canvas measurer; without one (tests, or no canvas) every character counts
 * the same, which is still right to within a letter.
 */
export type CharMeasurer = (s: string) => number[];

let measurer: CharMeasurer | null = null;
const edgeCache = new Map<string, number[]>();

export function setCharMeasurer(m: CharMeasurer | null) {
  measurer = m;
  edgeCache.clear();
}

/**
 * Edges of each character from the run's reading START, as fractions of the
 * run's width: n + 1 numbers from 0 to 1.
 */
export function charEdges(s: string): number[] {
  const hit = edgeCache.get(s);
  if (hit) return hit;
  const n = s.length;
  let widths = measurer ? measurer(s) : [];
  if (widths.length !== n || widths.some((w) => !(w >= 0))) widths = new Array(n).fill(1);
  const total = widths.reduce((a, b) => a + b, 0) || n || 1;
  const edges = [0];
  let acc = 0;
  for (const w of widths) {
    acc += w;
    edges.push(acc / total);
  }
  if (edgeCache.size > 4000) edgeCache.clear();
  edgeCache.set(s, edges);
  return edges;
}

/** x of the boundary before character `i` of a run (0..length). */
function boundaryX(run: LaidRun, i: number): number {
  const f = charEdges(run.t)[Math.max(0, Math.min(run.t.length, i))];
  return run.dir === "r" ? run.x + run.w * (1 - f) : run.x + run.w * f;
}

/** Page-fraction box of characters [a, b) of a run. */
function runSlice(run: LaidRun, a: number, b: number): Rect {
  const x0 = boundaryX(run, a);
  const x1 = boundaryX(run, b);
  return { x: Math.min(x0, x1), y: run.y, w: Math.abs(x1 - x0), h: run.h };
}

// ---------------------------------------------------------------------------
// Hit testing and selection
// ---------------------------------------------------------------------------

/**
 * The text offset nearest a point (page fractions). A point beside a line
 * lands at that line's nearer end; a point in the margin lands on the closest
 * line - so a drag that overshoots the text still selects up to it.
 */
export function offsetAt(layout: PageLayout, px: number, py: number): number | null {
  const { runs, page } = layout;
  if (!runs.length) return null;
  const aspect = page.h > 0 ? page.w / page.h : 1;
  let best: LaidRun | null = null;
  let bestD = Infinity;
  for (const r of runs) {
    const dx = Math.max(0, r.x - px, px - (r.x + r.w)) * aspect;
    const dy = Math.max(0, r.y - py, py - (r.y + r.h));
    // Being on the right line matters more than being near the right word.
    const d = dx + dy * 4;
    if (d < bestD) {
      bestD = d;
      best = r;
    }
  }
  if (!best) return null;
  const edges = charEdges(best.t);
  // Where along the run, measured from its reading start.
  const f = best.dir === "r" ? (best.x + best.w - px) / best.w : (px - best.x) / best.w;
  let i = 0;
  while (i < edges.length - 1 && f > (edges[i] + edges[i + 1]) / 2) i++;
  return best.start + i;
}

const WORD_CHAR = /[\p{L}\p{N}\p{M}_'’׳״-]/u;

/** The word around an offset, [start, end). Empty when there is none. */
export function wordRangeAt(text: string, offset: number): [number, number] {
  let s = Math.max(0, Math.min(text.length, offset));
  let e = s;
  if (!WORD_CHAR.test(text[s] ?? "") && WORD_CHAR.test(text[s - 1] ?? "")) s = e = s - 1;
  if (!WORD_CHAR.test(text[s] ?? "")) return [offset, offset];
  while (s > 0 && WORD_CHAR.test(text[s - 1])) s--;
  while (e < text.length && WORD_CHAR.test(text[e])) e++;
  return [s, e];
}

/** Boxes covering text [start, end), one per run touched. */
export function rangeRects(layout: PageLayout, start: number, end: number): LineRect[] {
  const out: LineRect[] = [];
  if (end <= start) return out;
  for (const r of layout.runs) {
    if (r.end <= start || r.start >= end) continue;
    const a = Math.max(start, r.start) - r.start;
    const b = Math.min(end, r.end) - r.start;
    out.push({ ...runSlice(r, a, b), line: r.line });
  }
  return out;
}

/**
 * Merges the boxes of each line into the stretches a pen would draw: pieces of
 * one line closer than about a letter become one. Mixed-direction lines may
 * select two separate stretches, and they stay separate.
 */
export function lineSegments(rects: LineRect[], aspect = 1): LineRect[] {
  const byLine = new Map<number, LineRect[]>();
  for (const r of rects) {
    const list = byLine.get(r.line) ?? [];
    list.push(r);
    byLine.set(r.line, list);
  }
  const out: LineRect[] = [];
  for (const [line, list] of byLine) {
    list.sort((a, b) => a.x - b.x);
    let cur = { ...list[0] };
    for (const r of list.slice(1)) {
      if ((r.x - (cur.x + cur.w)) * aspect <= 0.6 * Math.max(cur.h, r.h)) {
        const x1 = Math.max(cur.x + cur.w, r.x + r.w);
        const y0 = Math.min(cur.y, r.y);
        const y1 = Math.max(cur.y + cur.h, r.y + r.h);
        cur = { x: cur.x, y: y0, w: x1 - cur.x, h: y1 - y0, line };
      } else {
        out.push(cur);
        cur = { ...r };
      }
    }
    out.push(cur);
  }
  return out;
}

/**
 * Where the caret for a selection edge is drawn: the boundary before `offset`
 * (`side` "start") or after `offset - 1` ("end"), with its line's box.
 */
export function caretAt(layout: PageLayout, offset: number, side: "start" | "end"): { x: number; y: number; h: number } | null {
  const runs = layout.runs;
  if (!runs.length) return null;
  let run: LaidRun | undefined;
  if (side === "start") run = runs.find((r) => offset < r.end) ?? runs[runs.length - 1];
  else run = [...runs].reverse().find((r) => offset > r.start) ?? runs[0];
  const i = Math.max(0, Math.min(run.t.length, offset - run.start));
  return { x: boundaryX(run, i), y: run.y, h: run.h };
}

/** The selected text, as it should land on the clipboard. */
export function selectedText(layout: PageLayout, start: number, end: number): string {
  return layout.text
    .slice(Math.max(0, start), Math.max(0, end))
    .replace(/[\u00AD\u200B-\u200F\u202A-\u202E\u2066-\u2069]/g, "")
    .replace(/[ \t]+\n/g, "\n")
    .trim();
}

// ---------------------------------------------------------------------------
// Search
// ---------------------------------------------------------------------------

/** Invisible or decorative characters that must never stop a match. */
const IGNORABLE = /[\u00AD\u0640\u200B-\u200F\u202A-\u202E\u2066-\u2069\uFEFF]/;
const MARK = /\p{M}/u;

/**
 * Letters Arabic text is spelled with interchangeably - and that PDF fonts map
 * to their Persian look-alikes (a PDF's "ي" often comes out as "ی").
 */
const LETTER_FOLD: Record<string, string> = {
  "\u06CC": "\u064A",
  "\u0649": "\u064A",
  "\u06BE": "\u0647",
  "\u06A9": "\u0643",
};

/**
 * Folds text for matching - lower case, no accents, no Hebrew niqqud or Arabic
 * harakat, Arabic presentation forms and ligatures to plain letters, every run
 * of whitespace to one space - and keeps, for each folded character, the index
 * of the original character it came from.
 */
export function foldForSearch(s: string): { folded: string; map: number[] } {
  let folded = "";
  const map: number[] = [];
  for (let i = 0; i < s.length; i++) {
    const ch = s[i];
    if (IGNORABLE.test(ch)) continue;
    if (/\s/.test(ch)) {
      if (folded.length > 0 && folded[folded.length - 1] !== " ") {
        folded += " ";
        map.push(i);
      }
      continue;
    }
    for (const c of ch.normalize("NFKD").toLowerCase()) {
      if (MARK.test(c) || IGNORABLE.test(c)) continue;
      folded += LETTER_FOLD[c] ?? c;
      map.push(i);
    }
  }
  return { folded, map };
}

export function foldQuery(q: string): string {
  return foldForSearch(q).folded.trim();
}

/**
 * The words of a search, as the notebook search reads them: quotes dropped,
 * split on spaces, each word once. A page matches when it has every word, in
 * any order - the same rule as for text boxes and notes.
 */
export function queryTerms(query: string): string[] {
  const out: string[] = [];
  for (const t of query.replace(/["“”„«»]/g, " ").split(/\s+/)) {
    if (t && foldQuery(t) && !out.some((o) => foldQuery(o) === foldQuery(t))) out.push(t);
  }
  return out;
}

/** Every match of `query` in `text`, as [start, end) offsets into `text`. */
export function findAll(text: string, query: string, max = Infinity): Array<[number, number]> {
  const q = foldQuery(query);
  if (!q) return [];
  const { folded, map } = foldForSearch(text);
  const out: Array<[number, number]> = [];
  let from = 0;
  while (out.length < max) {
    const at = folded.indexOf(q, from);
    if (at < 0) break;
    const start = map[at];
    const end = map[at + q.length - 1] + 1;
    out.push([start, end]);
    from = at + Math.max(1, q.length);
  }
  return out;
}

/**
 * A readable one-line excerpt around a match, about `size` characters, cut at
 * word boundaries where it can be, with "…" where text was left out.
 */
export function snippetAround(
  text: string,
  start: number,
  end: number,
  size = 80
): { snippet: string; matchStart: number; matchLength: number } {
  const matchLen = end - start;
  const room = Math.max(0, size - matchLen);
  let a = Math.max(0, start - Math.floor(room / 2));
  let b = Math.min(text.length, end + (room - (start - a)));
  a = Math.max(0, Math.min(a, b - size));
  // Pull each cut back to a space, but never by more than a word's worth.
  if (a > 0) {
    const sp = text.indexOf(" ", a);
    if (sp >= 0 && sp < start && sp - a < 15) a = sp + 1;
  }
  if (b < text.length) {
    const sp = text.lastIndexOf(" ", b);
    if (sp >= end && b - sp < 15) b = sp;
  }
  const flat = (s: string) => s.replace(/\s/g, " ");
  const lead = a > 0 ? "…" : "";
  const snippet = lead + flat(text.slice(a, b)) + (b < text.length ? "…" : "");
  return { snippet, matchStart: lead.length + (start - a), matchLength: matchLen };
}

// ---------------------------------------------------------------------------
// Sources
// ---------------------------------------------------------------------------

/** The subset of a pdf.js text item this module reads. */
export interface PdfTextItemLike {
  str: string;
  transform: number[];
  width: number;
  fontName?: string;
}

export interface PdfTextStyleLike {
  ascent?: number;
  descent?: number;
  vertical?: boolean;
}

function mul(m1: number[], m2: number[]): number[] {
  return [
    m1[0] * m2[0] + m1[2] * m2[1],
    m1[1] * m2[0] + m1[3] * m2[1],
    m1[0] * m2[2] + m1[2] * m2[3],
    m1[1] * m2[2] + m1[3] * m2[3],
    m1[0] * m2[4] + m1[2] * m2[5] + m1[4],
    m1[1] * m2[4] + m1[3] * m2[5] + m1[5],
  ];
}

/**
 * pdf.js text items -> runs. `viewport` is the page's viewport transform at
 * scale 1 (so the page's own /Rotate is honoured) and its size.
 *
 * An item's box is its baseline start, the width pdf.js measured, and the
 * font's ascent / descent - the same geometry pdf.js's own text layer uses.
 */
export function runsFromPdfItems(
  items: PdfTextItemLike[],
  styles: Record<string, PdfTextStyleLike | undefined>,
  viewport: { transform: number[]; width: number; height: number }
): TextRun[] {
  const out: TextRun[] = [];
  const vt = viewport.transform;
  const scale = Math.hypot(vt[0], vt[1]) || 1;
  for (const it of items) {
    if (typeof it.str !== "string" || !it.str.trim() || !Array.isArray(it.transform)) continue;
    const style = (it.fontName && styles[it.fontName]) || {};
    if (style.vertical) continue;
    const tx = mul(vt, it.transform);
    const fontH = Math.hypot(tx[2], tx[3]);
    if (!(fontH > 0)) continue;
    const ascent = style.ascent && style.ascent > 0 ? style.ascent : style.descent ? 1 + style.descent : 0.8;
    const descent = style.descent !== undefined && style.descent < 0 ? style.descent : ascent - 1;
    const angle = Math.atan2(tx[1], tx[0]);
    const ux = Math.cos(angle);
    const uy = Math.sin(angle);
    // "Up" on screen for this text direction (y grows downwards).
    const upx = uy;
    const upy = -ux;
    const w = it.width * scale;
    const up = ascent * fontH;
    const down = -descent * fontH;
    const bx = tx[4];
    const by = tx[5];
    const xs = [bx + upx * up, bx + ux * w + upx * up, bx - upx * down, bx + ux * w - upx * down];
    const ys = [by + upy * up, by + uy * w + upy * up, by - upy * down, by + uy * w - upy * down];
    const x0 = Math.min(...xs);
    const x1 = Math.max(...xs);
    const y0 = Math.min(...ys);
    const y1 = Math.max(...ys);
    if (!(x1 > x0) || !(y1 > y0)) continue;
    out.push({
      t: it.str,
      x: x0 / viewport.width,
      y: y0 / viewport.height,
      w: (x1 - x0) / viewport.width,
      h: (y1 - y0) / viewport.height,
    });
  }
  return out;
}

/**
 * Text drawn a piece at a time (PowerPoint slides are drawn with one canvas
 * call per line, word, or even letter) -> one run per stretch of a line.
 * Pieces join when they share a line and touch; repeats of the same piece in
 * the same place (a slide drawn twice, fill + outline) are dropped.
 */
export function mergeFragments(frags: TextRun[], aspect = 1): TextRun[] {
  const seen = new Set<string>();
  const out: TextRun[] = [];
  for (const f of frags) {
    if (!f.t || !(f.w > 0) || !(f.h > 0)) continue;
    const key = `${f.t}|${f.x.toFixed(4)}|${f.y.toFixed(4)}`;
    if (seen.has(key)) continue;
    seen.add(key);
    const last = out[out.length - 1];
    if (last && !/\s/.test(f.t) && f.t.length <= 2 && dirOf(f.t) === dirOf(last.t) && overlapY(last, f) >= 0.7) {
      // Letter-by-letter drawing: glue the letter on when it starts where the
      // previous piece ended.
      // Touching, not a space apart: a space is ~0.25em, and gluing across
      // one turned "is a test of it" into "isa testofit". Right-to-left
      // letters are drawn leftwards, so their gap is measured the other way.
      const gap =
        (dirOf(f.t) === "r" ? last.x - (f.x + f.w) : f.x - (last.x + last.w)) * aspect;
      if (gap >= -0.3 * f.h && gap <= 0.06 * f.h) {
        const x0 = Math.min(last.x, f.x);
        const x1 = Math.max(last.x + last.w, f.x + f.w);
        const y0 = Math.min(last.y, f.y);
        const y1 = Math.max(last.y + last.h, f.y + f.h);
        out[out.length - 1] = { t: last.t + f.t, x: x0, y: y0, w: x1 - x0, h: y1 - y0 };
        continue;
      }
    }
    out.push({ ...f });
  }
  return out;
}

// ---------------------------------------------------------------------------
// Sheet mapping
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// Marking up: highlight, underline, strike
// ---------------------------------------------------------------------------

export type MarkKind = "highlight" | "underline" | "strike";

/**
 * Strokes that mark selected lines, from line boxes already in sheet (world)
 * units: a highlighter stroke as tall as the line, or a fineliner rule under
 * the baseline or through the lower-case letters. Ordinary strokes on purpose -
 * saved, undoable, erasable and exported like ink you drew yourself.
 */
export function markStrokes(
  kind: MarkKind,
  segs: Rect[],
  color: { fill: string; ink: string },
  makeId: () => string,
  now = Date.now()
): StrokeElement[] {
  return segs
    .filter((s) => s.w > 0.5 && s.h > 0.5)
    .map((s) => {
      const style = kind === "highlight" ? "highlighter" : "fineliner";
      // A stroke renders at strokeWidth x its pen's size scale.
      const scale = PEN_TYPE_PRESETS[style].sizeScale ?? 1;
      const width = kind === "highlight" ? s.h : Math.max(1, s.h * 0.07);
      // Font boxes run ascent + descent with the baseline about 80% down, so
      // an underline sits just under it and a strike through the x-height.
      const y = kind === "highlight" ? s.y + s.h / 2 : kind === "underline" ? s.y + s.h * 0.88 : s.y + s.h * 0.56;
      const steps = 8;
      const points: [number, number, number][] = Array.from({ length: steps + 1 }, (_, i) => [(s.w * i) / steps, 0, 0.5]);
      return {
        id: makeId(),
        type: "stroke",
        x: s.x,
        y,
        rotation: 0,
        opacity: 1,
        points,
        color: kind === "highlight" ? color.fill : color.ink,
        strokeWidth: width / scale,
        strokeStyle: style,
        smoothing: 50,
        createdAt: now,
        updatedAt: now,
      } satisfies StrokeElement;
    });
}

/**
 * Where the page sits on its sheet. Pages are drawn "contain" and centred
 * (PdfPageLayer's preserveAspectRatio="xMidYMid meet"), so a page inserted
 * into a notebook of another shape is letterboxed; text must follow exactly.
 */
export function pageBoxOnSheet(page: { w: number; h: number }, sheetW: number, sheetH: number): Rect {
  if (!(page.w > 0) || !(page.h > 0)) return { x: 0, y: 0, w: sheetW, h: sheetH };
  const s = Math.min(sheetW / page.w, sheetH / page.h);
  const w = page.w * s;
  const h = page.h * s;
  return { x: (sheetW - w) / 2, y: (sheetH - h) / 2, w, h };
}
