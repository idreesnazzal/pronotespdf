/**
 * Whiteboard Geometry & Math Utilities (v3 — Obsidian Canvas & Vector Grade)
 * =========================================================================
 *
 * Provides:
 * - World <-> Screen coordinate conversions
 * - Bounding boxes & hit testing for all primitives
 * - Smart Anchor Port calculation for diagram nodes
 * - 3 Connection Routing Engines: Smooth Cubic Bezier, Orthogonal Step, Straight
 * - Directional Arrowhead polygon generators
 * - Viewport culling
 */

import type {
  ArrowElement,
  BoundingBox,
  ConnectionElement,
  DiamondElement,
  EllipseElement,
  ImageElement,
  LineElement,
  NodeAnchor,
  RectangleElement,
  StarElement,
  CloudElement,
  StickyElement,
  StrokeElement,
  TextElement,
  TriangleElement,
  WhiteboardElement,
  ArrowheadType,
} from "./types";

export type { BoundingBox };
export const HIT_THRESHOLD = 8;

export interface Viewport {
  width: number;
  height: number;
}

// ============================================================================
// Coordinate Transforms
// ============================================================================

export function worldToScreen(
  wx: number,
  wy: number,
  camera: { x: number; y: number; zoom: number },
  viewport: Viewport
): { x: number; y: number } {
  return {
    x: (wx - camera.x) * camera.zoom + viewport.width / 2,
    y: (wy - camera.y) * camera.zoom + viewport.height / 2,
  };
}

export function screenToWorld(
  sx: number,
  sy: number,
  camera: { x: number; y: number; zoom: number },
  viewport: Viewport
): { x: number; y: number } {
  return {
    x: (sx - viewport.width / 2) / camera.zoom + camera.x,
    y: (sy - viewport.height / 2) / camera.zoom + camera.y,
  };
}

/**
 * SVG transform for a group that lives INSIDE the canvas' world group but wants
 * to draw in SCREEN coordinates (the selection overlay does this: it computes
 * handle positions in screen space so handles keep a constant pixel size).
 *
 * The world group is `translate(vw/2, vh/2) scale(z) translate(-cx, -cy)`, and
 * an SVG transform list applies right-to-left, so the exact inverse is the same
 * three operations REVERSED and inverted. Listing them in the forward order
 * composes to the identity only at zoom === 1 and otherwise leaves a constant
 * offset of (camera + viewport/2) * (1 - zoom).
 */
export function screenSpaceOverlayTransform(
  camera: { x: number; y: number; zoom: number },
  viewport: Viewport
): string {
  return `translate(${camera.x}, ${camera.y}) scale(${1 / camera.zoom}) translate(${-viewport.width / 2}, ${-viewport.height / 2})`;
}

export function worldToScreenDelta(d: number, zoom: number): number {
  return d * zoom;
}

export function screenToWorldDelta(d: number, zoom: number): number {
  return d / zoom;
}

export function rotatePoint(
  px: number,
  py: number,
  cx: number,
  cy: number,
  angleRad: number
): { x: number; y: number } {
  if (angleRad === 0) return { x: px, y: py };
  const cos = Math.cos(angleRad);
  const sin = Math.sin(angleRad);
  const dx = px - cx;
  const dy = py - cy;
  return {
    x: cx + dx * cos - dy * sin,
    y: cy + dx * sin + dy * cos,
  };
}

export function clamp(v: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, v));
}

export function lerp(a: number, b: number, t: number): number {
  return a + (b - a) * t;
}

// ============================================================================
// Bounding Boxes & Centers
// ============================================================================

export function getElementBounds(el: WhiteboardElement): BoundingBox {
  switch (el.type) {
    case "stroke":
      return getStrokeBounds(el);
    case "connection":
      return { x: el.x, y: el.y, width: 0, height: 0 };
    case "rectangle":
    case "ellipse":
    case "diamond":
    case "triangle":
    case "star":
    case "cloud":
    case "text":
    case "sticky":
    case "image":
      return { x: el.x, y: el.y, width: el.width, height: el.height };
    case "line":
    case "arrow": {
      const minX = Math.min(el.x, el.x + el.x2);
      const minY = Math.min(el.y, el.y + el.y2);
      const maxX = Math.max(el.x, el.x + el.x2);
      const maxY = Math.max(el.y, el.y + el.y2);
      return { x: minX, y: minY, width: Math.max(maxX - minX, 2), height: Math.max(maxY - minY, 2) };
    }
    default: {
      // Every known element type is handled above, so this is only reached by
      // data this build does not understand: a corrupt save, or a type added
      // by a newer version. With a usable position it gets a small box there.
      // Without one it gets a NON-FINITE box, which getUnionBounds skips - the
      // old `?? 0` placed it at 0,0, dragging union bounds (and so export and
      // zoom-to-fit) all the way back to the origin.
      const unknown = el as { x?: unknown; y?: unknown };
      const x = typeof unknown.x === "number" && Number.isFinite(unknown.x) ? unknown.x : NaN;
      const y = typeof unknown.y === "number" && Number.isFinite(unknown.y) ? unknown.y : NaN;
      return { x, y, width: 10, height: 10 };
    }
  }
}

function getStrokeBounds(el: StrokeElement): BoundingBox {
  if (!el.points || el.points.length === 0) {
    return { x: el.x, y: el.y, width: 0, height: 0 };
  }
  let minX = Infinity;
  let minY = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;
  for (const [px, py] of el.points) {
    if (px < minX) minX = px;
    if (py < minY) minY = py;
    if (px > maxX) maxX = px;
    if (py > maxY) maxY = py;
  }
  const pad = Math.max((el.strokeWidth || 3) * 1.5, 4);
  return {
    x: el.x + minX - pad,
    y: el.y + minY - pad,
    width: Math.max(maxX - minX + pad * 2, pad * 2),
    height: Math.max(maxY - minY + pad * 2, pad * 2),
  };
}

export function getElementCenter(el: WhiteboardElement): { x: number; y: number } {
  if (el.type === "line" || el.type === "arrow") {
    return { x: el.x + el.x2 / 2, y: el.y + el.y2 / 2 };
  }
  const b = getElementBounds(el);
  return { x: b.x + b.width / 2, y: b.y + b.height / 2 };
}

export function getUnionBounds(elements: WhiteboardElement[]): BoundingBox | null {
  if (elements.length === 0) return null;
  let minX = Infinity;
  let minY = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;
  for (const el of elements) {
    if (el.type === "connection") continue;
    const b = getElementBounds(el);
    // An element with no usable position (unrecognised or corrupt data) has a
    // non-finite box; including it would make the whole union NaN or pin it
    // to the origin.
    if (!Number.isFinite(b.x) || !Number.isFinite(b.y)) continue;
    if (b.x < minX) minX = b.x;
    if (b.y < minY) minY = b.y;
    if (b.x + b.width > maxX) maxX = b.x + b.width;
    if (b.y + b.height > maxY) maxY = b.y + b.height;
  }
  if (!isFinite(minX)) return null;
  return { x: minX, y: minY, width: maxX - minX, height: maxY - minY };
}

// ============================================================================
// Smart Anchor Ports for Diagram Nodes (Obsidian Canvas Grade)
// ============================================================================

export interface AnchorPoint {
  x: number;
  y: number;
  nx: number; // outward normal X (-1 to 1)
  ny: number; // outward normal Y (-1 to 1)
  anchor: NodeAnchor;
}

export function getNodeAnchorPorts(el: WhiteboardElement): Record<"top" | "right" | "bottom" | "left", AnchorPoint> {
  const b = getElementBounds(el);
  const cx = b.x + b.width / 2;
  const cy = b.y + b.height / 2;
  const rot = el.rotation || 0;

  const topUnrot = { x: cx, y: b.y };
  const rightUnrot = { x: b.x + b.width, y: cy };
  const bottomUnrot = { x: cx, y: b.y + b.height };
  const leftUnrot = { x: b.x, y: cy };

  const top = rotatePoint(topUnrot.x, topUnrot.y, cx, cy, rot);
  const right = rotatePoint(rightUnrot.x, rightUnrot.y, cx, cy, rot);
  const bottom = rotatePoint(bottomUnrot.x, bottomUnrot.y, cx, cy, rot);
  const left = rotatePoint(leftUnrot.x, leftUnrot.y, cx, cy, rot);

  const cos = Math.cos(rot);
  const sin = Math.sin(rot);

  return {
    top: { x: top.x, y: top.y, nx: sin, ny: -cos, anchor: "top" },
    right: { x: right.x, y: right.y, nx: cos, ny: sin, anchor: "right" },
    bottom: { x: bottom.x, y: bottom.y, nx: -sin, ny: cos, anchor: "bottom" },
    left: { x: left.x, y: left.y, nx: -cos, ny: -sin, anchor: "left" },
  };
}

export function getResolvedAnchorPoint(
  el: WhiteboardElement,
  anchor: NodeAnchor,
  targetPos?: { x: number; y: number }
): AnchorPoint {
  const ports = getNodeAnchorPorts(el);
  const b = getElementBounds(el);
  const cx = b.x + b.width / 2;
  const cy = b.y + b.height / 2;

  if (anchor === "center") {
    return { x: cx, y: cy, nx: 0, ny: 0, anchor: "center" };
  }

  if (anchor === "auto" || !anchor) {
    if (!targetPos) return ports.right;
    // Pick the closest port to targetPos
    const dTop = Math.hypot(ports.top.x - targetPos.x, ports.top.y - targetPos.y);
    const dRight = Math.hypot(ports.right.x - targetPos.x, ports.right.y - targetPos.y);
    const dBottom = Math.hypot(ports.bottom.x - targetPos.x, ports.bottom.y - targetPos.y);
    const dLeft = Math.hypot(ports.left.x - targetPos.x, ports.left.y - targetPos.y);
    const min = Math.min(dTop, dRight, dBottom, dLeft);
    if (min === dTop) return ports.top;
    if (min === dRight) return ports.right;
    if (min === dBottom) return ports.bottom;
    return ports.left;
  }

  return ports[anchor as "top" | "right" | "bottom" | "left"] || ports.right;
}

export function getOptimalConnectionAnchors(
  sourceEl: WhiteboardElement,
  targetEl: WhiteboardElement,
  preferredSourceAnchor: NodeAnchor = "auto",
  preferredTargetAnchor: NodeAnchor = "auto"
): { source: AnchorPoint; target: AnchorPoint } {
  const sCenter = getElementCenter(sourceEl);
  const tCenter = getElementCenter(targetEl);

  const sAnchor = getResolvedAnchorPoint(sourceEl, preferredSourceAnchor, tCenter);
  const tAnchor = getResolvedAnchorPoint(targetEl, preferredTargetAnchor, sAnchor);

  return { source: sAnchor, target: tAnchor };
}

// ============================================================================
// 3 Connection Routing Engines (Obsidian / Heptabase / Flow Grade)
// ============================================================================

/**
 * 1. Smooth Cubic Bezier S-Curve with Tangent Normals
 */
export function getCurvedBezierPath(
  p1: AnchorPoint,
  p2: AnchorPoint
): string {
  const dx = p2.x - p1.x;
  const dy = p2.y - p1.y;
  const dist = Math.hypot(dx, dy);

  if (dist < 2) {
    return `M ${p1.x},${p1.y} L ${p2.x},${p2.y}`;
  }

  // Tangent strength based on distance and orientation
  const curvature = Math.min(Math.max(dist * 0.4, 30), 200);

  const cx1 = p1.x + p1.nx * curvature;
  const cy1 = p1.y + p1.ny * curvature;
  const cx2 = p2.x + p2.nx * curvature;
  const cy2 = p2.y + p2.ny * curvature;

  return `M ${p1.x},${p1.y} C ${cx1},${cy1} ${cx2},${cy2} ${p2.x},${p2.y}`;
}

/**
 * 2. Orthogonal Step (Elbow) Path with Smooth Rounded Corners
 */
export function getOrthogonalPath(
  p1: AnchorPoint,
  p2: AnchorPoint
): string {
  const dx = p2.x - p1.x;
  const dy = p2.y - p1.y;
  const dist = Math.hypot(dx, dy);

  if (dist < 4) {
    return `M ${p1.x},${p1.y} L ${p2.x},${p2.y}`;
  }

  const r = Math.min(12, dist / 4); // fillet radius
  const margin = Math.min(24, dist * 0.2);

  const startOutX = p1.x + p1.nx * margin;
  const startOutY = p1.y + p1.ny * margin;
  const endOutX = p2.x + p2.nx * margin;
  const endOutY = p2.y + p2.ny * margin;

  const midX = (startOutX + endOutX) / 2;
  const midY = (startOutY + endOutY) / 2;

  // If mostly horizontal or vertical orientation
  if (Math.abs(p1.nx) > 0.5 && Math.abs(p2.nx) > 0.5) {
    return `M ${p1.x},${p1.y} L ${midX},${p1.y} L ${midX},${p2.y} L ${p2.x},${p2.y}`;
  } else if (Math.abs(p1.ny) > 0.5 && Math.abs(p2.ny) > 0.5) {
    return `M ${p1.x},${p1.y} L ${p1.x},${midY} L ${p2.x},${midY} L ${p2.x},${p2.y}`;
  } else {
    // Corner turn
    if (Math.abs(p1.nx) > 0.5) {
      return `M ${p1.x},${p1.y} L ${p2.x},${p1.y} L ${p2.x},${p2.y}`;
    } else {
      return `M ${p1.x},${p1.y} L ${p1.x},${p2.y} L ${p2.x},${p2.y}`;
    }
  }
}

/**
 * 3. Straight Directed Line
 */
export function getStraightPath(
  p1: AnchorPoint,
  p2: AnchorPoint
): string {
  return `M ${p1.x},${p1.y} L ${p2.x},${p2.y}`;
}

export function getConnectionPath(
  p1: AnchorPoint,
  p2: AnchorPoint,
  routing: "curved" | "orthogonal" | "straight" = "curved"
): string {
  switch (routing) {
    case "orthogonal":
      return getOrthogonalPath(p1, p2);
    case "straight":
      return getStraightPath(p1, p2);
    case "curved":
    default:
      return getCurvedBezierPath(p1, p2);
  }
}

// ============================================================================
// Arrowhead Polygon Generators
// ============================================================================

export function getArrowheadPath(
  tipX: number,
  tipY: number,
  fromX: number,
  fromY: number,
  type: ArrowheadType = "arrow",
  size: number = 10
): { path: string; fill: string; stroke: string } | null {
  if (type === "none") return null;

  const dx = tipX - fromX;
  const dy = tipY - fromY;
  const len = Math.hypot(dx, dy);
  if (len < 0.001) return null;

  const ux = dx / len;
  const uy = dy / len;
  const px = -uy;
  const py = ux;

  switch (type) {
    case "triangle":
    case "arrow": {
      const p1x = tipX - ux * size + px * (size * 0.5);
      const p1y = tipY - uy * size + py * (size * 0.5);
      const p2x = tipX - ux * size - px * (size * 0.5);
      const p2y = tipY - uy * size - py * (size * 0.5);
      return {
        path: `M ${tipX},${tipY} L ${p1x},${p1y} L ${p2x},${p2y} Z`,
        fill: "currentColor",
        stroke: "none",
      };
    }
    case "stealth": {
      const p1x = tipX - ux * (size * 1.2) + px * (size * 0.5);
      const p1y = tipY - uy * (size * 1.2) + py * (size * 0.5);
      const notchX = tipX - ux * (size * 0.8);
      const notchY = tipY - uy * (size * 0.8);
      const p2x = tipX - ux * (size * 1.2) - px * (size * 0.5);
      const p2y = tipY - uy * (size * 1.2) - py * (size * 0.5);
      return {
        path: `M ${tipX},${tipY} L ${p1x},${p1y} L ${notchX},${notchY} L ${p2x},${p2y} Z`,
        fill: "currentColor",
        stroke: "none",
      };
    }
    case "diamond": {
      const midX = tipX - ux * size;
      const midY = tipY - uy * size;
      const backX = tipX - ux * (size * 2);
      const backY = tipY - uy * (size * 2);
      const p1x = midX + px * (size * 0.45);
      const p1y = midY + py * (size * 0.45);
      const p2x = midX - px * (size * 0.45);
      const p2y = midY - py * (size * 0.45);
      return {
        path: `M ${tipX},${tipY} L ${p1x},${p1y} L ${backX},${backY} L ${p2x},${p2y} Z`,
        fill: "currentColor",
        stroke: "none",
      };
    }
    case "circle": {
      const cx = tipX - ux * (size * 0.5);
      const cy = tipY - uy * (size * 0.5);
      const r = size * 0.4;
      return {
        path: `M ${cx - r},${cy} a ${r},${r} 0 1,0 ${r * 2},0 a ${r},${r} 0 1,0 ${-r * 2},0`,
        fill: "currentColor",
        stroke: "none",
      };
    }
    default:
      return null;
  }
}

// ============================================================================
// Hit Testing
// ============================================================================

export function hitTestElement(
  el: WhiteboardElement,
  worldX: number,
  worldY: number,
  tolerance: number = HIT_THRESHOLD,
  allElements?: WhiteboardElement[]
): boolean {
  if (el.locked) return false;

  const b = getElementBounds(el);
  const cx = b.x + b.width / 2;
  const cy = b.y + b.height / 2;
  const rot = el.rotation || 0;

  // Un-rotate the point into element's local frame
  const local = rotatePoint(worldX, worldY, cx, cy, -rot);

  switch (el.type) {
    case "rectangle":
    case "text":
    case "sticky":
    case "image":
      return (
        local.x >= el.x - tolerance &&
        local.x <= el.x + el.width + tolerance &&
        local.y >= el.y - tolerance &&
        local.y <= el.y + el.height + tolerance
      );
    case "ellipse": {
      const rx = el.width / 2 + tolerance;
      const ry = el.height / 2 + tolerance;
      if (rx <= 0 || ry <= 0) return false;
      const nx = (local.x - cx) / rx;
      const ny = (local.y - cy) / ry;
      return nx * nx + ny * ny <= 1;
    }
    case "diamond": {
      const dx = Math.abs(local.x - cx) / (el.width / 2 + tolerance);
      const dy = Math.abs(local.y - cy) / (el.height / 2 + tolerance);
      return dx + dy <= 1;
    }
    case "triangle":
    case "star":
    case "cloud": {
      // Conservative bounding box test
      return (
        local.x >= el.x - tolerance &&
        local.x <= el.x + el.width + tolerance &&
        local.y >= el.y - tolerance &&
        local.y <= el.y + el.height + tolerance
      );
    }
    case "line":
    case "arrow": {
      const x1 = el.x;
      const y1 = el.y;
      const x2 = el.x + el.x2;
      const y2 = el.y + el.y2;
      // Use the un-rotated query point so rotated lines hit-test correctly
      const dist = distanceToSegment(local.x, local.y, x1, y1, x2, y2);
      return dist <= (el.strokeWidth || 2) / 2 + tolerance;
    }
    case "stroke": {
      if (!el.points || el.points.length === 0) return false;
      const radius = Math.max((el.strokeWidth || 3) / 2, 2) + tolerance;
      // Query point was un-rotated into the element's local frame above
      // (`local`), so rotated strokes hit-test against their VISIBLE geometry.
      if (el.points.length === 1) {
        const [px, py] = el.points[0];
        return Math.hypot(local.x - (el.x + px), local.y - (el.y + py)) <= radius;
      }
      for (let i = 0; i < el.points.length - 1; i++) {
        const p1 = el.points[i];
        const p2 = el.points[i + 1];
        const dist = distanceToSegment(
          local.x,
          local.y,
          el.x + p1[0],
          el.y + p1[1],
          el.x + p2[0],
          el.y + p2[1]
        );
        if (dist <= radius) return true;
      }
      return false;
    }
    case "connection": {
      if (!allElements) return false;
      const conn = el as ConnectionElement;
      const sourceEl = allElements.find((e) => e.id === conn.source.elementId);
      const targetEl = allElements.find((e) => e.id === conn.target.elementId);
      if (!sourceEl || !targetEl) return false;

      const { source, target } = getOptimalConnectionAnchors(
        sourceEl,
        targetEl,
        conn.source.anchor,
        conn.target.anchor
      );

      const hitRadius = (conn.strokeWidth || 2.5) / 2 + tolerance + 4;
      const routing = conn.routing || "curved";

      if (routing === "straight") {
        return distanceToSegment(worldX, worldY, source.x, source.y, target.x, target.y) <= hitRadius;
      }

      if (routing === "orthogonal") {
        const dx = target.x - source.x;
        const dy = target.y - source.y;
        const dist = Math.hypot(dx, dy);
        const margin = Math.min(24, dist * 0.2);
        const startOutX = source.x + source.nx * margin;
        const startOutY = source.y + source.ny * margin;
        const endOutX = target.x + target.nx * margin;
        const endOutY = target.y + target.ny * margin;
        const midX = (startOutX + endOutX) / 2;
        const midY = (startOutY + endOutY) / 2;

        let waypoints: Array<{ x: number; y: number }> = [];
        if (Math.abs(source.nx) > 0.5 && Math.abs(target.nx) > 0.5) {
          waypoints = [
            { x: source.x, y: source.y },
            { x: midX, y: source.y },
            { x: midX, y: target.y },
            { x: target.x, y: target.y },
          ];
        } else if (Math.abs(source.ny) > 0.5 && Math.abs(target.ny) > 0.5) {
          waypoints = [
            { x: source.x, y: source.y },
            { x: source.x, y: midY },
            { x: target.x, y: midY },
            { x: target.x, y: target.y },
          ];
        } else {
          if (Math.abs(source.nx) > 0.5) {
            waypoints = [
              { x: source.x, y: source.y },
              { x: target.x, y: source.y },
              { x: target.x, y: target.y },
            ];
          } else {
            waypoints = [
              { x: source.x, y: source.y },
              { x: source.x, y: target.y },
              { x: target.x, y: target.y },
            ];
          }
        }

        for (let i = 0; i < waypoints.length - 1; i++) {
          if (
            distanceToSegment(
              worldX,
              worldY,
              waypoints[i].x,
              waypoints[i].y,
              waypoints[i + 1].x,
              waypoints[i + 1].y
            ) <= hitRadius
          ) {
            return true;
          }
        }
        return false;
      }

      // Curved Bezier (sample 24 intervals along cubic curve)
      const dx = target.x - source.x;
      const dy = target.y - source.y;
      const dist = Math.hypot(dx, dy);
      const curvature = Math.min(Math.max(dist * 0.4, 30), 200);

      const cx1 = source.x + source.nx * curvature;
      const cy1 = source.y + source.ny * curvature;
      const cx2 = target.x + target.nx * curvature;
      const cy2 = target.y + target.ny * curvature;

      let prevX = source.x;
      let prevY = source.y;
      const steps = 24;
      for (let i = 1; i <= steps; i++) {
        const t = i / steps;
        const omt = 1 - t;
        const currX =
          omt * omt * omt * source.x +
          3 * omt * omt * t * cx1 +
          3 * omt * t * t * cx2 +
          t * t * t * target.x;
        const currY =
          omt * omt * omt * source.y +
          3 * omt * omt * t * cy1 +
          3 * omt * t * t * cy2 +
          t * t * t * target.y;

        if (distanceToSegment(worldX, worldY, prevX, prevY, currX, currY) <= hitRadius) {
          return true;
        }
        prevX = currX;
        prevY = currY;
      }
      return false;
    }
    default:
      return false;
  }
}

/**
 * Test if a 2D point falls inside a closed 2D polygon using the ray-casting algorithm (even-odd rule).
 */
export function isPointInPolygon(
  px: number,
  py: number,
  polygon: Array<{ x: number; y: number }>
): boolean {
  if (polygon.length < 3) return false;
  let inside = false;
  for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
    const xi = polygon[i].x;
    const yi = polygon[i].y;
    const xj = polygon[j].x;
    const yj = polygon[j].y;

    const intersect =
      yi > py !== yj > py &&
      px < ((xj - xi) * (py - yi)) / (yj - yi) + xi;
    if (intersect) inside = !inside;
  }
  return inside;
}

/**
 * Every visible point of an element, in world units: rotation pivot first,
 * then stroke samples / line endpoints, then the visible bounds corners.
 * Loose lasso selects when ANY is inside; strict encircle requires ALL.
 */
export function sampleElementPoints(el: WhiteboardElement): Array<{ x: number; y: number }> {
  const b = getElementBounds(el);
  const rot = el.rotation || 0;
  const bcx = b.x + b.width / 2;
  const bcy = b.y + b.height / 2;
  const place =
    rot !== 0 ? (x: number, y: number) => rotatePoint(x, y, bcx, bcy, rot) : (x: number, y: number) => ({ x, y });

  // 1. Center containment (the center is the rotation pivot, so it is
  // rotation-invariant).
  const center = getElementCenter(el);
  const pts = [place(center.x, center.y)];

  // 2. Stroke sample points (rotated into visible position)
  if (el.type === "stroke" && el.points) {
    for (const [px, py] of el.points) {
      pts.push(place(el.x + px, el.y + py));
    }
  }

  // 3. Line / Arrow endpoints (rotated into visible position)
  if (el.type === "line" || el.type === "arrow") {
    pts.push(place(el.x, el.y));
    pts.push(place(el.x + el.x2, el.y + el.y2));
  }

  // 4. Bounding box corners — rotated so lasso matches the VISIBLE quad
  for (const corner of [
    { x: b.x, y: b.y },
    { x: b.x + b.width, y: b.y },
    { x: b.x + b.width, y: b.y + b.height },
    { x: b.x, y: b.y + b.height },
  ]) {
    pts.push(place(corner.x, corner.y));
  }

  return pts;
}

/**
 * Test if a whiteboard element is contained in or intersects with a freeform polygon (e.g. for Lasso selection).
 */
export function isElementInPolygon(
  el: WhiteboardElement,
  polygon: Array<{ x: number; y: number }>
): boolean {
  if (polygon.length < 3) return false;
  return sampleElementPoints(el).some((p) => isPointInPolygon(p.x, p.y, polygon));
}

/**
 * Where an element actually IS, for a containment test — which is not the
 * same set of points as "any part of it", and the difference decides whether
 * strict encircle is usable on handwriting at all.
 *
 * A stroke's bounding box is a rectangle around a curve: for a diagonal line
 * the box corners sit in empty space, far off the ink. Requiring THOSE inside
 * the loop means the Samsung gesture this mode exists for — snaking a loop
 * between two lines of writing to lift one word — always fails, because the
 * corners of the word's box are up in the line above. So ink is tested as
 * ink, and only elements with no finer geometry fall back to their box.
 */
export function outlineElementPoints(el: WhiteboardElement): Array<{ x: number; y: number }> {
  const b = getElementBounds(el);
  const rot = el.rotation || 0;
  const bcx = b.x + b.width / 2;
  const bcy = b.y + b.height / 2;
  const place =
    rot !== 0 ? (x: number, y: number) => rotatePoint(x, y, bcx, bcy, rot) : (x: number, y: number) => ({ x, y });

  // Handwriting: the ink itself, sampled along the path.
  if (el.type === "stroke" && el.points && el.points.length > 0) {
    return el.points.map(([px, py]) => place(el.x + px, el.y + py));
  }

  // A line or arrow is its two ends; the box around a diagonal is mostly air.
  if (el.type === "line" || el.type === "arrow") {
    return [place(el.x, el.y), place(el.x + el.x2, el.y + el.y2)];
  }

  // Rectangles, ellipses, text, stickies, images: the box IS the extent.
  return [
    { x: b.x, y: b.y },
    { x: b.x + b.width, y: b.y },
    { x: b.x + b.width, y: b.y + b.height },
    { x: b.x, y: b.y + b.height },
  ].map((c) => place(c.x, c.y));
}

/**
 * Samsung-style strict encircle: the whole element must lie inside the loop.
 * A neighbour the loop only grazes stays unselected — the surgical precision
 * the loose lasso trades away for speed.
 */
export function isElementFullyInPolygon(
  el: WhiteboardElement,
  polygon: Array<{ x: number; y: number }>
): boolean {
  if (polygon.length < 3) return false;
  const pts = outlineElementPoints(el);
  if (pts.length === 0) return false;
  return pts.every((p) => isPointInPolygon(p.x, p.y, polygon));
}

function distanceToSegment(
  px: number,
  py: number,
  x1: number,
  y1: number,
  x2: number,
  y2: number
): number {
  const dx = x2 - x1;
  const dy = y2 - y1;
  const lenSq = dx * dx + dy * dy;
  if (lenSq === 0) return Math.hypot(px - x1, py - y1);
  const t = clamp(((px - x1) * dx + (py - y1) * dy) / lenSq, 0, 1);
  const projX = x1 + t * dx;
  const projY = y1 + t * dy;
  return Math.hypot(px - projX, py - projY);
}

// ============================================================================
// Resize Handles
// ============================================================================

export function getResizeHandles(
  bounds: BoundingBox,
  rotation: number,
  camera: { x: number; y: number; zoom: number },
  viewport: Viewport
): Array<{ handle: string; x: number; y: number }> {
  const cx = bounds.x + bounds.width / 2;
  const cy = bounds.y + bounds.height / 2;
  const hw = bounds.width / 2;
  const hh = bounds.height / 2;

  const localHandles: Array<{ handle: string; x: number; y: number }> = [
    { handle: "nw", x: cx - hw, y: cy - hh },
    { handle: "n", x: cx, y: cy - hh },
    { handle: "ne", x: cx + hw, y: cy - hh },
    { handle: "e", x: cx + hw, y: cy },
    { handle: "se", x: cx + hw, y: cy + hh },
    { handle: "s", x: cx, y: cy + hh },
    { handle: "sw", x: cx - hw, y: cy + hh },
    { handle: "w", x: cx - hw, y: cy },
    // 44 screen px above the top edge: far enough that the rotate handle's
    // touch target does not swallow the top-centre resize handle's.
    { handle: "rotate", x: cx, y: cy - hh - 44 / camera.zoom },
  ];

  return localHandles.map((h) => {
    const rotated = rotatePoint(h.x, h.y, cx, cy, rotation);
    return {
      handle: h.handle,
      x: (rotated.x - camera.x) * camera.zoom + viewport.width / 2,
      y: (rotated.y - camera.y) * camera.zoom + viewport.height / 2,
    };
  });
}

// ============================================================================
// Viewport Culling
// ============================================================================

export function isVisibleInViewport(
  bounds: BoundingBox,
  rotation: number,
  camera: { x: number; y: number; zoom: number },
  viewport: Viewport
): boolean {
  const halfW = viewport.width / 2 / camera.zoom;
  const halfH = viewport.height / 2 / camera.zoom;
  const margin = 80;
  const viewLeft = camera.x - halfW - margin;
  const viewRight = camera.x + halfW + margin;
  const viewTop = camera.y - halfH - margin;
  const viewBottom = camera.y + halfH + margin;

  return !(
    bounds.x + bounds.width < viewLeft ||
    bounds.x > viewRight ||
    bounds.y + bounds.height < viewTop ||
    bounds.y > viewBottom
  );
}

// ============================================================================
// Alignment & Distribution Utilities
// ============================================================================

export type AlignmentType = "left" | "center" | "right" | "top" | "middle" | "bottom";

export function alignElements(
  elements: WhiteboardElement[],
  alignment: AlignmentType
): WhiteboardElement[] {
  if (elements.length <= 1) return elements;
  const union = getUnionBounds(elements);
  if (!union) return elements;

  return elements.map((el) => {
    if (el.type === "connection") return el;
    const b = getElementBounds(el);
    let dx = 0;
    let dy = 0;

    switch (alignment) {
      case "left":
        dx = union.x - b.x;
        break;
      case "center":
        dx = union.x + (union.width - b.width) / 2 - b.x;
        break;
      case "right":
        dx = union.x + union.width - b.width - b.x;
        break;
      case "top":
        dy = union.y - b.y;
        break;
      case "middle":
        dy = union.y + (union.height - b.height) / 2 - b.y;
        break;
      case "bottom":
        dy = union.y + union.height - b.height - b.y;
        break;
    }

    return {
      ...el,
      x: el.x + dx,
      y: el.y + dy,
      updatedAt: Date.now(),
    };
  });
}

export function distributeElements(
  elements: WhiteboardElement[],
  axis: "horizontal" | "vertical"
): WhiteboardElement[] {
  const validElements = elements.filter((el) => el.type !== "connection");
  if (validElements.length < 3) return elements;

  if (axis === "horizontal") {
    const sorted = [...validElements].sort((a, b) => {
      const ba = getElementBounds(a);
      const bb = getElementBounds(b);
      return ba.x - bb.x;
    });

    const first = getElementBounds(sorted[0]);
    const last = getElementBounds(sorted[sorted.length - 1]);
    const totalWidth = sorted.reduce((sum, el) => sum + getElementBounds(el).width, 0);
    const span = last.x + last.width - first.x;
    const gap = (span - totalWidth) / (sorted.length - 1);

    let currentX = first.x;
    const updatedMap = new Map<string, number>();

    for (let i = 0; i < sorted.length; i++) {
      const el = sorted[i];
      const b = getElementBounds(el);
      const dx = currentX - b.x;
      updatedMap.set(el.id, el.x + dx);
      currentX += b.width + gap;
    }

    return elements.map((el) => {
      if (updatedMap.has(el.id)) {
        return { ...el, x: updatedMap.get(el.id)!, updatedAt: Date.now() };
      }
      return el;
    });
  } else {
    const sorted = [...validElements].sort((a, b) => {
      const ba = getElementBounds(a);
      const bb = getElementBounds(b);
      return ba.y - bb.y;
    });

    const first = getElementBounds(sorted[0]);
    const last = getElementBounds(sorted[sorted.length - 1]);
    const totalHeight = sorted.reduce((sum, el) => sum + getElementBounds(el).height, 0);
    const span = last.y + last.height - first.y;
    const gap = (span - totalHeight) / (sorted.length - 1);

    let currentY = first.y;
    const updatedMap = new Map<string, number>();

    for (let i = 0; i < sorted.length; i++) {
      const el = sorted[i];
      const b = getElementBounds(el);
      const dy = currentY - b.y;
      updatedMap.set(el.id, el.y + dy);
      currentY += b.height + gap;
    }

    return elements.map((el) => {
      if (updatedMap.has(el.id)) {
        return { ...el, y: updatedMap.get(el.id)!, updatedAt: Date.now() };
      }
      return el;
    });
  }
}
