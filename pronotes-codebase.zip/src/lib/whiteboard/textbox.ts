/**
 * Text boxes that were started but never written in.
 *
 * Tapping with the text tool creates a box immediately so you can start
 * typing. If you tap away without typing, the box used to stay on the page as
 * an invisible element that only showed a "Type thoughts..." placeholder while
 * selected - and they piled up, because nothing ever removed them. GoodNotes,
 * Notability and OneNote all throw such a box away, and so do we: the store
 * discards it when editing ends (see `discardAbandonedText` in the store), and
 * the loader drops ones that older builds left behind (persistence.ts).
 *
 * ONE definition, used by both, so they can never disagree.
 */
import type { WhiteboardElement } from "./types";

export function isAbandonedTextBox(el: WhiteboardElement | null | undefined): boolean {
  if (!el || el.type !== "text") return false;
  const t = el as { text?: unknown; backgroundColor?: unknown; borderColor?: unknown };
  if (typeof t.text === "string" && t.text.trim() !== "") return false;
  // An empty box that was deliberately given a fill or border is being used
  // as a shape, not abandoned. Keep it.
  if (typeof t.backgroundColor === "string" && t.backgroundColor && t.backgroundColor !== "transparent") return false;
  if (typeof t.borderColor === "string" && t.borderColor && t.borderColor !== "transparent") return false;
  return true;
}
