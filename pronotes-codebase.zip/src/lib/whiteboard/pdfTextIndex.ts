/**
 * The text of a notebook's PDF / Word / PowerPoint pages, on demand
 * =================================================================
 * One place that answers "what text is on this page, and where": for the
 * Select-text tool, for the find highlight, and for the notebook search.
 *
 * Lazy by design. A 90-page lecture PDF is never read in one go when you open
 * it: a page's text is extracted the first time something asks for that page
 * (you pick up the text tool on it, or a search walks past it), then kept in
 * memory and in IndexedDB (pdfTextStore.ts), so the next search is instant and
 * survives a restart.
 */

import type { PDFDocumentProxy } from "pdfjs-dist";
import type { Board, PdfPageRef } from "./types";
import { getPages } from "./notebook";
import {
  findAll,
  layoutPage,
  queryTerms,
  runsFromPdfItems,
  snippetAround,
  type PageLayout,
  type PageText,
  type PdfTextItemLike,
  type PdfTextStyleLike,
} from "./pdfText";

export interface PdfTextHit {
  pageIndex: number;      // 0-based page index within the notebook
  pageId?: string;        // the notebook page id, if known
  snippet: string;        // ~80 chars around the match, readable order
  matchStart: number;     // index of the match inside snippet
  matchLength: number;
  /** Which match on its page this is (0 = the first), so find can go to it. */
  ordinal?: number;
}

interface DocState {
  source: "office" | "pdf";
  pages: Array<PageText | null>;
  layouts: Map<number, PageLayout | null>;
  inflight: Map<number, Promise<PageText>>;
  saveTimer: ReturnType<typeof setTimeout> | null;
  /**
   * The stored record could not be read. Nothing is written back then: the
   * record may hold a Word/PowerPoint file's text, which exists nowhere else.
   */
  readFailed?: boolean;
}

const docs = new Map<string, Promise<DocState>>();

/** Reads the stored record once per document; a failed read means "none yet". */
function docState(docId: string): Promise<DocState> {
  let d = docs.get(docId);
  if (!d) {
    d = (async (): Promise<DocState> => {
      const fresh: DocState = { source: "pdf", pages: [], layouts: new Map(), inflight: new Map(), saveTimer: null };
      try {
        const { getDocText, PDF_TEXT_VERSION } = await import("./pdfTextStore");
        const rec = await getDocText(docId);
        if (rec && Array.isArray(rec.pages) && (rec.source === "office" || rec.version === PDF_TEXT_VERSION)) {
          return { ...fresh, source: rec.source, pages: rec.pages };
        }
      } catch {
        // No IndexedDB (or a broken record): extract again, in memory only,
        // and ask again next time instead of trusting this for the session.
        queueMicrotask(() => docs.delete(docId));
        return { ...fresh, readFailed: true };
      }
      return fresh;
    })();
    docs.set(docId, d);
  }
  return d;
}

/** Writes a document's extracted pages back, a moment after the last one. */
function scheduleSave(docId: string, st: DocState) {
  if (st.source !== "pdf" || st.readFailed) return;
  if (st.saveTimer) clearTimeout(st.saveTimer);
  st.saveTimer = setTimeout(async () => {
    st.saveTimer = null;
    try {
      const { putDocText, PDF_TEXT_VERSION } = await import("./pdfTextStore");
      await putDocText({ id: docId, source: "pdf", version: PDF_TEXT_VERSION, pages: st.pages });
    } catch {
      // A cache: failing to keep it only means reading the page again later.
    }
  }, 1500);
}

async function extractPdfPage(docId: string, pageNumber: number, opened?: PDFDocumentProxy): Promise<PageText> {
  const doc = opened ?? (await (await import("./pdf")).openStoredPdf(docId));
  if (pageNumber < 1 || pageNumber > doc.numPages) return { w: 1, h: 1, runs: [] };
  const page = await doc.getPage(pageNumber);
  const viewport = page.getViewport({ scale: 1 });
  const content = await page.getTextContent();
  const items = content.items.filter((it): it is typeof it & PdfTextItemLike => "str" in it);
  const runs = runsFromPdfItems(items, content.styles as Record<string, PdfTextStyleLike>, {
    transform: viewport.transform,
    width: viewport.width,
    height: viewport.height,
  });
  return { w: viewport.width, h: viewport.height, runs };
}

/** The raw text of one page. Never rejects: a page it cannot read has none. */
export async function getPageText(ref: PdfPageRef, opened?: PDFDocumentProxy): Promise<PageText> {
  const st = await docState(ref.docId);
  const i = ref.pageNumber - 1;
  const have = st.pages[i];
  if (have) return have;
  // A converted Office file has ALL its text in its record; a page missing
  // from it has none, and pdf.js would find nothing in a picture anyway.
  if (st.source === "office") return { w: 1, h: 1, runs: [] };
  let p = st.inflight.get(i);
  if (!p) {
    p = extractPdfPage(ref.docId, ref.pageNumber, opened)
      .then((text) => {
        st.pages[i] = text;
        st.layouts.delete(i);
        scheduleSave(ref.docId, st);
        return text;
      })
      // A page that failed to read (memory, a race with a delete) has no text
      // THIS time only: nothing is kept, so the next ask tries again rather
      // than calling it a scan forever.
      .catch(() => ({ w: 1, h: 1, runs: [] }) as PageText);
    st.inflight.set(i, p);
    p.finally(() => st.inflight.delete(i));
  }
  return p;
}

/** A page's text laid out for reading and selection; null when it has none. */
export async function getPageLayout(ref: PdfPageRef, opened?: PDFDocumentProxy): Promise<PageLayout | null> {
  const text = await getPageText(ref, opened);
  const st = await docState(ref.docId);
  const i = ref.pageNumber - 1;
  if (st.layouts.has(i)) return st.layouts.get(i) ?? null;
  const layout = text.runs.length ? layoutPage(text) : null;
  st.layouts.set(i, layout);
  return layout;
}

/**
 * Whether a page-less-of-text document is a Word / PowerPoint file converted
 * before text was captured: those PDFs were written by jsPDF. Lets the tool
 * say "open the file again" instead of "this is a scan".
 */
export async function isImageOnlyOfficeImport(docId: string): Promise<boolean> {
  try {
    const st = await docState(docId);
    if (st.source === "office") return false;
    const { openStoredPdf } = await import("./pdf");
    const doc = await openStoredPdf(docId);
    const meta = await doc.getMetadata();
    const info = (meta?.info ?? {}) as { Producer?: string; Creator?: string };
    return /jspdf/i.test(`${info.Producer ?? ""} ${info.Creator ?? ""}`);
  } catch {
    return false;
  }
}

/**
 * Stores the captured text of a converted Word / PowerPoint file under the id
 * its PDF was given, and makes it the document's text at once.
 */
export async function saveOfficeText(docId: string, pages: PageText[]): Promise<void> {
  docs.set(docId, Promise.resolve({ source: "office", pages, layouts: new Map(), inflight: new Map(), saveTimer: null }));
  const { putDocText, PDF_TEXT_VERSION } = await import("./pdfTextStore");
  await putDocText({ id: docId, source: "office", version: PDF_TEXT_VERSION, pages });
}

/** Most matches listed for one page, so one busy page cannot hide the rest. */
const HITS_PER_PAGE = 5;

/**
 * A document for reading text in a search. One that is already open (shown on
 * screen) is shared; otherwise it is opened just for this search and closed
 * after it - searching "everywhere" must not leave every PDF in the
 * workspace open for the rest of the session.
 */
async function openForSearch(docId: string): Promise<{ doc: PDFDocumentProxy; close: () => void }> {
  const { peekStoredPdf, openPdf } = await import("./pdf");
  const shared = peekStoredPdf(docId);
  if (shared) return { doc: await shared, close: () => {} };
  const { getPdf } = await import("./pdfstore");
  const stored = await getPdf(docId);
  if (!stored) throw new Error("This PDF is no longer stored on this device.");
  const doc = await openPdf(stored.bytes);
  return { doc, close: () => void doc.loadingTask.destroy().catch(() => {}) };
}

/**
 * Text hits for `query` in a notebook's PDF/Office pages. Case- and
 * diacritic-insensitive; with several words, a page must contain all of them
 * (any order), and the hits are placed on the first word. `signal` stops a
 * search that is no longer wanted between pages.
 */
export async function searchNotebookPdfText(
  board: Board,
  query: string,
  limit = 100,
  options: { signal?: AbortSignal } = {}
): Promise<PdfTextHit[]> {
  const hits: PdfTextHit[] = [];
  const terms = queryTerms(query ?? "");
  if (terms.length === 0) return hits;
  const pages = getPages(board);
  const opened = new Map<string, { doc: PDFDocumentProxy; close: () => void }>();
  try {
    for (let i = 0; i < pages.length && hits.length < limit; i++) {
      if (options.signal?.aborted) break;
      const ref = pages[i].pdf;
      if (!ref?.docId) continue;
      // Only open the document when a page's text is not known yet.
      const st = await docState(ref.docId);
      let doc: PDFDocumentProxy | undefined;
      if (!st.pages[ref.pageNumber - 1] && st.source === "pdf") {
        let o = opened.get(ref.docId);
        if (!o) {
          try {
            o = await openForSearch(ref.docId);
          } catch {
            continue;
          }
          opened.set(ref.docId, o);
        }
        doc = o.doc;
      }
      const layout = await getPageLayout(ref, doc);
      if (!layout) continue;
      if (terms.slice(1).some((t) => findAll(layout.text, t, 1).length === 0)) continue;
      const lead = findAll(layout.text, terms[0], Math.min(HITS_PER_PAGE, limit - hits.length));
      lead.forEach(([s, e], ordinal) => {
        hits.push({ pageIndex: i, pageId: pages[i].id, ordinal, ...snippetAround(layout.text, s, e) });
      });
    }
  } finally {
    for (const o of opened.values()) o.close();
  }
  return hits;
}
