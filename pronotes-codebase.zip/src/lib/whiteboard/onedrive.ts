/**
 * OneDrive Sync (Microsoft account)
 * ==================================
 * Signs in with a Microsoft account and keeps ONE workspace file in the user's
 * own OneDrive, so the same email gives the same boards on every device.
 *
 * Why this shape:
 * - **App folder scope only** (`Files.ReadWrite.AppFolder`). We can read and
 *   write exactly one folder that belongs to this app — never the rest of the
 *   user's OneDrive. Least privilege, and the consent prompt says so.
 * - **No backend, no secret.** Browser apps cannot keep a client secret, so
 *   this uses the OAuth 2.0 authorization-code flow with PKCE, which is the
 *   only flow Microsoft still allows for SPAs. The implicit flow is deprecated.
 * - **No dependency.** MSAL would add ~100KB for what is three fetch calls.
 *
 * Storage cost is the user's own OneDrive quota, so syncing is free forever.
 */

import { parseWorkspace, serializeWorkspace, type WorkspaceSnapshot } from "./workspace";

const AUTH_HOST = "https://login.microsoftonline.com";
const GRAPH = "https://graph.microsoft.com/v1.0";
/** "common" = personal Microsoft accounts AND work/school accounts. */
const TENANT = "common";
const SCOPES = ["Files.ReadWrite.AppFolder", "User.Read", "offline_access"];
const FILE_NAME = "pronotes-workspace.json";

const LS_TOKENS = "pronotes.ms.tokens";
const LS_VERIFIER = "pronotes.ms.pkce";
const LS_RETURN = "pronotes.ms.return";

export interface StoredTokens {
  accessToken: string;
  refreshToken?: string;
  /** Epoch ms. */
  expiresAt: number;
  account?: { name?: string; email?: string };
}

export interface RemoteWorkspace {
  snapshot: WorkspaceSnapshot;
  /** Graph eTag — lets us detect that the remote changed under us. */
  eTag?: string;
  lastModified?: number;
}

export function getClientId(): string | null {
  const id = process.env.NEXT_PUBLIC_MS_CLIENT_ID;
  return id && id.trim() ? id.trim() : null;
}

export function isConfigured(): boolean {
  return !!getClientId();
}

function redirectUri(): string {
  return `${window.location.origin}${window.location.pathname}`;
}

// ---------------------------------------------------------------------------
// PKCE helpers
// ---------------------------------------------------------------------------

function base64Url(bytes: ArrayBuffer): string {
  return btoa(String.fromCharCode(...new Uint8Array(bytes)))
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/, "");
}

async function makeVerifierAndChallenge() {
  const random = new Uint8Array(64);
  crypto.getRandomValues(random);
  const verifier = base64Url(random.buffer);
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(verifier));
  return { verifier, challenge: base64Url(digest) };
}

// ---------------------------------------------------------------------------
// Token storage
// ---------------------------------------------------------------------------

/**
 * Web storage throws (Safari private mode, quota, storage disabled): a saved
 * credential is a convenience, never a requirement, so every access below is
 * guarded and a failure just means "not signed in" / "sign in again".
 */
function storageGet(store: Storage, key: string): string | null {
  try {
    return store.getItem(key);
  } catch {
    return null;
  }
}

function storageSet(store: Storage, key: string, value: string): void {
  try {
    store.setItem(key, value);
  } catch {
    // Swallowed deliberately — but note what it costs: there is NO in-memory
    // copy of the tokens (loadTokens re-reads storage on every call), so a
    // failed write means the user is simply not signed in, not "signed in
    // until reload". Callers that must not silently lose the session (like
    // beginSignIn's verifier write) verify with a read-back instead of
    // trusting this.
  }
}

function storageRemove(store: Storage, key: string): void {
  try {
    store.removeItem(key);
  } catch {
    /* the key is unreadable anyway, so there is nothing left to clear */
  }
}

export function loadTokens(): StoredTokens | null {
  try {
    const raw = storageGet(localStorage, LS_TOKENS);
    if (!raw) return null;
    const t = JSON.parse(raw) as StoredTokens;
    return typeof t?.accessToken === "string" ? t : null;
  } catch {
    return null;
  }
}

function storeTokens(t: StoredTokens): void {
  storageSet(localStorage, LS_TOKENS, JSON.stringify(t));
}

export function signOut(): void {
  storageRemove(localStorage, LS_TOKENS);
  // The verifier (and return URL) live in sessionStorage — that is the only
  // place they are ever written (beginSignIn) and read
  // (completeSignInIfRedirected). Clearing them from localStorage, as this
  // used to do, cleared nothing.
  storageRemove(sessionStorage, LS_VERIFIER);
  storageRemove(sessionStorage, LS_RETURN);
}

// ---------------------------------------------------------------------------
// Sign-in
// ---------------------------------------------------------------------------

export async function beginSignIn(): Promise<void> {
  const clientId = getClientId();
  if (!clientId) throw new Error("Microsoft sign-in is not configured.");

  const { verifier, challenge } = await makeVerifierAndChallenge();
  storageSet(sessionStorage, LS_VERIFIER, verifier);
  // The stored verifier is the ONLY copy — nothing keeps it in memory — so
  // prove it landed BEFORE leaving for Microsoft. Otherwise the user logs in,
  // comes back, and sign-in fails silently for lack of a verifier: a wasted
  // round trip with no explanation. SyncPanel's doSignIn shows this error.
  if (storageGet(sessionStorage, LS_VERIFIER) !== verifier) {
    throw new Error(
      "This browser is blocking storage, so Microsoft sign-in can't finish. " +
        "Allow site data (or leave private browsing) and try again."
    );
  }
  storageSet(sessionStorage, LS_RETURN, window.location.href);

  const params = new URLSearchParams({
    client_id: clientId,
    response_type: "code",
    redirect_uri: redirectUri(),
    response_mode: "query",
    scope: SCOPES.join(" "),
    code_challenge: challenge,
    code_challenge_method: "S256",
  });
  window.location.assign(`${AUTH_HOST}/${TENANT}/oauth2/v2.0/authorize?${params}`);
}

/**
 * Complete sign-in if we came back from Microsoft with `?code=`.
 * Returns true when a sign-in was completed on this page load.
 */
export async function completeSignInIfRedirected(): Promise<boolean> {
  const url = new URL(window.location.href);
  const code = url.searchParams.get("code");
  const error = url.searchParams.get("error");

  if (error) {
    // Clean the URL so a refresh does not replay the failure.
    cleanAuthParams();
    throw new Error(url.searchParams.get("error_description") || error);
  }
  if (!code) return false;

  const clientId = getClientId();
  const verifier = storageGet(sessionStorage, LS_VERIFIER);
  if (!clientId || !verifier) {
    cleanAuthParams();
    return false;
  }

  const body = new URLSearchParams({
    client_id: clientId,
    grant_type: "authorization_code",
    code,
    redirect_uri: redirectUri(),
    code_verifier: verifier,
    scope: SCOPES.join(" "),
  });

  const res = await fetch(`${AUTH_HOST}/${TENANT}/oauth2/v2.0/token`, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body,
  });
  storageRemove(sessionStorage, LS_VERIFIER);
  cleanAuthParams();

  if (!res.ok) {
    throw new Error(`Microsoft sign-in failed (${res.status}).`);
  }
  const json = (await res.json()) as {
    access_token: string;
    refresh_token?: string;
    expires_in: number;
  };
  const tokens: StoredTokens = {
    accessToken: json.access_token,
    refreshToken: json.refresh_token,
    expiresAt: Date.now() + json.expires_in * 1000,
  };
  storeTokens(tokens);
  tokens.account = await fetchAccount(tokens.accessToken);
  storeTokens(tokens);
  return true;
}

function cleanAuthParams(): void {
  const url = new URL(window.location.href);
  for (const k of ["code", "error", "error_description", "session_state", "state"]) {
    url.searchParams.delete(k);
  }
  window.history.replaceState({}, "", url.toString());
}

async function fetchAccount(accessToken: string) {
  try {
    const res = await fetch(`${GRAPH}/me`, {
      headers: { Authorization: `Bearer ${accessToken}` },
    });
    if (!res.ok) return undefined;
    const me = (await res.json()) as {
      displayName?: string;
      userPrincipalName?: string;
      mail?: string;
    };
    return { name: me.displayName, email: me.mail || me.userPrincipalName };
  } catch {
    return undefined;
  }
}

/** A valid access token, refreshing silently when it has expired. */
async function getAccessToken(): Promise<string | null> {
  const tokens = loadTokens();
  if (!tokens) return null;
  // Refresh a minute early — a token that expires mid-request would surface as
  // a spurious "sync failed".
  if (tokens.expiresAt - 60_000 > Date.now()) return tokens.accessToken;
  if (!tokens.refreshToken) return null;

  const clientId = getClientId();
  if (!clientId) return null;

  const res = await fetch(`${AUTH_HOST}/${TENANT}/oauth2/v2.0/token`, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      client_id: clientId,
      grant_type: "refresh_token",
      refresh_token: tokens.refreshToken,
      scope: SCOPES.join(" "),
    }),
  });
  if (!res.ok) {
    // The refresh token is dead (revoked / expired): force a fresh sign-in
    // rather than retrying forever.
    signOut();
    return null;
  }
  const json = (await res.json()) as {
    access_token: string;
    refresh_token?: string;
    expires_in: number;
  };
  const next: StoredTokens = {
    accessToken: json.access_token,
    refreshToken: json.refresh_token ?? tokens.refreshToken,
    expiresAt: Date.now() + json.expires_in * 1000,
    account: tokens.account,
  };
  storeTokens(next);
  return next.accessToken;
}

export function getSignedInAccount(): StoredTokens["account"] | null {
  return loadTokens()?.account ?? null;
}

export function isSignedIn(): boolean {
  return !!loadTokens();
}

// ---------------------------------------------------------------------------
// Graph file I/O — one JSON file in the app folder
// ---------------------------------------------------------------------------

const FILE_PATH = `${GRAPH}/me/drive/special/approot:/${FILE_NAME}`;

/** Pull the workspace, or null when nothing has been synced yet. */
export async function downloadWorkspace(): Promise<RemoteWorkspace | null> {
  const token = await getAccessToken();
  if (!token) throw new Error("Not signed in to Microsoft.");

  const res = await fetch(`${FILE_PATH}:/content`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  if (res.status === 404) return null; // first ever sync
  if (!res.ok) throw new Error(`OneDrive download failed (${res.status}).`);

  const text = await res.text();
  const snapshot = parseWorkspace(text);
  return {
    snapshot,
    eTag: res.headers.get("etag") ?? undefined,
    lastModified: Date.parse(res.headers.get("last-modified") ?? "") || undefined,
  };
}

export async function uploadWorkspace(
  snapshot: WorkspaceSnapshot,
  deviceLabel?: string
): Promise<void> {
  const token = await getAccessToken();
  if (!token) throw new Error("Not signed in to Microsoft.");

  const res = await fetch(`${FILE_PATH}:/content`, {
    method: "PUT",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
    },
    body: serializeWorkspace(snapshot, deviceLabel),
  });
  if (!res.ok) throw new Error(`OneDrive upload failed (${res.status}).`);
}
