/**
 * Split-view pointer hand-off
 * ===========================
 * When a press lands on the non-live pane, that pane becomes live and the
 * press is replayed on the canvas that replaces it a couple of frames later.
 * Moved here (out of SplitPane.tsx) unchanged so the press/release pairing
 * can be unit-tested: it is exactly the pairing that decides whether a stale
 * finger poisons later gestures.
 */

export interface PressInit extends PointerEventInit {
  pointerId: number;
}

/**
 * Hands a PRESS to the canvas that replaced this pane - and keeps the press
 * and its release paired.
 *
 * The canvas counts fingers: one goes into its map on pointerdown and comes
 * out on pointerup. The replayed pointerdown arrives a few frames late, so a
 * quick tap had usually lifted already - its real release reached the canvas
 * FIRST and removed nothing, then the late replay added a finger that was
 * never lifted. Every later one-finger touch then counted as the second finger
 * of a pinch: scrolling zoomed, drawing and typing did nothing, and closing the
 * split did not help. Measured: a one-finger drag after one quick tap changed
 * the zoom from 0.5 to 0.355; the same drag on a fresh page changed nothing.
 *
 * So: a pointer already released is not replayed at all, and if it lifts after
 * the replay but its release lands outside the canvas, the release is
 * delivered too. Every replayed press gets exactly one release.
 */
export function handOffPress(init: PressInit, clientX: number, clientY: number) {
  let released = false;
  let replayTarget: Element | null = null;
  const stop = () => {
    window.removeEventListener("pointerup", onEnd, true);
    window.removeEventListener("pointercancel", onEnd, true);
  };
  function onEnd(e: PointerEvent) {
    if (e.pointerId !== init.pointerId) return;
    stop();
    released = true;
    if (!replayTarget) return; // lifted before the canvas existed: nothing to pair
    const canvas = replayTarget.closest("[data-wb-canvas-area]") ?? replayTarget;
    if (e.target instanceof Node && canvas.contains(e.target)) return; // it got the real one
    replayTarget.dispatchEvent(
      new PointerEvent(e.type, {
        ...init,
        clientX: e.clientX,
        clientY: e.clientY,
        buttons: 0,
        pressure: 0,
        bubbles: true,
        cancelable: true,
        composed: true,
      })
    );
  }
  window.addEventListener("pointerup", onEnd, true);
  window.addEventListener("pointercancel", onEnd, true);
  // A pointer whose end is never reported must not leave listeners forever.
  setTimeout(stop, 30_000);

  handOff(() => {
    if (released) return null;
    replayTarget = document.elementFromPoint(clientX, clientY);
    return new PointerEvent("pointerdown", { ...init, bubbles: true, cancelable: true, composed: true });
  }, clientX, clientY);
}

/**
 * Replays an event on whatever is now under it, two frames after a focus
 * switch - by then React has swapped this pane for the real canvas, which
 * never saw the original event. `make` may return null to cancel.
 */
export function handOff(make: () => Event | null, clientX: number, clientY: number) {
  // Exactly once, whichever comes first: two frames (React has certainly
  // swapped the panes by then) or a short timer. requestAnimationFrame alone is
  // paused while the page is hidden, and a replay that never arrives means the
  // stroke you started simply does not happen.
  let done = false;
  const fire = () => {
    if (done) return;
    done = true;
    const ev = make();
    if (ev) document.elementFromPoint(clientX, clientY)?.dispatchEvent(ev);
  };
  requestAnimationFrame(() => requestAnimationFrame(fire));
  setTimeout(fire, 50);
}
