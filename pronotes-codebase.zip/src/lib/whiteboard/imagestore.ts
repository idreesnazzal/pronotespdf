/**
 * Image storage (IndexedDB)
 * =========================
 * Image pixels live here, NOT in the workspace that goes to localStorage.
 *
 * The measured problem: a single pasted image on the demo board was **908 KB
 * of a 918 KB workspace** — 99% of it. localStorage allows roughly 5 MB, so a
 * handful of photos fills it, and the failure lands on SAVE: you would work
 * for an hour and then discover nothing had been written.
 *
 * When that happened the fallback dropped every image's `src` to `""` to get
 * under the limit. The pixels were gone for good, because the data URL in the
 * workspace was the only copy anyone had.
 *
 * So images follow the same rule as imported PDFs: the bytes go to IndexedDB
 * once, and the element keeps only `asset:<id>`. That keeps the workspace
 * small, and the pixels survive a quota event because they were never in the
 * thing that overflowed.
 */

const DB_NAME = "pronotes-assets";
const DB_VERSION = 1;
const STORE = "images";

/** Marks a src as a reference into this store rather than inline pixels. */
export const ASSET_PREFIX = "asset:";

export interface StoredImage {
  id: string;
  /** The original data URL, kept verbatim so re-encoding never degrades it. */
  dataUrl: string;
  addedAt: number;
}

export function isAssetRef(src: string | undefined | null): boolean {
  return typeof src === "string" && src.startsWith(ASSET_PREFIX);
}

export function assetIdOf(src: string): string {
  return src.slice(ASSET_PREFIX.length);
}

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === "undefined") {
      reject(new Error("This browser has no IndexedDB, so images cannot be stored."));
      return;
    }
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE, { keyPath: "id" });
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error ?? new Error("Could not open the image store"));
  });
}

function tx<T>(mode: IDBTransactionMode, run: (s: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  return openDb().then(
    (db) =>
      new Promise<T>((resolve, reject) => {
        const t = db.transaction(STORE, mode);
        const req = run(t.objectStore(STORE));
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error ?? new Error("Image store request failed"));
        t.oncomplete = () => db.close();
      })
  );
}

/**
 * Stores a data URL and returns the `asset:<id>` src to put on the element.
 *
 * If IndexedDB is unavailable the ORIGINAL data URL is returned instead. That
 * keeps the picture — an inline image that risks the quota is still far better
 * than losing it outright — and the degraded-save path remains as the backstop.
 */
export async function storeImage(dataUrl: string): Promise<string> {
  if (!dataUrl.startsWith("data:")) return dataUrl;
  const id = `img_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 9)}`;
  try {
    await tx("readwrite", (s) =>
      s.put({ id, dataUrl, addedAt: Date.now() } as StoredImage) as unknown as IDBRequest<void>
    );
    return `${ASSET_PREFIX}${id}`;
  } catch (err) {
    // Keeping the picture inline is still the right call - it beats losing it
    // - but it puts the image back into the ~5 MB workspace, which is the exact
    // quota problem this store exists to avoid. A few of these and saving
    // starts failing, so the user is told NOW rather than at the failed save.
    console.warn("[imagestore] Could not store an image in IndexedDB; keeping it inline.", err);
    if (typeof window !== "undefined") {
      window.dispatchEvent(new CustomEvent("wb:image-inline", { detail: { bytes: dataUrl.length } }));
    }
    return dataUrl;
  }
}

export async function loadImage(id: string): Promise<string | null> {
  try {
    const rec = await tx<StoredImage | undefined>("readonly", (s) => s.get(id));
    return rec?.dataUrl ?? null;
  } catch {
    return null;
  }
}

/**
 * The newest stored pictures, for "use again" in the image sheet. Only ids
 * still referenced by some note are worth offering; the caller filters.
 */
export async function listRecentImages(limit = 12): Promise<StoredImage[]> {
  try {
    // Keys only: getAll() would pull every photo's pixels into memory. Ids
    // start with their creation time (see storeImage), so they sort by age.
    const keys = await tx<IDBValidKey[]>("readonly", (s) => s.getAllKeys());
    const born = (k: string) => parseInt(k.split("_")[1] ?? "0", 36) || 0;
    const newest = (keys as string[]).sort((a, b) => born(b) - born(a)).slice(0, limit);
    const out: StoredImage[] = [];
    for (const id of newest) {
      const rec = await tx<StoredImage | undefined>("readonly", (s) => s.get(id));
      if (rec) out.push(rec);
    }
    return out;
  } catch {
    return [];
  }
}

/** Removes images nothing references any more. */
export async function pruneUnusedImages(referenced: Set<string>): Promise<number> {
  try {
    const all = await tx<StoredImage[]>("readonly", (s) => s.getAll() as IDBRequest<StoredImage[]>);
    const orphans = all.filter((r) => !referenced.has(r.id));
    for (const o of orphans) {
      await tx("readwrite", (s) => s.delete(o.id) as unknown as IDBRequest<void>);
    }
    return orphans.length;
  } catch (err) {
    // Pruning is housekeeping and must never break the delete that triggered
    // it - but a prune that always fails means storage only ever grows, so
    // it is logged rather than swallowed.
    console.warn("[imagestore] Pruning unused images failed; storage was not reclaimed.", err);
    return 0;
  }
}
