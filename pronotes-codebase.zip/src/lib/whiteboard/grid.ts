/**
 * Grid and Snapping Math (v3 — Obsidian Canvas & Vector Grade)
 * =============================================================
 * Standard grid size and point snapping utilities.
 */

export const GRID_SIZE = 24;

/**
 * Snap a single scalar value to the nearest multiple of `gridSize`.
 * Normalizes -0 to 0 for clean numerical precision.
 */
export function snapToGrid(val: number, gridSize: number = GRID_SIZE): number {
  if (!gridSize || gridSize <= 0) return val;
  const res = Math.round(val / gridSize) * gridSize;
  return res === 0 ? 0 : res;
}

/**
 * Snap 2D coordinate point (x, y) to the nearest grid intersection.
 */
export function snapPointToGrid(
  x: number,
  y: number,
  gridSize: number = GRID_SIZE
): { x: number; y: number } {
  return {
    x: snapToGrid(x, gridSize),
    y: snapToGrid(y, gridSize),
  };
}
