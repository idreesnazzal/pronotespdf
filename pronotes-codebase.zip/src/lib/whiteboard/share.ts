/**
 * Delivering an exported file
 * ===========================
 * One question, asked three ways depending on where ProNotes is running:
 * "you have a PDF in memory - how does it reach WhatsApp, Drive, Gmail, or
 * the user's Downloads folder?"
 *
 *   Android APK  -> write to the app cache, hand the URI to the OS share
 *                   sheet (@capacitor/share). This is the ONLY route that
 *                   works: the WebView has no download manager behind it, so
 *                   an `<a download>` click is swallowed with no file and no
 *                   error at all.
 *   Chrome/Edge  -> navigator.share({ files }) opens the Windows share flyout,
 *   on Windows      which is the same "choose an app" experience. Guarded by
 *                   navigator.canShare, because Firefox exposes share() but
 *                   refuses files, and the API needs HTTPS.
 *   Everywhere   -> an ordinary browser download.
 *   else
 *
 * Two things make this harder than it looks, and both are handled below:
 *
 * 1. TRANSIENT USER ACTIVATION. navigator.share may only be called shortly
 *    after a click. Rasterising a 30-page notebook takes longer than that
 *    window, so share() rejects with NotAllowedError on a file the user very
 *    much wanted. That is not an error to show - it is a fallback to download.
 * 2. CANCELLING IS NOT FAILING. Dismissing either share sheet rejects the
 *    promise. Reporting "export failed" for "I changed my mind" trains people
 *    to distrust the message that matters.
 */

import { Capacitor } from "@capacitor/core";

/** How a file left the app, so the UI can say something true afterwards. */
export type ShareOutcome = "shared" | "downloaded" | "cancelled";

export type ShareRoute = "native" | "webshare" | "download";

/**
 * True when running inside the Capacitor APK. Capacitor's own runtime flag is
 * used rather than a user-agent test, because Chrome on the same Android
 * tablet is a real browser and must keep the normal download path.
 */
export function isNativeApp(): boolean {
  return Capacitor.isNativePlatform();
}

/**
 * Whether this build can show an OS app chooser at all.
 *
 * `canShare` is probed with a real File: Chrome on Windows returns true for
 * `{ files }` while some builds return true for text and then throw on files.
 * A one-byte probe file costs nothing and answers the question honestly.
 */
export function canChooseApp(): boolean {
  if (isNativeApp()) return true;
  if (typeof navigator === "undefined" || typeof navigator.share !== "function") return false;
  if (typeof navigator.canShare !== "function" || typeof File === "undefined") return false;
  try {
    return navigator.canShare({ files: [new File([new Uint8Array(1)], "probe.png", { type: "image/png" })] });
  } catch {
    return false;
  }
}

/** Which route `shareBlob` would take right now. */
export function shareRoute(): ShareRoute {
  if (isNativeApp()) return "native";
  return canChooseApp() ? "webshare" : "download";
}

/**
 * Dismissing a share sheet rejects the call. That is the user changing their
 * mind, not a failure, so it must not surface as an error.
 *
 * AbortError is the Web Share API's own name for it; the Android plugin sends
 * a plain message instead, hence the text test as well.
 */
export function isShareCancellation(err: unknown): boolean {
  const e = err as { name?: string; message?: string } | null;
  if (e?.name === "AbortError") return true;
  return /cancel|abort|dismiss/i.test(e?.message ?? "");
}

/** The browser refused because the click that started this has expired. */
function isActivationExpiry(err: unknown): boolean {
  const e = err as { name?: string; message?: string } | null;
  if (e?.name === "NotAllowedError") return true;
  return /user activation|user gesture|transient/i.test(e?.message ?? "");
}

/**
 * Reads a Blob as a data URL. Capacitor's Filesystem bridge only carries
 * JSON, so binary has to round-trip through one to cross it.
 */
export function blobToDataUrl(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error("Could not read the exported file data"));
    reader.readAsDataURL(blob);
  });
}

async function blobToBase64(blob: Blob): Promise<string> {
  const result = await blobToDataUrl(blob);
  const comma = result.indexOf(",");
  return comma >= 0 ? result.slice(comma + 1) : result;
}

/**
 * Hands a file to the Android share sheet.
 *
 * Cache, not Documents: the file only has to outlive the share sheet, and the
 * cache directory needs no storage permission on any Android version. The
 * plugins are imported lazily so the web and Electron bundles never load
 * native code they cannot use.
 */
async function shareNative(blob: Blob, filename: string, title: string): Promise<ShareOutcome> {
  const [{ Filesystem, Directory }, { Share }] = await Promise.all([
    import("@capacitor/filesystem"),
    import("@capacitor/share"),
  ]);

  const data = await blobToBase64(blob);
  const written = await Filesystem.writeFile({
    path: filename,
    data,
    directory: Directory.Cache,
    recursive: true,
  });

  try {
    await Share.share({ title, files: [written.uri] });
    return "shared";
  } catch (err) {
    if (isShareCancellation(err)) return "cancelled";
    throw err;
  }
}

/** Triggers an ordinary browser download for any Blob. */
export function downloadBlob(blob: Blob, filename: string): void {
  if (typeof window === "undefined") return;
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

/**
 * Opens the OS app chooser for this file, falling back to a download whenever
 * the chooser is unavailable or the click that started the export has aged
 * out. Returns how it actually left, never guessing.
 */
export async function shareBlob(blob: Blob, filename: string, title = filename): Promise<ShareOutcome> {
  if (isNativeApp()) return shareNative(blob, filename, title);

  if (canChooseApp()) {
    try {
      const file = new File([blob], filename, { type: blob.type || "application/octet-stream" });
      if (navigator.canShare({ files: [file] })) {
        await navigator.share({ files: [file], title });
        return "shared";
      }
    } catch (err) {
      if (isShareCancellation(err)) return "cancelled";
      // Anything else - an expired click, a share target that blew up - still
      // leaves the user wanting their file. Falling through to the download is
      // always better than an error dialog and no file.
      if (!isActivationExpiry(err)) {
        console.warn("[share] The system share sheet failed; downloading instead.", err);
      }
    }
  }

  downloadBlob(blob, filename);
  return "downloaded";
}

/**
 * Saves a file without offering an app chooser: a plain download on the web
 * and desktop. On Android there is no such thing - the share sheet IS how a
 * file is saved, and it offers "Save to Files" among the apps.
 */
export async function saveBlob(blob: Blob, filename: string): Promise<ShareOutcome> {
  if (isNativeApp()) return shareNative(blob, filename, filename);
  downloadBlob(blob, filename);
  return "downloaded";
}
