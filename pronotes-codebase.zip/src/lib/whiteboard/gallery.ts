/**
 * "Save to Gallery"
 * =================
 * A screenshot is a photo-shaped thing, and on the tablet people look for it
 * in the Gallery app - not in a Files folder, and not behind a share sheet.
 *
 *   Android APK  -> the app's own GallerySaver plugin (GallerySaverPlugin.java)
 *                   inserts it into MediaStore under Pictures/ProNotes, which
 *                   is exactly what Gallery / Google Photos list. The export
 *                   path cannot do this: it writes to the app cache for the
 *                   share sheet, and nothing there is ever indexed.
 *   Web/desktop  -> an ordinary download.
 *
 * An APK built before the plugin existed has no GallerySaver; the call then
 * falls back to the share sheet (which offers "Save to device"), and says so.
 */

import { registerPlugin } from "@capacitor/core";
import { blobToDataUrl, downloadBlob, isNativeApp, saveBlob } from "./share";

interface GallerySaverPlugin {
  saveImage(options: { data: string; filename: string; album?: string }): Promise<{ uri: string }>;
}

const GallerySaver = registerPlugin<GallerySaverPlugin>("GallerySaver");

/** The album (Pictures/<album>) screenshots land in. */
export const GALLERY_ALBUM = "ProNotes";

/** Where the picture really went, so the UI can say something true. */
export type GalleryOutcome = "gallery" | "downloaded" | "shared" | "cancelled";

export async function saveImageToGallery(blob: Blob, filename: string): Promise<GalleryOutcome> {
  if (!isNativeApp()) {
    downloadBlob(blob, filename);
    return "downloaded";
  }
  const dataUrl = await blobToDataUrl(blob);
  const data = dataUrl.slice(dataUrl.indexOf(",") + 1);
  try {
    await GallerySaver.saveImage({ data, filename, album: GALLERY_ALBUM });
    return "gallery";
  } catch (err) {
    const e = err as { code?: string; message?: string };
    // Only a MISSING plugin (an older APK) falls back; a real failure, such as
    // a refused permission, is reported rather than papered over.
    if (e?.code === "UNIMPLEMENTED" || /not implemented/i.test(e?.message ?? "")) {
      const outcome = await saveBlob(blob, filename);
      return outcome === "cancelled" ? "cancelled" : "shared";
    }
    throw err;
  }
}
