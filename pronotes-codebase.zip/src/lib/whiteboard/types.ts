/**
 * Whiteboard Type System (v3 — Professional Obsidian Canvas Grade)
 * ================================================================
 * Core type definitions for whiteboard elements, connections, styling, and boards.
 */

// ============================================================================
// Element Types
// ============================================================================

export interface BaseElement {
  id: string;
  type: ElementType;
  x: number;
  y: number;
  rotation: number;
  opacity: number;
  locked?: boolean;
  zIndex?: number;
  createdAt: number;
  updatedAt: number;
}

export type ElementType =
  | "stroke"       // freehand pen, pencil, marker, highlighter, brush, calligraphy
  | "rectangle"
  | "ellipse"
  | "diamond"
  | "triangle"
  | "star"
  | "cloud"
  | "line"
  | "arrow"
  | "text"
  | "sticky"
  | "image"
  | "connection";  // Obsidian Canvas-grade semantic directed link between nodes

// ============================================================================
// Stroke Styles & Pen Types
// ============================================================================

/**
 * Pen families. These are modelled on what note apps actually ship (GoodNotes:
 * fountain / ball / brush; Samsung Notes: standard / fountain / slanted / ink
 * brush) plus the universal marker, highlighter and pencil.
 *
 * Each one must differ in HOW IT RENDERS, not just in its label. The previous
 * set did not: pen, marker, highlighter and pencil all had simulatePressure
 * off, thinning ~0 and no taper, so they produced the same geometry and
 * differed only in opacity, and brush vs calligraphy differed by 0.05 thinning.
 */
export type StrokeStyle =
  | "ballpoint"
  | "gel"
  | "fineliner"
  | "fountain"
  | "brush"
  | "marker"
  | "highlighter"
  | "pencil"
  // Legacy ids kept so strokes drawn before the pen rework still render.
  | "pen"
  | "calligraphy";

export interface PenPreset {
  thinning: number;
  smoothing: number;
  streamline: number;
  simulatePressure: boolean;
  startTaper: number;
  endTaper: number;
  opacity: number;
  mixBlendMode: "normal" | "multiply";
  label: string;
  /** Short description shown in the pen picker. */
  hint: string;
  /**
   * Round nib or flat chisel. A marker and a highlighter have a squared-off
   * tip; a pen does not. This is `cap` in perfect-freehand and is a visible
   * difference at both ends of every stroke.
   */
  cap: "round" | "flat";
  /**
   * How strongly speed changes the width, 0 = never. Real ballpoints and
   * fountain pens thin out when moved fast; a fineliner does not. Applies even
   * with a mouse, which is why the old presets all looked alike on desktop.
   */
  speedResponse: number;
  /**
   * Chisel-nib angle in degrees. When set, width depends on the DIRECTION of
   * travel — thick across the nib, thin along it. This is what makes a fountain
   * pen look calligraphic rather than just thin.
   */
  nibAngle?: number;
  /** Pencil tooth. Rendered as a grain filter over the stroke. */
  grain?: boolean;
  /**
   * Nominal line weight relative to the chosen size. Real pens differ mostly by
   * WEIGHT — a 0.3mm fineliner against a 0.7mm ballpoint — and without this the
   * everyday writing pens were within 8% of each other's ink area, i.e.
   * indistinguishable at handwriting size.
   */
  sizeScale: number;
}

export const PEN_TYPE_PRESETS: Record<StrokeStyle, PenPreset> = {
  ballpoint: {
    thinning: 0.28, smoothing: 0.45, streamline: 0.42, simulatePressure: false,
    startTaper: 0, endTaper: 0, opacity: 1, mixBlendMode: "normal",
    cap: "round", speedResponse: 0.55, sizeScale: 0.7,
    label: "Ballpoint", hint: "Thin, crisp, thins slightly when you write fast",
  },
  gel: {
    thinning: 0.08, smoothing: 0.62, streamline: 0.52, simulatePressure: false,
    startTaper: 0, endTaper: 0, opacity: 1, mixBlendMode: "normal",
    cap: "round", speedResponse: 0.15, sizeScale: 1,
    label: "Pen", hint: "Smooth, even line — everyday writing",
  },
  fineliner: {
    thinning: 0, smoothing: 0.75, streamline: 0.62, simulatePressure: false,
    startTaper: 0, endTaper: 0, opacity: 1, mixBlendMode: "normal",
    cap: "round", speedResponse: 0, sizeScale: 0.5,
    label: "Fineliner", hint: "Perfectly even line — technical drawing",
  },
  fountain: {
    thinning: 0.5, smoothing: 0.6, streamline: 0.5, simulatePressure: false,
    startTaper: 0, endTaper: 6, opacity: 1, mixBlendMode: "normal",
    cap: "round", speedResponse: 0.35, nibAngle: 40, sizeScale: 1.05,
    label: "Fountain", hint: "Thick across the nib, thin along it — calligraphic",
  },
  brush: {
    thinning: 0.62, smoothing: 0.5, streamline: 0.4, simulatePressure: true,
    startTaper: 6, endTaper: 14, opacity: 0.95, mixBlendMode: "normal",
    cap: "round", speedResponse: 0.7, sizeScale: 1.25,
    label: "Brush", hint: "Pressure and speed sensitive, tapers to a point",
  },
  marker: {
    thinning: 0, smoothing: 0.5, streamline: 0.4, simulatePressure: false,
    startTaper: 0, endTaper: 0, opacity: 0.92, mixBlendMode: "normal",
    cap: "flat", speedResponse: 0, sizeScale: 1.6,
    label: "Marker", hint: "Thick, opaque, squared-off chisel tip",
  },
  highlighter: {
    thinning: 0, smoothing: 0.4, streamline: 0.3, simulatePressure: false,
    startTaper: 0, endTaper: 0, opacity: 0.35, mixBlendMode: "multiply",
    cap: "flat", speedResponse: 0, sizeScale: 3,
    label: "Highlighter", hint: "Wide, translucent, multiplies over text",
  },
  pencil: {
    thinning: 0.22, smoothing: 0.32, streamline: 0.22, simulatePressure: false,
    startTaper: 0, endTaper: 0, opacity: 0.85, mixBlendMode: "multiply",
    cap: "round", speedResponse: 0.4, grain: true, sizeScale: 0.85,
    label: "Pencil", hint: "Grainy graphite tooth, slightly translucent",
  },

  // ---- legacy ids -> nearest new pen, so old strokes keep rendering --------
  pen: {
    thinning: 0.08, smoothing: 0.62, streamline: 0.52, simulatePressure: false,
    startTaper: 0, endTaper: 0, opacity: 1, mixBlendMode: "normal",
    cap: "round", speedResponse: 0.15, sizeScale: 1,
    label: "Gel pen", hint: "Smooth, near-constant width",
  },
  calligraphy: {
    thinning: 0.5, smoothing: 0.6, streamline: 0.5, simulatePressure: false,
    startTaper: 0, endTaper: 6, opacity: 1, mixBlendMode: "normal",
    cap: "round", speedResponse: 0.35, nibAngle: 40, sizeScale: 1.05,
    label: "Fountain", hint: "Thick across the nib, thin along it",
  },
};

/** Every id that draws a freehand stroke, including legacy ones. */
export const STROKE_TOOL_IDS: string[] = [
  "ballpoint",
  "gel",
  "fineliner",
  "fountain",
  "brush",
  "marker",
  "highlighter",
  "pencil",
  "pen",
  "calligraphy",
];

export function isStrokeTool(tool: string): boolean {
  return STROKE_TOOL_IDS.includes(tool);
}

/**
 * Default ink per pen. Sizes differ because the pens differ: a fineliner is a
 * 0.3mm line and a highlighter is a broad chisel, and starting them both at the
 * same width makes half the picker feel identical.
 */
export const DEFAULT_TOOL_INK: Record<string, { color: string; size: number }> = {
  ballpoint: { color: "#1e293b", size: 3 },
  gel: { color: "#1e293b", size: 4 },
  fineliner: { color: "#1e293b", size: 2 },
  fountain: { color: "#1e293b", size: 5 },
  brush: { color: "#1e293b", size: 12 },
  marker: { color: "#3b82f6", size: 10 },
  highlighter: { color: "#fde047", size: 22 },
  pencil: { color: "#64748b", size: 4 },
  // legacy ids
  pen: { color: "#1e293b", size: 4 },
  calligraphy: { color: "#1e293b", size: 5 },
};

/** Legacy per-pen fields, for migrating a save written before `toolInk`. */
const LEGACY_INK_FIELDS: Record<string, { color: keyof StyleState; size: keyof StyleState }> = {
  pen: { color: "penColor", size: "penSize" },
  highlighter: { color: "highlighterColor", size: "highlighterSize" },
  marker: { color: "markerColor", size: "markerSize" },
  brush: { color: "brushColor", size: "brushSize" },
  calligraphy: { color: "calligraphyColor", size: "calligraphySize" },
  pencil: { color: "pencilColor", size: "pencilSize" },
};

/** Build a complete ink map, filling gaps from legacy fields then defaults. */
export function buildToolInk(
  partial?: Record<string, { color: string; size: number }>,
  legacy?: Partial<StyleState>
): Record<string, { color: string; size: number }> {
  const out: Record<string, { color: string; size: number }> = {};
  for (const id of STROKE_TOOL_IDS) {
    const saved = partial?.[id];
    if (saved && typeof saved.color === "string" && Number.isFinite(saved.size)) {
      out[id] = { color: saved.color, size: saved.size };
      continue;
    }
    const legacyField = LEGACY_INK_FIELDS[id];
    const fallback = DEFAULT_TOOL_INK[id] ?? { color: "#1e293b", size: 4 };
    out[id] = {
      color:
        (legacyField && (legacy?.[legacyField.color] as string | undefined)) || fallback.color,
      size:
        (legacyField && (legacy?.[legacyField.size] as number | undefined)) || fallback.size,
    };
  }
  return out;
}


/**
 * The pens offered in the picker: only pens that LOOK different. Ballpoint
 * and fineliner were near-duplicates of the gel pen (they differ mainly in
 * width, which the thickness setting already covers), so the picker offers
 * one "Pen". Their presets stay, so strokes written with them keep their look.
 */
export const PEN_TYPES: StrokeStyle[] = [
  "gel",
  "fountain",
  "brush",
  "pencil",
  "marker",
  "highlighter",
];

/** Whether pressing harder changes this pen's line at all. */
export function penUsesPressure(style: StrokeStyle): boolean {
  const p = PEN_TYPE_PRESETS[style];
  // simulatePressure: the width comes from writing SPEED, and real pressure
  // is ignored; thinning 0: the width never changes.
  return !!p && !p.simulatePressure && p.thinning > 0;
}

export interface StrokeElement extends BaseElement {
  type: "stroke";
  points: [number, number, number][]; // [x, y, pressure]
  color: string;
  strokeWidth: number;
  strokeStyle: StrokeStyle;
  path?: string;
  smoothing?: number;
  /**
   * `points` ARE the drawn line: already smoothed and hook-trimmed, so they
   * are drawn as they are. Set when the eraser first cuts a stroke - its
   * pieces must keep the exact shape you saw, and re-smoothing each piece
   * from its new start bent the writing beside every cut.
   */
  settled?: boolean;
  /** Ends made by the eraser: drawn blunt, never with the pen's taper. */
  cutStart?: boolean;
  cutEnd?: boolean;
}

// ============================================================================
// Shape Fill & Border Styles
// ============================================================================

export type EraserMode = "pixel" | "object";

export type FillStyle = "transparent" | "solid" | "semi" | "hatch";
export type DashStyle = "solid" | "dashed" | "dotted";

export interface RectangleElement extends BaseElement {
  type: "rectangle";
  width: number;
  height: number;
  cornerRadius?: number;
  strokeColor: string;
  fillColor: string;
  fillStyle: FillStyle;
  dashStyle: DashStyle;
  strokeWidth: number;
}

export interface EllipseElement extends BaseElement {
  type: "ellipse";
  width: number;
  height: number;
  strokeColor: string;
  fillColor: string;
  fillStyle: FillStyle;
  dashStyle: DashStyle;
  strokeWidth: number;
}

export interface DiamondElement extends BaseElement {
  type: "diamond";
  width: number;
  height: number;
  strokeColor: string;
  fillColor: string;
  fillStyle: FillStyle;
  dashStyle: DashStyle;
  strokeWidth: number;
}

export interface TriangleElement extends BaseElement {
  type: "triangle";
  width: number;
  height: number;
  strokeColor: string;
  fillColor: string;
  fillStyle: FillStyle;
  dashStyle: DashStyle;
  strokeWidth: number;
}

export interface StarElement extends BaseElement {
  type: "star";
  width: number;
  height: number;
  strokeColor: string;
  fillColor: string;
  fillStyle: FillStyle;
  dashStyle: DashStyle;
  strokeWidth: number;
}

export interface CloudElement extends BaseElement {
  type: "cloud";
  width: number;
  height: number;
  strokeColor: string;
  fillColor: string;
  fillStyle: FillStyle;
  dashStyle: DashStyle;
  strokeWidth: number;
}

// ============================================================================
// Lines & Arrows
// ============================================================================

export type ArrowheadType = "none" | "arrow" | "triangle" | "stealth" | "diamond" | "circle";

export interface LineElement extends BaseElement {
  type: "line";
  x2: number;
  y2: number;
  strokeColor: string;
  strokeWidth: number;
  dashStyle: DashStyle;
}

export interface ArrowElement extends BaseElement {
  type: "arrow";
  x2: number;
  y2: number;
  strokeColor: string;
  strokeWidth: number;
  dashStyle: DashStyle;
  startArrowhead: ArrowheadType;
  endArrowhead: ArrowheadType;
  arrowheadSize: number;
}

// ============================================================================
// Text & Sticky Notes & Typography
// ============================================================================

export type TextAlign = "left" | "center" | "right";

/**
 * Per-line writing direction. Missing entries (and "auto") mean auto-detect
 * from the line's first strong character, so one box holds RTL Hebrew and
 * LTR English lines with no setup. Old saves have no array at all and read
 * as all-auto.
 */
export type LineDir = "ltr" | "rtl" | "auto";

export const FONT_FAMILIES = [
  { id: "inter", label: "Clean (Inter)", value: "var(--font-inter), Inter, system-ui, sans-serif" },
  { id: "hand", label: "Handwritten (Caveat)", value: "var(--font-caveat), 'Caveat', cursive, sans-serif" },
  { id: "mono", label: "Code (JetBrains)", value: "var(--font-mono), 'JetBrains Mono', monospace" },
  { id: "serif", label: "Editorial (Playfair)", value: "var(--font-serif), 'Playfair Display', Georgia, serif" },
  { id: "display", label: "Display (Plus Jakarta)", value: "var(--font-display), 'Plus Jakarta Sans', sans-serif" },
];

export interface TextElement extends BaseElement {
  type: "text";
  width: number;
  height: number;
  text: string;
  color: string;
  fontSize: number;
  fontFamily: string;
  fontWeight: number;
  align: TextAlign;
  /** Per-line direction overrides, parallel to text lines (see LineDir). */
  lineDirs?: LineDir[];
  lineHeight?: number;
  backgroundColor?: string;
  borderColor?: string;
  cardMode?: boolean;
  borderRadius?: number;
  padding?: number;
  highlightColor?: string;
}

export const CARD_BACKGROUNDS = [
  { id: "transparent", label: "Transparent", bg: "transparent", border: "transparent" },
  { id: "white", label: "Paper White", bg: "#ffffff", border: "#e2e8f0" },
  { id: "yellow", label: "Soft Yellow", bg: "#fef9c3", border: "#fde047" },
  { id: "blue", label: "Soft Blue", bg: "#eff6ff", border: "#bfdbfe" },
  { id: "green", label: "Soft Green", bg: "#f0fdf4", border: "#bbf7d0" },
  { id: "purple", label: "Soft Purple", bg: "#faf5ff", border: "#e9d5ff" },
  { id: "rose", label: "Soft Rose", bg: "#fff1f2", border: "#fecdd3" },
  { id: "dark", label: "Card Dark", bg: "#18181b", border: "#3f3f46" },
] as const;

export const TEXT_HIGHLIGHT_COLORS = [
  "transparent",
  "#fef08a",
  "#bae6fd",
  "#bbf7d0",
  "#fbcfe8",
  "#fed7aa",
  "#e9d5ff",
] as const;

export type StickyColor = "yellow" | "pink" | "blue" | "green" | "purple" | "orange" | "zinc";

export const STICKY_COLORS: Record<StickyColor, { bg: string; border: string; text: string; label: string }> = {
  yellow: { bg: "#fef9c3", border: "#fde047", text: "#713f12", label: "Yellow" },
  pink: { bg: "#fce7f3", border: "#f472b6", text: "#831843", label: "Pink" },
  blue: { bg: "#e0f2fe", border: "#38bdf8", text: "#0c4a6e", label: "Blue" },
  green: { bg: "#dcfce7", border: "#4ade80", text: "#14532d", label: "Green" },
  purple: { bg: "#f3e8ff", border: "#c084fc", text: "#581c87", label: "Purple" },
  orange: { bg: "#ffedd5", border: "#fb923c", text: "#7c2d12", label: "Orange" },
  zinc: { bg: "#f4f4f5", border: "#d4d4d8", text: "#18181b", label: "Zinc" },
};

export interface StickyElement extends BaseElement {
  type: "sticky";
  width: number;
  height: number;
  text: string;
  color: StickyColor;
  fontSize: number;
  align: TextAlign;
  /** Per-line direction overrides, parallel to text lines (see LineDir). */
  lineDirs?: LineDir[];
}

export interface ImageElement extends BaseElement {
  type: "image";
  width: number;
  height: number;
  src: string;
  borderColor?: string;
  borderWidth?: number;
  naturalWidth: number;
  naturalHeight: number;
  /**
   * Non-destructive edits (see lib/whiteboard/imageEdit.ts). The stored
   * pixels never change, so every edit can be undone or reset later.
   */
  crop?: ImageCrop;
  flipX?: boolean;
  flipY?: boolean;
  filter?: ImageFilter;
  frame?: ImageFrame;
}

/** The kept part of the picture, as fractions (0..1) of the flipped picture. */
export interface ImageCrop {
  x: number;
  y: number;
  w: number;
  h: number;
}

/** Split view layout: side by side (left | right) or stacked (top / bottom). */
export type SplitOrientation = "side" | "stacked";

export type ImageFilter = "none" | "document" | "mono" | "vivid" | "faded";
export type ImageFrame = "square" | "rounded" | "circle";

// ============================================================================
// Obsidian Canvas-Grade Semantic Directed Connections
// ============================================================================

export type NodeAnchor = "top" | "right" | "bottom" | "left" | "center" | "auto";
export type ConnectionRouting = "curved" | "orthogonal" | "straight";

export interface ConnectionEndpoint {
  boardId: string;
  elementId: string;
  anchor: NodeAnchor;
}

export type BuiltinLinkType =
  | "relates"
  | "depends"
  | "causes"
  | "contradicts"
  | "leads_to"
  | "supports"
  | "flow";

export const BUILTIN_LINK_TYPES: BuiltinLinkType[] = [
  "relates",
  "depends",
  "causes",
  "contradicts",
  "leads_to",
  "supports",
  "flow",
];

export const LINK_TYPE_COLORS: Record<BuiltinLinkType, string> = {
  relates: "#3b82f6",     // Blue
  depends: "#ef4444",     // Red
  causes: "#f97316",      // Orange
  contradicts: "#dc2626", // Crimson
  leads_to: "#8b5cf6",    // Purple
  supports: "#10b981",    // Green
  flow: "#06b6d4",        // Cyan
};

export const LINK_TYPE_LABELS: Record<BuiltinLinkType, string> = {
  relates: "Relates to",
  depends: "Depends on",
  causes: "Causes",
  contradicts: "Contradicts",
  leads_to: "Leads to",
  supports: "Supports",
  flow: "Flows into",
};

export function getLinkTypeColor(
  linkType: string,
  customLinkTypes: Array<{ id: string; name: string; color: string }> = []
): string {
  if (linkType in LINK_TYPE_COLORS) {
    return LINK_TYPE_COLORS[linkType as BuiltinLinkType];
  }
  const custom = customLinkTypes.find((t) => t.id === linkType);
  return custom?.color || "#6b7280";
}

export function getLinkTypeLabel(
  linkType: string,
  customLinkTypes: Array<{ id: string; name: string; color: string }> = []
): string {
  if (linkType in LINK_TYPE_LABELS) {
    return LINK_TYPE_LABELS[linkType as BuiltinLinkType];
  }
  const custom = customLinkTypes.find((t) => t.id === linkType);
  return custom?.name || linkType || "Link";
}

export interface ConnectionElement extends BaseElement {
  type: "connection";
  source: ConnectionEndpoint;
  target: ConnectionEndpoint;
  linkType: string;
  label?: string;
  routing: ConnectionRouting;
  dashStyle: DashStyle;
  startArrowhead: ArrowheadType;
  endArrowhead: ArrowheadType;
  strokeWidth: number;
}

// Union of all whiteboard elements
export type WhiteboardElement =
  | StrokeElement
  | RectangleElement
  | EllipseElement
  | DiamondElement
  | TriangleElement
  | StarElement
  | CloudElement
  | LineElement
  | ArrowElement
  | TextElement
  | StickyElement
  | ImageElement
  | ConnectionElement;

// ============================================================================
// Tool & Style Types
// ============================================================================

export type ToolType =
  | "select"
  | "lasso"
  | "pan"
  | "ballpoint"
  | "gel"
  | "fineliner"
  | "fountain"
  | "brush"
  | "marker"
  | "highlighter"
  | "pencil"
  // legacy tool ids, still selectable from old saved state
  | "pen"
  | "calligraphy"
  | "eraser"
  | "rectangle"
  | "ellipse"
  | "diamond"
  | "triangle"
  | "star"
  | "cloud"
  | "line"
  | "arrow"
  | "text"
  | "sticky"
  | "image"
  | "connect"
  // Points without writing: nothing it draws is saved or undoable.
  | "laser"
  // Selects the text of PDF / Word / PowerPoint pages to copy or mark up.
  | "textselect";

/**
 * How the laser shows where you point.
 * - "dot":   a glowing dot only - the classic presenter pointer.
 * - "trail": the dot drags a short comet tail that fades within a moment.
 * - "draw":  lines you can circle and underline with; they stay while you keep
 *            drawing and all fade together shortly after the pen lifts.
 */
export type LaserMode = "dot" | "trail" | "draw";

export const LASER_COLORS = ["#ef4444", "#22c55e", "#3b82f6", "#a855f7", "#f97316", "#ec4899"];

// ============================================================================
// Customisable tool bar
// ============================================================================

/** One button of the tool bar. "pen" and "shapes" each stand for a family. */
export type ToolbarItemId =
  | "select"
  | "pan"
  | "textselect"
  | "pen"
  | "eraser"
  | "laser"
  | "autoshape"
  | "shapes"
  | "connect"
  | "text"
  | "sticky"
  | "image";

/**
 * Every button the tool bar can hold, in the default order. `group` decides
 * where the thin dividers go: one is drawn wherever two neighbours differ.
 */
export const TOOLBAR_ITEMS: Array<{ id: ToolbarItemId; label: string; group: "move" | "ink" | "insert" }> = [
  { id: "select", label: "Select", group: "move" },
  { id: "pan", label: "Hand (move the page)", group: "move" },
  { id: "textselect", label: "Select text", group: "move" },
  { id: "pen", label: "Pens", group: "ink" },
  { id: "eraser", label: "Eraser", group: "ink" },
  { id: "laser", label: "Laser pointer", group: "ink" },
  { id: "autoshape", label: "Shape recognition", group: "ink" },
  { id: "shapes", label: "Shapes & lines", group: "insert" },
  { id: "connect", label: "Connector", group: "insert" },
  { id: "text", label: "Text", group: "insert" },
  { id: "sticky", label: "Sticky note", group: "insert" },
  { id: "image", label: "Picture", group: "insert" },
];

/** Every button there is, in their natural order. */
export const ALL_TOOLBAR_ITEMS: ToolbarItemId[] = TOOLBAR_ITEMS.map((t) => t.id);

/**
 * What a new tool bar holds. The hand is left out: fingers already move the
 * page, so on the tablet it only took space. It can still be added back.
 */
export const DEFAULT_TOOLBAR_ITEMS: ToolbarItemId[] = ALL_TOOLBAR_ITEMS.filter((id) => id !== "pan");

/**
 * A saved tool bar, kept only if it is a list of known, distinct buttons with
 * at least one in it; anything else means "the default".
 */
export function cleanToolbarItems(v: unknown): ToolbarItemId[] | undefined {
  if (!Array.isArray(v)) return undefined;
  const known = new Set<string>(ALL_TOOLBAR_ITEMS);
  const out: ToolbarItemId[] = [];
  for (const id of v) {
    if (typeof id === "string" && known.has(id) && !out.includes(id as ToolbarItemId)) out.push(id as ToolbarItemId);
  }
  return out.length > 0 ? out : undefined;
}

/**
 * The tool bar to show, from what was saved. A tool that did not exist when
 * the bar was saved appears at its default place - unless the user removed
 * it (`hidden`). Saved bars from before `hidden` was kept count only the
 * hand as removed, the one tool that was ever left out by default.
 */
export function mergeToolbarItems(
  saved: ToolbarItemId[] | undefined,
  hidden: ToolbarItemId[] | undefined
): ToolbarItemId[] {
  if (!saved || saved.length === 0) return [...DEFAULT_TOOLBAR_ITEMS];
  const removed = new Set<ToolbarItemId>(hidden ?? ["pan"]);
  const out = [...saved];
  DEFAULT_TOOLBAR_ITEMS.forEach((id, i) => {
    if (out.includes(id) || removed.has(id)) return;
    const before = DEFAULT_TOOLBAR_ITEMS.slice(0, i).reverse().find((x) => out.includes(x));
    out.splice(before ? out.indexOf(before) + 1 : 0, 0, id);
  });
  return out;
}

export interface StyleState {
  // Freehand
  /**
   * Per-tool ink, keyed by tool id. This replaced a hand-written switch that
   * had to be edited every time a pen was added — and was not, so ballpoint /
   * gel / fineliner / fountain silently fell through to `strokeColor` and
   * shared one colour and size with EACH OTHER and with shape borders.
   * A map cannot fall through, so a new pen can never again inherit that bug.
   */
  toolInk: Record<string, { color: string; size: number }>;

  // Legacy per-pen fields. Kept so an older save still migrates; the map above
  // is the source of truth.
  penColor: string;
  penSize: number;
  highlighterColor: string;
  highlighterSize: number;
  markerColor: string;
  markerSize: number;
  brushColor: string;
  brushSize: number;
  calligraphyColor: string;
  calligraphySize: number;
  pencilColor: string;
  pencilSize: number;
  eraserSize: number;
  /**
   * "pixel"  — erase only the part of a stroke under the eraser, splitting it.
   * "object" — delete whole elements on contact (the old behaviour).
   * Shapes, text, stickies and images have no partial form, so they are always
   * deleted whole regardless of this setting.
   */
  eraserMode: EraserMode;

  // Shapes & Lines
  strokeColor: string;
  fillColor: string;
  fillStyle: FillStyle;
  dashStyle: DashStyle;
  strokeWidth: number;
  shapeStrokeColor: string;
  shapeFillColor: string;

  // Lines & Arrows
  lineColor: string;
  lineWidth: number;
  startArrowhead: ArrowheadType;
  endArrowhead: ArrowheadType;

  // Text & Stickies
  textColor: string;
  fontSize: number;
  fontFamily: string;
  fontWeight: number;
  textAlign: TextAlign;
  stickyColor: StickyColor;

  // Connections
  connectionLinkType: string;
  connectionRouting: ConnectionRouting;
  connectionArrowStart: ArrowheadType;
  connectionArrowEnd: ArrowheadType;

  // Laser pointer. Size is in SCREEN pixels: a pointer is for the audience,
  // and it should look the same at every zoom.
  laserColor: string;
  laserSize: number;
  laserMode: LaserMode;
  /** "draw" mode: how long the lines stay after the pen lifts. */
  laserFadeMs: number;
}

/**
 * A pinned pen on the Favorites bar. Each pin is a full (pen type + color +
 * size) triple, so the same pen type can be pinned many times in different
 * colors — that is the whole point of the bar.
 */
export interface PinnedPen {
  id: string;
  tool: StrokeStyle;
  color: string;
  size: number;
}

/** Screen position of the floating Favorites bar (px from top-left). */
/**
 * Which edge the tool dock is attached to.
 *
 * Fixing it to the bottom wastes the widest dimension on a landscape tablet
 * and puts the tools under your writing hand. Every serious note app lets the
 * bar move; this is that setting.
 */
export type DockPosition = "bottom" | "top" | "left" | "right";

export const DOCK_POSITIONS: Array<{ id: DockPosition; label: string }> = [
  { id: "top", label: "Top" },
  { id: "bottom", label: "Bottom" },
  { id: "left", label: "Left" },
  { id: "right", label: "Right" },
];

/** Left and right docks stack vertically and need different layout. */
export function isVerticalDock(pos: DockPosition): boolean {
  return pos === "left" || pos === "right";
}

export interface PinnedBarPosition {
  x: number;
  y: number;
}

export const PEN_COLORS = [
  "#1e293b", // Slate / Black
  "#ef4444", // Red
  "#f97316", // Orange
  "#eab308", // Amber
  "#22c55e", // Green
  "#06b6d4", // Cyan
  "#3b82f6", // Blue
  "#8b5cf6", // Purple
  "#ec4899", // Pink
  "#ffffff", // White
];

export const STROKE_WIDTHS = [2, 4, 8, 14, 24];

export const DEFAULT_STYLE: StyleState = {
  toolInk: buildToolInk(),
  penColor: "#1e293b",
  penSize: 3,
  highlighterColor: "#fde047",
  highlighterSize: 24,
  markerColor: "#3b82f6",
  markerSize: 8,
  brushColor: "#1e293b",
  brushSize: 12,
  calligraphyColor: "#1e293b",
  calligraphySize: 6,
  pencilColor: "#64748b",
  pencilSize: 2,
  eraserSize: 24,
  eraserMode: "pixel",

  strokeColor: "#1e293b",
  fillColor: "transparent",
  fillStyle: "transparent",
  dashStyle: "solid",
  strokeWidth: 2,
  shapeStrokeColor: "#1e293b",
  shapeFillColor: "#3b82f6",

  lineColor: "#1e293b",
  lineWidth: 2,
  startArrowhead: "none",
  endArrowhead: "arrow",

  textColor: "#1e293b",
  fontSize: 18,
  fontFamily: FONT_FAMILIES[0].value,
  fontWeight: 400,
  textAlign: "left",
  stickyColor: "yellow",

  connectionLinkType: "relates",
  connectionRouting: "curved",
  connectionArrowStart: "none",
  connectionArrowEnd: "arrow",

  laserColor: "#ef4444",
  laserSize: 10,
  laserMode: "trail",
  laserFadeMs: 1500,
};

export function getToolColor(style: StyleState, tool: ToolType): string {
  if (isStrokeTool(tool)) {
    return style.toolInk?.[tool]?.color ?? DEFAULT_TOOL_INK[tool]?.color ?? "#1e293b";
  }
  switch (tool) {
    case "rectangle":
    case "ellipse":
    case "diamond":
    case "triangle":
    case "star":
    case "cloud": return style.shapeStrokeColor;
    case "line":
    case "arrow": return style.lineColor;
    case "text": return style.textColor;
    case "sticky": return STICKY_COLORS[style.stickyColor]?.bg ?? "#fef9c3";
    case "connect": return getLinkTypeColor(style.connectionLinkType);
    case "laser": return style.laserColor ?? DEFAULT_STYLE.laserColor;
    default: return style.strokeColor;
  }
}

export function getToolSize(style: StyleState, tool: ToolType): number {
  if (isStrokeTool(tool)) {
    return style.toolInk?.[tool]?.size ?? DEFAULT_TOOL_INK[tool]?.size ?? 4;
  }
  switch (tool) {
    case "eraser": return style.eraserSize;
    case "laser": return style.laserSize ?? DEFAULT_STYLE.laserSize;
    case "rectangle":
    case "ellipse":
    case "diamond":
    case "triangle":
    case "star":
    case "cloud":
    case "line":
    case "arrow": return style.strokeWidth;
    case "text":
    case "sticky": return style.fontSize;
    default: return style.strokeWidth;
  }
}

/**
 * Write colour and/or size for one tool in a SINGLE patch.
 *
 * Colour and size share the `toolInk` map, so two separate patches spread onto
 * one object would silently drop the first — the second `toolInk` wins. Anything
 * setting both at once (applying a pinned pen) must go through here.
 */
/**
 * The sticky colour a value names: a key ("pink") or the colour code
 * getToolColor returns for it ("#fce7f3"). Reading a sticky's colour and
 * writing it straight back used to reset it to yellow, because the getter
 * returns codes and the setter only understood names.
 */
export function stickyColorKey(c: string): StickyColor | null {
  if (c in STICKY_COLORS) return c as StickyColor;
  const lc = c.toLowerCase();
  const hit = (Object.keys(STICKY_COLORS) as StickyColor[]).find((k) => STICKY_COLORS[k].bg.toLowerCase() === lc);
  return hit ?? null;
}

export function setToolInk(
  style: StyleState,
  tool: ToolType,
  patch: { color?: string; size?: number }
): Partial<StyleState> {
  if (isStrokeTool(tool)) {
    const current =
      style.toolInk?.[tool] ?? DEFAULT_TOOL_INK[tool] ?? { color: "#1e293b", size: 4 };
    return {
      toolInk: {
        ...style.toolInk,
        [tool]: {
          color: patch.color ?? current.color,
          size: patch.size ?? current.size,
        },
      },
    };
  }

  const out: Partial<StyleState> = {};
  if (patch.color !== undefined) {
    const c = patch.color;
    switch (tool) {
      case "rectangle":
      case "ellipse":
      case "diamond":
      case "triangle":
      case "star":
      case "cloud": Object.assign(out, { shapeStrokeColor: c, shapeFillColor: c, strokeColor: c }); break;
      case "line":
      case "arrow": Object.assign(out, { lineColor: c }); break;
      case "text": Object.assign(out, { textColor: c }); break;
      case "sticky": Object.assign(out, { stickyColor: stickyColorKey(c) ?? style.stickyColor }); break;
      case "laser": Object.assign(out, { laserColor: c }); break;
      default: Object.assign(out, { strokeColor: c });
    }
  }
  if (patch.size !== undefined) {
    const n = patch.size;
    switch (tool) {
      case "eraser": Object.assign(out, { eraserSize: n }); break;
      case "laser": Object.assign(out, { laserSize: n }); break;
      case "text":
      case "sticky": Object.assign(out, { fontSize: n }); break;
      default: Object.assign(out, { strokeWidth: n });
    }
  }
  return out;
}

export function setToolColor(
  style: StyleState,
  tool: ToolType,
  color: string
): Partial<StyleState> {
  return setToolInk(style, tool, { color });
}

export function setToolSize(
  style: StyleState,
  tool: ToolType,
  size: number
): Partial<StyleState> {
  return setToolInk(style, tool, { size });
}


// ============================================================================
// Camera & Bounding Box & Document Tree
// ============================================================================

export interface Camera {
  x: number;
  y: number;
  zoom: number;
}

export const MIN_ZOOM = 0.05;
export const MAX_ZOOM = 8.0;

export interface BoundingBox {
  x: number;
  y: number;
  width: number;
  height: number;
}

export type ResizeHandle = "nw" | "n" | "ne" | "e" | "se" | "s" | "sw" | "w" | "rotate";

/** Paper style drawn behind a board's elements. */
export type BoardPattern = "dots" | "grid" | "lines" | "plain";

export interface BoardBackground {
  /** CSS colour, or undefined to follow the light/dark theme. */
  color?: string;
  pattern: BoardPattern;
  /** Spacing of the pattern in px. Undefined means the default (24). */
  size?: number;
}

/** Paper spacing limits. Below ~6px a pattern turns into visual noise; above
 *  ~120px it stops reading as ruling at all. */
export const BOARD_PATTERN_MIN_SIZE = 6;
export const BOARD_PATTERN_MAX_SIZE = 120;
export const BOARD_PATTERN_DEFAULT_SIZE = 24;

/** Handy jumps, so the common paper sizes are one tap rather than a drag. */
export const BOARD_PATTERN_SIZE_PRESETS = [12, 24, 40, 64];

export const DEFAULT_BOARD_BACKGROUND: BoardBackground = {
  pattern: "dots",
  size: BOARD_PATTERN_DEFAULT_SIZE,
};

/**
 * Ready-made board colours. Deliberately low-saturation: the background sits
 * behind everything, and a vivid one makes ink and sticky notes unreadable.
 * Each has a dark-mode partner so a board stays legible in either theme.
 */
export const BOARD_BACKGROUNDS: Array<{ id: string; label: string; light: string; dark: string }> = [
  { id: "default", label: "Theme", light: "", dark: "" },
  { id: "paper", label: "Paper", light: "#fdfaf3", dark: "#1c1a17" },
  { id: "warm", label: "Warm", light: "#fbf3e8", dark: "#221c14" },
  { id: "mint", label: "Mint", light: "#eef8f2", dark: "#12201a" },
  { id: "sky", label: "Sky", light: "#eef4fd", dark: "#121a26" },
  { id: "lavender", label: "Lavender", light: "#f4f0fd", dark: "#1a1626" },
  { id: "rose", label: "Rose", light: "#fdf0f3", dark: "#241419" },
  { id: "slate", label: "Slate", light: "#f1f3f5", dark: "#16181b" },
];

export const BOARD_PATTERNS: Array<{ id: BoardPattern; label: string }> = [
  { id: "dots", label: "Dots" },
  { id: "grid", label: "Grid" },
  { id: "lines", label: "Lines" },
  { id: "plain", label: "Plain" },
];

// ============================================================================
// Notebooks (paged documents)
// ============================================================================

/**
 * A document is either the infinite canvas ProNotes started as, or a paged
 * notebook like GoodNotes / Notability.
 *
 * Keeping both is the point. GoodNotes users' loudest complaint is that its
 * fixed pages cost them the unlimited canvas; the canvas apps have no pages at
 * all. Here they are two kinds of the same document, sharing one tree, one
 * search, one graph, one backup.
 */
export type BoardKind = "canvas" | "notebook";

export type PageSizeId = "a4" | "a4-landscape" | "letter" | "letter-landscape" | "square";

/** Page dimensions in CSS pixels at 96 dpi. */
export const PAGE_SIZES: Record<PageSizeId, { label: string; width: number; height: number }> = {
  a4: { label: "A4", width: 794, height: 1123 },
  "a4-landscape": { label: "A4 landscape", width: 1123, height: 794 },
  letter: { label: "Letter", width: 816, height: 1056 },
  "letter-landscape": { label: "Letter landscape", width: 1056, height: 816 },
  square: { label: "Square", width: 900, height: 900 },
};

export const DEFAULT_PAGE_SIZE: PageSizeId = "a4";

/**
 * A page backed by a page of an imported PDF.
 *
 * Only the reference is stored. The bytes live in IndexedDB (see
 * lib/whiteboard/pdfstore.ts) and the picture is rasterised on demand —
 * rendering 90 lecture pages into the workspace would be tens of megabytes
 * against a ~5 MB localStorage budget, and the failure would arrive on save,
 * after an hour of annotating.
 */
export interface PdfPageRef {
  docId: string;
  /** 1-based, matching how PDFs and people number pages. */
  pageNumber: number;
}

export interface NotebookPage {
  id: string;
  elements: WhiteboardElement[];
  /** Set when this page shows a PDF page underneath your ink. */
  pdf?: PdfPageRef;
  /**
   * Starred pages surface in the Favourites tab of the page rail. In a
   * 90-page lecture notebook, "the page with the exam question on it" is
   * otherwise only findable by scrolling.
   */
  bookmarked?: boolean;
  /**
   * Per-page paper. Notability is criticised for not letting one document mix
   * templates; here each page carries its own, falling back to the notebook's.
   */
  background?: BoardBackground;
  createdAt: number;
  updatedAt: number;
}

export interface Board {
  id: string;
  name: string;
  folderId: string | null;
  elements: WhiteboardElement[];
  camera: Camera;
  createdAt: number;
  updatedAt: number;
  tags?: string[];
  starred?: boolean;
  accessedAt?: number;
  color?: string;
  /** Per-board paper: colour + pattern. Undefined means the theme default. */
  background?: BoardBackground;

  /**
   * Undefined means "canvas" — every board saved before notebooks existed is
   * therefore still a valid canvas with no migration needed.
   */
  kind?: BoardKind;
  /** Notebooks only. The canvas keeps using `elements` above. */
  pages?: NotebookPage[];
  activePageId?: string;
  pageSize?: PageSizeId;
  /**
   * Exact sheet size for a notebook made from a PDF, since a PDF page is
   * rarely exactly A4 and letterboxing a lecture slide wastes the screen.
   * Overrides `pageSize` when present.
   */
  customPageSize?: { width: number; height: number };
  /** PDFs this notebook draws from, so unused ones can be pruned. */
  pdfDocIds?: string[];
}

/**
 * A reusable page: the elements and paper of a page you saved, or an imported
 * image laid onto a blank sheet. GoodNotes calls this the template library and
 * lets any PDF page or image become one.
 */
export interface PageTemplate {
  id: string;
  name: string;
  createdAt: number;
  /** Page size the template was designed at, so it can be scaled to fit. */
  width: number;
  height: number;
  background?: BoardBackground;
  elements: WhiteboardElement[];
}

export interface Folder {
  id: string;
  name: string;
  parentId: string | null;
  expanded: boolean;
  createdAt: number;
  color?: string;
}


export const FOLDER_COLORS = [
  "#3b82f6", // blue
  "#ef4444", // red
  "#f59e0b", // amber
  "#10b981", // green
  "#8b5cf6", // purple
  "#ec4899", // pink
  "#6b7280", // gray
];

// ============================================================================
// Touchscreen & Stylus Mode Types
// ============================================================================

import type { WheelMode } from "./input";

export type TouchInputMode = "touch-draw" | "stylus-only" | "touch-pan";

export type PressureCurve = "off" | "soft" | "standard" | "firm";

export interface TouchSettings {
  /**
   * Hold the stylus barrel button (or invert to the eraser end) to erase, then
   * release to get your pen back. Off switches the shortcut off entirely for
   * anyone whose pen reports the button by accident.
   */
  stylusButtonErases?: boolean;
  /**
   * Show the raw pointer-event readout. Off by default: it exists so a real
   * device can tell us what its stylus actually sends, because the spec-correct
   * reading of the barrel button does not hold on every Android WebView.
   */
  penDiagnostics?: boolean;
  /**
   * What the Select tool picks up (both the rectangle and the freeform lasso,
   * and Select All). Missing or empty means everything. It lives here because
   * this is the persisted input-preferences object, merged with defaults on
   * load, so adding it needed no migration.
   */
  selectFilter?: SelectCategory[];
  /** How a wheel event is interpreted — see lib/whiteboard/input.ts. */
  wheelMode: WheelMode;
  mode: TouchInputMode;
  palmRejection: boolean;
  twoFingerUndo: boolean;
  touchFeedback: boolean;
  largeHandles: boolean;

  // ── S Pen & Inking Engine Enhancements ──
  /** Stroke smoothing & stabilization (0 to 100, default 50). */
  penSmoothing: number;
  /** Stylus pressure dynamic sensitivity (0 to 100, default 50 = the curve exactly). 0 = uniform line. */
  penPressureSensitivity: number;
  /** Stylus pressure response curve: "off" | "soft" | "standard" | "firm". */
  penPressureCurve: PressureCurve;
  /** Prune trailing capacitive lift-off hooks when lifting pen nib. */
  penAntiHook: boolean;
  /** Draw-and-hold at the end of a stroke to auto-straighten lines / shapes. */
  penAutoStraighten: boolean;
  /** Show live S Pen hover dot previewing thickness and ink color. */
  penHoverIndicator: boolean;
  /**
   * Each pen's own writing feel. A pen without an entry uses the shared
   * values above, so nothing changes until a pen is tuned on its own.
   */
  penFeel?: Partial<Record<StrokeStyle, PenFeel>>;
}

export interface PenFeel {
  curve?: PressureCurve;
  smoothing?: number;
  sensitivity?: number;
}

/** The writing feel a pen actually uses: its own, else the shared one. */
export function penFeelFor(
  ts: Partial<TouchSettings>,
  style: string
): { curve: PressureCurve; smoothing: number; sensitivity: number } {
  const own = ts.penFeel?.[style as StrokeStyle] ?? {};
  return {
    curve: own.curve ?? ts.penPressureCurve ?? "standard",
    smoothing: own.smoothing ?? ts.penSmoothing ?? 50,
    sensitivity: own.sensitivity ?? ts.penPressureSensitivity ?? 50,
  };
}

// ============================================================================
// Selection filter
// ============================================================================
// GoodNotes and Notability let the lasso pick up only some kinds of thing —
// the usual reason being to grab your handwriting off a page without also
// dragging the typed text or the image beside it.

export type SelectCategory = "ink" | "text" | "shapes" | "images";

export const SELECT_CATEGORIES: SelectCategory[] = ["ink", "text", "shapes", "images"];

export function selectCategoryOf(el: { type: string }): SelectCategory | null {
  switch (el.type) {
    case "stroke":
      return "ink";
    case "text":
    case "sticky":
      return "text";
    case "image":
      return "images";
    case "rectangle":
    case "ellipse":
    case "diamond":
    case "triangle":
    case "star":
    case "cloud":
    case "line":
    case "arrow":
      return "shapes";
    default:
      return null; // connections and anything unknown are never swept up
  }
}

/**
 * The effective filter. Anything malformed — a missing field, an empty list,
 * a value from a newer build this one does not know — falls back to
 * "everything", because a filter that silently selects nothing looks exactly
 * like the Select tool being broken.
 */
export function effectiveSelectFilter(saved: unknown): Set<SelectCategory> {
  if (!Array.isArray(saved)) return new Set(SELECT_CATEGORIES);
  const known = saved.filter((c): c is SelectCategory =>
    (SELECT_CATEGORIES as string[]).includes(c as string)
  );
  return new Set(known.length ? known : SELECT_CATEGORIES);
}

/**
 * Whether a selection gesture may pick this element right now. Normally
 * locked things are out of reach; in locked-items mode ONLY they are, so
 * they can be found and unlocked without touching anything else.
 */
export function pickableNow(el: { locked?: boolean }, lockedMode: boolean): boolean {
  return lockedMode ? !!el.locked : !el.locked;
}

export function passesSelectFilter(el: { type: string }, filter: Set<SelectCategory>): boolean {
  const cat = selectCategoryOf(el);
  return cat !== null && filter.has(cat);
}

export const DEFAULT_TOUCH_SETTINGS: TouchSettings = {
  stylusButtonErases: true,
  penDiagnostics: false,
  wheelMode: "auto",
  mode: "touch-draw",
  palmRejection: false,
  twoFingerUndo: true,
  touchFeedback: true,
  largeHandles: true,
  penSmoothing: 50,
  penPressureSensitivity: 50,
  penPressureCurve: "standard",
  penAntiHook: true,
  penAutoStraighten: true,
  penHoverIndicator: true,
};


