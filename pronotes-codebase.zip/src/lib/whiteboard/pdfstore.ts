/**
 * PDF byte storage (IndexedDB)
 * ============================
 * Imported PDFs are kept here, NOT in the workspace that goes to localStorage.
 *
 * Why this exists at all: the obvious implementation is to render every page
 * to a PNG and drop those into the notebook as image elements. A 90-page
 * lecture PDF at A4 is roughly 200-500 KB per page once rasterised — 20-45 MB
 * — against a localStorage budget of about 5 MB. It would not fail politely
 * either: the quota error arrives on SAVE, so you would import a PDF, annotate
 * it for an hour, and then lose the lot.
 *
 * So the original bytes are stored once in IndexedDB (hundreds of MB
 * available), each notebook page holds only a `{ docId, pageNumber }`
 * reference, and pages are rasterised on demand for display. Your ink stays in
 * the normal element list, completely separate from the PDF, so it survives
 * even if the source document is later removed.
 */

const DB_NAME = "pronotes-pdfs";
const DB_VERSION = 1;
const STORE = "documents";

export interface StoredPdf {
  id: string;
  name: string;
  bytes: ArrayBuffer;
  pageCount: number;
  addedAt: number;
}

/** Metadata without the payload — cheap to list. */
export type PdfSummary = Omit<StoredPdf, "bytes">;

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === "undefined") {
      reject(new Error("This browser has no IndexedDB, so PDFs cannot be stored."));
      return;
    }
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE)) {
        db.createObjectStore(STORE, { keyPath: "id" });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error ?? new Error("Could not open the PDF store"));
  });
}

function tx<T>(mode: IDBTransactionMode, run: (store: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  return openDb().then(
    (db) =>
      new Promise<T>((resolve, reject) => {
        const t = db.transaction(STORE, mode);
        const req = run(t.objectStore(STORE));
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error ?? new Error("PDF store request failed"));
        t.oncomplete = () => db.close();
      })
  );
}

export function putPdf(doc: StoredPdf): Promise<void> {
  return tx("readwrite", (s) => s.put(doc) as unknown as IDBRequest<void>).then(() => undefined);
}

export function getPdf(id: string): Promise<StoredPdf | undefined> {
  return tx<StoredPdf | undefined>("readonly", (s) => s.get(id));
}

export function deletePdf(id: string): Promise<void> {
  return tx("readwrite", (s) => s.delete(id) as unknown as IDBRequest<void>).then(() => undefined);
}

/** Every stored PDF, without its bytes. */
export async function listPdfs(): Promise<PdfSummary[]> {
  const all = await tx<StoredPdf[]>("readonly", (s) => s.getAll() as IDBRequest<StoredPdf[]>);
  return all
    .map(({ id, name, pageCount, addedAt }) => ({ id, name, pageCount, addedAt }))
    .sort((a, b) => b.addedAt - a.addedAt);
}

/**
 * Removes PDFs nothing references any more.
 *
 * Deleting a notebook does not reach in here, so without this a discarded
 * import would occupy storage forever with nothing able to open it.
 */
export async function pruneUnusedPdfs(referencedIds: Set<string>): Promise<string[]> {
  const stored = await listPdfs();
  const orphans = stored.filter((d) => !referencedIds.has(d.id)).map((d) => d.id);
  for (const id of orphans) await deletePdf(id);
  // A document's text goes with it - and only then. Keyed on what is still
  // STORED, not on what is referenced, so text can never outlive its PDF nor
  // be dropped while the PDF (and an Undo that restores it) still exists.
  try {
    const { pruneDocTexts } = await import("./pdfTextStore");
    // Listed again NOW: a document imported while the deletes ran (a Word
    // file converting) must keep the text it just stored.
    const current = await listPdfs();
    await pruneDocTexts(new Set(current.map((d) => d.id)));
  } catch {
    // Housekeeping only.
  }
  return orphans;
}

/** Total bytes held, for showing the user what their imports cost. */
export async function pdfStorageBytes(): Promise<number> {
  const all = await tx<StoredPdf[]>("readonly", (s) => s.getAll() as IDBRequest<StoredPdf[]>);
  return all.reduce((sum, d) => sum + (d.bytes?.byteLength ?? 0), 0);
}
