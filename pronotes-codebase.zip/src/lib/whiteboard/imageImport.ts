/**
 * Getting a picture ready to go on the page.
 *
 * A tablet camera photo is 12-50 megapixels and 4-12 MB. Stored as taken, a
 * dozen of them fill the app's storage, and every one costs memory each time
 * the page is drawn - for detail no one can see on a notebook page. So a
 * picture larger than MAX_SIDE is scaled down once, here, before it is saved.
 * Small pictures, and anything that is not a plain photo (GIF, SVG), pass
 * through untouched.
 */

export const MAX_SIDE = 2560;

export function readAsDataUrl(file: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(String(r.result ?? ""));
    r.onerror = () => reject(r.error ?? new Error("Could not read the picture."));
    r.readAsDataURL(file);
  });
}

function loadImg(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("This file is not a picture ProNotes can open."));
    img.src = src;
  });
}

/** The size a picture is scaled to so its longer side is at most `max`. */
export function fitWithin(w: number, h: number, max = MAX_SIDE): { w: number; h: number } {
  const s = Math.min(1, max / Math.max(w, h, 1));
  return { w: Math.max(1, Math.round(w * s)), h: Math.max(1, Math.round(h * s)) };
}

export async function prepareImage(file: Blob): Promise<string> {
  const dataUrl = await readAsDataUrl(file);
  if (/^data:image\/(gif|svg)/i.test(dataUrl)) return dataUrl;
  const img = await loadImg(dataUrl);
  const { naturalWidth: w, naturalHeight: h } = img;
  if (Math.max(w, h) <= MAX_SIDE) return dataUrl;
  const size = fitWithin(w, h);
  const canvas = document.createElement("canvas");
  canvas.width = size.w;
  canvas.height = size.h;
  const ctx = canvas.getContext("2d");
  if (!ctx) return dataUrl;
  ctx.imageSmoothingQuality = "high";
  ctx.drawImage(img, 0, 0, size.w, size.h);
  // PNGs may be screenshots or diagrams with transparency: keep them PNG.
  const png = /^data:image\/png/i.test(dataUrl);
  return canvas.toDataURL(png ? "image/png" : "image/jpeg", 0.9);
}

export function isImageFile(file: File): boolean {
  return file.type.startsWith("image/") || /\.(png|jpe?g|gif|webp|bmp|svg|heic|heif)$/i.test(file.name);
}
