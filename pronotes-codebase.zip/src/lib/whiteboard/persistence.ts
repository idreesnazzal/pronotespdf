/**
 * Whiteboard Persistence Layer
 * =============================
 *
 * Saves the entire whiteboard state (folders, boards, elements) to localStorage
 * with a debounced autosave. Provides load/save/clear operations.
 *
 * Schema versioning: if the schema changes in a breaking way, bump SCHEMA_VERSION
 * and add a migration in `migrate()`.
 */

import { isAbandonedTextBox } from "./textbox";
import { DEFAULT_PAGE_SIZE, STROKE_TOOL_IDS, cleanToolbarItems } from "./types";
import {
  HEARTBEAT_KEY,
  STORAGE_PRESSURE_RATIO,
  createIdbWorkspaceBackend,
  decodeWorkspace,
  encodeWorkspace,
  measureStoragePressure,
  workspaceDbAvailable,
  type WorkspaceBackend,
} from "./workspaceDb";
import type {
  Board,
  BoardBackground,
  Folder,
  NotebookPage,
  PageSizeId,
  DockPosition,
  PageTemplate,
  PinnedBarPosition,
  PinnedPen,
  StyleState,
  ToolType,
  ToolbarItemId,
  TouchSettings,
  WhiteboardElement,
} from "./types";

const STORAGE_KEY = "z-whiteboard-state-v1";
const SCHEMA_VERSION = 1;

const VALID_BOARD_PATTERNS: string[] = ["dots", "grid", "lines", "plain"];
const VALID_PAGE_SIZES: string[] = ["a4", "a4-landscape", "letter", "letter-landscape", "square"];
const VALID_DOCKS: string[] = ["bottom", "top", "left", "right"];
const BOARD_PATTERN_MIN_SIZE = 6;
const BOARD_PATTERN_MAX_SIZE = 120;

/**
 * Tool ids accepted from a save. DERIVED from STROKE_TOOL_IDS rather than
 * hand-listed: the hand-written version still named only the pre-rework pens,
 * so a saved `tool` of "ballpoint" / "gel" / "fineliner" / "fountain" was
 * rejected and the pen silently reset to the default on every reload.
 */
const NON_STROKE_TOOLS: string[] = [
  "select", "lasso", "pan", "eraser", "rectangle", "ellipse", "diamond",
  "triangle", "star", "cloud", "line", "arrow", "text", "sticky", "image",
  "connect", "laser", "textselect",
];
const VALID_TOOLS: string[] = [...NON_STROKE_TOOLS, ...STROKE_TOOL_IDS];

/** Only keep a plain object; anything else would poison the merged defaults. */
function objectOrUndefined<T>(v: unknown): T | undefined {
  return v && typeof v === "object" && !Array.isArray(v) ? (v as T) : undefined;
}

function boolOrUndefined(v: unknown): boolean | undefined {
  return typeof v === "boolean" ? v : undefined;
}

/**
 * A pin is a pen, so this is exactly the stroke tools. Hand-listing it meant a
 * pinned ballpoint / gel / fineliner / fountain failed validation and was
 * DELETED from the favourites bar on the next load.
 */
const VALID_PIN_TOOLS: string[] = STROKE_TOOL_IDS;

export interface PersistedState {
  version: number;
  folders: Folder[];
  boards: Board[];
  activeBoardId: string | null;
  activeFolderId: string | null;
  customLinkTypes?: Array<{ id: string; name: string; color: string }>;
  pinnedPens?: PinnedPen[];
  pinnedBarPos?: PinnedBarPosition | null;
  toolbarPosition?: DockPosition;
  pageTemplates?: PageTemplate[];
  splitBoardId?: string | null;
  splitRatio?: number;
  splitSide?: "left" | "right";
  splitOrientation?: "side" | "stacked";
  recentColors?: string[];
  style?: Partial<StyleState>;
  tool?: ToolType;
  lastStrokeTool?: ToolType;
  touchSettings?: Partial<TouchSettings>;
  snapToGrid?: boolean;
  minimapOpen?: boolean;
  legendOpen?: boolean;
  zoomDockOpen?: boolean;
  shapeRecognition?: boolean;
  defaultPaper?: BoardBackground;
  pinnedBarOpen?: boolean;
  pinnedBarVertical?: boolean;
  propsPanelCollapsed?: boolean;
  toolPropsBarCollapsed?: boolean;
  /** The tool bar's buttons, in order. Absent = all of them, default order. */
  toolbarTools?: ToolbarItemId[];
  /** Buttons the user took off the bar, so tools added later can still appear. */
  toolbarHidden?: ToolbarItemId[];
}

export function loadState(): PersistedState | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as PersistedState;
    // Always run migrate() — it's idempotent and ensures any missing fields
    // (e.g., tags/starred/accessedAt added after initial release) are backfilled.
    return migrate(parsed);
  } catch (e) {
    console.error("[whiteboard] Failed to load state:", e);
    return null;
  }
}

let lastSaveWasDegraded = false;

/**
 * Fire a storage-health event without ever throwing. saveState's whole job on
 * the failure path is to report trouble instead of propagating it; if the
 * reporting itself threw (no CustomEvent, no dispatchEvent, a listener that
 * raises) the exception would escape saveState and reach the autosave timer —
 * the exact crash the quota handling exists to prevent.
 */
function notify(event: string): void {
  try {
    window.dispatchEvent(new CustomEvent(event));
  } catch {
    /* reporting is best-effort; never let it break a save */
  }
}

/**
 * Ordered save queue. IndexedDB writes are async, so two rapid saves could
 * otherwise interleave and an OLDER snapshot could land after a newer one.
 * Chaining keeps last-write-wins: every save waits for the previous one.
 * Rejections are consumed here (each failure is already reported via the
 * storage-health events below), so the chain itself never breaks.
 */
let saveChain: Promise<void> = Promise.resolve();
function queueWorkspaceSave(task: () => Promise<void>): Promise<void> {
  saveChain = saveChain.then(task, task);
  saveChain.catch(() => undefined);
  return saveChain;
}

/**
 * Tiny cross-tab heartbeat. The workspace itself moved to IndexedDB (which
 * fires no cross-tab events), so every successful save also stamps ~50 bytes
 * into localStorage — just enough to keep the `storage`-event based
 * multi-tab guard in `watchExternalSaves` working. Best-effort by design: a
 * full localStorage must never be able to fail the real save.
 */
let heartbeatRev = 0;
function writeHeartbeat(): void {
  try {
    heartbeatRev += 1;
    window.localStorage.setItem(HEARTBEAT_KEY, JSON.stringify({ rev: heartbeatRev, at: Date.now() }));
  } catch {
    /* heartbeat is expendable; the save already succeeded */
  }
}

let lastPressureCheck = 0;
/**
 * Early warning BEFORE writes start failing: if the origin's pooled storage
 * is past the pressure line, tell the user to back up while saves still work.
 * Throttled — estimate() is cheap but there is no reason to ask twice a second.
 */
function checkPressureThrottled(): void {
  const now = Date.now();
  if (now - lastPressureCheck < 30_000) return;
  lastPressureCheck = now;
  void measureStoragePressure().then((p) => {
    if (p && p.ratio >= STORAGE_PRESSURE_RATIO) notify("wb:storage-pressure");
  });
}

/**
 * Primary save. Where the bytes land depends on capability, not preference:
 *
 * - IndexedDB present (every real browser, the APK, Electron): the snapshot
 *   is gzipped past 1 MB and stored there, where the quota is a share of free
 *   disk instead of localStorage's ~5 MB hard cap.
 * - IndexedDB absent (unit tests, SSR, exotic WebViews): the legacy
 *   synchronous localStorage write, byte-for-byte the old behavior — the E2E
 *   suites exercise exactly this path.
 *
 * Failure reporting is identical on both paths: `wb:save-degraded` when only
 * the image-stripped retry fit, `wb:save-failed` when nothing could be
 * written, `wb:save-recovered` when writes succeed again.
 */
export function saveState(state: PersistedState): void | Promise<void> {
  if (typeof window === "undefined") return;
  if (!workspaceDbAvailable()) {
    saveStateLocalStorage(state);
    return;
  }
  return queueWorkspaceSave(() => saveWorkspaceToBackend(state, createIdbWorkspaceBackend()).then(() => undefined));
}

/**
 * The IndexedDB save itself, backend-injected so unit tests can prove the
 * quota story with an in-memory store: returns how the write landed.
 * Production always passes the real IndexedDB backend via saveState above.
 */
export async function saveWorkspaceToBackend(
  state: PersistedState,
  backend: WorkspaceBackend
): Promise<"ok" | "degraded" | "failed"> {
  let json: string;
  try {
    json = JSON.stringify({ ...state, version: SCHEMA_VERSION });
  } catch (e) {
    // Unserializable state (e.g. a cycle smuggled into an element). This
    // used to escape saveState and kill the autosave timer; reporting a
    // failed save keeps the app alive and the banner truthful.
    console.error("[whiteboard] Failed to serialize state:", e);
    notify("wb:save-failed");
    return "failed";
  }
  try {
    await backend.save(await encodeWorkspace(json));
  } catch (e) {
    console.error("[whiteboard] Failed to save state:", e);
    // Degraded retry: pasted image data-URLs are the heaviest single
    // payloads. Structure, strokes and text survive; images don't.
    try {
      await backend.save(await encodeWorkspace(JSON.stringify(withoutImagePayloads(state))));
    } catch {
      notify("wb:save-failed");
      return "failed";
    }
    lastSaveWasDegraded = true;
    notify("wb:save-degraded");
    return "degraded";
  }
  if (lastSaveWasDegraded) {
    lastSaveWasDegraded = false;
    notify("wb:save-recovered");
  }
  writeHeartbeat();
  checkPressureThrottled();
  return "ok";
}

/** The legacy synchronous localStorage write. Still the whole story where IndexedDB is absent. */
function saveStateLocalStorage(state: PersistedState): void {
  const payload = JSON.stringify({ ...state, version: SCHEMA_VERSION });
  try {
    window.localStorage.setItem(STORAGE_KEY, payload);
  } catch (e) {
    console.error("[whiteboard] Failed to save state:", e);
    return saveDegraded(state);
  }
  // The write succeeded. Announcing recovery must not be able to undo that by
  // throwing into the catch above, so it happens outside the guarded block.
  if (lastSaveWasDegraded) {
    lastSaveWasDegraded = false;
    notify("wb:save-recovered");
  }
  writeHeartbeat();
}

/**
 * Workspace without the heaviest payloads — pasted image data-URLs, from BOTH
 * places they live. This used to touch only `b.elements` — the canvas field —
 * so a notebook, whose images sit in `b.pages[i].elements`, shed nothing, the
 * payload stayed over quota, the retry failed too, and NOTHING was saved.
 * Dropping image pixels is bad; silently saving nothing is worse.
 */
function withoutImagePayloads(state: PersistedState): PersistedState {
  const stripImages = (els: WhiteboardElement[] | undefined) =>
    (els ?? []).map((el) => (el.type === "image" ? { ...el, src: "" } : el));
  return {
    ...state,
    boards: state.boards.map((b) => ({
      ...b,
      elements: stripImages(b.elements),
      ...(Array.isArray(b.pages)
        ? { pages: b.pages.map((p) => ({ ...p, elements: stripImages(p.elements ?? []) })) }
        : {}),
    })),
  };
}

/**
 * Quota (or any write failure) on the localStorage path: retry once without
 * the heaviest payloads. Either way the UI is notified so the user knows
 * saving is impaired.
 */
function saveDegraded(state: PersistedState): void {
  let written = false;
  try {
    const degraded = withoutImagePayloads(state);
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify({ ...degraded, version: SCHEMA_VERSION }));
    written = true;
  } catch {
    written = false;
  }
  // Notifications live outside the try so a throwing listener cannot flip a
  // successful degraded write into a reported failure (or escape the function).
  if (written) {
    lastSaveWasDegraded = true;
    notify("wb:save-degraded");
  } else {
    notify("wb:save-failed");
  }
}

export interface WorkspaceLoadResult {
  state: PersistedState | null;
  /** True when the state was adopted from the legacy localStorage copy. */
  migratedFromLs: boolean;
}

/**
 * Primary load. Prefers the IndexedDB record; adopts the legacy localStorage
 * copy (and moves it over) when there is none; returns null when nothing
 * readable exists anywhere. A corrupt IndexedDB record falls back to
 * localStorage rather than bricking the app — a bad record costs convenience,
 * never boards.
 *
 * The localStorage copy is deleted only AFTER the migrated record is safely
 * stored — a crash mid-migration keeps the old copy readable. Downgrades are
 * not supported: an older build cannot read the IndexedDB record, so moving
 * back to an older APK requires a backup round-trip.
 */
export async function loadWorkspace(backend?: WorkspaceBackend): Promise<WorkspaceLoadResult> {
  const store = backend ?? (workspaceDbAvailable() ? createIdbWorkspaceBackend() : null);
  if (!store) return { state: loadState(), migratedFromLs: false };
  try {
    const rec = await store.load();
    if (rec) {
      return { state: migrate(JSON.parse(await decodeWorkspace(rec)) as PersistedState), migratedFromLs: false };
    }
  } catch (e) {
    console.error("[whiteboard] Workspace record unreadable, falling back:", e);
  }
  const legacy = loadState();
  if (!legacy) return { state: null, migratedFromLs: false };
  try {
    await store.save(await encodeWorkspace(JSON.stringify({ ...legacy, version: SCHEMA_VERSION })));
    try {
      window.localStorage.removeItem(STORAGE_KEY);
    } catch {
      /* origin full; the stale copy is harmless, the live one is in IndexedDB */
    }
    return { state: legacy, migratedFromLs: true };
  } catch (e) {
    console.error("[whiteboard] Could not migrate workspace to IndexedDB:", e);
    return { state: legacy, migratedFromLs: false };
  }
}

export function clearState(): void {
  if (typeof window === "undefined") return;
  window.localStorage.removeItem(STORAGE_KEY);
  // The workspace itself lives in IndexedDB now; the localStorage key is only
  // the legacy copy / heartbeat. Clearing must remove both, or a reload would
  // resurrect the "deleted" boards from the other store.
  if (workspaceDbAvailable()) {
    createIdbWorkspaceBackend().clear().catch(() => undefined);
  }
}

/**
 * Multi-tab guard: the `storage` event fires in every OTHER tab when this
 * tab writes. Each successful workspace save stamps a tiny heartbeat key, so
 * a write from another tab means this tab's in-memory copy is now stale —
 * listeners can warn the user instead of silently losing work on the next save.
 */
export function watchExternalSaves(onExternal: () => void): () => void {
  if (typeof window === "undefined") return () => {};
  const handler = (ev: StorageEvent) => {
    if (ev.key === STORAGE_KEY) onExternal();
  };
  window.addEventListener("storage", handler);
  return () => window.removeEventListener("storage", handler);
}

/**
 * Validate + backfill an arbitrary saved payload. Exported so that data coming
 * from OUTSIDE localStorage — an imported backup file, or a workspace pulled
 * from OneDrive — goes through exactly the same hardening as a local load.
 */
export function migrateState(old: PersistedState): PersistedState {
  return migrate(old);
}

function migrate(old: PersistedState): PersistedState {
  // Harden against corrupt / partial / hand-edited saves: a board whose
  // `elements` is undefined used to pass through and crash every consumer
  // (`for..of` throws), bricking the app on each load because the bad state
  // was re-saved. Everything is validated and backfilled here.
  const rawBoards = Array.isArray(old.boards) ? old.boards : [];
  const rawFolders = Array.isArray(old.folders) ? old.folders : [];

  const folders: Folder[] = rawFolders
    .filter((f) => f && typeof f.id === "string")
    .map((f) => ({
      ...f,
      name: typeof f.name === "string" ? f.name : "Untitled folder",
      parentId: typeof f.parentId === "string" ? f.parentId : null,
      expanded: f.expanded !== false,
      createdAt: typeof f.createdAt === "number" ? f.createdAt : Date.now(),
      color: typeof f.color === "string" ? f.color : "#f59e0b",
    }));

  // Elements are sanitised identically wherever they live — the canvas field
  // or a notebook page — so a stroke cannot survive on one and be dropped on
  // the other.
  const cleanElements = (raw: unknown): WhiteboardElement[] =>
    (Array.isArray(raw) ? raw : [])
      .filter(
        (el) =>
          el && typeof (el as { id?: unknown }).id === "string" &&
          typeof (el as { type?: unknown }).type === "string"
      )
      // Text boxes started and never written in. Older builds never removed
      // them, so they piled up as invisible elements that only showed a "Type
      // thoughts..." placeholder when selected. Lossless to drop: they hold no
      // text, and a box styled as a shape (fill / border) is kept.
      .filter((el) => !isAbandonedTextBox(el as WhiteboardElement))
      // Drop the legacy cached stroke `path`. It is derived data that froze
      // each stroke's geometry at draw time and cost ~143% of the points'
      // size; dropping it reclaims that space and lets existing strokes pick
      // up rendering fixes.
      .map((el) => {
        const e = el as Record<string, unknown>;
        if (e.type === "stroke" && "path" in e) {
          const { path: _legacyPath, ...rest } = e;
          return rest;
        }
        return e;
      }) as unknown as WhiteboardElement[];

  const cleanBackground = (bg: unknown): BoardBackground | undefined => {
    const b = bg as { pattern?: string; size?: unknown } | undefined;
    if (!b || !VALID_BOARD_PATTERNS.includes(b.pattern as never)) return undefined;
    return {
      ...b,
      size:
        typeof b.size === "number" && Number.isFinite(b.size)
          ? Math.min(BOARD_PATTERN_MAX_SIZE, Math.max(BOARD_PATTERN_MIN_SIZE, b.size))
          : undefined,
    } as BoardBackground;
  };

  const boards = rawBoards
    .filter((b) => b && typeof b.id === "string" && typeof b.name === "string")
    .map((b) => ({
      ...b,
      elements: cleanElements(b.elements),
      camera:
        b.camera &&
        typeof b.camera.x === "number" &&
        typeof b.camera.y === "number" &&
        typeof b.camera.zoom === "number" &&
        Number.isFinite(b.camera.zoom) &&
        b.camera.zoom > 0
          ? b.camera
          : { x: 0, y: 0, zoom: 1 },
      // Board paper: drop an unknown pattern rather than rendering nothing, and
      // clamp the spacing. A size of 0 or NaN would make the SVG pattern tile
      // infinitely small and lock the renderer.
      background: cleanBackground(b.background),

      // ---- Notebooks ----
      // A board with no `kind` is a canvas, so everything saved before
      // notebooks existed loads unchanged with no migration.
      ...(b.kind === "notebook"
        ? (() => {
            const rawPages: unknown[] = Array.isArray(b.pages) ? (b.pages as unknown[]) : [];
            const pages: NotebookPage[] = rawPages
              .filter((p) => p && typeof (p as { id?: unknown }).id === "string")
              .map((raw) => {
                const p = raw as Record<string, unknown>;
                return {
                  id: p.id as string,
                  elements: cleanElements(p.elements),
                  background: cleanBackground(p.background),
                  bookmarked: p.bookmarked === true,
                  // A PDF reference is only usable if both halves survived.
                  // A half-written one would render a blank sheet forever.
                  pdf:
                    p.pdf &&
                    typeof (p.pdf as { docId?: unknown }).docId === "string" &&
                    Number.isInteger((p.pdf as { pageNumber?: unknown }).pageNumber) &&
                    (p.pdf as { pageNumber: number }).pageNumber >= 1
                      ? (p.pdf as { docId: string; pageNumber: number })
                      : undefined,
                  createdAt: typeof p.createdAt === "number" ? p.createdAt : Date.now(),
                  updatedAt: typeof p.updatedAt === "number" ? p.updatedAt : Date.now(),
                };
              });

            // A notebook must always have at least one page to draw on, and
            // `activePageId` must name a page that exists — a stale id would
            // otherwise leave the document apparently blank.
            const safePages: NotebookPage[] =
              pages.length > 0
                ? pages
                : [
                    {
                      id: `pg_recovered_${b.id}`,
                      elements: [],
                      createdAt: Date.now(),
                      updatedAt: Date.now(),
                    },
                  ];
            const activePageId =
              typeof b.activePageId === "string" && safePages.some((p) => p.id === b.activePageId)
                ? b.activePageId
                : safePages[0].id;

            return {
              kind: "notebook" as const,
              pages: safePages,
              activePageId,
              pageSize: (VALID_PAGE_SIZES.includes(b.pageSize as string)
                ? b.pageSize
                : DEFAULT_PAGE_SIZE) as PageSizeId,
              // A zero or negative sheet size would collapse every page to
              // nothing, with no way back from the UI.
              customPageSize:
                b.customPageSize &&
                typeof (b.customPageSize as { width?: unknown }).width === "number" &&
                typeof (b.customPageSize as { height?: unknown }).height === "number" &&
                (b.customPageSize as { width: number }).width > 0 &&
                (b.customPageSize as { height: number }).height > 0
                  ? (b.customPageSize as { width: number; height: number })
                  : undefined,
              pdfDocIds: Array.isArray(b.pdfDocIds)
                ? (b.pdfDocIds as unknown[]).filter((x): x is string => typeof x === "string")
                : undefined,
            };
          })()
        : { kind: undefined, pages: undefined, activePageId: undefined, pageSize: undefined }),
      tags: Array.isArray(b.tags) ? b.tags : [],
      starred: typeof b.starred === "boolean" ? b.starred : false,
      accessedAt: typeof b.accessedAt === "number" ? b.accessedAt : b.createdAt ?? Date.now(),
      color: typeof b.color === "string" ? b.color : "#3b82f6",
    }));

  return {
    ...old,
    version: SCHEMA_VERSION,
    folders,
    boards: boards as unknown as Board[],
    activeBoardId: typeof old.activeBoardId === "string" ? old.activeBoardId : null,
    activeFolderId: typeof old.activeFolderId === "string" ? old.activeFolderId : null,
    // Templates carry ink, so they get the same sanitising as a page — a
    // malformed one would otherwise crash the picker that renders it.
    pageTemplates: (Array.isArray(old.pageTemplates) ? (old.pageTemplates as unknown[]) : [])
      .filter(
        (t) =>
          t &&
          typeof (t as { id?: unknown }).id === "string" &&
          typeof (t as { name?: unknown }).name === "string"
      )
      .map((raw) => {
        const t = raw as Record<string, unknown>;
        return {
          id: t.id as string,
          name: t.name as string,
          createdAt: typeof t.createdAt === "number" ? t.createdAt : Date.now(),
          width: typeof t.width === "number" && t.width > 0 ? t.width : 794,
          height: typeof t.height === "number" && t.height > 0 ? t.height : 1123,
          background: cleanBackground(t.background),
          elements: cleanElements(t.elements),
        };
      }),
    // A split pointing at a board that has since been deleted would render
    // an empty pane with no obvious way to close it.
    splitBoardId:
      typeof old.splitBoardId === "string" &&
      (Array.isArray(old.boards) ? old.boards : []).some(
        (b: { id?: unknown }) => b && b.id === old.splitBoardId
      )
        ? old.splitBoardId
        : null,
    splitRatio:
      typeof old.splitRatio === "number" && Number.isFinite(old.splitRatio)
        ? Math.max(0.2, Math.min(0.8, old.splitRatio))
        : 0.5,
    splitSide: old.splitSide === "right" ? "right" : "left",
    splitOrientation: old.splitOrientation === "stacked" ? "stacked" : "side",
    // An unknown dock edge would position the toolbar nowhere; fall back.
    toolbarPosition: VALID_DOCKS.includes(old.toolbarPosition as string)
      ? old.toolbarPosition
      : "bottom",
    customLinkTypes: Array.isArray(old.customLinkTypes) ? old.customLinkTypes : [],
    // Favourite pens: drop anything that is not a well-formed pin rather than
    // letting a corrupt entry render as an unusable swatch.
    pinnedPens: Array.isArray(old.pinnedPens)
      ? old.pinnedPens.filter(
          (p): p is PinnedPen =>
            !!p &&
            typeof p.id === "string" &&
            VALID_PIN_TOOLS.includes(p.tool) &&
            typeof p.color === "string" &&
            Number.isFinite(p.size) &&
            p.size > 0
        )
      : [],
    // Preferences. Each is validated on its own so one bad field cannot throw
    // away the rest; anything invalid falls back to the default at init().
    style: objectOrUndefined<Partial<StyleState>>(old.style),
    touchSettings: objectOrUndefined<Partial<TouchSettings>>(old.touchSettings),
    tool: typeof old.tool === "string" && VALID_TOOLS.includes(old.tool) ? old.tool : undefined,
    snapToGrid: boolOrUndefined(old.snapToGrid),
    minimapOpen: boolOrUndefined(old.minimapOpen),
    legendOpen: boolOrUndefined(old.legendOpen),
    zoomDockOpen: boolOrUndefined(old.zoomDockOpen),
    shapeRecognition: boolOrUndefined(old.shapeRecognition),
    // App default paper for future boards/pages. Validated like every other
    // background; garbage falls back to plain at init().
    defaultPaper: cleanBackground(old.defaultPaper) ?? { pattern: "plain" },
    pinnedBarOpen: boolOrUndefined(old.pinnedBarOpen),
    propsPanelCollapsed: boolOrUndefined(old.propsPanelCollapsed),
    toolPropsBarCollapsed: boolOrUndefined(old.toolPropsBarCollapsed),
    toolbarTools: cleanToolbarItems(old.toolbarTools),
    toolbarHidden: Array.isArray(old.toolbarHidden) ? cleanToolbarItems(old.toolbarHidden) ?? [] : undefined,
    recentColors: Array.isArray(old.recentColors)
      ? old.recentColors.filter((c): c is string => typeof c === "string").slice(0, 8)
      : [],
    pinnedBarPos:
      old.pinnedBarPos &&
      Number.isFinite(old.pinnedBarPos.x) &&
      Number.isFinite(old.pinnedBarPos.y)
        ? { x: old.pinnedBarPos.x, y: old.pinnedBarPos.y }
        : null,
  };
}

// ============================================================================
// Debounced autosave
// ============================================================================

let saveTimer: ReturnType<typeof setTimeout> | null = null;
const SAVE_DEBOUNCE_MS = 500;

/**
 * While the pen is writing, background saves wait. A save serialises the
 * WHOLE workspace on the main thread (9 MB for a 20-notebook workspace:
 * ~75 ms on a Galaxy Tab S9), and with a 500 ms debounce it landed in the
 * short pauses between words - exactly when the next word began, so its
 * first stroke started late. Saves now run once the pen has been quiet a
 * moment. Leaving the app still saves at once (flushSave / flushHistorySave
 * on visibilitychange, pagehide and beforeunload), so nothing is put at risk.
 */
let quietUntil = 0;
export function deferSavesWhileWriting(ms = 1500): void {
  quietUntil = Math.max(quietUntil, Date.now() + ms);
}

/**
 * setTimeout that, when due, waits on while the pen is still writing.
 * `setHandle` always holds the live timer, so a flush can still cancel it.
 */
function whenQuiet(
  delay: number,
  fn: () => void,
  setHandle: (t: ReturnType<typeof setTimeout>) => void
): void {
  const run = () => {
    const wait = quietUntil - Date.now();
    if (wait > 0) {
      setHandle(setTimeout(run, wait));
      return;
    }
    fn();
  };
  setHandle(setTimeout(run, delay));
}

/**
 * Schedule a debounced save. Multiple rapid updates (e.g., during drawing)
 * will collapse into a single write at the end of activity.
 */
export function scheduleSave(getState: () => PersistedState): void {
  if (saveTimer) clearTimeout(saveTimer);
  whenQuiet(
    SAVE_DEBOUNCE_MS,
    () => {
      saveTimer = null;
      saveState(getState());
    },
    (t) => {
      saveTimer = t;
    }
  );
}

/** Force an immediate save (e.g., before unload) */
export function flushSave(getState: () => PersistedState): void {
  if (saveTimer) {
    clearTimeout(saveTimer);
    saveTimer = null;
  }
  saveState(getState());
}

// ============================================================================
// Undo history persistence — a SEPARATE key, on purpose
// ============================================================================
//
// Undo used to die with the session: close the app and every step was gone.
// It is now remembered per notebook (last 100 undo steps) across restarts.
//
// The separation is the safety design, not an accident:
//  - the workspace save must never fail because history grew — a quota error
//    on the workspace key can lose boards, while a quota error here only
//    forgets old undo steps (oldest first);
//  - history entries are dropped, never migrated: a corrupt entry costs one
//    undo step, and anything structurally wrong is rejected at load.

const HISTORY_KEY = "z-whiteboard-history-v1";
/** Undo steps remembered per the feature request. */
export const HISTORY_PAST_MAX = 100;
export const HISTORY_FUTURE_MAX = 100;
/** History may never threaten the ~5 MB workspace budget. */
const HISTORY_MAX_BYTES = 1_500_000;

export interface SavedHistoryEntry {
  boardId: string;
  /** Document that was live when recorded; absent in older saves (= boardId). */
  activeAt?: string;
  pageId?: string;
  elements: WhiteboardElement[];
  pages?: NotebookPage[];
  /** Epoch ms; orders entries back into one list on load. */
  at?: number;
}

export interface SavedHistory {
  past: SavedHistoryEntry[];
  future: SavedHistoryEntry[];
}

/** A structurally valid entry whose elements cannot crash a restore. */
export function cleanHistoryEntry(e: unknown): SavedHistoryEntry | null {
  if (!e || typeof e !== "object") return null;
  const r = e as Record<string, unknown>;
  if (typeof r.boardId !== "string") return null;

  const hasElements = Array.isArray(r.elements);
  const hasPages = Array.isArray(r.pages);
  if (!hasElements && !hasPages) return null;

  const elements: WhiteboardElement[] = [];
  if (hasElements) {
    for (const el of r.elements as unknown[]) {
      if (
        !el ||
        typeof (el as { id?: unknown }).id !== "string" ||
        typeof (el as { type?: unknown }).type !== "string"
      ) {
        return null;
      }
      elements.push(el as WhiteboardElement);
    }
  }

  let pages: NotebookPage[] | undefined = undefined;
  if (hasPages) {
    const cleanedPages: NotebookPage[] = [];
    for (const p of r.pages as unknown[]) {
      if (
        !p ||
        typeof (p as { id?: unknown }).id !== "string" ||
        !Array.isArray((p as { elements?: unknown }).elements)
      ) {
        return null;
      }
      const pageElements: WhiteboardElement[] = [];
      for (const el of (p as { elements: unknown[] }).elements) {
        if (
          !el ||
          typeof (el as { id?: unknown }).id !== "string" ||
          typeof (el as { type?: unknown }).type !== "string"
        ) {
          return null;
        }
        pageElements.push(el as WhiteboardElement);
      }
      cleanedPages.push({
        ...(p as NotebookPage),
        elements: pageElements,
      });
    }
    pages = cleanedPages;
  }

  return {
    boardId: r.boardId,
    activeAt: typeof r.activeAt === "string" ? r.activeAt : undefined,
    pageId: typeof r.pageId === "string" ? r.pageId : undefined,
    elements,
    pages,
    at: typeof r.at === "number" ? r.at : 0,
  };
}

/**
 * Write history, oldest-first shrinking until it fits. Never throws into the
 * caller: the worst outcome is forgotten undo steps, never lost boards.
 */
export function saveHistory(history: SavedHistory): void {
  if (typeof window === "undefined") return;
  let past = history.past.slice(-HISTORY_PAST_MAX);
  let future = history.future.slice(-HISTORY_FUTURE_MAX);
  for (let i = 0; i < 6; i++) {
    let payload: string;
    try {
      payload = JSON.stringify({ version: 1, past, future });
    } catch {
      return; // unserializable — drop it all rather than half a history
    }
    if (payload.length <= HISTORY_MAX_BYTES) {
      try {
        window.localStorage.setItem(HISTORY_KEY, payload);
      } catch {
        // Nearly full (the workspace owns most of the quota): shrink and retry.
        past = past.slice(Math.ceil(past.length / 2));
        future = future.slice(Math.floor(future.length / 2));
        continue;
      }
      return;
    }
    if (past.length <= 1 && future.length === 0) return;
    past = past.slice(Math.ceil(past.length / 2));
    future = future.slice(Math.floor(future.length / 2));
  }
}

export function loadHistory(): SavedHistory | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(HISTORY_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as { past?: unknown; future?: unknown };
    const clean = (list: unknown): SavedHistoryEntry[] =>
      (Array.isArray(list) ? list : [])
        .map(cleanHistoryEntry)
        .filter((e): e is SavedHistoryEntry => e !== null);
    return { past: clean(parsed.past), future: clean(parsed.future) };
  } catch {
    return null;
  }
}

/**
 * What survives a restart: entries for boards that still exist, oldest first,
 * capped to what the session keeps. Pure, so it is unit-tested directly.
 */
export function restorableHistory(
  boardIds: string[],
  loaded: SavedHistory | null
): SavedHistory {
  if (!loaded) return { past: [], future: [] };
  const alive = new Set(boardIds);
  const byTime = (a: SavedHistoryEntry, b: SavedHistoryEntry) => (a.at ?? 0) - (b.at ?? 0);
  return {
    past: loaded.past
      .filter((e) => alive.has(e.boardId))
      .sort(byTime)
      .slice(-HISTORY_PAST_MAX),
    future: loaded.future
      .filter((e) => alive.has(e.boardId))
      .sort(byTime)
      .slice(-HISTORY_FUTURE_MAX),
  };
}

let historyTimer: ReturnType<typeof setTimeout> | null = null;
const HISTORY_DEBOUNCE_MS = 800;

/** Debounced history write after commit/undo/redo. */
export function scheduleHistorySave(getHistory: () => SavedHistory): void {
  if (historyTimer) clearTimeout(historyTimer);
  whenQuiet(
    HISTORY_DEBOUNCE_MS,
    () => {
      historyTimer = null;
      saveHistory(getHistory());
    },
    (t) => {
      historyTimer = t;
    }
  );
}

/** Force an immediate history write (e.g., before unload). */
export function flushHistorySave(getHistory: () => SavedHistory): void {
  if (historyTimer) {
    clearTimeout(historyTimer);
    historyTimer = null;
  }
  saveHistory(getHistory());
}
