/**
 * Where a newly inserted image goes, and how big it is.
 *
 * Before this, the toolbar placed an image at `camera.x/y` at up to 500 units
 * wide with no idea a page existed. In a notebook that meant an image could
 * land half off the sheet, straddling the gap between two pages, or partly
 * outside the part of the page you were looking at — "added to a random
 * place". GoodNotes and Notability both drop a new image in the middle of what
 * you can see, sized to fit comfortably, and never off the paper.
 *
 * So the rule here:
 *   1. The target region is what is VISIBLE — and in a notebook, the visible
 *      part of the active sheet (the sheet sits at the world origin).
 *   2. The image fits inside 60% of that region, keeps its aspect ratio, and
 *      is never scaled UP past its own pixels.
 *   3. It is centred on the point asked for (a paste at the pointer) or on the
 *      region, then pulled fully onto the sheet.
 */

import type { WhiteboardElement } from "./types";
import { getUnionBounds } from "./geometry";

export interface PlaceImageInput {
  naturalWidth: number;
  naturalHeight: number;
  camera: { x: number; y: number; zoom: number };
  viewport: { width: number; height: number };
  /** The active notebook sheet, at the world origin. Null for a canvas. */
  page?: { width: number; height: number } | null;
  /** Preferred centre in world units (e.g. where the pointer is). */
  at?: { x: number; y: number } | null;
}

export interface PlacedRect {
  x: number;
  y: number;
  width: number;
  height: number;
}

/** Fraction of the target region a new image may occupy at most. */
export const IMAGE_FIT_FRACTION = 0.6;
/** Smallest a new image is made, so a tiny icon is still grabbable. */
export const IMAGE_MIN_SIDE = 48;

export function placeImage(input: PlaceImageInput): PlacedRect {
  const { camera, viewport, page } = input;
  const natW = Math.max(1, input.naturalWidth || 1);
  const natH = Math.max(1, input.naturalHeight || 1);
  const zoom = camera.zoom > 0 ? camera.zoom : 1;

  // What the viewport shows, in world units.
  const halfW = viewport.width / 2 / zoom;
  const halfH = viewport.height / 2 / zoom;
  let region = {
    x: camera.x - halfW,
    y: camera.y - halfH,
    w: halfW * 2,
    h: halfH * 2,
  };

  if (page) {
    // Only the part of the sheet you can actually see.
    const x0 = Math.max(region.x, 0);
    const y0 = Math.max(region.y, 0);
    const x1 = Math.min(region.x + region.w, page.width);
    const y1 = Math.min(region.y + region.h, page.height);
    region =
      x1 - x0 > 1 && y1 - y0 > 1
        ? { x: x0, y: y0, w: x1 - x0, h: y1 - y0 }
        : { x: 0, y: 0, w: page.width, h: page.height }; // sheet off screen: use all of it
  }

  // Fit inside 60% of the region, never enlarge past the image's own pixels.
  const fit = Math.min(
    (region.w * IMAGE_FIT_FRACTION) / natW,
    (region.h * IMAGE_FIT_FRACTION) / natH,
    1
  );
  let width = natW * fit;
  let height = natH * fit;

  // A tiny image is enlarged to a grabbable minimum, aspect preserved, but
  // never past the page.
  const shortSide = Math.min(width, height);
  if (shortSide < IMAGE_MIN_SIDE) {
    const up = IMAGE_MIN_SIDE / shortSide;
    width *= up;
    height *= up;
  }
  if (page) {
    const cap = Math.min(page.width / width, page.height / height, 1);
    width *= cap;
    height *= cap;
  }

  const cx = input.at ? input.at.x : region.x + region.w / 2;
  const cy = input.at ? input.at.y : region.y + region.h / 2;
  let x = cx - width / 2;
  let y = cy - height / 2;

  if (page) {
    // Fully on the paper — translate, never shrink again.
    x = Math.min(Math.max(x, 0), page.width - width);
    y = Math.min(Math.max(y, 0), page.height - height);
  }

  return { x, y, width, height };
}

/**
 * Aspect-locked resize for a corner handle.
 *
 * A photo stretched by its corner looks broken, so images keep their
 * proportions: the larger of the two proposed scale factors wins, which makes
 * the corner track the pointer along whichever axis you moved most.
 */
export function lockAspect(
  origW: number,
  origH: number,
  proposedW: number,
  proposedH: number,
  minSide = 20
): { width: number; height: number } {
  const s = Math.max(proposedW / origW, proposedH / origH);
  const floor = minSide / Math.min(origW, origH);
  const scale = Math.max(s, floor);
  return { width: origW * scale, height: origH * scale };
}

/** Rotation snaps to the nearest right angle within this many radians (~4°). */
export const ROTATE_SNAP = (4 * Math.PI) / 180;

// ============================================================================
// Favorite pens bar: where it parks before you have dragged it.
// ============================================================================

/** Gap between the bar and the edge of the canvas pane. */
export const PENS_BAR_EDGE_GAP = 16;
/** Height guess used before first layout, when the bar cannot be measured. */
export const PENS_BAR_HEIGHT_ESTIMATE = 300;

export interface CanvasAreaRect {
  left: number;
  top: number;
  right: number;
  bottom: number;
}

/**
 * The bar's home: left edge of the canvas pane, vertically centred.
 *
 * One global spot shared by every board (canvases and notebooks alike) — the
 * position is a single persisted value, not per-board — and a saved drag
 * always wins over this. It only ever applies when there is no saved position
 * (a fresh workspace), so existing placements are left untouched.
 */
export function defaultPensBarPosition(
  area: CanvasAreaRect,
  barHeight: number
): { x: number; y: number } {
  const h =
    Number.isFinite(barHeight) && barHeight > 0 ? barHeight : PENS_BAR_HEIGHT_ESTIMATE;
  const areaH = area.bottom - area.top;
  const y = areaH > h + 16 ? area.top + (areaH - h) / 2 : area.top + 8;
  return { x: area.left + PENS_BAR_EDGE_GAP, y };
}
export function snapRotation(rad: number): number {
  const quarter = Math.PI / 2;
  const nearest = Math.round(rad / quarter) * quarter;
  const snapped = Math.abs(rad - nearest) <= ROTATE_SNAP ? nearest : rad;
  const twoPi = Math.PI * 2;
  return ((snapped % twoPi) + twoPi) % twoPi;
}

// ============================================================================
// Shape tools: what a tap (no drag) inserts.
// ============================================================================

/**
 * Default tap-inserted shape size, in world units — the same house style as
 * text (220x48) and sticky notes (200x160), which are also fixed world sizes.
 */
export const TAP_SHAPE_WIDTH = 160;
export const TAP_SHAPE_HEIGHT = 120;
/** A tapped line/arrow is this long, horizontal. */
export const TAP_LINE_LENGTH = 160;
/**
 * Drag smaller than this is a tap, not a shape: fingers always wobble a few
 * pixels on contact, and committing the wobble produced thin slivers nobody
 * asked for. Same ballpark as the long-press slop for the same reason.
 */
export const TAP_DRAG_SLOP_PX = 12;

export interface TapShapeRect {
  x: number;
  y: number;
  width: number;
  height: number;
}

/**
 * Where a tapped (not dragged) shape lands, and how big it is.
 *
 * A tap means "put one HERE": the shape is centred on the tap point, never
 * larger than the sheet (capped, then translated fully onto it — the same
 * translate-don't-reshape rule as clampBoxToSheet), and optionally snapped.
 * Before this, a tap created a 2x2 draft that pointer-up discarded, so every
 * shape on a tablet required a finger drag — and finger drags overshoot,
 * which is where the "shapes come out huge" reports came from.
 */
export function tapShapeRect(
  tapX: number,
  tapY: number,
  opts: {
    snap?: (v: number) => number;
    /** The active notebook sheet. Null for a canvas (nothing to stay inside). */
    page?: { width: number; height: number } | null;
  } = {}
): TapShapeRect {
  let width = TAP_SHAPE_WIDTH;
  let height = TAP_SHAPE_HEIGHT;
  if (opts.page && opts.page.width > 0 && opts.page.height > 0) {
    // A shape must never be born bigger than the page it lands on.
    const cap = Math.min(1, opts.page.width / width, opts.page.height / height);
    width *= cap;
    height *= cap;
  }
  let x = tapX - width / 2;
  let y = tapY - height / 2;
  if (opts.snap) {
    x = opts.snap(x);
    y = opts.snap(y);
  }
  if (opts.page && opts.page.width > 0 && opts.page.height > 0) {
    x = Math.min(Math.max(x, 0), Math.max(0, opts.page.width - width));
    y = Math.min(Math.max(y, 0), Math.max(0, opts.page.height - height));
  }
  return { x, y, width, height };
}

// ---------------------------------------------------------------------------
// Where a capture lands when it is added to a document
// ---------------------------------------------------------------------------

/**
 * On a fresh page: at the top, centred, at its own size - it is a clipping of
 * something you read, and blowing it up to fill the sheet would change what
 * it looks like. Only shrunk, never enlarged, to fit inside the margins.
 */
export function placeCaptureOnPage(
  page: { width: number; height: number },
  size: { width: number; height: number },
  margin = 48
): PlacedRect {
  const room = {
    width: Math.max(1, page.width - margin * 2),
    height: Math.max(1, page.height - margin * 2),
  };
  const fit = Math.min(1, room.width / Math.max(1, size.width), room.height / Math.max(1, size.height));
  const width = size.width * fit;
  const height = size.height * fit;
  return { x: (page.width - width) / 2, y: Math.min(margin, (page.height - height) / 2), width, height };
}

/**
 * On a whiteboard: to the right of everything already there, top-aligned
 * with it, so adding to a board you are not looking at never covers its
 * contents. An empty board gets it at the origin.
 */
export function placeCaptureBeside(
  elements: WhiteboardElement[],
  size: { width: number; height: number },
  gap = 80
): PlacedRect {
  const b = getUnionBounds(elements.filter((el) => el.type !== "connection"));
  if (!b) return { x: -size.width / 2, y: -size.height / 2, width: size.width, height: size.height };
  return { x: b.x + b.width + gap, y: b.y, width: size.width, height: size.height };
}
