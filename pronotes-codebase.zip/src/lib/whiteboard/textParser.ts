/**
 * Rich Markdown & Typography Tokenizer for ProNotes Whiteboard Cards & Stickies
 * ==============================================================================
 * Fast, robust, dependency-free parser for:
 * - Headings (#, ##, ###)
 * - Interactive checklists (- [ ], - [x])
 * - Bullet lists (- , * , + ) and numbered lists (1. , 2. )
 * - Blockquotes (> )
 * - Code blocks (```)
 * - Inline formatting: **bold**, *italic*, <u>underline</u>, ~~strikethrough~~, `code`, ==highlight==
 * - LaTeX math: $...$ and $$...$$
 * - Obsidian [[WikiLinks]] and #tags
 */

export interface InlineToken {
  type:
    | "text"
    | "bold"
    | "italic"
    | "underline"
    | "strike"
    | "code"
    | "highlight"
    | "math"
    | "link"
    | "tag"
    | "url";
  text: string;
  value?: string; // target for links / math formula
}

export interface BlockToken {
  type:
    | "h1"
    | "h2"
    | "h3"
    | "checklist"
    | "bullet"
    | "numbered"
    | "quote"
    | "codeblock"
    | "paragraph";
  lineIndex: number; // for interactive checklist toggles
  checked?: boolean; // for checklist
  number?: number; // for numbered list
  tokens: InlineToken[];
  rawText: string;
}

/**
 * Tokenize a single line's inline markdown: bold, italic, underline, strike, code, highlight, math, wikilinks, tags.
 */
export function tokenizeInline(text: string): InlineToken[] {
  if (!text) return [];

  const tokens: InlineToken[] = [];
  const remaining = text;

  // Pattern matching precedence
  // 1. Math: $$...$$ or $...$
  // 2. WikiLink: [[Target|Alias]] or [[Target]]
  // 3. Markdown Link: [label](url)
  // 4. Raw URL: https?://...
  // 5. Underline: <u>...</u>
  // 6. Bold: **...**
  // 7. Italic: *...*
  // 8. Strikethrough: ~~...~~
  // 9. Highlight: ==...==
  // 10. Code: `...`
  // 11. Tag: #tag
  //
  // Maths needs no space inside its $...$ and no digit after it, so prices
  // ("$5 and $10") stay text; italics need non-word characters around
  // them, so "2*3*4" stays text; a tag starts with a letter, so "#42" does
  // not become one.
  const inlineRegex =
    /(\$\$(.+?)\$\$|\$([^\s$](?:[^$\n]*?[^\s$])?)\$(?!\d)|\[\[([^\]|]+)(?:\|([^\]]+))?\]\]|\[([^\]]+)\]\(([^)]+)\)|https?:\/\/[^\s]+|<u>(.*?)<\/u>|\*\*(.*?)\*\*|(?<![\w*])\*(?![\s*])(.+?)(?<![\s*])\*(?![\w*])|~~(.*?)~~|==(.*?)==|`([^`]+)`|(?<![\w&/])#([a-zA-Z_\u0590-\u05FF\u0600-\u06FF][a-zA-Z0-9_\u0590-\u05FF\u0600-\u06FF-]*))/g;

  let lastIndex = 0;
  let match: RegExpExecArray | null;

  while ((match = inlineRegex.exec(remaining)) !== null) {
    if (match.index > lastIndex) {
      tokens.push({
        type: "text",
        text: remaining.slice(lastIndex, match.index),
      });
    }

    const fullMatch = match[0];

    if (fullMatch.startsWith("$$") && fullMatch.endsWith("$$")) {
      tokens.push({ type: "math", text: match[2], value: match[2] });
    } else if (fullMatch.startsWith("$") && fullMatch.endsWith("$") && fullMatch.length > 2) {
      tokens.push({ type: "math", text: match[3], value: match[3] });
    } else if (fullMatch.startsWith("[[")) {
      const target = match[4].trim();
      const alias = match[5]?.trim() || target;
      tokens.push({ type: "link", text: alias, value: target });
    } else if (match[6] && match[7]) {
      tokens.push({ type: "url", text: match[6], value: match[7] });
    } else if (fullMatch.startsWith("http://") || fullMatch.startsWith("https://")) {
      tokens.push({ type: "url", text: fullMatch, value: fullMatch });
    } else if (fullMatch.startsWith("<u>")) {
      tokens.push({ type: "underline", text: match[8] || "" });
    } else if (fullMatch.startsWith("**")) {
      tokens.push({ type: "bold", text: match[9] || "" });
    } else if (fullMatch.startsWith("*")) {
      tokens.push({ type: "italic", text: match[10] || "" });
    } else if (fullMatch.startsWith("~~")) {
      tokens.push({ type: "strike", text: match[11] || "" });
    } else if (fullMatch.startsWith("==")) {
      tokens.push({ type: "highlight", text: match[12] || "" });
    } else if (fullMatch.startsWith("`")) {
      tokens.push({ type: "code", text: match[13] || "" });
    } else if (fullMatch.startsWith("#")) {
      tokens.push({ type: "tag", text: fullMatch, value: match[14] });
    } else {
      tokens.push({ type: "text", text: fullMatch });
    }

    lastIndex = inlineRegex.lastIndex;
  }

  if (lastIndex < remaining.length) {
    tokens.push({
      type: "text",
      text: remaining.slice(lastIndex),
    });
  }

  return tokens;
}

/**
 * Parse full markdown text into blocks for rendering.
 */
export function parseMarkdownBlocks(text: string): BlockToken[] {
  if (!text) return [];

  const lines = text.split("\n");
  const blocks: BlockToken[] = [];
  let inCodeBlock = false;
  let codeBuffer: string[] = [];
  let codeStartLine = 0;

  for (let i = 0; i < lines.length; i++) {
    const rawLine = lines[i];
    const trimmed = rawLine.trim();

    // Code block toggle: ```
    if (trimmed.startsWith("```")) {
      if (inCodeBlock) {
        // End code block
        blocks.push({
          type: "codeblock",
          lineIndex: codeStartLine,
          rawText: codeBuffer.join("\n"),
          tokens: [{ type: "code", text: codeBuffer.join("\n") }],
        });
        codeBuffer = [];
        inCodeBlock = false;
      } else {
        // Start code block
        inCodeBlock = true;
        codeStartLine = i;
        codeBuffer = [];
      }
      continue;
    }

    if (inCodeBlock) {
      codeBuffer.push(rawLine);
      continue;
    }

    // Heading 1: #
    if (rawLine.startsWith("# ") || rawLine === "#") {
      const content = rawLine.replace(/^#\s*/, "");
      blocks.push({
        type: "h1",
        lineIndex: i,
        rawText: rawLine,
        tokens: tokenizeInline(content),
      });
      continue;
    }

    // Heading 2: ##
    if (rawLine.startsWith("## ") || rawLine === "##") {
      const content = rawLine.replace(/^##\s*/, "");
      blocks.push({
        type: "h2",
        lineIndex: i,
        rawText: rawLine,
        tokens: tokenizeInline(content),
      });
      continue;
    }

    // Heading 3: ###
    if (rawLine.startsWith("### ") || rawLine === "###") {
      const content = rawLine.replace(/^###\s*/, "");
      blocks.push({
        type: "h3",
        lineIndex: i,
        rawText: rawLine,
        tokens: tokenizeInline(content),
      });
      continue;
    }

    // Checklist: - [ ] or - [x]
    const checkMatch = rawLine.match(/^(\s*[-*]\s*\[([ xX])\]\s*)(.*)$/);
    if (checkMatch) {
      const isChecked = checkMatch[2].toLowerCase() === "x";
      const content = checkMatch[3];
      blocks.push({
        type: "checklist",
        lineIndex: i,
        checked: isChecked,
        rawText: rawLine,
        tokens: tokenizeInline(content),
      });
      continue;
    }

    // Bullet list: - or * or +
    const bulletMatch = rawLine.match(/^(\s*[-*+]\s+)(.*)$/);
    if (bulletMatch) {
      blocks.push({
        type: "bullet",
        lineIndex: i,
        rawText: rawLine,
        tokens: tokenizeInline(bulletMatch[2]),
      });
      continue;
    }

    // Numbered list: 1. or 2.
    const numMatch = rawLine.match(/^(\s*(\d+)\.\s+)(.*)$/);
    if (numMatch) {
      blocks.push({
        type: "numbered",
        lineIndex: i,
        number: parseInt(numMatch[2], 10),
        rawText: rawLine,
        tokens: tokenizeInline(numMatch[3]),
      });
      continue;
    }

    // Blockquote: >
    if (rawLine.startsWith("> ") || rawLine === ">") {
      const content = rawLine.replace(/^>\s*/, "");
      blocks.push({
        type: "quote",
        lineIndex: i,
        rawText: rawLine,
        tokens: tokenizeInline(content),
      });
      continue;
    }

    // Regular paragraph / line
    blocks.push({
      type: "paragraph",
      lineIndex: i,
      rawText: rawLine,
      tokens: tokenizeInline(rawLine),
    });
  }

  // Handle unclosed code block
  if (inCodeBlock && codeBuffer.length > 0) {
    blocks.push({
      type: "codeblock",
      lineIndex: codeStartLine,
      rawText: codeBuffer.join("\n"),
      tokens: [{ type: "code", text: codeBuffer.join("\n") }],
    });
  }

  return blocks;
}

export interface PlainLine {
  text: string;
  /** Font size relative to the element's (headings are larger). */
  scale: number;
  /** Font weight override (headings are bold). */
  weight?: number;
  /** Source line index, so exports can honour per-line direction. */
  lineIndex: number;
}

const HEADING_STYLE = {
  h1: { scale: 1.45, weight: 700 },
  h2: { scale: 1.25, weight: 600 },
  h3: { scale: 1.12, weight: 600 },
} as const;

/**
 * The text as the canvas SHOWS it, one entry per rendered line - for exports,
 * which draw plain SVG text. Without this a PDF showed the raw markup the
 * canvas hides: "- [ ] **Buy milk**" instead of "☐ Buy milk".
 */
export function markdownToPlainLines(text: string): PlainLine[] {
  const out: PlainLine[] = [];
  const plain = (b: BlockToken) => b.tokens.map((t) => t.text).join("");
  const indent = (b: BlockToken) => b.rawText.match(/^\s*/)?.[0] ?? "";
  for (const b of parseMarkdownBlocks(text)) {
    switch (b.type) {
      case "h1":
      case "h2":
      case "h3":
        out.push({ text: plain(b), ...HEADING_STYLE[b.type], lineIndex: b.lineIndex });
        break;
      case "checklist":
        out.push({ text: `${indent(b)}${b.checked ? "☑" : "☐"} ${plain(b)}`, scale: 1, lineIndex: b.lineIndex });
        break;
      case "bullet":
        out.push({ text: `${indent(b)}• ${plain(b)}`, scale: 1, lineIndex: b.lineIndex });
        break;
      case "numbered":
        out.push({ text: `${indent(b)}${b.number}. ${plain(b)}`, scale: 1, lineIndex: b.lineIndex });
        break;
      case "quote":
        out.push({ text: `│ ${plain(b)}`, scale: 1, lineIndex: b.lineIndex });
        break;
      case "codeblock":
        b.rawText.split("\n").forEach((line, k) => out.push({ text: line, scale: 1, lineIndex: b.lineIndex + k }));
        break;
      default:
        out.push({ text: plain(b), scale: 1, lineIndex: b.lineIndex });
    }
  }
  return out;
}

/**
 * Toggles a checklist item at a specific line index in full text.
 * Switches between `- [ ]` and `- [x]`.
 */
export function toggleChecklistAtLine(text: string, targetLineIndex: number): string {
  const lines = text.split("\n");
  if (targetLineIndex < 0 || targetLineIndex >= lines.length) return text;

  const line = lines[targetLineIndex];
  const uncheckedMatch = line.match(/^(\s*[-*]\s*\[\s\]\s*)(.*)$/);
  if (uncheckedMatch) {
    lines[targetLineIndex] = line.replace(/\[\s\]/, "[x]");
    return lines.join("\n");
  }

  const checkedMatch = line.match(/^(\s*[-*]\s*\[[xX]\]\s*)(.*)$/);
  if (checkedMatch) {
    lines[targetLineIndex] = line.replace(/\[[xX]\]/, "[ ]");
    return lines.join("\n");
  }

  return text;
}

/**
 * Intelligent list auto-continuation for the Enter key.
 * If user is on an empty list item (e.g. `- [ ] ` or `- `), returns shouldExit: true
 * so the editor clears the prefix and creates a regular newline.
 * Otherwise returns the appropriate prefix for the next line (incrementing numbers).
 */
export function getNextLinePrefix(currentLine: string): { prefix: string; shouldExit: boolean } {
  // Empty checklist: line is just whitespace + - [ ] or - [x]
  const emptyCheckMatch = currentLine.match(/^\s*[-*]\s*\[([ xX])\]\s*$/);
  if (emptyCheckMatch) {
    return { prefix: "", shouldExit: true };
  }

  // Checklist with content: copy prefix to next line
  const checkMatch = currentLine.match(/^(\s*[-*]\s*\[([ xX])\]\s*)/);
  if (checkMatch) {
    return { prefix: "- [ ] ", shouldExit: false };
  }

  // Empty bullet: line is just whitespace + - or * or +
  const emptyBulletMatch = currentLine.match(/^\s*[-*+]\s*$/);
  if (emptyBulletMatch) {
    return { prefix: "", shouldExit: true };
  }

  // Bullet with content: copy bullet prefix
  const bulletMatch = currentLine.match(/^(\s*[-*+]\s+)/);
  if (bulletMatch) {
    return { prefix: bulletMatch[1], shouldExit: false };
  }

  // Empty numbered: line is just whitespace + digits + .
  const emptyNumMatch = currentLine.match(/^\s*\d+\.\s*$/);
  if (emptyNumMatch) {
    return { prefix: "", shouldExit: true };
  }

  // Numbered list with content: increment number
  const numMatch = currentLine.match(/^(\s*)(\d+)\.\s+/);
  if (numMatch) {
    const nextNum = parseInt(numMatch[2], 10) + 1;
    return { prefix: `${numMatch[1]}${nextNum}. `, shouldExit: false };
  }

  // Blockquote with content: continue quote
  const quoteMatch = currentLine.match(/^(\s*>\s+)/);
  if (quoteMatch) {
    if (currentLine.trim() === ">") {
      return { prefix: "", shouldExit: true };
    }
    return { prefix: "> ", shouldExit: false };
  }

  return { prefix: "", shouldExit: false };
}

const BLOCK_PREFIX_RE = /^(\s*[-*]\s*\[[ xX]\]\s*|\s*[-*+]\s*|\s*\d+\.\s*|#+\s*|>\s*)/;

/** First strong directional character wins; digits/punctuation look deeper. */
const RTL_STRONG_RE = /[\u0590-\u08FF\uFB1D-\uFDFF\uFE70-\uFEFC]/;
const LTR_STRONG_RE = /[A-Za-z\u00C0-\u024F\u0370-\u03FF\u0400-\u04FF\u4E00-\u9FFF]/;

/**
 * Auto-detects a line's direction from its first strong character, the same
 * rule browsers apply for dir="auto": Hebrew/Arabic lead RTL, Latin/Cyrillic/
 * Greek/CJK lead LTR, and a line with no letters at all reads LTR.
 */
export function detectLineDir(line: string): "ltr" | "rtl" {
  for (const ch of line) {
    if (RTL_STRONG_RE.test(ch)) return "rtl";
    if (LTR_STRONG_RE.test(ch)) return "ltr";
  }
  return "ltr";
}

/**
 * The direction a line renders with: an explicit ltr/rtl override wins,
 * anything else (missing, "auto") leaves it to the browser via dir="auto".
 */
export function resolveLineDir(
  lineDirs: Array<string | undefined> | undefined,
  lineIndex: number
): "ltr" | "rtl" | "auto" {
  const d = lineDirs?.[lineIndex];
  return d === "ltr" || d === "rtl" ? d : "auto";
}

/** Which source lines a selection touches (shared by prefix and direction). */
export function selectedLineRange(
  text: string,
  start: number,
  end: number
): { first: number; last: number } {
  const lines = text.split("\n");
  const starts: number[] = [];
  let off = 0;
  for (const ln of lines) {
    starts.push(off);
    off += ln.length + 1;
  }
  const lineOf = (pos: number): number => {
    let li = 0;
    for (let k = 0; k < lines.length; k++) {
      if (starts[k] <= pos) li = k;
    }
    return li;
  };
  const first = lineOf(start);
  // A selection ending exactly at a line start does not claim that line.
  const lastPos = end > start && text[end - 1] === "\n" ? end - 1 : Math.min(end, text.length);
  return { first, last: Math.max(first, lineOf(lastPos)) };
}

/**
 * Sets the direction override for every selected line. "auto" clears back
 * to detection. Trailing autos are trimmed so the array never grows past
 * the lines it describes.
 */
export function setLineDirs(
  lineDirs: Array<"ltr" | "rtl" | "auto"> | undefined,
  text: string,
  start: number,
  end: number,
  dir: "ltr" | "rtl" | "auto"
): Array<"ltr" | "rtl" | "auto"> {
  const lineCount = text.split("\n").length;
  const { first, last } = selectedLineRange(text, start, end);
  const out: Array<"ltr" | "rtl" | "auto"> = [];
  for (let i = 0; i < lineCount; i++) {
    if (i >= first && i <= last) out.push(dir);
    else out.push(lineDirs?.[i] ?? "auto");
  }
  while (out.length > 0 && out[out.length - 1] === "auto") out.pop();
  return out;
}

/**
 * Applies a line prefix (lists, headings, quotes) to every line the
 * selection touches. A collapsed cursor keeps the old single-line toggle
 * exactly; a real selection prefixes each intersected line (a selection
 * ending right at a line start does not claim that line). Toggles off only
 * when EVERY touched line already carries the prefix.
 */
export function prefixSelectedLines(
  text: string,
  start: number,
  end: number,
  prefix: string
): { updated: string; cursor: number } {
  const lines = text.split("\n");
  const { first, last } = selectedLineRange(text, start, end);
  const allHave = lines.slice(first, last + 1).every((l) => l.startsWith(prefix));
  const out = lines.map((l, idx) => {
    if (idx < first || idx > last) return l;
    if (allHave) return l.startsWith(prefix) ? l.slice(prefix.length) : l;
    if (l.startsWith(prefix)) return l;
    return `${prefix}${l.replace(BLOCK_PREFIX_RE, "")}`;
  });
  let cursor = 0;
  for (let k = 0; k < last; k++) cursor += out[k].length + 1;
  return { updated: out.join("\n"), cursor: cursor + out[last].length };
}

/**
 * Wraps the selection in a marker pair (Bold, Italic, code, `$…$`, `[[…]]`).
 * With NO selection it inserts the empty pair and parks the cursor between
 * the markers, so typing starts inside immediately — no placeholder word to
 * delete first. A real selection wraps exactly as before.
 */
export function spliceFormatMarkers(
  text: string,
  start: number,
  end: number,
  prefix: string,
  suffix: string
): { updated: string; cursor: number } {
  if (start === end) {
    return { updated: text.slice(0, start) + prefix + suffix + text.slice(end), cursor: start + prefix.length };
  }
  const sel = text.slice(start, end);
  const replacement = `${prefix}${sel}${suffix}`;
  return {
    updated: text.slice(0, start) + replacement + text.slice(end),
    cursor: start + prefix.length + sel.length,
  };
}
