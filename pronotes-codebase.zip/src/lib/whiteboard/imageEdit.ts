/**
 * Image edits
 * ===========
 * Crop, flip, a look (filter) and a frame shape for pictures on the page.
 *
 * Every edit is a DESCRIPTION stored on the element, never new pixels: the
 * photo in IndexedDB stays exactly as it was taken. That keeps each edit
 * undoable, lets "Reset" bring back the whole photo months later, and costs
 * no extra storage however many times a picture is re-cropped.
 *
 * The canvas renderer and the exporter both draw from `imageLayout`, so a
 * picture looks the same on screen, in a PNG and in a PDF.
 */

import type { ImageCrop, ImageElement, ImageFilter, ImageFrame } from "./types";

export const FULL_CROP: ImageCrop = { x: 0, y: 0, w: 1, h: 1 };

/** The smallest crop, as a fraction of the picture: always something left to grab. */
export const MIN_CROP = 0.04;

export const IMAGE_FILTERS: Array<{ id: ImageFilter; label: string; hint: string; css: string }> = [
  { id: "none", label: "Original", hint: "As taken", css: "" },
  {
    id: "document",
    label: "Document",
    hint: "Whiter paper, darker ink — for photos of pages and boards",
    css: "grayscale(1) contrast(1.6) brightness(1.12)",
  },
  { id: "mono", label: "Gray", hint: "Black and white", css: "grayscale(1)" },
  { id: "vivid", label: "Vivid", hint: "Stronger colour", css: "saturate(1.45) contrast(1.08)" },
  {
    id: "faded",
    label: "Faded",
    hint: "Pale, so your writing stands out on top of it",
    css: "opacity(0.45) grayscale(0.3)",
  },
];

export const IMAGE_FRAMES: Array<{ id: ImageFrame; label: string }> = [
  { id: "square", label: "Square" },
  { id: "rounded", label: "Rounded" },
  { id: "circle", label: "Circle" },
];

export function filterCss(filter: ImageFilter | undefined): string {
  return IMAGE_FILTERS.find((f) => f.id === filter)?.css ?? "";
}

const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));

/** A crop that is always inside the picture and never smaller than MIN_CROP. */
export function normalizeCrop(c: ImageCrop | undefined): ImageCrop {
  if (!c || ![c.x, c.y, c.w, c.h].every(Number.isFinite)) return { ...FULL_CROP };
  const w = clamp(c.w, MIN_CROP, 1);
  const h = clamp(c.h, MIN_CROP, 1);
  return { x: clamp(c.x, 0, 1 - w), y: clamp(c.y, 0, 1 - h), w, h };
}

export function isFullCrop(c: ImageCrop | undefined): boolean {
  if (!c) return true;
  const n = normalizeCrop(c);
  return n.x < 1e-4 && n.y < 1e-4 && n.w > 1 - 1e-4 && n.h > 1 - 1e-4;
}

/**
 * Mirrors a crop with the picture. Crops are measured on the picture as you
 * SEE it, so flipping the picture must move the kept window with it, or a
 * flip would silently show a different part of the photo.
 */
export function flipCrop(c: ImageCrop, axis: "x" | "y"): ImageCrop {
  return axis === "x" ? { ...c, x: 1 - c.x - c.w } : { ...c, y: 1 - c.y - c.h };
}

/** Whether the picture is drawn exactly as a plain, unedited image. */
export function isUnedited(el: ImageElement): boolean {
  return (
    isFullCrop(el.crop) &&
    !el.flipX &&
    !el.flipY &&
    (!el.filter || el.filter === "none") &&
    (!el.frame || el.frame === "square") &&
    !(el.borderWidth && el.borderWidth > 0)
  );
}

/** The picture's own pixel size, with a fallback for old elements that lack it. */
export function naturalSize(el: ImageElement): { nw: number; nh: number } {
  const nw = el.naturalWidth > 0 ? el.naturalWidth : el.width || 1;
  const nh = el.naturalHeight > 0 ? el.naturalHeight : el.height || 1;
  return { nw, nh };
}

export interface ImageLayout {
  /** viewBox of the inner <svg>, in the picture's own pixels. */
  viewBox: { x: number; y: number; w: number; h: number };
  nw: number;
  nh: number;
  /** Transform for the <image> inside the viewBox (the flip). */
  flip: string;
  filter: string;
  frame: ImageFrame;
  /** Corner radius of the frame, in element units. */
  radius: number;
}

export function imageLayout(el: ImageElement): ImageLayout {
  const { nw, nh } = naturalSize(el);
  const c = normalizeCrop(el.crop);
  const sx = el.flipX ? -1 : 1;
  const sy = el.flipY ? -1 : 1;
  const flip =
    sx === 1 && sy === 1 ? "" : `translate(${sx === -1 ? nw : 0} ${sy === -1 ? nh : 0}) scale(${sx} ${sy})`;
  const frame = el.frame ?? "square";
  return {
    viewBox: { x: c.x * nw, y: c.y * nh, w: c.w * nw, h: c.h * nh },
    nw,
    nh,
    flip,
    filter: filterCss(el.filter),
    frame,
    radius: frame === "rounded" ? Math.min(el.width, el.height) * 0.08 : 0,
  };
}

/**
 * The element's new box after a crop, keeping the picture at the SAME scale
 * and centred where it was: cropping takes away, it never zooms.
 */
export function boxForCrop(
  el: ImageElement,
  next: ImageCrop
): { x: number; y: number; width: number; height: number } {
  const { nw, nh } = naturalSize(el);
  const prev = normalizeCrop(el.crop);
  const n = normalizeCrop(next);
  // Scale on screen per picture pixel. "meet" fits the crop inside the box,
  // so the smaller ratio is what is actually drawn.
  const scale = Math.min(el.width / (prev.w * nw), el.height / (prev.h * nh));
  const width = n.w * nw * scale;
  const height = n.h * nh * scale;
  const cx = el.x + el.width / 2;
  const cy = el.y + el.height / 2;
  return { x: cx - width / 2, y: cy - height / 2, width, height };
}

/** The next quarter turn, snapping a hand-rotated picture to the grid first. */
export function quarterTurn(rotation: number, dir: 1 | -1): number {
  const q = Math.PI / 2;
  const snapped = Math.round((rotation || 0) / q) * q;
  let next = snapped + dir * q;
  // Keep the stored angle in (-π, π] so it never grows without bound.
  while (next > Math.PI + 1e-9) next -= 2 * Math.PI;
  while (next <= -Math.PI + 1e-9) next += 2 * Math.PI;
  return Math.abs(next) < 1e-9 ? 0 : next;
}

/**
 * Moves or resizes a crop from one handle, in crop fractions.
 * `handle` is one of n/s/e/w/ne/nw/se/sw, or "move". `aspect` (w/h in
 * PICTURE pixels, i.e. already divided by nw/nh) holds a ratio when set.
 */
export type CropHandle = "move" | "n" | "s" | "e" | "w" | "ne" | "nw" | "se" | "sw";

export function dragCrop(
  start: ImageCrop,
  handle: CropHandle,
  dx: number,
  dy: number,
  aspect: number | null
): ImageCrop {
  if (handle === "move") {
    return {
      ...start,
      x: clamp(start.x + dx, 0, 1 - start.w),
      y: clamp(start.y + dy, 0, 1 - start.h),
    };
  }
  let x0 = start.x;
  let y0 = start.y;
  let x1 = start.x + start.w;
  let y1 = start.y + start.h;
  if (handle.includes("w")) x0 = clamp(x0 + dx, 0, x1 - MIN_CROP);
  if (handle.includes("e")) x1 = clamp(x1 + dx, x0 + MIN_CROP, 1);
  if (handle.includes("n")) y0 = clamp(y0 + dy, 0, y1 - MIN_CROP);
  if (handle.includes("s")) y1 = clamp(y1 + dy, y0 + MIN_CROP, 1);
  let out: ImageCrop = { x: x0, y: y0, w: x1 - x0, h: y1 - y0 };
  if (aspect && aspect > 0) out = fitAspect(out, aspect, handle);
  return out;
}

/**
 * Forces a crop to a ratio (in fractions: w/h where 1 means the picture's own
 * shape), shrinking the free side and anchoring the edge opposite the handle.
 */
export function fitAspect(c: ImageCrop, aspect: number, handle: CropHandle = "se"): ImageCrop {
  let w = c.w;
  let h = c.h;
  if (w / h > aspect) w = h * aspect;
  else h = w / aspect;
  // Too big for the picture: shrink both, keeping the ratio.
  if (w > 1) {
    w = 1;
    h = w / aspect;
  }
  if (h > 1) {
    h = 1;
    w = h * aspect;
  }
  const x = handle.includes("w") ? c.x + c.w - w : handle === "n" || handle === "s" ? c.x + (c.w - w) / 2 : c.x;
  const y = handle.includes("n") ? c.y + c.h - h : handle === "e" || handle === "w" ? c.y + (c.h - h) / 2 : c.y;
  return normalizeCrop({ x, y, w, h });
}

/** A centred crop of the given ratio (w/h in fractions), as large as fits. */
export function centeredAspectCrop(aspect: number): ImageCrop {
  const w = aspect >= 1 ? 1 : aspect;
  const h = aspect >= 1 ? 1 / aspect : 1;
  return normalizeCrop({ x: (1 - w) / 2, y: (1 - h) / 2, w, h });
}

const esc = (s: string) =>
  s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

/**
 * The picture as standalone SVG markup, placed at the element's position.
 * Used by export, so a file shows exactly what the canvas shows.
 */
export function imageSvgMarkup(el: ImageElement, href: string, extraAttrs = ""): string {
  const L = imageLayout(el);
  const vb = L.viewBox;
  const clipId = `imgclip-${el.id}`;
  const clipShape =
    L.frame === "circle"
      ? `<ellipse cx="${el.width / 2}" cy="${el.height / 2}" rx="${el.width / 2}" ry="${el.height / 2}" />`
      : `<rect x="0" y="0" width="${el.width}" height="${el.height}" rx="${L.radius}" />`;
  const style = L.filter ? ` style="filter:${L.filter}"` : "";
  const flip = L.flip ? ` transform="${L.flip}"` : "";
  const bw = el.borderWidth && el.borderWidth > 0 ? el.borderWidth : 0;
  const border = bw
    ? L.frame === "circle"
      ? `<ellipse cx="${el.width / 2}" cy="${el.height / 2}" rx="${el.width / 2}" ry="${el.height / 2}" fill="none" stroke="${esc(el.borderColor || "#18181b")}" stroke-width="${bw}" />`
      : `<rect x="0" y="0" width="${el.width}" height="${el.height}" rx="${L.radius}" fill="none" stroke="${esc(el.borderColor || "#18181b")}" stroke-width="${bw}" />`
    : "";
  return (
    `<g transform="translate(${el.x} ${el.y})" ${extraAttrs}>` +
    `<clipPath id="${clipId}">${clipShape}</clipPath>` +
    `<g clip-path="url(#${clipId})">` +
    `<svg x="0" y="0" width="${el.width}" height="${el.height}" viewBox="${vb.x} ${vb.y} ${vb.w} ${vb.h}" preserveAspectRatio="xMidYMid meet">` +
    `<image href="${esc(href)}" x="0" y="0" width="${L.nw}" height="${L.nh}" preserveAspectRatio="none"${flip}${style} />` +
    `</svg></g>${border}</g>`
  );
}
