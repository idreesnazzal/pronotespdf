/**
 * Word and PowerPoint files -> a PDF -> a notebook.
 * ==================================================
 * A .docx or .pptx is turned, ON THE DEVICE, into a PDF whose pages are the
 * document's pages (or slides), and that PDF then goes through the normal PDF
 * import. So an opened Word/PowerPoint file IS a PDF notebook afterwards:
 * export, share, split view, duplicate, delete/undo, page thumbnails and
 * "Open with" all work on it with no special cases anywhere else.
 *
 * Nothing is uploaded. Conversion needs no network.
 *
 * PowerPoint: slides are drawn with pptxviewjs (canvas). Two of its bugs are
 * worked around here, both measured on a real Hebrew lecture deck:
 *  - It has no right-to-left support: Hebrew/Arabic lines were laid out with
 *    a left-to-right base, so punctuation landed at the wrong end. Lines
 *    containing RTL letters are drawn with an RTL base (same position).
 *  - A text box holding an equation is stored twice (mc:AlternateContent): an
 *    Office-2010 version with the maths, and a fallback PICTURE of the box
 *    as PowerPoint drew it. The renderer cannot read the maths version and
 *    drew the whole box as a column one letter wide (7 of 25 slides of a real
 *    lecture deck). `preferFallbackContent` keeps the fallback - PowerPoint's own
 *    image of that box - so those slides look exactly as in PowerPoint.
 *  - Placeholders get their layout position written in and a slot of their
 *    own (`normalizeSlideXml`), so nothing depends on the renderer's
 *    inheritance rules.
 *
 * Word: docx-preview lays the document out as HTML - the browser's own text
 * engine, so Hebrew, Arabic and mixed text are right - but it does not break
 * pages by height, so `paginateSection` does, between paragraphs and table
 * rows, never through a line. Each page is then drawn to an image.
 *
 * Text: the pages become pictures, so their text is captured on the way - a
 * box per word from the laid-out page (Word), every text-drawing call on the
 * slide canvas (PowerPoint) - and handed to the import, which stores it beside
 * the PDF (pdfTextStore.ts). That is what makes these pages selectable and
 * searchable.
 */

import { mergeFragments, type PageText, type TextRun } from "./pdfText";
import { attachOfficeText } from "./pdfTextStore";

export type OfficeKind = "docx" | "pptx";

const DOCX_MIME = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
const PPTX_MIME = "application/vnd.openxmlformats-officedocument.presentationml.presentation";
const PPSX_MIME = "application/vnd.openxmlformats-officedocument.presentationml.slideshow";

/** docx / pptx, "legacy" for the pre-2007 binary formats, else null. */
export function officeKindOf(file: { name: string; type?: string }): OfficeKind | "legacy" | null {
  const name = file.name.toLowerCase();
  const type = (file.type || "").toLowerCase();
  if (type === DOCX_MIME || /\.(docx|docm|dotx)$/.test(name)) return "docx";
  if (type === PPTX_MIME || type === PPSX_MIME || /\.(pptx|pptm|ppsx|potx)$/.test(name)) return "pptx";
  if (type === "application/msword" || type === "application/vnd.ms-powerpoint" || /\.(doc|ppt|pps)$/.test(name)) {
    return "legacy";
  }
  return null;
}

export const LEGACY_OFFICE_MESSAGE =
  "This is an old Office format (.doc / .ppt). Open it in Word or PowerPoint and save it as .docx / .pptx, then open that.";

/** What the file-pickers accept: PDF plus Word and PowerPoint. */
export const DOCUMENT_ACCEPT = [
  "application/pdf",
  ".pdf",
  DOCX_MIME,
  ".docx",
  PPTX_MIME,
  PPSX_MIME,
  ".pptx",
  ".ppsx",
].join(",");

export interface ConvertProgress {
  /** Human-readable: "Reading slides…", "Slide 3 of 25"… */
  label: string;
  done: number;
  total: number;
}

// ---------------------------------------------------------------------------
// PowerPoint XML clean-up (pure: unit-tested)
// ---------------------------------------------------------------------------

const RTL_CHARS = /[֐-ࣿיִ-﷿ﹰ-﻿]/;

/** True when a string contains Hebrew/Arabic/Syriac/Thaana letters. */
export function hasRtl(text: string): boolean {
  return RTL_CHARS.test(text);
}

interface PlaceholderGeom {
  idx: string | null;
  type: string | null;
  xfrm: string;
}

function attr(tag: string, name: string): string | null {
  const m = new RegExp(`\\s${name}="([^"]*)"`).exec(tag);
  return m ? m[1] : null;
}

/** Placeholders (idx, type, <a:xfrm>) defined on a layout or master. */
export function placeholderGeometry(xml: string): PlaceholderGeom[] {
  const out: PlaceholderGeom[] = [];
  for (const sp of xml.match(/<p:sp>[\s\S]*?<\/p:sp>/g) ?? []) {
    const ph = /<p:ph\b[^>]*>/.exec(sp)?.[0];
    const xfrm = /<a:xfrm\b[\s\S]*?<\/a:xfrm>/.exec(sp)?.[0];
    if (!ph || !xfrm) continue;
    out.push({ idx: attr(ph, "idx"), type: attr(ph, "type"), xfrm });
  }
  return out;
}

/** A placeholder with no type is a body placeholder (ECMA-376 19.3.1.36). */
const phType = (t: string | null) => t ?? "body";
const sameKind = (a: string, b: string) =>
  a === b || (a === "ctrTitle" && b === "title") || (a === "title" && b === "ctrTitle") || (a === "subTitle" && b === "body");

function findGeometry(
  idx: string | null,
  type: string | null,
  layout: PlaceholderGeom[],
  master: PlaceholderGeom[]
): string | null {
  const t = phType(type);
  if (idx !== null) {
    const byIdx = layout.find((g) => g.idx === idx);
    if (byIdx) return byIdx.xfrm;
  }
  const byType = layout.find((g) => sameKind(phType(g.type), t)) ?? master.find((g) => sameKind(phType(g.type), t));
  return byType?.xfrm ?? null;
}

/** The visible text of a shape (all <a:t> runs). */
function shapeText(sp: string): string {
  return (sp.match(/<a:t>([^<]*)<\/a:t>/g) ?? []).map((t) => t.slice(5, -6)).join("");
}

/**
 * A text-less shape filled with a picture, rewritten as `<p:pic>` at the same
 * place with the same crop. Null when the shape is anything else, or has no
 * position to put the picture at.
 */
export function pictureFromFilledBox(sp: string): string | null {
  const spPr = /<p:spPr\b[^>]*>([\s\S]*?)<\/p:spPr>/.exec(sp)?.[1];
  if (!spPr) return null;
  const blipFill = /<a:blipFill\b[^>]*>[\s\S]*?<\/a:blipFill>/.exec(spPr)?.[0];
  const xfrm = /<a:xfrm\b[\s\S]*?<\/a:xfrm>/.exec(spPr)?.[0];
  if (!blipFill || !xfrm || shapeText(sp).trim() !== "") return null;
  const cNvPr = /<p:cNvPr\b[^>]*?(\/>|>[\s\S]*?<\/p:cNvPr>)/.exec(sp)?.[0] ?? '<p:cNvPr id="0" name="Picture"/>';
  const inner = blipFill.replace(/^<a:blipFill\b[^>]*>/, "").replace(/<\/a:blipFill>$/, "");
  return (
    `<p:pic><p:nvPicPr>${cNvPr}<p:cNvPicPr/><p:nvPr/></p:nvPicPr>` +
    `<p:blipFill>${inner}</p:blipFill>` +
    `<p:spPr>${xfrm}<a:prstGeom prst="rect"><a:avLst/></a:prstGeom></p:spPr></p:pic>`
  );
}

/**
 * Gives every placeholder on a slide an explicit position and a slot of its
 * own. A placeholder without `<a:xfrm>` gets its layout's (or master's), and a
 * second shape claiming an already-used `idx` is moved to a free idx - the
 * renderer mixed up the geometry of shapes sharing one.
 */
export function normalizeSlideXml(slideXml: string, layoutXml: string, masterXml = ""): string {
  const layout = placeholderGeometry(layoutXml);
  const master = placeholderGeometry(masterXml);
  const seen = new Set<string>();
  let spare = 9000;
  return slideXml.replace(/<p:sp>[\s\S]*?<\/p:sp>/g, (sp) => {
    const phTag = /<p:ph\b[^>]*>/.exec(sp)?.[0];
    if (!phTag) return sp;
    const idx = attr(phTag, "idx");
    const type = attr(phTag, "type");
    let out = sp;
    const spPr = /<p:spPr\b[^>]*?(\/>|>)([\s\S]*?<\/p:spPr>)?/.exec(out);
    const hasXfrm = spPr ? /<a:xfrm\b/.test(spPr[0]) : false;
    if (!hasXfrm) {
      const xfrm = findGeometry(idx, type, layout, master);
      if (xfrm) {
        if (spPr && spPr[1] === "/>") {
          out = out.replace(spPr[0], spPr[0].replace(/\/>$/, `>${xfrm}</p:spPr>`));
        } else if (spPr) {
          out = out.replace(spPr[0], spPr[0].replace(/^(<p:spPr\b[^>]*>)/, `$1${xfrm}`));
        }
      }
    }
    // A box whose only content is a picture fill (PowerPoint's fallback image
    // of an equation box) becomes a real picture: the renderer draws
    // pictures, but not pictures used as a box's fill.
    const asPicture = pictureFromFilledBox(out);
    if (asPicture) return asPicture;

    const key = idx ?? `type:${phType(type)}`;
    if (idx !== null && seen.has(key)) {
      // Already positioned above; a unique idx stops it borrowing the
      // layout slot another shape on this slide owns.
      let free = String(spare++);
      while (seen.has(free)) free = String(spare++);
      out = out.replace(phTag, phTag.replace(/\sidx="[^"]*"/, ` idx="${free}"`));
      seen.add(free);
    }
    seen.add(key);
    return out;
  });
}

/**
 * Replaces every `mc:AlternateContent` with its `mc:Fallback` (or, with no
 * fallback, its first `mc:Choice`). For equations the fallback is
 * PowerPoint's own picture of the text box - exact - where the renderer drew
 * the maths version as a broken one-letter column.
 */
export function preferFallbackContent(xml: string): string {
  if (!xml.includes("mc:AlternateContent")) return xml;
  return xml.replace(/<mc:AlternateContent\b[^>]*>([\s\S]*?)<\/mc:AlternateContent>/g, (_all, inner: string) => {
    const fallback = /<mc:Fallback\b[^>]*>([\s\S]*?)<\/mc:Fallback>/.exec(inner);
    if (fallback) return fallback[1];
    const choice = /<mc:Choice\b[^>]*>([\s\S]*?)<\/mc:Choice>/.exec(inner);
    return choice ? choice[1] : "";
  });
}

/** Resolves a relationship target ("../slideLayouts/x.xml") against a part. */
function resolveTarget(fromPart: string, target: string): string {
  const base = fromPart.split("/").slice(0, -1);
  for (const seg of target.split("/")) {
    if (seg === "..") base.pop();
    else if (seg !== ".") base.push(seg);
  }
  return base.join("/");
}

async function normalizePptx(bytes: ArrayBuffer): Promise<ArrayBuffer> {
  const { default: JSZip } = await import("jszip");
  const zip = await JSZip.loadAsync(bytes);
  const read = async (p: string) => (zip.file(p) ? await zip.file(p)!.async("string") : "");
  const slides = Object.keys(zip.files).filter((p) => /^ppt\/slides\/slide\d+\.xml$/.test(p));
  for (const slide of slides) {
    const rels = await read(slide.replace(/slides\/(slide\d+\.xml)$/, "slides/_rels/$1.rels"));
    const layoutTarget = /Target="([^"]*slideLayout[^"]*)"/.exec(rels)?.[1];
    if (!layoutTarget) continue;
    const layoutPath = resolveTarget(slide, layoutTarget);
    const layoutRels = await read(layoutPath.replace(/slideLayouts\/(slideLayout\d+\.xml)$/, "slideLayouts/_rels/$1.rels"));
    const masterTarget = /Target="([^"]*slideMaster[^"]*)"/.exec(layoutRels)?.[1];
    const masterXml = masterTarget ? await read(resolveTarget(layoutPath, masterTarget)) : "";
    const xml = await read(slide);
    const fixed = normalizeSlideXml(preferFallbackContent(xml), preferFallbackContent(await read(layoutPath)), masterXml);
    if (fixed !== xml) zip.file(slide, fixed);
  }
  return zip.generateAsync({ type: "arraybuffer" });
}

// ---------------------------------------------------------------------------
// Drawing surfaces
// ---------------------------------------------------------------------------

/** An off-screen host: laid out (so text measures right) but never visible. */
function offscreenHost(): HTMLDivElement {
  const host = document.createElement("div");
  host.setAttribute("aria-hidden", "true");
  host.style.cssText =
    "position:fixed;left:-100000px;top:0;pointer-events:none;background:#fff;color:#000;z-index:-1;";
  document.body.appendChild(host);
  return host;
}

/** Lines with Hebrew/Arabic letters are drawn with an RTL base, same anchor. */
function patchRtlText(ctx: CanvasRenderingContext2D) {
  for (const fn of ["fillText", "strokeText"] as const) {
    const orig = ctx[fn].bind(ctx);
    ctx[fn] = ((text: string, x: number, y: number, maxWidth?: number) => {
      if (typeof text === "string" && hasRtl(text)) {
        const dir = ctx.direction;
        const align = ctx.textAlign;
        ctx.direction = "rtl";
        // The renderer measured with a left-to-right base: keep its anchor.
        ctx.textAlign = align === "start" ? "left" : align === "end" ? "right" : align;
        try {
          return maxWidth === undefined ? orig(text, x, y) : orig(text, x, y, maxWidth);
        } finally {
          ctx.direction = dir;
          ctx.textAlign = align;
        }
      }
      return maxWidth === undefined ? orig(text, x, y) : orig(text, x, y, maxWidth);
    }) as typeof ctx.fillText;
  }
}

interface RasterPage {
  /** JPEG data URL. */
  image: string;
  /** Page size in PDF points (1/72 in). */
  widthPt: number;
  heightPt: number;
  /** The page's text, captured while it was drawn. */
  text?: PageText;
}

const EMU_PER_PT = 12700;
/** Long side of a rendered slide, in pixels: sharp on a tablet at zoom. */
const SLIDE_PX = 1920;

/**
 * Loads pptxviewjs WITHOUT letting it damage the page. On load it assigns its
 * own classes over browser globals - `window.FileReader` among them - and after
 * one PowerPoint import every later file read in the app (PDFs, pictures)
 * failed with "readAsArrayBuffer is not a function". Whatever it overwrites is
 * put back; names it only adds are left alone (it may use them itself).
 */
let pptxModule: Promise<typeof import("pptxviewjs")> | null = null;
export function loadPptxViewer(): Promise<typeof import("pptxviewjs")> {
  if (!pptxModule) {
    const w = window as unknown as Record<string, unknown>;
    const before = new Map<string, unknown>();
    for (const key of Object.getOwnPropertyNames(window)) {
      try {
        before.set(key, w[key]);
      } catch {
        /* some window properties throw on read; they cannot be overwritten either */
      }
    }
    pptxModule = import("pptxviewjs").then((mod) => {
      restoreGlobals(w, before);
      return mod;
    });
  }
  return pptxModule;
}

/** Puts back every global that `before` knew and that has since changed. */
export function restoreGlobals(target: Record<string, unknown>, before: Map<string, unknown>): string[] {
  const restored: string[] = [];
  for (const [key, value] of before) {
    let now: unknown;
    try {
      now = target[key];
    } catch {
      continue;
    }
    if (now !== value) {
      try {
        target[key] = value;
        restored.push(key);
      } catch {
        /* read-only: it could not have been replaced either */
      }
    }
  }
  return restored;
}

type PageSink = (page: RasterPage) => void;

/**
 * Records the text drawn on a slide canvas: every fillText call, with where it
 * really landed (the canvas transform, alignment and font metrics applied), in
 * fractions of the canvas. Installed OVER the RTL patch, so it sees the
 * renderer's own alignment - which the patch keeps - and the logical string.
 */
function recordCanvasText(ctx: CanvasRenderingContext2D, canvas: HTMLCanvasElement) {
  let frags: TextRun[] | null = null;
  const orig = ctx.fillText.bind(ctx);
  const note = (out: TextRun[], text: string, x: number, y: number, maxWidth?: number) => {
    const m = ctx.measureText(text);
    const w = maxWidth !== undefined ? Math.min(m.width, maxWidth) : m.width;
    if (!(w > 0)) return;
    const rtl = ctx.direction === "rtl";
    const align = ctx.textAlign;
    const left =
      align === "right" || (align === "end" && !rtl) || (align === "start" && rtl)
        ? x - w
        : align === "center"
          ? x - w / 2
          : x;
    const size = parseFloat(/(\d+(?:\.\d+)?)px/.exec(ctx.font)?.[1] ?? "") || 16;
    const ascent = m.fontBoundingBoxAscent || m.actualBoundingBoxAscent || size * 0.8;
    const descent = m.fontBoundingBoxDescent || m.actualBoundingBoxDescent || size * 0.2;
    const t = ctx.getTransform();
    const pts = [
      [left, y - ascent],
      [left + w, y - ascent],
      [left, y + descent],
      [left + w, y + descent],
    ].map(([px, py]) => [t.a * px + t.c * py + t.e, t.b * px + t.d * py + t.f]);
    const xs = pts.map((p) => p[0]);
    const ys = pts.map((p) => p[1]);
    const x0 = Math.max(0, Math.min(...xs));
    const x1 = Math.min(canvas.width, Math.max(...xs));
    const y0 = Math.max(0, Math.min(...ys));
    const y1 = Math.min(canvas.height, Math.max(...ys));
    if (x1 <= x0 || y1 <= y0) return;
    out.push({
      t: text,
      x: x0 / canvas.width,
      y: y0 / canvas.height,
      w: (x1 - x0) / canvas.width,
      h: (y1 - y0) / canvas.height,
    });
  };
  ctx.fillText = ((text: string, x: number, y: number, maxWidth?: number) => {
    if (frags && typeof text === "string" && text.trim()) {
      try {
        note(frags, text, x, y, maxWidth);
      } catch {
        /* recording must never break drawing */
      }
    }
    return maxWidth === undefined ? orig(text, x, y) : orig(text, x, y, maxWidth);
  }) as typeof ctx.fillText;
  return {
    start() {
      frags = [];
    },
    stop(): TextRun[] {
      const out = frags ?? [];
      frags = null;
      return out;
    },
  };
}

async function rasterizePptx(bytes: ArrayBuffer, sink: PageSink, onProgress?: (p: ConvertProgress) => void): Promise<number> {
  onProgress?.({ label: "Reading slides…", done: 0, total: 1 });
  const fixed = await normalizePptx(bytes);
  const { PPTXViewer } = await loadPptxViewer();
  const host = offscreenHost();
  const canvas = document.createElement("canvas");
  host.appendChild(canvas); // the renderer refuses a detached canvas
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("This device cannot draw the slides.");
  patchRtlText(ctx);
  const recorder = recordCanvasText(ctx, canvas);
  try {
    const viewer = new PPTXViewer({ canvas });
    await viewer.loadFile(fixed);
    const count = viewer.getSlideCount();
    if (!count) throw new Error("This presentation has no slides.");
    const proc = (viewer as unknown as { processor?: { getSlideDimensions?: () => { cx: number; cy: number } } }).processor;
    const dims = proc?.getSlideDimensions?.() ?? { cx: 12192000, cy: 6858000 };
    const cx = dims.cx > 0 ? dims.cx : 12192000;
    const cy = dims.cy > 0 ? dims.cy : 6858000;
    const scale = SLIDE_PX / Math.max(cx, cy);
    canvas.width = Math.round(cx * scale);
    canvas.height = Math.round(cy * scale);
    for (let i = 0; i < count; i++) {
      onProgress?.({ label: `Slide ${i + 1} of ${count}`, done: i, total: count });
      ctx.save();
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.restore();
      recorder.start();
      await viewer.render(canvas, { slideIndex: i });
      const runs = mergeFragments(recorder.stop(), canvas.width / canvas.height);
      const widthPt = cx / EMU_PER_PT;
      const heightPt = cy / EMU_PER_PT;
      sink({ image: canvas.toDataURL("image/jpeg", 0.9), widthPt, heightPt, text: { w: widthPt, h: heightPt, runs, ordered: true } });
      // Let the page breathe between slides: a long deck must not freeze it.
      await new Promise((r) => setTimeout(r, 0));
    }
    return count;
  } finally {
    host.remove();
  }
}

// ---------------------------------------------------------------------------
// Word
// ---------------------------------------------------------------------------

/**
 * Splits one docx-preview section (which grows as tall as its content) into
 * page-sized sections. Whole paragraphs move to the next page; a table too tall
 * for a page is split between rows; a single block taller than a page keeps a
 * page to itself (and is clipped there) rather than looping.
 */
export function paginateSection(section: HTMLElement): HTMLElement[] {
  const article = section.querySelector(":scope > article") as HTMLElement | null;
  const pageH = parseFloat(section.style.minHeight) || 0;
  if (!article || !pageH) return [section];
  // docx-preview sizes pages as content-box: min-height is the height INSIDE
  // the margins. Fixing the height and comparing scroll to client height
  // measures overflow correctly whatever the box model.
  section.style.height = `${pageH}px`;
  section.style.overflow = "hidden";
  if (section.scrollHeight <= section.clientHeight + 1) return [section];
  const header = section.querySelector(":scope > header");
  const footer = section.querySelector(":scope > footer");
  const blocks = Array.from(article.children) as HTMLElement[];
  const pages: HTMLElement[] = [];

  const newPage = () => {
    const page = section.cloneNode(false) as HTMLElement;
    page.style.height = `${pageH}px`;
    page.style.overflow = "hidden";
    if (header) page.appendChild(header.cloneNode(true));
    const art = article.cloneNode(false) as HTMLElement;
    page.appendChild(art);
    if (footer) page.appendChild(footer.cloneNode(true));
    section.parentElement?.insertBefore(page, section);
    pages.push(page);
    return { page, art };
  };
  const overflows = (page: HTMLElement) => page.scrollHeight > page.clientHeight + 1;

  let cur = newPage();
  for (const block of blocks) {
    cur.art.appendChild(block);
    if (!overflows(cur.page)) continue;
    const alone = cur.art.children.length === 1;
    if (block.tagName === "TABLE" && block.querySelector("tr")) {
      // Keep the rows that fit here; carry the rest in a copy of the table.
      const rows = Array.from(block.querySelectorAll(":scope > tbody > tr, :scope > tr")) as HTMLElement[];
      let rest: HTMLElement[] = [];
      for (let i = rows.length - 1; i > 0 && overflows(cur.page); i--) {
        rest.unshift(rows[i]);
        rows[i].remove();
      }
      while (rest.length) {
        cur = newPage();
        const copy = block.cloneNode(false) as HTMLElement;
        const body = document.createElement("tbody");
        copy.appendChild(body);
        cur.art.appendChild(copy);
        const moved: HTMLElement[] = [];
        for (const r of rest) {
          body.appendChild(r);
          moved.push(r);
          if (overflows(cur.page) && moved.length > 1) {
            r.remove();
            moved.pop();
            break;
          }
        }
        rest = rest.slice(moved.length);
      }
      continue;
    }
    if (alone) {
      // Taller than a page on its own: it keeps this page, clipped.
      cur = newPage();
      continue;
    }
    block.remove();
    cur = newPage();
    cur.art.appendChild(block);
    if (overflows(cur.page)) cur = newPage();
  }
  // A trailing empty page (from the last "alone" block) is dropped.
  const last = pages[pages.length - 1];
  if (pages.length > 1 && last && last.querySelector("article")?.children.length === 0) {
    last.remove();
    pages.pop();
  }
  section.remove();
  return pages;
}

/** Draws one page element: the browser's own renderer first, a fallback second. */
async function drawElement(el: HTMLElement, scale: number): Promise<string> {
  const w = el.offsetWidth;
  const h = el.offsetHeight;
  try {
    const { toCanvas } = await import("html-to-image");
    const canvas = await Promise.race([
      toCanvas(el, { pixelRatio: scale, backgroundColor: "#ffffff", width: w, height: h, cacheBust: false }),
      new Promise<never>((_, reject) => setTimeout(() => reject(new Error("timeout")), 6000)),
    ]);
    return canvas.toDataURL("image/jpeg", 0.9);
  } catch {
    // html-to-image draws through an SVG image; a WebView that stalls on it
    // gets html2canvas, which re-lays the text itself (slightly less exact
    // for mixed-direction lines, but never blank).
    const { default: html2canvas } = await import("html2canvas");
    const canvas = await html2canvas(el, {
      scale,
      backgroundColor: "#ffffff",
      logging: false,
      width: w,
      height: h,
      // The page only needs the document's own styles. The app's stylesheet
      // uses oklch() colours, which html2canvas cannot parse - it threw on
      // the very first page. Strip every stylesheet but the document's.
      onclone: (doc) => {
        doc.querySelectorAll("style, link[rel=stylesheet]").forEach((node) => {
          if (!(node as Element).closest("[data-office-styles]")) node.remove();
        });
      },
    });
    return canvas.toDataURL("image/jpeg", 0.9);
  }
}

const PX_TO_PT = 0.75;

/**
 * The words of a laid-out page with their boxes, in document (reading) order,
 * as fractions of the page. A word the page clips away (the overflow of a
 * block taller than a page) is left out, as it is from the picture.
 */
export function captureDomText(page: HTMLElement): PageText {
  const box = page.getBoundingClientRect();
  const W = box.width || page.offsetWidth || 1;
  const H = box.height || page.offsetHeight || 1;
  const runs: TextRun[] = [];
  const range = document.createRange();
  const walker = document.createTreeWalker(page, NodeFilter.SHOW_TEXT);
  for (let node = walker.nextNode() as Text | null; node; node = walker.nextNode() as Text | null) {
    const parent = node.parentElement;
    if (!parent || parent.closest("style, script")) continue;
    for (const m of node.data.matchAll(/\S+/g)) {
      const at = m.index ?? 0;
      range.setStart(node, at);
      range.setEnd(node, at + m[0].length);
      const rects = Array.from(range.getClientRects()).filter((r) => r.width > 0 && r.height > 0);
      if (!rects.length) continue;
      // A word broken over two lines (a long URL) is shared out by width.
      const total = rects.reduce((n, r) => n + r.width, 0);
      let used = 0;
      rects.forEach((r, k) => {
        const take = k === rects.length - 1 ? m[0].length - used : Math.round((m[0].length * r.width) / total);
        const t = m[0].slice(used, used + take);
        used += take;
        const x = r.left - box.left;
        const y = r.top - box.top;
        if (!t || y >= H || y + r.height <= 0 || x >= W || x + r.width <= 0) return;
        runs.push({ t, x: x / W, y: y / H, w: r.width / W, h: r.height / H });
      });
    }
  }
  return { w: W * PX_TO_PT, h: H * PX_TO_PT, runs, ordered: true };
}

async function rasterizeDocx(bytes: ArrayBuffer, sink: PageSink, onProgress?: (p: ConvertProgress) => void): Promise<number> {
  onProgress?.({ label: "Reading document…", done: 0, total: 1 });
  const { renderAsync } = await import("docx-preview");
  const host = offscreenHost();
  const styles = document.createElement("div");
  styles.setAttribute("data-office-styles", "");
  const body = document.createElement("div");
  host.append(styles, body);
  try {
    await renderAsync(bytes, body, styles, {
      inWrapper: false,
      breakPages: true,
      ignoreLastRenderedPageBreak: false,
      experimental: true,
      renderHeaders: true,
      renderFooters: true,
      renderFootnotes: true,
      renderEndnotes: true,
      useBase64URL: true,
    });
    // Fonts must be ready before anything is measured or drawn.
    await (document as Document & { fonts?: FontFaceSet }).fonts?.ready;
    const sections = Array.from(body.querySelectorAll("section.docx")) as HTMLElement[];
    const pages = sections.flatMap((s) => paginateSection(s));
    if (!pages.length) throw new Error("This document has no pages.");
    for (let i = 0; i < pages.length; i++) {
      onProgress?.({ label: `Page ${i + 1} of ${pages.length}`, done: i, total: pages.length });
      const page = pages[i];
      let text: PageText | undefined;
      try {
        text = captureDomText(page);
      } catch {
        /* a page without its text is still a page */
      }
      const image = await drawElement(page, 2);
      sink({ image, widthPt: page.offsetWidth * PX_TO_PT, heightPt: page.offsetHeight * PX_TO_PT, text });
      await new Promise((r) => setTimeout(r, 0));
    }
    return pages.length;
  } finally {
    host.remove();
  }
}

// ---------------------------------------------------------------------------
// The one entry point
// ---------------------------------------------------------------------------

/** A PDF built one page at a time; each page image can be dropped once added. */
async function pdfBuilder() {
  const { jsPDF } = await import("jspdf");
  let pdf: InstanceType<typeof jsPDF> | null = null;
  return {
    add(p: RasterPage) {
      const orientation = p.widthPt > p.heightPt ? "landscape" : "portrait";
      if (!pdf) {
        pdf = new jsPDF({ unit: "pt", format: [p.widthPt, p.heightPt], orientation, compress: true });
      } else {
        pdf.addPage([p.widthPt, p.heightPt], orientation);
      }
      pdf.addImage(p.image, "JPEG", 0, 0, p.widthPt, p.heightPt, undefined, "FAST");
    },
    blob(): Blob {
      if (!pdf) throw new Error("The document has no pages.");
      return pdf.output("blob");
    },
  };
}

/**
 * Converts a .docx or .pptx into a PDF File named after the original (so the
 * notebook it becomes is called "Lecture 3", not "Lecture 3.pdf").
 */
export async function convertOfficeToPdf(file: File, onProgress?: (p: ConvertProgress) => void): Promise<File> {
  const kind = officeKindOf(file);
  if (kind === "legacy") throw new Error(LEGACY_OFFICE_MESSAGE);
  if (!kind) throw new Error(`"${file.name}" is not a Word or PowerPoint file.`);
  const bytes = await file.arrayBuffer();
  const builder = await pdfBuilder();
  const texts: PageText[] = [];
  const sink: PageSink = (page) => {
    builder.add(page);
    texts.push(page.text ?? { w: page.widthPt, h: page.heightPt, runs: [] });
  };
  let pageCount: number;
  try {
    pageCount = kind === "pptx" ? await rasterizePptx(bytes, sink, onProgress) : await rasterizeDocx(bytes, sink, onProgress);
  } catch (err) {
    const msg = (err as Error)?.message || String(err);
    throw new Error(
      /corrupt|zip|end of central directory|signature/i.test(msg)
        ? `"${file.name}" could not be read - it may be damaged or password-protected.`
        : msg
    );
  }
  onProgress?.({ label: "Making the notebook…", done: pageCount, total: pageCount });
  const blob = builder.blob();
  const base = file.name.replace(/\.[^.]+$/, "");
  const pdf = new File([blob], `${base}.pdf`, { type: "application/pdf" });
  attachOfficeText(pdf, texts);
  return pdf;
}
