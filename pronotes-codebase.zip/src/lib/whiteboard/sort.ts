/**
 * Universal comparator for folders and boards.
 * Sorts by "updated" (most recent first / oldest first), "created", or natural "name" (A-Z / Z-A).
 */
export function sortItems<T extends { name: string; createdAt?: number; updatedAt?: number }>(
  items: T[],
  sortBy: "updated" | "created" | "name",
  sortOrder: "asc" | "desc"
): T[] {
  return [...items].sort((a, b) => {
    if (sortBy === "name") {
      const cmp = a.name.localeCompare(b.name, undefined, { numeric: true, sensitivity: "base" });
      return sortOrder === "asc" ? cmp : -cmp;
    }
    if (sortBy === "created") {
      const tA = a.createdAt || 0;
      const tB = b.createdAt || 0;
      return sortOrder === "asc" ? tA - tB : tB - tA;
    }
    // updated
    const tA = a.updatedAt || a.createdAt || 0;
    const tB = b.updatedAt || b.createdAt || 0;
    return sortOrder === "asc" ? tA - tB : tB - tA;
  });
}
