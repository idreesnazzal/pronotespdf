/**
 * Palm rejection and deliberate touch
 * ===================================
 *
 * The problem this solves: on a tablet you rest the side of your hand on the
 * glass before and while you write. Every one of those contacts is a real
 * `pointerdown` with `pointerType === "touch"`, indistinguishable from a
 * deliberate tap unless you look at context. Landing on an object, it used to
 * select it — popping the transform box open mid-sentence and, if the hand
 * shifted a millimetre, dragging the text away.
 *
 * How the note apps that get this right (OneNote, Samsung Notes, GoodNotes,
 * Notability) actually do it — none of them relies on a single signal:
 *
 *  1. **The stylus wins.** While a pen is in contact, touch is not input.
 *  2. **The window outstays the pen.** You lift the pen between words while
 *     your hand stays put, so touch stays suppressed for a beat AFTER the pen
 *     leaves the glass. Suppressing only during contact — which is what this
 *     app did — leaves the gap wide open, because the palm usually lands
 *     BEFORE the nib does.
 *  3. **Retroactively.** A hand that lands first is only revealed as a palm
 *     when the pen arrives a moment later, so whatever that contact started
 *     gets rolled back rather than merely stopped. (Handled by the caller —
 *     see `WhiteboardCanvas.handlePointerDown`.)
 *  4. **Contact geometry.** A palm is a much bigger patch than a fingertip.
 *
 * The pen-based rules cost pure-touch users nothing, because a device with no
 * stylus never sets `lastPenAt` — the window can never open. That is what lets
 * all of this be always-on instead of hidden behind a setting nobody finds.
 */

/**
 * How long after the stylus leaves the glass touch stays suppressed.
 *
 * Long enough to cover the lift between words (roughly 300-500ms of travel),
 * short enough that putting the pen down and immediately pinching to zoom does
 * not feel broken. The same ballpark the tablet note apps use.
 */
export const PEN_SUPPRESSION_MS = 800;

/**
 * Context-aware fast-bypass suppression window for multi-touch gestures (R1-DEF-03).
 * When the stylus is lifted and two fingertip contacts arrive, multi-touch
 * pinch-to-zoom and pan unfreeze after 150ms (or immediately if fingertip-sized),
 * eliminating the 800ms deadlock while preserving resting palm protection.
 */
export const PEN_FAST_BYPASS_MS = 150;

/**
 * Contact patch, in CSS pixels, at or above which a touch is a palm rather
 * than a fingertip. A fingertip on a tablet reports roughly 15-30; the edge of
 * a hand reports 45+, often as a long thin ellipse (e.g. 30x70), which is why
 * this tests the LARGER dimension and not the smaller one.
 *
 * Deliberately generous. A false positive here means "my finger cannot select
 * anything", which is worse than the bug being fixed, so the geometry test is
 * a supporting signal — the pen window above is the reliable one.
 */
export const PALM_CONTACT_PX = 45;

/** Android's platform long-press. Matching it is why it feels native. */
export const LONG_PRESS_MS = 500;

/**
 * Movement that turns a press into a drag. Below it the finger is holding
 * still (fingers always wobble a little); above it the user is panning and
 * clearly did not mean to grab anything.
 */
export const LONG_PRESS_SLOP_PX = 12;

export type TouchVerdict = "allow" | "pen-down" | "pen-recent" | "contact-size";

export interface ContactGeometry {
  /** PointerEvent.width — contact patch width in CSS px. */
  width?: number;
  /** PointerEvent.height — contact patch height in CSS px. */
  height?: number;
}

export interface PenProximity {
  /** Is the stylus touching the glass right now? */
  penDown: boolean;
  /** Date.now() of the last stylus contact; 0 when no pen has ever been seen. */
  lastPenAt: number;
  now: number;
}

/**
 * Is this contact patch too big to be a fingertip?
 *
 * Browsers that cannot measure the patch report the Pointer Events spec
 * default of 1x1. That is "unknown", not "tiny" — calling it a fingertip would
 * be exactly as unfounded as calling it a palm — so we abstain and let the pen
 * window decide.
 */
export function contactLooksLikePalm(c: ContactGeometry): boolean {
  const w = typeof c.width === "number" && Number.isFinite(c.width) ? c.width : 0;
  const h = typeof c.height === "number" && Number.isFinite(c.height) ? c.height : 0;
  if (w <= 1 && h <= 1) return false;
  return Math.max(w, h) >= PALM_CONTACT_PX;
}

/**
 * Should this touch be allowed to interact with content, and if not, why?
 * The reason is kept (rather than a bare boolean) so the canvas can log it and
 * so the tests can assert WHICH rule fired.
 */
export function classifyTouch(
  c: ContactGeometry,
  p: PenProximity,
  suppressionWindowMs: number = PEN_SUPPRESSION_MS
): TouchVerdict {
  if (p.penDown) return "pen-down";
  const sincePen = p.now - p.lastPenAt;
  if (p.lastPenAt > 0 && sincePen >= 0 && sincePen < suppressionWindowMs) return "pen-recent";

  if (contactLooksLikePalm(c)) return "contact-size";
  return "allow";
}

/** Convenience wrapper: true when the touch must not reach content. */
export function isRejectedTouch(c: ContactGeometry, p: PenProximity): boolean {
  return classifyTouch(c, p) !== "allow";
}

/** Has the finger moved far enough that this is a drag, not a press? */
export function exceedsLongPressSlop(dx: number, dy: number): boolean {
  return Math.hypot(dx, dy) > LONG_PRESS_SLOP_PX;
}

export interface TouchTapSelectInput {
  /** classifyTouch verdict for this contact. */
  verdict: TouchVerdict;
  /** The finger landed on an object that is already selected. */
  hitSelected: boolean;
  /** Shift is held (multi-select toggle gesture). */
  shiftKey: boolean;
  /** An inline text/sticky editor is open. */
  editing: boolean;
}

/**
 * Does a fingertip tap select at once?
 *
 * A clean fingertip tap on an unselected object selects it on contact — the
 * tap-to-select, press-drag-to-move contract every tablet note app uses,
 * with finger-drag still panning. Anything else keeps the old behaviour: a
 * palm-sized patch still needs the deliberate long press (a resting hand must
 * never pop the transform box open), shift keeps toggling, and mid-edit a
 * touch is a resting hand.
 */
export function shouldSelectOnTouchTap(i: TouchTapSelectInput): boolean {
  if (i.verdict !== "allow") return false;
  if (i.hitSelected) return false;
  if (i.shiftKey) return false;
  if (i.editing) return false;
  return true;
}
