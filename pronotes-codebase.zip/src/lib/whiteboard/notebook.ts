/**
 * Notebook pages
 * ==============
 * Pure helpers for paged documents. No React, no store — so the page model can
 * be tested on its own.
 *
 * The one rule that keeps notebooks and canvases from drifting apart: nothing
 * outside this file may read or write a board's element list directly. Reads go
 * through `getBoardElements`, writes through `mapBoardElements`. A canvas
 * resolves to `board.elements`; a notebook resolves to its active page. Every
 * existing tool then works on both without knowing which it is drawing on.
 */

import {
  BOARD_PATTERN_MAX_SIZE,
  BOARD_PATTERN_MIN_SIZE,
  DEFAULT_PAGE_SIZE,
  PAGE_SIZES,
  type Board,
  type BoardBackground,
  type BoardPattern,
  type ConnectionElement,
  type NotebookPage,
  type PageSizeId,
  type PageTemplate,
  type WhiteboardElement,
} from "./types";
import { GRID_SIZE } from "./grid";

/** Ids are generated here so the helpers stay usable outside the browser. */
function pageId(): string {
  return `pg_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 9)}`;
}

export function isNotebook(board: Board | null | undefined): boolean {
  return board?.kind === "notebook";
}

export function pageSizeOf(board: Board | null | undefined) {
  // A PDF-backed notebook carries the document's own page size, so a slide
  // deck is not letterboxed into A4.
  const custom = board?.customPageSize;
  if (custom && custom.width > 0 && custom.height > 0) {
    return { label: "PDF", width: custom.width, height: custom.height };
  }
  return PAGE_SIZES[board?.pageSize ?? DEFAULT_PAGE_SIZE];
}

/** Every PDF a notebook's pages reference, deduplicated. */
export function pdfDocIdsOf(board: Board | null | undefined): string[] {
  const ids = new Set<string>();
  for (const p of getPages(board)) if (p.pdf?.docId) ids.add(p.pdf.docId);
  return [...ids];
}

export function createPage(background?: BoardBackground): NotebookPage {
  const now = Date.now();
  return { id: pageId(), elements: [], background, createdAt: now, updatedAt: now };
}

/** A notebook's pages, tolerating a malformed or absent array. */
export function getPages(board: Board | null | undefined): NotebookPage[] {
  if (!board || !isNotebook(board)) return [];
  return Array.isArray(board.pages) ? board.pages : [];
}

/**
 * The page currently being edited. Falls back to the first page when
 * `activePageId` points at a page that no longer exists, so a stale id can
 * never leave the notebook with nothing to draw on.
 */
export function getActivePage(board: Board | null | undefined): NotebookPage | null {
  const pages = getPages(board);
  if (pages.length === 0) return null;
  return pages.find((p) => p.id === board?.activePageId) ?? pages[0];
}

export function getActivePageIndex(board: Board | null | undefined): number {
  const pages = getPages(board);
  if (pages.length === 0) return -1;
  const i = pages.findIndex((p) => p.id === board?.activePageId);
  return i === -1 ? 0 : i;
}

/** The live element list: the page's for a notebook, the board's for a canvas. */
export function getBoardElements(board: Board | null | undefined): WhiteboardElement[] {
  if (!board) return [];
  if (!isNotebook(board)) return board.elements ?? [];
  return getActivePage(board)?.elements ?? [];
}

/**
 * Applies `fn` to whichever element list is live, returning a new board.
 *
 * Every element mutation in the store funnels through this. Without a single
 * funnel, each of the store's mutation sites would need its own notebook
 * branch, and the one that got missed would silently write a page's strokes
 * onto the canvas field where nothing would ever render them again.
 */
export function mapBoardElements(
  board: Board,
  fn: (elements: WhiteboardElement[]) => WhiteboardElement[]
): Board {
  const now = Date.now();

  if (!isNotebook(board)) {
    return { ...board, elements: fn(board.elements ?? []), updatedAt: now };
  }

  const pages = getPages(board);
  if (pages.length === 0) {
    // A notebook with no pages is malformed; give it one rather than dropping
    // whatever the caller was trying to add.
    const page = createPage();
    return {
      ...board,
      pages: [{ ...page, elements: fn([]), updatedAt: now }],
      activePageId: page.id,
      updatedAt: now,
    };
  }

  const activeId = (getActivePage(board) as NotebookPage).id;
  return {
    ...board,
    pages: pages.map((p) =>
      p.id === activeId ? { ...p, elements: fn(p.elements ?? []), updatedAt: now } : p
    ),
    activePageId: activeId,
    updatedAt: now,
  };
}

/**
 * Like `mapBoardElements`, but applies to EVERY page rather than the active
 * one. Used for document-wide sweeps such as stripping connections that point
 * at a deleted board: a dangling link on page 7 is just as broken as one on
 * the page you happen to be looking at.
 */
export function mapAllBoardElements(
  board: Board,
  fn: (elements: WhiteboardElement[]) => WhiteboardElement[]
): Board {
  const now = Date.now();

  if (!isNotebook(board)) {
    return { ...board, elements: fn(board.elements ?? []), updatedAt: now };
  }

  return {
    ...board,
    pages: getPages(board).map((p) => ({ ...p, elements: fn(p.elements ?? []), updatedAt: now })),
    updatedAt: now,
  };
}

/**
 * Deep-copies a document for "duplicate". `remap` rewrites one element — the
 * caller owns id generation, because connections also have to have their
 * endpoints repointed at the copy. Pages are copied too, so duplicating a
 * notebook does not hand two documents the same page objects.
 */
export function cloneBoardContent(
  board: Board,
  remap: (el: WhiteboardElement) => WhiteboardElement
): Pick<Board, "elements" | "pages" | "activePageId"> {
  if (!isNotebook(board)) {
    return { elements: (board.elements ?? []).map(remap) };
  }

  const pages = getPages(board).map((p) => ({
    ...p,
    id: pageId(),
    elements: (p.elements ?? []).map(remap),
  }));
  const activeIndex = Math.max(0, getActivePageIndex(board));

  return {
    elements: [],
    pages,
    activePageId: pages[activeIndex]?.id ?? pages[0]?.id,
  };
}

// ---------------------------------------------------------------------------
// Continuous scroll layout
// ---------------------------------------------------------------------------
//
// Pages are stacked down the canvas with a gap between them, so a notebook
// scrolls the way GoodNotes and Notability do rather than making you click a
// next button. Page `i` occupies world Y from `pageOffsetY(i)` to
// `pageOffsetY(i) + height`; the gap between sheets is dead space.
//
// Each page's elements stay stored in PAGE-LOCAL coordinates. Only rendering
// and hit-testing add the offset. Storing world coordinates instead would
// mean every insert, delete or reorder of a page had to rewrite the
// coordinates of every element below it.

/** Dead space between sheets, in world units. Small enough to waste no screen,
 *  large enough to read as a separator and to host the gap "+" button.
 *  Pinned at 14 by `notebook_camera.test.ts` ("the join is a seam, not a
 *  band"): at the zoom floor it must render under 12 screen px on phone,
 *  tablet and desktop alike. */
export const PAGE_GAP = 14;

export function pageOffsetY(index: number, pageHeight: number): number {
  return index * (pageHeight + PAGE_GAP);
}

/** Total world height of the whole stack, excluding the trailing gap. */
export function notebookContentHeight(pageCount: number, pageHeight: number): number {
  if (pageCount <= 0) return 0;
  return pageCount * pageHeight + (pageCount - 1) * PAGE_GAP;
}

/**
 * Which page a world Y belongs to.
 *
 * A point in the gap between two sheets belongs to the page above it, so a
 * stroke started just off the bottom edge lands on the page you were writing
 * on rather than jumping to the next one. Points above the first page and
 * below the last clamp to those pages.
 */
export function pageIndexAtY(y: number, pageHeight: number, pageCount: number): number {
  if (pageCount <= 0) return -1;
  if (y < 0) return 0;
  const stride = pageHeight + PAGE_GAP;
  const raw = Math.floor(y / stride);
  return Math.max(0, Math.min(pageCount - 1, raw));
}

/** World Y -> the same point measured from the top of its own page. */
export function toPageLocalY(y: number, index: number, pageHeight: number): number {
  return y - pageOffsetY(index, pageHeight);
}

/** True when a world point falls on the sheet itself rather than in a gap. */
export function isOnSheet(
  x: number,
  y: number,
  index: number,
  pageWidth: number,
  pageHeight: number
): boolean {
  const localY = toPageLocalY(y, index, pageHeight);
  return x >= 0 && x <= pageWidth && localY >= 0 && localY <= pageHeight;
}

// ---------------------------------------------------------------------------
// Keeping ink on the paper
// ---------------------------------------------------------------------------
//
// A notebook is a stack of sheets, not an infinite canvas, and it is the only
// thing on screen that looks like paper. Before this, a notebook was drawn on
// the SAME unbounded world as a whiteboard: you could write a metre to the
// right of the page, or into the dead gap between two sheets, and the ink
// stayed there — visible, saved, and impossible to see again once you scrolled,
// because nothing outside the sheet is ever printed or exported. GoodNotes,
// Notability and OneNote all refuse that, and so do we now.
//
// The ACTIVE page always sits at world origin: re-anchoring slides the camera
// by exactly one stride whenever the next sheet takes over, so the page you are
// writing on is always the rectangle (0,0)-(width,height). That is what makes
// these two functions as simple as they look.

/**
 * How far inside the sheet edge ink is allowed to land.
 *
 * Not zero: a stroke has width, and a point exactly on the boundary paints a
 * half-width smear over the page border. Two world units keeps the nib inside
 * the paper at every zoom without being visible as a margin.
 */
export const SHEET_INK_INSET = 2;

/** True when a world point is on the ACTIVE sheet (which sits at the origin). */
export function isOnActiveSheet(
  x: number,
  y: number,
  pageWidth: number,
  pageHeight: number,
  margin = 0
): boolean {
  return (
    x >= -margin && x <= pageWidth + margin && y >= -margin && y <= pageHeight + margin
  );
}

/**
 * Pulls a world point back onto the active sheet.
 *
 * Used for every point that becomes content — stroke samples, shape corners,
 * where a text box lands. Clamping rather than dropping the point matters for
 * strokes: if you run off the edge mid-word the line stops at the margin
 * instead of tearing a hole in the middle of the stroke.
 */
export function clampToSheet(
  x: number,
  y: number,
  pageWidth: number,
  pageHeight: number,
  inset = SHEET_INK_INSET
): { x: number; y: number } {
  const lo = inset;
  const hiX = Math.max(lo, pageWidth - inset);
  const hiY = Math.max(lo, pageHeight - inset);
  return {
    x: Math.min(hiX, Math.max(lo, x)),
    y: Math.min(hiY, Math.max(lo, y)),
  };
}

/**
 * Clamps a whole element's bounding box onto the sheet by TRANSLATION only.
 *
 * Moving is the right correction for a drag: resizing an element because it
 * reached the edge would silently reshape the user's drawing. An element too
 * big for the page is pinned to the top-left rather than squashed, so it stays
 * whole and reachable.
 */
export function clampBoxToSheet(
  x: number,
  y: number,
  w: number,
  h: number,
  pageWidth: number,
  pageHeight: number
): { x: number; y: number } {
  const maxX = pageWidth - w;
  const maxY = pageHeight - h;
  return {
    x: maxX < 0 ? 0 : Math.min(maxX, Math.max(0, x)),
    y: maxY < 0 ? 0 : Math.min(maxY, Math.max(0, y)),
  };
}

/**
 * The pages whose sheets intersect a visible world Y range, as an index range.
 * A 200-page notebook must not render 200 sheets and every stroke on them.
 */
export function visiblePageRange(
  topY: number,
  bottomY: number,
  pageHeight: number,
  pageCount: number,
  overscan = 1
): { start: number; end: number } {
  if (pageCount <= 0) return { start: 0, end: -1 };
  const stride = pageHeight + PAGE_GAP;
  const start = Math.max(0, Math.floor(topY / stride) - overscan);
  const end = Math.min(pageCount - 1, Math.floor(bottomY / stride) + overscan);
  return { start, end: Math.max(start, end) };
}

/**
 * Turns a 1-based, inclusive page range a person typed into page INDICES that
 * actually exist.
 *
 * People type ranges loosely - "5 to 2" when they mean 2 to 5, "3 to 999" for
 * "to the end", an empty box while they are still typing. Every one of those
 * must come back as a sensible range rather than an empty export or a throw,
 * so this is the single place that decides what a range means. It returns the
 * clamped `from`/`to` as well, so the UI can show what it actually used.
 */
export function resolvePageRange(
  pageCount: number,
  from: number,
  to: number
): { from: number; to: number; indices: number[] } {
  if (pageCount <= 0) return { from: 0, to: 0, indices: [] };
  const clamp = (n: number, fallback: number) => {
    const v = Math.round(Number.isFinite(n) ? n : fallback);
    return Math.min(Math.max(1, v), pageCount);
  };
  let lo = clamp(from, 1);
  let hi = clamp(to, pageCount);
  if (lo > hi) [lo, hi] = [hi, lo];
  const indices: number[] = [];
  for (let i = lo; i <= hi; i++) indices.push(i - 1);
  return { from: lo, to: hi, indices };
}

/**
 * Reads a page selection the way people write one: "2-5, 8", "1,3", "4-",
 * "-6", "7". Returns 1-based page numbers, sorted, deduplicated and clamped
 * to what exists.
 *
 * Every note-taking app that offers this accepts the same shorthand, so the
 * parser is deliberately forgiving: stray spaces, en-dashes pasted from a PDF,
 * trailing commas and a half-typed "2-" all mean something sensible rather
 * than an error. An empty or entirely unparseable string returns no pages, and
 * the caller decides whether that means "nothing" or "fall back to all".
 */
export function parsePageSelection(input: string, pageCount: number): number[] {
  if (pageCount <= 0) return [];
  const clamp = (n: number) => Math.min(Math.max(1, n), pageCount);
  const chosen = new Set<number>();

  // En-dash and em-dash arrive from anything pasted out of a document, and
  // people space their ranges out ("4 - 2"), so spaces around a dash are
  // closed up BEFORE splitting - otherwise that reads as three separate pages.
  const normalised = input.replace(/[\u2012-\u2015]/g, "-").replace(/\s*-\s*/g, "-");
  for (const rawPart of normalised.split(/[,;\s]+/)) {
    const part = rawPart.trim();
    if (!part) continue;

    const range = /^(\d*)-(\d*)$/.exec(part);
    if (range) {
      const [, a, b] = range;
      if (!a && !b) continue; // a lone "-" says nothing
      let lo = a ? clamp(parseInt(a, 10)) : 1;
      let hi = b ? clamp(parseInt(b, 10)) : pageCount;
      if (lo > hi) [lo, hi] = [hi, lo];
      for (let i = lo; i <= hi; i++) chosen.add(i);
      continue;
    }

    if (/^\d+$/.test(part)) chosen.add(clamp(parseInt(part, 10)));
  }

  return [...chosen].sort((x, y) => x - y);
}

/**
 * Describes a set of page numbers the way it would be typed: [1,2,3,5] reads
 * "1-3, 5". Used for filenames and for showing back what was understood.
 */
export function formatPageSelection(pages: number[]): string {
  const sorted = [...new Set(pages)].sort((a, b) => a - b);
  const parts: string[] = [];
  let i = 0;
  while (i < sorted.length) {
    const start = sorted[i];
    let end = start;
    while (i + 1 < sorted.length && sorted[i + 1] === end + 1) { end = sorted[++i]; }
    parts.push(start === end ? `${start}` : `${start}-${end}`);
    i++;
  }
  return parts.join(", ");
}

// ---------------------------------------------------------------------------
// Page operations
// ---------------------------------------------------------------------------

/**
 * Fresh copies of the pages at `indices`, ready to be inserted into
 * `targetBoardId`.
 *
 * Every element gets a new id, because the same element existing twice under
 * one id makes selection, deletion and undo act on both at once. Connections
 * are remapped to the new ids; one whose other end was NOT copied is dropped
 * rather than carried over pointing at nothing, which would draw a line to the
 * origin of the page.
 *
 * A page that shows a PDF keeps its `{ docId, pageNumber }` reference. That is
 * safe without copying any bytes: the PDF garbage collector scans every
 * board's pages for referenced docIds, so the import stays alive exactly as
 * long as some page still points at it.
 */
export function copyPagesFrom(
  source: Board,
  indices: number[],
  targetBoardId: string,
  newId: () => string
): NotebookPage[] {
  const pages = getPages(source);
  const chosen = indices.map((i) => pages[i]).filter(Boolean);

  const idMap = new Map<string, string>();
  for (const page of chosen) {
    for (const el of page.elements ?? []) idMap.set(el.id, newId());
  }

  const remap = (el: WhiteboardElement): WhiteboardElement | null => {
    const id = idMap.get(el.id) ?? newId();
    if (el.type === "connection") {
      const conn = el as ConnectionElement;
      const ends = [conn.source, conn.target];
      for (const end of ends) {
        // An end on THIS board that was not copied has nothing to attach to.
        if (end.boardId === source.id && !idMap.has(end.elementId)) return null;
      }
      return {
        ...conn,
        id,
        source: {
          ...conn.source,
          boardId: conn.source.boardId === source.id ? targetBoardId : conn.source.boardId,
          elementId: idMap.get(conn.source.elementId) ?? conn.source.elementId,
        },
        target: {
          ...conn.target,
          boardId: conn.target.boardId === source.id ? targetBoardId : conn.target.boardId,
          elementId: idMap.get(conn.target.elementId) ?? conn.target.elementId,
        },
        updatedAt: Date.now(),
      } as WhiteboardElement;
    }
    return { ...el, id, updatedAt: Date.now() };
  };

  const now = Date.now();
  return chosen.map((page) => ({
    ...page,
    id: pageId(),
    elements: (page.elements ?? [])
      .map(remap)
      .filter((el): el is WhiteboardElement => el !== null),
    createdAt: now,
    updatedAt: now,
  }));
}

/** A notebook page that shows one page of an imported PDF. */
export function pageFromPdf(docId: string, pageNumber: number): NotebookPage {
  const now = Date.now();
  return {
    id: pageId(),
    elements: [],
    pdf: { docId, pageNumber },
    // A PDF page IS the paper; drawing dots over a lecture slide is noise.
    background: { pattern: "plain" },
    createdAt: now,
    updatedAt: now,
  };
}

/**
 * Inserts pages at `atIndex` (0-based, clamped), selecting the first one.
 *
 * `atIndex` is the position the first new page ENDS UP at, so 0 means "before
 * everything" and pageCount means "at the end" - the two answers people
 * actually want when they say where to put something.
 */
export function insertPages(board: Board, incoming: NotebookPage[], atIndex: number): Board {
  if (!isNotebook(board) || incoming.length === 0) return board;
  const pages = getPages(board);
  const at = Math.min(Math.max(0, Math.round(atIndex)), pages.length);
  const next = [...pages.slice(0, at), ...incoming, ...pages.slice(at)];
  return {
    ...board,
    pages: next,
    activePageId: incoming[0].id,
    updatedAt: Date.now(),
  };
}

/** Inserts a blank page after `afterPageId` (or at the end) and selects it. */
export function addPage(board: Board, afterPageId?: string): Board {
  const pages = getPages(board);
  // A new page starts with the NOTEBOOK's paper (the Settings default), not
  // the neighbour's: per-page overrides stay exactly where you put them, and
  // a fresh sheet in a mixed notebook is predictable instead of a copy of
  // whatever it landed next to.
  const anchorIndex = afterPageId ? pages.findIndex((p) => p.id === afterPageId) : pages.length - 1;
  const page = createPage(board.background);
  const at = anchorIndex >= 0 ? anchorIndex + 1 : pages.length;

  return {
    ...board,
    pages: [...pages.slice(0, at), page, ...pages.slice(at)],
    activePageId: page.id,
    updatedAt: Date.now(),
  };
}

export function duplicatePage(board: Board, pageId_: string): Board {
  const pages = getPages(board);
  const index = pages.findIndex((p) => p.id === pageId_);
  if (index === -1) return board;

  const source = pages[index];
  const now = Date.now();
  const copy: NotebookPage = {
    ...source,
    id: pageId(),
    // Elements carry ids; cloning without fresh ones would give two pages
    // elements that selection and deletion treat as the same object.
    elements: source.elements.map((el) => ({
      ...el,
      id: `${el.id}_c${Math.random().toString(36).slice(2, 7)}`,
    })),
    createdAt: now,
    updatedAt: now,
  };

  return {
    ...board,
    pages: [...pages.slice(0, index + 1), copy, ...pages.slice(index + 1)],
    activePageId: copy.id,
    updatedAt: now,
  };
}

/** Deletes a page. A notebook always keeps at least one, so the last delete clears instead. */
export function deletePage(board: Board, pageId_: string): Board {
  const pages = getPages(board);
  const index = pages.findIndex((p) => p.id === pageId_);
  if (index === -1) return board;

  if (pages.length === 1) {
    const blank = createPage(pages[0].background);
    return { ...board, pages: [blank], activePageId: blank.id, updatedAt: Date.now() };
  }

  const remaining = pages.filter((p) => p.id !== pageId_);
  // Select the page that takes the deleted one's place, or the new last page.
  const next = remaining[Math.min(index, remaining.length - 1)];
  return { ...board, pages: remaining, activePageId: next.id, updatedAt: Date.now() };
}

/** Moves a page to `toIndex`, clamped into range. */
export function movePage(board: Board, pageId_: string, toIndex: number): Board {
  const pages = getPages(board);
  const from = pages.findIndex((p) => p.id === pageId_);
  if (from === -1) return board;

  const to = Math.max(0, Math.min(pages.length - 1, toIndex));
  if (to === from) return board;

  const next = [...pages];
  const [moved] = next.splice(from, 1);
  next.splice(to, 0, moved);
  return { ...board, pages: next, updatedAt: Date.now() };
}

/**
 * Which sheet is under a world point, in the ANCHORED frame (the active page
 * sits at y = 0 and page i at (i - activeIndex) * stride). Null in the gap
 * between sheets, above the first, below the last, or beside the paper.
 *
 * Needed because several sheets can be on screen at once when zoomed out, but
 * only the anchored one is live. Without this a pen landing on the sheet
 * above or below was treated as "off the page" and panned instead of writing.
 */
export function sheetIndexAt(
  wx: number,
  wy: number,
  activeIndex: number,
  pageCount: number,
  pageWidth: number,
  pageHeight: number,
  marginX = 0
): number | null {
  if (pageCount <= 0) return null;
  const stride = pageHeight + PAGE_GAP;
  const offset = Math.floor(wy / stride);
  const index = activeIndex + offset;
  if (index < 0 || index >= pageCount) return null;
  const localY = wy - offset * stride;
  if (localY > pageHeight) return null; // in the gap below this sheet
  if (wx < -marginX || wx > pageWidth + marginX) return null;
  return index;
}

/**
 * Inserts a blank page so that it ends up AT `index` and selects it.
 *
 * `0` is above the first page and `pages.length` is below the last — the
 * three places a "+" can appear between sheets. Like addPage, the new sheet
 * starts with the notebook default paper.
 */
export function insertPageAt(board: Board, index: number): Board {
  const pages = getPages(board);
  const at = Math.max(0, Math.min(pages.length, Math.round(index)));
  if (at === 0) return pages.length > 0 ? addPageBefore(board, pages[0].id) : addPage(board);
  return addPage(board, pages[at - 1].id);
}

/** Inserts a blank page BEFORE `pageId` and selects it. */
export function addPageBefore(board: Board, pageId_: string): Board {
  const pages = getPages(board);
  const index = pages.findIndex((p) => p.id === pageId_);
  if (index === -1) return addPage(board);

  const page = createPage(board.background);
  return {
    ...board,
    pages: [...pages.slice(0, index), page, ...pages.slice(index)],
    activePageId: page.id,
    updatedAt: Date.now(),
  };
}

// ---------------------------------------------------------------------------
// Bookmarks
// ---------------------------------------------------------------------------

export function togglePageBookmark(board: Board, pageId_: string): Board {
  const pages = getPages(board);
  if (!pages.some((p) => p.id === pageId_)) return board;
  return {
    ...board,
    pages: pages.map((p) =>
      p.id === pageId_ ? { ...p, bookmarked: !p.bookmarked, updatedAt: Date.now() } : p
    ),
    updatedAt: Date.now(),
  };
}

/** Starred pages with their real page numbers, for the Favourites list. */
export function bookmarkedPages(
  board: Board | null | undefined
): Array<{ page: NotebookPage; index: number }> {
  return getPages(board)
    .map((page, index) => ({ page, index }))
    .filter((e) => e.page.bookmarked === true);
}

// ---------------------------------------------------------------------------
// Templates
// ---------------------------------------------------------------------------

/** Captures a page as a reusable template. Ink is copied, not referenced. */
export function templateFromPage(
  page: NotebookPage,
  name: string,
  width: number,
  height: number
): PageTemplate {
  return {
    id: `tpl_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`,
    name: name.trim() || "Untitled template",
    createdAt: Date.now(),
    width,
    height,
    background: page.background,
    elements: (page.elements ?? []).map((el) => ({ ...el })),
  };
}

/**
 * A new page from a template.
 *
 * Every element gets a fresh id — reusing the template's would make two pages
 * built from it share identities, so selecting on one would select on the
 * other and deleting from one would delete from both.
 */
export function pageFromTemplate(template: PageTemplate): NotebookPage {
  const now = Date.now();
  return {
    id: pageId(),
    background: template.background,
    elements: (template.elements ?? []).map((el) => ({
      ...el,
      id: `${el.id}_t${Math.random().toString(36).slice(2, 7)}`,
    })),
    createdAt: now,
    updatedAt: now,
  };
}

/** Inserts a template-built page after `afterPageId` (or at the end). */
export function insertTemplatePage(
  board: Board,
  template: PageTemplate,
  afterPageId?: string
): Board {
  const pages = getPages(board);
  const page = pageFromTemplate(template);
  const anchor = afterPageId ? pages.findIndex((p) => p.id === afterPageId) : pages.length - 1;
  const at = anchor >= 0 ? anchor + 1 : pages.length;
  return {
    ...board,
    pages: [...pages.slice(0, at), page, ...pages.slice(at)],
    activePageId: page.id,
    updatedAt: Date.now(),
  };
}

export function setActivePage(board: Board, pageId_: string): Board {
  if (!getPages(board).some((p) => p.id === pageId_)) return board;
  return { ...board, activePageId: pageId_ };
}

/** Steps `delta` pages from the current one, stopping at the ends. */
export function stepPage(board: Board, delta: number): Board {
  const pages = getPages(board);
  if (pages.length === 0) return board;
  const index = getActivePageIndex(board);
  const next = Math.max(0, Math.min(pages.length - 1, index + delta));
  return next === index ? board : { ...board, activePageId: pages[next].id };
}

/** Per-page paper, falling back to the notebook's own. */
export function setPageBackground(
  board: Board,
  pageId_: string,
  patch: Partial<BoardBackground>
): Board {
  const pages = getPages(board);
  if (!pages.some((p) => p.id === pageId_)) return board;

  return {
    ...board,
    pages: pages.map((p) =>
      p.id === pageId_
        ? {
            ...p,
            background: { ...(p.background ?? board.background ?? { pattern: "dots" }), ...patch },
            updatedAt: Date.now(),
          }
        : p
    ),
    updatedAt: Date.now(),
  };
}

export function backgroundForPage(board: Board, page: NotebookPage | null): BoardBackground | undefined {
  return page?.background ?? board.background;
}

const VALID_PATTERNS: ReadonlySet<string> = new Set(["dots", "grid", "lines", "plain"]);

export interface SheetPaper {
  pattern: BoardPattern;
  /** Spacing in px, clamped to the sane range. */
  size: number;
  /** Raw stored colour (preset id or literal); undefined follows the theme. */
  color?: string;
}

/**
 * The paper one sheet is painted with: the page's own, falling back to the
 * notebook's. Every renderer (canvas live sheet, neighbour sheets, thumbnails,
 * export) must go through this — reading only the ACTIVE page's paper and
 * painting it on every sheet is exactly how a grid page "turned blank" the
 * moment you navigated to it while showing grid from the page above.
 */
export function paperForPage(
  board: Board | null | undefined,
  page: NotebookPage | null
): SheetPaper {
  const bg = board ? backgroundForPage(board, page) ?? board.background : undefined;
  const pattern: BoardPattern =
    bg && VALID_PATTERNS.has(bg.pattern) ? bg.pattern : "dots";
  const size = Math.min(
    BOARD_PATTERN_MAX_SIZE,
    Math.max(BOARD_PATTERN_MIN_SIZE, bg?.size ?? GRID_SIZE)
  );
  return { pattern, size, color: bg?.color };
}

/** Turns a fresh board into a notebook with one blank page. */
export function makeNotebook(board: Board, pageSize: PageSizeId = DEFAULT_PAGE_SIZE): Board {
  const first = createPage(board.background);
  // Anything already drawn on the canvas becomes the first page rather than
  // being stranded on a field the notebook view never reads.
  const seeded: NotebookPage =
    board.elements && board.elements.length > 0 ? { ...first, elements: board.elements } : first;

  return {
    ...board,
    kind: "notebook",
    pageSize,
    pages: [seeded],
    activePageId: seeded.id,
    elements: [],
    updatedAt: Date.now(),
  };
}

/** Every element in the document, for search, export and the knowledge graph. */
export function allElements(board: Board | null | undefined): WhiteboardElement[] {
  if (!board) return [];
  if (!isNotebook(board)) return board.elements ?? [];
  return getPages(board).flatMap((p) => p.elements ?? []);
}

// ---------------------------------------------------------------------------
// How much empty desk may surround the paper
// ---------------------------------------------------------------------------

/**
 * Screen pixels of bare desk allowed past the edge of the paper.
 *
 * Stated in SCREEN pixels on purpose. A bound in world units looks completely
 * different at each zoom - the same 400-unit slack is a thin strip at 200% and
 * most of the screen at 44% - and what the eye judges is the strip of grey it
 * can see, not the number behind it. A small strip is wanted: it is the handle
 * you grab to pan, and it shows where the sheet ends.
 */
export const DESK_MARGIN_PX = 80;

/** clamp(), or the midpoint when the interval is empty (content fits: centre it). */
function boundAxis(v: number, lo: number, hi: number): number {
  if (lo > hi) return (lo + hi) / 2;
  return Math.min(Math.max(v, lo), hi);
}

/**
 * Where a notebook's camera is allowed to sit.
 *
 * The camera is the world point at the centre of the viewport, so the visible
 * world band is `camera +/- half the viewport in world units`. The rule is
 * simply: no more than `DESK_MARGIN_PX` of desk beyond the paper on any side.
 *
 * Horizontally the paper is one sheet wide; vertically the "paper" is the whole
 * stack, measured in the anchored frame where the ACTIVE page starts at y = 0,
 * so the bound moves with the page you are on and never fights re-anchoring.
 *
 * When the paper is smaller than the viewport - a zoomed-out sheet, or a
 * one-page notebook on a tall screen - the interval is empty and the midpoint
 * centres the paper instead, which is the only position with equal margins.
 */
/**
 * How far out a notebook may be zoomed: until the whole sheet fits, and no
 * further.
 *
 * Capping the desk at DESK_MARGIN_PX does nothing while the paper itself can
 * be shrunk to a quarter of the screen - at 44% an A4 page is 349px wide on a
 * 1250px tablet, so two thirds of the glass is grey no matter where the camera
 * sits, and the margin rule can only centre the waste rather than remove it.
 * The cure is to stop the zoom at the point where more zooming out buys
 * nothing but grey: the page already fits, with the same margin around it.
 *
 * Derived from the viewport rather than being a fixed percentage, because
 * "40%" means a full page on a phone and a stamp on a monitor. On a wide
 * screen the height is what runs out first, so the floor lands low enough to
 * still see a whole A4 page; on a tall one it is the width.
 *
 * Returns 0 when there is nothing to go on, meaning "no floor".
 */
/**
 * How far past the page-fit you may still zoom out, as a fraction of it.
 *
 * Stopping exactly at the fit was too strict to use: at that zoom the sheet
 * fills the screen and you cannot see the next page coming, which is the
 * reason to zoom out at all. A fifth further shows the neighbouring sheets -
 * and because the pages are separated by a seam rather than a gap, what that
 * extra room shows is paper, not desk.
 */
export const ZOOM_OUT_HEADROOM = 0.8;

export function minNotebookZoom(
  vp: { width: number; height: number },
  page: { width: number; height: number }
): number {
  const usableW = vp.width - DESK_MARGIN_PX * 2;
  const usableH = vp.height - DESK_MARGIN_PX * 2;
  if (!(usableW > 0) || !(usableH > 0) || !page.width || !page.height) return 0;
  return Math.min(usableW / page.width, usableH / page.height) * ZOOM_OUT_HEADROOM;
}

export function clampNotebookCamera(
  cam: { x: number; y: number; zoom: number },
  vp: { width: number; height: number },
  page: { width: number; height: number },
  doc?: { pageCount: number; activeIndex: number }
): { x: number; y: number } {
  const z = cam.zoom;
  if (!z || !vp.width || !vp.height || !page.width || !page.height) {
    return { x: cam.x, y: cam.y };
  }
  const halfW = vp.width / 2 / z;
  const halfH = vp.height / 2 / z;
  const margin = DESK_MARGIN_PX / z;

  const count = Math.max(1, doc?.pageCount ?? 1);
  const index = Math.min(Math.max(0, doc?.activeIndex ?? 0), count - 1);
  const stride = page.height + PAGE_GAP;
  const docTop = -(index * stride);
  const docBottom = (count - 1 - index) * stride + page.height;

  return {
    x: boundAxis(cam.x, halfW - margin, page.width - halfW + margin),
    y: boundAxis(cam.y, docTop + halfH - margin, docBottom - halfH + margin),
  };
}

// ---------------------------------------------------------------------------
// One notebook view, shared by every pane that draws one
// ---------------------------------------------------------------------------
//
// A notebook is drawn by two components: the live canvas, and the split view's
// other pane. They used to compute their own layouts - the live canvas as a
// continuous strip anchored on the active page, the split pane as a single
// sheet at y = 0 - while sharing one stored camera. The same camera therefore
// meant two different pictures, and swapping which pane was live visibly moved
// the page. These helpers are the single definition both now use.

/** A sheet to draw, in the frame where the anchored (active) page sits at y = 0. */
export interface VisibleSheet {
  index: number;
  offsetY: number;
}

/**
 * The sheets a viewport can reach, including the anchored one.
 *
 * Mirrors the live canvas exactly: pages are one stride apart, and anything
 * more than a stride beyond the visible band is skipped, so a 200-page
 * notebook draws a handful of sheets rather than 200.
 */
export function visibleSheets(
  pageCount: number,
  activeIndex: number,
  pageHeight: number,
  cameraY: number,
  halfWorldHeight: number
): VisibleSheet[] {
  if (pageCount <= 0 || !(pageHeight > 0)) return [];
  const stride = pageHeight + PAGE_GAP;
  const topY = cameraY - halfWorldHeight;
  const bottomY = cameraY + halfWorldHeight;
  const out: VisibleSheet[] = [];
  for (let i = 0; i < pageCount; i++) {
    const offsetY = (i - activeIndex) * stride;
    if (offsetY + pageHeight < topY - stride) continue;
    if (offsetY > bottomY + stride) continue;
    out.push({ index: i, offsetY });
  }
  return out;
}

/**
 * Which way continuous scrolling should hand the anchor on: +1, -1 or 0.
 *
 * Once the view centre crosses the middle of the gap between two sheets the
 * next page becomes the anchored one and the camera slides one stride to
 * compensate, so the picture does not move. Same thresholds as the live canvas.
 */
export function reanchorDirection(
  cameraY: number,
  pageHeight: number,
  activeIndex: number,
  pageCount: number
): -1 | 0 | 1 {
  const forward = pageHeight + PAGE_GAP / 2;
  const backward = -PAGE_GAP / 2;
  if (cameraY > forward && activeIndex < pageCount - 1) return 1;
  if (cameraY < backward && activeIndex > 0) return -1;
  return 0;
}
