/**
 * Capture: a picture of what you see in one area
 * ==============================================
 * The select tool's "screenshot". You draw a box or a loop over anything on
 * the canvas - ink, text, pictures, the paper and its ruling, the PDF / Word /
 * PowerPoint page underneath - and get back a PNG of exactly that, to copy,
 * share or drop into a notebook.
 *
 * It is NOT a screen grab. A WebView cannot read its own pixels, and a screen
 * grab would be stuck at screen resolution with the selection handles in it.
 * The area is re-drawn from the document instead, through the export engine
 * (export.ts) - the same serializer, the same sheet painter, the same PDF
 * rasteriser - so a capture can never disagree with an export, and it can be
 * rendered sharper than the screen showed it.
 *
 * Coordinates are WORLD units in the frame the canvas was in when the area
 * was drawn: for a notebook that is the frame anchored on the active page
 * (`anchorIndex` at y = 0, its neighbours one stride above and below), which
 * is why the source carries the anchor with it. A capture that spans the gap
 * between two sheets shows both halves, the way the screen did.
 *
 * Everything here except the last few async functions is pure, so the region
 * maths and the SVG it produces are unit-tested in node.
 */

import type { Board, ConnectionElement, NotebookPage, WhiteboardElement } from "./types";
import { BOARD_BACKGROUNDS } from "./types";
import { getBoardElements, getPages, isNotebook, pageSizeOf, PAGE_GAP } from "./notebook";
import { getElementBounds, getUnionBounds, rotatePoint } from "./geometry";
import {
  SVG_HEAD_STYLE,
  fitScale,
  paperFor,
  paperPatternSvg,
  rasterizeSvg,
  resolveExportImages,
  resolvePageBackdrops,
  serializeElements,
  sheetSvg,
  type ExportReport,
  type SheetLayers,
} from "./export";

export interface CapturePoint {
  x: number;
  y: number;
}

export interface CaptureRect {
  x: number;
  y: number;
  width: number;
  height: number;
}

export type CaptureShape = "rectangle" | "lasso";

/**
 * What goes behind the content.
 *  - page:        what you see - paper colour, ruling, the PDF page.
 *  - white:       a clean white sheet: no ruling, no tinted paper, but the PDF
 *                 page stays, because on a lecture slide the slide IS the
 *                 content.
 *  - transparent: your ink and objects alone.
 */
export type CaptureBackground = "page" | "white" | "transparent";

/** One capture: a document, an area of it, and how the area was drawn. */
export interface CaptureSource {
  board: Board;
  /** World units, in the frame anchored on `anchorIndex`. */
  region: CaptureRect;
  /** A freeform loop: the picture is masked to it, transparent outside. */
  polygon?: CapturePoint[];
  /** The notebook page that sat at y = 0 when the area was drawn. */
  anchorIndex: number;
  /** "Selection only": draw just these elements (plus the paper, if asked). */
  onlyIds?: string[];
}

export interface CaptureLook {
  background: CaptureBackground;
  /** The app was in dark mode, so "page" means the dark paper you saw. */
  dark: boolean;
}

/** Smaller than this (world units) is a tap or a slip, not an area. */
export const CAPTURE_MIN_SIDE = 6;

/** The sharpness steps the panel offers: pixels per world unit. */
export const CAPTURE_SCALES = [1, 2, 3] as const;
export type CaptureScale = (typeof CAPTURE_SCALES)[number];

/** The canvas background in dark mode (globals.css `--background`). */
const THEME_DARK_BG = "#0a0a0a";

// ---------------------------------------------------------------------------
// Region maths
// ---------------------------------------------------------------------------

export function rectFromCorners(a: CapturePoint, b: CapturePoint): CaptureRect {
  return {
    x: Math.min(a.x, b.x),
    y: Math.min(a.y, b.y),
    width: Math.abs(b.x - a.x),
    height: Math.abs(b.y - a.y),
  };
}

export function boundsOfPoints(points: CapturePoint[]): CaptureRect | null {
  if (points.length === 0) return null;
  let x0 = Infinity;
  let y0 = Infinity;
  let x1 = -Infinity;
  let y1 = -Infinity;
  for (const p of points) {
    if (!Number.isFinite(p.x) || !Number.isFinite(p.y)) continue;
    x0 = Math.min(x0, p.x);
    y0 = Math.min(y0, p.y);
    x1 = Math.max(x1, p.x);
    y1 = Math.max(y1, p.y);
  }
  if (!Number.isFinite(x0)) return null;
  return { x: x0, y: y0, width: x1 - x0, height: y1 - y0 };
}

export function intersectRect(a: CaptureRect, b: CaptureRect): CaptureRect | null {
  const x0 = Math.max(a.x, b.x);
  const y0 = Math.max(a.y, b.y);
  const x1 = Math.min(a.x + a.width, b.x + b.width);
  const y1 = Math.min(a.y + a.height, b.y + b.height);
  if (x1 <= x0 || y1 <= y0) return null;
  return { x: x0, y: y0, width: x1 - x0, height: y1 - y0 };
}

/** Shoelace area; used to tell a real loop from a scribbled line. */
export function polygonArea(points: CapturePoint[]): number {
  let sum = 0;
  for (let i = 0; i < points.length; i++) {
    const a = points[i];
    const b = points[(i + 1) % points.length];
    sum += a.x * b.y - b.x * a.y;
  }
  return Math.abs(sum) / 2;
}

/**
 * The paper a notebook's pages cover, in the frame anchored on `anchorIndex`.
 * Null for a whiteboard, whose world has no edge.
 */
export function documentBounds(board: Board, anchorIndex: number): CaptureRect | null {
  if (!isNotebook(board)) return null;
  const count = getPages(board).length;
  if (count === 0) return null;
  const { width, height } = pageSizeOf(board);
  const stride = height + PAGE_GAP;
  return {
    x: 0,
    y: -anchorIndex * stride,
    width,
    height: count * height + (count - 1) * PAGE_GAP,
  };
}

/**
 * The area actually captured from what was drawn, or null when it is too
 * small to be one.
 *
 * In a notebook the grey desk around the pages is furniture, not content, so
 * the area is trimmed to the paper: a box dragged generously past the page
 * edge gives the page, not a frame of empty desk. A whiteboard is captured as
 * drawn.
 */
export function clampCaptureRegion(
  board: Board,
  anchorIndex: number,
  drawn: CaptureRect
): CaptureRect | null {
  const doc = documentBounds(board, anchorIndex);
  const r = doc ? intersectRect(drawn, doc) : drawn;
  if (!r || r.width < CAPTURE_MIN_SIDE || r.height < CAPTURE_MIN_SIDE) return null;
  return r;
}

/** The notebook sheets an area touches, with where each sits in the frame. */
export function sheetsInRegion(
  board: Board,
  anchorIndex: number,
  region: CaptureRect
): Array<{ page: NotebookPage; index: number; offsetY: number }> {
  if (!isNotebook(board)) return [];
  const { height } = pageSizeOf(board);
  const stride = height + PAGE_GAP;
  const out: Array<{ page: NotebookPage; index: number; offsetY: number }> = [];
  getPages(board).forEach((page, index) => {
    const offsetY = (index - anchorIndex) * stride;
    if (offsetY + height <= region.y || offsetY >= region.y + region.height) return;
    out.push({ page, index, offsetY });
  });
  return out;
}

/**
 * The area to capture for a selection: its bounds plus a little air, so ink
 * right at the edge of the box is not shaved. The air is in SCREEN pixels
 * (divided by the zoom), which is what the eye judges.
 */
export function selectionCaptureRegion(
  elements: WhiteboardElement[],
  ids: string[],
  zoom: number,
  airPx = 14
): CaptureRect | null {
  const set = new Set(ids);
  const picked = elements.filter((el) => set.has(el.id) && el.type !== "connection");
  if (picked.length === 0 || !getUnionBounds(picked)) return null;
  // Turned pictures and shapes reach past their unturned box.
  const boxes = picked.map(rotatedBounds);
  const x0 = Math.min(...boxes.map((q) => q.x));
  const y0 = Math.min(...boxes.map((q) => q.y));
  const b = {
    x: x0,
    y: y0,
    width: Math.max(...boxes.map((q) => q.x + q.width)) - x0,
    height: Math.max(...boxes.map((q) => q.y + q.height)) - y0,
  };
  const air = airPx / (zoom > 0 ? zoom : 1);
  return { x: b.x - air, y: b.y - air, width: b.width + air * 2, height: b.height + air * 2 };
}

/**
 * The sharpness to start with: as sharp as the screen showed it (zoom times
 * the device's pixel ratio), and never below 2, which is what a shared picture
 * of handwriting needs to stay readable on a phone.
 */
export function defaultCaptureScale(zoom: number, devicePixelRatio: number): CaptureScale {
  const seen = Math.ceil((zoom > 0 ? zoom : 1) * (devicePixelRatio > 0 ? devicePixelRatio : 1) - 0.05);
  return Math.min(3, Math.max(2, seen)) as CaptureScale;
}

/** Largest capture, in pixels (about 5000 x 4000). */
const CAPTURE_MAX_PIXELS = 20_000_000;

/**
 * The picture's real size in pixels. A huge area at 3x is scaled down to what
 * a canvas can hold (the same limits every export obeys) rather than failing,
 * so the panel shows the size the file will actually have.
 */
export function capturePixelSize(region: CaptureRect, scale: number) {
  // Tighter than an export's cap: a capture's PNG then crosses to Android
  // (share, gallery) as one base64 string, several copies of it at once.
  const s = Math.min(
    fitScale(region.width, region.height, scale),
    Math.sqrt(CAPTURE_MAX_PIXELS / Math.max(region.width * region.height, 1))
  );
  return {
    width: Math.max(1, Math.round(region.width * s)),
    height: Math.max(1, Math.round(region.height * s)),
    scale: s,
  };
}

/**
 * Which elements a capture draws. Selection-only keeps the chosen elements,
 * plus any connector whose BOTH ends were chosen: connectors cannot be picked
 * by a box or a loop, so without this a captured diagram lost its arrows.
 */
export function captureKeep(onlyIds?: string[]): ((el: WhiteboardElement) => boolean) | undefined {
  if (!onlyIds) return undefined;
  const set = new Set(onlyIds);
  return (el) => {
    if (set.has(el.id)) return true;
    if (el.type === "connection") {
      const c = el as ConnectionElement;
      return set.has(c.source?.elementId) && set.has(c.target?.elementId);
    }
    return false;
  };
}

/** An element's box as it is drawn: its unturned box, turned by its rotation. */
function rotatedBounds(el: WhiteboardElement): CaptureRect {
  const b = getElementBounds(el);
  const rot = el.rotation || 0;
  if (!rot) return b;
  const cx = b.x + b.width / 2;
  const cy = b.y + b.height / 2;
  const pts = [
    rotatePoint(b.x, b.y, cx, cy, rot),
    rotatePoint(b.x + b.width, b.y, cx, cy, rot),
    rotatePoint(b.x, b.y + b.height, cx, cy, rot),
    rotatePoint(b.x + b.width, b.y + b.height, cx, cy, rot),
  ];
  const xs = pts.map((p) => p.x);
  const ys = pts.map((p) => p.y);
  return {
    x: Math.min(...xs),
    y: Math.min(...ys),
    width: Math.max(...xs) - Math.min(...xs),
    height: Math.max(...ys) - Math.min(...ys),
  };
}

function boundsTouch(el: WhiteboardElement, r: CaptureRect): boolean {
  // Connections store no geometry of their own; they are always kept, and the
  // serializer draws them only when both ends are present anyway.
  if (el.type === "connection") return true;
  const b = rotatedBounds(el);
  return b.x <= r.x + r.width && b.x + b.width >= r.x && b.y <= r.y + r.height && b.y + b.height >= r.y;
}

// ---------------------------------------------------------------------------
// The picture
// ---------------------------------------------------------------------------

const MASK_ID = "pn-capture-mask";
const PAPER_ID = "pn-capture-paper";

function num(n: number): string {
  return Number(n.toFixed(2)).toString();
}

/**
 * The capture as a standalone SVG whose viewBox is the area itself.
 *
 * Notebook sheets are painted by the export's own `sheetSvg`, each clipped to
 * its paper, so the gap between two sheets stays empty (transparent) exactly
 * as it is empty desk on screen. A whiteboard's paper has no edge, so its
 * colour and ruling simply fill the area, tiled from the world origin the way
 * the canvas tiles it.
 */
export function buildCaptureSvg(
  src: CaptureSource,
  look: CaptureLook,
  customLinkTypes: Array<{ id: string; name: string; color: string }> = [],
  resolvedImages?: Map<string, string>,
  backdrops?: Map<string, string>,
  /** The canvas' own text boxes and their fonts (see collectLiveText). */
  live?: LiveText
): { svg: string; width: number; height: number; report: ExportReport } {
  const { board, region } = src;
  const report: ExportReport = { missingImages: 0, missingPdfPages: 0, pages: 1 };
  const tone = look.dark ? "dark" : "white";
  // Default-coloured text follows the paper it will sit on.
  const inkTone = look.background === "white" ? "white" : tone;
  const keep = captureKeep(src.onlyIds);
  const liveMarkup = live?.markup;
  const override = liveMarkup?.size
    ? (el: WhiteboardElement) => liveMarkup.get(el.id) ?? null
    : undefined;
  const areaRect = (fill: string) =>
    `<rect x="${num(region.x)}" y="${num(region.y)}" width="${num(region.width)}" height="${num(region.height)}" fill="${fill}" />`;

  // The canvas' fonts, embedded: an SVG drawn as an image cannot load the
  // page's web fonts, and text would fall back to a serif.
  let defs = live?.fontCss ? `<style><![CDATA[\n${live.fontCss}\n]]></style>` : "";
  let body = "";

  if (isNotebook(board)) {
    const { width, height } = pageSizeOf(board);
    const sheets = sheetsInRegion(board, src.anchorIndex, region);
    report.pages = sheets.length;
    const layers: SheetLayers =
      look.background === "page"
        ? { keep, override }
        : look.background === "white"
          ? { paper: "#ffffff", ruling: false, keep, override }
          : { paper: false, ruling: false, backdrop: false, keep, override };
    // White means white: the desk showing between two sheets too.
    if (look.background === "white") body += `  ${areaRect("#ffffff")}\n`;
    for (const s of sheets) {
      body += sheetSvg(
        board, s.page, s.index, s.offsetY, width, height,
        { background: inkTone }, customLinkTypes, resolvedImages, backdrops, report, false, layers
      );
    }
  } else {
    if (look.background === "page") {
      const paper = paperFor(board, null, tone);
      const own = board.background?.color;
      const preset = BOARD_BACKGROUNDS.find((b) => b.id === own);
      const hasColour = preset ? !!(look.dark ? preset.dark : preset.light) : !!own;
      // No colour of its own: the canvas shows the theme's background.
      body += `  ${areaRect(hasColour ? paper.fill : look.dark ? THEME_DARK_BG : "#ffffff")}\n`;
      const pattern = paperPatternSvg(PAPER_ID, paper);
      if (pattern) {
        defs += pattern;
        body += `  ${areaRect(`url(#${PAPER_ID})`)}\n`;
      }
    } else if (look.background === "white") {
      body += `  ${areaRect("#ffffff")}\n`;
    }
    const elements = getBoardElements(board).filter((el) => !keep || keep(el));
    body += serializeElements(elements, inkTone, customLinkTypes, resolvedImages, report, override);
  }

  const poly = src.polygon && src.polygon.length >= 3 ? src.polygon : null;
  if (poly) {
    defs += `<clipPath id="${MASK_ID}"><polygon points="${poly.map((p) => `${num(p.x)},${num(p.y)}`).join(" ")}" /></clipPath>`;
    body = `  <g clip-path="url(#${MASK_ID})">\n${body}  </g>\n`;
  }

  const svg = `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="${num(region.x)} ${num(region.y)} ${num(region.width)} ${num(region.height)}" width="${num(region.width)}" height="${num(region.height)}">
${SVG_HEAD_STYLE}
  ${defs ? `<defs>${defs}</defs>` : ""}
${body}</svg>`;
  return { svg, width: region.width, height: region.height, report };
}

/** Pictures and PDF pages a capture needs, fetched once per sharpness. */
export interface CaptureAssets {
  images: Map<string, string>;
  backdrops: Map<string, string>;
}

/**
 * Loads only what the area touches: the pictures that overlap it and the PDF
 * pages of the sheets under it, the PDF rendered at the capture's own density
 * so a crop of a slide is as crisp as the ink over it.
 */
export async function resolveCaptureAssets(src: CaptureSource, scale: number): Promise<CaptureAssets> {
  const { board, region } = src;
  if (isNotebook(board)) {
    const sheets = sheetsInRegion(board, src.anchorIndex, region);
    const trimmed: Board = {
      ...board,
      pages: sheets.map((s) => {
        const local = { ...region, y: region.y - s.offsetY };
        return { ...s.page, elements: (s.page.elements ?? []).filter((el) => boundsTouch(el, local)) };
      }),
    };
    const [images, backdrops] = await Promise.all([
      resolveExportImages(trimmed),
      resolvePageBackdrops(sheets.map((s) => s.page), pageSizeOf(board).width, scale),
    ]);
    return { images, backdrops };
  }
  const trimmed: Board = { ...board, elements: getBoardElements(board).filter((el) => boundsTouch(el, region)) };
  return { images: await resolveExportImages(trimmed), backdrops: new Map() };
}

/** The canvas' text boxes as it draws them, plus the fonts they use. */
export interface LiveText {
  /** Element id -> that element's own markup, ready to drop into the SVG. */
  markup: Map<string, string>;
  /** @font-face rules with the font files inlined. */
  fontCss: string;
}

/** Computed properties baked onto class-styled nodes inside a text box. */
const BAKED_PROPS = ["color", "background-color", "font-weight", "font-style", "text-decoration-line", "text-decoration-color"];

/**
 * The canvas' own markup for the text boxes and sticky notes in the area.
 *
 * The export serializer lays text out itself, one SVG <text> per line with
 * no wrapping, so a paragraph the canvas wraps inside its box came out as one
 * long line running off the capture - acceptable in a vector export, wrong
 * for "a picture of what I see". The canvas draws text as inline-styled HTML
 * in a <foreignObject>; reusing that exact markup makes the capture wrap,
 * clip and space every line the way the screen does.
 *
 * Two things do not survive the trip into an SVG image and are fixed here:
 * CSS variables (the fonts are `var(--font-inter)`) resolve to nothing, so
 * each is replaced by its computed value; and web fonts cannot be fetched by
 * an image, so the @font-face rules the text uses are inlined as data URLs.
 * Tailwind classes (a link's colour) are baked in as computed styles too.
 *
 * Only elements actually drawn can be read (the canvas culls, and hides the
 * one being edited); anything missing falls back to the serializer.
 */
export async function collectLiveText(src: CaptureSource): Promise<LiveText> {
  const markup = new Map<string, string>();
  if (typeof document === "undefined" || typeof XMLSerializer === "undefined") return { markup, fontCss: "" };
  const host = document.querySelector("svg[data-wb-tool]");
  if (!host) return { markup, fontCss: "" };
  const candidates = isNotebook(src.board)
    ? sheetsInRegion(src.board, src.anchorIndex, src.region).flatMap((s) => s.page.elements ?? [])
    : getBoardElements(src.board);
  const xml = new XMLSerializer();
  const families = new Set<string>();
  for (const el of candidates) {
    if (el.type !== "text" && el.type !== "sticky") continue;
    const node = host.querySelector(`g[data-element-id="${CSS.escape(el.id)}"]`);
    if (!node || !node.querySelector("foreignObject")) continue;
    const clone = node.cloneNode(true) as Element;
    const lives = [node, ...Array.from(node.querySelectorAll("*"))];
    const clones = [clone, ...Array.from(clone.querySelectorAll("*"))];
    lives.forEach((live, k) => {
      const copy = clones[k] as HTMLElement | undefined;
      const inline = (live as HTMLElement).style;
      if (!copy?.style || !inline) return;
      const computed = getComputedStyle(live);
      for (let n = 0; n < inline.length; n++) {
        const prop = inline[n];
        if (inline.getPropertyValue(prop).includes("var(")) copy.style.setProperty(prop, computed.getPropertyValue(prop));
      }
      if (live.closest("foreignObject")) {
        if (live.getAttribute("class")) {
          for (const prop of BAKED_PROPS) copy.style.setProperty(prop, computed.getPropertyValue(prop));
          copy.removeAttribute("class");
        }
        for (const f of computed.fontFamily.split(",")) families.add(f.trim().replace(/^["']|["']$/g, ""));
      }
    });
    clone.removeAttribute("style");
    clone.removeAttribute("data-element-id");
    markup.set(el.id, xml.serializeToString(clone));
  }
  const fontCss = markup.size ? await embedFontFaces(families) : "";
  return { markup, fontCss };
}

/** Font files already read, by URL: every capture after the first is free. */
const fontData = new Map<string, Promise<string | null>>();

function fontDataUrl(url: string): Promise<string | null> {
  let p = fontData.get(url);
  if (!p) {
    p = fetch(url)
      .then((r) => (r.ok ? r.blob() : null))
      .then(
        (b) =>
          b &&
          new Promise<string>((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(String(reader.result));
            reader.onerror = () => reject(reader.error);
            reader.readAsDataURL(b);
          })
      )
      .catch(() => null);
    fontData.set(url, p);
  }
  return p;
}

/** The page's @font-face rules for these families, with their files inlined. */
async function embedFontFaces(families: Set<string>): Promise<string> {
  if (families.size === 0) return "";
  const out: string[] = [];
  for (const sheet of Array.from(document.styleSheets)) {
    let rules: CSSRuleList;
    try {
      rules = sheet.cssRules;
    } catch {
      continue; // a cross-origin sheet; the app ships none, but never throw
    }
    for (const rule of Array.from(rules)) {
      if (!(rule instanceof CSSFontFaceRule)) continue;
      const family = rule.style.getPropertyValue("font-family").trim().replace(/^["']|["']$/g, "");
      if (!families.has(family)) continue;
      let css = rule.cssText;
      const base = sheet.href ?? document.baseURI;
      for (const m of Array.from(css.matchAll(/url\((["']?)([^"')]+)\1\)/g))) {
        if (m[2].startsWith("data:")) continue;
        const data = await fontDataUrl(new URL(m[2], base).href);
        if (data) css = css.split(m[0]).join(`url("${data}")`);
      }
      out.push(css);
    }
  }
  return out.join("\n");
}

/** How long a WebView gets to draw HTML-in-SVG before the plain path is used. */
// Generous: when it fires, the first render cannot be stopped and a second
// one starts beside it, so it must only catch a real stall, never a slow
// large capture on the tablet.
const LIVE_RASTER_TIMEOUT_MS = 15000;

/** The finished PNG, its pixel size and what it had to leave out. */
export async function renderCapture(
  src: CaptureSource,
  look: CaptureLook,
  scale: number,
  customLinkTypes: Array<{ id: string; name: string; color: string }>,
  assets: CaptureAssets,
  live?: LiveText
): Promise<{ blob: Blob; width: number; height: number; report: ExportReport }> {
  const size = capturePixelSize(src.region, scale);
  // Render at the capped scale, so the file is the size the panel showed.
  scale = size.scale;
  // The SVG paints its own background (or none): the rasteriser must not
  // fill the canvas first, or the outside of a freeform loop would not be
  // transparent.
  const draw = async (withLive?: LiveText) => {
    const built = buildCaptureSvg(src, look, customLinkTypes, assets.images, assets.backdrops, withLive);
    const blob = await rasterizeSvg(built.svg, built.width, built.height, scale, "transparent", "png", !!withLive);
    return { blob, report: built.report };
  };
  let out: { blob: Blob; report: ExportReport };
  if (live && live.markup.size > 0) {
    // HTML inside an SVG image is the one thing a WebView may stall on or
    // refuse (officeImport met the same). The plain serializer never does,
    // so it is the fallback rather than an error.
    let timer: ReturnType<typeof setTimeout> | undefined;
    try {
      out = await Promise.race([
        draw(live),
        new Promise<never>((_, reject) => {
          timer = setTimeout(() => reject(new Error("timed out")), LIVE_RASTER_TIMEOUT_MS);
        }),
      ]);
    } catch (err) {
      console.warn("[capture] Drawing the canvas' own text failed; using the export serializer.", err);
      out = await draw();
    } finally {
      clearTimeout(timer);
    }
  } else {
    out = await draw();
  }
  return { blob: out.blob, width: size.width, height: size.height, report: out.report };
}

/** e.g. `Physics_notes_capture_2026-09-29_143205.png`. */
export function captureFilename(boardName: string, when: Date = new Date()): string {
  const base = (boardName || "capture").replace(/[^a-z0-9-_ ]/gi, "_").trim().replace(/ +/g, "_") || "capture";
  const p = (n: number) => String(n).padStart(2, "0");
  // Seconds too: screenshot mode takes several in a row, and the gallery
  // would otherwise rename them "(1)", "(2)".
  const stamp = `${when.getFullYear()}-${p(when.getMonth() + 1)}-${p(when.getDate())}_${p(when.getHours())}${p(when.getMinutes())}${p(when.getSeconds())}`;
  return `${base}_capture_${stamp}.png`;
}
