/**
 * Speech-to-Text & Live Voice Dictation Controller
 * =================================================
 * Provides continuous speech recognition and real-time transcription
 * streaming directly into ProNotes text boxes and sticky notes.
 *
 * Supports Web Speech API (Chrome, Edge, Safari, Android WebView)
 * with graceful fallback and user feedback.
 *
 * Key design patterns (from react-speech-recognition & annyang):
 *  - Auto-restart on natural `onend` (Android WebView kills recognition
 *    after ~10-60s of silence even with continuous:true)
 *  - `manualStop` flag to distinguish user-initiated stop from engine timeout
 *  - Restart debounce to prevent rapid onend→start() crash loops
 *  - Max restart limit to prevent infinite restart loops on broken sessions
 *  - Clearing interim text when final results arrive or session ends
 *  - Filtering "aborted" errors triggered by our own abort() cleanup calls
 */

// Web Speech API Types
interface SpeechRecognitionErrorEvent extends Event {
  readonly error: string;
  readonly message?: string;
}

interface SpeechRecognitionAlternative {
  readonly transcript: string;
  readonly confidence: number;
}

interface SpeechRecognitionResult {
  readonly isFinal: boolean;
  readonly length: number;
  item(index: number): SpeechRecognitionAlternative;
  [index: number]: SpeechRecognitionAlternative;
}

interface SpeechRecognitionResultList {
  readonly length: number;
  item(index: number): SpeechRecognitionResult;
  [index: number]: SpeechRecognitionResult;
}

interface SpeechRecognitionEvent extends Event {
  readonly resultIndex: number;
  readonly results: SpeechRecognitionResultList;
}

interface ISpeechRecognition extends EventTarget {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  maxAlternatives: number;
  start(): void;
  stop(): void;
  abort(): void;
  onaudiostart: ((this: ISpeechRecognition, ev: Event) => void) | null;
  onsoundstart: ((this: ISpeechRecognition, ev: Event) => void) | null;
  onspeechstart: ((this: ISpeechRecognition, ev: Event) => void) | null;
  onspeechend: ((this: ISpeechRecognition, ev: Event) => void) | null;
  onsoundend: ((this: ISpeechRecognition, ev: Event) => void) | null;
  onaudioend: ((this: ISpeechRecognition, ev: Event) => void) | null;
  onresult: ((this: ISpeechRecognition, ev: SpeechRecognitionEvent) => void) | null;
  onnomatch: ((this: ISpeechRecognition, ev: Event) => void) | null;
  onerror: ((this: ISpeechRecognition, ev: SpeechRecognitionErrorEvent) => void) | null;
  onstart: ((this: ISpeechRecognition, ev: Event) => void) | null;
  onend: ((this: ISpeechRecognition, ev: Event) => void) | null;
}

type SpeechRecognitionConstructor = new () => ISpeechRecognition;

export type SpeechStatus =
  | "idle"
  | "requesting-permission"
  | "listening"
  | "processing"
  | "unsupported"
  | "error";

export interface FinalOpts {
  /**
   * True when this final CONTINUES the previous one (the engine re-sent the
   * sentence-so-far with more words: "how" then "how to"). The receiver
   * should revise the previously inserted chunk in place, not append.
   */
  revisesPrevious: boolean;
}

export interface SpeechListenerOptions {
  onInterim?: (interim: string) => void;
  onFinal?: (finalText: string, opts?: FinalOpts) => void;
  onError?: (error: string) => void;
  onStatusChange?: (status: SpeechStatus) => void;
  lang?: string;
}

/** Languages the dictation picker offers. BCP-47 ids, as Web Speech expects. */
export const SUPPORTED_DICTATION_LANGS: Array<{ id: string; label: string }> = [
  { id: "en-US", label: "English" },
  { id: "he-IL", label: "עברית" },
  { id: "ar-SA", label: "العربية" },
  { id: "ru-RU", label: "Русский" },
  { id: "es-ES", label: "Español" },
  { id: "fr-FR", label: "Français" },
  { id: "de-DE", label: "Deutsch" },
  { id: "it-IT", label: "Italiano" },
];

export const DEFAULT_DICTATION_LANG = "en-US";

/**
 * Resolves a preferred language to one the picker supports: exact id wins,
 * then a bare base language ("he" -> "he-IL"), else the default.
 */
export function resolveDictationLang(pref: string | undefined | null): string {
  if (pref) {
    const exact = SUPPORTED_DICTATION_LANGS.find((l) => l.id.toLowerCase() === pref.toLowerCase());
    if (exact) return exact.id;
    const base = pref.split(/[-_]/)[0]?.toLowerCase();
    if (base) {
      const byBase = SUPPORTED_DICTATION_LANGS.find(
        (l) => l.id.split("-")[0]?.toLowerCase() === base
      );
      if (byBase) return byBase.id;
    }
  }
  return DEFAULT_DICTATION_LANG;
}

export function isSpeechRecognitionSupported(): boolean {
  if (typeof window === "undefined") return false;
  const w = window as unknown as {
    SpeechRecognition?: SpeechRecognitionConstructor;
    webkitSpeechRecognition?: SpeechRecognitionConstructor;
  };
  return !!(w.SpeechRecognition || w.webkitSpeechRecognition);
}

/**
 * Explicitly requests microphone audio permission via getUserMedia.
 * This triggers the browser or Android system permission dialog
 * ("Allow ProNotes to record audio?").
 */
/** Set once the microphone has been granted in this app session. */
let micGranted = false;

export async function requestMicrophonePermission(): Promise<{ granted: boolean; error?: string }> {
  if (typeof navigator === "undefined" || !navigator.mediaDevices?.getUserMedia) {
    // If mediaDevices is unavailable, fallback directly to Web Speech API
    return { granted: true };
  }
  // Opening the mic just to close it again costs ~0.3-1 s on the tablet before
  // a single word is heard. Once granted, every later Dictate starts at once.
  if (micGranted) return { granted: true };

  try {
    // Processing flags help the engine "hear well" on noisy tablets: echo
    // cancellation, background-noise suppression and auto gain are all free
    // on Chrome/Edge/Android WebView and ignored where unsupported.
    const stream = await navigator.mediaDevices.getUserMedia({
      audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
    });
    // Stop all audio tracks immediately so the microphone is released for speech recognition
    stream.getTracks().forEach((track) => track.stop());
    micGranted = true;
    return { granted: true };
  } catch (err: unknown) {
    const error = err as { name?: string; message?: string };
    if (error?.name === "NotAllowedError" || error?.name === "PermissionDeniedError") {
      return {
        granted: false,
        error: "Microphone permission was denied. Please allow microphone access in your device or browser settings.",
      };
    }
    return {
      granted: false,
      error: error?.message || "Could not access microphone.",
    };
  }
}

/**
 * Max auto-restarts in a row where the engine died almost at once (under
 * QUICK_END_MS, nothing heard). That is a broken engine, not a pause.
 *
 * It used to cap EVERY restart at 5 - but Android ends a session after a few
 * seconds of quiet, so thinking for ~30 s silently switched dictation off.
 * Pauses are now limited by time instead (SILENCE_LIMIT_MS).
 */
const MAX_QUICK_FAILS = 4;
const QUICK_END_MS = 1500;

/** Dictation turns itself off after this long with nothing heard. */
export const SILENCE_LIMIT_MS = 90_000;

/** After Stop, finals still arriving within this window are kept. */
const STOP_DRAIN_MS = 1200;

/** A "network" error is retried this many times in a row before giving up. */
const MAX_NETWORK_RETRIES = 3;

/**
 * Minimum ms between auto-restart attempts.
 * annyang uses 1000ms based on years of production use — rapid restarts cause
 * runaway CPU usage and browser rate-limits on mobile WebView.
 */
const RESTART_DEBOUNCE_MS = 1000;

/** Errors that should NOT trigger the error UI (they are expected/internal) */
const SILENT_ERRORS = new Set(["no-speech", "aborted"]);

/** Errors that should NOT trigger auto-restart (terminal conditions) */
const FATAL_ERRORS = new Set(["not-allowed", "service-not-allowed", "audio-capture", "language-not-supported"]);

/**
 * A small ring of recent engine events, readable on the tablet as
 * `window.__dictationLog` (e.g. over remote DevTools) - so "it missed my
 * words" can be checked against what the engine actually sent.
 */
function logDictation(ev: string, detail?: unknown) {
  if (typeof window === "undefined") return;
  const w = window as unknown as { __dictationLog?: Array<{ t: number; ev: string; detail?: unknown }> };
  const log = (w.__dictationLog ??= []);
  log.push({ t: Date.now(), ev, detail });
  if (log.length > 300) log.splice(0, log.length - 300);
}

/** How long a repeated final phrase still counts as the engine's echo. */
export const REPEAT_FINAL_WINDOW_MS = 3000;

/**
 * True when `text` is the engine repeating the phrase it just delivered.
 *
 * Android's recogniser sometimes reports one phrase twice. The old guard
 * dropped the second of ANY two final-only results in a row, without looking
 * at the words - but Android delivers most phrases final-only, so every other
 * sentence you spoke was silently thrown away. Only a true repeat - same
 * words, moments later - is dropped now.
 */
export function isRepeatedFinal(
  prevText: string,
  prevAt: number,
  text: string,
  now: number,
  ignoreWindow = false
): boolean {
  const norm = normTranscript(text);
  return norm !== "" && norm === prevText && (ignoreWindow || now - prevAt < REPEAT_FINAL_WINDOW_MS);
}

/** Lowercase, trimmed, inner whitespace collapsed — the comparison form. */
export function normTranscript(text: string): string {
  return text.trim().toLowerCase().replace(/\s+/g, " ");
}

/** One word, comparison form: lowercase, no surrounding punctuation. */
function normWord(w: string): string {
  return w.toLowerCase().replace(/^[^\p{L}\p{N}]+|[^\p{L}\p{N}]+$/gu, "");
}

/**
 * True when `text` is the engine re-sending the sentence-so-far — grown
 * ("how" -> "how to") OR with an earlier word revised ("are you want to
 * fix the" -> "are you going to fix the problem") — rather than a new
 * phrase. The two must share at least one leading word and the new final
 * must not be shorter (a shrink is treated as a new phrase: revising would
 * delete confirmed words). A repeat outside the echo window is a new
 * phrase, and "yes" -> "yesterday" shares no whole word, so it is not one.
 *
 * Known trade-off, same class as the exact-echo drop: two deliberate
 * utterances sharing leading words inside 3s ("I want tea" … "I want
 * coffee") merge into one. Continuous speech revises far more often than
 * people repeat sentence starts, so revising wins.
 *
 * `prevText` must already be in `normTranscript` form (as stored below).
 */
export function isContinuationOfFinal(
  prevText: string,
  prevAt: number,
  text: string,
  now: number,
  ignoreWindow = false
): boolean {
  const norm = normTranscript(text);
  if (norm === "" || prevText === "") return false;
  if (!ignoreWindow && now - prevAt >= REPEAT_FINAL_WINDOW_MS) return false;
  if (norm === prevText) return false;
  const prevWords = prevText.split(" ");
  const nextWords = norm.split(" ");
  if (nextWords.length < prevWords.length) return false;
  let common = 0;
  while (common < prevWords.length && normWord(nextWords[common]) === normWord(prevWords[common])) {
    // Guard a word that normalises to nothing (e.g. "--"): it must not
    // count as a shared word, or "--" -> "-- x" would revise on punctuation.
    if (normWord(nextWords[common]) === "") break;
    common++;
  }
  return common >= 1;
}

/** Where the last dictated chunk was inserted (editor coordinates). */
export interface DictationRange {
  start: number;
  length: number;
}

/**
 * Splices one dictated chunk into the text, pure and unit-tested.
 *
 * Append is the default. When `revisesPrevious` is set and the cursor is
 * still parked exactly where the last chunk landed (the user did not type
 * or tap elsewhere in between), the previous chunk is first removed and the
 * fuller text inserted at the same spot — so "how" + "how to" becomes
 * "how to ", never "how how to ". Anything else falls back to a plain
 * append at the cursor/selection.
 */
export function spliceDictationChunk(
  current: string,
  selStart: number,
  selEnd: number,
  chunk: string,
  last: DictationRange | null,
  revisesPrevious: boolean
): { text: string; cursor: number; range: DictationRange } {
  let base = current;
  let at = selStart;
  let end = selEnd;
  if (
    revisesPrevious &&
    last &&
    selEnd === selStart &&
    selStart === last.start + last.length &&
    last.start >= 0 &&
    last.start + last.length <= current.length
  ) {
    base = current.slice(0, last.start) + current.slice(last.start + last.length);
    at = last.start;
    end = last.start;
  }
  const before = base.slice(0, at);
  const after = base.slice(end);
  const trimmed = chunk.trim();
  const addSpace = before.length > 0 && !before.endsWith(" ") && !before.endsWith("\n") ? " " : "";
  const insertion = `${addSpace}${trimmed} `;
  return { text: before + insertion + after, cursor: at + insertion.length, range: { start: at, length: insertion.length } };
}

/**
 * Takes the live (not yet final) words back out of the text. They sit in
 * `range`; the caret goes to where they started, which is exactly where the
 * final — or the next interim — belongs.
 */
export function stripInterim(
  value: string,
  selStart: number,
  selEnd: number,
  range: DictationRange | null
): { value: string; selStart: number; selEnd: number } {
  if (!range || range.start < 0 || range.start + range.length > value.length) {
    return { value, selStart, selEnd };
  }
  return {
    value: value.slice(0, range.start) + value.slice(range.start + range.length),
    selStart: range.start,
    selEnd: range.start,
  };
}

/**
 * Shows the words being heard right now IN the text, replacing the previous
 * interim. Returns the new text, caret and range (null when nothing is heard).
 */
export function placeInterim(
  value: string,
  selStart: number,
  selEnd: number,
  prev: DictationRange | null,
  interim: string
): { text: string; cursor: number; range: DictationRange | null } {
  const base = stripInterim(value, selStart, selEnd, prev);
  const words = interim.trim();
  if (!words) return { text: base.value, cursor: base.selStart, range: null };
  const before = base.value.slice(0, base.selStart);
  const after = base.value.slice(base.selEnd);
  const lead = before.length > 0 && !/\s$/.test(before) ? " " : "";
  const insertion = lead + words;
  return {
    text: before + insertion + after,
    cursor: base.selStart + insertion.length,
    range: { start: base.selStart, length: insertion.length },
  };
}

export class VoiceDictationController {
  private recognition: ISpeechRecognition | null = null;
  private status: SpeechStatus = "idle";
  private options: SpeechListenerOptions = {};
  private errorMessage: string = "";

  // ── Auto-restart state ──
  /** True when user explicitly called stop()/abort() — prevents auto-restart */
  private manualStop: boolean = false;
  /** Timer handle for debounced restart */
  private restartTimer: ReturnType<typeof setTimeout> | null = null;
  /** Whether the last onerror was a fatal (non-restartable) error */
  private lastErrorWasFatal: boolean = false;
  /** Timestamp of the last .start() call (for debounce calculation) */
  private lastStartedAt: number = 0;

  // ── Duplicate detection (see isRepeatedFinal) ──
  private lastFinalText: string = "";
  private lastFinalAt: number = 0;
  /**
   * Engine session counter: every startRecognitionEngine() (including an
   * auto-restart after a pause) opens a new one. Result indices restart at
   * 0 in each session, so emission memory is keyed `${session}:${index}`.
   */
  private sessionSeq: number = 0;
  /** Norm text already emitted per session+result-index: re-sends are skipped. */
  private emittedFinals: Map<string, string> = new Map();
  /**
   * True right after an auto-restart, until the first genuinely-new final
   * arrives. A pause ends the engine session; the new session routinely
   * re-sends what was already written (exact or grown), NO MATTER how long
   * the pause was — so the time window is ignored while this is set.
   */
  private catchUp: boolean = false;
  /** Norms of recently emitted chunks (capped): the catch-up echo check. */
  private recentChunks: string[] = [];
  /** The words heard but not yet final: written as final if you stop mid-phrase. */
  private pendingInterim: string = "";
  /** Last time anything was heard (speech, interim or final). */
  private lastHeardAt: number = 0;
  /** Quick-death restarts in a row (see MAX_QUICK_FAILS). */
  private quickFails: number = 0;
  private networkRetries: number = 0;
  /** After stop(): the old engine may still deliver the last final. */
  private draining: boolean = false;
  private drainTimer: ReturnType<typeof setTimeout> | null = null;
  private heardInSession: boolean = false;

  constructor(options: SpeechListenerOptions = {}) {
    this.options = options;
  }

  public getStatus(): SpeechStatus {
    return this.status;
  }

  public getErrorMessage(): string {
    return this.errorMessage;
  }

  private setStatus(s: SpeechStatus, errorMsg: string = "") {
    this.status = s;
    this.errorMessage = errorMsg;
    this.options.onStatusChange?.(s);
    if (errorMsg) {
      this.options.onError?.(errorMsg);
    }
  }

  private clearRestartTimer() {
    if (this.restartTimer !== null) {
      clearTimeout(this.restartTimer);
      this.restartTimer = null;
    }
  }

  /**
   * Detach all event handlers from the current recognition instance
   * and null it out. Prevents stale callbacks firing on old objects.
   */
  private detachRecognition() {
    if (this.recognition) {
      this.recognition.onstart = null;
      this.recognition.onresult = null;
      this.recognition.onerror = null;
      this.recognition.onend = null;
      this.recognition.onspeechstart = null;
      this.recognition.onspeechend = null;
      this.recognition.onaudiostart = null;
      this.recognition.onaudioend = null;
      this.recognition.onsoundstart = null;
      this.recognition.onsoundend = null;
      this.recognition.onnomatch = null;
      this.recognition = null;
    }
  }

  public async start(): Promise<boolean> {
    if (typeof window === "undefined") return false;

    // Reset restart state for a fresh session
    this.manualStop = false;
    this.lastErrorWasFatal = false;
    this.lastFinalText = "";
    this.lastFinalAt = 0;
    this.sessionSeq = 0;
    this.emittedFinals.clear();
    this.catchUp = false;
    this.recentChunks = [];
    this.pendingInterim = "";
    this.lastHeardAt = Date.now();
    this.quickFails = 0;
    this.networkRetries = 0;
    this.endDrain();
    this.clearRestartTimer();
    logDictation("start", { lang: this.options.lang });

    // 1. Explicitly prompt / verify microphone permission
    this.setStatus("requesting-permission");
    const perm = await requestMicrophonePermission();
    if (!perm.granted) {
      this.setStatus(
        "error",
        perm.error || "Microphone permission is required to record speech."
      );
      return false;
    }

    return this.startRecognitionEngine();
  }

  /**
   * Internal: creates and starts the SpeechRecognition engine.
   * Separated from start() so auto-restart can call it without
   * re-requesting microphone permission. `isAutoRestart` marks a session
   * that follows a pause: its first finals are engine catch-up until proven
   * otherwise (see catchUp).
   */
  private startRecognitionEngine(isAutoRestart = false): boolean {
    const w = window as unknown as {
      SpeechRecognition?: SpeechRecognitionConstructor;
      webkitSpeechRecognition?: SpeechRecognitionConstructor;
    };

    const SpeechRec = w.SpeechRecognition || w.webkitSpeechRecognition;
    if (!SpeechRec) {
      this.setStatus(
        "unsupported",
        "Speech recognition is not available in this browser. Tip: Tap the microphone key (🎙️) on your keyboard to dictate directly."
      );
      return false;
    }

    try {
      // Clean up any previous instance
      if (this.recognition) {
        try {
          this.recognition.abort();
        } catch {
          // ignore
        }
        this.detachRecognition();
      }

      const rec = new SpeechRec();
      this.recognition = rec;
      // A new engine session: indices restart at 0, so last session's
      // emission memory must not leak into this one (cross-session repeats
      // are the catch-up check's job, below).
      this.sessionSeq++;
      this.emittedFinals.clear();
      this.catchUp = isAutoRestart;
      this.heardInSession = false;
      rec.continuous = true;
      rec.interimResults = true;
      rec.maxAlternatives = 1;
      rec.lang =
        this.options.lang ||
        (typeof navigator !== "undefined" && navigator.language) ||
        "en-US";

      rec.onstart = () => {
        logDictation("onstart", { restart: isAutoRestart });
        if (!this.draining) this.setStatus("listening");
      };
      rec.onspeechstart = () => {
        this.lastHeardAt = Date.now();
        this.heardInSession = true;
      };

      rec.onresult = (e: SpeechRecognitionEvent) => {
        // Successfully received results - reset the failure counters
        this.quickFails = 0;
        this.networkRetries = 0;
        this.lastHeardAt = Date.now();
        this.heardInSession = true;
        logDictation("onresult", {
          i: e.resultIndex,
          r: Array.from({ length: e.results.length }, (_, k) => [
            e.results[k].isFinal ? "F" : "i",
            e.results[k][0]?.transcript,
          ]),
        });

        let interim = "";
        // Finals in index order, each with its result index: the same
        // segment re-sent is the same (session, index), a new phrase never is.
        const finals: Array<{ index: number; text: string }> = [];

        for (let i = e.resultIndex; i < e.results.length; ++i) {
          const res = e.results[i];
          if (res.isFinal) {
            // Confidence is NOT used to filter: Android reports 0 for many real
            // phrases, and those were being dropped. Echoes are caught below.
            finals.push({ index: i, text: res[0].transcript });
          } else {
            interim += res[0].transcript;
          }
        }

        if (finals.length > 0) {
          const now = Date.now();
          for (const f of finals) {
            const norm = normTranscript(f.text);
            if (norm === "") continue;
            const key = `${this.sessionSeq}:${f.index}`;
            // Same segment re-sent (the engine repeats whole result lists,
            // e.g. resultIndex 0 after a long pause): never new content.
            if (this.emittedFinals.get(key) === norm) {
              continue;
            }
            if (this.catchUp) {
              // First finals after a pause/restart: an exact re-send of
              // anything recent is the engine catching up — drop it, no
              // matter how long the pause was.
              if (this.recentChunks.includes(norm)) {
                this.options.onInterim?.("");
                continue;
              }
              // A grown re-send revises the previous chunk in place.
              if (isContinuationOfFinal(this.lastFinalText, this.lastFinalAt, f.text, now, true)) {
                this.emitFinal(f.text, now, true, key, norm);
                continue;
              }
              // Genuinely new speech: append, and catch-up is over.
              this.emitFinal(f.text, now, false, key, norm);
              this.catchUp = false;
              continue;
            }
            if (isRepeatedFinal(this.lastFinalText, this.lastFinalAt, f.text, now)) {
              this.options.onInterim?.("");
              continue;
            }
            // A cumulative re-send ("how" -> "how to") revises the previous
            // chunk in place; anything else appends as a new phrase.
            const revisesPrevious = isContinuationOfFinal(this.lastFinalText, this.lastFinalAt, f.text, now);
            this.emitFinal(f.text, now, revisesPrevious, key, norm);
          }
          // Interim is always replaced by final (react-speech-recognition
          // pattern). Words AFTER the final in the same event are the next
          // phrase already starting: they stay as the new interim.
          this.pendingInterim = interim;
          if (!this.draining) this.options.onInterim?.(interim);
        } else if (interim && !this.draining) {
          this.pendingInterim = interim;
          this.options.onInterim?.(interim);
        }
      };

      rec.onerror = (e: SpeechRecognitionErrorEvent) => {
        logDictation("onerror", e.error);
        // "no-speech" and "aborted" are expected/internal — don't show UI errors
        if (SILENT_ERRORS.has(e.error) || this.draining) {
          return;
        }
        // A dropped connection mid-sentence is usually momentary: the restart
        // after onend retries it, and only repeated failures are reported.
        if (e.error === "network" && this.networkRetries < MAX_NETWORK_RETRIES) {
          this.networkRetries++;
          return;
        }

        // Track fatal errors to prevent auto-restart
        if (FATAL_ERRORS.has(e.error)) {
          this.lastErrorWasFatal = true;
        }

        let userMsg = "Speech recognition error: " + (e.error || "unknown");
        if (e.error === "not-allowed") {
          userMsg = "Microphone access was denied. Please allow microphone permission in device settings.";
        } else if (e.error === "audio-capture") {
          userMsg = "Microphone is unavailable or busy with another application.";
        } else if (e.error === "language-not-supported") {
          userMsg = "This device can't dictate in the chosen language. Pick another one from the language menu next to Dictate.";
        } else if (e.error === "network" || e.error === "service-not-allowed") {
          userMsg = "Speech service is temporarily unavailable. Tip: Tap the microphone key (🎙️) on your keyboard to speak into notes.";
        }

        this.setStatus("error", userMsg);
      };

      rec.onend = () => {
        logDictation("onend", { heard: this.heardInSession });
        if (this.draining) {
          this.endDrain();
          return;
        }
        // A session ending mid-phrase: what was heard is kept, not lost.
        this.flushInterim();
        // Always clear interim text when recognition session ends
        this.options.onInterim?.("");

        const now = Date.now();
        const quick = !this.heardInSession && now - this.lastStartedAt < QUICK_END_MS;
        this.quickFails = quick ? this.quickFails + 1 : 0;
        const tooQuiet = now - this.lastHeardAt > SILENCE_LIMIT_MS;
        if (!this.manualStop && tooQuiet && this.status === "listening") {
          this.detachRecognition();
          this.setStatus("idle");
          this.options.onError?.("Dictation stopped after 1.5 minutes of silence. Tap Dictate to continue.");
          return;
        }

        // ── Auto-restart logic ──
        // If the user manually stopped, or we hit a fatal error, or we've
        // exceeded the restart limit — go idle. Otherwise, auto-restart
        // with debounce (Android WebView regularly kills continuous sessions
        // after silence timeouts).
        if (
          this.manualStop ||
          this.lastErrorWasFatal ||
          this.status === "error" ||
          this.status === "unsupported" ||
          this.quickFails >= MAX_QUICK_FAILS
        ) {
          if (this.quickFails >= MAX_QUICK_FAILS && !this.manualStop && this.status === "listening") {
            this.options.onError?.("The speech engine keeps stopping. Tap Dictate to try again.");
          }
          if (this.status === "listening" || this.status === "processing") {
            this.setStatus("idle");
          }
          this.detachRecognition();
          return;
        }

        // Debounced auto-restart (annyang pattern: wait at least RESTART_DEBOUNCE_MS
        // since the last start, so very short sessions don't cause rapid-fire restarts)
        this.clearRestartTimer();
        const elapsed = Date.now() - this.lastStartedAt;
        const delay = Math.max(0, RESTART_DEBOUNCE_MS - elapsed);
        this.restartTimer = setTimeout(() => {
          this.restartTimer = null;
          // Double-check we weren't manually stopped during the debounce window
          if (!this.manualStop && this.status !== "error" && this.status !== "idle") {
            this.startRecognitionEngine(true);
          }
        }, delay);
      };

      this.lastStartedAt = Date.now();
      rec.start();
      return true;
    } catch (err: unknown) {
      // DOMException indicates a redundant microphone start — safe to swallow
      // (Chrome throws when recognition.start() is called while already started)
      if (typeof DOMException !== "undefined" && err instanceof DOMException) {
        return true;
      }
      const msg = (err as Error)?.message || "Failed to start speech recognition.";
      this.setStatus("error", msg);
      return false;
    }
  }

  /**
   * Writes the words heard so far as a final (used when the session ends or
   * you tap Stop mid-phrase). If the engine's real final follows, it revises
   * this in place (or is dropped as a repeat), so nothing is written twice.
   */
  private flushInterim() {
    const text = this.pendingInterim;
    this.pendingInterim = "";
    const norm = normTranscript(text);
    if (!norm) return;
    const now = Date.now();
    if (isRepeatedFinal(this.lastFinalText, this.lastFinalAt, text, now)) return;
    logDictation("flush", text);
    const revises = isContinuationOfFinal(this.lastFinalText, this.lastFinalAt, text, now);
    this.emitFinal(text, now, revises, `flush:${now}`, norm);
  }

  private endDrain() {
    if (this.drainTimer !== null) {
      clearTimeout(this.drainTimer);
      this.drainTimer = null;
    }
    if (this.draining) {
      this.draining = false;
      this.detachRecognition();
    }
  }

  /** Records one emitted final and forwards it to the editor. */
  private emitFinal(text: string, now: number, revisesPrevious: boolean, key: string, norm: string) {
    this.emittedFinals.set(key, norm);
    this.lastFinalText = norm;
    this.lastFinalAt = now;
    this.recentChunks.push(norm);
    if (this.recentChunks.length > 8) this.recentChunks.splice(0, this.recentChunks.length - 8);
    this.options.onFinal?.(text, { revisesPrevious });
  }

  /**
   * Switches the recognition language. Takes effect on the next session;
   * also applied live when the engine allows it.
   */
  public setLang(lang: string) {
    const resolved = resolveDictationLang(lang);
    this.options.lang = resolved;
    try {
      if (this.recognition) this.recognition.lang = resolved;
    } catch {
      // ignore — the next startRecognitionEngine() applies it
    }
  }

  /**
   * Stop listening, KEEPING what was being said. The words heard so far are
   * written straight away; the engine's own final for them, which arrives a
   * moment after stop(), still revises them for STOP_DRAIN_MS. (Stop used to
   * unhook the engine at once, and the last sentence was simply lost.)
   */
  public stop() {
    this.manualStop = true;
    this.clearRestartTimer();
    logDictation("stop");
    this.flushInterim();

    if (this.recognition) {
      try {
        this.recognition.stop();
      } catch {
        // ignore
      }
      this.draining = true;
      if (this.drainTimer !== null) clearTimeout(this.drainTimer);
      this.drainTimer = setTimeout(() => this.endDrain(), STOP_DRAIN_MS);
    }
    // Clear any lingering interim text
    this.options.onInterim?.("");
    this.setStatus("idle");
  }

  /** Stop at once and discard anything not yet final. */
  public abort() {
    this.manualStop = true;
    this.clearRestartTimer();
    this.pendingInterim = "";
    this.endDrain();

    if (this.recognition) {
      try {
        this.recognition.abort();
      } catch {
        // ignore
      }
      this.detachRecognition();
    }
    // Clear any lingering interim text
    this.options.onInterim?.("");
    this.setStatus("idle");
  }
}
