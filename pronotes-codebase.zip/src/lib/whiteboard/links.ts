/**
 * Wikilinks & Knowledge Graph Intelligence (v3 — Obsidian Canvas Grade)
 * ====================================================================
 * Handles:
 * - Parsing [[WikiLinks]], [[Board|Alias]], and #tags
 * - Bi-directional backlink aggregation across all boards
 * - 2D Knowledge Graph data generation with typed semantic edges
 * - Autocomplete search for WikiLinks & Connections
 */

import type {
  Board,
  TextElement,
  StickyElement,
  ConnectionElement,
  WhiteboardElement,
} from "./types";
import { getLinkTypeColor, getLinkTypeLabel } from "./types";
import { allElements } from "./notebook";

// ============================================================================
// Types
// ============================================================================

export interface Wikilink {
  target: string;
  display: string;
  start: number;
  end: number;
}

export interface Tag {
  name: string;
  start: number;
  end: number;
}

export interface ParsedText {
  links: Wikilink[];
  tags: Tag[];
}

export interface TextSegment {
  type: "text" | "link" | "tag";
  text: string;
  value?: string; // target board name or tag name
}

// ============================================================================
// Parsing
// ============================================================================

const WIKILINK_REGEX = /\[\[([^\]|]+)(?:\|([^\]]*))?\]\]/g;
// Obsidian semantics: only the first "|segment" is the display alias
const TAG_REGEX = /(?:^|\s)#([a-zA-Z][a-zA-Z0-9_-]*)/g;

export function parseText(text: string): ParsedText {
  const links: Wikilink[] = [];
  const tags: Tag[] = [];

  if (!text) return { links, tags };

  // Find wikilinks
  let match: RegExpExecArray | null;
  WIKILINK_REGEX.lastIndex = 0;
  while ((match = WIKILINK_REGEX.exec(text)) !== null) {
    const target = match[1].trim();
    if (!target) continue; // "[[ ]]" / "[[|alias]]" have no target — skip
    // "[[Target|]]" (empty alias) displays the target itself
    const alias = match[2]?.split("|")[0]?.trim();
    links.push({
      target,
      display: alias || target,
      start: match.index,
      end: match.index + match[0].length,
    });
  }

  // Find tags
  TAG_REGEX.lastIndex = 0;
  while ((match = TAG_REGEX.exec(text)) !== null) {
    const tagName = match[1].trim();
    const insideLink = links.some(
      (l) => match!.index >= l.start && match!.index < l.end
    );
    if (!insideLink) {
      tags.push({
        name: tagName,
        start: match.index,
        end: match.index + match[0].length,
      });
    }
  }

  return { links, tags };
}

export function segmentText(text: string): TextSegment[] {
  if (!text) return [];
  const { links, tags } = parseText(text);

  interface Token {
    type: "link" | "tag";
    start: number;
    end: number;
    text: string;
    value: string;
  }

  const tokens: Token[] = [
    ...links.map((l) => ({
      type: "link" as const,
      start: l.start,
      end: l.end,
      text: l.display,
      value: l.target,
    })),
    ...tags.map((t) => ({
      type: "tag" as const,
      start: t.start,
      end: t.end,
      text: `#${t.name}`,
      value: t.name,
    })),
  ].sort((a, b) => a.start - b.start);

  const segments: TextSegment[] = [];
  let cursor = 0;

  for (const token of tokens) {
    if (token.start > cursor) {
      segments.push({
        type: "text",
        text: text.slice(cursor, token.start),
      });
    }
    segments.push({
      type: token.type,
      text: token.text,
      value: token.value,
    });
    cursor = token.end;
  }

  if (cursor < text.length) {
    segments.push({
      type: "text",
      text: text.slice(cursor),
    });
  }

  return segments;
}

export function getBoardLinks(board: Board): string[] {
  const targets = new Set<string>();
  // allElements, not board.elements: a notebook keeps its content on its
  // pages and leaves the canvas field empty, so links written in a notebook
  // were invisible to backlinks, tags and the graph.
  for (const el of allElements(board)) {
    if (el.type === "text" || el.type === "sticky") {
      const text = (el as TextElement | StickyElement).text || "";
      const parsed = parseText(text);
      for (const link of parsed.links) {
        targets.add(link.target.toLowerCase());
      }
    }
  }
  return Array.from(targets);
}

export function getBoardTags(board: Board): string[] {
  const tags = new Set<string>();
  if (board.tags) {
    board.tags.forEach((t) => tags.add(t.toLowerCase()));
  }
  {
    for (const el of allElements(board)) {
      if (el.type === "text" || el.type === "sticky") {
        const text = (el as TextElement | StickyElement).text || "";
        const parsed = parseText(text);
        for (const tag of parsed.tags) {
          tags.add(tag.name.toLowerCase());
        }
      }
    }
  }
  return Array.from(tags);
}

// ============================================================================
// Backlinks Aggregator
// ============================================================================

export interface BacklinkEntry {
  sourceBoardId: string;
  sourceBoardName: string;
  elementId: string;
  target: string;
  snippet?: string;
  relationship?: string;
  color?: string;
}

export function getBacklinks(
  boards: Board[],
  targetBoardName: string,
  targetBoardId?: string,
  customLinkTypes: Array<{ id: string; name: string; color: string }> = []
): BacklinkEntry[] {
  const targetName = targetBoardName.toLowerCase();
  const backlinks: BacklinkEntry[] = [];

  for (const board of boards) {
    for (const el of allElements(board)) {
      // 1. Text & Sticky note wikilinks
      if (el.type === "text" || el.type === "sticky") {
        const text = (el as TextElement | StickyElement).text || "";
        const parsed = parseText(text);
        for (const link of parsed.links) {
          if (link.target.toLowerCase() === targetName) {
            backlinks.push({
              sourceBoardId: board.id,
              sourceBoardName: board.name,
              elementId: el.id,
              target: link.target,
              snippet: text.slice(0, 80),
              relationship: "WikiLink",
              color: "#6366f1",
            });
          }
        }
      }
      // 2. Direct semantic connection arrows
      if (el.type === "connection") {
        const conn = el as ConnectionElement;
        if (targetBoardId && (conn.target.boardId === targetBoardId || conn.source.boardId === targetBoardId)) {
          backlinks.push({
            sourceBoardId: board.id,
            sourceBoardName: board.name,
            elementId: el.id,
            target: targetBoardName,
            relationship: getLinkTypeLabel(conn.linkType, customLinkTypes),
            color: getLinkTypeColor(conn.linkType, customLinkTypes),
          });
        }
      }
    }
  }

  return backlinks;
}

// ============================================================================
// Knowledge Graph Engine
// ============================================================================

/**
 * A graph vertex is not always a whole board. When a single text box (or
 * sticky, image, shape...) is what actually carries the link, it earns its own
 * vertex, so the graph shows WHICH note points at the target rather than
 * collapsing every link on a board into one dot.
 */
export type GraphNodeKind = "board" | "folder" | "element" | "tag";

export interface GraphNode {
  id: string;
  name: string;
  outDegree: number;
  inDegree: number;
  orphan: boolean;
  starred: boolean;
  tagCount: number;
  folderId: string | null;
  color?: string;
  kind?: GraphNodeKind;
  /** For element vertices: where to navigate, and what shape to draw. */
  boardId?: string;
  elementId?: string;
  elementType?: string;
  snippet?: string;
  tags?: string[];
  folderName?: string;
}

/**
 * Element vertex ids are namespaced. Element ids are nanoid and would not
 * realistically collide with board ids, but an accidental collision would make
 * a click navigate to the wrong thing, and the prefix also makes an id
 * self-describing in a debug dump.
 */
export function elementNodeId(boardId: string, elementId: string): string {
  return `el:${boardId}:${elementId}`;
}

export function parseElementNodeId(
  id: string
): { boardId: string; elementId: string } | null {
  if (!id.startsWith("el:")) return null;
  const rest = id.slice(3);
  const cut = rest.indexOf(":");
  if (cut < 1) return null;
  return { boardId: rest.slice(0, cut), elementId: rest.slice(cut + 1) };
}

/** A short, human label for an element vertex. */
function elementLabel(el: WhiteboardElement): string {
  if (el.type === "text" || el.type === "sticky") {
    const raw = ((el as TextElement | StickyElement).text || "").trim();
    // Show what the note SAYS, with link markup rendered as its display text —
    // "[[Physics|see here]]" reads as "see here", not as markup.
    const plain = segmentText(raw)
      .map((seg) => seg.text)
      .join("")
      .replace(/[#*`>_~]/g, "")
      .replace(/\s+/g, " ")
      .trim();
    if (plain) return plain.length > 28 ? plain.slice(0, 27) + "…" : plain;
  }
  if (el.type === "image") return "Image";
  return el.type.charAt(0).toUpperCase() + el.type.slice(1);
}

export interface GraphEdge {
  id: string;
  source: string;
  target: string;
  label: string;
  linkType?: string;
  color?: string;
}

export interface GraphData {
  nodes: GraphNode[];
  edges: GraphEdge[];
}

export interface BuildGraphOptions {
  includeTags?: boolean;
  includeElements?: boolean;
}

export function buildGraph(
  boards: Board[],
  customLinkTypes: Array<{ id: string; name: string; color: string }> = [],
  folders: Array<{ id: string; name: string }> = [],
  options?: BuildGraphOptions
): GraphData {
  const nodes: GraphNode[] = [];
  const edges: GraphEdge[] = [];
  const boardNameMap = new Map<string, Board>();

  for (const board of boards) {
    boardNameMap.set(board.name.toLowerCase(), board);
  }

  const folderMap = new Map<string, string>();
  for (const f of folders) {
    folderMap.set(f.id, f.name);
  }

  // Every id the graph can draw a node for. The Link Manager stores the REAL
  // endpoint (a board id OR a folder id) in `elementId`; `boardId` is only the
  // board the connection is filed under. Resolving through this set is what
  // lets folder endpoints reach the graph at all.
  const graphNodeIds = new Set<string>([
    ...boards.map((b) => b.id),
    ...folders.map((f) => f.id),
  ]);

  const inDegrees = new Map<string, number>();
  for (const board of boards) {
    inDegrees.set(board.id, 0);
  }

  // Element vertices: any element that actually carries a link gets its own
  // node, so the graph answers "which note points at this?" instead of only
  // "which board". Elements with no links stay out — a vertex per shape would
  // bury the structure under noise.
  const elementNodes = new Map<string, GraphNode>();
  const addElementNode = (board: Board, el: WhiteboardElement): string => {
    const id = elementNodeId(board.id, el.id);
    if (!elementNodes.has(id)) {
      const rawText = (el.type === "text" || el.type === "sticky")
        ? ((el as TextElement | StickyElement).text || "").trim()
        : "";
      const snippet = rawText ? (rawText.length > 120 ? rawText.slice(0, 117) + "…" : rawText) : undefined;
      const parsedEl = rawText ? parseText(rawText) : { links: [], tags: [] };
      const elTags = parsedEl.tags.map((t) => t.name);

      elementNodes.set(id, {
        id,
        name: elementLabel(el),
        outDegree: 0,
        inDegree: 0,
        orphan: false,
        starred: false,
        tagCount: elTags.length,
        folderId: board.folderId,
        folderName: board.folderId ? folderMap.get(board.folderId) : undefined,
        kind: "element",
        boardId: board.id,
        elementId: el.id,
        elementType: el.type,
        snippet,
        tags: elTags,
      });
      inDegrees.set(id, inDegrees.get(id) || 0);
    }
    return id;
  };

  // 1. Edges from WikiLinks — sourced at the ELEMENT that contains the link.
  for (const board of boards) {
    for (const el of allElements(board)) {
      if (el.type !== "text" && el.type !== "sticky") continue;
      const text = (el as TextElement | StickyElement).text || "";
      const { links } = parseText(text);
      for (const link of links) {
        const targetBoard = boardNameMap.get(link.target.toLowerCase());
        if (!targetBoard || targetBoard.id === board.id) continue;

        const sourceId = addElementNode(board, el);
        const edgeId = `wl-${el.id}-${targetBoard.id}-${link.target.toLowerCase()}`;
        if (edges.some((e) => e.id === edgeId)) continue;
        edges.push({
          id: edgeId,
          source: sourceId,
          target: targetBoard.id,
          label: link.display,
          linkType: "wikilink",
          color: "#6366f1",
        });
        inDegrees.set(targetBoard.id, (inDegrees.get(targetBoard.id) || 0) + 1);
      }
    }
  }

  // 2. Edges from connection arrows.
  for (const board of boards) {
    const docElements = allElements(board);
    const byId = new Map(docElements.map((e) => [e.id, e]));
    for (const el of docElements) {
      if (el.type !== "connection") continue;
      const conn = el as ConnectionElement;

      const endpointNode = (ep: { boardId: string; elementId: string }): string | null => {
        if (ep.elementId && graphNodeIds.has(ep.elementId)) return ep.elementId;
        const target = byId.get(ep.elementId);
        if (target && target.type !== "connection") return addElementNode(board, target);
        return ep.boardId || null;
      };

      const sNode = endpointNode(conn.source);
      const tNode = endpointNode(conn.target);
      if (!sNode || !tNode || sNode === tNode) continue;

      const edgeId = `conn-${conn.id}`;
      if (edges.some((e) => e.id === edgeId)) continue;
      edges.push({
        id: edgeId,
        source: sNode,
        target: tNode,
        label: conn.label || getLinkTypeLabel(conn.linkType, customLinkTypes),
        linkType: conn.linkType,
        color: getLinkTypeColor(conn.linkType, customLinkTypes),
      });
      inDegrees.set(tNode, (inDegrees.get(tNode) || 0) + 1);
    }
  }

  // 3. Board vertices
  for (const board of boards) {
    const outDegree = edges.filter((e) => e.source === board.id).length;
    const inDegree = inDegrees.get(board.id) || 0;
    let snippet: string | undefined;
    for (const el of allElements(board)) {
      if (el.type === "text" || el.type === "sticky") {
        const raw = ((el as TextElement | StickyElement).text || "").trim();
        if (raw) {
          snippet = raw.length > 120 ? raw.slice(0, 117) + "…" : raw;
          break;
        }
      }
    }

    nodes.push({
      id: board.id,
      name: board.name,
      outDegree,
      inDegree,
      orphan: outDegree === 0 && inDegree === 0,
      starred: !!board.starred,
      tagCount: (board.tags || []).length,
      folderId: board.folderId,
      folderName: board.folderId ? folderMap.get(board.folderId) : undefined,
      color: board.color || "#3b82f6",
      kind: "board",
      snippet,
      tags: board.tags || [],
    });
  }

  // 4. Element vertices
  for (const node of elementNodes.values()) {
    node.outDegree = edges.filter((e) => e.source === node.id).length;
    node.inDegree = inDegrees.get(node.id) || 0;
    nodes.push(node);
    edges.push({
      id: `owns-${node.id}`,
      source: node.boardId!,
      target: node.id,
      label: "",
      linkType: "contains",
      color: "#9ca3af",
    });
  }

  // 5. Tag vertices (Obsidian Canvas Grade Tag Clustering)
  if (options?.includeTags) {
    const tagToSources = new Map<string, Set<string>>();
    for (const board of boards) {
      for (const t of board.tags || []) {
        const norm = t.toLowerCase().replace(/^#/, "");
        if (!tagToSources.has(norm)) tagToSources.set(norm, new Set());
        tagToSources.get(norm)!.add(board.id);
      }
      for (const el of allElements(board)) {
        if (el.type === "text" || el.type === "sticky") {
          const parsed = parseText((el as TextElement | StickyElement).text || "");
          for (const t of parsed.tags) {
            const norm = t.name.toLowerCase().replace(/^#/, "");
            if (!tagToSources.has(norm)) tagToSources.set(norm, new Set());
            tagToSources.get(norm)!.add(board.id);
          }
        }
      }
    }

    for (const [tagNorm, sourceIds] of tagToSources.entries()) {
      if (sourceIds.size === 0) continue;
      const tagNodeId = `tag:${tagNorm}`;
      nodes.push({
        id: tagNodeId,
        name: `#${tagNorm}`,
        outDegree: 0,
        inDegree: sourceIds.size,
        orphan: false,
        starred: false,
        tagCount: 0,
        folderId: null,
        color: "#10b981", // vibrant emerald
        kind: "tag",
      });

      for (const sourceId of sourceIds) {
        edges.push({
          id: `tag-edge-${sourceId}-${tagNorm}`,
          source: sourceId,
          target: tagNodeId,
          label: `#${tagNorm}`,
          linkType: "tag",
          color: "#10b981",
        });
      }
    }
  }

  return { nodes, edges };
}

/**
 * Filter graph down to a neighborhood around a focus node up to a given hop depth.
 */
export function filterGraphNeighborhood(
  graph: GraphData,
  focusNodeId: string,
  depth: number = 1
): GraphData {
  if (!focusNodeId || depth <= 0) return graph;
  const includedNodeIds = new Set<string>([focusNodeId]);
  let frontier = new Set<string>([focusNodeId]);

  // A board and its note elements are one entity: seed all owned elements
  for (const edge of graph.edges) {
    if (edge.linkType === "contains") {
      if (edge.source === focusNodeId) {
        includedNodeIds.add(edge.target);
        frontier.add(edge.target);
      } else if (edge.target === focusNodeId) {
        includedNodeIds.add(edge.source);
        frontier.add(edge.source);
      }
    }
  }

  for (let d = 0; d < depth; d++) {
    const nextFrontier = new Set<string>();
    for (const edge of graph.edges) {
      if (frontier.has(edge.source) && !includedNodeIds.has(edge.target)) {
        includedNodeIds.add(edge.target);
        nextFrontier.add(edge.target);
        // Include elements owned by newly reached board
        for (const c of graph.edges) {
          if (c.linkType === "contains" && c.source === edge.target) {
            includedNodeIds.add(c.target);
            nextFrontier.add(c.target);
          }
        }
      }
      if (frontier.has(edge.target) && !includedNodeIds.has(edge.source)) {
        includedNodeIds.add(edge.source);
        nextFrontier.add(edge.source);
        // Include board owning newly reached element
        for (const c of graph.edges) {
          if (c.linkType === "contains" && c.target === edge.source) {
            includedNodeIds.add(c.source);
            nextFrontier.add(c.source);
          }
        }
      }
    }
    frontier = nextFrontier;
  }

  const nodes = graph.nodes.filter((n) => includedNodeIds.has(n.id));
  const edges = graph.edges.filter(
    (e) => includedNodeIds.has(e.source) && includedNodeIds.has(e.target)
  );

  return { nodes, edges };
}

/**
 * Local Board Elements Graph
 * Generates an interactive graph of all cards, sticky notes, shapes, and connections on a specific board.
 */
export function buildBoardLocalGraph(
  board: Board | null | undefined,
  customLinkTypes: Array<{ id: string; name: string; color: string }> = []
): GraphData {
  const docElements = allElements(board);
  if (!board || docElements.length === 0) {
    return { nodes: [], edges: [] };
  }

  const nodes: GraphNode[] = [];
  const edges: GraphEdge[] = [];
  const inDegrees = new Map<string, number>();

  const elementMap = new Map<string, string>(); // elementId -> displayName

  // 1. Create nodes for all non-connection elements
  for (const el of docElements) {
    if (el.type === "connection") continue;

    let name = "Element";
    let color = "#3b82f6";

    if (el.type === "text") {
      const text = (el as TextElement).text || "Text Note";
      name = text.split("\n")[0].slice(0, 30) || "Text Note";
      color = (el as TextElement).color || "#6366f1";
    } else if (el.type === "sticky") {
      const text = (el as StickyElement).text || "Sticky Note";
      name = text.split("\n")[0].slice(0, 30) || "Sticky Note";
      color = "#eab308";
    } else if (el.type === "image") {
      name = "Image";
      color = "#ec4899";
    } else {
      name = el.type.charAt(0).toUpperCase() + el.type.slice(1);
      color = (el as { strokeColor?: string }).strokeColor || "#10b981";
    }

    elementMap.set(el.id, name);
    inDegrees.set(el.id, 0);

    nodes.push({
      id: el.id,
      name,
      outDegree: 0,
      inDegree: 0,
      orphan: true,
      starred: false,
      tagCount: 0,
      folderId: null,
      color,
    });
  }

  // 2. Build edges from connections
  for (const el of docElements) {
    if (el.type === "connection") {
      const conn = el as ConnectionElement;
      const sId = conn.source.elementId;
      const tId = conn.target.elementId;

      if (sId && tId && elementMap.has(sId) && elementMap.has(tId)) {
        const edgeId = `conn-${conn.id}`;
        edges.push({
          id: edgeId,
          source: sId,
          target: tId,
          label: conn.label || getLinkTypeLabel(conn.linkType, customLinkTypes),
          linkType: conn.linkType,
          color: getLinkTypeColor(conn.linkType, customLinkTypes),
        });
        inDegrees.set(tId, (inDegrees.get(tId) || 0) + 1);
      }
    }
  }

  // 3. Update degree and orphan status
  for (const node of nodes) {
    const outDegree = edges.filter((e) => e.source === node.id).length;
    const inDegree = inDegrees.get(node.id) || 0;
    node.outDegree = outDegree;
    node.inDegree = inDegree;
    node.orphan = outDegree === 0 && inDegree === 0;
  }

  return { nodes, edges };
}

