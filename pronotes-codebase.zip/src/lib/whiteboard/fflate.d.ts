/**
 * Minimal declarations for the fflate functions ProNotes uses.
 * fflate ships no bundled types; this covers zip-building only.
 */
declare module "fflate" {
  export function zipSync(data: Record<string, Uint8Array>, options?: unknown): Uint8Array;
  export function unzipSync(data: Uint8Array): Record<string, Uint8Array>;
  export function strToU8(str: string): Uint8Array;
  export function strFromU8(data: Uint8Array): string;
}
