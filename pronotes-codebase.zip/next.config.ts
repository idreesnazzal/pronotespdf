import { readFileSync } from "node:fs";
import { join } from "node:path";
import type { NextConfig } from "next";
import { PHASE_DEVELOPMENT_SERVER } from "next/constants";

/**
 * The app's version, read from THIS FILE's directory rather than imported.
 *
 * `import pkg from "./package.json"` looks right and works when `next` is run
 * from the repository root - but Next transpiles this config and resolves that
 * specifier against the process's working directory, so starting the dev
 * server from anywhere else died on startup with MODULE_NOT_FOUND before it
 * printed a single useful line. Reading from __dirname is cwd-proof, and it
 * also keeps package.json out of the bundle.
 */
const pkg = JSON.parse(readFileSync(join(__dirname, "package.json"), "utf8")) as { version: string };

/**
 * The packaged apps need a fully static export: there is no Node server
 * inside an APK, and the Electron app loads ./out through its own
 * `pronotes://` scheme. Plain `next build` keeps the server build so that
 * `npm start` still works.
 *
 * So the export mode is opt-in via an env flag rather than always-on:
 *   npm run build     -> server build, for `npm start`
 *   npm run export    -> static export into ./out (scripts/build-static.mjs)
 *   npm run apk       -> export, then the Android APK
 *   npm run dist:win  -> export, then the Windows installer
 */
const isStaticExport = process.env.PRONOTES_STATIC === "1";

const nextConfig = (phase: string): NextConfig => {
  return {
    // The DEV SERVER gets its own build directory; every build keeps `.next`.
    //
    // They used to share `.next`, so running an export while `npm run dev` was
    // up deleted the dev server's manifests under it and it served 500s with a
    // different "missing" file each reload - which looked exactly like a flaky
    // Windows race and was not one.
    //
    // It is the dev server that moves, not the export: with `output: "export"`
    // Next treats `distDir` as the EXPORT DESTINATION rather than the build
    // directory. Setting it on the export (tried first) wrote the site to that
    // folder instead of ./out - which Capacitor and Electron both read - and
    // still built into `.next`.
    distDir: phase === PHASE_DEVELOPMENT_SERVER ? ".next-dev" : ".next",
    ...(isStaticExport
      ? {
          output: "export" as const,
          // next/image's optimizer needs a server; the app ships its own assets.
          images: { unoptimized: true },
        }
      : {}),
    typescript: {
      // Next's own type pass runs ONLY when no wrapper already type-checked:
      // scripts/build.mjs (`npm run build`) and scripts/build-static.mjs (every
      // export: APK, Windows, desktop) run `npx tsc --noEmit` first and then set
      // PRONOTES_TYPECHECKED=1 for the child `next build`. A bare `npx next build`
      // never sets it, so broken types fail the build instead of shipping green.
      // (The emergency hatch PRONOTES_SKIP_TYPECHECK=1 deliberately leaves it
      // unset, so Next still type-checks that build.)
      ignoreBuildErrors: process.env.PRONOTES_TYPECHECKED === "1",
    },
    /**
     * What this build IS, baked in so the running app can say so.
     *
     * Installing an APK and finding nothing had changed was impossible to tell
     * apart from a fix that did not work - there was no way, on the tablet, to
     * see which build was running. Settings now shows both numbers.
     *
     * The build code is Android's versionCode, handed down by
     * scripts/build-apk.mjs; a plain export has none and says so.
     */
    env: {
      NEXT_PUBLIC_APP_VERSION: pkg.version,
      NEXT_PUBLIC_BUILD_CODE: process.env.PRONOTES_BUILD_CODE || "",
    },
    // reactStrictMode is off; reason not recorded (present since the initial commit).
    reactStrictMode: false,
  };
};

export default nextConfig;
