# ProNotes — Handoff / Start Here

**The one file to read first.** Everything about what this project is, how to run
it, what every file does, what is broken, and what is still owed.

Last updated: 2026-09-19; sidebar-pro + doc refresh in progress on
`feat/sidebar-pro` (2026-09-25, unmerged).

> Note on the other docs: `MAP.md` is the file-by-file map of the whole
> repository — read it alongside this one. `PROJECT.md` was deleted in the
> 2026-09-18 cleanup (it predated the pen rework, the settings panel, the
> eraser rewrite, Electron packaging, the APK and accounts/sync); `README.md`
> is now a short pointer rather than a stale duplicate.
> `CHANGELOG_FIXES.md` is a ~104 KB chronological log, not an overview. Its
> STEP numbers were renumbered on 2026-09-19 (two sessions had reused 21–27);
> an old -> new table is at the top of that file.

---

## 1. What it is

ProNotes is an infinite whiteboard + knowledge canvas: freehand ink, shapes,
text, sticky notes and images on a pannable/zoomable canvas, with
`[[WikiLink]]` backlinks between boards and a force-directed knowledge graph
over them.

It is **local-first**. Nothing is uploaded unless you deliberately turn on sync.

**Location:** `C:\Users\idree\Documents\pronotesdevelop`
(moved here from a scratch folder belonging to another tool, which could have
been cleaned out at any time — see "Gotchas".)

**It is a git repository** (`main`, remote
`https://github.com/idreesnazzal/pronotesdev.git`). Earlier versions of this
file said otherwise, which was wrong - `git status` / `git diff` / `git restore`
are all available. Several Claude sessions have worked on this project at the
same time; commit finished work so one session's edits cannot silently collide
with another's.

---

## 2. How to run it — three ways

### Windows desktop app (what you normally use)

Double-click the **ProNotes** desktop shortcut, or run directly:

```
C:\Users\idree\Documents\pronotesdevelop\dist-desktop\win-unpacked\ProNotes.exe
```

A real `.exe` with its own process, icon and taskbar button. No browser needed,
works fully offline. Built on Electron — the UI is drawn by a bundled Chromium,
the same way VS Code, Discord and Slack work. It is *not* a native Win32 app.

### Development (live reload, for making changes)

```bash
npm run dev
```

Then open `http://localhost:3000`.

The dev server builds into **`.next-dev`**, and every other build (`npm run
build`, `npm run export`, the APK and Windows builds) into `.next`. They used to
share `.next`, so running an export while the dev server was up deleted its
manifests and it served 500s. See `next.config.ts`.

### Android tablet

Sideload `ProNotes.apk` from the project root. App id `com.idrees.pronotes`.

---

## 3. Where your data actually lives

**Not in this project folder.** The desktop app stores everything in Electron's
user-data directory:

```
%APPDATA%\ProNotes
```

Boards are held in **IndexedDB** under that profile (database
`pronotes-workspace`, one snapshot record, gzipped past 1 MB of JSON) —
localStorage's ~5 MB hard cap once made every save fail on a large workspace,
so since 2026-09-21 the snapshot lives where the quota is a share of free
disk instead. Images and PDF bytes were already in IndexedDB. localStorage
now keeps only a tiny save heartbeat, the (separately capped, separately
keyed) undo history, and the pre-migration legacy copy, which is deleted
after the first successful IndexedDB write. This means:

- Moving, rebuilding or even deleting the project does **not** touch your notes.
- Reinstalling the app keeps your notes.
- The dev server (`localhost:3000`) has a *separate* store from the `.exe`,
  because they are different origins. Boards do not appear in both.

To move boards between devices: **Settings → Sync → Save backup** writes a
`pronotes-backup-<date>.json` containing the whole workspace.

---

## 4. Tech stack

| Layer | Choice |
|---|---|
| Framework | Next.js 15 (App Router), React 19, TypeScript |
| State | Zustand (single store, `src/store/whiteboard.ts`) |
| Styling | Tailwind v4 + Radix UI primitives |
| Ink | `perfect-freehand` for stroke outlines |
| PDF | `pdfjs-dist` to open/render imported PDFs (worker copied into `public/` by `scripts/sync-pdf-worker.mjs`); `jspdf`, loaded lazily, to write exported PDFs |
| Desktop | Electron 43 + electron-builder |
| Android | Capacitor **6** (pinned — see Gotchas) |
| Accounts | Supabase (email/password + row-level security) |
| Cloud file sync | Microsoft Graph / OneDrive app-folder, OAuth 2.0 + PKCE |

---

## 5. Code map

### `src/lib/whiteboard/` — the engine (no React in here)

| File | Owns |
|---|---|
| `types.ts` | Every shared type, plus `PEN_TYPE_PRESETS` (ballpoint, gel, fineliner, fountain, brush, marker, highlighter, pencil), colour/size accessors (`getToolColor`/`setToolColor`, `getToolSize`/`setToolSize`), board background + paper-pattern constants, `PinnedPen`, `EraserMode` |
| `stroke.ts` | Ink geometry. Outline → SVG path, sharp-corner routing (130° threshold), terminal-hook pruning, speed→pressure, and the pixel eraser's `clipSegmentToCapsule` / `eraseFromStroke` |
| `geometry.ts` | World↔screen transforms, `screenSpaceOverlayTransform` |
| `grid.ts` | `GRID_SIZE`, snapping helpers |
| `notebook.ts` | Paged documents. The **only** sanctioned way to reach a board's elements: `getBoardElements` / `mapBoardElements` for the page being edited, `allElements` / `mapAllBoardElements` for the whole document (search, links, graph, export counts). A notebook's `board.elements` is always empty. Plus page geometry (`pageOffsetY`, `clampToSheet`) and every page operation. |
| `links.ts` | WikiLinks, tags, backlinks and `buildGraph()`. Reads every page through `allElements` - it used to read `board.elements`, so notebooks had no links, tags or graph edges. |
| `persistence.ts` | localStorage load/save, `migrate()` hardening, quota degradation |
| `workspace.ts` | Whole-workspace serialize/parse/**merge** (per-board by `updatedAt`) |
| `account.ts` | Supabase sign-up / sign-in / reset, push & pull workspace |
| `onedrive.ts` | PKCE OAuth, upload/download workspace to the OneDrive app folder |
| `export.ts` | Board → SVG / PNG / PDF, plus `saveBlob` (Android share sheet on the APK, ordinary download on web & Electron). A notebook exports **every page** by default (`pages: "current"` for one): one PDF page per sheet, or sheets stacked for SVG/PNG, each clipped to the paper with its ruling and any imported PDF underneath. Exports return an `ExportReport` counting missing pictures / PDF pages so the dialog can warn. |
| `pdf.ts`, `pdfstore.ts` | pdf.js loading and page rendering; the imported PDFs' bytes in IndexedDB |
| `imagestore.ts` | Image pixels in IndexedDB, referenced from elements as `asset:<id>`. Falls back to an inline data URL if IndexedDB fails, and fires `wb:image-inline` so the app warns |
| `placement.ts` | Where an inserted image lands and how big it is |
| `input.ts` | Wheel/trackpad normalisation, mouse-vs-trackpad detection |
| `palm.ts` | Palm rejection / touch classification |
| `shortcuts.ts` | Undo/redo combo matching (on `event.code`, not `event.key`) |

### `src/components/whiteboard/` — the UI

| File | Owns |
|---|---|
| `WhiteboardApp.tsx` | Top-level shell, header (Links / Search / Graph / Export / Sync / Settings) |
| `WhiteboardCanvas.tsx` | ~3400 lines. All pointer handling, rendering, paper pattern, erasing, the stylus-button bridge listener |
| `Toolbar.tsx` | Tool selection + view controls |
| `ToolProperties.tsx` | The contextual bar under the toolbar + the full ⚙ panel |
| `StepperControl.tsx` | Shared −/+ steppers used by every numeric slider |
| `NotebookPages.tsx` | Page bar (prev / next / count / add) and the thumbnail rail with drag-reorder, duplicate, delete and per-page paper |
| `ColorSwatches.tsx` | Swatches, custom-colour picker, recents |
| `SettingsPanel.tsx` | Appearance / board background / canvas / pens / touch / help |
| `FavoritePensBar.tsx` | Pinnable pens, drag to reorder, movable dock |
| `PropertiesPanel.tsx` | Properties of the current selection |
| `SelectionOverlay.tsx`, `SelectionActions.tsx` | Selection box, handles, actions |
| `InlineTextEditor.tsx` | In-place text/markdown editing + formatting bar |
| `GraphView.tsx` | Force-directed knowledge graph |
| `LinkManager.tsx`, `BacklinksPanel.tsx`, `LinkLegend.tsx` | Typed links between boards |
| `ExportModal.tsx` | PNG / SVG / PDF export UI |
| `SyncPanel.tsx`, `AccountSection.tsx` | Accounts, OneDrive, backup file |
| `Sidebar.tsx`, `Minimap.tsx`, `SearchModal.tsx`, `CanvasContextMenu.tsx` | Navigation |
| `ElementRenderer.tsx` | Draws one element of any type |
| `PdfPageLayer.tsx` | Renders the imported PDF under a notebook page |
| `SplitPane.tsx`, `SplitPicker.tsx` | Side-by-side split view of two documents |
| `DockControls.tsx`, `SelectToolButton.tsx` | Movable toolbar dock; the merged Select/Lasso tool |
| `FileDropZone.tsx` | Drag-and-drop of images and PDFs onto the app |
| `PenDiagnostics.tsx` | Settings → "Show pen diagnostics": raw pointer events plus the native stylus-button bridge |
| `TutorialModal.tsx`, `KeyboardShortcutsModal.tsx`, `ThemeToggle.tsx` | Onboarding, shortcut list, theme |

### Elsewhere

- `src/store/whiteboard.ts` — the single Zustand store: boards, elements,
  camera, history/undo, style, pinned pens, persistence.
- `electron/main.js` — the desktop app. Registers a custom `pronotes://`
  scheme (see Gotchas), path-traversal guard, single-instance lock.
- `android/app/src/main/java/com/idrees/pronotes/MainActivity.java` — reads the
  S Pen side button natively (the WebView never delivers it) and forwards it to
  the page as a `pronotes:stylusbutton` event.
- `scripts/` — `build-static.mjs` (the static export; also the preflight every
  packaged build shares: pdf-worker sync + type check), `build-apk.mjs`,
  `build-desktop.mjs`, `sync-pdf-worker.mjs`, `deploy-android.mjs`,
  `make-ico.mjs`, `make-android-icons.mjs`, `generate-icons.js`, `audit.mjs`,
  `test-runner.mjs`.
- `assets/pronotes-icon-source.jpg` — the master brand image all icons derive
  from. Keep it; the icon script reads it relative to itself.

---

## 6. Commands

```bash
npm run dev        # dev server on :3000 (builds into .next-dev)
npm run typecheck  # tsc --noEmit
npm run lint       # eslint with next/core-web-vitals + next/typescript
npm test           # regression + challenger + E2E suites
npm run build      # type check, then the production server build
npm run export     # type check + pdf-worker sync, then static export to ./out
npm run apk        # export, then ProNotes.apk   (build:apk is an alias)
npm run dist:win   # export, then the Windows installer + win-unpacked
npm run audit      # unreachable modules / risky patterns (leads, not verdicts)
```

**`npm run build:apk` used to be the static export only** - it did not build
an APK, which made it easy to ship a stale `ProNotes.apk`. It is now an alias of
`npm run apk`; the export alone is `npm run export`.

Every packaged build goes through `scripts/build-static.mjs`, which syncs the
pdf.js worker and runs the type check first and refuses to build on a type
error. `PRONOTES_SKIP_TYPECHECK=1` skips the check in an emergency.
`public/pdf.worker.min.mjs` is generated (postinstall and every build) and is
not committed. Once the check passes, the wrapper sets `PRONOTES_TYPECHECKED=1`
for the child `next build` so Next skips its duplicate type pass
(`ignoreBuildErrors` in `next.config.ts` is true only with that marker) — a
bare `npx next build` never sets it, so it still fails on type errors.
`npm run build` does the same via `scripts/build.mjs`.

Testing: a regression suite, a "challenger" suite (~12,289 assertions), ~259
E2E tests, and two notebook suites (`notebook.test.ts` for the pure page model,
`notebook_store.test.ts` for the store wiring), plus `duplicate_notebook`,
`workspace_store_v2` (the IndexedDB quota fix, incl. a 6 MB tablet replay) and
`shape_tools` (fill, tap-insert, tap-select, inspector rules).
See `TEST_INFRA.md`.

**If you add a store action that touches elements**, route it through
`mapBoardElements` and add a case to `notebook_store.test.ts`. A direct
`board.elements` write compiles fine and silently loses notebook strokes.

---

## 7. Feature inventory

- Infinite pan/zoom canvas; mouse, trackpad, touch and stylus input with palm
  rejection
- Eight pen families with per-pen colour and size, pressure/speed response,
  taper and blend modes
- **Favourite pens bar** — pin any pen in any colour, several of the same type,
  drag to reorder, move the dock
- Shapes, lines/arrows, text, sticky notes, images, lasso and box select
- **Pixel eraser** (erases the part you touch, splitting strokes) and whole-object eraser
- **Two document kinds in one tree**: the infinite canvas, and paged
  **notebooks** (A4 / Letter / landscape / square) with page navigation, a
  thumbnail rail, drag-to-reorder, duplicate and delete. PageUp / PageDown
  turn pages. An existing canvas can be converted to a notebook (its content
  becomes page 1); there is no reverse, since flattening pages would have to
  overlap or discard them. Undo spans the notebook and returns you to the page
  the edit happened on.
- Per-board background colour and paper pattern (dots/grid/lines/plain) with
  adjustable **paper size** — and **per-page** paper inside a notebook, so one
  document can mix templates
- `[[WikiLinks]]`, typed links, backlinks panel, force-directed graph view
- Folders, search, minimap, keyboard shortcuts, undo/redo
- Export to PNG (1×/2×/3×, white/dark/transparent), SVG and PDF; copy PNG to
  clipboard; on Android these go to the system share sheet
- Local-first storage with debounced autosave; optional account sync and OneDrive
- Settings persist across restarts (style, tool, touch settings, toggles)

---

## 8. Setup you still have to do yourself

Both are free and optional — the app works fully without them.

1. **Supabase** (~5 min) for accounts/sync. Create a project, put
   `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY` in
   `.env.local`, and run the row-level-security SQL in `ACCOUNTS_SETUP.md`.
2. **Microsoft app registration** (~2 min) for OneDrive.
   `NEXT_PUBLIC_MS_CLIENT_ID` — see `ONEDRIVE_SETUP.md`.

Template: `.env.local.example`.

---

## 9. Outstanding work

| Item | Status |
|---|---|
| Android share sheet (export was dead on the tablet) | **done** — needs a real-device test |
| PDF export | **done** — verified end to end in the browser |
| −/+ steppers on all seven numeric sliders | **done** |
| Rebuild APK with everything since 2026-09-04 | **done** — see `ProNotes.apk` in the project root (~6 MB as of 2026-09-19; sizes here go stale, check the file) |
| APK `versionCode` was stuck at 1 | **done** 2026-09-19 — computed by `scripts/build-apk.mjs` from the build time; `versionName` comes from `package.json` (1.1.0), shared with the Windows app |
| Service worker ran inside the APK and could serve a stale pdf.js worker after an update | **done** 2026-09-19 — only registers on the http(s) web build in production; elsewhere it is unregistered and its caches cleared |
| Home-screen shortcuts (`/?action=new`, `/?view=graph`) did nothing | **done** 2026-09-19 — handled in `WhiteboardApp.tsx` |
| 42 unused npm dependencies | **done** — 71 deps down to 29 (30 + 12 dev as of 2026-09-19) |
| `app.asar` shipped 340 MB of node_modules | **done** — 340.6 MB down to 3.4 MB |
| Windows `.exe` was the 2026-09-04 build | **done** — rebuilt 2026-09-09, launches in 0.5 s |
| ESLint config has ignores but no rules — it lints almost nothing | **done** 2026-09-19 — `next/core-web-vitals` + `next/typescript`; 0 errors, ~260 warnings (mostly unused variables) to work down |
| Notebook export wrote only the active page while the dialog counted all | **done** 2026-09-19 |
| `links.ts` ignored notebook pages (no links/tags/graph) | **done** 2026-09-19 |
| Exports built into the dev server's `.next` | **done** 2026-09-19 — dev uses `.next-dev` |
| Nothing enforced types (`ignoreBuildErrors`, no tsc step) | **done** 2026-09-19 — type check in every build path |
| Android `targetSdk 34`; Google Play requires 35 | not done — only matters for Play publishing, and API 35 forces edge-to-edge layout, which needs testing on the tablet first |
| OneDrive sign-in in the packaged apps | open — see `ONEDRIVE_SETUP.md` (the redirect URIs differ per platform) |
| `PROJECT.md` / `README.md` were three weeks stale | **done** — `PROJECT.md` deleted, `README.md` rewritten, `MAP.md` added (2026-09-18) |
| `CHANGELOG_FIXES.md` STEP numbers 21–27 are each duplicated | **done** 2026-09-19 — renumbered 27–36, mapping at the top of the file |

### Deleted in the 2026-09-09 cleanup

`ProNotes.vbs`, `Build-ProNotes.bat`, `Stop-ProNotes.bat`, `start.bat` — the
obsolete Edge-app launcher, superseded by the real `.exe` and the direct cause
of the "pinned icon is wrong" bug. `pen-sampler.svg` — a stroke-tuning debug
artifact. Plus `.next`, `.test-dist`, `out`, `android/app/build`,
`tsconfig.tsbuildinfo` and the Sept-4 installers, all of which regenerate.
Copies of the small deleted files are in the session scratchpad.

### Package sizes after the 2026-09-09 rebuild

| | Before | After |
|---|---|---|
| `app.asar` | 340.6 MB | **3.4 MB** |
| `win-unpacked` | 901 MB | **360 MB** |
| Installer / portable `.exe` | 194 MB each | **100 MB each** |
| Project on disk | 2,774 MB | **1,722 MB** |
| npm dependencies | 71 | **29** |

The desktop package was carrying its whole `node_modules` — 37,807 of
`app.asar`'s 37,885 entries. `"!node_modules/**/*"` in the electron-builder
`files` list is what removes it; do not drop that line.

**First launch after a rebuild takes ~17 s** while Windows Defender scans the
new binaries. Every launch after that is ~0.5 s. This is not a regression.

---

## 10. Gotchas — read before changing anything

Traps that have already cost real time.

**Capacitor is pinned to 6.x.** Capacitor 8 requires JDK 21; this machine has
JDK 17. Upgrading fails with `invalid source release: 21`.

**Electron loads via `pronotes://`, not `file://`.** Next.js emits absolute
asset paths (`/_next/...`) which `file://` resolves against the drive root and
fails to find, and `file://` is an opaque origin so `localStorage` would not
persist — and every board lives in localStorage. The scheme is registered
`standard: true, secure: true` to give it a stable secure origin.

**`unzip` globs do not cross `/`.** A pattern like `assets/public/*` matches
nothing several levels deep. This once produced a confident, completely false
"the APK is missing every feature" report. Extract and search recursively.

**Keyboard shortcuts must match on `event.code`, not `event.key`.** `event.key`
carries the *shifted* character, so Ctrl+Shift+Z arrives as `Z` and Caps Lock
breaks Ctrl+Z.

**SVG transform lists apply right-to-left.** The inverse of a composed
transform is the reversed order. Getting this wrong looked fine at zoom 1 and
drifted 1285 px at 2.4×.

**Test layout bugs at the size that fails.** A panel-overlap bug was declared
fixed after a 1600×900 sweep; it reproduced instantly at 900×700.

**Electron's binary may not download** because npm postinstall scripts are
blocked. Fix: `node node_modules/electron/install.js`.

**Windows Smart App Control blocks the app the first time after a rebuild.**
Confirmed 2026-09-09: SAC is in *Enforcement* mode (`HKLM:\SYSTEM\CurrentControlSet\Control\CI\Policy` → `VerifiedAndReputablePolicyState = 1`)
and every binary here is unsigned, so a freshly written `ProNotes.exe` has no
reputation and the first launch dies with "An Application Control policy has
blocked this file" (CodeIntegrity event 3118). **Just launch it again** — the
second attempt succeeds, verified twice in a row, and it then keeps working at
~0.4s. The portable `ProNotes <version>.exe` is unaffected because it extracts a
fresh copy to `%TEMP%` on each run.

SAC can only be turned *off*, never back on without reinstalling Windows, so
it was deliberately left alone — that is the user's call. The real fix is a
code-signing certificate; an EV certificate is trusted by SAC immediately.

**Python `str.replace` fails silently** when the pattern does not match. Always
assert the replacement count when patching files this way, and write via a
temp file + `os.replace` so a crash cannot truncate the original.

**Stylus side button on Android is NATIVE.** Chromium's WebView never delivers
the S Pen side button to web content, so no pointer-event code can see it.
`MainActivity.java` reads `getButtonState()` and forwards it. Android clears
the button bits on `ACTION_UP`, and fires `ACTION_HOVER_EXIT` before every
touch-down - both caused visible bugs when handled naively. See that file.

**Three tests once encoded buggy behaviour** and had to be rewritten to assert
the corrected intent. If a test fails after a genuine fix, check whether the
test was wrong before "fixing" the code back.

---

## 11. Starting a new chat

Point the new session at this file:

> Read `C:\Users\idree\Documents\pronotesdevelop\HANDOFF.md`, then <your task>.

That plus `CHANGELOG_FIXES.md` (for the detail behind any single fix) is
everything needed to pick the project up cold.
