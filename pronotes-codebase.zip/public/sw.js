/**
 * ProNotes Service Worker
 * ========================
 * Provides offline caching, asset caching (Cache-First with SWR),
 * and navigation fallback (Network-First) for standalone PWA.
 */

// Bump on every deploy: 'activate' deletes every cache whose key differs,
// so stale hashed chunks and old entries never accumulate.
const CACHE_VERSION = 'pronotes-v4.3.0';
const STATIC_ASSETS = [
  '/',
  '/manifest.json',
  '/favicon.ico',
  '/favicon.png',
  '/favicon-32x32.png',
  '/favicon-16x16.png',
  '/icon-192.png',
  '/icon-512.png',
  '/icon-192-maskable.png',
  '/icon-512-maskable.png',
  '/apple-touch-icon.png',
  '/logo.png',
];

// Install: pre-cache core application shell
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches
      .open(CACHE_VERSION)
      .then((cache) => cache.addAll(STATIC_ASSETS))
      .then(() => self.skipWaiting())
  );
});

// Activate: clean up old cache versions & claim clients immediately
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(
          keys.map((key) => {
            if (key !== CACHE_VERSION) {
              return caches.delete(key);
            }
          })
        )
      )
      .then(() => self.clients.claim())
  );
});

// Fetch: smart caching strategies
self.addEventListener('fetch', (event) => {
  const request = event.request;

  // Only handle GET requests
  if (request.method !== 'GET') {
    return;
  }

  const url = new URL(request.url);

  // Ignore API requests and browser extension requests
  if (url.pathname.startsWith('/api') || !url.protocol.startsWith('http')) {
    return;
  }

  // Next.js App Router data (RSC payloads / prefetches) must NOT be served
  // cache-first: after a deploy they would be inconsistent with freshly
  // loaded hashed JS chunks. Let them go to the network (browser HTTP cache
  // still applies) and never store them here.
  if (request.headers.get('RSC') === '1' || request.headers.has('Next-Router-Prefetch')) {
    return;
  }

  // 1. Navigation requests (HTML pages): Network-First, fallback to cached '/'
  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request)
        .then((networkResponse) => {
          if (networkResponse && networkResponse.status === 200) {
            const responseToCache = networkResponse.clone();
            event.waitUntil(
              caches.open(CACHE_VERSION).then((cache) => cache.put(request, responseToCache))
            );
          }
          return networkResponse;
        })
        .catch(() => caches.match('/'))
    );
    return;
  }

  // 2. Static assets (JS bundles, CSS, images, fonts): Cache-First with SWR
  event.respondWith(
    caches.match(request).then((cachedResponse) => {
      if (cachedResponse) {
        // Stale-While-Revalidate: fetch in background to keep cache fresh
        // (kept alive via event.waitUntil so the SW isn't terminated first)
        event.waitUntil(
          fetch(request)
            .then((networkResponse) => {
              if (networkResponse && networkResponse.status === 200) {
                return caches
                  .open(CACHE_VERSION)
                  .then((cache) => cache.put(request, networkResponse));
              }
            })
            .catch(() => {
              // Offline or network error; ignore background update failure
            })
        );
        return cachedResponse;
      }

      // If not in cache, fetch from network and cache
      return fetch(request).then((networkResponse) => {
        if (!networkResponse || networkResponse.status !== 200) {
          return networkResponse;
        }
        const responseToCache = networkResponse.clone();
        event.waitUntil(
          caches.open(CACHE_VERSION).then((cache) => cache.put(request, responseToCache))
        );
        return networkResponse;
      });
    })
  );
});
